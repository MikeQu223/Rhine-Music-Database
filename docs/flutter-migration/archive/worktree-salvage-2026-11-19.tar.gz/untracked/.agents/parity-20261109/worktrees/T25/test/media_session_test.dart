// 系统媒体控件端口与动作映射的单元测试（只写不跑）。
//
// 覆盖当前原子可写域内的全部行为：
// - MediaSessionAction.parse：Java 侧动作词表与 rhine.media.SEEK: 前缀解析；
// - mediaPlaybackIntent：NativeApplication::mediaAction 的四个出口与 seek 抑制；
// - MediaPlaybackDispatcher：意图到注入回调的路由；
// - MediaSessionPort：接口可注入性与宿主调用顺序契约（供 MediaSessionSync 原子沿用）；
// - mediaSessionStandby / MediaSessionThrottle：Qt 的待机判定与 1000ms 上报节流时序。
//
// 按任务禁令，本文件未执行（未跑 flutter test / dart test），
// 首次执行结果留待集成侧记录 RED/GREEN。
//
// INTEGRATION：下面 import 的 package:rhine_music_database/domain/models/media_snapshot.dart
// 当前不在本工作树（SHARED-S4 仍 pending，lib/ 下只有 main.dart 与 platform/media_session.dart），
// 因此本文件与端口文件一样在当前树无法编译。这是已知整合缺口，不是断言 RED。
import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/domain/models/media_snapshot.dart';
import 'package:rhine_music_database/platform/media_session.dart';

/// 记录型端口实现：只用于证明 [MediaSessionPort] 可注入，不做业务断言。
class _FakeMediaSessionPort implements MediaSessionPort {
  _FakeMediaSessionPort(this._incoming);

  final Stream<MediaSessionAction> _incoming;
  final List<String> calls = <String>[];

  @override
  Future<void> ensureStarted() async {
    calls.add('ensureStarted');
  }

  @override
  Future<void> update(MediaSnapshot snapshot) async {
    calls.add('update');
  }

  @override
  Future<void> stop() async {
    calls.add('stop');
  }

  @override
  Stream<MediaSessionAction> get actions => _incoming;
}

void main() {
  group('MediaSessionAction.parse', () {
    test('定长词表逐字往返', () {
      const wires = <String>['resume', 'pause', 'toggle', 'next', 'prev'];
      for (final wire in wires) {
        expect(MediaSessionAction.parse(wire).wire, wire);
      }
    });

    test('定长词表落到对应子类', () {
      expect(MediaSessionAction.parse('resume'), isA<MediaSessionResume>());
      expect(MediaSessionAction.parse('pause'), isA<MediaSessionPause>());
      expect(MediaSessionAction.parse('toggle'), isA<MediaSessionToggle>());
      expect(MediaSessionAction.parse('next'), isA<MediaSessionNext>());
      expect(MediaSessionAction.parse('prev'), isA<MediaSessionPrevious>());
    });

    test('seek 前缀携带小数毫秒', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix + '1250.5');
      expect(action, isA<MediaSessionSeek>());
      expect((action as MediaSessionSeek).positionMs, 1250.5);
      expect(action.wire, mediaSessionSeekPrefix + '1250.5');
    });

    test('seek 整数毫秒回写不带小数点', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix + '60000') as MediaSessionSeek;
      expect(action.positionMs, 60000.0);
      expect(action.wire, mediaSessionSeekPrefix + '60000');
    });

    test('空载荷按 QString::toDouble 语义得 0.0', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix) as MediaSessionSeek;
      expect(action.positionMs, 0.0);
      expect(action.wire, mediaSessionSeekPrefix + '0');
    });

    test('非数字载荷得 0.0 且不抛异常', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix + 'abc') as MediaSessionSeek;
      expect(action.positionMs, 0.0);
    });

    test('首尾空白按 toDouble 语义被忽略', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix + '  12.5 ') as MediaSessionSeek;
      expect(action.positionMs, 12.5);
    });

    test('负毫秒在 wire 层原样保留，交由意图映射夹取', () {
      final action = MediaSessionAction.parse(mediaSessionSeekPrefix + '-5') as MediaSessionSeek;
      expect(action.positionMs, -5.0);
      expect(action.wire, mediaSessionSeekPrefix + '-5');
    });

    test('未识别动作原样保留', () {
      final action = MediaSessionAction.parse('buffering');
      expect(action, isA<MediaSessionUnknown>());
      expect((action as MediaSessionUnknown).raw, 'buffering');
      expect(action.wire, 'buffering');
    });

    test('词表大小写敏感，RESUME 属未识别', () {
      expect(MediaSessionAction.parse('RESUME'), isA<MediaSessionUnknown>());
    });

    test('空串属未识别', () {
      expect(MediaSessionAction.parse(''), isA<MediaSessionUnknown>());
    });
  });

  group('mediaPlaybackIntent', () {
    MediaPlaybackIntent? intentOf(String wire, {num durationMs = 0}) {
      return mediaPlaybackIntent(MediaSessionAction.parse(wire), durationMs: durationMs);
    }

    test('resume 解析为 setPaused(false)', () {
      final intent = intentOf('resume') as MediaSetPaused;
      expect(intent.paused, isFalse);
    });

    test('pause 解析为 setPaused(true)', () {
      final intent = intentOf('pause') as MediaSetPaused;
      expect(intent.paused, isTrue);
    });

    test('next / prev 解析为方向 +1 / -1', () {
      expect((intentOf('next') as MediaStepTrack).direction, 1);
      expect((intentOf('prev') as MediaStepTrack).direction, -1);
    });

    test('toggle 走 hud 命名空间而非 setPaused', () {
      final intent = intentOf('toggle');
      expect(intent, isA<MediaHudAction>());
      expect((intent as MediaHudAction).action, 'player:toggle');
    });

    test('未识别动作落到 player: 前缀兜底', () {
      final intent = intentOf('buffering') as MediaHudAction;
      expect(intent.action, 'player:buffering');
    });

    test('seek 落在区间内按比例换算', () {
      final intent = intentOf(mediaSessionSeekPrefix + '50000', durationMs: 200000) as MediaSeekFraction;
      expect(intent.fraction, 0.25);
    });

    test('seek 超出时长夹到 1.0', () {
      final intent = intentOf(mediaSessionSeekPrefix + '300000', durationMs: 200000) as MediaSeekFraction;
      expect(intent.fraction, 1.0);
    });

    test('seek 负位置夹到 0.0', () {
      final intent = intentOf(mediaSessionSeekPrefix + '-5', durationMs: 200000) as MediaSeekFraction;
      expect(intent.fraction, 0.0);
    });

    test('seek 载荷无效时得 0.0 比例并仍产生意图', () {
      final intent = intentOf(mediaSessionSeekPrefix + 'abc', durationMs: 200000) as MediaSeekFraction;
      expect(intent.fraction, 0.0);
    });

    test('duration 为 0 抑制 seek', () {
      expect(intentOf(mediaSessionSeekPrefix + '5000', durationMs: 0), isNull);
    });

    test('duration 为负抑制 seek', () {
      expect(intentOf(mediaSessionSeekPrefix + '5000', durationMs: -1), isNull);
    });

    test('duration 为 NaN 抑制 seek', () {
      expect(intentOf(mediaSessionSeekPrefix + '5000', durationMs: double.nan), isNull);
    });
  });

  group('MediaPlaybackDispatcher', () {
    late List<String> log;
    late MediaPlaybackDispatcher dispatcher;

    setUp(() {
      log = <String>[];
      dispatcher = MediaPlaybackDispatcher(
        setPaused: (paused) => log.add(paused ? 'setPaused:true' : 'setPaused:false'),
        stepTrack: (direction) => log.add('stepTrack:' + direction.toString()),
        seekFraction: (fraction) => log.add('seekFraction:' + fraction.toString()),
        hudAction: (action) => log.add('hudAction:' + action),
      );
    });

    test('各意图路由到各自回调且只触发一次', () {
      expect(dispatcher.dispatch(const MediaSetPaused(true)), isTrue);
      expect(dispatcher.dispatch(const MediaStepTrack(-1)), isTrue);
      expect(dispatcher.dispatch(const MediaSeekFraction(0.375)), isTrue);
      expect(dispatcher.dispatch(const MediaHudAction('player:toggle')), isTrue);
      expect(log, <String>[
        'setPaused:true',
        'stepTrack:-1',
        'seekFraction:0.375',
        'hudAction:player:toggle',
      ]);
    });

    test('空意图不产生任何调用并返回 false', () {
      expect(dispatcher.dispatch(null), isFalse);
      expect(log, isEmpty);
    });
  });

  group('MediaSessionPort 契约', () {
    test('端口可注入实现，动作流按解析结果送达订阅者', () async {
      final controller = StreamController<MediaSessionAction>();
      final port = _FakeMediaSessionPort(controller.stream);
      final received = <MediaSessionAction>[];
      final subscription = port.actions.listen(received.add);

      controller.add(MediaSessionAction.parse('next'));
      await Future<void>.delayed(Duration.zero);

      expect(received.single, isA<MediaSessionNext>());
      await subscription.cancel();
      await controller.close();
    });

    // 接口形状用例（不是行为断言）：只证明 fake 可注入、重复 start 无害、actions 是 Stream。
    // 真正的「先 ensureStarted 再 update、待机走 stop」行为属后续 MediaSessionSync 原子。
    test('接口形状：fake 可注入、重复 start 无害、actions 为 Stream', () async {
      final port = _FakeMediaSessionPort(const Stream<MediaSessionAction>.empty());
      await port.ensureStarted();
      await port.ensureStarted();
      await port.stop();
      expect(port.calls, <String>['ensureStarted', 'ensureStarted', 'stop']);
      expect(port.actions, isA<Stream<MediaSessionAction>>());
    });
  });

  // 待机判定逐字对应 Qt/src/PlatformAndroid.cpp:64：
  //   if (title.isEmpty() || state.value("duration").toLongLong() <= 0) { AndroidMediaSession::stop(); return; }
  // 判定为待机时调用方走 stop（不是撤岗），否则先 ensureStarted 再 update。
  group('mediaSessionStandby（PlatformAndroid.cpp:64）', () {
    test('标题为空即待机，与时长无关', () {
      expect(mediaSessionStandby(title: '', durationMs: 300000), isTrue);
    });

    test('时长 <= 0 即待机，与标题无关', () {
      expect(mediaSessionStandby(title: '夜曲', durationMs: 0), isTrue);
      expect(mediaSessionStandby(title: '夜曲', durationMs: -1), isTrue);
    });

    test('有标题且时长为正才不待机', () {
      expect(mediaSessionStandby(title: '夜曲', durationMs: 1), isFalse);
      expect(mediaSessionStandby(title: '夜曲', durationMs: 266000), isFalse);
    });

    test('标题为空白字符不算空：Qt 用的是 isEmpty 而非 trim', () {
      expect(mediaSessionStandby(title: ' ', durationMs: 1000), isFalse);
    });
  });

  // 上报节流逐字对应 Qt/src/Host.cpp:993-994 与 Host.h:137：
  //   if (!offline && now - lastMediaUpdate >= 1000) { lastMediaUpdate = now; platformMediaInfo(...); }
  // 初始 lastMediaUpdate = 0，故首帧必到点；到点先记账再发布。
  group('MediaSessionThrottle（Host.cpp:993 / Host.h:137）', () {
    test('默认间隔是 Qt 的 1000ms', () {
      expect(mediaSessionReportIntervalMs, 1000);
      expect(MediaSessionThrottle().intervalMs, 1000);
    });

    test('初始 lastMediaUpdate=0：真实时钟下第一次调用必然到点', () {
      // Qt 的 now 是 QDateTime::currentMSecsSinceEpoch()，量级远大于 1000，
      // 因此 lastMediaUpdate 初值 0 保证首帧到点（Host.cpp:992-993）。
      var now = 1000000;
      final throttle = MediaSessionThrottle(clock: () => now);
      expect(throttle.due(), isTrue);

      // 边界如实钉住：首帧必到点的前提是 now 已达 epoch 量级。
      // 时钟真为 0 时 0 - 0 = 0 < 1000，判据本身就不会放行——
      // 这是 Host.cpp:993 的必然结果，不是缺陷，也不许为它改产品实现。
      final atZero = MediaSessionThrottle(clock: () => 0);
      expect(atZero.due(), isFalse);
    });

    test('未满 1000ms 不再到点，满 1000ms 到点', () {
      var now = 1000000;
      final throttle = MediaSessionThrottle(clock: () => now);

      expect(throttle.due(), isTrue); // 记账 now=1000000
      now = 1000999;
      expect(throttle.due(), isFalse); // 差 999ms
      now = 1001000;
      expect(throttle.due(), isTrue); // 差 1000ms，边界含等号
    });

    test('到点后以本次时间重新记账，不累积偏差', () {
      var now = 5000;
      final throttle = MediaSessionThrottle(clock: () => now);
      expect(throttle.due(), isTrue); // 记账 5000
      now = 7000;
      expect(throttle.due(), isTrue); // 记账 7000（不是 5000+1000）
      now = 7999;
      expect(throttle.due(), isFalse); // 相对 7000 差 999ms
      now = 8000;
      expect(throttle.due(), isTrue);
    });

    test('invalidate 归零后下一次立即到点（Host.cpp:960/968/982）', () {
      var now = 42000;
      final throttle = MediaSessionThrottle(clock: () => now);
      expect(throttle.due(), isTrue);
      now = 42001;
      expect(throttle.due(), isFalse);
      throttle.invalidate();
      expect(throttle.due(), isTrue);
    });

    test('间隔可注入，行为仍是 >= intervalMs', () {
      // 起点同样取 epoch 量级，首帧才在 250ms 判据下到点（250 - 0 >= 250）。
      var now = 250;
      final throttle = MediaSessionThrottle(intervalMs: 250, clock: () => now);
      expect(throttle.due(), isTrue); // 记账 250
      now = 499;
      expect(throttle.due(), isFalse); // 差 249ms，不到点
      now = 500;
      expect(throttle.due(), isTrue); // 差 250ms，边界含等号
    });
  });
}
