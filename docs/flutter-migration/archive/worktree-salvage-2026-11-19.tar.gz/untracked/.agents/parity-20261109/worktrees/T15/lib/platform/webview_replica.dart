// T15-C18-A3 - Flutter side of the local WebView replica host (plan candidate E).
//
// Qt is the specification. This file re-derives the host rules from it and invents no protocol:
//   Qt/src/NativeHud.h:74-76       commands / hits / frame are the only published HUD values
//   Qt/src/NativeHud.cpp:102-109   hits carry exactly {x, y, width, height, action, label}
//   Qt/src/PlayerBar.cpp:46-53     only the PlayerBar hit adds fixed: true
//   Qt/src/Engine.cpp:841-849      Engine::resize sets the surface size; stageScale = height / 1080
//   Qt/src/Engine.cpp:1348,1379    one published object carries commands (m_commands = commands)
//   Qt/src/Engine.cpp:1412         hits are read from that same published object
//   Qt/src/Engine.cpp:1353         stageWidth = width / (height / 1080), fallback 1920
//   docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:183-213
//                                  command array contract, hits/frame, generation for consistency only
//
// Page side (web/rhine_replica/index.html, read-only for this atom):
//   :392-399  the eight documented entries of window.__rhineRail (assets accessor at :400)
//   :402      window.__rhineReady = true, set after the rail object is installed
//   :88-99    outbound window.__rhineHost.postMessage(JSON.stringify({type, payload}))
//   :57-59    outbound whitelist ready|firstFrame|publish|state|error|console
//   :75,118   the stage starts at scale 0 and applyHudTransform multiplies by it, so a publish
//             that arrives before resize() paints at zero scale - which is why the host refuses it
//
// Nothing here has been executed. flutter/dart execution is forbidden in this phase, so the atom
// report records every test that covers this file as RED-not-executed.
//
// No platform binding is imported on purpose: the transport is injected, so this library compiles
// and runs under plain Dart as well as under flutter_test, and pubspec.yaml may not gain a
// dependency (there is no webview_flutter, and no package:flutter/services.dart import below).
// A real host plugs a WebView-backed transport in; nothing in this file knows about Android.

import "dart:async";
import "dart:convert";

// ---------------------------------------------------------------------------------------------
// Contract constants. Every one names the line that publishes it.
// ---------------------------------------------------------------------------------------------

/// The logical HUD stage is always 1080 tall: Qt/src/Engine.cpp:847, and the page agrees
/// (web/rhine_replica/renderer.js:28 defines STAGE_HEIGHT = 1080)
/// scene.resize(width / (height / 1080), 1080).
const double kStageHeight = 1080.0;

/// Rail version, published twice by the page: index.html:381 (hello) and :391 (rail object).
const String kRailVersion = "T15-S01-rail-1";

/// The eight documented inbound entries of window.__rhineRail (index.html:392-399).
/// The assets accessor at index.html:400 is deliberately not here: it is a read-only internal,
/// and keeping it out of this list is what makes the host surface provably exclusive (M12-F8 of
/// reports/T15-S01-M12-R.json asks for that check to be real rather than a string grep).
const List<String> kRailEntries = <String>[
  "resize", //      index.html:126  (logicalWidth, logicalHeight)
  "publish", //     index.html:227  ({generation, commands, hits, frame}) or its JSON string
  "state", //       index.html:268  () -> {generation, hits, logical, stage, counters, ...}
  "conformance", // index.html:294  () -> [{id, ok, expected, actual, note}]
  "loadAssets", //  index.html:311  (base, letteringBase) -> Promise
  "attachAsset", // index.html:338  (kind, key, value) -> {ok, reason?}
  "attachImage", // index.html:351  (key, src) -> {ok} or a Promise
  "hello", //       index.html:379  () -> {version, stageHeight, devicePixelRatio, ...}
];

/// Outbound types the page may emit (index.html:57-59). Anything else is counted, never ignored.
const List<String> kOutboundTypes = <String>[
  "ready",
  "firstFrame",
  "publish",
  "state",
  "error",
  "console",
];

/// The twelve in-page conformance ids the page must answer (web/rhine_replica/renderer.js:633-763,
/// mirrored by test/spike/webview/renderer_contract_test.dart:55-68). The host invents no new id:
/// expectedConformanceIds may be replaced with whatever the page actually answers.
const List<String> kConformanceIds = <String>[
  "alpha-multiplicative",
  "clip-intersect",
  "path-dash-normalized",
  "arc-angle-mapping",
  "right-mask-stops",
  "gradient-spec",
  "color-calibration",
  "glyph-baseline",
  "unknown-op-ignored",
  "hits-contract",
  "stage-math",
  "no-dedupe",
];

/// The six published hit keys (Qt/src/NativeHud.cpp:102-109), plus the PlayerBar-only fixed flag
/// (Qt/src/PlayerBar.cpp:46-53).
const Set<String> kHitKeys = <String>{"x", "y", "width", "height", "action", "label"};

/// The only hit key tolerated outside kHitKeys (Qt/src/PlayerBar.cpp:46-53).
const Set<String> kOptionalHitKeys = <String>{"fixed"};

/// Asset kinds attachAsset accepts (index.html:338-349): anything else is an unknown-kind refusal.
const List<String> kAssetKinds = <String>["glyphs", "lettering", "image"];

/// Every own member of window.__rhineRail (index.html:390-401): the version string, the eight
/// callable entries, and the assets accessor. kRailEntries is this list minus the two
/// non-callable members, so the two statements cannot drift apart unnoticed.
const List<String> kRailMembers = <String>[
  "version",
  "resize",
  "publish",
  "state",
  "conformance",
  "loadAssets",
  "attachAsset",
  "attachImage",
  "hello",
  "assets",
];

/// The members of that object which are not inbound calls: page state and page identity
/// (index.html:391 version, :400 assets). A host must never call either.
const Set<String> kRailNonCallableMembers = <String>{"version", "assets"};

/// The four refusals window.__rhineRail.publish() can answer with (index.html:235 unparsable,
/// :240 malformed, :244 incomplete-generation-triple, :249 missing-generation). They are page
/// vocabulary: when the page answers one, the host reuses the string verbatim rather than
/// translating it.
const List<String> kPublishRejectionReasons = <String>[
  "unparsable",
  "malformed",
  "incomplete-generation-triple",
  "missing-generation",
];

/// The keys of a successful publish answer (index.html:265).
const List<String> kPublishResultKeys = <String>["ok", "generation", "ops", "hits"];

/// The three payload keys the page sends with publish (index.html:264), without the ok flag the
/// synchronous answer carries.
const List<String> kPublishPayloadKeys = <String>["generation", "ops", "hits"];

/// The payload of the single firstFrame envelope (index.html:260-262). It is sent once, on the
/// first accepted publish only, which is why the host treats it as a one-shot event.
const List<String> kFirstFramePayloadKeys = <String>["at", "generation", "ops"];

/// resize()'s refusal when the surface is not positive (index.html:130).
const String kResizeBadSizeReason = "bad-size";

/// attachAsset()'s refusal for a kind outside kAssetKinds (index.html:346).
const String kAttachUnknownKindReason = "unknown-kind";

/// state()'s snapshot keys (index.html:268-291). The host reads the stage out of this answer, so
/// a page refactor that drops one of them must fail loudly.
const List<String> kStateSnapshotKeys = <String>[
  "generation",
  "hits",
  "logical",
  "stage",
  "devicePixelRatio",
  "firstFrame",
  "ops",
  "counters",
  "assets",
  "assetErrors",
  "errors",
  "three",
];

/// The eight counters inside that snapshot (index.html:277-286).
const List<String> kStateCounterKeys = <String>[
  "published",
  "rejected",
  "rendered",
  "unknownOps",
  "missingGlyphs",
  "missingImages",
  "missingArt",
  "layoutFallbacks",
];

/// The three asset groups inside that snapshot (index.html:287).
const List<String> kStateAssetKeys = <String>["glyphs", "lettering", "images"];

/// hello()'s answer keys (index.html:379-388). It is the only entry that is safe to call before
/// ready, because it needs no page state beyond the version and the probes.
const List<String> kHelloKeys = <String>[
  "version",
  "stageHeight",
  "devicePixelRatio",
  "webgl2",
  "path2d",
  "userAgent",
];

/// The reason the page records when the optional three.js module is absent (index.html:203).
/// The host never fabricates present: true in its place (index.html:81 is the same initial
/// shape with present: false).
const String kSceneModuleAbsentReason = "scene-module-absent";

// Host-side error codes. The page has its own vocabulary (index.html:130 bad-size, :235
// unparsable, :240 malformed, :244 incomplete-generation-triple, :249 missing-generation,
// :256 render-failed, :346 unknown-kind) and those strings are reused verbatim when the page
// rejects a call.
const String kErrorNotReady = "not-ready";
const String kErrorResizeRequired = "resize-required";
const String kErrorUnknownRailEntry = "unknown-rail-entry";
const String kErrorBadEnvelope = "bad-envelope";
const String kErrorHitContract = "hit-contract";
const String kErrorCommandContract = "command-contract";
const String kErrorUnknownKind = "unknown-kind";
const String kErrorRemoteImage = "remote-image";
const String kErrorUnencodable = "unencodable-payload";
const String kErrorNonFiniteNumber = "non-finite-number";
const String kErrorTransport = "transport-failed";
const String kErrorPageError = "page-error";
const String kErrorStageMismatch = "stage-mismatch";
const String kErrorRailVersion = "rail-version";
const String kErrorDisposed = "disposed";

// ---------------------------------------------------------------------------------------------
// Value types.
// ---------------------------------------------------------------------------------------------

/// The single error type of this library. A failure is surfaced, never swallowed: transport
/// failures, page rejections and contract violations all arrive as this.
class WebViewReplicaError implements Exception {
  const WebViewReplicaError(this.code, this.message, {this.entry, this.cause});

  /// Either a host code from this file or a verbatim page reason (index.html:130-256).
  final String code;

  /// Human readable detail; never used as control flow.
  final String message;

  /// The rail entry the failure belongs to, when one is known.
  final String? entry;

  /// The wrapped cause, for a FormatException or a transport exception.
  final Object? cause;

  @override
  String toString() => entry == null
      ? "WebViewReplicaError(" + code + "): " + message
      : "WebViewReplicaError(" + code + ") at " + entry! + ": " + message;
}

/// One decoded outbound envelope: {type, payload} (index.html:88-99).
class WebViewReplicaMessage {
  const WebViewReplicaMessage({
    required this.type,
    required this.payload,
    required this.raw,
    required this.sequence,
    required this.isKnownType,
  });

  /// The wire type field, unmodified.
  final String type;

  /// The wire payload field, unmodified; usually a Map but never trusted to be one.
  final Object? payload;

  /// The envelope exactly as it arrived: a JSON string or an already decoded Map.
  final Object? raw;

  /// Delivery order, starting at 0, so a transcript can be compared with a publish log.
  final int sequence;

  /// True when type is one of kOutboundTypes; false is counted by the host, never dropped.
  final bool isKnownType;

  /// The payload as a string-keyed map; an absent or non-map payload is an empty map.
  Map<String, Object?> get payloadMap => stringKeyedMap(payload);

  /// Decodes a JSON string or a Map. A malformed envelope is a WebViewReplicaError, never null.
  static WebViewReplicaMessage decode(Object? raw, {int sequence = 0}) {
    Object? decoded = raw;
    if (raw is String) {
      final text = raw.trim();
      if (text.isEmpty) {
        throw const WebViewReplicaError(kErrorBadEnvelope, "empty outbound message");
      }
      try {
        decoded = jsonDecode(text);
      } on FormatException catch (error) {
        throw WebViewReplicaError(
          kErrorBadEnvelope,
          "outbound message is not JSON: " + error.message,
          cause: error,
        );
      }
    }
    if (decoded is! Map) {
      throw WebViewReplicaError(
        kErrorBadEnvelope,
        "outbound message is " + decoded.runtimeType.toString() + ", not a {type, payload} object",
        cause: raw,
      );
    }
    final map = stringKeyedMap(decoded);
    final type = map["type"];
    if (type is! String || type.isEmpty) {
      throw WebViewReplicaError(kErrorBadEnvelope, "outbound message has no string type", cause: raw);
    }
    return WebViewReplicaMessage(
      type: type,
      payload: map["payload"],
      raw: raw,
      sequence: sequence,
      isKnownType: kOutboundTypes.contains(type),
    );
  }
}

/// The observable result of one rail call. value is the decoded page return value; a page that
/// answers a Promise (loadAssets at index.html:311-336, the async attachImage path at :356-368)
/// cannot be observed through evaluateJavascript and is reported with observed == false.
class WebViewReplicaResult {
  const WebViewReplicaResult({required this.entry, required this.raw, required this.value});

  final String entry;

  /// The raw string the transport returned, or null when it returned nothing.
  final String? raw;

  /// jsonDecode(raw) when it parses, the raw string otherwise, null when observed is false.
  final Object? value;

  bool get observed => raw != null;

  Map<String, Object?> get map => stringKeyedMap(value);

  Object? operator [](String key) => map[key];

  /// The page's own ok flag (index.html:158, :265, :348, :354). Absent means accepted.
  bool get ok => map["ok"] != false;

  /// The page's rejection reason, verbatim (index.html:130, :234-235, :240, :244, :249, :256, :346).
  String? get reason {
    final value = map["reason"];
    return value is String ? value : null;
  }
}

/// The answer of window.__rhineRail.conformance() (index.html:294-296), checked against the ids
/// the host expects. A missing id is a failure, never a skip.
class ConformanceReport {
  const ConformanceReport({
    required this.checks,
    required this.missing,
    required this.failed,
    required this.unexpected,
  });

  final List<Map<String, Object?>> checks;
  final List<String> missing;
  final List<String> failed;
  final List<String> unexpected;

  List<String> get answered =>
      checks.map((check) => check["id"]).whereType<String>().toList(growable: false);

  bool get ok => missing.isEmpty && failed.isEmpty;

  @override
  String toString() =>
      "ConformanceReport(answered: " +
      checks.length.toString() +
      ", missing: " +
      missing.toString() +
      ", failed: " +
      failed.toString() +
      ", unexpected: " +
      unexpected.toString() +
      ")";
}

/// Reads any Map as a string-keyed map; a non-map becomes an empty map.
Map<String, Object?> stringKeyedMap(Object? value) {
  if (value is! Map) {
    return const <String, Object?>{};
  }
  return <String, Object?>{
    for (final entry in value.entries) entry.key.toString(): entry.value,
  };
}

// ---------------------------------------------------------------------------------------------
// Transport: the only platform seam. The host never talks to a WebView directly.
// ---------------------------------------------------------------------------------------------

/// "host -> page evaluateJavascript" and "page -> host postMessage", with no platform types.
abstract class WebViewReplicaTransport {
  /// Runs a script in the page and returns its JSON result, or null when there is none.
  Future<String?> evaluate(String script);

  /// Raw outbound messages: a JSON string (index.html:94 stringifies) or an already decoded Map.
  Stream<Object?> get incoming;

  /// Releases the bridge. Called by WebViewReplicaHost.dispose.
  Future<void> close();
}

// ---------------------------------------------------------------------------------------------
// Pure contract helpers: no state, no I/O, so a test can prove each rule directly.
// ---------------------------------------------------------------------------------------------

class WebViewReplicaContract {
  const WebViewReplicaContract._();

  /// stageScale = height / 1080 (Qt/src/Engine.cpp:847).
  static double stageScale(double height) => height / kStageHeight;

  /// stageWidth = width / (height / 1080) (Qt/src/Engine.cpp:1353); the 1920 fallback is that
  /// same line's ": 1920" arm, used only when the height is not positive.
  static double stageWidth(double width, double height) =>
      height > 0 ? width / (height / kStageHeight) : 1920.0;

  /// commands is an array of arrays whose a[0] is the operation name (plan 4.2 at
  /// docs/.../parity-plan.md:185, dispatch at Qt/src/Glyphs.cpp:637-825). Legal equal commands
  /// are never merged: the same plan line forbids deduplication.
  static void validateCommands(List<Object?> commands) {
    for (var index = 0; index < commands.length; index += 1) {
      final command = commands[index];
      if (command is! List) {
        throw WebViewReplicaError(
          kErrorCommandContract,
          "command " + index.toString() + " is " + command.runtimeType.toString() +
              ", not the published array form",
        );
      }
      if (command.isEmpty || command.first is! String || (command.first as String).isEmpty) {
        throw WebViewReplicaError(
          kErrorCommandContract,
          "command " + index.toString() + " has no string a[0] operation name (Glyphs.cpp:637-825)",
        );
      }
    }
  }

  /// Hits keep exactly the six published keys (Qt/src/NativeHud.cpp:102-109) and may only add
  /// fixed, which belongs to the PlayerBar owner alone (Qt/src/PlayerBar.cpp:46-53).
  static List<Map<String, Object?>> validateHits(List<Object?> hits) {
    final checked = <Map<String, Object?>>[];
    for (var index = 0; index < hits.length; index += 1) {
      final raw = hits[index];
      if (raw is! Map) {
        throw WebViewReplicaError(
          kErrorHitContract,
          "hit " + index.toString() + " is " + raw.runtimeType.toString() + ", not an object",
        );
      }
      final hit = stringKeyedMap(raw);
      final missing = kHitKeys.difference(hit.keys.toSet());
      if (missing.isNotEmpty) {
        throw WebViewReplicaError(
          kErrorHitContract,
          "hit " + index.toString() + " is missing " + missing.join(", ") + " (NativeHud.cpp:102-109)",
        );
      }
      final invented = hit.keys.toSet().difference(kHitKeys).difference(kOptionalHitKeys);
      if (invented.isNotEmpty) {
        throw WebViewReplicaError(
          kErrorHitContract,
          "hit " + index.toString() + " invents " + invented.join(", ") +
              "; only PlayerBar adds fixed (PlayerBar.cpp:46-53)",
        );
      }
      final fixed = hit["fixed"];
      if (fixed != null && fixed is! bool) {
        throw WebViewReplicaError(
          kErrorHitContract,
          "hit " + index.toString() + " has a non-boolean fixed flag",
        );
      }
      checked.add(hit);
    }
    return checked;
  }

  /// The keys of expected that map does not have. The page's own answers are held to the
  /// constants above with this, so a renamed or removed page field fails a test instead of
  /// silently reading as null.
  static List<String> missingKeys(Map<String, Object?> map, List<String> expected) =>
      expected.where((key) => !map.containsKey(key)).toList(growable: false);

  /// Checks the page answer of conformance() against expected. Accepts the plain array
  /// (index.html:295) and a {checks: [...]} wrapper, so a page refactor needs no host edit.
  static ConformanceReport evaluateConformance(
    Object? pageResult, {
    List<String> expected = kConformanceIds,
  }) {
    Object? list = pageResult;
    if (list is Map) {
      list = stringKeyedMap(list)["checks"];
    }
    if (list is! List) {
      throw WebViewReplicaError(
        kErrorBadEnvelope,
        "conformance() answered " + pageResult.runtimeType.toString() + ", not a check array",
      );
    }
    final checks = <Map<String, Object?>>[];
    for (var index = 0; index < list.length; index += 1) {
      final raw = list[index];
      if (raw is! Map) {
        throw WebViewReplicaError(
          kErrorBadEnvelope,
          "conformance check " + index.toString() + " is not an object",
        );
      }
      final check = stringKeyedMap(raw);
      final id = check["id"];
      if (id is! String || id.isEmpty) {
        throw WebViewReplicaError(
          kErrorBadEnvelope,
          "conformance check " + index.toString() + " has no id",
        );
      }
      checks.add(check);
    }
    final answered = <String>{};
    final failed = <String>[];
    for (final check in checks) {
      final id = check["id"] as String;
      answered.add(id);
      if (check["ok"] != true) {
        failed.add(id);
      }
    }
    final expectedSet = expected.toSet();
    return ConformanceReport(
      checks: checks,
      missing: expectedSet.difference(answered).toList(growable: false),
      failed: failed,
      unexpected: answered.difference(expectedSet).toList(growable: false),
    );
  }

  /// A single quoted JS string literal. Escapes every character that could end the literal or be
  /// reinterpreted: backslash, single quote, the line terminators, U+2028/U+2029 and every control
  /// character. Surrogate pairs pass through, so astral text survives unchanged.
  static String jsStringLiteral(String value) {
    final buffer = StringBuffer("'");
    for (final unit in value.codeUnits) {
      switch (unit) {
        case 0x27: // single quote
          buffer.write(r"\'");
          break;
        case 0x5c: // backslash
          buffer.write(r"\\");
          break;
        case 0x0a:
          buffer.write(r"\n");
          break;
        case 0x0d:
          buffer.write(r"\r");
          break;
        case 0x09:
          buffer.write(r"\t");
          break;
        case 0x2028:
          buffer.write(r"\u2028");
          break;
        case 0x2029:
          buffer.write(r"\u2029");
          break;
        case 0x3c: // "<" keeps a literal from closing an inline script block
          buffer.write(r"\x3c");
          break;
        default:
          if (unit < 0x20) {
            buffer.write(r"\u" + unit.toRadixString(16).padLeft(4, "0"));
          } else {
            buffer.writeCharCode(unit);
          }
      }
    }
    buffer.write("'");
    return buffer.toString();
  }

  /// A JS expression for value. Maps and lists go through JSON.parse of a JSON string, so the page
  /// receives a real object instead of a string (index.html:338-349 stores the value as-is).
  /// JSON is a subset of JS expression syntax, so no hand written serializer is needed.
  static String jsValue(Object? value) {
    if (value == null) {
      return "null";
    }
    if (value is bool) {
      return value ? "true" : "false";
    }
    if (value is int) {
      return value.toString();
    }
    if (value is double) {
      if (!value.isFinite) {
        throw WebViewReplicaError(
          kErrorNonFiniteNumber,
          value.toString() + " has no JS number literal",
        );
      }
      return value.toString();
    }
    if (value is String) {
      return jsStringLiteral(value);
    }
    String json;
    try {
      json = jsonEncode(value);
    } on JsonUnsupportedObjectError catch (error) {
      throw WebViewReplicaError(
        kErrorUnencodable,
        value.runtimeType.toString() + " cannot be sent to the page",
        cause: error,
      );
    }
    return "JSON.parse(" + jsStringLiteral(json) + ")";
  }
}

// ---------------------------------------------------------------------------------------------
// The host.
// ---------------------------------------------------------------------------------------------

/// Owns one replica page: readiness, stage size, the publish triple, the outbound transcript and
/// the error stream. It can only ever call the eight rail entries of kRailEntries.
class WebViewReplicaHost {
  WebViewReplicaHost({
    required this.transport,
    this.expectedConformanceIds = kConformanceIds,
  }) {
    _subscription = transport.incoming.listen(
      _onIncoming,
      onError: (Object error, StackTrace stack) {
        _errors.add(WebViewReplicaError(
          kErrorTransport,
          "outbound stream failed: " + error.toString(),
          cause: error,
        ));
      },
    );
  }

  /// The injected platform seam (evaluateJavascript plus the postMessage stream).
  final WebViewReplicaTransport transport;

  /// Ids conformance() must answer. Defaults to kConformanceIds; a caller may pass the ids it
  /// read back from the page, so the host never disagrees with the shipped page.
  final List<String> expectedConformanceIds;

  /// The eight names this host may call, in page order (index.html:392-399).
  static List<String> get railEntries => kRailEntries;

  final StreamController<WebViewReplicaMessage> _messages =
      StreamController<WebViewReplicaMessage>.broadcast();
  final StreamController<WebViewReplicaError> _errors =
      StreamController<WebViewReplicaError>.broadcast();
  final List<String> _railCalls = <String>[];
  final List<String> _unknownTypes = <String>[];

  StreamSubscription<Object?>? _subscription;

  bool _ready = false;
  bool _resized = false;
  bool _disposed = false;
  int _received = 0;
  int _unknownTypeCount = 0;
  int _evalCount = 0;
  int _publishedCount = 0;
  int _rejectedCount = 0;
  int? _lastGeneration;
  String? _railVersion;
  Map<String, Object?>? _hello;
  Map<String, Object?>? _lastState;
  Map<String, Object?>? _firstFrame;
  ConformanceReport? _lastConformance;
  double? _stageScale;
  double? _stageWidth;
  double? _logicalWidth;
  double? _logicalHeight;

  /// Every decoded outbound envelope, in delivery order, including unknown types.
  Stream<WebViewReplicaMessage> get messages => _messages.stream;

  /// Page errors, transport failures, malformed envelopes and contract divergences.
  Stream<WebViewReplicaError> get errors => _errors.stream;

  /// Ordered log of the rail entries this host actually invoked.
  List<String> get railCalls => List<String>.unmodifiable(_railCalls);

  /// Types outside kOutboundTypes, in arrival order. Counted and exposed, never silently dropped.
  List<String> get unknownTypes => List<String>.unmodifiable(_unknownTypes);

  int get unknownTypeCount => _unknownTypeCount;
  int get receivedCount => _received;
  int get evalCount => _evalCount;
  int get publishedCount => _publishedCount;
  int get rejectedCount => _rejectedCount;

  /// False until the page posts ready (index.html:403).
  bool get isReady => _ready;

  /// False until resize() succeeds. A publish before that paints at stage scale 0
  /// (index.html:75 sets scale 0, and :118-119 multiplies by it and applies it).
  bool get isResized => _resized;

  int? get lastGeneration => _lastGeneration;
  String? get railVersion => _railVersion;
  Map<String, Object?>? get helloPayload => _hello;
  Map<String, Object?>? get lastState => _lastState;
  Map<String, Object?>? get firstFrame => _firstFrame;
  ConformanceReport? get lastConformance => _lastConformance;
  double? get stageScale => _stageScale;
  double? get stageWidth => _stageWidth;
  double? get logicalWidth => _logicalWidth;
  double? get logicalHeight => _logicalHeight;

  /// True when the page reported the version this host was written against.
  bool get railVersionMatches => _railVersion == null || _railVersion == kRailVersion;

  // ---- inbound ------------------------------------------------------------------------------

  void _onIncoming(Object? raw) {
    if (_disposed) {
      return;
    }
    WebViewReplicaMessage message;
    try {
      message = WebViewReplicaMessage.decode(raw, sequence: _received);
    } on WebViewReplicaError catch (error) {
      _errors.add(error);
      return;
    }
    _received += 1;
    _messages.add(message);
    if (!message.isKnownType) {
      // Unknown types are counted and kept on the public list; the host never guesses a meaning.
      _unknownTypeCount += 1;
      _unknownTypes.add(message.type);
      return;
    }
    final payload = message.payloadMap;
    switch (message.type) {
      case "ready":
        _ready = true;
        _hello = payload;
        final version = payload["version"];
        if (version is String) {
          _railVersion = version;
          if (version != kRailVersion) {
            _errors.add(WebViewReplicaError(
              kErrorRailVersion,
              "page rail is " + version + ", host was written against " + kRailVersion,
              cause: raw,
            ));
          }
        }
        final stageHeight = payload["stageHeight"];
        if (stageHeight is num && stageHeight != kStageHeight) {
          _errors.add(WebViewReplicaError(
            kErrorStageMismatch,
            "page reports a " + stageHeight.toString() + " tall stage, Qt fixes it at " +
                kStageHeight.toString() + " (Engine.cpp:847)",
          ));
        }
        break;
      case "firstFrame":
        _firstFrame = payload;
        break;
      case "state":
        _lastState = payload;
        _absorbStage(payload);
        break;
      case "publish":
        final generation = payload["generation"];
        if (generation is num) {
          _lastGeneration = generation.toInt();
        }
        break;
      case "error":
        _errors.add(WebViewReplicaError(
          kErrorPageError,
          "[" + (payload["where"] ?? "unknown").toString() + "] " +
              (payload["detail"] ?? "no detail").toString(),
          cause: raw,
        ));
        break;
      case "console":
        break;
      default:
        break;
    }
  }

  void _absorbStage(Map<String, Object?> payload) {
    final stage = stringKeyedMap(payload["stage"]);
    final scale = stage["scale"];
    final width = stage["width"];
    final height = stage["height"];
    if (scale is num) {
      _stageScale = scale.toDouble();
    }
    if (width is num) {
      _stageWidth = width.toDouble();
    }
    if (height is num && height > 0) {
      _stageScale ??= WebViewReplicaContract.stageScale(height.toDouble());
    }
    final logical = stringKeyedMap(payload["logical"]);
    final logicalWidth = logical["width"];
    final logicalHeight = logical["height"];
    if (logicalWidth is num) {
      _logicalWidth = logicalWidth.toDouble();
    }
    if (logicalHeight is num) {
      _logicalHeight = logicalHeight.toDouble();
    }
  }

  // ---- outbound -----------------------------------------------------------------------------

  /// The single chokepoint: every call to the page passes here, and only kRailEntries pass.
  /// An entry outside the list is a refusal, which is what makes "the only entry points" a fact
  /// the host enforces instead of a comment (M12-F8).
  Future<WebViewReplicaResult> invoke(String entry, [List<Object?> args = const <Object?>[]]) async {
    _ensureOpen();
    if (!kRailEntries.contains(entry)) {
      throw WebViewReplicaError(
        kErrorUnknownRailEntry,
        '"' + entry + '" is not one of the ' + kRailEntries.length.toString() +
            " rail entries the page exposes (index.html:392-399)",
        entry: entry,
      );
    }
    final script = _script(entry, args);
    _railCalls.add(entry);
    _evalCount += 1;
    String? raw;
    try {
      raw = await transport.evaluate(script);
    } catch (error) {
      final wrapped = WebViewReplicaError(
        kErrorTransport,
        "evaluateJavascript failed: " + error.toString(),
        entry: entry,
        cause: error,
      );
      _errors.add(wrapped);
      throw wrapped;
    }
    final result = WebViewReplicaResult(entry: entry, raw: raw, value: _decodeResult(raw));
    if (!result.ok) {
      _rejectedCount += 1;
      throw WebViewReplicaError(
        result.reason ?? "rejected",
        "the page rejected " + entry + ": " + (result.raw ?? "no answer"),
        entry: entry,
      );
    }
    return result;
  }

  String _script(String entry, List<Object?> args) {
    final encoded = args.map(WebViewReplicaContract.jsValue).join(", ");
    return "window.__rhineRail." + entry + "(" + encoded + ")";
  }

  Object? _decodeResult(String? raw) {
    if (raw == null) {
      return null;
    }
    final text = raw.trim();
    if (text.isEmpty || text == "null" || text == "undefined") {
      return null;
    }
    try {
      return jsonDecode(text);
    } on FormatException {
      // evaluateJavascript may return a bare (quoted or unquoted) string on some bridges.
      return text;
    }
  }

  /// resize(logicalWidth, logicalHeight) - index.html:126-159. Must succeed before the first
  /// publish: the page stage scale starts at 0 (index.html:75, :118-119) and only resize() sets it.
  /// Qt/src/Engine.cpp:841-849 is the same rule: the surface size is set, then frames are drawn.
  Future<WebViewReplicaResult> resize(double width, double height) async {
    _ensureOpen();
    final result = await invoke("resize", <Object?>[width, height]);
    _logicalWidth = width;
    _logicalHeight = height;
    _resized = true;
    final stage = stringKeyedMap(result["stage"]);
    final scale = stage["scale"];
    final reportedWidth = stage["width"];
    _stageScale = scale is num ? scale.toDouble() : WebViewReplicaContract.stageScale(height);
    _stageWidth = reportedWidth is num
        ? reportedWidth.toDouble()
        : WebViewReplicaContract.stageWidth(width, height);
    return result;
  }

  /// publish({generation, commands, hits, frame}) - index.html:227-266. The four values travel as
  /// one generation (Qt/src/NativeHud.h:74-76, Engine.cpp:1348/1412); a partial one is refused by
  /// the page (index.html:242-245) and by this host before the call is made.
  Future<WebViewReplicaResult> publish({
    required int generation,
    required List<Object?> commands,
    required List<Map<String, Object?>> hits,
    required Map<String, Object?> frame,
  }) async {
    _ensureOpen();
    if (!_ready) {
      throw const WebViewReplicaError(
        kErrorNotReady,
        "the page has not posted ready yet: window.__rhineRail does not exist before index.html:390",
        entry: "publish",
      );
    }
    if (!_resized) {
      throw const WebViewReplicaError(
        kErrorResizeRequired,
        "no resize() has succeeded: publishing now would paint at stage scale 0 (index.html:75, :118-119)",
        entry: "publish",
      );
    }
    WebViewReplicaContract.validateCommands(commands);
    final checkedHits = WebViewReplicaContract.validateHits(hits.cast<Object?>());
    final payload = <String, Object?>{
      "generation": generation,
      "commands": commands,
      "hits": checkedHits,
      "frame": frame,
    };
    late final String serialized;
    try {
      serialized = jsonEncode(payload);
    } on JsonUnsupportedObjectError catch (error) {
      throw WebViewReplicaError(
        kErrorUnencodable,
        "the generation triple is not encodable",
        entry: "publish",
        cause: error,
      );
    }
    final result = await invoke("publish", <Object?>[serialized]);
    _lastGeneration = generation;
    _publishedCount += 1;
    return result;
  }

  /// state() - index.html:268-292. Returns the page's own snapshot of what it received.
  Future<WebViewReplicaResult> state() async {
    final result = await invoke("state");
    _lastState = result.map;
    _absorbStage(result.map);
    return result;
  }

  /// conformance() - index.html:294-296. The page runs the twelve in-page checks and returns one
  /// entry per id; a missing id lands in ConformanceReport.missing and is a failure, never a skip.
  Future<ConformanceReport> conformance() async {
    final result = await invoke("conformance");
    final report = WebViewReplicaContract.evaluateConformance(
      result.value,
      expected: expectedConformanceIds,
    );
    _lastConformance = report;
    return report;
  }

  /// hello() - index.html:379-388. Useful before ready: it is a plain synchronous function.
  Future<WebViewReplicaResult> hello() async {
    final result = await invoke("hello");
    final map = result.map;
    final version = map["version"];
    if (version is String) {
      _railVersion = version;
    }
    final stageHeight = map["stageHeight"];
    if (stageHeight is num && stageHeight != kStageHeight) {
      _errors.add(WebViewReplicaError(
        kErrorStageMismatch,
        "hello() reports a " + stageHeight.toString() + " tall stage, Qt fixes it at " +
            kStageHeight.toString() + " (Engine.cpp:847)",
      ));
    }
    return result;
  }

  /// loadAssets(base, letteringBase) - index.html:311-336. The page returns a Promise, which
  /// evaluateJavascript cannot await, so the result is expected to be unobserved; the injected
  /// path is attachAsset (index.html:338). A host that needs the asset state reads state() and
  /// checks its assetErrors list (index.html:288).
  Future<WebViewReplicaResult> loadAssets({String? base, String? letteringBase}) {
    final args = <Object?>[base, if (letteringBase != null) letteringBase];
    return invoke("loadAssets", args);
  }

  /// attachAsset(kind, key, value) - index.html:338-349. kind must be one of kAssetKinds.
  Future<WebViewReplicaResult> attachAsset(String kind, String key, Object? value) {
    _ensureOpen();
    if (!kAssetKinds.contains(kind)) {
      throw WebViewReplicaError(
        kErrorUnknownKind,
        '"' + kind + '" is not one of ' + kAssetKinds.join(", ") + " (index.html:338-349)",
        entry: "attachAsset",
      );
    }
    return invoke("attachAsset", <Object?>[kind, key, value]);
  }

  /// attachImage(key, dataUrl) - index.html:351-368. Only same-origin relative, data: or blob:
  /// sources are admissible: the page CSP is img-src 'self' data: blob: (index.html:18).
  Future<WebViewReplicaResult> attachImage(String key, String source) {
    _ensureOpen();
    final lower = source.toLowerCase();
    if (lower.startsWith("http://") || lower.startsWith("https://")) {
      throw WebViewReplicaError(
        kErrorRemoteImage,
        "the slice never loads a remote image (CSP img-src 'self' data: blob:, index.html:18)",
        entry: "attachImage",
      );
    }
    return invoke("attachImage", <Object?>[key, source]);
  }

  /// Releases the subscription and both streams. Safe to call twice.
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    await _subscription?.cancel();
    _subscription = null;
    await _messages.close();
    await _errors.close();
    await transport.close();
  }

  void _ensureOpen() {
    if (_disposed) {
      throw const WebViewReplicaError(kErrorDisposed, "the host was disposed");
    }
  }
}
