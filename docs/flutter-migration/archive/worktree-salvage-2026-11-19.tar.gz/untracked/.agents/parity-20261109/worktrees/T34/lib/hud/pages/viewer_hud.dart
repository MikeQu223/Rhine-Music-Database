/// Qt 封面查看器（3D 场景页）的纯状态机移植。
///
/// 真值来源（逐字移植，行号对应 /home/aibeto/code/Rhine-Music-Database/Qt/src）：
/// - NativeViewer.cpp:1-355    open/action/key/pointer/update/reset/coverFront/frame 全部语义
/// - NativeViewer.h:1-69       字段与默认值（eye={7.2,3.8,12}、width=1920/height=1080 等）
/// - SceneMath.cpp:1-220       Vector / Matrix::compose / perspective / camera / inverse / json
/// - SceneMotion.cpp          Spring::damp 的阻尼积分
/// - Overlay.qml:290-352      触控转发：pointer("pan", dx, dy) 与 wheelInput 的正 delta 缩小半径
///
/// 契约：
/// 1. 纯 Dart：只 import 'dart:convert' 与 'dart:math'，不依赖 Flutter、不 import 本仓其它文件。
/// 2. Qt 的 NativeViewer 不产出任何 2D HUD 命令（全文件无 Canvas::fill/text/hit 调用），
///    只向 scene draw 通道写 frame 字段。因此本文件同样只产出 frame 字段与 20 槽卡片状态，
///    绝不虚构按钮、命中或文本——竖屏也不新增 Qt 没有的自绘控件。
/// 3. 状态机与 Qt 逐分支对齐：opening 0.38s / closing 0.22s / reset 0.56s 三次缓出、
///    clarity 阻尼率 8、spread 阻尼率 5.5、reduced 时全部瞬时。
/// 4. 输入一律不修改调用方对象：frame() 复制 base 后写入。
/// 5. 半径夹 5..28、注视点夹 |target|<=5、phi 夹 (1e-6, pi-1e-6) 与 Qt 同界。
/// 6. NativeCards::expand 只吃 20 个 double 的 state 数组（NativeViewer.cpp:310-320），
///    由 cardState() 交给宿主的 cards port；本文件不实现卡片绘制。

import 'dart:convert';
import 'dart:math' as math;

/// 装配部件与沿 z 的展开深度（NativeViewer.cpp:11-14，顺序即绘制顺序）。
class ViewerPartDepth {
  const ViewerPartDepth(this.name, this.depth);
  final String name;
  final double depth;
}

const List<ViewerPartDepth> viewerPartDepths = <ViewerPartDepth>[
  ViewerPartDepth('fasteners', 2.75),
  ViewerPartDepth('cover', 1.85),
  ViewerPartDepth('optical-lenses', 0.75),
  ViewerPartDepth('optical-core', -0.15),
  ViewerPartDepth('substrate', -1.1),
  ViewerPartDepth('carrier', -2.05),
];

/// Qt 的默认相机位置（NativeViewer.h:64）。
const ViewerVector viewerDefaultEye = ViewerVector(7.2, 3.8, 12);

/// 打开/关闭/复位的时长与阻尼率（NativeViewer.cpp:59/120/150-160）。
const double viewerOpenSeconds = 0.38;
const double viewerCloseSeconds = 0.22;
const double viewerResetSeconds = 0.56;
const double viewerClarityRate = 8;
const double viewerSpreadRate = 5.5;

/// 投影与雾（NativeViewer.cpp:262-274）。
const double viewerNear = 0.3;
const double viewerFar = 120;
const double viewerFovDegrees = 34;

/// 交互边界（NativeViewer.cpp:139-232）。
const double viewerMinRadius = 5;
const double viewerMaxRadius = 28;
const double viewerTargetLimit = 5;

/// 卡片锚点 actor id 与装配根位置（NativeViewer.cpp:302-320）。
const int viewerCardActorId = 100000;
const ViewerVector viewerCardRoot = ViewerVector(0, -1.85, 0);
const ViewerVector viewerCoverLabelPosition = ViewerVector(-1.36, 3.04, 0.255);

/// Qt SceneMath::Vector（SceneMath.cpp:6-41）。
class ViewerVector {
  const ViewerVector(this.x, this.y, this.z);

  final double x;
  final double y;
  final double z;

  static const ViewerVector zero = ViewerVector(0, 0, 0);

  ViewerVector operator +(ViewerVector other) => ViewerVector(x + other.x, y + other.y, z + other.z);
  ViewerVector operator -(ViewerVector other) => ViewerVector(x - other.x, y - other.y, z - other.z);
  ViewerVector operator *(double scale) => ViewerVector(x * scale, y * scale, z * scale);

  double dot(ViewerVector other) => x * other.x + y * other.y + z * other.z;

  ViewerVector cross(ViewerVector other) => ViewerVector(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x,
      );

  double get length => math.sqrt(x * x + y * y + z * z);

  ViewerVector get normalized {
    final double size = length;
    return this * (size == 0 ? 1 : 1 / size);
  }

  ViewerVector lerp(ViewerVector other, double amount) => ViewerVector(
        x + (other.x - x) * amount,
        y + (other.y - y) * amount,
        z + (other.z - z) * amount,
      );

  List<double> toList() => <double>[x, y, z];

  @override
  String toString() => 'ViewerVector(' + x.toString() + ', ' + y.toString() + ', ' + z.toString() + ')';
}

/// Qt NativeViewer::Spherical（NativeViewer.cpp:27-38）。
class ViewerSpherical {
  const ViewerSpherical(this.radius, this.phi, this.theta);

  final double radius;
  final double phi;
  final double theta;

  static const ViewerSpherical zero = ViewerSpherical(0, 0, 0);

  /// spherical(Vector)：r==0 时全零，否则 acos(clamp(y/r)) + atan2(x,z)。
  static ViewerSpherical fromVector(ViewerVector value) {
    final double radius = value.length;
    if (radius == 0) {
      return zero;
    }
    return ViewerSpherical(
      radius,
      math.acos((value.y / radius).clamp(-1.0, 1.0).toDouble()),
      math.atan2(value.x, value.z),
    );
  }

  /// vector(Spherical)：{sin(phi)*r*sin(theta), cos(phi)*r, sin(phi)*r*cos(theta)}。
  ViewerVector toVector() {
    final double sine = math.sin(phi) * radius;
    return ViewerVector(sine * math.sin(theta), math.cos(phi) * radius, sine * math.cos(theta));
  }

  @override
  String toString() =>
      'ViewerSpherical(rad=' + radius.toString() + ', phi=' + phi.toString() + ', theta=' + theta.toString() + ')';
}

/// Qt SceneMotion::Spring（SceneMotion.cpp 的 damp）。
class ViewerSpring {
  ViewerSpring([this.value = 0, this.velocity = 0]);

  double value;
  double velocity;

  void damp(double target, double rate, double seconds) {
    final double delta = value - target;
    final double impulse = velocity + rate * delta;
    final double decay = math.exp(-rate * seconds);
    value = target + (delta + impulse * seconds) * decay;
    velocity = (velocity - rate * impulse * seconds) * decay;
  }
}

/// Qt SceneMath::Matrix（列主序 16 值，SceneMath.cpp:43-206）。
class ViewerMatrix {
  ViewerMatrix(this.values);

  factory ViewerMatrix.identity() => ViewerMatrix(<double>[
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1,
      ]);

  final List<double> values;

  /// compose(position, rotation, scale = {1,1,1})：四元数半角展开后按列写。
  static ViewerMatrix compose(ViewerVector position, ViewerVector rotation,
      [ViewerVector scale = const ViewerVector(1, 1, 1)]) {
    final double c1 = math.cos(rotation.x / 2);
    final double c2 = math.cos(rotation.y / 2);
    final double c3 = math.cos(rotation.z / 2);
    final double s1 = math.sin(rotation.x / 2);
    final double s2 = math.sin(rotation.y / 2);
    final double s3 = math.sin(rotation.z / 2);
    final double x = s1 * c2 * c3 + c1 * s2 * s3;
    final double y = c1 * s2 * c3 - s1 * c2 * s3;
    final double z = c1 * c2 * s3 + s1 * s2 * c3;
    final double w = c1 * c2 * c3 - s1 * s2 * s3;
    final double x2 = x + x;
    final double y2 = y + y;
    final double z2 = z + z;
    final double xx = x * x2;
    final double xy = x * y2;
    final double xz = x * z2;
    final double yy = y * y2;
    final double yz = y * z2;
    final double zz = z * z2;
    final double wx = w * x2;
    final double wy = w * y2;
    final double wz = w * z2;
    return ViewerMatrix(<double>[
      (1 - (yy + zz)) * scale.x,
      (xy + wz) * scale.x,
      (xz - wy) * scale.x,
      0,
      (xy - wz) * scale.y,
      (1 - (xx + zz)) * scale.y,
      (yz + wx) * scale.y,
      0,
      (xz + wy) * scale.z,
      (yz - wx) * scale.z,
      (1 - (xx + yy)) * scale.z,
      0,
      position.x,
      position.y,
      position.z,
      1,
    ]);
  }

  /// perspective(fov, aspect, near, far)：Qt 的 top/height/left/right 推导。
  static ViewerMatrix perspective(double fov, double aspect, double near, double far) {
    final double top = near * math.tan(math.pi / 180 * 0.5 * fov);
    final double height = 2 * top;
    final double width = aspect * height;
    final double left = -0.5 * width;
    final double right = left + width;
    final double bottom = top - height;
    final double x = 2 * near / (right - left);
    final double y = 2 * near / (top - bottom);
    final double a = (right + left) / (right - left);
    final double b = (top + bottom) / (top - bottom);
    final double c = -(far + near) / (far - near);
    final double d = -2 * far * near / (far - near);
    return ViewerMatrix(<double>[x, 0, 0, 0, 0, y, 0, 0, a, b, c, -1, 0, 0, d, 0]);
  }

  /// camera(position, target)：右手系 look-at，列主序。
  static ViewerMatrix camera(ViewerVector position, ViewerVector target) {
    ViewerVector z = position - target;
    if (z.length == 0) {
      z = ViewerVector(z.x, z.y, 1);
    }
    z = z.normalized;
    const ViewerVector up = ViewerVector(0, 1, 0);
    ViewerVector x = up.cross(z);
    if (x.length == 0) {
      z = ViewerVector(z.x, z.y, z.z + 0.0001).normalized;
      x = up.cross(z);
    }
    x = x.normalized;
    final ViewerVector y = z.cross(x);
    return ViewerMatrix(<double>[
      x.x, x.y, x.z, 0,
      y.x, y.y, y.z, 0,
      z.x, z.y, z.z, 0,
      position.x, position.y, position.z, 1,
    ]);
  }

  ViewerMatrix multiply(ViewerMatrix other) {
    final List<double> result = List<double>.filled(16, 0);
    for (int column = 0; column < 4; column++) {
      for (int row = 0; row < 4; row++) {
        double value = 0;
        for (int k = 0; k < 4; k++) {
          value += values[k * 4 + row] * other.values[column * 4 + k];
        }
        result[column * 4 + row] = value;
      }
    }
    return ViewerMatrix(result);
  }

  /// Gauss-Jordan + 部分主元；奇异输入返回零矩阵（SceneMath.cpp:113-166）。
  ViewerMatrix inverse() {
    final List<List<double>> rows = List<List<double>>.generate(4, (int row) {
      final List<double> line = List<double>.filled(8, 0);
      for (int column = 0; column < 4; column++) {
        line[column] = values[column * 4 + row];
      }
      line[row + 4] = 1;
      return line;
    });
    for (int column = 0; column < 4; column++) {
      int pivot = column;
      for (int row = column + 1; row < 4; row++) {
        if (rows[row][column].abs() > rows[pivot][column].abs()) {
          pivot = row;
        }
      }
      if (rows[pivot][column] == 0) {
        return ViewerMatrix(List<double>.filled(16, 0));
      }
      if (pivot != column) {
        for (int index = 0; index < 8; index++) {
          final double swap = rows[pivot][index];
          rows[pivot][index] = rows[column][index];
          rows[column][index] = swap;
        }
      }
      final double divisor = rows[column][column];
      for (int index = 0; index < 8; index++) {
        rows[column][index] /= divisor;
      }
      for (int row = 0; row < 4; row++) {
        if (row == column) {
          continue;
        }
        final double factor = rows[row][column];
        for (int index = 0; index < 8; index++) {
          rows[row][index] -= factor * rows[column][index];
        }
      }
    }
    final List<double> result = List<double>.filled(16, 0);
    for (int row = 0; row < 4; row++) {
      for (int column = 0; column < 4; column++) {
        result[column * 4 + row] = rows[row][column + 4];
      }
    }
    return ViewerMatrix(result);
  }

  ViewerVector point(ViewerVector point) {
    final List<double> m = values;
    final double w = 1 / (m[3] * point.x + m[7] * point.y + m[11] * point.z + m[15]);
    return ViewerVector(
      (m[0] * point.x + m[4] * point.y + m[8] * point.z + m[12]) * w,
      (m[1] * point.x + m[5] * point.y + m[9] * point.z + m[13]) * w,
      (m[2] * point.x + m[6] * point.y + m[10] * point.z + m[14]) * w,
    );
  }

  ViewerVector direction(ViewerVector vector) => ViewerVector(
        values[0] * vector.x + values[4] * vector.y + values[8] * vector.z,
        values[1] * vector.x + values[5] * vector.y + values[9] * vector.z,
        values[2] * vector.x + values[6] * vector.y + values[10] * vector.z,
      ).normalized;

  List<double> toList() => List<double>.of(values);

  List<double> get column0 => <double>[values[0], values[1], values[2]];
  List<double> get column1 => <double>[values[4], values[5], values[6]];
}

/// 装配网格：Qt 侧从 archive-assembly.json 的 meshes 读 name + assemblyPart。
class ViewerMesh {
  const ViewerMesh({required this.name, required this.assemblyPart});
  final String name;
  final String assemblyPart;
}

double _lerp(double from, double to, double amount) => (1 - amount) * from + amount * to;

ViewerVector _clampTarget(ViewerVector value) {
  if (value.length > viewerTargetLimit) {
    return value.normalized * viewerTargetLimit;
  }
  return value;
}

/// Qt NativeViewer 的状态机移植：只产出 frame 字段，不产出 2D HUD 命令。
class ViewerHud {
  ViewerHud({
    this.width = 1920,
    this.height = 1080,
    this.theme = 0,
    this.loadMeshes,
  });

  /// 舞台尺寸（Qt resize；默认 1920x1080，NativeViewer.h:54-55）。
  double width;
  double height;

  /// 主题 0/1，只透传给卡片 state[18]（NativeViewer.cpp:316）。
  double theme;

  /// 装配模板来源：Qt 读 root + "/archive-assembly.json" 的 meshes 数组
  /// （NativeViewer.cpp:74-79）。宿主注入同一份数据，缺省即空模板（ready=false）。
  final List<ViewerMesh> Function()? loadMeshes;

  List<ViewerMesh> _meshes = const <ViewerMesh>[];
  bool _open = false;
  bool _closing = false;
  bool _dragging = false;
  bool _resetting = false;
  bool _ready = false;
  bool _reduced = false;
  double _previousX = 0;
  double _previousY = 0;
  double _last = 0;
  double _time = 0;
  double _pendingUntil = 0;
  double _closeAt = 0;
  double _resetElapsed = 0;
  final ViewerSpring _clarity = ViewerSpring(1, 0);
  final ViewerSpring _spread = ViewerSpring();
  double _targetClarity = 1;
  double _targetSpread = 0;
  ViewerVector _eye = viewerDefaultEye;
  ViewerVector _focus = ViewerVector.zero;
  ViewerVector _target = ViewerVector.zero;
  ViewerVector _resetFocus = ViewerVector.zero;
  ViewerSpherical _pose = ViewerSpherical.fromVector(viewerDefaultEye);
  ViewerSpherical _goal = ViewerSpherical.fromVector(viewerDefaultEye);
  ViewerSpherical _resetFrom = ViewerSpherical.zero;
  String _transition = 'closed';
  String _surface = 'clear';

  bool get isOpen => _open;
  bool get closing => _closing;
  bool get ready => _ready;
  bool get reduced => _reduced;
  bool get resetting => _resetting;
  bool get dragging => _dragging;
  String get transition => _transition;
  String get surface => _surface;
  double get stageTime => _time;
  double get pendingUntil => _pendingUntil;
  double get closeAt => _closeAt;
  ViewerSpring get clarity => _clarity;
  ViewerSpring get spread => _spread;
  double get targetClarity => _targetClarity;
  double get targetSpread => _targetSpread;
  ViewerVector get eye => _eye;
  ViewerVector get focus => _focus;
  ViewerVector get target => _target;
  ViewerSpherical get pose => _pose;
  ViewerSpherical get goal => _goal;
  List<ViewerMesh> get meshes => _meshes;

  /// Qt pending()（NativeViewer.cpp:41-43）。
  bool get pending => _open && (_closing || _time < _pendingUntil);

  /// Qt open()（NativeViewer.cpp:52-84）。
  void open(double time) {
    if (_open) {
      return;
    }
    _open = true;
    _closing = false;
    _transition = 'opening';
    _time = time;
    _pendingUntil = _reduced ? time : time + viewerOpenSeconds;
    _spread.value = 0;
    _spread.velocity = 0;
    _targetSpread = 0;
    _clarity.value = 1;
    _clarity.velocity = 0;
    _targetClarity = 1;
    _surface = 'clear';
    _last = 0;
    reset(false);
    if (_meshes.isEmpty) {
      _meshes = loadMeshes?.call() ?? const <ViewerMesh>[];
    }
    _ready = _meshes.isNotEmpty;
    update(0, theme);
    _time = time;
  }

  /// Qt resize()（NativeViewer.cpp:86-89）。
  void resize(double width, double height) {
    this.width = width;
    this.height = height;
  }

  /// Qt reduced()（NativeViewer.cpp:91-99）：开启减弱动效时立刻贴到目标。
  void reduced(bool value) {
    _reduced = value;
    if (value) {
      _pendingUntil = _time;
      _clarity.value = _targetClarity;
      _clarity.velocity = 0;
      _spread.value = _targetSpread;
      _spread.velocity = 0;
    }
  }

  /// Qt reset(bool)（NativeViewer.cpp:101-115）。animated 且未减弱时走 0.56s 缓出插值。
  void reset(bool animated) {
    _target = ViewerVector.zero;
    _goal = ViewerSpherical.fromVector(viewerDefaultEye);
    if (animated && !_reduced) {
      _resetFrom = _pose;
      _resetFocus = _focus;
      _resetElapsed = 0;
      _resetting = true;
    } else {
      _pose = _goal;
      _focus = _target;
      _eye = _pose.toVector() + _focus;
      _resetting = false;
    }
  }

  /// Qt interrupt()（NativeViewer.cpp:117-123）：复位被打断时把当前姿态作为新目标。
  void interrupt() {
    if (_resetting) {
      _resetting = false;
      _goal = _pose;
      _target = _focus;
    }
  }

  /// Qt coverFront(bool)（NativeViewer.cpp:125-134）：正面/背面对齐到 ±|eye|。
  void coverFront(bool front) {
    interrupt();
    final double distance = viewerDefaultEye.length;
    _goal = ViewerSpherical.fromVector(ViewerVector(0, 0, front ? distance : -distance));
    _target = ViewerVector.zero;
    _pose = _goal;
    _focus = ViewerVector.zero;
    _eye = _pose.toVector();
  }

  /// Qt action()（NativeViewer.cpp:136-160）。
  void action(String action, double time) {
    if (!_open || _closing) {
      return;
    }
    if (action == 'close') {
      _closing = true;
      _dragging = false;
      _transition = 'closing';
      _closeAt = _reduced ? time : time + viewerCloseSeconds;
      return;
    }
    if (!_ready) {
      return;
    }
    if (action == 'clear' || action == 'frosted') {
      _targetClarity = action == 'clear' ? 1 : 0;
      _surface = action;
    } else if (action == 'explode' || action == 'assemble') {
      _targetSpread = action == 'explode' ? 1 : 0;
    } else if (action == 'reset') {
      reset(true);
    }
  }

  /// Qt key()（NativeViewer.cpp:162-200）。
  void key(String key, double time) {
    if (key == 'Escape') {
      action('close', time);
      return;
    }
    if (!_ready || _closing) {
      return;
    }
    if (key == 'Home') {
      reset(true);
      return;
    }
    interrupt();
    if (key == '+' || key == '=' || key == '-') {
      final double factor = key == '-' ? 1.12 : 1 / 1.12;
      _goal = ViewerSpherical(
        (_goal.radius * factor).clamp(viewerMinRadius, viewerMaxRadius).toDouble(),
        _goal.phi,
        _goal.theta,
      );
      return;
    }
    final ViewerMatrix camera = ViewerMatrix.camera(_eye, _focus);
    final ViewerVector right = ViewerVector(camera.values[0], camera.values[1], camera.values[2]);
    final ViewerVector up = ViewerVector(camera.values[4], camera.values[5], camera.values[6]);
    final double step = _goal.radius * 0.025;
    ViewerVector delta = ViewerVector.zero;
    if (key == 'ArrowLeft') {
      delta = right * -step;
    } else if (key == 'ArrowRight') {
      delta = right * step;
    } else if (key == 'ArrowUp') {
      delta = up * step;
    } else if (key == 'ArrowDown') {
      delta = up * -step;
    }
    _target = _clampTarget(_target + delta);
  }

  /// Qt pointer()（NativeViewer.cpp:202-247）。x/y 是舞台像素。
  void pointer(String type, double x, double y, [double delta = 0]) {
    if (!_ready || _closing) {
      return;
    }
    if (type == 'pointerdown') {
      interrupt();
      _dragging = true;
      _previousX = x;
      _previousY = y;
    } else if (type == 'pointermove' && _dragging) {
      _goal = ViewerSpherical(
        _goal.radius,
        (_goal.phi - 2 * math.pi * (y - _previousY) * 0.65 / height)
            .clamp(0.000001, math.pi - 0.000001)
            .toDouble(),
        _goal.theta - 2 * math.pi * (x - _previousX) * 0.65 / height,
      );
      _previousX = x;
      _previousY = y;
    } else if (type == 'pointerup' || type == 'pointercancel') {
      _dragging = false;
    } else if (type == 'wheel') {
      interrupt();
      final double scale = math.pow(0.95, 0.7 * delta.abs() * 0.01).toDouble();
      _goal = ViewerSpherical(
        (_goal.radius * (delta < 0 ? scale : 1 / scale))
            .clamp(viewerMinRadius, viewerMaxRadius)
            .toDouble(),
        _goal.phi,
        _goal.theta,
      );
    } else if (type == 'pan') {
      interrupt();
      final ViewerMatrix camera = ViewerMatrix.camera(_eye, _focus);
      final ViewerVector right = ViewerVector(camera.values[0], camera.values[1], camera.values[2]);
      final ViewerVector up = ViewerVector(camera.values[4], camera.values[5], camera.values[6]);
      final double span = 2 * _goal.radius * math.tan(viewerFovDegrees * math.pi / 360);
      final double worldPerPixel = span / height;
      _target = _clampTarget(
        _target + right * (-x * worldPerPixel) + up * (y * worldPerPixel),
      );
    }
  }

  /// Qt update()（NativeViewer.cpp:250-301）。
  void update(double time, double theme) {
    if (!_open) {
      return;
    }
    _time = time;
    this.theme = theme;
    if (_closing && time >= _closeAt) {
      _open = false;
      _closing = false;
      _ready = false;
      _meshes = const <ViewerMesh>[];
      _transition = 'closed';
      return;
    }
    if (!_closing && time >= _pendingUntil) {
      _transition = 'open';
    }
    final double seconds = math.min(_last != 0 ? time - _last : 1 / 60, 0.05);
    _last = time;
    if (_reduced) {
      _clarity.value = _targetClarity;
      _clarity.velocity = 0;
      _spread.value = _targetSpread;
      _spread.velocity = 0;
    } else {
      _clarity.damp(_targetClarity, viewerClarityRate, seconds);
      _spread.damp(_targetSpread, viewerSpreadRate, seconds);
    }
    if ((_clarity.value - _targetClarity).abs() < 0.0001 && _clarity.velocity.abs() < 0.001) {
      _clarity.value = _targetClarity;
      _clarity.velocity = 0;
    }
    if ((_spread.value - _targetSpread).abs() < 0.0001 && _spread.velocity.abs() < 0.001) {
      _spread.value = _targetSpread;
      _spread.velocity = 0;
    }
    if (_reduced) {
      _pose = _goal;
      _focus = _target;
    } else if (_resetting) {
      _resetElapsed += math.max(0, seconds);
      final double t = math.min(1, _resetElapsed / viewerResetSeconds);
      final double amount = 1 - math.pow(1 - t, 3).toDouble();
      _focus = _resetFocus.lerp(_target, amount);
      _interpolate(_resetFrom, _goal, amount, amount);
      if (t == 1) {
        _resetting = false;
      }
    } else {
      final double pan = 1 - math.exp(-13 * math.max(0, seconds));
      _focus = _focus.lerp(_target, pan);
      _interpolate(
        _pose,
        _goal,
        1 - math.exp(-9 * math.max(0, seconds)),
        1 - math.exp(-15 * math.max(0, seconds)),
      );
      final ViewerVector gap = _focus - _target;
      if (gap.dot(gap) < 1e-10) {
        _focus = _target;
      }
    }
    _eye = _pose.toVector() + _focus;
  }

  /// 球面角与对数半径插值（NativeViewer.cpp:209-216）。
  void _interpolate(ViewerSpherical from, ViewerSpherical to, double angle, double radius) {
    final double nextRadius = math.exp(_lerp(math.log(from.radius), math.log(to.radius), radius));
    final double nextPhi =
        _lerp(from.phi, to.phi, angle).clamp(0.000001, math.pi - 0.000001).toDouble();
    final double nextTheta = from.theta +
        math.atan2(math.sin(to.theta - from.theta), math.cos(to.theta - from.theta)) * angle;
    _pose = ViewerSpherical(nextRadius, nextPhi, nextTheta);
  }

  /// Qt trimMemory()（NativeViewer.cpp:303-307）：关闭后释放装配模板。
  void trimMemory() {
    if (!_open) {
      _meshes = const <ViewerMesh>[];
    }
  }

  /// 交给宿主 NativeCards port 的 20 个 double（NativeViewer.cpp:310-320）：
  /// [0..15] 根矩阵 compose({0,-1.85,0})、[16]=1、[17]=clarity、[18]=theme、[19]=0。
  List<double> cardState() {
    final ViewerMatrix root = ViewerMatrix.compose(viewerCardRoot, ViewerVector.zero);
    final List<double> state = List<double>.filled(20, 0);
    for (int index = 0; index < 16; index++) {
      state[index] = root.values[index];
    }
    state[16] = 1;
    state[17] = _clarity.value;
    state[18] = theme;
    state[19] = 0;
    return state;
  }

  /// Qt frame()（NativeViewer.cpp:258-352）：关闭时原样返回 base；打开时写入场景字段。
  Map<String, Object?> frame(
    Map<String, Object?> base, {
    required List<Map<String, Object?>> actorTemplate,
  }) {
    if (!_open) {
      return Map<String, Object?>.of(base);
    }
    final Map<String, Object?> out = Map<String, Object?>.of(base);
    out['viewer'] = true;
    out['viewerReady'] = _ready;
    out['near'] = viewerNear;
    out['far'] = viewerFar;
    out['view'] = ViewerMatrix.camera(_eye, _focus).inverse().toList();
    out['eye'] = _eye.toList();
    final ViewerMatrix projection =
        ViewerMatrix.perspective(viewerFovDegrees, width / height, viewerNear, viewerFar);
    final double aspect = width / height;
    if (aspect < 1.05) {
      final double zoom = math.min(1.15, aspect / 0.85) / (1 + 0.08 * _spread.value);
      projection.values[0] = projection.values[0] * zoom;
      projection.values[5] = projection.values[5] * zoom;
    }
    out['projection'] = projection.toList();
    out['fogNear'] = math.max(0, _eye.length - 1);
    out['fogFar'] = _eye.length + 12;
    out['draws'] = <Object?>[];
    out['actorTemplate'] =
        viewerTemplateParts(actorTemplate: actorTemplate, meshes: _meshes, spread: _spread.value);
    out['actors'] = <Object?>[
      <String, Object?>{'id': viewerCardActorId, 'musicKey': null, 'selected': true, 'shadowOnly': false},
    ];
    out['viewerState'] = <String, Object?>{
      'transition': _transition,
      'surface': _surface,
      'exploded': _targetSpread == 1 ? 'true' : 'false',
      'stats': viewerStatsJson(),
    };
    return out;
  }

  /// viewerState.stats 的键集合（NativeViewer.cpp:321-344）。QJsonObject 按 key 字典序序列化，
  /// 这里同样按字典序插入；数值文本形式由 dart:convert 决定（语义与 Qt 一致）。
  String viewerStatsJson() {
    return jsonEncode(<String, Object?>{
      'azimuth': _goal.theta,
      'cameraPosition': _eye.toList(),
      'clarity': _clarity.value,
      'distance': _pose.radius,
      'polar': _goal.phi,
      'ready': _ready,
      'requestedDistance': _goal.radius,
      'requestedTarget': _target.toList(),
      'resetting': _resetting,
      'spread': _spread.value,
      'target': _targetSpread,
      'targetClarity': _targetClarity,
      'targetPosition': _focus.toList(),
    });
  }
}

/// Qt frame() 里的模板展开（NativeViewer.cpp:276-300）：外层按 parts 深度顺序，
/// 内层 0..meshes.length（==length 即封面纸片 label 行），命中即 append 并 break。
List<Map<String, Object?>> viewerTemplateParts({
  required List<Map<String, Object?>> actorTemplate,
  required List<ViewerMesh> meshes,
  required double spread,
}) {
  final List<Map<String, Object?>> parts = <Map<String, Object?>>[];
  for (final ViewerPartDepth part in viewerPartDepths) {
    for (int mesh = 0; mesh <= meshes.length; mesh++) {
      final bool label = mesh == meshes.length;
      final ViewerMesh? entry = label ? null : meshes[mesh];
      final String assemblyPart = label ? 'cover' : entry!.assemblyPart;
      if (assemblyPart != part.name) {
        continue;
      }
      for (final Map<String, Object?> source in actorTemplate) {
        final bool isLabel = source['label'] == true;
        if (isLabel != label) {
          continue;
        }
        if (!label && source['name'] != entry!.name) {
          continue;
        }
        final Map<String, Object?> result = Map<String, Object?>.of(source);
        result['partIndex'] = parts.length;
        result['mesh'] = label ? -1 : mesh;
        result['asset'] = label ? 'cassette' : 'assembly';
        result['side'] = label ? 2 : (source['side'] is int ? source['side'] as int : 0);
        result['castShadow'] = false;
        final ViewerVector anchor = label ? viewerCoverLabelPosition : ViewerVector.zero;
        result['localMatrix'] = ViewerMatrix.compose(
          ViewerVector(anchor.x, anchor.y, anchor.z + part.depth * spread),
          ViewerVector.zero,
        ).toList();
        parts.add(result);
        break;
      }
    }
  }
  return parts;
}
