// T15 slice test - candidate E: Flutter host + local WebView (canvas/WebGL/Three.js) replica.
//
// Contract sources (Qt is the specification; this file must not invent protocol):
//   Qt/src/NativeHud.h:74-76          commands / hits / frame are the only published HUD values
//   Qt/src/Engine.cpp:1348,1379,1412   one published object carries all three (m_commands, hits)
//   Qt/src/Engine.cpp:841-849          the surface size is set before a frame is drawn
//   Qt/src/Engine.cpp:847              the logical stage is 1080 tall (scale = height / 1080)
//   Qt/src/Engine.cpp:1353             stageWidth = width / (height / 1080), 1920 without a height
//   Qt/src/Glyphs.cpp:637-825          the 17 operations of the flat command array a[0] = op
//   Qt/src/Glyphs.cpp:35-49            calibrated colours are Gamma 1.8 -> sRGB
//   Qt/src/Glyphs.cpp:530-564          text baseline y + size * 1.044, advance * size + tracking
//   Qt/src/Glyphs.cpp:565-588          lettering art has no baseline shift and a positive y scale
//   Qt/src/NativeHud.cpp:102-109       hits carry exactly {x, y, width, height, action, label}
//   Qt/src/PlayerBar.cpp:46-53         only the PlayerBar hit adds fixed: true
//   docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:183-227  contract tables
//
// Page side (web/rhine_replica/index.html, read-only for this atom):
//   :392-399  the eight documented inbound entries (assets accessor at :400 is not one)
//   :402-403  window.__rhineReady and the ready envelope posted from hello()
//   :75,:118-119  the stage scale starts at 0, then applyHudTransform multiplies and applies it
//   :57-59    outbound whitelist ready|firstFrame|publish|state|error|console
//   :88-99    outbound window.__rhineHost.postMessage(JSON.stringify({type, payload}))
//
// Two revisions landed with this atom (T15-C18-A3); both are recorded in
// .agents/parity-20261109/reports/T15-C18-A3-dart-host.json:
//   * M12-F3 (must-fix of reports/T15-S01-M12-R.json): the old "the pending set covers the full
//     inbound rail" case searched the pending requirement text for each of resize/publish/state/
//     conformance. No pending text ever mentioned state() or conformance(), so the case could
//     only fail once executed. Coverage is now an explicit covers field that must union to the
//     whole rail, and the text check only accepts a pending item that really names the entry.
//   * M12-F8: string greps are not a proof of exclusivity, so the host itself refuses every name
//     outside lib/platform/webview_replica.dart's kRailEntries, and the case for it is here.
//
// Two Qt citations carried by earlier revisions were fabricated and are gone: NativeHud.cpp:58-66
// is the fit() binary search and NativeHud.cpp:74-76 is the fit cache insert, not a ready
// handshake and not a
// lifetime signal. Readiness is a page rule (index.html:402-403) and the resize ordering is proved by
// index.html:75, :118-119 together with Engine.cpp:841-849.
//
// Nothing in this tree has been executed. flutter/dart execution is forbidden in this phase, so
// the report records every case below as RED-not-executed rather than a green run.
//
// The host library is imported with a prefix on purpose: it publishes the same contract names this
// file asserts on (kConformanceIds, kHitKeys, kRailEntries), and the prefix keeps the copies here
// an independent statement of the contract instead of an alias of the implementation. The library
// imports only dart:async and dart:convert, so it compiles and runs under flutter_test with no
// platform binding and no new dependency in the shared pubspec.yaml.

import "dart:convert";

import "package:flutter_test/flutter_test.dart";
import "package:rhine_music_database/platform/webview_replica.dart" as replica;

/// Device level checks cannot run in this phase. They are listed, never skipped silently, so the
/// remaining gap is visible in the report instead of hidden behind a green run.
const bool kDeviceAvailable = bool.fromEnvironment("RHINE_SLICE_DEVICE");

/// The operation order of the published stream: the chain opens with save and closes with the
/// matching restore, exactly as Qt/src/Glyphs.cpp:644 and :651 bracket the draw.
const List<String> kOpOrder = <String>[
  "save",
  "alpha",
  "translate",
  "scale",
  "rotate",
  "clip",
  "fill",
  "ellipse",
  "text",
  "art",
  "fill-path",
  "path",
  "arc",
  "right-mask",
  "gradient",
  "image",
  "restore",
];

/// Identifiers of the in-page conformance checks. The page answers window.__rhineRail.conformance()
/// with one entry per id: {id, ok, expected, actual, note}. A missing id is a failure, never a skip.
/// The same twelve ids are asserted by test/spike/webview/renderer_contract_test.dart:55-68 against
/// renderer.js:633-763, and by the host library, so the three statements must agree.
const List<String> kConformanceIds = <String>[
  "alpha-multiplicative",
  "clip-intersect",
  "path-dash-normalized",
  "arc-angle-mapping",
  "right-mask-stops",
  "gradient-spec",
  "color-calibration",
  "glyph-baseline",
  "unknown-op-ignored",
  "hits-contract",
  "stage-math",
  "no-dedupe",
];

/// The eight documented inbound entries of window.__rhineRail (web/rhine_replica/index.html:392-399).
/// The assets accessor at index.html:400 is deliberately absent: it is page internal state, and
/// leaving it out is what makes the host surface only these eight (M12-F8).
const List<String> kRailEntryNames = <String>[
  "resize", //      index.html:126  (logicalWidth, logicalHeight)
  "publish", //     index.html:227  ({generation, commands, hits, frame}) or the same JSON string
  "state", //       index.html:268  () -> {generation, hits, logical, stage, counters, ...}
  "conformance", // index.html:294  () -> [{id, ok, expected, actual, note}]
  "loadAssets", //  index.html:311  (base, letteringBase) -> Promise
  "attachAsset", // index.html:338  (kind, key, value) -> {ok, reason?}
  "attachImage", // index.html:351  (key, src) -> {ok} or a Promise
  "hello", //       index.html:379  () -> {version, stageHeight, devicePixelRatio, ...}
];

/// Outbound envelope types the page may emit (index.html:57-59). Anything else is counted by the
/// host and exposed on unknownTypes; it is never dropped silently.
const List<String> kOutboundWhitelist = <String>[
  "ready",
  "firstFrame",
  "publish",
  "state",
  "error",
  "console",
];

/// Host transcript assertions that are still pending: they need a device or a webview_flutter
/// dependency this phase forbids. Each entry names the requirement, the evidence that makes it a
/// requirement, and the rail entries it covers. covers is the M12-F3 fix: the previous version
/// searched the joined requirement text for each rail call, but no pending text mentioned state()
/// or conformance(), so the search could only fail once executed. Coverage is an explicit set now,
/// and a covered entry must still be named in the requirement of the item that covers it.
const List<Map<String, Object>> kHostPending = <Map<String, Object>>[
  <String, Object>{
    "id": "H1-rail-ready",
    "requirement": "the host waits for window.__rhineReady and reads the rail version back with "
        "hello() before it publishes anything",
    "evidence": "web/rhine_replica/index.html:402-403 sets __rhineReady and posts ready from "
        "hello(); no Qt counterpart - Qt has no ready handshake, so the page owns this rule",
    "covers": <String>["hello"],
  },
  <String, Object>{
    "id": "H2-resize-before-publish",
    "requirement": "the stage size arrives through resize() before the first publish(), because "
        "the stage is unusable until it has a scale",
    "evidence": "web/rhine_replica/index.html:75 and :118-119 - the stage scale starts at 0 and "
        "applyHudTransform multiplies by it and applies it; Qt/src/Engine.cpp:841-849 sets the "
        "surface size "
        "before the first frame is drawn",
    "covers": <String>["resize"],
  },
  <String, Object>{
    "id": "H3-triple-forwarded",
    "requirement": "publish() carries generation, commands, hits and frame as one generation and "
        "all four reach the page unchanged",
    "evidence": "Qt/src/NativeHud.h:74-76 - commands, hits and frame are the published generation; "
        "Qt/src/Engine.cpp:1348,1379,1412 read and store all three from one object",
    "covers": <String>["publish"],
  },
  <String, Object>{
    "id": "H4-hit-dispatch",
    "requirement": "the hit table that publish() delivered is the dispatch table: a tap becomes "
        "the published action of the matching hit, unchanged",
    "evidence": "Qt/src/NativeHud.cpp:102-109 - the hit table is the dispatch table; "
        "Qt/src/PlayerBar.cpp:46-53 - only the PlayerBar owner adds fixed",
    "covers": <String>["publish"],
  },
  <String, Object>{
    "id": "H5-resume-without-rebuild",
    "requirement": "resume after background does not rebuild the page, and state() is read back "
        "to compare the delivered generation with the page counters",
    "evidence": "web/rhine_replica/index.html:268-292 - state() reports generation and counters, so "
        "a rebuilt page is visible; no Qt counterpart - the page owns its surface for the lifetime "
        "of the host",
    "covers": <String>["state"],
  },
  <String, Object>{
    "id": "H6-conformance-readback",
    "requirement": "conformance() must answer all twelve in-page ids and a missing id is a failure, "
        "never a skip",
    "evidence": "web/rhine_replica/index.html:294-296 - conformance() answers one entry per id; "
        "web/rhine_replica/renderer.js:633-763 defines the twelve ids",
    "covers": <String>["conformance"],
  },
  <String, Object>{
    "id": "H7-assets-attached",
    "requirement": "assets reach the page only through loadAssets(), attachAsset() and "
        "attachImage(), and a remote image source is refused",
    "evidence": "web/rhine_replica/index.html:311-368 - the three asset entries; index.html:18 - "
        "img-src 'self' data: blob: refuses a remote image; Qt/src/Glyphs.cpp:75,83 load the same "
        "files from disk",
    "covers": <String>["loadAssets", "attachAsset", "attachImage"],
  },
];

/// One command stream that exercises all 17 operations once, in the published order.
List<List<Object>> buildCommandFixture() {
  return <List<Object>>[
    <Object>["save"],
    <Object>["alpha", 0.5],
    <Object>["translate", 12.5, -8.25],
    <Object>["scale", 1.5, 2.0],
    <Object>["rotate", 0.7853981633974483],
    <Object>["clip", 40, 260, 326, 696],
    <Object>["fill", <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"], 0, 0, 1728, 1080],
    <Object>["ellipse", <Object>[0.92, 0.92, 0.92, 1, "calibratedWhite"], 864, 540, 192, 192],
    <Object>["text", "Rhine", 326, 434, 32, "demibold", 0.5, <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"]],
    <Object>["art", "brand", 234, 96, 48, 3, 1.0, <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"]],
    <Object>["fill-path", "M0 0H10V10H0Z", <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"]],
    <Object>[
      "path",
      "M0 0L10 10",
      2.0,
      <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"],
      <Object>[6.0, 4.0],
      3.0,
    ],
    <Object>["arc", 864, 540, 120, 0.0, 1.5707963267948966, 3.0, <Object>[0.08, 0.085, 0.075, 1, "calibratedRGB"]],
    <Object>["right-mask", <Object>[0.9, 0.9, 0.88, 1, "calibratedRGB"], 1240, 160, 1728, 1080],
    <Object>["gradient", true],
    <Object>["image", "cover-17", 700, 300, 328, 328],
    <Object>["restore"],
  ];
}

/// The published hit table shape: exactly these six keys, plus fixed only where the Qt owner adds it.
const Set<String> kHitKeys = <String>{
  "x",
  "y",
  "width",
  "height",
  "action",
  "label",
};

Map<String, Object?> buildFrameFixture({int generation = 1}) {
  return <String, Object?>{
    "generation": generation,
    "commands": buildCommandFixture(),
    "hits": <Object>[
      <String, Object?>{"x": 700.0, "y": 300.0, "width": 328.0, "height": 328.0, "action": "open-detail", "label": "第 17 首"},
      <String, Object?>{
        "x": 96.0,
        "y": 1000.0,
        "width": 1728.0,
        "height": 80.0,
        "action": "player-toggle",
        "label": "播放",
        "fixed": true,
      },
    ],
    "frame": <String, Object?>{
      "mode": "detail",
      "viewer": false,
      "detail": 1.0,
      "background": <Object>[0.8227857543924378, 0.7835377915215659, 0.7529422167708612],
    },
  };
}

/// The stage mapping of plan 4.3: a 1080 tall logical stage, width from the surface aspect ratio.
double stageScale(double height) => height / 1080.0;

double stageWidth(double width, double height) => 1080.0 * (width / height);

// ---------------------------------------------------------------------------------------------
// A page shaped transport. The library under test never touches a WebView, so the whole host
// contract is observable here without a device and without dart:ffi or a Flutter binding.
// ---------------------------------------------------------------------------------------------

/// Answers like the page and records every script the host sent. The inbound queue is fixed at
/// construction and replayed through Stream.fromIterable (dart:core), which is why this file needs
/// no dart:async import on top of dart:convert and flutter_test.
class FakeRailTransport implements replica.WebViewReplicaTransport {
  FakeRailTransport({
    this.answers = const <String, String>{},
    List<Object?> inbound = const <Object?>[],
  }) : _inbound = <Object?>[...inbound];

  /// Response per rail entry name; the key "*" answers any entry with no exact key.
  final Map<String, String> answers;

  final List<Object?> _inbound;
  final List<String> scripts = <String>[];

  int closeCount = 0;
  Object? throwOnce;

  @override
  Stream<Object?> get incoming => Stream<Object?>.fromIterable(_inbound);

  @override
  Future<String?> evaluate(String script) async {
    scripts.add(script);
    final failure = throwOnce;
    if (failure != null) {
      throwOnce = null;
      throw failure;
    }
    for (final answer in answers.entries) {
      if (script.startsWith("window.__rhineRail." + answer.key + "(")) {
        return answer.value;
      }
    }
    return answers["*"];
  }

  @override
  Future<void> close() async {
    closeCount += 1;
  }

  /// The rail entry names this transport was asked for, in call order.
  List<String> get called => scripts
      .map((script) => script.substring("window.__rhineRail.".length).split("(").first)
      .toList();
}

/// The answers a healthy page gives. resize mirrors index.html:157-158 (stage = width, height,
/// scale); hello mirrors index.html:379-388.
Map<String, String> railAnswers({
  String attachImage = '{"ok":true}',
  String? conformance,
  String state = '{"generation":7,"hits":[],"logical":{"width":1462.857,"height":914.286},'
      '"stage":{"width":1728,"height":1080,"scale":0.846561},"devicePixelRatio":1,'
      '"firstFrame":null,"ops":{"fill":2},'
      '"counters":{"published":1,"rejected":0,"rendered":1,"unknownOps":0,"missingGlyphs":0,'
      '"missingImages":0,"missingArt":0,"layoutFallbacks":0},'
      '"assets":{"glyphs":true,"lettering":false,"images":0},"assetErrors":[],"errors":[],'
      '"three":{"present":false,"glbLoaded":false,"loadedKeys":[],"renderClock":0,'
      '"webgl2":false,"lastError":null,"reason":"scene-module-absent"}}',
}) {
  return <String, String>{
    "resize": '{"ok":true,"stage":{"width":1728,"height":1080,"scale":0.846561,'
        '"logical":{"width":1462.857,"height":914.286}}}',
    "publish": '{"ok":true,"generation":7,"ops":{"fill":2},"hits":2}',
    "state": state,
    "conformance": conformance ?? conformanceAnswer(kConformanceIds),
    "hello": '{"version":"T15-S01-rail-1","stageHeight":1080,"devicePixelRatio":1,"webgl2":false,'
        '"path2d":true,"userAgent":"RhineSlice/1.0"}',
    "loadAssets": '{"ok":true}',
    "attachAsset": '{"ok":true}',
    "attachImage": attachImage,
    "*": '{"ok":true}',
  };
}

/// One conformance answer per id, all passing except the ones in failing.
String conformanceAnswer(List<String> ids, {Set<String> failing = const <String>{}}) {
  final rows = ids
      .map((id) => '{"id":"' + id + '","ok":' + (failing.contains(id) ? "false" : "true") +
          ',"expected":1,"actual":1,"note":""}')
      .toList();
  return "[" + rows.join(",") + "]";
}

/// The ready envelope index.html:403 posts from hello().
String readyEnvelope() =>
    '{"type":"ready","payload":{"version":"T15-S01-rail-1","stageHeight":1080,"devicePixelRatio":1}}';

/// Lets the fixed inbound queue reach the host. Five turns is far more than a stream needs, and it
/// uses no fake clock, so no case can hang on a device this phase never has.
Future<void> settle() async {
  for (var turn = 0; turn < 5; turn += 1) {
    await Future<void>.delayed(Duration.zero);
  }
}

Matcher throwsReplicaCode(String code) => throwsA(
      isA<replica.WebViewReplicaError>().having((error) => error.code, "code", code),
    );

/// Publishes the fixture generation through the host contract.
Future<replica.WebViewReplicaResult> publishFixture(
  replica.WebViewReplicaHost host, {
  int generation = 7,
  List<Object?>? commands,
  List<Map<String, Object?>>? hits,
  Map<String, Object?>? frame,
}) {
  final fixture = buildFrameFixture(generation: generation);
  return host.publish(
    generation: generation,
    commands: commands ?? (fixture["commands"]! as List).cast<Object?>(),
    hits: hits ?? (fixture["hits"]! as List).cast<Map<String, Object?>>(),
    frame: frame ?? (fixture["frame"]! as Map).cast<String, Object?>(),
  );
}

/// Reads the JSON the host handed to publish() back out of the script. The literal is single
/// quoted by WebViewReplicaContract.jsStringLiteral, and the fixture carries no quote or
/// backslash, so the body must still be the JSON verbatim.
String publishedJson(String script) {
  final open = script.indexOf("(");
  final close = script.lastIndexOf(")");
  expect(open, greaterThan(0), reason: "a rail call is an expression");
  expect(close, greaterThan(open));
  final literal = script.substring(open + 1, close);
  expect(literal.startsWith("'"), isTrue, reason: "the JSON travels as a single quoted literal");
  expect(literal.endsWith("'"), isTrue);
  final body = literal.substring(1, literal.length - 1);
  expect(body.contains("\\"), isFalse,
      reason: "the fixture needs no escape, so the JSON reaches the page unchanged");
  return body;
}

/// Builds a host whose queue already carries whichever envelopes the case needs.
replica.WebViewReplicaHost hostWith(FakeRailTransport transport) =>
    replica.WebViewReplicaHost(transport: transport);

void main() {
  // flutter_test binding only: package:integration_test is not a dependency of this tree.
  TestWidgetsFlutterBinding.ensureInitialized();

  group("T15 slice fixture integrity (pure Dart, no device, no host)", () {
    test("the fixture covers the 17 published operations in the published order", () {
      final ops = buildCommandFixture().map((row) => row.first as String).toList();
      expect(ops, equals(kOpOrder));
      expect(ops.toSet().length, kOpOrder.length, reason: "no operation may stand in for another");
      expect(ops.first, "save", reason: "the chain opens with save (Glyphs.cpp:644)");
      expect(ops.last, "restore", reason: "and closes with the matching restore (Glyphs.cpp:651)");
    });

    test("a[0] is the operation name and only absent numbers default to zero", () {
      final fixture = buildCommandFixture();
      for (final row in fixture) {
        expect(row, isNotEmpty);
        expect(row.first, isA<String>());
      }
      // fill puts its colour at a[1] and its rectangle at a[2..5] (Glyphs.cpp:691).
      final fill = fixture.firstWhere((row) => row.first == "fill");
      expect(fill[1], isA<List<Object>>());
      expect(fill.length, 6);
      // text keeps value a[1], x a[2], y a[3], size a[4], weight a[5], tracking a[6], colour a[7].
      final text = fixture.firstWhere((row) => row.first == "text");
      expect(text.length, 8);
      expect(text[5], "demibold");
      // art keeps the count at a[5] as a number; Qt reads it with toInt(-1) (Glyphs.cpp:718).
      final art = fixture.firstWhere((row) => row.first == "art");
      expect(art[5], isA<int>());
      // the clip rectangle is four numbers in the published order (Glyphs.cpp:676).
      final clip = fixture.firstWhere((row) => row.first == "clip");
      expect(clip.sublist(1), <Object>[40, 260, 326, 696]);
    });

    test("hits carry exactly the six published keys and only PlayerBar is fixed", () {
      final hits = (buildFrameFixture()["hits"]! as List<Object>).cast<Map<String, Object?>>();
      for (final hit in hits) {
        expect(hit.keys.toSet().difference(kHitKeys).difference(<String>{"fixed"}), isEmpty,
            reason: "an unknown hit key is an invented field");
        expect(kHitKeys.difference(hit.keys.toSet()), isEmpty,
            reason: "a missing key would break NativeHud.cpp:102-109");
      }
      final fixed = hits.where((hit) => hit["fixed"] == true).toList();
      expect(fixed.length, 1, reason: "PlayerBar.cpp:46-53 is the only fixed hit");
      expect(fixed.single["action"], "player-toggle");
      expect(hits.first.containsKey("fixed"), isFalse,
          reason: "a HUD hit never grows the PlayerBar flag");
    });

    test("equal commands are never deduplicated and hits keep their published order", () {
      final commands = buildCommandFixture();
      final doubled = <List<Object>>[...commands, commands[6]];
      final count = doubled.where((row) => row.first == "fill").length;
      expect(count, 2, reason: "deduplication of legal equal commands is forbidden");
      final hits = (buildFrameFixture()["hits"]! as List<Object>).cast<Map<String, Object?>>();
      expect(hits.first["action"], "open-detail");
      expect(hits.last["action"], "player-toggle",
          reason: "the PlayerBar hit is published last and never sorted to the front");
    });

    test("the generation triple survives a JSON round trip unchanged", () {
      final fixture = buildFrameFixture(generation: 7);
      final decoded = jsonDecode(jsonEncode(fixture)) as Map<String, dynamic>;
      expect(decoded["generation"], 7);
      expect(decoded.containsKey("commands"), isTrue);
      expect(decoded.containsKey("hits"), isTrue);
      expect(decoded.containsKey("frame"), isTrue);
      expect(decoded["commands"], hasLength(kOpOrder.length));
      final hits = (decoded["hits"] as List<dynamic>).cast<Map<String, dynamic>>();
      expect(hits, hasLength(2));
      expect(hits.last["fixed"], isTrue);
      expect(hits.first.containsKey("fixed"), isFalse);
      final frame = decoded["frame"] as Map<String, dynamic>;
      expect(frame["mode"], "detail");
      expect(frame["viewer"], isFalse);
      expect(frame["background"], hasLength(3));
    });

    test("the stage mapping reproduces the published scale and width", () {
      expect(stageScale(914.286), closeTo(0.846561, 1e-6));
      expect(stageWidth(1462.857, 914.286), closeTo(1728.0, 0.01));
      expect(stageScale(720.0), closeTo(0.666667, 1e-6));
      expect(stageWidth(1280.0, 720.0), closeTo(1920.0, 1e-6));
      expect(stageScale(1080.0), 1.0);
    });
  });

  group("T15 slice host transcript (pending, no device in this phase)", () {
    test("every pending host assertion is unique and names its evidence", () {
      final ids = kHostPending.map((entry) => entry["id"]! as String).toList();
      expect(ids.toSet().length, ids.length, reason: "a duplicated id would hide a missing assertion");
      final citation = RegExp(r"[A-Za-z0-9_./-]+\.(dart|cpp|h|html|js|md|yaml):[0-9]+");
      for (final entry in kHostPending) {
        expect(entry["requirement"]! as String, isNotEmpty);
        final evidence = entry["evidence"]! as String;
        expect(evidence, isNotEmpty, reason: "a requirement without evidence is an invention");
        expect(citation.hasMatch(evidence) || evidence.contains("no Qt counterpart"), isTrue,
            reason: "the evidence of " + (entry["id"]! as String) +
                " must name a file and a line, or admit that Qt has no counterpart");
      }
    });

    test("the covered entries union to the whole inbound rail", () {
      // M12-F3: coverage is a set relation now, not a substring hunt over requirement prose.
      final covered = <String>{};
      for (final entry in kHostPending) {
        final covers = (entry["covers"]! as List<Object?>).cast<String>();
        for (final name in covers) {
          expect(kRailEntryNames, contains(name),
              reason: "pending " + (entry["id"]! as String) + " covers " + name +
                  ", which is not one of the eight documented rail entries");
          covered.add(name);
        }
      }
      expect(kRailEntryNames, hasLength(8), reason: "index.html:392-399 exposes eight entries");
      expect(kRailEntryNames.toSet().length, 8);
      expect(kRailEntryNames, isNot(contains("assets")),
          reason: "the assets accessor of index.html:400 is not a host entry point");
      expect(covered, equals(kRailEntryNames.toSet()),
          reason: "every rail entry needs a pending assertion or the coverage claim is false");
    });

    test("a covered rail entry is named in the requirement of the item that covers it", () {
      // The old case searched the joined requirement text for each rail call, but the texts never
      // contained state() or conformance(), so it could only fail. The relation above carries the
      // coverage; this case keeps the prose honest: an item that claims an entry must name it.
      for (final name in kRailEntryNames) {
        final items = kHostPending
            .where((entry) => (entry["covers"]! as List<Object?>).contains(name))
            .toList();
        expect(items, isNotEmpty, reason: "no pending item covers the rail entry " + name);
        final named = items
            .any((entry) => (entry["requirement"]! as String).contains(name + "()"));
        expect(named, isTrue,
            reason: "the pending items covering " + name + " never write " + name +
                "(), so an unrelated word could satisfy a text search");
      }
    });

    test("the in-page conformance ids are exactly the ones the page must answer", () {
      expect(kConformanceIds.toSet().length, kConformanceIds.length);
      expect(kConformanceIds, contains("unknown-op-ignored"),
          reason: "the must-fix of reports/T15-V3-S01-REVIEW2.json is guarded by this id");
      expect(kConformanceIds, contains("hits-contract"));
      expect(kConformanceIds, contains("stage-math"));
    });
  });

  group("T15 replica host contract (lib/platform/webview_replica.dart, RED-not-executed)", () {
    test("the library states the same contract as the page and this fixture", () {
      expect(replica.kStageHeight, 1080.0,
          reason: "Engine.cpp:847 resizes the scene to a 1080 tall stage");
      expect(replica.kRailVersion, "T15-S01-rail-1",
          reason: "index.html:381 and :391 both publish this version");
      expect(replica.kRailEntries, equals(kRailEntryNames),
          reason: "the host may only call the documented entries");
      expect(replica.kConformanceIds, equals(kConformanceIds),
          reason: "the host, the page and the sister test must name the same twelve ids");
      expect(replica.kHitKeys, equals(kHitKeys),
          reason: "NativeHud.cpp:102-109 publishes exactly these six keys");
      expect(replica.kOutboundTypes, equals(kOutboundWhitelist),
          reason: "index.html:57-59 is the outbound whitelist");
      expect(replica.kAssetKinds, equals(<String>["glyphs", "lettering", "image"]),
          reason: "index.html:338-349 accepts exactly these kinds");
    });

    test("the library names every rail member, page refusal and answer field", () {
      // The rail object as the page really builds it (index.html:390-401). The host may call
      // eight of these ten members; version and assets are page identity and page state.
      expect(replica.kRailMembers,
          equals(<String>[
            "version", "resize", "publish", "state", "conformance", "loadAssets", "attachAsset",
            "attachImage", "hello", "assets",
          ]),
          reason: "index.html:390-401 is the whole rail object, members in page order");
      expect(replica.kRailMembers.sublist(1, 9), equals(replica.kRailEntries),
          reason: "the eight host-callable entries are exactly kRailMembers minus version and assets");
      expect(replica.kRailMembers.toSet().difference(replica.kRailNonCallableMembers),
          equals(replica.kRailEntries.toSet()),
          reason: "subtracting the non-callable members leaves the eight entries, not nine");
      expect(replica.kRailNonCallableMembers, equals(<String>{"version", "assets"}),
          reason: "index.html:391 is the version string and :400 is the assets accessor");
      expect(replica.kRailMembers, isNot(contains("render")),
          reason: "render is a page internal function, never a rail entry");

      expect(replica.kPublishRejectionReasons,
          equals(<String>[
            "unparsable", "malformed", "incomplete-generation-triple", "missing-generation",
          ]),
          reason: "index.html:235, :240, :244, :249 are the four publish refusals");
      expect(replica.kResizeBadSizeReason, "bad-size", reason: "index.html:130");
      expect(replica.kAttachUnknownKindReason, "unknown-kind", reason: "index.html:346");
      expect(replica.kSceneModuleAbsentReason, "scene-module-absent",
          reason: "index.html:203 records the absent scene module; the host never fakes present: true");
      expect(replica.kPublishResultKeys, equals(<String>["ok", "generation", "ops", "hits"]),
          reason: "index.html:265 answers exactly these four keys");
      expect(replica.kPublishPayloadKeys, equals(<String>["generation", "ops", "hits"]),
          reason: "index.html:264 posts the same three keys without the ok flag");
      expect(replica.kFirstFramePayloadKeys, equals(<String>["at", "generation", "ops"]),
          reason: "index.html:261 builds the one-shot firstFrame payload");
      expect(replica.kStateSnapshotKeys, hasLength(12), reason: "index.html:269-291");
      expect(replica.kStateCounterKeys, hasLength(8), reason: "index.html:277-286");
      expect(replica.kStateAssetKeys, equals(<String>["glyphs", "lettering", "images"]),
          reason: "index.html:287");
      expect(replica.kHelloKeys, hasLength(6), reason: "index.html:380-387");
      expect(replica.kHelloKeys, containsAll(<String>["webgl2", "path2d", "userAgent"]),
          reason: "the two probes and the user agent are the reason hello() works before ready");

      // The constants only earn their place if they describe the payloads the host really
      // receives, so every documented shape is checked against a page-shaped answer instead of
      // against the constant list itself.
      final stateMap = replica.stringKeyedMap(jsonDecode(railAnswers()["state"]!));
      expect(replica.WebViewReplicaContract.missingKeys(stateMap, replica.kStateSnapshotKeys),
          isEmpty,
          reason: "the state answer carries every documented snapshot key (index.html:269-291)");
      expect(
          replica.WebViewReplicaContract.missingKeys(
              replica.stringKeyedMap(stateMap["counters"]), replica.kStateCounterKeys),
          isEmpty,
          reason: "index.html:277-286 publishes all eight counters");
      expect(
          replica.WebViewReplicaContract.missingKeys(
              replica.stringKeyedMap(stateMap["assets"]), replica.kStateAssetKeys),
          isEmpty);
      expect(
          replica.WebViewReplicaContract.missingKeys(
              replica.stringKeyedMap(jsonDecode(railAnswers()["hello"]!)), replica.kHelloKeys),
          isEmpty,
          reason: "hello() answers every documented key (index.html:380-387)");
      expect(
          replica.WebViewReplicaContract.missingKeys(
              replica.stringKeyedMap(jsonDecode(railAnswers()["publish"]!)), replica.kPublishResultKeys),
          isEmpty,
          reason: "a publish answer that is missing ops or hits is incomplete");
      expect(
          replica.WebViewReplicaContract.missingKeys(
              replica.stringKeyedMap(jsonDecode('{"generation":7}')), replica.kPublishResultKeys),
          equals(<String>["ok", "ops", "hits"]),
          reason: "a thin answer must be reported, never read as complete");
    });

    test("the host reaches every rail entry and refuses every other name", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      expect(host.isReady, isTrue, reason: "index.html:403 posts ready from hello()");
      for (final entry in kRailEntryNames) {
        if (entry == "resize") {
          await host.resize(1462.857, 914.286);
        } else if (entry == "publish") {
          await publishFixture(host);
        } else {
          await host.invoke(entry);
        }
      }
      expect(transport.called, equals(kRailEntryNames),
          reason: "each documented entry is reachable exactly once, in page order");
      for (final invented in <String>["assets", "render", "ready", "", "resize ", "_rhineRail"]) {
        await expectLater(host.invoke(invented),
            throwsReplicaCode(replica.kErrorUnknownRailEntry));
      }
      expect(transport.called, hasLength(kRailEntryNames.length),
          reason: "a refused name never reaches the page, so exclusivity is enforced, not commented");
      expect(host.railCalls, hasLength(kRailEntryNames.length));
      await host.dispose();
    });

    test("a refused publish never reaches the page", () async {
      final cold = FakeRailTransport(answers: railAnswers());
      final coldHost = hostWith(cold);
      await expectLater(publishFixture(coldHost), throwsReplicaCode(replica.kErrorNotReady));
      expect(cold.scripts, isEmpty, reason: "the host refuses before it builds a script");
      expect(coldHost.publishedCount, 0);
      expect(coldHost.railCalls, isEmpty);
      await coldHost.dispose();

      // ready, but no resize: index.html:75 leaves the stage at scale 0, so a publish would paint
      // nothing and the host must say so instead of sending it.
      final scaleZero = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final warmHost = hostWith(scaleZero);
      await settle();
      expect(warmHost.isReady, isTrue);
      expect(warmHost.isResized, isFalse);
      await expectLater(publishFixture(warmHost),
          throwsReplicaCode(replica.kErrorResizeRequired));
      expect(scaleZero.scripts, isEmpty,
          reason: "a publish that would paint at scale 0 is refused host side");
      await warmHost.dispose();
    });

    test("resize precedes the first publish and the stage math is the Qt math", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      final resized = await host.resize(1462.857, 914.286);
      expect(transport.scripts.first, "window.__rhineRail.resize(1462.857, 914.286)",
          reason: "the host builds the documented rail expression and nothing else");
      expect(resized["stage"], isA<Map<String, Object?>>(),
          reason: "index.html:157-158 answers with the applied stage");
      expect(host.stageScale, closeTo(0.846561, 1e-6), reason: "scale = height / 1080 (Engine.cpp:847)");
      expect(host.stageWidth, closeTo(1728.0, 0.01), reason: "Engine.cpp:1353");
      expect(host.logicalWidth, 1462.857);
      expect(host.logicalHeight, 914.286);
      expect(host.isResized, isTrue);
      expect(host.railCalls, <String>["resize"]);
      await publishFixture(host);
      expect(host.railCalls, <String>["resize", "publish"],
          reason: "the first publish lands after resize, never before it");
      expect(host.publishedCount, 1);
      expect(host.lastGeneration, 7);
      await host.dispose();
    });

    test("the four published values travel as one generation", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      await host.resize(1462.857, 914.286);
      await publishFixture(host, generation: 7);
      final script = transport.scripts.last;
      expect(script.startsWith("window.__rhineRail.publish('"), isTrue,
          reason: "the generation travels as the JSON string index.html:231 parses");
      final published = jsonDecode(publishedJson(script)) as Map<String, dynamic>;
      expect(published.keys.toSet(),
          equals(<String>{"generation", "commands", "hits", "frame"}),
          reason: "the page refuses a partial triple (index.html:242-245)");
      expect(published["generation"], 7);
      final commands = (published["commands"] as List<dynamic>);
      expect(commands, hasLength(kOpOrder.length));
      expect(commands.first, <dynamic>["save"]);
      final hits = (published["hits"] as List<dynamic>).cast<Map<String, dynamic>>();
      expect(hits, hasLength(2));
      expect(hits.last["fixed"], isTrue, reason: "PlayerBar.cpp:46-53");
      expect(hits.first.containsKey("fixed"), isFalse);
      expect((published["frame"] as Map<String, dynamic>)["mode"], "detail");
      await host.dispose();
    });

    test("the outbound whitelist admits six types and counts the rest", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[
          readyEnvelope(),
          '{"type":"firstFrame","payload":{"generation":7}}',
          '{"type":"publish","payload":{"generation":7}}',
          '{"type":"state","payload":{"generation":7,"stage":{"scale":0.846561,"width":1728,"height":1080},'
              '"logical":{"width":1462.857,"height":914.286}}}',
          '{"type":"console","payload":{"level":"log","text":"ready"}}',
          '{"type":"error","payload":{"where":"render","detail":"render-failed"}}',
          '{"type":"telemetry","payload":{"fps":60}}',
          '{"type":"bogus","payload":{}}',
        ],
      );
      final host = hostWith(transport);
      final seen = <replica.WebViewReplicaMessage>[];
      final errors = <replica.WebViewReplicaError>[];
      host.messages.listen(seen.add);
      host.errors.listen(errors.add);
      await settle();
      expect(host.receivedCount, 8);
      expect(seen.map((message) => message.type).toList(),
          equals(<String>["ready", "firstFrame", "publish", "state", "console", "error", "telemetry", "bogus"]),
          reason: "an unknown type is still delivered, never dropped");
      expect(seen.first.isKnownType, isTrue);
      expect(seen.last.isKnownType, isFalse);
      expect(host.unknownTypes, <String>["telemetry", "bogus"],
          reason: "unknown types are counted and exposed");
      expect(host.unknownTypeCount, 2);
      expect(errors.map((error) => error.code).toList(), <String>[replica.kErrorPageError],
          reason: "the page error type is an error, and console is not");
      expect(errors.single.message, contains("render-failed"),
          reason: "the page's own words survive");
      expect(host.firstFrame, isNotNull);
      expect(host.lastState?["generation"], 7);
      await host.dispose();
    });

    test("a Map envelope and a JSON string envelope are both accepted", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[
          <String, Object?>{
            "type": "ready",
            "payload": <String, Object?>{"version": "T15-S01-rail-1", "stageHeight": 1080},
          },
          '{"type":"firstFrame","payload":{"generation":1}}',
        ],
      );
      final host = hostWith(transport);
      await settle();
      expect(host.isReady, isTrue, reason: "a bridge that already decoded the envelope must work");
      expect(host.receivedCount, 2);
      expect(host.firstFrame, isNotNull);
      await host.dispose();
    });

    test("a ready message that disagrees with the host is reported, not accepted", () async {
      final wrongVersion = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[
          '{"type":"ready","payload":{"version":"T15-rail-9","stageHeight":1080}}',
        ],
      );
      final versionHost = hostWith(wrongVersion);
      final versionErrors = <replica.WebViewReplicaError>[];
      versionHost.errors.listen(versionErrors.add);
      await settle();
      expect(versionHost.isReady, isTrue);
      expect(versionHost.railVersionMatches, isFalse);
      expect(versionErrors.map((error) => error.code).toList(),
          <String>[replica.kErrorRailVersion]);
      await versionHost.dispose();

      final wrongStage = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[
          '{"type":"ready","payload":{"version":"T15-S01-rail-1","stageHeight":720}}',
        ],
      );
      final stageHost = hostWith(wrongStage);
      final stageErrors = <replica.WebViewReplicaError>[];
      stageHost.errors.listen(stageErrors.add);
      await settle();
      expect(stageErrors.map((error) => error.code).toList(),
          <String>[replica.kErrorStageMismatch],
          reason: "Engine.cpp:847 fixes the logical stage at 1080, whatever the surface is");
      await stageHost.dispose();
    });

    test("a rejection from the page surfaces as its own reason, never as silence", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(attachImage: '{"ok":false,"reason":"unknown-kind"}'),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      await expectLater(host.attachImage("cover-17", "./assets/cover-17.png"),
          throwsReplicaCode("unknown-kind"));
      expect(host.rejectedCount, 1);
      expect(
        () => host.attachImage("cover-17", "https://example.test/cover.png"),
        throwsReplicaCode(replica.kErrorRemoteImage),
        reason: "index.html:18 allows img-src 'self' data: blob: only",
      );
      expect(
        () => host.attachAsset("video", "cover-17", 1),
        throwsReplicaCode(replica.kErrorUnknownKind),
        reason: "index.html:346 answers unknown-kind for anything outside glyphs/lettering/image",
      );
      expect(transport.called, <String>["attachImage"],
          reason: "a refused asset never reaches the page");
      await host.dispose();
    });

    test("a malformed envelope is an error, not a dropped message", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>['{not json', '[]', '{"payload":{}}', '{"type":""}'],
      );
      final host = hostWith(transport);
      final errors = <replica.WebViewReplicaError>[];
      host.errors.listen(errors.add);
      await settle();
      expect(errors.map((error) => error.code).toList(),
          <String>[
            replica.kErrorBadEnvelope,
            replica.kErrorBadEnvelope,
            replica.kErrorBadEnvelope,
            replica.kErrorBadEnvelope,
          ]);
      expect(host.receivedCount, 0, reason: "a broken envelope is not a message");
      expect(host.unknownTypeCount, 0);
      expect(transport.scripts, isEmpty);
      await host.dispose();
    });

    test("a transport failure is reported and rethrown", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      final errors = <replica.WebViewReplicaError>[];
      host.errors.listen(errors.add);
      await settle();
      transport.throwOnce = StateError("bridge is gone");
      await expectLater(host.resize(1462.857, 914.286),
          throwsReplicaCode(replica.kErrorTransport));
      expect(errors.map((error) => error.code).toList(), <String>[replica.kErrorTransport],
          reason: "a failure the page never sees is still an error the host exposes");
      expect(host.evalCount, 1);
      expect(host.isResized, isFalse, reason: "a failed resize is not recorded as done");
      await host.dispose();
    });

    test("the hit and command contracts are refused before the call leaves", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      await host.resize(1462.857, 914.286);
      final sixKeys = <String, Object?>{
        "x": 700.0,
        "y": 300.0,
        "width": 328.0,
        "height": 328.0,
        "action": "open-detail",
        "label": "第 17 首",
      };
      await expectLater(
        publishFixture(host, hits: <Map<String, Object?>>[
          <String, Object?>{"x": 700.0, "y": 300.0, "width": 328.0, "height": 328.0, "action": "open-detail"},
        ]),
        throwsReplicaCode(replica.kErrorHitContract),
      );
      await expectLater(
        publishFixture(host, hits: <Map<String, Object?>>[
          <String, Object?>{...sixKeys, "z": 9},
        ]),
        throwsReplicaCode(replica.kErrorHitContract),
      );
      await expectLater(
        publishFixture(host, hits: <Map<String, Object?>>[
          <String, Object?>{...sixKeys, "fixed": "yes"},
        ]),
        throwsReplicaCode(replica.kErrorHitContract),
      );
      await expectLater(
        publishFixture(host, commands: <Object?>[
          <Object?>[7, 1],
        ]),
        throwsReplicaCode(replica.kErrorCommandContract),
      );
      await expectLater(
        publishFixture(host, commands: <Object?>[<Object?>[]]),
        throwsReplicaCode(replica.kErrorCommandContract),
      );
      expect(transport.called, <String>["resize"],
          reason: "every refusal happened host side: no publish script reached the page");
      expect(host.publishedCount, 0);
      await host.dispose();
    });

    test("string literals and values survive the bridge unchanged", () {
      // Every call below goes through the static helpers: a class name is a Type value in Dart,
      // so WebViewReplicaContract can only be used as a prefix, never bound to a local.
      expect(replica.WebViewReplicaContract.jsStringLiteral("Rhine"), "'Rhine'");
      expect(replica.WebViewReplicaContract.jsStringLiteral("it's"), "'it\\'s'",
          reason: "a bare single quote would end the literal");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\nb"), "'a\\nb'",
          reason: "a raw newline would break the one-line script");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\rb"), "'a\\rb'");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\tb"), "'a\\tb'");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\u2028b"), "'a\\u2028b'",
          reason: "U+2028 ends a JavaScript line even inside a literal");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\u2029b"), "'a\\u2029b'");
      expect(replica.WebViewReplicaContract.jsStringLiteral("<script>"), "'\\x3cscript>'",
          reason: "the payload must not close an inline script block");
      expect(replica.WebViewReplicaContract.jsStringLiteral("a\u0001b"), "'a\\u0001b'",
          reason: "a control character is escaped, never emitted raw");
      expect(replica.WebViewReplicaContract.jsStringLiteral("\u{1D11E}"), "'\u{1D11E}'",
          reason: "an astral pair passes through unchanged");
      expect(replica.WebViewReplicaContract.jsValue(null), "null");
      expect(replica.WebViewReplicaContract.jsValue(true), "true");
      expect(replica.WebViewReplicaContract.jsValue(7), "7");
      expect(replica.WebViewReplicaContract.jsValue(1.5), "1.5");
      expect(replica.WebViewReplicaContract.jsValue("Rhine"), "'Rhine'");
      expect(replica.WebViewReplicaContract.jsValue(<String, Object?>{"generation": 7}),
          "JSON.parse('{\"generation\":7}')",
          reason: "the page receives an object, not a string of JSON (index.html:338-349)");
      expect(replica.WebViewReplicaContract.jsValue(<Object?>[1, "a"]), "JSON.parse('[1,\"a\"]')");
      expect(
        () => replica.WebViewReplicaContract.jsValue(double.nan),
        throwsReplicaCode(replica.kErrorNonFiniteNumber),
        reason: "there is no JSON literal for a non finite number, so it is refused",
      );
    });

    test("assets use the three documented entries with the documented arguments", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      await host.loadAssets(base: "./assets/", letteringBase: "./Resources/");
      expect(transport.scripts.last,
          "window.__rhineRail.loadAssets('./assets/', './Resources/')",
          reason: "index.html:311 takes base and letteringBase in that order");
      final attach = await host.attachAsset("glyphs", "misans-demibold", <String, Object?>{"units": 1000});
      expect(attach.ok, isTrue);
      expect(transport.scripts.last,
          "window.__rhineRail.attachAsset('glyphs', 'misans-demibold', JSON.parse('{\"units\":1000}'))",
          reason: "index.html:338 stores the value as an object, not as a JSON string");
      await host.attachImage("cover-17", "./assets/cover-17.png");
      expect(transport.scripts.last,
          "window.__rhineRail.attachImage('cover-17', './assets/cover-17.png')");
      expect(transport.called,
          <String>["loadAssets", "attachAsset", "attachImage"]);
      await host.dispose();
    });

    test("state() reads the page snapshot back and conformance() demands all twelve ids", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      final snapshot = await host.state();
      expect(transport.called, <String>["state"]);
      expect(snapshot["generation"], 7);
      expect(host.lastState?["generation"], 7);
      expect(host.stageScale, closeTo(0.846561, 1e-6),
          reason: "index.html:268-292 reports the stage the page applied");
      expect(host.logicalWidth, 1462.857);
      final report = await host.conformance();
      expect(report.answered, hasLength(12));
      expect(report.ok, isTrue);
      expect(report.missing, isEmpty);
      expect(report.failed, isEmpty);
      await host.dispose();

      final failing = FakeRailTransport(
        answers: railAnswers(
          conformance: conformanceAnswer(kConformanceIds, failing: <String>{"hits-contract"}),
        ),
        inbound: <Object?>[readyEnvelope()],
      );
      final failingHost = hostWith(failing);
      await settle();
      final failed = await failingHost.conformance();
      expect(failed.ok, isFalse);
      expect(failed.failed, <String>["hits-contract"]);
      expect(failed.missing, isEmpty);
      await failingHost.dispose();

      final partial = FakeRailTransport(
        answers: railAnswers(conformance: conformanceAnswer(kConformanceIds.sublist(0, 10))),
        inbound: <Object?>[readyEnvelope()],
      );
      final partialHost = hostWith(partial);
      await settle();
      final missing = await partialHost.conformance();
      expect(missing.ok, isFalse);
      expect(missing.missing, equals(kConformanceIds.sublist(10)),
          reason: "a missing id is a failure, never a skip");
      await partialHost.dispose();

      final wrapped = FakeRailTransport(
        answers: railAnswers(
          conformance: '{"checks":' + conformanceAnswer(<String>[...kConformanceIds, "extra-check"]) + '}',
        ),
        inbound: <Object?>[readyEnvelope()],
      );
      final wrappedHost = hostWith(wrapped);
      await settle();
      final wrappedReport = await wrappedHost.conformance();
      expect(wrappedReport.answered, hasLength(13),
          reason: "the wrapped {checks: [...]} shape is accepted too");
      expect(wrappedReport.unexpected, <String>["extra-check"],
          reason: "an id the host never asked for is reported, not ignored");
      await wrappedHost.dispose();
    });

    test("the library stage math is the fixture stage math", () {
      expect(replica.WebViewReplicaContract.stageScale(914.286), closeTo(stageScale(914.286), 1e-12));
      expect(replica.WebViewReplicaContract.stageWidth(1462.857, 914.286),
          closeTo(stageWidth(1462.857, 914.286), 1e-9));
      expect(replica.WebViewReplicaContract.stageWidth(1280.0, 720.0), closeTo(1920.0, 1e-9));
      expect(replica.WebViewReplicaContract.stageWidth(100.0, 0.0), 1920.0,
          reason: "Engine.cpp:1353 falls back to 1920 when the height is not positive");
      expect(replica.WebViewReplicaContract.stageScale(1080.0), 1.0);
    });

    test("dispose closes the bridge once and refuses later calls", () async {
      final transport = FakeRailTransport(
        answers: railAnswers(),
        inbound: <Object?>[readyEnvelope()],
      );
      final host = hostWith(transport);
      await settle();
      await host.dispose();
      expect(transport.closeCount, 1);
      await expectLater(host.invoke("hello"), throwsReplicaCode(replica.kErrorDisposed));
      await host.dispose();
      expect(transport.closeCount, 1, reason: "dispose is idempotent");
    });
  });

  group("T15 slice device gates (DEVICE_BLOCKED in this phase)", () {
    test("the device evidence stays recorded as missing, never claimed", () {
      // DEVICE_BLOCKED. Kept as an explicit list so the missing evidence is visible:
      //   E1 first visible frame after the command stream is delivered
      //   E2 no black or transparent flash between the Flutter surface and the platform view
      //   E3 rotation does not rebuild the media source, the login session or the Node worker
      //   G4 real Chinese input reaches the page and the committed text is visible
      //   H4 the accessibility tree exposes role, name and the same action as the hit
      //   I1 texture admission order is recorded per frame
      //   J1 System WebView and Chromium versions are recorded; a single version is an open gap
      //   K1 media session resume/pause/toggle/next/prev forward contract
      expect(kDeviceAvailable, isFalse,
          reason: "device gates are not adjudicated in this phase; the slice is source complete only");
    });
  });
}
