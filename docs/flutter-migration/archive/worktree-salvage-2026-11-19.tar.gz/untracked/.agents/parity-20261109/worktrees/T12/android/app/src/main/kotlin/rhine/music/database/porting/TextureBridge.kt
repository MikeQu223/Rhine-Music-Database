/*
 * port-local API，非 Qt 既有远端协议。
 *
 * 本文件是「Qt Android → Flutter 迁移」T12 卡（Qt 离屏 Texture 切片，候选 B）的 Kotlin 侧桥接：
 * Flutter 的 TextureRegistry 产出一个真实的 Flutter texture id 与可渲染 Surface，
 * Qt6 的 QQuickRenderControl 离屏渲染宿主（Qt/porting/TextureHost.cpp）在该 Surface 上出帧，
 * Dart 侧直接 Texture(textureId) 合成 —— 不做像素读回、不伪造首帧、不以静态截图兜底。
 *
 * 通道名、方法名、入参键、返回键、status / backend 枚举与下列两侧逐字对称：
 *   - Qt/porting/TextureHost.h      （C++ 侧 JNI 契约）
 *   - lib/platform/qt_texture.dart  （Dart 侧 MethodChannel 客户端）
 * 协议版本 protocolVersion = 1。该协议是本移植工程为本次迁移自定义的 port-local 契约，
 * Qt 上游并不存在同名远端协议，禁止对外表述为「Qt 既有协议」。
 *
 * 状态：源码已落盘。按本卡硬禁令，**未执行** 任何 flutter / dart / gradle / kotlinc / Qt 编译或测试，
 * validation = NOT_EXECUTED。宿主接线（FlutterEngine / MainActivity / build.gradle.kts 把 Qt .so 打进 APK、
 * pubspec 依赖、Dart 侧注册）属于 ARCH_BLOCKED，本文件不伪造成已完成。
 */

package rhine.music.database.porting

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.Surface
import androidx.annotation.Keep
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.view.TextureRegistry
import org.json.JSONException
import org.json.JSONObject
import kotlin.math.floor

/** 把异常压成一行可读文本；status / reason 回传时不吞掉类名与 message。 */
private fun describeThrowable(t: Throwable): String {
    val message = t.message
    return if (message.isNullOrBlank()) t.javaClass.simpleName else t.javaClass.simpleName + ": " + message
}

/**
 * Flutter Texture 与 Qt 离屏渲染宿主之间的 Kotlin 桥（T12 候选 B）。
 *
 * ## port-local 冻结契约 v1
 *
 * MethodChannel: rhine.music.database/porting/qt_texture；protocolVersion = 1；Map 键全 lowerCamel。
 *
 * | 方法 | 入参 | 返回 |
 * | --- | --- | --- |
 * | probe | {} | status, backend, protocolVersion, reason |
 * | create | width, height, dpr, rotationQuarterTurns | textureId, status, backend, width, height |
 * | render | textureId, frameTimeNanos | textureId, rendered, frameSequence, firstFrame, width, height, rotationQuarterTurns, publishTimestampNanos, status |
 * | resize | textureId, width, height, dpr | width, height |
 * | setRotation | textureId, quarterTurns | rotationQuarterTurns |
 * | status | textureId | status, textureId, frameSequence, firstFrameRendered, width, height, rotationQuarterTurns, backend, lastError, publishTimestampNanos |
 * | dispose | textureId | released |
 * | sendPointer | textureId, x, y, phase(down/move/up), buttons | accepted |
 * | sendKey | textureId, key, down, repeat | accepted |
 *
 * status 枚举：ready / nativeUnavailable / archBlocked / deviceBlocked / failed / released。
 * backend 枚举：opengl / vulkan / none。
 *
 * JNI 类名 rhine.music.database.porting.TextureBridge；companion object + @JvmStatic；
 * 导出符号 Java_rhine_music_database_porting_TextureBridge_<name>（9 个，见 companion 内的声明）。
 *
 * ## 线程模型（本类的核心不变量）
 *
 * worker 线程 HandlerThread("rhine-qt-texture") 串行执行：全部 9 个 native 调用、producer.setSize、
 * producer.getSurface、org.json 解析、entry 表读写。任何两个 native 调用不会并发（Qt 的
 * QQuickRenderControl 与 EGL 上下文都要求单线程使用）。
 *
 * 只有两处 Flutter 侧记账必须留在平台主线程，且有引擎源码依据：
 * 1) TextureRegistry.createSurfaceProducer(...) —— FlutterRenderer 的 imageReaderProducers 是
 *    非同步 ArrayList（FlutterRenderer.java:106 声明、:237 add、:136 restoreSurfaceProducers 遍历、
 *    :313 onTrimMemory 遍历），off-main 调用会与 onResume / 低内存回调竞争；
 * 2) SurfaceProducer.release() —— 同一 list 的 remove（FlutterRenderer.java:761）。
 * 除这两处外，所有 registry / native 操作都在 worker 线程，且 worker 内部严格串行。
 *
 * 渲染节拍由 Dart 侧驱动（Dart 调 render），本类不自建 Choreographer / 定时循环，
 * 避免与 Flutter 自己的帧循环争用 vsync。
 *
 * ## 生命周期
 *
 * create → (render*) → resize / setRotation* → dispose。
 * - textureId 就是 producer.id()，即引擎分配的真实 Flutter texture id，Dart 可直接
 *   Texture(textureId) 使用；本类绝不自行编号。
 * - SurfaceProducer.Callback.onSurfaceAvailable()：重建（先 nativeDestroy 旧 handle，再
 *   nativeCreate(producer.getSurface(), w, h, dpr)），textureId 不变；重建失败 → status=failed + lastError。
 * - onSurfaceCleanup()：nativeDestroy(handle)，handle=0，surfaceLost=true，status 保持 ready，
 *   但 firstFrame 与 publishTimestampNanos 归零（旧帧不得再被当作首帧）。
 * - 两个回调内严禁抛异常（会在 Flutter 平台线程炸掉帧循环）：一律 try/catch 后 post 到 worker。
 *
 * ## 异常与失败语义（全类一致）
 *
 * - 非法参数（width/height <= 0、dpr <= 0、rotationQuarterTurns 不在 0..3、phase 非法、
 *   textureId 未知、参数缺失/类型错）→ result.error("invalid_argument", message, null)。
 * - 运行期失败（native 返回 0、JSON 非法、字段缺失/类型错、handle == 0、库未加载）→ 返回契约 Map，
 *   其中 status 为 failed / nativeUnavailable / archBlocked，并写 entry.lastError（status 方法可读）。
 * - 库加载：System.loadLibrary("RhineMusicDatabase_arm64-v8a") 失败再试 "RhineMusicDatabase"；
 *   全失败 → 所有方法返回 status=nativeUnavailable，reason 含两个库名与异常 message。
 * - 库已加载但符号解析失败（UnsatisfiedLinkError，Kotlin 声明与 .so 导出不一致）→ status=archBlocked。
 * - 任何异常都不允许穿透到 Dart：dispatch 有兜底 catch。
 *
 * ## ARCH_BLOCKED（本文件不负责、也未假装完成）
 *
 * 1) FlutterEngine / MainActivity 里 new TextureBridge(flutterEngine.renderer, messenger).install() 的宿主接线；
 * 2) build.gradle.kts 把 Qt 的 .so（含 JNI 导出）打进 APK，以及 abiFilters / 符号可见性；
 * 3) pubspec 依赖与 Dart 侧 channel 注册；
 * 4) 设备真机首帧、旋转、输入转发的实机验证。
 * 以上均属共享文件或实机验证，不在本 writer 的写域内。
 */
@Keep
class TextureBridge(
    private val registry: TextureRegistry,
    messenger: BinaryMessenger,
) : MethodChannel.MethodCallHandler {

    companion object {
        /** Dart 侧 MethodChannel 名（与 lib/platform/qt_texture.dart 逐字一致）。 */
        const val CHANNEL_NAME: String = "rhine.music.database/porting/qt_texture"

        /** 契约协议版本；任何破坏性字段变更必须自增并同步三方（Kotlin / C++ / Dart）。 */
        const val PROTOCOL_VERSION: Int = 1

        /** worker 线程名：全类唯一的 native 执行线程。 */
        const val THREAD_NAME: String = "rhine-qt-texture"

        // ---- status 枚举（冻结，只允许这 6 个字符串） ----
        const val STATUS_READY: String = "ready"
        const val STATUS_NATIVE_UNAVAILABLE: String = "nativeUnavailable"
        const val STATUS_ARCH_BLOCKED: String = "archBlocked"
        const val STATUS_DEVICE_BLOCKED: String = "deviceBlocked"
        const val STATUS_FAILED: String = "failed"
        const val STATUS_RELEASED: String = "released"

        // ---- backend 枚举（冻结） ----
        const val BACKEND_OPENGL: String = "opengl"
        const val BACKEND_VULKAN: String = "vulkan"
        const val BACKEND_NONE: String = "none"

        // ---- 方法名（冻结，逐字） ----
        const val METHOD_PROBE: String = "probe"
        const val METHOD_CREATE: String = "create"
        const val METHOD_RENDER: String = "render"
        const val METHOD_RESIZE: String = "resize"
        const val METHOD_SET_ROTATION: String = "setRotation"
        const val METHOD_STATUS: String = "status"
        const val METHOD_DISPOSE: String = "dispose"
        const val METHOD_SEND_POINTER: String = "sendPointer"
        const val METHOD_SEND_KEY: String = "sendKey"

        // ---- 入参键（冻结，逐字 lowerCamel） ----
        const val ARG_TEXTURE_ID: String = "textureId"
        const val ARG_WIDTH: String = "width"
        const val ARG_HEIGHT: String = "height"
        const val ARG_DPR: String = "dpr"
        const val ARG_ROTATION_QUARTER_TURNS: String = "rotationQuarterTurns"
        const val ARG_QUARTER_TURNS: String = "quarterTurns"
        const val ARG_FRAME_TIME_NANOS: String = "frameTimeNanos"
        const val ARG_X: String = "x"
        const val ARG_Y: String = "y"
        const val ARG_PHASE: String = "phase"
        const val ARG_BUTTONS: String = "buttons"
        const val ARG_KEY: String = "key"
        const val ARG_DOWN: String = "down"
        const val ARG_REPEAT: String = "repeat"

        // ---- 原生 JSON 键（nativeRender / nativeStatus 返回，冻结，逐字；C++ 侧同名字段） ----
        const val FIELD_RENDERED: String = "rendered"
        const val FIELD_FRAME_SEQUENCE: String = "frameSequence"
        const val FIELD_FIRST_FRAME_RENDERED: String = "firstFrameRendered"
        const val FIELD_WIDTH: String = "width"
        const val FIELD_HEIGHT: String = "height"
        const val FIELD_ROTATION_QUARTER_TURNS: String = "rotationQuarterTurns"
        const val FIELD_PUBLISH_TIMESTAMP_NANOS: String = "publishTimestampNanos"
        const val FIELD_STATUS: String = "status"
        const val FIELD_LAST_ERROR: String = "lastError"
        const val FIELD_BACKEND: String = "backend"

        // ---- sendPointer phase 字符串 ↔ native int 编码 ----
        // 冻结：0 = down，1 = move，2 = up。A1 的 Qt/porting/TextureHost.h 必须用同一编码，
        // nativeSendPointer(handle, x, y, phase, buttons) 的 phase 参数即此值。
        const val PHASE_DOWN: String = "down"
        const val PHASE_MOVE: String = "move"
        const val PHASE_UP: String = "up"
        const val POINTER_PHASE_DOWN: Int = 0
        const val POINTER_PHASE_MOVE: Int = 1
        const val POINTER_PHASE_UP: Int = 2

        /** create 失败 / 未知 texture 的哨兵值；不能复用 0，因为 Flutter 的 textureId 从 0 开始自增。 */
        const val NO_TEXTURE_ID: Long = -1L

        // ---- result.error 的错误码（Kotlin 侧统一走 result.error，不抛给 Dart） ----
        const val ERROR_CODE_INVALID_ARGUMENT: String = "invalid_argument"
        const val ERROR_CODE_DISPOSED: String = "bridge_disposed"
        const val ERROR_CODE_UNAVAILABLE: String = "worker_unavailable"
        const val ERROR_CODE_INTERNAL: String = "bridge_internal"

        // ---- 原生库名单（冻结顺序） ----
        /** Qt Android 的应用库实际名为 lib<applicationBinary>_<abi>.so，故首选带 ABI 后缀的拼写。 */
        private const val LIBRARY_PRIMARY: String = "RhineMusicDatabase_arm64-v8a"
        private const val LIBRARY_FALLBACK: String = "RhineMusicDatabase"

        @Volatile
        private var libraryLoaded: Boolean = false

        @Volatile
        private var libraryLoadError: String? = null

        init {
            loadNativeLibraries()
        }

        /**
         * 依次尝试两个库名；全部失败时记录 reason（含两个库名与每条异常 message），绝不抛出。
         * 只加载一次（companion 初始化时机 = 本类首次被引用）。
         */
        private fun loadNativeLibraries() {
            val failureDetail = StringBuilder()
            for (libraryName in listOf(LIBRARY_PRIMARY, LIBRARY_FALLBACK)) {
                try {
                    System.loadLibrary(libraryName)
                    libraryLoaded = true
                    libraryLoadError = null
                    return
                } catch (t: Throwable) {
                    if (failureDetail.isNotEmpty()) {
                        failureDetail.append("; ")
                    }
                    failureDetail.append(libraryName).append(" -> ").append(describeThrowable(t))
                }
            }
            libraryLoaded = false
            libraryLoadError = "原生库加载失败：依次尝试 " + LIBRARY_PRIMARY + "、" + LIBRARY_FALLBACK +
                " 均不成功（" + failureDetail.toString() + "）"
        }

        /** 供实例方法读取加载结果（避免把可变字段直接暴露给外部）。 */
        internal fun isNativeLibraryLoaded(): Boolean = libraryLoaded

        /** 库加载失败的完整 reason；加载成功时为 null。 */
        internal fun nativeLibraryLoadError(): String? = libraryLoadError

        // ------------------------------------------------------------------
        // JNI 声明：类 rhine.music.database.porting.TextureBridge，companion + @JvmStatic。
        // 契约固定符号名 Java_rhine_music_database_porting_TextureBridge_<name>：
        //   nativeProbe(JNIEnv*, jclass) -> jstring
        //   nativeCreate(JNIEnv*, jclass, jobject surface, jint w, jint h, jfloat dpr) -> jlong
        //   nativeResize(JNIEnv*, jclass, jlong, jint, jint, jfloat) -> void
        //   nativeSetRotation(JNIEnv*, jclass, jlong, jint) -> jboolean
        //   nativeRender(JNIEnv*, jclass, jlong, jlong) -> jstring(JSON)
        //   nativeStatus(JNIEnv*, jclass, jlong) -> jstring(JSON)
        //   nativeSendPointer(JNIEnv*, jclass, jlong, jfloat, jfloat, jint, jint) -> jboolean
        //   nativeSendKey(JNIEnv*, jclass, jlong, jint, jboolean, jboolean) -> jboolean
        //   nativeDestroy(JNIEnv*, jclass, jlong) -> void
        //
        // 注意（#1 未验证 ABI）：companion + @JvmStatic 的 external 声明在 JVM 侧是 TextureBridge 上的
        // static native 方法，符号不带 $Companion 段；但 kotlinc 未在本卡执行，该符号落点无法本机验证。
        // 若运行时符号不匹配，各 handler 会捕获 UnsatisfiedLinkError 并返回 status=archBlocked，
        // 不会崩溃也不会假成功。建议 C++ 侧同时导出带/不带 $Companion 两种拼写作为兜底。
        // ------------------------------------------------------------------

        /** JNI 探测（JSON：status / backend / reason）；库未加载时不会调用到此。 */
        @Keep
        @JvmStatic
        external fun nativeProbe(): String

        /** JNI 创建离屏渲染目标；返回非 0 handle，0 表示原生侧拒绝。 */
        @Keep
        @JvmStatic
        external fun nativeCreate(surface: Surface, width: Int, height: Int, dpr: Float): Long

        /** JNI 尺寸 / dpr 变更（Surface 身份未变时使用）。 */
        @Keep
        @JvmStatic
        external fun nativeResize(handle: Long, width: Int, height: Int, dpr: Float)

        /** JNI 设置旋转（quarterTurns 属于 0..3）；false 表示原生侧拒绝。 */
        @Keep
        @JvmStatic
        external fun nativeSetRotation(handle: Long, quarterTurns: Int): Boolean

        /** JNI 渲染一帧（frameTimeNanos 由 Dart 侧节拍给出），返回 JSON 状态。 */
        @Keep
        @JvmStatic
        external fun nativeRender(handle: Long, frameTimeNanos: Long): String

        /** JNI 读取当前状态，返回 JSON 状态。 */
        @Keep
        @JvmStatic
        external fun nativeStatus(handle: Long): String

        /** JNI 指针事件转发；phase 编码 0=down / 1=move / 2=up。 */
        @Keep
        @JvmStatic
        external fun nativeSendPointer(handle: Long, x: Float, y: Float, phase: Int, buttons: Int): Boolean

        /** JNI 按键事件转发。 */
        @Keep
        @JvmStatic
        external fun nativeSendKey(handle: Long, key: Int, down: Boolean, repeat: Boolean): Boolean

        /** JNI 销毁离屏渲染目标。 */
        @Keep
        @JvmStatic
        external fun nativeDestroy(handle: Long)
    }

    private val channel = MethodChannel(messenger, CHANNEL_NAME)

    /** 全类唯一的 native 执行线程（串行，见类注释「线程模型」）。 */
    private val workerThread = HandlerThread(THREAD_NAME).apply { start() }

    private val workerHandler = Handler(workerThread.looper)

    /** 平台主线程 Handler：只用于 createSurfaceProducer / producer.release() 这两处引擎记账。 */
    private val mainHandler = Handler(Looper.getMainLooper())

    /** 已 dispose 标志：dispose 后不再接受任何方法调用。 */
    @Volatile
    private var disposed = false

    /** 最近一次从原生侧观察到的 backend，用于失败回复里给出诚实值（默认 none）。 */
    private var cachedBackend: String = BACKEND_NONE

    /** textureId → 条目；只在 worker 线程读写（dispose 的退化路径除外，见 dispose）。 */
    private val entries = HashMap<Long, Entry>()

    // ------------------------------------------------------------------
    // 生命周期
    // ------------------------------------------------------------------

    /**
     * 注册 MethodChannel。必须在平台主线程、FlutterEngine attach 之后调用一次；
     * dispose 之前重复调用无害（幂等赋值 handler）。
     */
    fun install() {
        if (disposed) {
            return
        }
        channel.setMethodCallHandler(this)
    }

    /**
     * 解注册通道并释放全部 Flutter texture（幂等）。
     *
     * 顺序有意为之：先在 worker 上 nativeDestroy 所有 handle（停止 Qt 侧对 Surface 的使用），
     * 再回主线程 producer.release()（引擎的 imageReaderProducers 是非同步 list，必须在主线程 remove）。
     * 必须在平台主线程调用（与 FlutterEngine detach 的时机一致）。
     */
    fun dispose() {
        if (disposed) {
            return
        }
        disposed = true
        channel.setMethodCallHandler(null)
        val posted = try {
            workerHandler.post { teardownOnWorker() }
        } catch (t: Throwable) {
            false
        }
        if (!posted) {
            // 退化路径：worker Looper 已退出（例如进程收尾），此时只可能由主线程收尾。
            workerThread.quitSafely()
            releaseAllProducersOnMainThread()
        }
    }

    private fun teardownOnWorker() {
        val snapshot = ArrayList(entries.values)
        entries.clear()
        for (entry in snapshot) {
            entry.released = true
            val handle = entry.handle
            entry.handle = 0L
            if (handle != 0L) {
                runCatching { nativeDestroy(handle) }
            }
            runCatching { entry.producer.setCallback(null) }
            entry.status = STATUS_RELEASED
            entry.firstFrameRendered = false
            entry.publishTimestampNanos = 0L
        }
        workerThread.quitSafely()
        if (snapshot.isNotEmpty()) {
            mainHandler.post { releaseProducersOnMainThread(snapshot) }
        }
    }

    private fun releaseAllProducersOnMainThread() {
        val snapshot = ArrayList(entries.values)
        entries.clear()
        releaseProducersOnMainThread(snapshot)
    }

    private fun releaseProducersOnMainThread(snapshot: List<Entry>) {
        for (entry in snapshot) {
            runCatching { entry.producer.setCallback(null) }
            val released = runCatching { entry.producer.release() }.isSuccess
            if (!released) {
                entry.lastError = "producer.release() 抛异常：纹理可能仍注册在 Flutter 引擎侧"
            }
        }
    }

    // ------------------------------------------------------------------
    // 通道分发
    // ------------------------------------------------------------------

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        val reply = ChannelResult(result)
        if (disposed) {
            reply.error(ERROR_CODE_DISPOSED, "TextureBridge 已 dispose，不再接受方法调用: " + call.method, null)
            return
        }
        val posted = try {
            workerHandler.post { dispatch(call, reply) }
        } catch (t: Throwable) {
            false
        }
        if (!posted) {
            reply.error(ERROR_CODE_UNAVAILABLE, "纹理工作线程不可用，无法处理方法 " + call.method, null)
        }
    }

    /** 在 worker 线程上分发；任何异常都必须在这里被吃掉，绝不穿透到 Flutter 平台线程。 */
    private fun dispatch(call: MethodCall, reply: ChannelResult) {
        try {
            when (call.method) {
                METHOD_PROBE -> handleProbe(reply)
                METHOD_CREATE -> handleCreate(parseCreateArguments(call), reply)
                METHOD_RENDER -> handleRender(parseRenderArguments(call), reply)
                METHOD_RESIZE -> handleResize(parseResizeArguments(call), reply)
                METHOD_SET_ROTATION -> handleSetRotation(parseRotationArguments(call), reply)
                METHOD_STATUS -> handleStatus(parseTextureIdArguments(call), reply)
                METHOD_DISPOSE -> handleDispose(parseTextureIdArguments(call), reply)
                METHOD_SEND_POINTER -> handleSendPointer(parsePointerArguments(call), reply)
                METHOD_SEND_KEY -> handleSendKey(parseKeyArguments(call), reply)
                else -> reply.notImplemented()
            }
        } catch (t: InvalidArgumentsException) {
            reply.error(ERROR_CODE_INVALID_ARGUMENT, t.message ?: "非法参数", null)
        } catch (t: Throwable) {
            reply.error(ERROR_CODE_INTERNAL, "纹理桥内部错误: " + describeThrowable(t), null)
        }
    }

    // ------------------------------------------------------------------
    // 入参解析与校验：非法参数一律 InvalidArgumentsException → invalid_argument
    // ------------------------------------------------------------------

    private fun rawArgument(call: MethodCall, key: String): Any? {
        val present = try {
            call.hasArgument(key)
        } catch (t: Throwable) {
            throw InvalidArgumentsException("arguments 必须是 Map / JSONObject，读取参数 " + key + " 失败: " + describeThrowable(t))
        }
        if (!present) {
            throw InvalidArgumentsException("缺少参数 " + key)
        }
        return try {
            call.argument<Any?>(key)
        } catch (t: Throwable) {
            throw InvalidArgumentsException("读取参数 " + key + " 失败: " + describeThrowable(t))
        }
    }

    private fun requireIntArgument(call: MethodCall, key: String): Int {
        val value = rawArgument(call, key) ?: throw InvalidArgumentsException("参数 " + key + " 不能为 null")
        return when (value) {
            is Int -> value
            is Long -> {
                if (value < Int.MIN_VALUE.toLong() || value > Int.MAX_VALUE.toLong()) {
                    throw InvalidArgumentsException("参数 " + key + " 超出 32 位整数范围: " + value)
                }
                value.toInt()
            }
            else -> throw InvalidArgumentsException("参数 " + key + " 类型应为 int，实际 " + value.javaClass.simpleName)
        }
    }

    private fun requireLongArgument(call: MethodCall, key: String): Long {
        val value = rawArgument(call, key) ?: throw InvalidArgumentsException("参数 " + key + " 不能为 null")
        return when (value) {
            is Int -> value.toLong()
            is Long -> value
            else -> throw InvalidArgumentsException("参数 " + key + " 类型应为 int，实际 " + value.javaClass.simpleName)
        }
    }

    private fun requireDoubleArgument(call: MethodCall, key: String): Double {
        val value = rawArgument(call, key) ?: throw InvalidArgumentsException("参数 " + key + " 不能为 null")
        if (value !is Number) {
            throw InvalidArgumentsException("参数 " + key + " 类型应为 double，实际 " + value.javaClass.simpleName)
        }
        val number = value.toDouble()
        if (number.isNaN() || number.isInfinite()) {
            throw InvalidArgumentsException("参数 " + key + " 必须是有限数值，实际 " + number)
        }
        return number
    }

    private fun requireBooleanArgument(call: MethodCall, key: String): Boolean {
        val value = rawArgument(call, key) ?: throw InvalidArgumentsException("参数 " + key + " 不能为 null")
        val boolean = value as? Boolean
        return boolean ?: throw InvalidArgumentsException("参数 " + key + " 类型应为 bool，实际 " + value.javaClass.simpleName)
    }

    private fun requireStringArgument(call: MethodCall, key: String): String {
        val value = rawArgument(call, key) ?: throw InvalidArgumentsException("参数 " + key + " 不能为 null")
        val text = value as? String
        return text ?: throw InvalidArgumentsException("参数 " + key + " 类型应为 String，实际 " + value.javaClass.simpleName)
    }

    private fun parseCreateArguments(call: MethodCall): CreateArguments {
        val width = requireIntArgument(call, ARG_WIDTH)
        if (width <= 0) {
            throw InvalidArgumentsException("参数 width 必须 > 0，实际 " + width)
        }
        val height = requireIntArgument(call, ARG_HEIGHT)
        if (height <= 0) {
            throw InvalidArgumentsException("参数 height 必须 > 0，实际 " + height)
        }
        val dpr = requireDoubleArgument(call, ARG_DPR)
        if (dpr <= 0.0) {
            throw InvalidArgumentsException("参数 dpr 必须 > 0，实际 " + dpr)
        }
        val rotationQuarterTurns = requireIntArgument(call, ARG_ROTATION_QUARTER_TURNS)
        if (rotationQuarterTurns < 0 || rotationQuarterTurns > 3) {
            throw InvalidArgumentsException("参数 rotationQuarterTurns 必须为 0..3，实际 " + rotationQuarterTurns)
        }
        return CreateArguments(width, height, dpr.toFloat(), rotationQuarterTurns)
    }

    private fun parseRenderArguments(call: MethodCall): RenderArguments {
        val textureId = requireLongArgument(call, ARG_TEXTURE_ID)
        val frameTimeNanos = requireLongArgument(call, ARG_FRAME_TIME_NANOS)
        if (frameTimeNanos < 0L) {
            throw InvalidArgumentsException("参数 frameTimeNanos 必须 >= 0，实际 " + frameTimeNanos)
        }
        return RenderArguments(textureId, frameTimeNanos)
    }

    private fun parseResizeArguments(call: MethodCall): ResizeArguments {
        val textureId = requireLongArgument(call, ARG_TEXTURE_ID)
        val width = requireIntArgument(call, ARG_WIDTH)
        if (width <= 0) {
            throw InvalidArgumentsException("参数 width 必须 > 0，实际 " + width)
        }
        val height = requireIntArgument(call, ARG_HEIGHT)
        if (height <= 0) {
            throw InvalidArgumentsException("参数 height 必须 > 0，实际 " + height)
        }
        val dpr = requireDoubleArgument(call, ARG_DPR)
        if (dpr <= 0.0) {
            throw InvalidArgumentsException("参数 dpr 必须 > 0，实际 " + dpr)
        }
        return ResizeArguments(textureId, width, height, dpr.toFloat())
    }

    private fun parseRotationArguments(call: MethodCall): RotationArguments {
        val textureId = requireLongArgument(call, ARG_TEXTURE_ID)
        val quarterTurns = requireIntArgument(call, ARG_QUARTER_TURNS)
        if (quarterTurns < 0 || quarterTurns > 3) {
            throw InvalidArgumentsException("参数 quarterTurns 必须为 0..3，实际 " + quarterTurns)
        }
        return RotationArguments(textureId, quarterTurns)
    }

    private fun parseTextureIdArguments(call: MethodCall): TextureIdArguments {
        return TextureIdArguments(requireLongArgument(call, ARG_TEXTURE_ID))
    }

    private fun parsePointerArguments(call: MethodCall): PointerArguments {
        val textureId = requireLongArgument(call, ARG_TEXTURE_ID)
        val x = requireDoubleArgument(call, ARG_X).toFloat()
        val y = requireDoubleArgument(call, ARG_Y).toFloat()
        val phaseText = requireStringArgument(call, ARG_PHASE)
        val phase = when (phaseText) {
            PHASE_DOWN -> POINTER_PHASE_DOWN
            PHASE_MOVE -> POINTER_PHASE_MOVE
            PHASE_UP -> POINTER_PHASE_UP
            else -> throw InvalidArgumentsException("参数 phase 必须是 down / move / up，实际 " + phaseText)
        }
        val buttons = requireIntArgument(call, ARG_BUTTONS)
        return PointerArguments(textureId, x, y, phase, buttons)
    }

    private fun parseKeyArguments(call: MethodCall): KeyArguments {
        val textureId = requireLongArgument(call, ARG_TEXTURE_ID)
        val key = requireIntArgument(call, ARG_KEY)
        val down = requireBooleanArgument(call, ARG_DOWN)
        val repeat = requireBooleanArgument(call, ARG_REPEAT)
        return KeyArguments(textureId, key, down, repeat)
    }

    // ------------------------------------------------------------------
    // probe
    // ------------------------------------------------------------------

    /**
     * probe：库未加载 → nativeUnavailable（reason 含两个库名与异常）；已加载 → 调 nativeProbe()
     * 并把 status / backend 归一化到冻结枚举。原生返回纯文本（非 JSON）时按状态 token 处理，
     * 无法识别的 token 归一化为 failed（绝不谎报 ready）。
     */
    private fun handleProbe(reply: ChannelResult) {
        if (!isNativeLibraryLoaded()) {
            reply.success(
                mapOf<String, Any>(
                    "status" to STATUS_NATIVE_UNAVAILABLE,
                    "backend" to BACKEND_NONE,
                    "protocolVersion" to PROTOCOL_VERSION,
                    "reason" to (nativeLibraryLoadError() ?: "原生库未加载（loadLibrary 未成功，且无异常记录）"),
                )
            )
            return
        }
        try {
            val raw = nativeProbe()
            val json = parseJsonObject(raw)
            val status = canonicalStatus(optionalText(json, "status"))
                ?: canonicalStatus(raw)
                ?: STATUS_FAILED
            val backend = canonicalBackend(optionalText(json, "backend"))
            cachedBackend = backend
            val reportedReason = optionalText(json, "reason")
            val reason = when {
                reportedReason.isNotEmpty() -> reportedReason
                status == STATUS_FAILED -> "nativeProbe 返回无法识别的状态: " + truncate(raw)
                else -> ""
            }
            reply.success(
                mapOf<String, Any>(
                    "status" to status,
                    "backend" to backend,
                    "protocolVersion" to PROTOCOL_VERSION,
                    "reason" to reason,
                )
            )
        } catch (t: UnsatisfiedLinkError) {
            reply.success(probeFailure(STATUS_ARCH_BLOCKED, "nativeProbe 符号未解析（Kotlin 声明与 .so 导出不一致）: " + describeThrowable(t)))
        } catch (t: Throwable) {
            reply.success(probeFailure(STATUS_FAILED, "nativeProbe 调用失败: " + describeThrowable(t)))
        }
    }

    private fun probeFailure(status: String, reason: String): Map<String, Any> =
        mapOf<String, Any>(
            "status" to status,
            "backend" to cachedBackend,
            "protocolVersion" to PROTOCOL_VERSION,
            "reason" to reason,
        )

    // ------------------------------------------------------------------
    // create（两段式：主线程分配 producer → worker 完成 native 创建）
    // ------------------------------------------------------------------

    /**
     * create：
     * 1) 平台主线程 registry.createSurfaceProducer(SurfaceLifecycle.manual)
     *    —— FlutterRenderer.imageReaderProducers 是非同步 ArrayList（FlutterRenderer.java:106/:237），
     *    只能在主线程 add；
     * 2) 回到 worker：setCallback → setSize → getSurface → nativeCreate →（可选）nativeSetRotation。
     * textureId 取 producer.id()，即引擎真实 Flutter texture id，Dart 可直接 Texture(textureId)。
     *
     * 失败回复在契约 5 键之外附带 reason（本卡要求「status=failed + reason」）；成功回复严格 5 键。
     */
    private fun handleCreate(args: CreateArguments, reply: ChannelResult) {
        if (!isNativeLibraryLoaded()) {
            reply.success(
                createFailure(
                    NO_TEXTURE_ID, args.width, args.height, STATUS_NATIVE_UNAVAILABLE,
                    nativeLibraryLoadError() ?: "原生库未加载（loadLibrary 未成功，且无异常记录）",
                )
            )
            return
        }
        mainHandler.post {
            val producer = try {
                registry.createSurfaceProducer(TextureRegistry.SurfaceLifecycle.manual)
            } catch (t: Throwable) {
                reply.success(
                    createFailure(
                        NO_TEXTURE_ID, args.width, args.height, STATUS_FAILED,
                        "createSurfaceProducer 失败: " + describeThrowable(t),
                    )
                )
                null
            }
            if (producer == null) {
                return@post
            }
            val queued = try {
                workerHandler.post { finishCreateOnWorker(producer, args, reply) }
            } catch (t: Throwable) {
                false
            }
            if (!queued) {
                runCatching { producer.release() }
                reply.success(
                    createFailure(
                        NO_TEXTURE_ID, args.width, args.height, STATUS_FAILED,
                        "纹理工作线程已退出，无法完成创建",
                    )
                )
            }
        }
    }

    /** create 的 worker 段：所有 native 调用与 setSize / getSurface 都在这里串行执行。 */
    private fun finishCreateOnWorker(
        producer: TextureRegistry.SurfaceProducer,
        args: CreateArguments,
        reply: ChannelResult,
    ) {
        val textureId = producer.id()
        var handle = 0L
        try {
            attachSurfaceCallback(producer, textureId)
            producer.setSize(args.width, args.height)
            val surface = producer.getSurface()
            handle = nativeCreate(surface, args.width, args.height, args.dpr)
            if (handle == 0L) {
                releaseProducerQuietly(producer)
                reply.success(
                    createFailure(
                        textureId, args.width, args.height, STATUS_FAILED,
                        "nativeCreate 返回 0：原生侧拒绝创建离屏渲染目标",
                    )
                )
                return
            }
            val backend = detectBackend(handle)
            val entry = Entry(
                textureId = textureId,
                producer = producer,
                handle = handle,
                surface = surface,
                width = args.width,
                height = args.height,
                dpr = args.dpr,
                rotationQuarterTurns = args.rotationQuarterTurns,
                backend = backend,
            )
            entries[textureId] = entry
            if (args.rotationQuarterTurns != 0) {
                applyInitialRotation(entry)
            }
            reply.success(createSuccessMap(textureId, backend, args))
        } catch (t: UnsatisfiedLinkError) {
            if (handle != 0L) {
                runCatching { nativeDestroy(handle) }
            }
            releaseProducerQuietly(producer)
            reply.success(
                createFailure(
                    textureId, args.width, args.height, STATUS_ARCH_BLOCKED,
                    "nativeCreate 符号未解析（Kotlin 声明与 .so 导出不一致）: " + describeThrowable(t),
                )
            )
        } catch (t: Throwable) {
            if (handle != 0L) {
                runCatching { nativeDestroy(handle) }
            }
            releaseProducerQuietly(producer)
            reply.success(
                createFailure(
                    textureId, args.width, args.height, STATUS_FAILED,
                    "创建 Flutter 纹理失败: " + describeThrowable(t),
                )
            )
        }
    }

    /** 初始旋转：native 拒绝时把跟踪值退回 0（native 默认），并记录 lastError，不谎报已应用。 */
    private fun applyInitialRotation(entry: Entry) {
        val requested = entry.rotationQuarterTurns
        try {
            val applied = nativeSetRotation(entry.handle, requested)
            if (!applied) {
                entry.rotationQuarterTurns = 0
                entry.lastError = "初始旋转未应用：nativeSetRotation 拒绝 quarterTurns=" + requested
            }
        } catch (t: Throwable) {
            entry.rotationQuarterTurns = 0
            entry.lastError = "初始旋转应用失败: " + describeThrowable(t)
        }
    }

    /** 从原生侧读出真实 backend；读不到就退回 probe，最后退 none（不猜、不写死 opengl）。 */
    private fun detectBackend(handle: Long): String {
        val fromStatus = runCatching { nativeStatus(handle) }.getOrNull()
        val statusBackend = canonicalBackend(optionalText(parseJsonObject(fromStatus), "backend"))
        if (statusBackend != BACKEND_NONE) {
            cachedBackend = statusBackend
            return statusBackend
        }
        val fromProbe = runCatching { nativeProbe() }.getOrNull()
        val probeBackend = canonicalBackend(
            optionalText(parseJsonObject(fromProbe), "backend").ifEmpty { truncate(fromProbe) }
        )
        cachedBackend = probeBackend
        return probeBackend
    }

    private fun releaseProducerQuietly(producer: TextureRegistry.SurfaceProducer) {
        runCatching { producer.setCallback(null) }
        runCatching { producer.release() }
    }

    // ------------------------------------------------------------------
    // SurfaceProducer 回调（严禁抛异常）
    // ------------------------------------------------------------------

    /**
     * 注册 Surface 生命周期回调。回调线程由引擎决定（通常是平台主线程），
     * 这里只做「投递到 worker」，绝不直接碰 native 或 entry 表。
     */
    private fun attachSurfaceCallback(producer: TextureRegistry.SurfaceProducer, textureId: Long) {
        val callback = object : TextureRegistry.SurfaceProducer.Callback {
            override fun onSurfaceAvailable() {
                postWorkerSafely { entries[textureId]?.let { rebuildAfterSurfaceAvailable(it) } }
            }

            override fun onSurfaceCleanup() {
                postWorkerSafely { entries[textureId]?.let { markSurfaceCleanup(it) } }
            }
        }
        producer.setCallback(callback)
    }

    /** 回调专用投递：任何异常都必须就地吞掉（否则会在平台线程炸掉 Flutter 帧循环）。 */
    private fun postWorkerSafely(block: () -> Unit) {
        try {
            // 必须传 lambda 字面量（而非 () -> Unit 值）才能完成 Runnable 的 SAM 转换。
            workerHandler.post { block() }
        } catch (t: Throwable) {
            // 故意吞掉：回调里抛异常会打断引擎的 Surface 生命周期回调链。
        }
    }

    /**
     * onSurfaceAvailable：Surface 身份变了，必须重建（textureId 保持不变）。
     * 顺序：getSurface → nativeDestroy 旧 handle → nativeCreate → 重放旋转。
     */
    private fun rebuildAfterSurfaceAvailable(entry: Entry) {
        if (entry.released) {
            return
        }
        if (!isNativeLibraryLoaded()) {
            entry.status = STATUS_NATIVE_UNAVAILABLE
            entry.lastError = nativeLibraryLoadError() ?: "原生库未加载，无法重建 Surface"
            return
        }
        try {
            val surface = entry.producer.getSurface()
            val previousHandle = entry.handle
            entry.handle = 0L
            if (previousHandle != 0L) {
                runCatching { nativeDestroy(previousHandle) }
            }
            val handle = nativeCreate(surface, entry.width, entry.height, entry.dpr)
            if (handle == 0L) {
                entry.status = STATUS_FAILED
                entry.lastError = "onSurfaceAvailable 重建失败：nativeCreate 返回 0"
                return
            }
            entry.handle = handle
            entry.surface = surface
            entry.surfaceLost = false
            entry.status = STATUS_READY
            entry.lastError = ""
            if (entry.rotationQuarterTurns != 0) {
                val applied = runCatching { nativeSetRotation(handle, entry.rotationQuarterTurns) }.getOrDefault(false)
                if (!applied) {
                    entry.lastError = "onSurfaceAvailable 重建后 nativeSetRotation 返回 false"
                }
            }
        } catch (t: Throwable) {
            entry.status = STATUS_FAILED
            entry.lastError = "onSurfaceAvailable 重建失败: " + describeThrowable(t)
        }
    }

    /**
     * onSurfaceCleanup：引擎回收了 Surface。nativeDestroy + handle=0，status 保持 ready（纹理仍注册），
     * 但 firstFrame 与 publishTimestampNanos 归零 —— 重建后必须重新出帧，旧帧不得再算首帧。
     */
    private fun markSurfaceCleanup(entry: Entry) {
        if (entry.released) {
            return
        }
        val handle = entry.handle
        entry.handle = 0L
        if (handle != 0L) {
            runCatching { nativeDestroy(handle) }
        }
        entry.surfaceLost = true
        entry.firstFrameRendered = false
        entry.publishTimestampNanos = 0L
        entry.status = STATUS_READY
        entry.lastError = "Surface 已被 Flutter 引擎回收（onSurfaceCleanup），等待 onSurfaceAvailable 重建"
    }

    // ------------------------------------------------------------------
    // render / resize / setRotation / status / dispose / sendPointer / sendKey
    // ------------------------------------------------------------------

    /**
     * render：Dart 侧给出节拍（frameTimeNanos），本类只执行一次 nativeRender 并解析 JSON。
     * 不自建 Choreographer 循环（避免与 Flutter 帧循环争用 vsync）。
     *
     * 失败语义：
     * - handle == 0（surface 被回收 / 尚未就绪）→ rendered=false, status=failed（约定见类注释），
     *   entry.status 仍保持 ready，等待 onSurfaceAvailable 重建；
     * - JSON 非法或字段缺失 / 类型错 → rendered=false, status=failed，并写 entry.lastError。
     */
    private fun handleRender(args: RenderArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded()) {
            entry.lastError = nativeLibraryLoadError() ?: "原生库未加载"
            reply.success(renderStateMap(entry, rendered = false, status = STATUS_NATIVE_UNAVAILABLE))
            return
        }
        if (entry.handle == 0L) {
            entry.lastError = "surface 不可用（handle=0，等待 onSurfaceAvailable 重建）"
            reply.success(renderStateMap(entry, rendered = false, status = STATUS_FAILED))
            return
        }
        try {
            val raw = nativeRender(entry.handle, args.frameTimeNanos)
            val json = parseJsonObject(raw)
                ?: throw ProtocolViolationException("nativeRender 返回的不是 JSON 对象: " + truncate(raw))
            val state = parseNativeState(json)
            applyNativeState(entry, state)
            reply.success(
                mapOf<String, Any>(
                    "textureId" to entry.textureId,
                    "rendered" to state.rendered,
                    "frameSequence" to state.frameSequence,
                    "firstFrame" to state.firstFrameRendered,
                    "width" to entry.width,
                    "height" to entry.height,
                    "rotationQuarterTurns" to entry.rotationQuarterTurns,
                    "publishTimestampNanos" to state.publishTimestampNanos,
                    "status" to state.status,
                )
            )
        } catch (t: Throwable) {
            val message = "nativeRender 失败: " + describeThrowable(t)
            entry.status = STATUS_FAILED
            entry.lastError = message
            reply.success(renderStateMap(entry, rendered = false, status = STATUS_FAILED))
        }
    }

    /**
     * resize：先 producer.setSize（Flutter 侧分配新尺寸 buffer），再 getSurface。
     * 若 Surface 身份变化（ImageReaderSurfaceProducer 在 setSize 后新建 reader），必须
     * nativeDestroy 旧 handle 后 nativeCreate 新 Surface 并重放旋转；否则只需 nativeResize。
     */
    private fun handleResize(args: ResizeArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded()) {
            entry.lastError = nativeLibraryLoadError() ?: "原生库未加载"
            reply.success(sizeMap(entry))
            return
        }
        try {
            entry.producer.setSize(args.width, args.height)
            val surface = entry.producer.getSurface()
            entry.width = args.width
            entry.height = args.height
            entry.dpr = args.dpr
            if (entry.handle == 0L) {
                reply.success(sizeMap(entry))
                return
            }
            if (surface !== entry.surface) {
                val previousHandle = entry.handle
                entry.handle = 0L
                runCatching { nativeDestroy(previousHandle) }
                val rebuilt = nativeCreate(surface, args.width, args.height, args.dpr)
                if (rebuilt == 0L) {
                    entry.status = STATUS_FAILED
                    entry.lastError = "resize 后 nativeCreate 返回 0（Surface 身份已变，无法重建渲染目标）"
                    reply.success(sizeMap(entry))
                    return
                }
                entry.handle = rebuilt
                entry.surface = surface
                entry.surfaceLost = false
                entry.firstFrameRendered = false
                entry.publishTimestampNanos = 0L
                entry.status = STATUS_READY
                entry.lastError = ""
                if (entry.rotationQuarterTurns != 0) {
                    val applied = runCatching { nativeSetRotation(rebuilt, entry.rotationQuarterTurns) }.getOrDefault(false)
                    if (!applied) {
                        entry.lastError = "resize 重建后 nativeSetRotation 返回 false"
                    }
                }
            } else {
                nativeResize(entry.handle, args.width, args.height, args.dpr)
            }
            reply.success(sizeMap(entry))
        } catch (t: Throwable) {
            entry.status = STATUS_FAILED
            entry.lastError = "resize 失败: " + describeThrowable(t)
            reply.success(sizeMap(entry))
        }
    }

    /**
     * setRotation：native 返回 false 或抛异常时不改跟踪值（调用方看到的仍是真实生效值），
     * 只写 lastError —— 避免向 Dart 谎报旋转已生效。
     */
    private fun handleSetRotation(args: RotationArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded() || entry.handle == 0L) {
            entry.lastError = if (!isNativeLibraryLoaded()) {
                nativeLibraryLoadError() ?: "原生库未加载"
            } else {
                "surface 不可用（handle=0），旋转未下发"
            }
            reply.success(rotationMap(entry))
            return
        }
        try {
            val applied = nativeSetRotation(entry.handle, args.quarterTurns)
            if (applied) {
                entry.rotationQuarterTurns = args.quarterTurns
                entry.lastError = ""
            } else {
                entry.lastError = "nativeSetRotation 拒绝 quarterTurns=" + args.quarterTurns
            }
            reply.success(rotationMap(entry))
        } catch (t: Throwable) {
            entry.lastError = "nativeSetRotation 失败: " + describeThrowable(t)
            reply.success(rotationMap(entry))
        }
    }

    /** status：以 native 上报为准刷新 entry；handle == 0 时返回桥内跟踪值（如实反映 surfaceLost）。 */
    private fun handleStatus(args: TextureIdArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded()) {
            reply.success(statusMap(entry, STATUS_NATIVE_UNAVAILABLE, nativeLibraryLoadError() ?: "原生库未加载"))
            return
        }
        if (entry.handle == 0L) {
            reply.success(statusMap(entry, entry.status, entry.lastError))
            return
        }
        try {
            val raw = nativeStatus(entry.handle)
            val json = parseJsonObject(raw)
                ?: throw ProtocolViolationException("nativeStatus 返回的不是 JSON 对象: " + truncate(raw))
            val state = parseNativeState(json)
            applyNativeState(entry, state)
            reply.success(statusMap(entry, state.status, state.lastError))
        } catch (t: Throwable) {
            val message = "nativeStatus 失败: " + describeThrowable(t)
            entry.status = STATUS_FAILED
            entry.lastError = message
            reply.success(statusMap(entry, STATUS_FAILED, message))
        }
    }

    /**
     * dispose：未知 textureId 属非法参数（重复 dispose 也会被 requireEntry 拒绝），
     * 因此 released=true 只会出现一次。nativeDestroy 在 worker 上完成，producer.release() 回主线程，
     * 回复在 release 真正结束后才发出（不提前宣布成功）。
     */
    private fun handleDispose(args: TextureIdArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        entries.remove(args.textureId)
        entry.released = true
        val handle = entry.handle
        entry.handle = 0L
        if (handle != 0L) {
            runCatching { nativeDestroy(handle) }
        }
        runCatching { entry.producer.setCallback(null) }
        entry.status = STATUS_RELEASED
        entry.firstFrameRendered = false
        entry.publishTimestampNanos = 0L
        mainHandler.post {
            val released = runCatching { entry.producer.release() }.isSuccess
            if (!released) {
                entry.lastError = "producer.release() 抛异常：纹理可能仍注册在 Flutter 引擎侧"
            }
            reply.success(mapOf<String, Any>("released" to released))
        }
    }

    /** sendPointer：库 / surface 不可用时 accepted=false（不做假转发）。 */
    private fun handleSendPointer(args: PointerArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded() || entry.handle == 0L) {
            entry.lastError = if (!isNativeLibraryLoaded()) {
                nativeLibraryLoadError() ?: "原生库未加载"
            } else {
                "surface 不可用（handle=0），指针事件未转发"
            }
            reply.success(mapOf<String, Any>("accepted" to false))
            return
        }
        try {
            val accepted = nativeSendPointer(entry.handle, args.x, args.y, args.phase, args.buttons)
            if (!accepted) {
                entry.lastError = "nativeSendPointer 拒绝（phase=" + args.phase + ", buttons=" + args.buttons + "）"
            }
            reply.success(mapOf<String, Any>("accepted" to accepted))
        } catch (t: Throwable) {
            entry.lastError = "nativeSendPointer 失败: " + describeThrowable(t)
            reply.success(mapOf<String, Any>("accepted" to false))
        }
    }

    /** sendKey：同上，库 / surface 不可用时 accepted=false。 */
    private fun handleSendKey(args: KeyArguments, reply: ChannelResult) {
        val entry = requireEntry(args.textureId)
        if (!isNativeLibraryLoaded() || entry.handle == 0L) {
            entry.lastError = if (!isNativeLibraryLoaded()) {
                nativeLibraryLoadError() ?: "原生库未加载"
            } else {
                "surface 不可用（handle=0），按键事件未转发"
            }
            reply.success(mapOf<String, Any>("accepted" to false))
            return
        }
        try {
            val accepted = nativeSendKey(entry.handle, args.key, args.down, args.repeat)
            if (!accepted) {
                entry.lastError = "nativeSendKey 拒绝（key=" + args.key + ", down=" + args.down + "）"
            }
            reply.success(mapOf<String, Any>("accepted" to accepted))
        } catch (t: Throwable) {
            entry.lastError = "nativeSendKey 失败: " + describeThrowable(t)
            reply.success(mapOf<String, Any>("accepted" to false))
        }
    }

    private fun requireEntry(textureId: Long): Entry {
        val entry = entries[textureId]
        if (entry == null) {
            throw InvalidArgumentsException("未知 textureId=" + textureId + "（未 create 或已 dispose）")
        }
        if (entry.released) {
            throw InvalidArgumentsException("textureId=" + textureId + " 已释放（dispose 之后不能再使用）")
        }
        return entry
    }

    // ------------------------------------------------------------------
    // 回复 Map 构造（键名逐字对齐冻结契约）
    // ------------------------------------------------------------------

    private fun createSuccessMap(textureId: Long, backend: String, args: CreateArguments): Map<String, Any> =
        mapOf<String, Any>(
            "textureId" to textureId,
            "status" to STATUS_READY,
            "backend" to backend,
            "width" to args.width,
            "height" to args.height,
        )

    private fun createFailure(
        textureId: Long,
        width: Int,
        height: Int,
        status: String,
        reason: String,
    ): Map<String, Any> =
        mapOf<String, Any>(
            "textureId" to textureId,
            "status" to status,
            "backend" to cachedBackend,
            "width" to width,
            "height" to height,
            "reason" to reason,
        )

    private fun renderStateMap(entry: Entry, rendered: Boolean, status: String): Map<String, Any> =
        mapOf<String, Any>(
            "textureId" to entry.textureId,
            "rendered" to rendered,
            "frameSequence" to entry.frameSequence,
            "firstFrame" to entry.firstFrameRendered,
            "width" to entry.width,
            "height" to entry.height,
            "rotationQuarterTurns" to entry.rotationQuarterTurns,
            "publishTimestampNanos" to entry.publishTimestampNanos,
            "status" to status,
        )

    private fun sizeMap(entry: Entry): Map<String, Any> =
        mapOf<String, Any>(
            "width" to entry.width,
            "height" to entry.height,
        )

    private fun rotationMap(entry: Entry): Map<String, Any> =
        mapOf<String, Any>("rotationQuarterTurns" to entry.rotationQuarterTurns)

    private fun statusMap(entry: Entry, status: String, lastError: String): Map<String, Any> =
        mapOf<String, Any>(
            "status" to status,
            "textureId" to entry.textureId,
            "frameSequence" to entry.frameSequence,
            "firstFrameRendered" to entry.firstFrameRendered,
            "width" to entry.width,
            "height" to entry.height,
            "rotationQuarterTurns" to entry.rotationQuarterTurns,
            "backend" to entry.backend,
            "lastError" to lastError,
            "publishTimestampNanos" to entry.publishTimestampNanos,
        )

    // ------------------------------------------------------------------
    // 原生 JSON 解析：字段缺失 / 类型错 → ProtocolViolationException → status=failed
    // ------------------------------------------------------------------

    private fun parseJsonObject(raw: String?): JSONObject? {
        if (raw.isNullOrBlank()) {
            return null
        }
        return try {
            JSONObject(raw)
        } catch (e: JSONException) {
            null
        }
    }

    private fun parseNativeState(json: JSONObject): NativeState {
        val rendered = json.requireBoolean(FIELD_RENDERED)
        val frameSequence = json.requireLong(FIELD_FRAME_SEQUENCE)
        val firstFrameRendered = json.requireBoolean(FIELD_FIRST_FRAME_RENDERED)
        val width = json.requireInt(FIELD_WIDTH)
        val height = json.requireInt(FIELD_HEIGHT)
        val rotationQuarterTurns = json.requireInt(FIELD_ROTATION_QUARTER_TURNS)
        val publishTimestampNanos = json.requireLong(FIELD_PUBLISH_TIMESTAMP_NANOS)
        val statusToken = json.requireString(FIELD_STATUS)
        val status = canonicalStatus(statusToken)
            ?: throw ProtocolViolationException("原生 JSON 字段 status 不在冻结枚举内: " + truncate(statusToken))
        val lastError = json.optString(FIELD_LAST_ERROR, "")
        val backend = canonicalBackend(json.optString(FIELD_BACKEND, ""))
        return NativeState(
            rendered = rendered,
            frameSequence = frameSequence,
            firstFrameRendered = firstFrameRendered,
            width = width,
            height = height,
            rotationQuarterTurns = rotationQuarterTurns,
            publishTimestampNanos = publishTimestampNanos,
            status = status,
            lastError = lastError,
            backend = backend,
        )
    }

    private fun JSONObject.requireNumber(key: String): Number {
        if (!has(key) || isNull(key)) {
            throw ProtocolViolationException("原生 JSON 缺少字段 " + key)
        }
        val value = get(key)
        val number = value as? Number
        return number ?: throw ProtocolViolationException("原生 JSON 字段 " + key + " 类型应为 number，实际 " + value.javaClass.simpleName)
    }

    private fun JSONObject.requireInt(key: String): Int {
        val number = requireNumber(key)
        val asDouble = number.toDouble()
        if (asDouble.isNaN() || asDouble.isInfinite() || asDouble != floor(asDouble)) {
            throw ProtocolViolationException("原生 JSON 字段 " + key + " 应为整数，实际 " + asDouble)
        }
        if (asDouble < Int.MIN_VALUE.toDouble() || asDouble > Int.MAX_VALUE.toDouble()) {
            throw ProtocolViolationException("原生 JSON 字段 " + key + " 超出 32 位整数范围: " + asDouble)
        }
        return asDouble.toInt()
    }

    private fun JSONObject.requireLong(key: String): Long {
        val number = requireNumber(key)
        if (number is Long || number is Int) {
            return number.toLong()
        }
        val asDouble = number.toDouble()
        if (asDouble.isNaN() || asDouble.isInfinite() || asDouble != floor(asDouble)) {
            throw ProtocolViolationException("原生 JSON 字段 " + key + " 应为整数，实际 " + asDouble)
        }
        return asDouble.toLong()
    }

    private fun JSONObject.requireBoolean(key: String): Boolean {
        if (!has(key) || isNull(key)) {
            throw ProtocolViolationException("原生 JSON 缺少字段 " + key)
        }
        val value = get(key)
        val boolean = value as? Boolean
        return boolean ?: throw ProtocolViolationException("原生 JSON 字段 " + key + " 类型应为 bool，实际 " + value.javaClass.simpleName)
    }

    private fun JSONObject.requireString(key: String): String {
        if (!has(key) || isNull(key)) {
            throw ProtocolViolationException("原生 JSON 缺少字段 " + key)
        }
        val value = get(key)
        val text = value as? String
        return text ?: throw ProtocolViolationException("原生 JSON 字段 " + key + " 类型应为 string，实际 " + value.javaClass.simpleName)
    }

    private fun applyNativeState(entry: Entry, state: NativeState) {
        entry.status = state.status
        entry.lastError = state.lastError
        entry.frameSequence = state.frameSequence
        entry.firstFrameRendered = state.firstFrameRendered
        entry.publishTimestampNanos = state.publishTimestampNanos
        if (state.width > 0) {
            entry.width = state.width
        }
        if (state.height > 0) {
            entry.height = state.height
        }
        if (state.rotationQuarterTurns in 0..3) {
            entry.rotationQuarterTurns = state.rotationQuarterTurns
        }
        if (state.backend != BACKEND_NONE) {
            entry.backend = state.backend
            cachedBackend = state.backend
        }
    }

    // ------------------------------------------------------------------
    // 枚举归一化与小工具
    // ------------------------------------------------------------------

    /** 归一化 status；无法识别返回 null（调用方决定降级为 failed）。 */
    private fun canonicalStatus(raw: String?): String? {
        return when (normalizeToken(raw)) {
            "ready" -> STATUS_READY
            "nativeunavailable" -> STATUS_NATIVE_UNAVAILABLE
            "archblocked" -> STATUS_ARCH_BLOCKED
            "deviceblocked" -> STATUS_DEVICE_BLOCKED
            "failed" -> STATUS_FAILED
            "released" -> STATUS_RELEASED
            else -> null
        }
    }

    /** 归一化 backend；无法识别返回 none（绝不猜测 opengl / vulkan）。 */
    private fun canonicalBackend(raw: String?): String {
        return when (normalizeToken(raw)) {
            "opengl", "gl", "gles", "gles2", "gles3" -> BACKEND_OPENGL
            "vulkan", "vk" -> BACKEND_VULKAN
            else -> BACKEND_NONE
        }
    }

    private fun normalizeToken(raw: String?): String {
        val text = raw?.trim()?.lowercase().orEmpty()
        if (text.isEmpty()) {
            return ""
        }
        val builder = StringBuilder(text.length)
        for (ch in text) {
            if (ch != '_' && ch != '-' && ch != ' ') {
                builder.append(ch)
            }
        }
        return builder.toString()
    }

    /** 读可选字符串字段：null / JSONObject.NULL / 空串一律返回 ""。 */
    private fun optionalText(json: JSONObject?, key: String): String {
        if (json == null || !json.has(key) || json.isNull(key)) {
            return ""
        }
        val raw = json.optString(key, "")
        val text = raw.trim()
        return if (text == "null") "" else text
    }

    private fun truncate(text: String?, limit: Int = 160): String {
        val value = text?.trim().orEmpty()
        return if (value.length <= limit) value else value.substring(0, limit) + "..."
    }

    // ------------------------------------------------------------------
    // 内部类型
    // ------------------------------------------------------------------

    /** MethodChannel.Result 的幂等包装：同一个 reply 只允许 success / error 之一落地一次。 */
    private class ChannelResult(private val result: MethodChannel.Result) {
        @Volatile
        private var replied: Boolean = false

        fun success(value: Any?) {
            if (replied) {
                return
            }
            replied = true
            result.success(value)
        }

        fun error(code: String, message: String?, details: Any?) {
            if (replied) {
                return
            }
            replied = true
            result.error(code, message, details)
        }

        fun notImplemented() {
            if (replied) {
                return
            }
            replied = true
            result.notImplemented()
        }
    }

    /** 非法参数：dispatch 统一转成 result.error("invalid_argument", ...)。 */
    private class InvalidArgumentsException(message: String) : Exception(message)

    /** 原生侧返回的 JSON 违反冻结契约（字段缺失 / 类型错 / 枚举越界）。 */
    private class ProtocolViolationException(message: String) : Exception(message)

    private data class CreateArguments(
        val width: Int,
        val height: Int,
        val dpr: Float,
        val rotationQuarterTurns: Int,
    )

    private data class RenderArguments(val textureId: Long, val frameTimeNanos: Long)

    private data class ResizeArguments(val textureId: Long, val width: Int, val height: Int, val dpr: Float)

    private data class RotationArguments(val textureId: Long, val quarterTurns: Int)

    private data class TextureIdArguments(val textureId: Long)

    private data class PointerArguments(
        val textureId: Long,
        val x: Float,
        val y: Float,
        val phase: Int,
        val buttons: Int,
    )

    private data class KeyArguments(val textureId: Long, val key: Int, val down: Boolean, val repeat: Boolean)

    /** nativeRender / nativeStatus 返回的 JSON 映射（键名与 C++ 侧逐字一致）。 */
    private data class NativeState(
        val rendered: Boolean,
        val frameSequence: Long,
        val firstFrameRendered: Boolean,
        val width: Int,
        val height: Int,
        val rotationQuarterTurns: Int,
        val publishTimestampNanos: Long,
        val status: String,
        val lastError: String,
        val backend: String,
    )

    /**
     * 一个 Flutter texture 的全部可变状态；只在 worker 线程读写。
     * textureId 与 producer 恒定，其余字段随 native 上报同步。
     */
    private class Entry(
        val textureId: Long,
        val producer: TextureRegistry.SurfaceProducer,
        var handle: Long,
        var surface: Surface,
        var width: Int,
        var height: Int,
        var dpr: Float,
        var rotationQuarterTurns: Int,
        var backend: String,
    ) {
        /** 初值 = STATUS_READY（"ready"）。 */
        var status: String = "ready"
        var lastError: String = ""
        var frameSequence: Long = 0L
        var firstFrameRendered: Boolean = false
        var publishTimestampNanos: Long = 0L
        var surfaceLost: Boolean = false
        var released: Boolean = false
    }
}
