/// Flutter HUD port of the Qt landscape modal "provider", reproduced 1:1.
///
/// One-to-one port of NativeHud::modalDraw's generic (full-modal) layer plus its
/// provider branch, and of NativeHud::platformChoices / NativeHud::platformPanel
/// (Qt/src/NativeHudModal.cpp:80-257, branch at :212-213, :259-306).
///
/// This library is self-contained: it imports nothing (only dart:core, implicitly) and
/// it emits exactly the command/hit lists the Qt HUD emits while modal == "provider".
/// Every coordinate is a Qt landscape design-stage pixel (1920x1080); no portrait pixel
/// value is invented anywhere. The injected [ProviderModalRectHook] is the only
/// placement seam and its default is the identity.
///
/// Qt evidence for every number, string and command in this file:
///
/// * Envelope: Qt/src/NativeHudModal.cpp:83-84 (save, alpha(motion.opacity)), scrim
///   :162-165, translate :166, panel fill :171-172, hits reset :173,
///   m_modalControls = true :174, m_modalControls = false + restore :255-256.
/// * Bounds: Qt/src/NativeHud.cpp:153,157,158 - modalWidth = min(1260, width - 100),
///   left = (width - modalWidth) / 2, rect {left, 122, modalWidth, 836}.
/// * Header: category default "MUSIC DIRECTORY" :188, category line :198, back button
///   :199-200, title/subtitle :201-202; literals from the maps at :27
///   ("MUSIC PLATFORM") and :53 ("直接选择音乐平台 / 各平台账号独立保存").
/// * Body: platformPanel :292-306, platformChoices :259-291, provider table :12-24
///   including the !PlatformFeatures::LocalMusic removal at :20-22.
/// * Primitives: Qt/src/NativeHud.cpp:10-15 (ink), :19-36 (save/restore/alpha/
///   translate), :37-39 (fill), :40-43 (text), :48-76 (fit), :77-79 (limited),
///   :102-109 (hit), :110-120 (button), :125-129 (rule).
/// * Wrap: Qt/src/Glyphs.cpp:350-402 (Glyphs::wrap); its non-layout branch (:381-398)
///   is the default implemented here.
/// * Actions/keys: Qt/src/NativeHudController.cpp:508-524 (open and provider:<id>),
///   :64-84 (openModal guards, none of which reject provider), :913-925 (Escape and
///   the swallow-all rule).
///
/// All rects and text origins are mapped through [ProviderModalRectHook] exactly once
/// each, which models the single stage transform Qt's renderer applies to the whole
/// command stream: under the identity default every number below is the raw Qt stage
/// pixel, and under a portrait hook the whole panel, cards included, transforms
/// coherently instead of having its interior re-authored from the panel origin.
library;

/// Measures one text run exactly like Qt Glyphs::width(text, size, weight, tracking)
/// (Qt/src/Glyphs.cpp:286-311).
///
/// [tracking] is threaded through because text commands carry it
/// (Qt/src/NativeHud.cpp:40-43), while fit measures with the value it is handed: Qt's
/// fit passes tracking 0 (Qt/src/NativeHud.cpp:57). No glyph width is ever hardcoded
/// in this file.
typedef ProviderModalMeasureText = double Function(
  String text,
  double size,
  String? weight,
  double tracking,
);

/// Wraps one text run like Qt Glyphs::wrap(text, limit, size, weight)
/// (Qt/src/Glyphs.cpp:350-402).
///
/// The default installed by [ProviderModal] is [codeUnitWrap], the port of Qt's
/// non-layout branch (:381-398), which is the branch Qt takes for the bundled
/// Latin/Han detail strings. A host whose font needs Qt's layout branch
/// (Glyphs::needsLayout, Qt/src/Glyphs.cpp:109-139: combining marks, surrogate pairs,
/// bidi text, or a glyph the bundled fonts lack) must inject its own wrapper, because
/// that branch depends on font-internal state this library cannot observe.
typedef ProviderModalWrapText = List<String> Function(
  String text,
  double limit,
  double size,
  String weight,
);

/// Maps one Qt stage rect to the rect the host actually paints, in this order:
/// [x, y, width, height].
///
/// The default is the identity, so the 1920x1080 Qt stage numbers stay exact. The hook
/// exists for portrait hosts, which must not be served invented pixels. Text origins
/// are mapped as the zero-size rectangle (x, y, 0, 0), so an affine hook maps them to
/// the transformed origin.
typedef ProviderModalRectHook = List<double> Function(
  double x,
  double y,
  double w,
  double h,
);

List<double> _identityRect(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

List<double> _mapRect(
    ProviderModalRectHook hook, double x, double y, double w, double h) {
  final List<double> mapped = hook(x, y, w, h);
  if (mapped.length != 4) {
    throw ArgumentError.value(
        mapped, 'rectHook', 'must return exactly [x, y, width, height]');
  }
  return mapped;
}

double _min(double a, double b) => a < b ? a : b;

int _minInt(int a, int b) => a < b ? a : b;

double _clamp(double value, double lower, double upper) {
  if (value < lower) {
    return lower;
  }
  if (value > upper) {
    return upper;
  }
  return value;
}

/// Qt's anonymous-namespace bezier solver (Qt/src/UiMotion.cpp:7-22), copied
/// operation for operation: 24 bisection rounds on the x component with a strict
/// less-than comparison, then the y component at the bisected parameter.
double _bezier(double x, double x1, double y1, double x2, double y2) {
  double component(double t, double a, double b) =>
      3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
  double lower = 0;
  double upper = 1;
  for (int i = 0; i < 24; i++) {
    final double t = (lower + upper) / 2;
    if (component(t, x1, x2) < x) {
      lower = t;
    } else {
      upper = t;
    }
  }
  return component((lower + upper) / 2, y1, y2);
}

/// Port of Glyphs::wrap's non-layout branch (Qt/src/Glyphs.cpp:381-398), expressed
/// through the injected [ProviderModalMeasureText].
///
/// Qt walks UTF-16 code units there (a QChar range over the string), measures each
/// single unit with width(single char, size, weight), accumulates the running length,
/// breaks before a unit that would overflow, and always appends the final, possibly
/// empty, line. Dart's String.codeUnits iterates the same UTF-16 units and re-joining
/// them rebuilds the input, so this is the same partition. The newline test is the
/// literal code unit 0x0A, which is what Qt compares the QChar against.
ProviderModalWrapText codeUnitWrap(ProviderModalMeasureText measureText) {
  return (String text, double limit, double size, String weight) {
    final List<String> lines = <String>[];
    String line = '';
    double length = 0;
    for (final int unit in text.codeUnits) {
      if (unit == 0x0A) {
        lines.add(line);
        line = '';
        length = 0;
        continue;
      }
      final String ch = String.fromCharCode(unit);
      final double advance = measureText(ch, size, weight, 0);
      if (line.isNotEmpty && length + advance > limit) {
        lines.add(line);
        line = '';
        length = 0;
      }
      line += ch;
      length += advance;
    }
    lines.add(line);
    return lines;
  };
}

/// Qt UiMotion::SurfaceMotion (Qt/src/UiMotion.h:24-42, Qt/src/UiMotion.cpp:86-120) for
/// the modal surface only.
///
/// The field defaults are the Qt member initialisers: opacity 0, offset 12, duration 0
/// (Qt/src/UiMotion.h:31-33), so a fresh instance is already "finished" and
/// offset-invisible; the host calls [set] to enter.
class ProviderModalMotion {
  ProviderModalMotion();

  /// Current surface opacity, lerped from the value captured by [set].
  double opacity = 0;

  /// Current vertical offset in stage pixels; starts at the Qt literal 12.
  double offset = 12;

  /// Remaining animation length in seconds; 0 means settled.
  double duration = 0;

  double _fromOpacity = 0;
  double _fromOffset = 12;
  double _targetOpacity = 0;
  double _targetOffset = 12;
  double _start = 0;
  bool _entering = true;

  /// Qt/src/UiMotion.h:28-30: finished() is exactly duration == 0, and sample collapses
  /// the duration to 0 once progress reaches 1 (UiMotion.cpp:95-97), so a completed
  /// transition reports finished while a freshly retargeted one does not.
  bool get finished => duration == 0;

  /// UiMotion::sample (Qt/src/UiMotion.cpp:86-98). A zero duration returns
  /// immediately, which is what makes the reduced-motion path snap.
  void sample(double time) {
    if (duration <= 0) {
      return;
    }
    final double progress = _clamp((time - _start) / duration, 0, 1);
    final double amount = _bezier(
        progress,
        _entering ? 0.22 : 0.4,
        _entering ? 1 : 0,
        _entering ? 0.36 : 1,
        1);
    opacity = _fromOpacity + (_targetOpacity - _fromOpacity) * amount;
    offset = _fromOffset + (_targetOffset - _fromOffset) * amount;
    if (progress >= 1) {
      duration = 0;
    }
  }

  /// UiMotion::set (Qt/src/UiMotion.cpp:100-120): sample the running transition first
  /// so a fast open/close continues from the current opacity and offset, then retarget.
  /// Entering: opacity 1 / offset 0 / 0.3 s. Leaving: opacity 0 / offset 8 / 0.2 s.
  /// Reduced motion: 0 s and an instant snap.
  void set({required bool shown, required double time, bool reduced = false}) {
    sample(time);
    _fromOpacity = opacity;
    _fromOffset = offset;
    _targetOpacity = shown ? 1 : 0;
    _targetOffset = shown ? 0 : 8;
    _entering = shown;
    _start = time;
    if (reduced) {
      duration = 0;
    } else if (shown) {
      duration = 0.3;
    } else {
      duration = 0.2;
    }
    if (reduced) {
      opacity = _targetOpacity;
      offset = _targetOffset;
    }
  }
}

/// One row of the Qt provider table (Qt/src/NativeHudModal.cpp:6-11).
///
/// The four strings are copied verbatim from the providers initialiser
/// (Qt/src/NativeHudModal.cpp:12-19). [id] is what the hit action and
/// Host::hasCredential use; [name] is the display name and also the hit label (:270);
/// [label] the uppercase caption (:274); [detail] the wrapped description (:277-280).
class ProviderModalCard {
  const ProviderModalCard({
    required this.id,
    required this.name,
    required this.label,
    required this.detail,
  });

  /// Provider id: siren, netease, qq, kugou, local.
  final String id;

  /// Display name, e.g. 塞壬唱片.
  final String name;

  /// Uppercase caption, e.g. MONSTER SIREN.
  final String label;

  /// Card description, wrapped to cardWidth - 32 at size 14, at most three rows.
  final String detail;
}

/// The Qt provider table (Qt/src/NativeHudModal.cpp:12-24).
class ProviderModalCatalog {
  const ProviderModalCatalog._();

  /// All five rows in Qt order, before the platform-feature filter.
  static const List<ProviderModalCard> all = <ProviderModalCard>[
    ProviderModalCard(
        id: 'siren', name: '塞壬唱片', label: 'MONSTER SIREN', detail: '官网曲库'), // :14
    ProviderModalCard(
        id: 'netease',
        name: '网易云音乐',
        label: 'NETEASE',
        detail: '搜索 · 个人音乐 · 推荐 · 播放 · 歌单编辑'), // :15
    ProviderModalCard(
        id: 'qq',
        name: 'QQ 音乐',
        label: 'QQ MUSIC',
        detail: '全类搜索 · 每日推荐 · 个人音乐 · 歌单编辑'), // :16
    ProviderModalCard(
        id: 'kugou',
        name: '酷狗音乐',
        label: 'KUGOU',
        detail: '标准版 / 概念版 · 个人歌单 · 推荐与榜单 · 播放'), // :17
    ProviderModalCard(
        id: 'local',
        name: '本地音乐',
        label: 'LOCAL',
        detail: '文件夹管理 · 导入与索引 · 本地检索 · 播放'), // :18
  ];

  /// providers as built at static-init time (Qt/src/NativeHudModal.cpp:12-24): the last
  /// row, local, is dropped when PlatformFeatures::LocalMusic is false (:20-22). Mobile
  /// builds have LocalMusic == false (Qt/src/PlatformFeatures.h:10), desktop builds
  /// true (:15).
  static List<ProviderModalCard> forFeatures({required bool localMusic}) {
    final List<ProviderModalCard> rows = List<ProviderModalCard>.of(all);
    if (!localMusic) {
      rows.removeLast();
    }
    return rows;
  }
}

/// Immutable result of [ProviderModal.build]: the Qt commands and hits arrays, in draw
/// order.
class ProviderModalFrame {
  const ProviderModalFrame({required this.commands, required this.hits});

  /// Qt op() shapes: save, alpha, translate, fill and text commands.
  final List<List<Object?>> commands;

  /// Six fields per hit, in this order: x, y, width, height, action, label
  /// (Qt/src/NativeHud.cpp:102-109).
  final List<List<Object?>> hits;
}

/// Every action string this modal can emit or receive, copied verbatim from Qt.
///
/// * [open] - the action that opens it: if (value == "provider") openModal("provider")
///   (Qt/src/NativeHudController.cpp:508-511).
/// * [providerPrefix] + id - one per drawn card (Qt/src/NativeHudModal.cpp:270).
/// * [login] - the login button of the non-local, non-siren branch (:304).
/// * [discover] - the folder-management button of the local branch (:300).
/// * [closeModal] - the header back button (:199-200), also what Escape maps to while
///   this modal is open (Qt/src/NativeHudController.cpp:913-921).
class ProviderModalActionTable {
  const ProviderModalActionTable._();

  static const String open = 'provider';
  static const String providerPrefix = 'provider:';
  static const String login = 'music:login';
  static const String discover = 'discover';
  static const String closeModal = 'close-modal';

  /// The string "provider:" + id (Qt/src/NativeHudModal.cpp:270).
  static String select(String id) => 'provider:' + id;

  /// The host's ordered reaction to provider:<id>
  /// (Qt/src/NativeHudController.cpp:512-524), recorded so the order cannot drift:
  ///
  /// 1. if (music.provider != provider) - a re-tap of the current card does nothing;
  /// 2. ++m_searchGeneration;
  /// 3. activeGroup.clear();
  /// 4. query.clear();
  /// 5. listOffset = 0;
  /// 6. resetResultViews();
  /// 7. trackOffset = 0;
  /// 8. music.switchProvider(provider).
  ///
  /// The modal is NOT closed: Qt never calls closeModal() on this action and none of
  /// the eight steps touches modal or closing. This port therefore emits no close
  /// action for a card tap; only the back button and Escape do.
  static const List<String> selectSequence = <String>[
    'searchGeneration++',
    'activeGroup.clear',
    'query.clear',
    'listOffset=0',
    'resetResultViews',
    'trackOffset=0',
    'switchProvider',
  ];

  /// Step 1 of [selectSequence] (Qt/src/NativeHudController.cpp:514).
  static bool shouldSwitch(String current, String id) => current != id;

  /// Qt keyboard table restricted to this open modal
  /// (Qt/src/NativeHudController.cpp:913-925): the modal is non-empty and is not
  /// desktop-lyrics, so Escape is close-modal. Arrow scrolling exists only for settings
  /// and desktop-lyrics (:891-904); every other key is swallowed while a modal is open
  /// (:923-925). Qt has no Tab focus ring, so none is fabricated here.
  static const Map<String, String> keyActions = <String, String>{
    'Escape': closeModal,
  };

  /// The single key action this modal resolves (Qt/src/NativeHudController.cpp:919).
  static const String escapeAction = closeModal;
}

/// The Qt landscape modal provider: "MUSIC PLATFORM" / "直接选择音乐平台 /
/// 各平台账号独立保存".
///
/// Opened by the provider action (Qt/src/NativeHudController.cpp:508-511) through
/// openModal("provider"), which none of the open guards reject: the guard list at
/// :66-78 covers login, quality, playlist-picker, playlist-form and the discover
/// remaps only, so the panel is reachable for every provider, including local and
/// siren.
///
/// Nothing here mutates: opacity, offset, closing, dark, reduced and every domain
/// value arrive from the host.
class ProviderModal {
  ProviderModal({
    required this.width,
    required this.dark,
    required this.reduced,
    required this.closing,
    required this.search,
    required this.opacity,
    required this.offset,
    required this.provider,
    required this.measureText,
    this.isLocal = false,
    this.isSiren = false,
    this.providerName = '',
    this.credentials = const <String>{},
    this.platformFeaturesLocalMusic = true,
    this.cardExpanded = true,
    ProviderModalWrapText? wrapText,
    ProviderModalRectHook? rectHook,
  })  : wrapText = wrapText ?? codeUnitWrap(measureText),
        rectHook = rectHook ?? _identityRect;

  /// Qt stage width in pixels (NativeHud::width, Qt/src/NativeHud.cpp:149,240).
  final double width;

  /// Qt dark theme flag; selects every colour below.
  final bool dark;

  /// Reduced-motion preference. It only shortens [ProviderModalMotion]
  /// (Qt/src/UiMotion.cpp:109-119); modalDraw never branches on it, so the frame is
  /// identical either way.
  final bool reduced;

  /// The host is running the close curve. Qt keeps painting the same panel until
  /// closing && motion.finished() and only then clears the modal
  /// (Qt/src/NativeHud.cpp:262-266), so [build] stays byte-identical either way.
  final bool closing;

  /// Mirrors Qt's local const bool search = (modal == "search")
  /// (Qt/src/NativeHudModal.cpp:162). Only the scrim alpha depends on it here; a
  /// provider modal is never search, so it is false in real use and is injected only to
  /// keep the shared formula exact.
  final bool search;

  /// Current surface opacity, i.e. motion.opacity (Qt/src/NativeHudModal.cpp:84).
  final double opacity;

  /// Current surface offset, i.e. motion.offset (Qt/src/NativeHudModal.cpp:166).
  final double offset;

  /// music.provider: the current provider id. Drives the selected card
  /// (Qt/src/NativeHudModal.cpp:265) and nothing else in this panel.
  final String provider;

  /// MusicLibrary::isLocal() is provider == "local" (Qt/src/MusicLibrary.h:45-47);
  /// selects the 文件夹管理 button (Qt/src/NativeHudModal.cpp:299-300).
  final bool isLocal;

  /// MusicLibrary::isSiren() is provider == "siren" (Qt/src/MusicLibrary.h:48-50);
  /// selects the plain 塞壬唱片官网曲库 text (Qt/src/NativeHudModal.cpp:301-302).
  final bool isSiren;

  /// MusicLibrary::providerName() (Qt/src/MusicLibrary.cpp:106-111), appended to the
  /// login button label (Qt/src/NativeHudModal.cpp:304). Injected verbatim; the kugou
  /// with lite edition rule stays in the domain layer.
  final String providerName;

  /// Host::hasCredential(id) answers (Qt/src/NativeHudModal.cpp:281,
  /// Qt/src/Host.cpp:541), as the set of ids whose credential is stored. Qt asks per
  /// card before choosing the note; set membership is the same predicate.
  final Set<String> credentials;

  /// PlatformFeatures::LocalMusic (Qt/src/PlatformFeatures.h:10,15). False drops the
  /// last table row (Qt/src/NativeHudModal.cpp:20-22), which recomputes the card width
  /// for the remaining cards.
  final bool platformFeaturesLocalMusic;

  /// NativeHud::platformChoices's expanded argument (Qt/src/NativeHud.h:312,
  /// Qt/src/NativeHudModal.cpp:259). Qt's only call site passes true (:294), which is
  /// the default here too; the inline 66 of the compact branch (:266) stays reachable
  /// through this flag instead of being dead code, and it changes nothing unless a host
  /// asks for the compact row list.
  final bool cardExpanded;

  /// Injected text measurement used by fit, limited and the button refit.
  final ProviderModalMeasureText measureText;

  /// Injected line wrapper for the expanded card details; defaults to [codeUnitWrap]
  /// over [measureText].
  final ProviderModalWrapText wrapText;

  /// Portrait placement seam; identity by default (see [ProviderModalRectHook]).
  final ProviderModalRectHook rectHook;

  /// Generic modal top edge, bounds.y() (Qt/src/NativeHud.cpp:158).
  static const double modalTop = 122;

  /// Framebuffer height covered by the scrim (Qt/src/NativeHudModal.cpp:163).
  static const double stageHeight = 1080;

  /// Generic modal maximum width (Qt/src/NativeHud.cpp:153).
  static const double modalMaxWidth = 1260;

  /// Generic modal height, in modalBounds and in the panel fill
  /// (Qt/src/NativeHud.cpp:158, Qt/src/NativeHudModal.cpp:171).
  static const double modalHeight = 836;

  /// width - 100 inside modalBounds (Qt/src/NativeHud.cpp:153).
  static const double modalHorizontalMargin = 100;

  /// Category segment of the shared header line (Qt/src/NativeHudModal.cpp:188; the
  /// provider branch keeps the default).
  static const String category = 'MUSIC DIRECTORY';

  /// modalTitle("provider") (Qt/src/NativeHudModal.cpp:27).
  static const String title = 'MUSIC PLATFORM';

  /// modalSubtitle("provider") (Qt/src/NativeHudModal.cpp:53).
  static const String subtitle = '直接选择音乐平台 / 各平台账号独立保存';

  /// Shared header back button label (Qt/src/NativeHudModal.cpp:199).
  static const String backLabel = '← 返回';

  /// Section heading (Qt/src/NativeHudModal.cpp:293).
  static const String bodyTitle = 'PROVIDER ACCESS / 音乐平台';

  /// First explanation line (Qt/src/NativeHudModal.cpp:296).
  static const String hint1 = '切换平台会停止当前播放，各平台账号与个人音乐独立保存。';

  /// Second explanation line (Qt/src/NativeHudModal.cpp:297).
  static const String hint2 = '网易云与 QQ 支持歌单编辑；酷狗支持读取与播放。';

  /// Third explanation line (Qt/src/NativeHudModal.cpp:298).
  static const String hint3 = '塞壬唱片';

  /// Local-provider button label (Qt/src/NativeHudModal.cpp:300).
  static const String localButtonLabel = '文件夹管理 ＋';

  /// Siren-provider plain text (Qt/src/NativeHudModal.cpp:302).
  static const String sirenLibraryText = '塞壬唱片官网曲库';

  /// Prefix of the login button label (Qt/src/NativeHudModal.cpp:304).
  static const String loginLabelPrefix = '账号登录 / ';

  /// Suffix appended to a selected card caption (Qt/src/NativeHudModal.cpp:274).
  static const String activeSuffix = ' / ACTIVE';

  /// Card gap literal (Qt/src/NativeHudModal.cpp:260).
  static const double cardGap = 12;

  /// Expanded card height (Qt/src/NativeHudModal.cpp:266).
  static const double cardExpandedHeight = 190;

  /// Compact card height (Qt/src/NativeHudModal.cpp:266).
  static const double cardCompactHeight = 66;

  /// Detail wrap inset, cardWidth - 32 (Qt/src/NativeHudModal.cpp:277).
  static const double detailHorizontalInset = 32;

  /// Maximum wrapped detail rows (Qt/src/NativeHudModal.cpp:278).
  static const int detailMaxRows = 3;

  /// Detail row stride (Qt/src/NativeHudModal.cpp:279).
  static const double detailRowStride = 21;

  /// providers as this build sees them (Qt/src/NativeHudModal.cpp:12-24).
  List<ProviderModalCard> get cards =>
      ProviderModalCatalog.forFeatures(localMusic: platformFeaturesLocalMusic);

  /// Builds the frame. Pure: allocates the two output lists, mutates nothing.
  ProviderModalFrame build() {
    final List<List<Object?>> commands = <List<Object?>>[];
    final List<List<Object?>> hits = <List<Object?>>[];
    final _Painter p = _Painter(
      commands: commands,
      hits: hits,
      dark: dark,
      measureText: measureText,
      wrapText: wrapText,
      rectHook: rectHook,
    );

    // Qt/src/NativeHudModal.cpp:83-84 - the whole modal is one save/restore scope and
    // every command below inherits the surface opacity.
    p.save();
    p.alpha(opacity);

    // Qt/src/NativeHudModal.cpp:163-165 - full-stage scrim, emitted BEFORE the offset
    // translate so it does not travel with the panel. The provider panel is not
    // "search", so the injected flag only ever reaches the alpha (:164-165).
    p.fill(0, 0, width, stageHeight, p.scrim(search: search));

    // Qt/src/NativeHudModal.cpp:166.
    p.translate(0, offset);

    // Qt/src/NativeHud.cpp:153,157,158 - generic bounds:
    // modalWidth = min(1260, width - 100); left = (width - modalWidth) / 2;
    // rect = {left, 122, modalWidth, 836}. The search bounds branch (:154-156) is
    // unreachable for this modal kind, so the generic numbers are computed directly.
    final double modalWidth = _min(modalMaxWidth, width - modalHorizontalMargin);
    final double x = (width - modalWidth) / 2;
    const double y = modalTop;
    final double usable = modalWidth;

    // Qt/src/NativeHudModal.cpp:171-172 - the fill height is the Qt literal 836, equal
    // to bounds.height().
    p.fill(x, y, usable, modalHeight, p.panel());

    // Qt/src/NativeHudModal.cpp:173-174 - hits are reset (this list is fresh) and from
    // here on every button is a modal control: tinted fill, inset and refit.
    p.modalControls = true;

    // Shared header, Qt/src/NativeHudModal.cpp:188,198-202. provider is not settings,
    // desktop-lyrics, player or quality, so the category stays the default
    // "MUSIC DIRECTORY" and the header sizes stay 11 and 15.
    p.text('RHINE LAB / MUSIC DATABASE / ' + category, x + 53, y + 37, 11);
    // modal == "desktop-lyrics" is false, so the back button closes the modal (:200).
    p.button(backLabel, x + usable - 220, y + 18, 167, 54,
        ProviderModalActionTable.closeModal, 20, 'demibold');
    p.text(title, x + 53, y + 91, 38, 'demibold');
    p.text(subtitle, x + 53, y + 147, 15);

    // platformPanel(x, y, usable) - Qt/src/NativeHudModal.cpp:212-213, :292-306.
    p.text(bodyTitle, x + 53, y + 222, 13, 'demibold');
    _platformChoices(p, x + 53, y + 258, usable - 106, cardExpanded);
    p.rule(x + 53, y + 490, usable - 106, 0.2);
    p.text(hint1, x + 53, y + 520, 15);
    p.text(hint2, x + 53, y + 558, 15);
    p.text(hint3, x + 53, y + 590, 15);
    if (isLocal) {
      // Qt/src/NativeHudModal.cpp:299-300.
      p.button(localButtonLabel, x + 53, y + 660, 330, 48,
          ProviderModalActionTable.discover, 16);
    } else if (isSiren) {
      // Qt/src/NativeHudModal.cpp:301-302 - a plain text line, no hit.
      p.text(sirenLibraryText, x + 53, y + 675, 15);
    } else {
      // Qt/src/NativeHudModal.cpp:303-304.
      p.button(loginLabelPrefix + providerName, x + 53, y + 660, 330, 48,
          ProviderModalActionTable.login, 16);
    }

    // Qt/src/NativeHudModal.cpp:255-256.
    p.modalControls = false;
    p.restore();
    return ProviderModalFrame(commands: commands, hits: hits);
  }

  /// NativeHud::platformChoices (Qt/src/NativeHudModal.cpp:259-291).
  ///
  /// [x] and [y] are already absolute stage coordinates - Qt's only call site passes
  /// (x + 53, y + 258) at :294 - and [width] is usable - 106.
  void _platformChoices(
      _Painter p, double x, double y, double width, bool expanded) {
    final List<ProviderModalCard> rows = cards;
    const double gap = cardGap; // :260
    // :261 - cardWidth = (width - gap * (n - 1)) / n.
    final double cardWidth = (width - gap * (rows.length - 1)) / rows.length;
    for (int index = 0; index < rows.length; index++) {
      final ProviderModalCard card = rows[index];
      // :264 - left = x + index * (cardWidth + gap).
      final double left = x + index * (cardWidth + gap);
      // :265 - selected = music.provider == provider.id.
      final bool selected = provider == card.id;
      // :266.
      final double height = expanded ? cardExpandedHeight : cardCompactHeight;
      // :267-268.
      final List<Object?> tint = dark
          ? <Object?>[0.55, 0.59, 0.46, selected ? 0.3 : 0.12]
          : <Object?>[0.44, 0.49, 0.36, selected ? 0.23 : 0.09];
      p.fill(left, y, cardWidth, height, tint); // :269
      // :270 - the hit comes after the tint fill and before the selected stripe, and
      // its label is the display name, not the uppercase caption.
      p.hit(left, y, cardWidth, height,
          ProviderModalActionTable.select(card.id), card.name);
      if (selected) {
        // :271-273.
        p.fill(
            left,
            y,
            3,
            height,
            dark
                ? <Object?>[0.7, 0.75, 0.53, 1]
                : <Object?>[0.44, 0.49, 0.36, 1]);
      }
      // :274 - caption at size 10 with default weight and tracking.
      p.text(card.label + (selected ? activeSuffix : ''), left + 16, y + 10, 10);
      // :275 - name, demibold, 22 expanded and 17 compact.
      p.text(card.name, left + 16, y + 29, expanded ? 22 : 17, 'demibold');
      if (expanded) {
        // :277 - wrap(detail, cardWidth - 32, 14) with Qt's default "regular" weight.
        final List<String> lines = p.wrapText(
            card.detail, cardWidth - detailHorizontalInset, 14, 'regular');
        // :278-280 - at most three rows at left + 16, y + 75 + row * 21, size 14.
        final int rowsToPaint = _minInt(lines.length, detailMaxRows);
        for (int row = 0; row < rowsToPaint; row++) {
          p.text(lines[row], left + 16, y + 75 + row * detailRowStride, 14);
        }
        // :288 - limited(note, left + 16, y + 150, 12, cardWidth - 32).
        p.limited(noteFor(card), left + 16, y + 150, 12,
            cardWidth - detailHorizontalInset);
      }
    }
  }

  /// The per-card status note (Qt/src/NativeHudModal.cpp:281-288).
  ///
  /// Qt computes authenticated for every card before branching, then: local gives
  /// 独立本地库 / 无需登录; siren gives 官网曲库 / 无需登录; otherwise
  /// hasCredential(id) selects 本机已保存登录 and the fallback is
  /// 未登录 / 可选择后扫码.
  String noteFor(ProviderModalCard card) {
    if (card.id == 'local') {
      return '独立本地库 / 无需登录';
    }
    if (card.id == 'siren') {
      return '官网曲库 / 无需登录';
    }
    return credentials.contains(card.id) ? '本机已保存登录' : '未登录 / 可选择后扫码';
  }
}

/// Qt draw primitive set (one instance per frame), mirroring NativeHud's private
/// painters so the command order matches the C++ call order exactly.
class _Painter {
  _Painter({
    required this.commands,
    required this.hits,
    required this.dark,
    required this.measureText,
    required this.wrapText,
    required this.rectHook,
  });

  final List<List<Object?>> commands;
  final List<List<Object?>> hits;
  final bool dark;
  final ProviderModalMeasureText measureText;
  final ProviderModalWrapText wrapText;
  final ProviderModalRectHook rectHook;

  /// Qt m_modalControls (Qt/src/NativeHud.h:222), enabled for the whole panel.
  bool modalControls = false;

  /// Qt NativeHud::ink (Qt/src/NativeHud.cpp:10-15).
  List<Object?> ink() => dark
      ? <Object?>[0.92, 0.92, 0.92, 1, 'calibratedWhite']
      : <Object?>[0.08, 0.085, 0.075, 1, 'calibratedRGB'];

  /// Qt ink() with alpha 0.45 (Qt/src/NativeHud.cpp:106-107). This panel paints no
  /// muted text - every text and limited call uses default ink
  /// (Qt/src/NativeHudModal.cpp:292-305) - kept because the shared primitive set is
  /// fixed by the eight-modal contract.
  // ignore: unused_element
  List<Object?> mutedInk() {
    final List<Object?> color = ink();
    color[3] = 0.45;
    return color;
  }

  /// Panel fill for the generic path (Qt/src/NativeHudModal.cpp:171-172).
  List<Object?> panel() => dark
      ? <Object?>[0.15, 0.15, 0.15, 1, 'calibratedWhite']
      : <Object?>[0.929, 0.922, 0.894, 1];

  /// Qt modal-control button tint (Qt/src/NativeHud.cpp:114-117).
  List<Object?> buttonTint() => dark
      ? <Object?>[0.55, 0.59, 0.46, 0.13]
      : <Object?>[0.44, 0.49, 0.36, 0.1];

  /// Scrim fill (Qt/src/NativeHudModal.cpp:163-165): the alpha is 0.6 in dark and 0.45
  /// in light, reduced to 0.15 and 0.12 respectively when search is true.
  List<Object?> scrim({required bool search}) => dark
      ? <Object?>[17 / 255, 24 / 255, 27 / 255, search ? 0.15 : 0.6]
      : <Object?>[227 / 255, 224 / 255, 215 / 255, search ? 0.12 : 0.45];

  void op(List<Object?> command) => commands.add(command);

  void save() => op(<Object?>['save']); // NativeHud.cpp:19-21

  void restore() => op(<Object?>['restore']); // :22-24

  void alpha(double value) => op(<Object?>['alpha', value]); // :25-27

  void translate(double x, double y) => op(<Object?>['translate', x, y]); // :28-30

  /// Qt fill (Qt/src/NativeHud.cpp:37-39); an omitted colour falls back to ink.
  void fill(double x, double y, double width, double height,
      [List<Object?>? color]) {
    final List<double> rect = _mapRect(rectHook, x, y, width, height);
    op(<Object?>['fill', color ?? ink(), rect[0], rect[1], rect[2], rect[3]]);
  }

  /// Qt text (Qt/src/NativeHud.cpp:40-43); weight defaults to regular, tracking to 0
  /// and colour to ink. The origin is mapped as a zero-size rectangle.
  void text(String value, double x, double y, double size,
      [String weight = 'regular', double tracking = 0, List<Object?>? color]) {
    final List<double> point = _mapRect(rectHook, x, y, 0, 0);
    op(<Object?>[
      'text',
      value,
      point[0],
      point[1],
      size,
      weight,
      tracking,
      color ?? ink(),
    ]);
  }

  /// Qt hit (Qt/src/NativeHud.cpp:102-109): six fields in Qt order, the label falling
  /// back to the action when none is drawn.
  void hit(double x, double y, double width, double height, String action,
      [String? label]) {
    final List<double> rect = _mapRect(rectHook, x, y, width, height);
    hits.add(<Object?>[
      rect[0],
      rect[1],
      rect[2],
      rect[3],
      action,
      label ?? action,
    ]);
  }

  /// Qt button (Qt/src/NativeHud.cpp:110-120): hit first, then the tinted fill, then
  /// the inset text whose label is refitted to width - inset * 2 with Qt's default
  /// regular measurement weight and drawn with the requested weight.
  void button(String label, double x, double y, double width, double height,
      String action, double size,
      [String weight = 'regular']) {
    hit(x, y, width, height, action, label);
    final double inset = modalControls ? _min(10.0, width / 8) : 0;
    if (modalControls) {
      fill(x, y, width, height, buttonTint());
    }
    text(modalControls ? fit(label, size, width - inset * 2) : label, x + inset,
        y + (height - size) / 2 - 4, size, weight);
  }

  /// Qt limited (Qt/src/NativeHud.cpp:77-79): text(fit(value, size, width), ...) with
  /// the same weight for measuring and drawing.
  void limited(String value, double x, double y, double size, double width,
      [String weight = 'regular']) {
    text(fit(value, size, width, weight), x, y, size, weight);
  }

  /// Qt rule (Qt/src/NativeHud.cpp:125-129): a 1 px fill tinted with ink whose alpha is
  /// [opacity].
  void rule(double x, double y, double width, double opacity) {
    final List<Object?> color = ink();
    color[3] = opacity;
    fill(x, y, width, 1, color);
  }

  /// Qt NativeHud::fit (Qt/src/NativeHud.cpp:48-76), operation for operation:
  ///
  /// * measure the full run through the injected [measureText] with tracking 0;
  /// * if it fits, return it unchanged;
  /// * otherwise binary-search the longest prefix that fits, then replace its last code
  ///   unit with the horizontal ellipsis - Qt does value.left(max(0, length - 1)) plus
  ///   the ellipsis at :71-73, which is why a truncated label is one code unit shorter
  ///   than the measured prefix.
  String fit(String value, double size, double width,
      [String weight = 'regular']) {
    int length = value.length;
    if (measureText(value, size, weight, 0) > width) {
      int low = 1;
      int high = length;
      while (low < high) {
        final int middle = (low + high + 1) ~/ 2;
        if (measureText(value.substring(0, middle), size, weight, 0) <= width) {
          low = middle;
        } else {
          high = middle - 1;
        }
      }
      length = low;
    }
    if (length != value.length) {
      final int keep = length - 1 < 0 ? 0 : length - 1;
      return value.substring(0, keep) + '…';
    }
    return value;
  }
}
