// T52-C18 (drafted as T52-S01-M12) — offline frame-timing collector for the Flutter port.
//
// Input : JSONL exported from a real Flutter `SchedulerBinding.addTimingsCallback`
//         capture (exactly one `meta` record plus one `frame` record per
//         `FrameTiming`). See tool/perf/README.md for the field contract.
// Output: one JSON report carrying provenance, the capture window, the unit
//         basis, the per-phase distribution, and the explicit "no threshold,
//         nothing measured yet" state.
//
// Why it looks like this (non-negotiable constraints for this atom):
//   * Pure `dart:` libraries only. No Flutter import and no package dependency,
//     so a future `dart run tool/perf/collect_frame_times.dart` needs no device
//     and no `flutter pub get`.
//   * No threshold, no pass/fail, no "p95 通过". The plan keeps every performance
//     ratio 拟议待冻结 until a same-device Qt baseline exists
//     (docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md §9.2).
//   * Protocol/memory bounds (e.g. the 48 MiB Node heap limit) are contract
//     bounds; they are never reused as frame-time thresholds.
//   * Debug-only capture. Samples from a non-active app are excluded, and this
//     tool is never wired into the production start-up path.
//
// This file was written but NOT executed for T52-C18 (drafted as T52-S01-M12):
// `dart analyze`,
// `dart run`, `flutter …`, Gradle and every device command are forbidden for
// this atom. The unexecuted-verification log lives in tool/perf/README.md.

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

const String _toolPath = 'tool/perf/collect_frame_times.dart';
const String _toolRevision = 'T52-C18';
const String _samplesSchema = 'rhine.frame-timings.samples/1';
const String _reportSchema = 'rhine.frame-timings.report/1';
const String _planPath =
    'docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md';

/// Rough cap for the invalid-record examples kept in the report.
const int _maxInvalidExamples = 8;

/// Every fixed invalid reason. All of them are pre-seeded in the report so
/// cross-report aggregation never mistakes a missing key for an unknown reason.
const List<String> _invalidReasons = <String>[
  'json_parse_error',
  'record_is_not_a_json_object',
  'record_type_is_not_a_string',
  'duplicate_meta_record',
  'unknown_record_type',
  'missing_or_non_integer_phase_timestamp',
  'non_monotonic_phase_span',
];

Future<void> main(List<String> arguments) async {
  if (arguments.contains('--help') || arguments.contains('-h')) {
    stdout.write(_usage());
    return;
  }
  try {
    final _Options options = _Options.parse(arguments);
    final _Capture capture = _Capture.read(File(options.input));
    final Map<String, Object?> report = _buildReport(capture, options);
    final String encoded =
        const JsonEncoder.withIndent('  ').convert(report) + '\n';
    final String? out = options.out;
    if (out == null) {
      stdout.write(encoded);
    } else {
      final File file = File(out);
      await file.parent.create(recursive: true);
      await file.writeAsString(encoded);
      stderr.writeln('report written: ${file.path}');
    }
  } on _UsageException catch (error) {
    stderr.writeln('usage error: ${error.message}\n');
    stderr.write(_usage());
    exitCode = 2;
  } on _InputException catch (error) {
    stderr.writeln('input error: ${error.message}');
    exitCode = 3;
  } on Object catch (error) {
    stderr.writeln('internal error: $error');
    exitCode = 3;
  }
}

String _usage() => '''
Usage: dart run $_toolPath --input <samples.jsonl> [options]

  --input <path>      JSONL capture (required): one "meta" record plus one
                      "frame" record per FrameTiming.
  --out <path>        Write the report here instead of stdout.
  --label <text>      Override the scene id recorded in the capture meta.
  --baseline <path>   Another report of this schema; deltas stay descriptive.
  --warmup-ms <int>   Drop frames that ended during warm-up
                      (default: meta.warmupUs, else 0 = no trimming).
  --active-only       Also drop samples that carry no appState field.
  --help              Print this text.

Exit codes: 0 = report produced, 2 = usage error, 3 = input/internal error.
This tool freezes no threshold and prints no pass/fail verdict.
''';

class _UsageException implements Exception {
  _UsageException(this.message);

  final String message;
}

class _InputException implements Exception {
  _InputException(this.message);

  final String message;
}

class _Options {
  _Options({
    required this.input,
    this.out,
    this.label,
    this.baseline,
    this.activeOnly = false,
    this.warmupMs,
  });

  final String input;
  final String? out;
  final String? label;
  final String? baseline;
  final bool activeOnly;
  final int? warmupMs;

  static _Options parse(List<String> arguments) {
    final Map<String, String> values = <String, String>{};
    final Set<String> flags = <String>{};
    for (int i = 0; i < arguments.length; i++) {
      final String argument = arguments[i];
      if (!argument.startsWith('--')) {
        throw _UsageException('unexpected positional argument: $argument');
      }
      final String body = argument.substring(2);
      final int separator = body.indexOf('=');
      final String name = separator >= 0 ? body.substring(0, separator) : body;
      String? value = separator >= 0 ? body.substring(separator + 1) : null;
      switch (name) {
        case 'input':
        case 'out':
        case 'label':
        case 'baseline':
        case 'warmup-ms':
          if (value == null) {
            if (i + 1 >= arguments.length) {
              throw _UsageException('--$name requires a value');
            }
            value = arguments[++i];
          }
          if (value.isEmpty) {
            throw _UsageException('--$name requires a non-empty value');
          }
          values[name] = value;
          break;
        case 'active-only':
          if (value != null) {
            throw _UsageException('--$name does not take a value');
          }
          flags.add(name);
          break;
        default:
          throw _UsageException('unknown option: --$name');
      }
    }
    final String? input = values['input'];
    if (input == null) {
      throw _UsageException('--input is required');
    }
    final String? warmupRaw = values['warmup-ms'];
    int? warmupMs;
    if (warmupRaw != null) {
      warmupMs = int.tryParse(warmupRaw);
      if (warmupMs == null || warmupMs < 0) {
        throw _UsageException('--warmup-ms must be a non-negative integer');
      }
    }
    return _Options(
      input: input,
      out: values['out'],
      label: values['label'],
      baseline: values['baseline'],
      activeOnly: flags.contains('active-only'),
      warmupMs: warmupMs,
    );
  }
}

/// One captured frame, already reduced to the six FrameTiming phases.
class _Frame {
  _Frame({
    required this.vsyncStartUs,
    required this.buildStartUs,
    required this.buildFinishUs,
    required this.rasterStartUs,
    required this.rasterFinishUs,
    required this.rasterFinishWallUs,
    required this.appState,
  });

  final int vsyncStartUs;
  final int buildStartUs;
  final int buildFinishUs;
  final int rasterStartUs;
  final int rasterFinishUs;
  final int? rasterFinishWallUs;
  final String? appState;

  int get buildUs => buildFinishUs - buildStartUs;
  int get rasterUs => rasterFinishUs - rasterStartUs;
  int get totalSpanUs => rasterFinishUs - vsyncStartUs;
  int get vsyncOverheadUs => buildStartUs - vsyncStartUs;

  /// The tool does not assume cross-phase interleaving; it only requires every
  /// derived span to be non-negative. A negative span means the phases were
  /// recorded out of order and the sample cannot be aggregated.
  bool get ordered =>
      buildUs >= 0 &&
      rasterUs >= 0 &&
      totalSpanUs >= 0 &&
      vsyncOverheadUs >= 0;
}

class _Capture {
  _Capture({
    required this.bytes,
    required this.linesRead,
    required this.meta,
    required this.frames,
    required this.invalidByReason,
    required this.invalidExamples,
    required this.stateCounts,
  });

  final int bytes;
  final int linesRead;
  final Map<String, Object?> meta;
  final List<_Frame> frames;
  final Map<String, int> invalidByReason;
  final List<Map<String, Object?>> invalidExamples;
  final Map<String, int> stateCounts;

  int get invalidTotal =>
      invalidByReason.values.fold<int>(0, (int sum, int value) => sum + value);

  Object? get samplesSchema => meta['schema'];

  Map<String, Object?> describe(String path) => <String, Object?>{
        'path': path,
        'bytes': bytes,
        'linesRead': linesRead,
        'encoding': 'utf-8 (malformed bytes replaced, not dropped)',
        'samplesSchema': samplesSchema,
      };

  static _Capture read(File file) {
    if (!file.existsSync()) {
      throw _InputException('input not found: ${file.path}');
    }
    final List<int> bytes = file.readAsBytesSync();
    final String text = utf8.decode(bytes, allowMalformed: true);
    final Map<String, int> invalidByReason = <String, int>{
      for (final String reason in _invalidReasons) reason: 0,
    };
    final List<Map<String, Object?>> invalidExamples = <Map<String, Object?>>[];
    final Map<String, int> stateCounts = <String, int>{};
    final List<_Frame> frames = <_Frame>[];
    Map<String, Object?>? meta;
    int linesRead = 0;

    // reason is a fixed key so counts stay aggregatable across captures;
    // variable text goes to detail.
    void recordInvalid(
      int recordIndex,
      String reason,
      String raw, {
      String? detail,
    }) {
      invalidByReason[reason] = (invalidByReason[reason] ?? 0) + 1;
      if (invalidExamples.length < _maxInvalidExamples) {
        invalidExamples.add(<String, Object?>{
          'recordIndex': recordIndex,
          'reason': reason,
          if (detail != null) 'detail': detail,
          'excerpt': raw.length > 160 ? raw.substring(0, 160) : raw,
        });
      }
    }

    for (final String rawLine in const LineSplitter().convert(text)) {
      final String line = rawLine.trim();
      if (line.isEmpty || line.startsWith('#')) {
        continue;
      }
      linesRead++;
      final int lineNumber = linesRead;

      Object? decoded;
      try {
        decoded = jsonDecode(line);
      } on FormatException catch (error) {
        recordInvalid(
          lineNumber,
          'json_parse_error',
          line,
          detail: error.message,
        );
        continue;
      }
      if (decoded is! Map<String, dynamic>) {
        recordInvalid(lineNumber, 'record_is_not_a_json_object', line);
        continue;
      }
      final Map<String, Object?> record = Map<String, Object?>.from(decoded);
      final bool hasType = record.containsKey('type');
      final String? type = _asRawString(record['type']);
      if (hasType && type == null) {
        recordInvalid(lineNumber, 'record_type_is_not_a_string', line);
        continue;
      }

      if (type == 'meta') {
        if (meta != null) {
          recordInvalid(lineNumber, 'duplicate_meta_record', line);
          continue;
        }
        meta = record;
        continue;
      }
      if (type != null && type != 'frame') {
        recordInvalid(
          lineNumber,
          'unknown_record_type',
          line,
          detail: type,
        );
        continue;
      }

      final int? vsyncStartUs = _asInt(record['vsyncStartUs']);
      final int? buildStartUs = _asInt(record['buildStartUs']);
      final int? buildFinishUs = _asInt(record['buildFinishUs']);
      final int? rasterStartUs = _asInt(record['rasterStartUs']);
      final int? rasterFinishUs = _asInt(record['rasterFinishUs']);
      if (vsyncStartUs == null ||
          buildStartUs == null ||
          buildFinishUs == null ||
          rasterStartUs == null ||
          rasterFinishUs == null) {
        recordInvalid(lineNumber, 'missing_or_non_integer_phase_timestamp', line);
        continue;
      }

      final _Frame frame = _Frame(
        vsyncStartUs: vsyncStartUs,
        buildStartUs: buildStartUs,
        buildFinishUs: buildFinishUs,
        rasterStartUs: rasterStartUs,
        rasterFinishUs: rasterFinishUs,
        rasterFinishWallUs: _asInt(record['rasterFinishWallUs']),
        appState: _asRawString(record['appState']),
      );
      if (!frame.ordered) {
        recordInvalid(lineNumber, 'non_monotonic_phase_span', line);
        continue;
      }
      frames.add(frame);
      final String stateKey = frame.appState ?? '(missing)';
      stateCounts[stateKey] = (stateCounts[stateKey] ?? 0) + 1;
    }

    final Map<String, Object?>? resolvedMeta = meta;
    if (resolvedMeta == null) {
      throw _InputException(
        'no "meta" record found; the capture schema is documented in '
        'tool/perf/README.md',
      );
    }
    final Object? schema = resolvedMeta['schema'];
    if (schema != null && schema != _samplesSchema) {
      throw _InputException(
        'unsupported samples schema "$schema" (expected $_samplesSchema)',
      );
    }

    return _Capture(
      bytes: bytes.length,
      linesRead: linesRead,
      meta: resolvedMeta,
      frames: frames,
      invalidByReason: invalidByReason,
      invalidExamples: invalidExamples,
      stateCounts: stateCounts,
    );
  }
}

Map<String, Object?> _buildReport(_Capture capture, _Options options) {
  final Map<String, Object?> meta = capture.meta;
  final int? metaWarmupUs = _asInt(meta['warmupUs']);
  if (metaWarmupUs != null && metaWarmupUs < 0) {
    throw _InputException(
      'meta.warmupUs must be non-negative, got $metaWarmupUs',
    );
  }
  final int warmupUs = options.warmupMs != null
      ? options.warmupMs! * 1000
      : (metaWarmupUs ?? 0);

  final Object? windowRaw = meta['captureWindow'];
  if (windowRaw != null && windowRaw is! Map) {
    throw _InputException('meta.captureWindow must be a JSON object');
  }
  final Map<String, Object?> windowMeta = _asMap(windowRaw);
  int? startWallUs = _asInt(windowMeta['startWallUs']);
  int? endWallUs = _asInt(windowMeta['endWallUs']);
  final bool windowFromMeta = startWallUs != null && endWallUs != null;
  if (!windowFromMeta) {
    int? minWall;
    int? maxWall;
    for (final _Frame frame in capture.frames) {
      final int? wall = frame.rasterFinishWallUs;
      if (wall == null) {
        continue;
      }
      minWall = (minWall == null || wall < minWall) ? wall : minWall;
      maxWall = (maxWall == null || wall > maxWall) ? wall : maxWall;
    }
    startWallUs = minWall;
    endWallUs = maxWall;
  }

  final List<_Frame> kept = <_Frame>[];
  int droppedWarmup = 0;
  int droppedWarmupUnknownWall = 0;
  int droppedInactive = 0;
  int droppedMissingState = 0;
  final int? warmupCutoffUs =
      startWallUs == null ? null : startWallUs + warmupUs;
  for (final _Frame frame in capture.frames) {
    if (warmupUs > 0) {
      final int? wall = frame.rasterFinishWallUs;
      if (wall == null || warmupCutoffUs == null) {
        // Warm-up cannot be proven for this sample, so it is not aggregated.
        droppedWarmupUnknownWall++;
        continue;
      }
      if (wall < warmupCutoffUs) {
        droppedWarmup++;
        continue;
      }
    }
    final String? state = frame.appState;
    if (state != null && state != 'active') {
      droppedInactive++;
      continue;
    }
    if (state == null && options.activeOnly) {
      droppedMissingState++;
      continue;
    }
    kept.add(frame);
  }

  final List<int> buildUs = <int>[];
  final List<int> rasterUs = <int>[];
  final List<int> totalSpanUs = <int>[];
  final List<int> vsyncOverheadUs = <int>[];
  for (final _Frame frame in kept) {
    buildUs.add(frame.buildUs);
    rasterUs.add(frame.rasterUs);
    totalSpanUs.add(frame.totalSpanUs);
    vsyncOverheadUs.add(frame.vsyncOverheadUs);
  }

  final String windowSource = windowFromMeta
      ? 'meta.captureWindow'
      : (startWallUs != null && endWallUs != null
          ? 'derived_from_rasterFinishWallUs'
          : 'unavailable');
  final int? windowSpanUs = startWallUs != null &&
          endWallUs != null &&
          endWallUs > startWallUs
      ? endWallUs - startWallUs
      : null;
  final int busyUs =
      totalSpanUs.fold<int>(0, (int sum, int value) => sum + value);
  // The rate denominator must describe the same frames as the numerator. After a
  // warm-up trim the capture window still contains the dropped frames, so the
  // kept frames' own wall span is preferred; the capture window is only a stated
  // fallback for captures without a wall clock.
  int? keptWallMin;
  int? keptWallMax;
  int keptWallCount = 0;
  for (final _Frame frame in kept) {
    final int? wall = frame.rasterFinishWallUs;
    if (wall == null) {
      continue;
    }
    keptWallCount++;
    keptWallMin =
        (keptWallMin == null || wall < keptWallMin) ? wall : keptWallMin;
    keptWallMax =
        (keptWallMax == null || wall > keptWallMax) ? wall : keptWallMax;
  }
  final int? keptMinWall = keptWallMin;
  final int? keptMaxWall = keptWallMax;
  int? keptSpanUs;
  if (keptMinWall != null && keptMaxWall != null && keptMaxWall > keptMinWall) {
    keptSpanUs = keptMaxWall - keptMinWall;
  }
  final int? rateSpanUs = keptSpanUs ?? windowSpanUs;
  final String rateBasis = keptSpanUs != null
      ? 'kept_frame_wall_span'
      : (windowSpanUs != null ? 'capture_window' : 'unavailable');
  // Numerator follows the denominator: when the span comes from kept frames'
  // wall clocks, only frames that actually carry a wall clock can be counted in
  // it, otherwise a capture with a few missing walls reads slightly high.
  final int rateFrames = keptSpanUs != null ? keptWallCount : kept.length;
  // Zero kept samples must never read as a measured 0 fps: the report already
  // says NO_VALID_SAMPLES, so the rate fields stay null while the window span is
  // still reported (it describes the window, not the samples).
  final bool noKeptSamples = kept.isEmpty;
  final double? engineFramesPerSecond =
      (rateSpanUs == null || noKeptSamples) ? null : rateFrames * 1e6 / rateSpanUs;
  final double? busyRatio =
      (rateSpanUs == null || noKeptSamples) ? null : busyUs / rateSpanUs;

  final Map<String, Object?> totalSpanStats = _distribution(totalSpanUs);

  final Object? sceneRaw = meta['scene'];
  String? sceneId = options.label;
  String? sceneDescription;
  if (sceneRaw is Map<String, dynamic>) {
    final Map<String, Object?> scene = Map<String, Object?>.from(sceneRaw);
    sceneId ??= _asString(scene['id']);
    sceneDescription = _asString(scene['description']);
    final Object? script = scene['script'];
    if (script != null) {
      // A non-string script would stringify as Dart map syntax; encode it as JSON.
      sceneDescription ??= script is String ? script : jsonEncode(script);
    }
  } else if (sceneRaw is String) {
    sceneId ??= sceneRaw;
  }

  final Map<String, Object?> report = <String, Object?>{
    'schema': _reportSchema,
    'tool': <String, Object?>{
      'path': _toolPath,
      'revision': _toolRevision,
      'atom': 'T52-C18',
      'plan': _planPath,
      'planSection': 'T52 性能与稳定性基线; §9.2 拟议辅助指标（待基线冻结）',
    },
    'generatedAtUtc': DateTime.now().toUtc().toIso8601String(),
    'input': capture.describe(options.input),
    'scene': <String, Object?>{
      'id': sceneId,
      'description': sceneDescription,
      'source': options.label != null
          ? 'cli_label_override'
          : (sceneRaw != null ? 'meta' : 'missing'),
    },
    'measurement': <String, Object?>{
      'status': kept.isEmpty ? 'NO_VALID_SAMPLES' : 'SAMPLED_UNFROZEN',
      'thresholds': <String, Object?>{
        'frozen': false,
        'evaluated': false,
        'provenance': '$_planPath §9.2 — 所有性能比例均为拟议辅助指标，'
            '必须用 Qt 同设备同场景基线冻结后才可写入验收',
        'reuseForbidden': <String>[
          'protocol/memory bounds (e.g. the 48 MiB Node heap limit) are contract '
              'bounds, not frame-time thresholds',
          '60 fps / 16.6 ms / jank<1% / +10% style promises are forbidden before '
              'a same-device Qt baseline is frozen (plan §9.2)',
        ],
      },
      'deviceGate': 'DEVICE_BLOCKED',
      'productionWiring': 'NOT_WIRED',
      'captureMode': 'debug-only; non-active-app samples excluded',
    },
    'window': <String, Object?>{
      'source': windowSource,
      'startWallUs': startWallUs,
      'endWallUs': endWallUs,
      'spanMs': windowSpanUs == null ? null : _ms(windowSpanUs),
      'unit': 'wall bounds in microseconds; spanMs in milliseconds',
      'warmupUs': warmupUs,
      'warmupTrimApplied':
          warmupUs > 0 && (droppedWarmup + droppedWarmupUnknownWall) > 0,
    },
    'counts': <String, Object?>{
      'linesRead': capture.linesRead,
      'frameRecords': capture.frames.length,
      'metaRecordsUsed': 1,
      'framesKept': kept.length,
      'droppedWarmup': droppedWarmup,
      'droppedWarmupUnknownWall': droppedWarmupUnknownWall,
      'droppedInactiveAppState': droppedInactive,
      'droppedMissingAppState': droppedMissingState,
      'appStateCounts': capture.stateCounts,
      'invalid': <String, Object?>{
        'total': capture.invalidTotal,
        'byReason': capture.invalidByReason,
        'examples': capture.invalidExamples,
      },
    },
    'distribution': <String, Object?>{
      'unit': 'ms',
      'sourceUnit': 'us (dart:ui FrameTiming.timestampInMicroseconds)',
      'percentileMethod': 'linear interpolation, rank=(n-1)*q over ascending values',
      'stdDev': 'population (divide by n)',
      'buildMs': _distribution(buildUs),
      'rasterMs': _distribution(rasterUs),
      'totalSpanMs': totalSpanStats,
      'vsyncOverheadMs': _distribution(vsyncOverheadUs),
    },
    'rate': <String, Object?>{
      'engineFramesPerSecond':
          engineFramesPerSecond == null ? null : _round(engineFramesPerSecond, 3),
      'busyRatio': busyRatio == null ? null : _round(busyRatio, 4),
      'spanUs': rateSpanUs,
      'spanMs': rateSpanUs == null ? null : _ms(rateSpanUs),
      'spanBasis': rateBasis,
      'framesInRate': rateFrames,
      'note': 'engineFramesPerSecond 是引擎帧产出率 = framesInRate / span；span 优先取'
          '保留帧自身的墙钟跨度（spanBasis=kept_frame_wall_span），样本无墙钟时'
          '退化为采集窗口（capture_window）并在 spanBasis 标注。span='
          'capture_window 时，被热身裁掉的帧仍占着窗口时间，因此 '
          'engineFramesPerSecond 与 busyRatio 都会被系统性低估。它不等于 Qt 的'
          '内容帧/s（render/s），两者等价性未验证。busyRatio 可 >1（相邻帧跨度'
          '重叠），只作负载描述，不是目标值。',
    },
    'provenance': _provenance(
      capture: capture,
      meta: meta,
      options: options,
      windowFromMeta: windowFromMeta,
      windowMetaIsPartial: windowFromMeta || windowRaw == null
          ? false
          : _asMap(windowRaw).isNotEmpty,
      warmupUs: warmupUs,
    ),
    'comparison': _compare(options.baseline, totalSpanStats),
    'nonClaims': <String>[
      '本报告不含任何阈值判定，不能读出“p95 通过/不通过”。',
      '48 MiB 等协议或内存上限不是帧时间阈值，本报告未复用为性能门。',
      '非 active app 的样本不参与结论；采集仅限调试构建与显式开关。',
      '静止低 fps 是正常现象；帧率必须连同场景动作脚本一起读。',
      '未与 Qt 同设备同场景基线对照前，不得声称性能对齐。',
    ],
    'capture': meta,
  };
  return report;
}

Map<String, Object?> _provenance({
  required _Capture capture,
  required Map<String, Object?> meta,
  required _Options options,
  required bool windowFromMeta,
  required bool windowMetaIsPartial,
  required int warmupUs,
}) {
  final List<String> gaps = <String>[];
  final Map<String, Object?> recorder = _asMap(meta['recorder']);
  final Map<String, Object?> device = _asMap(meta['device']);
  final Map<String, Object?> app = _asMap(meta['app']);
  if (recorder.isEmpty) {
    gaps.add('recorder block missing: capture API and toolchain versions unknown');
  } else {
    if (_asString(recorder['api']) == null) {
      gaps.add('recorder.api missing');
    }
    if (_asString(recorder['flutterVersion']) == null) {
      gaps.add('recorder.flutterVersion missing');
    }
    if (_asString(recorder['buildMode']) != 'debug') {
      gaps.add('recorder.buildMode is not "debug"');
    }
  }
  if (device.isEmpty) {
    gaps.add('device block missing: same-device Qt comparison impossible');
  }
  if (app.isEmpty) {
    gaps.add('app block missing: build identity unknown');
  }
  final Object? sceneBlock = meta['scene'];
  if (sceneBlock == null) {
    if (options.label == null) {
      gaps.add('scene missing: distribution is not tied to a scripted scenario');
    }
  } else if (sceneBlock is Map) {
    final Map<String, Object?> sceneMap = Map<String, Object?>.from(sceneBlock);
    if (_asString(sceneMap['id']) == null) {
      gaps.add('scene.id missing: distribution is not tied to a named scenario');
    }
    if (_asString(sceneMap['description']) == null) {
      gaps.add('scene.description missing: scenario action script unknown');
    }
  } else if (sceneBlock is! String) {
    gaps.add('scene block is neither object nor string: scenario binding unknown');
  }
  if (!windowFromMeta) {
    gaps.add(windowMetaIsPartial
        ? 'captureWindow incomplete in meta (startWallUs and endWallUs are both '
            'required): window derived from frame wall clocks'
        : 'captureWindow missing in meta: window derived from frame wall clocks');
  }
  if (warmupUs == 0) {
    gaps.add('warmupUs missing or zero: warm-up frames are included');
  }
  if (capture.stateCounts.containsKey('(missing)')) {
    gaps.add('some samples carry no appState: active-app filtering is partial');
  }
  return <String, Object?>{
    'complete': gaps.isEmpty,
    'gaps': gaps,
    'recorder': recorder,
    'device': device,
    'app': app,
    'scene': meta['scene'],
    'activeOnlyFilter': options.activeOnly,
    'appStateCounts': capture.stateCounts,
  };
}

/// One fixed shape for every "cannot compare" outcome: the field never changes
/// shape and always carries the frozen verdict.
Map<String, Object?> _unavailableComparison(
  String reason, {
  String? path,
  Object? baselineSchema,
  Map<String, Object?>? extra,
}) {
  final Map<String, Object?> out = <String, Object?>{
    'available': false,
    'path': path,
    'baselineSchema': baselineSchema,
    'metric': 'distribution.totalSpanMs',
    'deltaMs': null,
    'ratio': null,
    'verdict': 'NOT_EVALUATED',
    'reason': reason,
  };
  if (extra != null) {
    out.addAll(extra);
  }
  return out;
}

Map<String, Object?> _compare(String? baselinePath, Map<String, Object?> current) {
  if (baselinePath == null) {
    return _unavailableComparison(
      'no --baseline report supplied',
      extra: <String, Object?>{
        'qtAdapter':
            'NOT_IMPLEMENTED: tools/perf (Qt harness) prints 内容帧/s and FG '
                'diag lines; it does not export rhine.frame-timings.report/1 yet',
      },
    );
  }
  final File file = File(baselinePath);
  if (!file.existsSync()) {
    return _unavailableComparison(
      'baseline report not found',
      path: baselinePath,
    );
  }
  Object? decoded;
  try {
    decoded = jsonDecode(file.readAsStringSync());
  } on FormatException catch (error) {
    return _unavailableComparison(
      'baseline is not valid JSON: ${error.message}',
      path: baselinePath,
    );
  }
  if (decoded is! Map<String, dynamic>) {
    return _unavailableComparison(
      'baseline is not a JSON object',
      path: baselinePath,
    );
  }
  final Map<String, Object?> other = Map<String, Object?>.from(decoded);
  final Object? baselineSchema = other['schema'];
  if (baselineSchema != _reportSchema) {
    return _unavailableComparison(
      'baseline schema mismatch: "$baselineSchema" != "$_reportSchema"',
      path: baselinePath,
      baselineSchema: baselineSchema,
    );
  }
  final Map<String, Object?> otherSpan =
      _asMap(_asMap(other['distribution'])['totalSpanMs']);
  final double? baseP50 = _asDouble(otherSpan['p50Ms']);
  final double? baseP95 = _asDouble(otherSpan['p95Ms']);
  final double? currentP50 = _asDouble(current['p50Ms']);
  final double? currentP95 = _asDouble(current['p95Ms']);
  if (baseP50 == null && baseP95 == null) {
    return _unavailableComparison(
      'baseline distribution.totalSpanMs has neither p50Ms nor p95Ms',
      path: baselinePath,
      baselineSchema: baselineSchema,
    );
  }
  double? delta(double? left, double? right) =>
      left == null || right == null ? null : left - right;
  double? ratio(double? left, double? right) =>
      left == null || right == null || right == 0 ? null : left / right;
  return <String, Object?>{
    'available': true,
    'path': baselinePath,
    'baselineSchema': baselineSchema,
    'metric': 'distribution.totalSpanMs',
    'deltaMs': <String, Object?>{
      'p50': _round(delta(currentP50, baseP50), 3),
      'p95': _round(delta(currentP95, baseP95), 3),
    },
    'ratio': <String, Object?>{
      'p50': _round(ratio(currentP50, baseP50), 4),
      'p95': _round(ratio(currentP95, baseP95), 4),
    },
    'verdict': 'NOT_EVALUATED',
    'reason': 'plan §9.2: no frozen performance threshold; deltas are descriptive',
    'equivalence':
        'UNVERIFIED: Qt 内容帧/s (render/s) and Flutter engine frames are not '
            'proven equivalent; a ratio is not parity',
  };
}

Map<String, Object?> _distribution(List<int> micros) {
  if (micros.isEmpty) {
    return <String, Object?>{
      'count': 0,
      'minMs': null,
      'p50Ms': null,
      'p90Ms': null,
      'p95Ms': null,
      'p99Ms': null,
      'maxMs': null,
      'meanMs': null,
      'stdDevMs': null,
      'sumMs': null,
    };
  }
  final List<int> sorted = List<int>.of(micros)..sort();
  final int count = sorted.length;
  double total = 0;
  for (final int value in sorted) {
    total += value;
  }
  final double meanMicros = total / count;
  double squared = 0;
  for (final int value in sorted) {
    final double delta = value - meanMicros;
    squared += delta * delta;
  }
  final double stdDevMicros = math.sqrt(squared / count);
  return <String, Object?>{
    'count': count,
    'minMs': _ms(sorted.first),
    'p50Ms': _msDouble(_percentile(sorted, 0.50)),
    'p90Ms': _msDouble(_percentile(sorted, 0.90)),
    'p95Ms': _msDouble(_percentile(sorted, 0.95)),
    'p99Ms': _msDouble(_percentile(sorted, 0.99)),
    'maxMs': _ms(sorted.last),
    'meanMs': _msDouble(meanMicros),
    'stdDevMs': _msDouble(stdDevMicros),
    'sumMs': _msDouble(total),
  };
}

double _percentile(List<int> sorted, double q) {
  if (sorted.length == 1) {
    return sorted.first.toDouble();
  }
  final double rank = (sorted.length - 1) * q;
  final int lower = rank.floor();
  final int upper = rank.ceil();
  if (lower == upper) {
    return sorted[lower].toDouble();
  }
  final double fraction = rank - lower;
  return sorted[lower] + (sorted[upper] - sorted[lower]) * fraction;
}

double _ms(int micros) => double.parse((micros / 1000).toStringAsFixed(3));

double _msDouble(double micros) =>
    double.parse((micros / 1000).toStringAsFixed(3));

double? _round(double? value, int digits) {
  if (value == null || !value.isFinite) {
    return null;
  }
  final double factor = math.pow(10, digits).toDouble();
  return (value * factor).roundToDouble() / factor;
}

int? _asInt(Object? value) {
  if (value is int) {
    return value;
  }
  if (value is double && value == value.roundToDouble()) {
    return value.toInt();
  }
  if (value is String) {
    return int.tryParse(value.trim());
  }
  return null;
}

double? _asDouble(Object? value) {
  if (value is num) {
    return value.toDouble();
  }
  if (value is String) {
    return double.tryParse(value.trim());
  }
  return null;
}

String? _asString(Object? value) {
  if (value is String && value.trim().isNotEmpty) {
    return value;
  }
  return null;
}

/// Keeps the string verbatim (no trim / emptiness test); used where an empty
/// value is still meaningful, e.g. an enum-like record field.
String? _asRawString(Object? value) => value is String ? value : null;

Map<String, Object?> _asMap(Object? value) {
  if (value is Map) {
    return <String, Object?>{
      for (final MapEntry<Object?, Object?> entry in value.entries)
        if (entry.key is String) entry.key! as String: entry.value,
    };
  }
  return <String, Object?>{};
}
