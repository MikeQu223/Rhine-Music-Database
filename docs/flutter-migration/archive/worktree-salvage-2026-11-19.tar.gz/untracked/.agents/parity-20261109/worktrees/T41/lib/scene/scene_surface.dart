/// Scene surface assembly — the Dart port of the Qt scene draw list, the actor
/// template and the actor pass.
///
/// Source of truth: Qt/src/NativeSceneFrame.cpp (214 lines) at commit
/// 8ed3067b0812eb2612f7841ec127a6e8ca93231b, together with Qt/src/SceneAppearance.cpp
/// (258), Qt/src/SceneAppearance.h (23), Qt/src/NativeSceneUpdate.cpp:9-19,237-274,322,
/// Qt/src/NativeScene.h:83-96 and Qt/src/NativeViewer.cpp:8-11,296-335.
///
/// Conventions copied verbatim from the C++:
///  * emitFrame (NativeSceneFrame.cpp:56-214) is the single authority for the draw
///    list: the floor draw is id 1 and its JSON "matrices" is emptied at :63 even
///    though the GPU bytes live in drawBuffers[1] (:62).
///  * Every instanced draw shares one per-instance payload, published under key 10 by
///    the update pass (NativeSceneUpdate.cpp:322) and copied into each instanced id by
///    NativeSceneFrame.cpp:65,76.
///  * Actors are the selected card plus the returning cards only
///    (NativeSceneFrame.cpp:158-161). The 5 lane x 40 record grid addresses the cells;
///    visible cells are instances, never actors.
///  * A frame always carries three loads — floor, instanced cells and actors.
///    [surfaceFrame] refuses to build a frame that would silently drop one, because a
///    static background is a rendering regression, not a valid frame.
///
/// STATUS: written, deliberately NOT executed. dart analyze, dart test, flutter test,
/// dart format and code generation are forbidden for this atom, so RED and GREEN are
/// both unverified (RED/GREEN not run).
library;

import 'dart:typed_data';
import 'scene_frame.dart';
import 'scene_math.dart';


// ---------------------------------------------------------------------------
// Identify and geometry constants. Every value cites its Qt line.
// ---------------------------------------------------------------------------

/// NativeSceneFrame.cpp:62 — the floor is always draw id 1.
const int kFloorDrawId = 1;

/// NativeSceneUpdate.cpp:322 / NativeSceneFrame.cpp:65 — the id under which the
/// update pass publishes the shared per-instance payload.
const int kInstanceBufferId = 10;

/// SceneAppearance.cpp:148 — instanced draw ids are mesh + 10.
const int kInstancedIdBase = 10;

/// NativeSceneFrame.cpp:62 / SceneAppearance.cpp:248 — -pi / 2 around X. The literal
/// is written the way the C++ writes it so the double is identical.
const double kFloorTilt = -3.14159265358979323846 / 2;

/// NativeSceneFrame.cpp:62 — the floor sits 4.63 below the world origin.
const double kFloorDropY = -4.63;

/// SceneAppearance.cpp:228 — the floor colour crossfades between these two.
const String kFloorDayHex = '#d8c9b9';
const String kFloorNightHex = '#192125';

/// SceneAppearance.cpp:227 — the floor material factors (roughnessFactor 0.95 and
/// metallicFactor 0).
const double kFloorRoughness = 0.95;
const double kFloorMetalness = 0;

/// SceneAppearance.cpp:41-42 — roughnessFactor / metallicFactor default to 1 when the
/// glTF material omits them.
const double kMaterialDefaultFactor = 1;

/// SceneAppearance.cpp:46 — the glTF ior default.
const double kMaterialDefaultIor = 1.5;

/// SceneAppearance.cpp:48 — a glTF material without a volume extension gets an
/// effectively infinite attenuation distance.
const double kAttenuationDistanceInfinite = 1e9;

/// SceneAppearance.cpp:66 — this mesh is always dropped before it even gets a part
/// index.
const String kCarbonInkMesh = 'Carbon_Ink';

/// SceneAppearance.cpp:10-11 — meshes that never reach the template.
const Set<String> kHiddenMeshes = <String>{
  'Internal_Ceramic',
  'Optical_Edges',
  'Subsurface_Optics',
  'Optical_Film_Edge',
  'Amber_Optical_Inlay',
  'Champagne_Index',
  'Printed_Label',
};

/// SceneAppearance.cpp:14 — the only meshes that get a low/instanced variant.
const Set<String> kInstancedMeshes = <String>{
  'Frosted_Polymer',
  'Ivory_Edges',
  'Optical_Diffuser',
};

/// NativeScene.cpp:34,63-71 — the wall is 5 lanes, each lane maps a record index
/// 0..39 onto row 12 + index (NativeScene.cpp:67).
const int kLaneCount = 5;
const int kRecordsPerLane = 40;

/// NativeSceneFrame.cpp:134 — the shadow-only light window, widened by the actor
/// radius + 0.1 (NativeSceneFrame.cpp:131).
const double kShadowLightXExtent = 16.1;
const double kShadowLightYExtent = 15.1;
const double kShadowRadiusMargin = 0.1;

/// NativeSceneFrame.cpp:123 — the fixed light camera.
const Vec3 kShadowLightEye = Vec3(-6, 14, -5);

/// NativeViewer.cpp:327 — the synthetic viewer actor id, and NativeViewer.cpp:329 the
/// viewer card root translation.
const int kViewerActorId = 100000;
const Vec3 kViewerCardRoot = Vec3(0, -1.85, 0);

/// NativeViewer.cpp:316 — the cover label local position before the spread offset.
const Vec3 kCoverLabelPosition = Vec3(-1.36, 3.04, 0.255);

/// SceneAppearance.cpp:150 — every part is bound to the cassette asset.
const String kAssetKey = 'cassette';

/// NativeScene.cpp:89 — a selection index is a record index inside one lane.
const int kSelectionLimit = 40;

// ---------------------------------------------------------------------------
// Small JSON accessors mirroring the QJsonValue conversions in the C++.
// ---------------------------------------------------------------------------

Map<String, Object?> _asMap(Object? value) =>
    value is Map<Object?, Object?> ? value.cast<String, Object?>() : <String, Object?>{};

List<Object?> _asList(Object? value) => value is List<Object?> ? value : const <Object?>[];

double _asDouble(Object? value, [double fallback = 0]) =>
    value is num ? value.toDouble() : fallback;

int _asInt(Object? value, [int fallback = 0]) => value is num ? value.toInt() : fallback;

String _asString(Object? value) => value is String ? value : '';

bool _asBool(Object? value, [bool fallback = false]) => value is bool ? value : fallback;

/// QJsonObject value semantics: the template inserts independent copies, so a later
/// mutation of one row cannot leak into a sibling row.
Map<String, Object?> _copyMap(Map<String, Object?> source) => <String, Object?>{
      for (final MapEntry<String, Object?> entry in source.entries)
        entry.key: _copyValue(entry.value),
    };

Object? _copyValue(Object? value) {
  if (value is Map<Object?, Object?>) {
    return _copyMap(value.cast<String, Object?>());
  }
  if (value is List<Object?>) {
    return value.map(_copyValue).toList(growable: true);
  }
  return value;
}

/// std::min / std::max of the bounds sweep (SceneAppearance.cpp:72-77).
double _min(double left, double right) => left < right ? left : right;

double _max(double left, double right) => left > right ? left : right;

// ---------------------------------------------------------------------------
// Floor draw — SceneAppearance.cpp:33-52,225-258 and NativeSceneFrame.cpp:60-64.
// ---------------------------------------------------------------------------

/// SceneMath::Matrix::compose({0, -4.63, 0}, {-pi / 2, 0, 0})
/// (NativeSceneFrame.cpp:62, SceneAppearance.cpp:248).
Mat4 floorMatrix() => Mat4.compose(const Vec3(0, kFloorDropY, 0), const Vec3(kFloorTilt, 0, 0));

/// One completed floor draw: the JSON entry the HUD reads plus the GPU buffer the
/// renderer binds.
///
/// Qt keeps the two apart on purpose — NativeSceneFrame.cpp:63 blanks the JSON
/// matrices array so the 16 doubles never cross the JSON boundary, while the 64
/// Float32 bytes go into drawBuffers[1] at :62.
class SceneFloorPass {
  SceneFloorPass({required this.draw, required this.buffer});

  /// The draw object appended to frame["draws"] (NativeSceneFrame.cpp:59-64).
  final Map<String, Object?> draw;

  /// drawBuffers[1] — 64 bytes of Float32, empty themes and empty ids
  /// (NativeSceneFrame.cpp:62).
  final SceneDrawData buffer;
}

/// SceneAppearance.cpp:33-52 — the shared material projection.
///
/// The floor passes only pbrMetallicRoughness {roughnessFactor, metallicFactor}
/// (SceneAppearance.cpp:227) and no extensions, so baseColorFactor falls back to
/// {1, 1, 1, 1} at :37-39 giving opacity == 1, and every extension-driven field keeps
/// its glTF default (ior 1.5 at :46).
Map<String, Object?> floorMaterial({required double theme}) => <String, Object?>{
      'color': blendLinear(linearColor(kFloorDayHex), linearColor(kFloorNightHex), theme),
      'roughness': kFloorRoughness,
      'metalness': kFloorMetalness,
      'transmission': 0,
      'thickness': 0,
      'ior': kMaterialDefaultIor,
      'attenuation': <double>[1, 1, 1],
      'attenuationDistance': kAttenuationDistanceInfinite,
      'opacity': 1,
      'clearcoat': 0,
      'clearcoatRoughness': 0,
    };

/// NativeSceneFrame.cpp:60-64 — the floor draw plus its GPU buffer.
///
/// theme drives the material colour blend (SceneAppearance.cpp:228) and the draw
/// level theme field (SceneAppearance.cpp:253).
SceneFloorPass drawFloor({required double theme}) {
  final Map<String, Object?> draw = <String, Object?>{
    ...floorMaterial(theme: theme),
    // SceneAppearance.cpp:229-253 — the identity/geometry fields.
    'id': kFloorDrawId,
    'mesh': -1,
    'asset': kAssetKey,
    'instanced': false,
    'label': false,
    'floor': true,
    'transparent': false,
    'depthWrite': true,
    'order': 0,
    'side': 0,
    'name': '',
    'castShadow': false,
    'musicKey': null,
    'musicSelected': false,
    'shadowOnly': false,
    'count': 1,
    'matrixBuffer': -1,
    'themeBuffer': -1,
    // SceneAppearance.cpp:248 carries the matrix as 16 doubles, but
    // NativeSceneFrame.cpp:63 replaces it with an empty array before the frame is
    // published: the numbers travel through drawBuffers[1] only.
    'matrices': <Object?>[],
    'themes': <Object?>[],
    'quality': 0,
    'clarity': 0,
    'subdued': 0,
    'theme': theme,
  };
  return SceneFloorPass(
    draw: draw,
    buffer: SceneDrawData(matrices: floorMatrix().toBytes(), themes: Uint8List(0), ids: <int>[]),
  );
}

// ---------------------------------------------------------------------------
// Shared cassette template — SceneAppearance.cpp:55-223.
// ---------------------------------------------------------------------------

/// Qt SceneAppearance: the material template every card part is drawn from, the
/// instanced descriptors and the actor cull bounds.
class SceneSurfaceAssets {
  SceneSurfaceAssets({
    required this.actorTemplate,
    required this.instances,
    required this.pickingMeshes,
    required this.boundsCenter,
    required this.boundsRadius,
    required this.revision,
  });

  /// SceneAppearance.cpp:55-223 — build the shared template from the cassette glTF
  /// metadata (archive-cassette.json).
  ///
  /// The revision is a process-wide monotonic counter starting at 1
  /// (SceneAppearance.cpp:56-58 static std::atomic<quint64> nextRevision{1} plus
  /// revision = nextRevision.fetch_add(1)), so two templates built in one process
  /// never share a decode cache (SceneAppearance.h:10-11).
  factory SceneSurfaceAssets.fromAsset(Map<String, Object?> asset) {
    final int revision = _nextSurfaceRevision++;
    final List<Map<String, Object?>> actorTemplate = <Map<String, Object?>>[];
    final List<Map<String, Object?>> instances = <Map<String, Object?>>[];
    final List<int> pickingMeshes = <int>[];

    // SceneAppearance.h:15-16 — the bounds keep the header defaults until at least
    // one mesh carries a full pair of bounds (SceneAppearance.cpp:170).
    Vec3 boundsCenter = const Vec3(0, 1.85, 0);
    double boundsRadius = 3.3;
    Vec3 minimum = const Vec3(1e100, 1e100, 1e100);
    Vec3 maximum = const Vec3(-1e100, -1e100, -1e100);

    final List<Object?> meshes = _asList(asset['meshes']);
    int partIndex = 0;
    for (int mesh = 0; mesh < meshes.length; ++mesh) {
      final Map<String, Object?> entry = _asMap(meshes[mesh]);
      final String name = _asString(entry['name']);
      // SceneAppearance.cpp:66-68 — Carbon_Ink never consumes a part index and never
      // joins the picker.
      if (name == kCarbonInkMesh) {
        continue;
      }
      final List<Object?> lowBounds = _asList(entry['minimum']);
      final List<Object?> highBounds = _asList(entry['maximum']);
      // SceneAppearance.cpp:71-78 — only a complete 3-component pair moves the sweep.
      if (lowBounds.length == 3 && highBounds.length == 3) {
        minimum = Vec3(
          _min(minimum.x, _asDouble(lowBounds[0])),
          _min(minimum.y, _asDouble(lowBounds[1])),
          _min(minimum.z, _asDouble(lowBounds[2])),
        );
        maximum = Vec3(
          _max(maximum.x, _asDouble(highBounds[0])),
          _max(maximum.y, _asDouble(highBounds[1])),
          _max(maximum.z, _asDouble(highBounds[2])),
        );
      }
      pickingMeshes.add(mesh);
      final int index = partIndex++;
      // SceneAppearance.cpp:81-83 — a hidden mesh already owns its part index.
      if (kHiddenMeshes.contains(name)) {
        continue;
      }
      final Map<String, Object?> source = _asMap(entry['material']);
      final Map<String, Object?> high = _material(source);
      // SceneAppearance.cpp:86-103 — the per-name high material overrides.
      if (name == 'Frosted_Polymer') {
        high['color'] = linearColor('#fffdfa');
        high['transmission'] = 0.9;
        high['thickness'] = 0.12;
        high['roughness'] = 0.21;
        high['ior'] = 1.46;
        high['attenuation'] = linearColor('#eee6df');
        high['attenuationDistance'] = 2;
      } else if (name == 'Ivory_Edges') {
        high['color'] = linearColor('#f0e7df');
        high['roughness'] = 0.31;
        high['transmission'] = 0.65;
        high['thickness'] = 0.04;
      } else if (name == 'Optical_Diffuser') {
        high['color'] = linearColor('#e2dad4');
        high['transmission'] = 0;
        high['roughness'] = 0.7;
      }
      // SceneAppearance.cpp:104-123 — only the three array meshes get a low variant.
      // The Index_Inlay branch at :119-122 is unreachable in Qt (Index_Inlay is not in
      // the arrays set at :14) and is reproduced so the port stays a line-for-line
      // image of the C++.
      Map<String, Object?> low = <String, Object?>{};
      if (kInstancedMeshes.contains(name)) {
        low = _copyMap(high);
        if (name == 'Frosted_Polymer') {
          low['transmission'] = 0.78;
          low['color'] = linearColor('#fff7ed');
          low['roughness'] = 0.28;
          low['clearcoat'] = 0.3;
          low['clearcoatRoughness'] = 0.25;
        } else if (name == 'Optical_Diffuser') {
          low['color'] = linearColor('#806447');
        } else if (name == 'Ivory_Edges') {
          low['transmission'] = 0;
          low['color'] = linearColor('#fff5e9');
          low['roughness'] = 0.38;
        } else if (name == 'Index_Inlay') {
          low['color'] = linearColor('#e4d6c5');
          low['metalness'] = 0.05;
        }
      }
      // SceneAppearance.cpp:135-137 — closed, non-transmitting parts render front
      // faces only; every other part follows doubleSided.
      final bool closed = _asBool(entry['closed'], false);
      final double transmission = _asDouble(high['transmission']);
      final int side =
          (closed && transmission <= 0) ? 0 : (_asBool(source['doubleSided'], false) ? 2 : 0);
      final Map<String, Object?> definition = <String, Object?>{
        'partIndex': index,
        'mesh': mesh,
        'asset': kAssetKey,
        'label': false,
        'name': name,
        'transparent': _asString(source['alphaMode']) == 'BLEND',
        'depthWrite': true,
        'order': 0,
        'side': side,
        'castShadow': name == 'Optical_Diffuser',
        'localMatrix': Mat4().toJson(),
        'base': _copyMap(high),
        'high': _copyMap(high),
        'low': low.isEmpty ? null : low,
        'hasMap': false,
        'interpolateAttenuation':
            low.isNotEmpty && _asDouble(high['attenuationDistance']) < kAttenuationDistanceInfinite,
      };
      actorTemplate.add(definition);
      if (low.isNotEmpty) {
        // SceneAppearance.cpp:146-168 — the instanced descriptor shares the low
        // material and gets the fixed card flags.
        final Map<String, Object?> draw = _copyMap(low);
        draw['id'] = mesh + kInstancedIdBase;
        draw['mesh'] = mesh;
        draw['asset'] = kAssetKey;
        draw['instanced'] = true;
        draw['label'] = false;
        draw['floor'] = false;
        draw['transparent'] = false;
        draw['depthWrite'] = true;
        draw['order'] = 0;
        draw['side'] = side;
        draw['name'] = name;
        draw['castShadow'] = false;
        draw['musicKey'] = null;
        draw['musicSelected'] = false;
        draw['shadowOnly'] = false;
        draw['quality'] = 0;
        draw['clarity'] = 0;
        draw['subdued'] = 0;
        draw['theme'] = 0;
        instances.add(draw);
      }
    }
    // SceneAppearance.cpp:170-173 — the sweep only wins if at least one mesh
    // contributed a bound pair.
    if (maximum.x >= minimum.x) {
      boundsCenter = (minimum + maximum) * 0.5;
      boundsRadius = (maximum - minimum).length * 0.5;
    }
    // SceneAppearance.cpp:174-184 — the label material.
    final Map<String, Object?> label = <String, Object?>{
      'color': <double>[1, 1, 1],
      'roughness': 1,
      'metalness': 0,
      'transmission': 0,
      'thickness': 0,
      'ior': kMaterialDefaultIor,
      'attenuation': <double>[1, 1, 1],
      'attenuationDistance': kAttenuationDistanceInfinite,
      'opacity': 0,
      'clearcoat': 0,
      'clearcoatRoughness': 0,
    };
    // SceneAppearance.cpp:186-203 — the two decorative lettering sheets. Their
    // geometry already sits in card-local space, so the local matrix is identity.
    Map<String, Object?> letteringPart(int mesh, String name) => <String, Object?>{
          'partIndex': partIndex++,
          'mesh': mesh,
          'asset': kAssetKey,
          'label': false,
          'name': name,
          'transparent': true,
          'depthWrite': false,
          'order': 0,
          'side': 2,
          'castShadow': false,
          'localMatrix': Mat4().toJson(),
          'base': _copyMap(label),
          'high': null,
          'low': null,
          'hasMap': true,
          'interpolateAttenuation': false,
        };
    actorTemplate.add(letteringPart(-6, 'Case_Lettering_Front'));
    actorTemplate.add(letteringPart(-7, 'Case_Lettering_Spine'));
    // SceneAppearance.cpp:206-222 — the cover sheet. Qt uses the current partIndex
    // here without incrementing it; reproduced verbatim.
    actorTemplate.add(<String, Object?>{
      'partIndex': partIndex,
      'mesh': -1,
      'asset': kAssetKey,
      'label': true,
      'name': '',
      'transparent': true,
      'depthWrite': false,
      'order': 0,
      'side': 0,
      'castShadow': false,
      'localMatrix': Mat4.compose(kCoverLabelPosition, Vec3.zero).toJson(),
      'base': _copyMap(label),
      'high': null,
      'low': null,
      'hasMap': true,
      'interpolateAttenuation': false,
    });
    return SceneSurfaceAssets(
      actorTemplate: actorTemplate,
      instances: instances,
      pickingMeshes: pickingMeshes,
      boundsCenter: boundsCenter,
      boundsRadius: boundsRadius,
      revision: revision,
    );
  }

  /// SceneAppearance.cpp:9,145 — actorTemplate rows in build order.
  final List<Map<String, Object?>> actorTemplate;

  /// SceneAppearance.cpp:13,167 — the instanced descriptors (id == mesh + 10).
  final List<Map<String, Object?>> instances;

  /// SceneAppearance.cpp:14,79 — every non-Carbon_Ink mesh index.
  final List<int> pickingMeshes;

  /// SceneAppearance.h:15-16 / SceneAppearance.cpp:171 — the actor cull sphere.
  final Vec3 boundsCenter;
  final double boundsRadius;

  /// SceneAppearance.h:12 / SceneAppearance.cpp:58 — the template code.
  final int revision;
}

/// SceneAppearance.cpp:56-58 — the process-wide template counter.
int _nextSurfaceRevision = 1;

/// SceneAppearance.cpp:33-52 — material(source).
Map<String, Object?> _material(Map<String, Object?> source) {
  final Map<String, Object?> physical = _asMap(source['pbrMetallicRoughness']);
  final Map<String, Object?> extensions = _asMap(source['extensions']);
  final List<Object?> base = _asList(physical['baseColorFactor']);
  // SceneAppearance.cpp:36-39 — a missing baseColorFactor becomes opaque white.
  final List<Object?> factors = base.length >= 4 ? base : const <Object?>[1, 1, 1, 1];
  return <String, Object?>{
    'color': <Object?>[factors[0], factors[1], factors[2]],
    'roughness': _asDouble(physical['roughnessFactor'], kMaterialDefaultFactor),
    'metalness': _asDouble(physical['metallicFactor'], kMaterialDefaultFactor),
    'transmission':
        _asDouble(_asMap(extensions['KHR_materials_transmission'])['transmissionFactor']),
    'thickness': _asDouble(_asMap(extensions['KHR_materials_volume'])['thicknessFactor']),
    'ior': _asDouble(_asMap(extensions['KHR_materials_ior'])['ior'], kMaterialDefaultIor),
    'attenuation': <double>[1, 1, 1],
    'attenuationDistance': kAttenuationDistanceInfinite,
    // SceneAppearance.cpp:49 — base.at(3). A malformed 3-component factor has no alpha
    // in Qt either; the fallback keeps the glTF default (opaque).
    'opacity': base.length >= 4 ? base[3] : 1,
    'clearcoat': 0,
    'clearcoatRoughness': 0,
  };
}

// ---------------------------------------------------------------------------
// Instanced cells — NativeSceneUpdate.cpp:9-19,237-274,322 and
// NativeSceneFrame.cpp:65-78.
// ---------------------------------------------------------------------------

/// NativeScene.cpp:63-71 — the canonical 5 lane x 40 record grid.
///
/// select refuses anything outside 0..39 (NativeScene.cpp:89), and a record with
/// index i sits on row 12 + i (NativeScene.cpp:67), so the wall domain is rows 12..51
/// on lanes 0..4. This is the grid actors are addressed on; it is deliberately NOT the
/// drawn set — the drawn set comes from visibleCells (scene_math) or from the
/// 160-cell fixed list (NativeSceneUpdate.cpp:231-238).
List<SceneCell> wallGridCells() {
  final List<SceneCell> cells = <SceneCell>[];
  for (int lane = 0; lane < kLaneCount; ++lane) {
    for (int index = 0; index < kRecordsPerLane; ++index) {
      cells.add(SceneCell(lane, kLaneRowOrigin + index));
    }
  }
  return cells;
}

/// One drawn cell instance: the cell, its world matrix and its theme.
///
/// NativeSceneUpdate.cpp:256-274 builds the matrix from the tracked cell position, the
/// field height, the hover lift, the entrance/rail offset and the slope-derived X
/// rotation; the theme is sampled per cell at :272.
class SceneCellInstance {
  const SceneCellInstance({required this.cell, required this.matrix, required this.theme});

  final SceneCell cell;
  final Mat4 matrix;
  final double theme;

  /// NativeSceneUpdate.cpp:17-19 — quint32(quint16(lane)) << 16 | quint16(row).
  ///
  /// Binding the identity to the grid coordinate (not the list index) is what keeps
  /// motion vectors stable when the draw order is rewritten by the depth sort at
  /// :277-321.
  int get instanceId => ((cell.lane & 0xffff) << 16) | (cell.row & 0xffff);
}

/// NativeSceneUpdate.cpp:256-264 — the per-instance model matrix, with the X/Z half
/// taken from [trackedCellPosition] so the rail maths is never duplicated.
///
/// lift is the field height plus the hover lift (NativeSceneUpdate.cpp:257), slope is
/// field(row + 0.5, lane) - field(row - 0.5, lane) (:263) and the X rotation is
/// slope * 0.024 * (1 - detail) (:264).
Mat4 cellInstanceMatrix(
  SceneCell cell, {
  required double trackX,
  required double trackZ,
  required double lift,
  required double slope,
  required double detail,
}) {
  final Vec3 position =
      trackedCellPosition(cell, trackX: trackX, trackZ: trackZ) + Vec3(0, lift, 0);
  return Mat4.compose(position, Vec3(slope * 0.024 * (1 - detail), 0, 0));
}

/// NativeSceneUpdate.cpp:239-322 — the payload every instanced draw shares.
class SceneInstancePayload {
  SceneInstancePayload._(this.instances, this.matrices, this.themes, this.ids);

  /// The instances in draw order (front to back).
  final List<SceneCellInstance> instances;

  /// count * 64 bytes: one column-major Float32 matrix per instance
  /// (NativeSceneUpdate.cpp:270, NativeSceneFrame.cpp:76).
  final Uint8List matrices;

  /// count * 4 bytes: one Float32 theme per instance (NativeSceneUpdate.cpp:272-273).
  final Uint8List themes;

  /// count grid identities (NativeSceneUpdate.cpp:271).
  final List<int> ids;

  /// NativeSceneFrame.cpp:70 — count = m_drawnCells.size().
  int get count => instances.length;
}

/// NativeSceneUpdate.cpp:277-321 — opaque instances are ordered front to back so
/// early-z rejects occluded fragments; the order cannot change the opaque result.
///
/// Qt uses std::stable_sort over squared camera distance (:287-288); Dart's List.sort
/// is not stable, so equal distances fall back to the original index, which reproduces
/// the stable permutation exactly.
List<int> instanceDepthOrder(List<SceneCellInstance> instances, Vec3 eye) {
  final List<int> order =
      List<int>.generate(instances.length, (int index) => index, growable: false);
  double distance(int index) {
    final Float64List values = instances[index].matrix.values;
    final double dx = values[12] - eye.x;
    final double dy = values[13] - eye.y;
    final double dz = values[14] - eye.z;
    return dx * dx + dy * dy + dz * dz;
  }

  order.sort((int left, int right) {
    final int byDistance = distance(left).compareTo(distance(right));
    return byDistance != 0 ? byDistance : left.compareTo(right);
  });
  return order;
}

/// NativeSceneUpdate.cpp:239-274,322 — narrow every matrix/theme to the GPU layout
/// and publish the shared payload.
SceneInstancePayload buildInstancePayload({
  required List<SceneCellInstance> instances,
  required Vec3 eye,
}) {
  final List<int> order = instanceDepthOrder(instances, eye);
  // NativeSceneUpdate.cpp:290-296 — when the order is already front to back Qt skips
  // the rebuild; the observable payload is identical either way.
  bool reordered = false;
  for (int index = 0; index < order.length; ++index) {
    if (order[index] != index) {
      reordered = true;
      break;
    }
  }
  final List<SceneCellInstance> sorted = reordered
      ? <SceneCellInstance>[for (final int index in order) instances[index]]
      : instances;
  final Float32List matrices = Float32List(sorted.length * 16);
  final Float32List themes = Float32List(sorted.length);
  final List<int> ids = <int>[];
  for (int slot = 0; slot < sorted.length; ++slot) {
    final Float64List values = sorted[slot].matrix.values;
    for (int index = 0; index < 16; ++index) {
      matrices[slot * 16 + index] = values[index];
    }
    themes[slot] = sorted[slot].theme;
    ids.add(sorted[slot].instanceId);
  }
  return SceneInstancePayload._(
    sorted,
    matrices.buffer.asUint8List(matrices.offsetInBytes, matrices.lengthInBytes),
    themes.buffer.asUint8List(themes.offsetInBytes, themes.lengthInBytes),
    ids,
  );
}

/// The instanced half of the draw list: the per-id draw objects plus the buffers the
/// renderer binds.
class SceneInstancedPass {
  SceneInstancedPass({required this.draws, required this.buffers, required this.payload});

  /// One entry per descriptor, in descriptor order (NativeSceneFrame.cpp:66-78).
  final List<Map<String, Object?>> draws;

  /// drawBuffers[id] for every instanced id; all of them carry the same payload
  /// (NativeSceneFrame.cpp:65,76).
  final SceneDrawBuffers buffers;

  final SceneInstancePayload payload;

  /// NativeSceneFrame.cpp:70 — the same value written into every count.
  int get count => payload.count;
}

/// NativeSceneFrame.cpp:65-78 — overlay the frame-time fields on each instanced
/// descriptor and hand every id the shared payload.
///
/// instanceDescriptors is m_appearance.instances (SceneAppearance.cpp:167), cells is
/// the drawn set produced by the update pass (NativeSceneUpdate.cpp:251-274) and theme
/// is the frame theme that overrides the descriptor's own theme = 0
/// (SceneAppearance.cpp:166 -> NativeSceneFrame.cpp:75).
SceneInstancedPass drawInstancedCells({
  required List<Map<String, Object?>> instanceDescriptors,
  required List<SceneCellInstance> cells,
  required Vec3 eye,
  required double theme,
}) {
  final SceneInstancePayload payload = buildInstancePayload(instances: cells, eye: eye);
  final List<Map<String, Object?>> draws = <Map<String, Object?>>[];
  final SceneDrawBuffers buffers = <int, SceneDrawData>{};
  for (final Map<String, Object?> descriptor in instanceDescriptors) {
    final Map<String, Object?> draw = Map<String, Object?>.of(descriptor);
    final int id = _asInt(draw['id']);
    draw['count'] = payload.count;
    draw['matrices'] = <Object?>[];
    draw['themes'] = <Object?>[];
    draw['matrixBuffer'] = -1;
    draw['themeBuffer'] = -1;
    draw['theme'] = theme;
    // Qt assigns the same QByteArray handle to every id (implicit sharing); a fresh
    // SceneDrawData per id keeps that per-id ownership without copying the bytes.
    buffers[id] = SceneDrawData(
      matrices: payload.matrices,
      themes: payload.themes,
      ids: payload.ids,
    );
    draws.add(draw);
  }
  return SceneInstancedPass(draws: draws, buffers: buffers, payload: payload);
}

// ---------------------------------------------------------------------------
// Assembly-view template — NativeViewer.cpp:8-11,296-335.
// ---------------------------------------------------------------------------

/// NativeViewer.cpp:9-11 — one row of the assembly parts table: the assemblyPart name
/// and the depth the spread pushes it out by.
class AssemblyPart {
  const AssemblyPart(this.name, this.depth);

  final String name;
  final double depth;
}

/// NativeViewer.cpp:9-11 — the part order is the template order.
const List<AssemblyPart> kAssemblyParts = <AssemblyPart>[
  AssemblyPart('fasteners', 2.75),
  AssemblyPart('cover', 1.85),
  AssemblyPart('optical-lenses', 0.75),
  AssemblyPart('optical-core', -0.15),
  AssemblyPart('substrate', -1.1),
  AssemblyPart('carrier', -2.05),
];

/// NativeViewer.cpp:296-335 — the assembly template rows plus the single viewer actor
/// the same block appends.
class SceneTemplateParts {
  SceneTemplateParts({required this.parts, required this.actor, required this.actorState});

  /// base["actorTemplate"] — NativeViewer.cpp:325.
  final List<Map<String, Object?>> parts;

  /// base["actors"] — one actor, id 100000, selected, no music key
  /// (NativeViewer.cpp:326-327).
  final Map<String, Object?> actor;

  /// The matching 20-double state: root at {0, -1.85, 0}, quality 1, clarity and theme
  /// from the viewer springs (NativeViewer.cpp:328-334).
  final SceneActorState actorState;
}

/// NativeViewer.cpp:296-323 — the assembly template.
///
/// The outer loop walks [kAssemblyParts] in table order; the inner loop walks
/// mesh = 0..assets.length where mesh == assets.length is the synthetic cover label
/// entry (name empty, assemblyPart "cover", NativeViewer.cpp:299-301). The first base
/// row with the same label flag — and, for real parts, the same name — is cloned, so
/// the row order is the parts table order, not the mesh order.
///
/// spread drives each row's local Z (position.z += depth * spread.value,
/// NativeViewer.cpp:317); clarity and theme never touch the rows themselves — in Qt
/// they are the viewer actor's state slots 17/18 (:332-333), which is why they are
/// returned through [SceneTemplateParts.actorState] instead of being dropped.
SceneTemplateParts templateParts({
  required double spread,
  required double clarity,
  required double theme,
  required List<Map<String, Object?>> assets,
  required List<Map<String, Object?>> template,
}) {
  final List<Map<String, Object?>> parts = <Map<String, Object?>>[];
  for (final AssemblyPart part in kAssemblyParts) {
    for (int mesh = 0; mesh <= assets.length; ++mesh) {
      final bool label = mesh == assets.length;
      final Map<String, Object?> entry =
          label ? <String, Object?>{'name': '', 'assemblyPart': 'cover'} : _asMap(assets[mesh]);
      if (_asString(entry['assemblyPart']) != part.name) {
        continue;
      }
      for (final Map<String, Object?> value in template) {
        if (_asBool(value['label']) != label) {
          continue;
        }
        if (!label && _asString(value['name']) != _asString(entry['name'])) {
          continue;
        }
        final Map<String, Object?> row = Map<String, Object?>.of(value);
        row['partIndex'] = parts.length;
        row['mesh'] = label ? -1 : mesh;
        row['asset'] = label ? kAssetKey : 'assembly';
        // NativeViewer.cpp:314 — the cover sheet is drawn double sided in the assembly
        // view; other parts keep the template side.
        row['side'] = label ? 2 : _asInt(value['side']);
        row['castShadow'] = false;
        final Vec3 base = label ? kCoverLabelPosition : Vec3.zero;
        row['localMatrix'] =
            Mat4.compose(Vec3(base.x, base.y, base.z + part.depth * spread), Vec3.zero).toJson();
        parts.add(row);
        break;
      }
    }
  }
  return SceneTemplateParts(
    parts: parts,
    actor: <String, Object?>{
      'id': kViewerActorId,
      'musicKey': null,
      'selected': true,
      'shadowOnly': false,
    },
    actorState: SceneActorState(
      matrix: Mat4.compose(kViewerCardRoot, Vec3.zero),
      quality: 1,
      clarity: clarity,
      theme: theme,
    ),
  );
}

// ---------------------------------------------------------------------------
// Actors — NativeScene.h:83-96 and NativeSceneFrame.cpp:121-161.
// ---------------------------------------------------------------------------

/// NativeScene.h:83-96 — one native actor root.
///
/// The defaults mirror the header initialisers exactly (id 2, cell {2, 12}, lift
/// spring at rest, ageing 0) so a fresh actor is the same object Qt starts with.
class SceneActor {
  SceneActor({
    this.id = 2,
    this.cell = const SceneCell(2, 12),
    Vec3? position,
    Vec3? rotation,
    Spring? lift,
    this.returnY,
    this.quality = 0,
    this.clarity = 0,
    this.theme = 0,
    this.musicKey = '',
    this.age = 0,
  })  : position = position ?? Vec3.zero,
        rotation = rotation ?? Vec3.zero,
        lift = lift ?? Spring();

  final int id;
  final SceneCell cell;
  final Vec3 position;
  final Vec3 rotation;

  /// SceneMotion::Spring — mutated by the update pass only
  /// (NativeSceneUpdate.cpp:175,208).
  final Spring lift;

  /// NativeScene.h:89 — set while a card is still finding its height.
  final double? returnY;

  final double quality;
  final double clarity;
  final double theme;

  /// NativeScene.h:93 — empty serialises as JSON null (NativeSceneFrame.cpp:150).
  final String musicKey;

  /// NativeScene.h:95 — seconds spent returning.
  final double age;
}

/// NativeSceneFrame.cpp:121-161 — the actor half of the frame.
class SceneActorPass {
  SceneActorPass({
    required this.actors,
    required this.states,
    required this.kept,
    required this.culledCards,
    required this.shadowCards,
  });

  /// NativeSceneFrame.cpp:149-153 — the frame's actors array.
  final List<Map<String, Object?>> actors;

  /// NativeSceneFrame.cpp:142-148 — 20 doubles per written actor, packed.
  final Uint8List states;

  /// The actors actually written (culled ones are absent), in write order.
  final List<SceneActor> kept;

  /// NativeSceneFrame.cpp:136 — dropped entirely.
  final int culledCards;

  /// NativeSceneFrame.cpp:139 — kept, but drawn shadow-only.
  final int shadowCards;
}

/// NativeSceneFrame.cpp:122-161 — turn the actor roots into the frame's actor list
/// plus the packed states.
///
/// selected is m_actor and is never culled (:158 add(m_actor, true)); returning is
/// m_returning in vector order (:159-161). The frustum comes from the full projection
/// (Frustum(m_projection * m_view), :122), not the cull projection, and an actor
/// leaves the frame only when it misses both the camera frustum AND the fixed light
/// window (:130-140).
SceneActorPass buildActors({
  required SceneActor selected,
  required List<SceneActor> returning,
  required Mat4 projection,
  required Mat4 view,
  required bool drawCulling,
  required Vec3 boundsCenter,
  required double boundsRadius,
}) {
  final Frustum cameraFrustum = Frustum(projection * view);
  final Mat4 lightView = Mat4.camera(kShadowLightEye, Vec3.zero).inverse();
  final List<Map<String, Object?>> actors = <Map<String, Object?>>[];
  final List<SceneActor> kept = <SceneActor>[];
  final List<SceneActorState> states = <SceneActorState>[];
  int culledCards = 0;
  int shadowCards = 0;

  void add(SceneActor actor, bool isSelected) {
    final Mat4 matrix = Mat4.compose(actor.position, actor.rotation);
    bool shadowOnly = false;
    if (!isSelected && drawCulling) {
      final Vec3 center = matrix.point(boundsCenter);
      final double radius = boundsRadius + kShadowRadiusMargin;
      if (!cameraFrustum.intersectsSphere(center, radius)) {
        final Vec3 light = lightView.point(center);
        if (light.x.abs() > kShadowLightXExtent + radius ||
            light.y.abs() > kShadowLightYExtent + radius) {
          ++culledCards;
          return;
        }
        shadowOnly = true;
        ++shadowCards;
      }
    }
    states.add(SceneActorState(
      matrix: matrix,
      quality: actor.quality,
      clarity: actor.clarity,
      theme: actor.theme,
    ));
    actors.add(<String, Object?>{
      'id': actor.id,
      'musicKey': actor.musicKey.isEmpty ? null : actor.musicKey,
      'selected': isSelected,
      'shadowOnly': shadowOnly,
    });
    kept.add(actor);
  }

  add(selected, true);
  for (final SceneActor actor in returning) {
    add(actor, false);
  }
  return SceneActorPass(
    actors: actors,
    states: packSceneActorStates(states),
    kept: kept,
    culledCards: culledCards,
    shadowCards: shadowCards,
  );
}

/// NativeSceneFrame.cpp:57,66-78,154-156 — the draw ids kept after the frame is built.
///
/// The floor is always retained (:57), every instanced id is retained (:66-78) and
/// every template part of every written actor is retained under the negative card id
/// -(actor.id * 256 + partIndex + 1) (:155). Culled actors contribute nothing because
/// they return before the part loop (:135-137).
///
/// The per-part draws themselves belong to the card expansion (NativeCards), so this
/// set is published for that step rather than used here.
Set<int> retainedDrawIds({
  required Iterable<int> instancedIds,
  required SceneActorPass pass,
  required List<Map<String, Object?>> actorTemplate,
}) {
  final Set<int> retained = <int>{kFloorDrawId};
  retained.addAll(instancedIds);
  for (final SceneActor actor in pass.kept) {
    for (final Map<String, Object?> part in actorTemplate) {
      retained.add(-(actor.id * 256 + _asInt(part['partIndex']) + 1));
    }
  }
  return retained;
}

// ---------------------------------------------------------------------------
// Frame assembly — NativeSceneFrame.cpp:56-214.
// ---------------------------------------------------------------------------

/// Raised when a frame would violate the scene load contract.
///
/// A frame must always carry the three loads — floor, instanced cells and actors
/// (NativeSceneFrame.cpp:59-78,120-166). A scene that returns an empty draw list
/// silently renders a static background, which is the failure this guard exists to make
/// loud.
class SceneSurfaceError extends Error {
  SceneSurfaceError(this.message);

  final String message;

  @override
  String toString() => 'SceneSurfaceError: ' + message;
}

void _requireLoads(List<Map<String, Object?>> draws, SceneActorPass pass) {
  final bool floor = draws.any((Map<String, Object?> draw) => draw['floor'] == true);
  final bool instanced = draws.any((Map<String, Object?> draw) =>
      draw['instanced'] == true && _asInt(draw['count']) > 0);
  if (!floor) {
    throw SceneSurfaceError(
        'frame has no floor draw (id 1, NativeSceneFrame.cpp:62): the scene would '
        'render without a ground plane');
  }
  if (!instanced) {
    throw SceneSurfaceError(
        'frame has no instanced cell draw: NativeSceneUpdate.cpp:237-238 produced no '
        'drawn cells (visibleCells returned an empty set, or the fixed 160-cell list '
        'was not built), so the wall would be a static background');
  }
  if (pass.actors.isEmpty) {
    throw SceneSurfaceError(
        'frame has no actor: NativeSceneFrame.cpp:158 always writes m_actor, so an '
        'empty actor pass means the selected card was never supplied');
  }
}

/// NativeSceneFrame.cpp:56-214 — assemble one scene frame.
///
/// The assembly order is Qt's: the floor draw followed by every instanced draw
/// (:59-78), the returning summary (:79-86), the base frame literal (:87-119), the
/// actor pass (:120-166) and the stats block (:195-213). Serialisation is
/// [SceneFrame]'s job — nothing here re-implements it.
///
/// instances is the output of [drawInstancedCells] for the drawn cells,
/// actorTemplate/appearanceRevision come from [SceneSurfaceAssets]
/// (NativeSceneFrame.cpp:164-165) and selectedCell is the file cell of selectedIndex
/// (Qt fileLocation(m_selected), used by the stats slot at :206).
SceneFrame surfaceFrame({
  required String mode,
  required int selectedIndex,
  required SceneCell selectedCell,
  required Mat4 view,
  required Mat4 projection,
  required Mat4 aoProjection,
  required Vec3 eye,
  required double theme,
  required double fogNear,
  required double fogFar,
  required double detail,
  required double time,
  required Map<String, Object?> boot,
  required double focus,
  required double aperture,
  required double width,
  required double height,
  required double fieldOfView,
  required Map<String, Object?> decryption,
  required List<Map<String, Object?>> pulses,
  required double clearance,
  required SceneCell coordinateOrigin,
  required bool holdingArchive,
  required int archiveCandidates,
  required SceneActor selected,
  required List<SceneActor> returning,
  required List<Map<String, Object?>> actorTemplate,
  required int appearanceRevision,
  required Vec3 boundsCenter,
  required double boundsRadius,
  required SceneInstancedPass instances,
  SceneFloorPass? floor,
  bool drawCulling = true,
  int pendingAnimations = 0,
  int pointerCursor = 0,
  bool reference = false,
  int returningPartNodes = 0,
  int globalSubdued = 0,
}) {
  // NativeSceneFrame.cpp:60-64 — Qt builds the floor inline in emitFrame.
  final SceneFloorPass floorPass = floor ?? drawFloor(theme: theme);
  final SceneActorPass actorPass = buildActors(
    selected: selected,
    returning: returning,
    projection: projection,
    view: view,
    drawCulling: drawCulling,
    boundsCenter: boundsCenter,
    boundsRadius: boundsRadius,
  );
  final List<Map<String, Object?>> draws = <Map<String, Object?>>[
    floorPass.draw,
    ...instances.draws,
  ];
  _requireLoads(draws, actorPass);

  // NativeSceneFrame.cpp:79-86 — the returning summary is computed from m_returning,
  // i.e. the non-selected actors.
  final List<String> returningKeys = <String>[];
  double returningAgeMax = 0;
  for (final SceneActor actor in returning) {
    if (actor.musicKey.isNotEmpty) {
      returningKeys.add(actor.musicKey);
    }
    if (actor.age > returningAgeMax) {
      returningAgeMax = actor.age;
    }
  }

  final SceneFrame frame = SceneFrame.base(
    mode: mode,
    // NativeSceneFrame.cpp:97 — the integer selection index, not a cell.
    selected: selectedIndex,
    view: view,
    projection: projection,
    aoProjection: aoProjection,
    eye: eye,
    theme: theme,
    fogNear: fogNear,
    fogFar: fogFar,
    detail: detail,
    time: time,
    boot: boot,
    focus: focus,
    aperture: aperture,
    pendingAnimations: pendingAnimations,
    pointerCursor: pointerCursor,
    reference: reference,
    // :98-99 seed both counters and :162-163 overwrite them with the actor pass's own
    // numbers.
    culledCards: 0,
    shadowCards: 0,
    returningCards: returning.length,
    returningPartNodes: returningPartNodes,
    globalSubdued: globalSubdued,
    returningMusicKeys: returningKeys,
    returningAgeMax: returningAgeMax,
    draws: draws,
  );
  frame.attachActorPass(
    culledCards: actorPass.culledCards,
    shadowCards: actorPass.shadowCards,
    actorTemplate: actorTemplate,
    appearanceRevision: appearanceRevision.toDouble(),
    actors: actorPass.actors,
  );
  // :195-213 — the stats block, entirely delegated to scene_frame.dart.
  frame.stats = buildSceneStats(
    projection: projection,
    view: view,
    actorPosition: selected.position,
    actorRotation: selected.rotation,
    actorCell: selected.cell,
    selectedCell: selectedCell,
    // NativeSceneFrame.cpp:206 — fileLocation(selected).lane * 32 + column row.
    selectedSlot: selectedCell.lane * 32 + selectedCell.row,
    eye: eye,
    width: width,
    height: height,
    fieldOfView: fieldOfView,
    decryption: decryption,
    // :207 — archiveCount is the drawn-cell count, i.e. the instance count.
    archiveCount: instances.count,
    archiveCandidates: archiveCandidates,
    returningFiles: returning.length,
    pulses: pulses,
    clearance: clearance,
    coordinateOrigin: coordinateOrigin,
    holdingArchive: holdingArchive,
  );
  return frame;
}
