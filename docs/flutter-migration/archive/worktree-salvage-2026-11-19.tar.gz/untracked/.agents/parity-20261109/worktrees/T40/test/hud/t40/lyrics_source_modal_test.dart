import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/lyrics_source_modal.dart';

// ---------------------------------------------------------------------------
// Qt reference constants.
//
// Every literal here is copied from the Qt source, never from the Dart port, so
// the assertions fail if the port drifts:
//   Qt/src/NativeHud.cpp:145-148   modalBounds("lyrics-source")
//   Qt/src/NativeHudModal.cpp:142-161  the popover branch
//   Qt/src/NativeHud.cpp:10-15, 37-43, 102-120  ink/fill/text/hit/button
//   Qt/src/UiMotion.h:24-42, UiMotion.cpp:7-22, 86-120  SurfaceMotion
// ---------------------------------------------------------------------------

/// NativeHud stage width used by the Qt HUD (1920x1080 landscape stage).
const double _qtStageWidth = 1920;

/// NativeHud stage height; only used to prove that no full-screen op exists.
const double _qtStageHeight = 1080;

/// width * 0.56 + 156 at the Qt design width.
const double _qtPanelX = 1920 * 0.56 + 156;

/// modalBounds y.
const double _qtPanelY = 674;

/// modalBounds width.
const double _qtPanelW = 232;

/// modalBounds height.
const double _qtPanelH = 232;

/// Row inset from the panel edge (NativeHudModal.cpp:153-156).
const double _qtRowInset = 10;

/// First row offset from the panel top (NativeHudModal.cpp:155).
const double _qtRowTop = 11;

/// Row height (NativeHudModal.cpp:155).
const double _qtRowH = 42;

/// Distance between two row tops (NativeHudModal.cpp:155).
const double _qtRowPitch = 42;

/// Row width: bounds.width - 20 (NativeHudModal.cpp:155).
const double _qtRowW = 232 - 20;

/// Button text size for all five rows (NativeHudModal.cpp:156).
const double _qtButtonSize = 15;

/// min(10, rowWidth / 8) at the Qt width (NativeHud.cpp:113).
const double _qtButtonInset = 10;

/// Text baseline offset inside a button (NativeHud.cpp:118).
const double _qtTextDy = (42 - 15) / 2 - 4;

/// panelFill, light (NativeHudModal.cpp:146).
const List<Object?> _qtLightPanelFill = <Object?>[0.929, 0.922, 0.894, 1];

/// panelFill, dark (NativeHudModal.cpp:146).
const List<Object?> _qtDarkPanelFill = <Object?>[
  0.15,
  0.15,
  0.15,
  1,
  'calibratedWhite',
];

/// Modal-control tint, light (NativeHud.cpp:116).
const List<Object?> _qtLightButtonTint = <Object?>[0.44, 0.49, 0.36, 0.1];

/// Modal-control tint, dark (NativeHud.cpp:116).
const List<Object?> _qtDarkButtonTint = <Object?>[0.55, 0.59, 0.46, 0.13];

/// ink(), light (NativeHud.cpp:13-14).
const List<Object?> _qtLightInk = <Object?>[
  0.08,
  0.085,
  0.075,
  1,
  'calibratedRGB',
];

/// ink(), dark (NativeHud.cpp:11-12).
const List<Object?> _qtDarkInk = <Object?>[
  0.92,
  0.92,
  0.92,
  1,
  'calibratedWhite',
];

/// sources order (NativeHudModal.cpp:149).
const List<String> _qtIds = <String>[
  'auto',
  'local',
  'netease',
  'qq',
  'kugou',
];

/// labels order (NativeHudModal.cpp:150).
const List<String> _qtLabels = <String>[
  '自动（本地优先）',
  '本地歌词',
  '网易云音乐',
  'QQ 音乐',
  '酷狗音乐',
];

/// Selection prefix (NativeHudModal.cpp:153).
const String _qtCheck = '✓ ';

/// Action prefix (NativeHudModal.cpp:156).
const String _qtActionPrefix = 'player:lyrics-source:';

/// Escape target (NativeHudController.cpp:919).
const String _qtCloseAction = 'close-modal';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Deterministic stand-in for NativeHud's glyph metrics.
///
/// width = text.length * size * scale + tracking, recorded so tests can prove
/// that fit() measured through the injected hook instead of guessing.
class _Measure {
  _Measure(this.scale);

  /// Width per character, as a multiple of the font size.
  final double scale;

  /// Every measurement request, in call order:
  /// [text, size, weight, tracking].
  final List<List<Object?>> calls = <List<Object?>>[];

  double call(String text, double size, String? weight, double tracking) {
    calls.add(<Object?>[text, size, weight, tracking]);
    return text.length * size * scale + tracking;
  }
}

/// Identity-ish spy hook: shifts by a fixed delta and records the input rect.
class _RectSpy {
  _RectSpy(this.dx, this.dy);

  final double dx;
  final double dy;

  /// Recorded [x, y, w, h] inputs, in call order.
  final List<List<double>> inputs = <List<double>>[];

  List<double> call(double x, double y, double w, double h) {
    inputs.add(<double>[x, y, w, h]);
    return <double>[x + dx, y + dy, w, h];
  }
}

String _labelAt(int index, String selected) =>
    (selected == _qtIds[index] ? _qtCheck : '') + _qtLabels[index];

/// The full Qt op stream for a settled frame, written straight from the Qt
/// branch (order: save, alpha, translate, panel fill, 5x(fill, text), restore).
List<List<Object?>> _qtCommands({
  String selected = 'auto',
  double opacity = 0,
  double offset = 12,
  bool dark = false,
}) {
  final List<List<Object?>> out = <List<Object?>>[];
  out.add(const <Object?>['save']);
  out.add(<Object?>['alpha', opacity]);
  out.add(<Object?>['translate', 0, offset]);
  out.add(<Object?>[
    'fill',
    dark ? _qtDarkPanelFill : _qtLightPanelFill,
    _qtPanelX,
    _qtPanelY,
    _qtPanelW,
    _qtPanelH,
  ]);
  for (int index = 0; index < _qtIds.length; index++) {
    final double x = _qtPanelX + _qtRowInset;
    final double y = _qtPanelY + _qtRowTop + index * _qtRowPitch;
    out.add(<Object?>[
      'fill',
      dark ? _qtDarkButtonTint : _qtLightButtonTint,
      x,
      y,
      _qtRowW,
      _qtRowH,
    ]);
    out.add(<Object?>[
      'text',
      _labelAt(index, selected),
      x + _qtButtonInset,
      y + _qtTextDy,
      _qtButtonSize,
      'regular',
      0,
      dark ? _qtDarkInk : _qtLightInk,
    ]);
  }
  out.add(const <Object?>['restore']);
  return out;
}

/// The Qt hit table for the popover: five rows, six fields, draw order.
List<List<Object?>> _qtHits({String selected = 'auto'}) {
  final List<List<Object?>> out = <List<Object?>>[];
  for (int index = 0; index < _qtIds.length; index++) {
    out.add(<Object?>[
      _qtPanelX + _qtRowInset,
      _qtPanelY + _qtRowTop + index * _qtRowPitch,
      _qtRowW,
      _qtRowH,
      _qtActionPrefix + _qtIds[index],
      _labelAt(index, selected),
    ]);
  }
  return out;
}

/// Builds the port at the Qt design width with a non-truncating measurer.
LyricsSourceModal _modal({
  double width = _qtStageWidth,
  _Measure? measure,
  bool dark = false,
  bool reduced = false,
  bool closing = false,
  double opacity = 0,
  double offset = 12,
  String localSource = 'auto',
  LyricsSourceRectHook? rectHook,
}) {
  final _Measure real = measure ?? _Measure(0.5);
  return LyricsSourceModal(
    width: width,
    measureText: real.call,
    dark: dark,
    reduced: reduced,
    closing: closing,
    opacity: opacity,
    offset: offset,
    localSource: localSource,
    rectHook: rectHook ?? _identity,
  );
}

List<double> _identity(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

void main() {
  // -------------------------------------------------------------------------
  // 1. Stream shape: exactly 15 commands and exactly 5 hits.
  // -------------------------------------------------------------------------
  group('frame shape', () {
    test('emits 15 commands: save, alpha, translate, panel, 5 fills, 5 texts, '
        'restore', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.commands.length, 15);
      expect(frame.commands.first, <Object?>['save']);
      expect(frame.commands.last, <Object?>['restore']);
      expect(
        frame.commands.map((List<Object?> c) => c.first).toList(),
        <String>[
          'save',
          'alpha',
          'translate',
          'fill',
          'fill',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'restore',
        ],
      );
    });

    test('emits exactly 5 hits, one per row, in draw order', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.hits.length, 5);
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        <String>[
          'player:lyrics-source:auto',
          'player:lyrics-source:local',
          'player:lyrics-source:netease',
          'player:lyrics-source:qq',
          'player:lyrics-source:kugou',
        ],
      );
    });

    test('contains no clip, image or art op (popover draws only fills/text)', () {
      final LyricsSourceModalFrame frame = _modal().build();
      final List<String> ops =
          frame.commands.map((List<Object?> c) => c.first! as String).toList();
      expect(ops.contains('clip'), isFalse);
      expect(ops.contains('image'), isFalse);
      expect(ops.contains('art'), isFalse);
      expect(ops.contains('scale'), isFalse);
    });

    test('build() is pure: equal content, fresh lists, no shared state', () {
      final LyricsSourceModal modal = _modal();
      final LyricsSourceModalFrame first = modal.build();
      final LyricsSourceModalFrame second = modal.build();
      expect(first.commands, second.commands);
      expect(first.hits, second.hits);
      expect(identical(first.commands, second.commands), isFalse);
      expect(identical(first.hits, second.hits), isFalse);
      expect(identical(first.commands[3], second.commands[3]), isFalse);
    });

    test('closing and reduced do not change the drawn frame '
        '(NativeHud.cpp:263-266 keeps drawing until the motion settles)', () {
      final LyricsSourceModalFrame settled = _modal().build();
      final LyricsSourceModalFrame closing =
          _modal(closing: true, reduced: true).build();
      expect(closing.commands, settled.commands);
      expect(closing.hits, settled.hits);
    });
  });

  // -------------------------------------------------------------------------
  // 2. Whole-stream equality against the Qt op order and Qt literals.
  // -------------------------------------------------------------------------
  group('command stream matches Qt', () {
    test('light theme, auto selected, opacity 0 / offset 12', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.commands, _qtCommands());
    });

    test('dark theme uses the calibratedWhite panel fill and dark ink', () {
      final LyricsSourceModalFrame frame = _modal(dark: true).build();
      expect(frame.commands, _qtCommands(dark: true));
    });

    test('injected opacity and offset are echoed verbatim', () {
      final LyricsSourceModalFrame frame =
          _modal(opacity: 0.42, offset: 5.5).build();
      expect(frame.commands[1], <Object?>['alpha', 0.42]);
      expect(frame.commands[2], <Object?>['translate', 0, 5.5]);
    });

    test('alpha precedes translate, translate precedes the panel fill '
        '(NativeHudModal.cpp:84, :144-146)', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.commands[0][0], 'save');
      expect(frame.commands[1][0], 'alpha');
      expect(frame.commands[2][0], 'translate');
      expect(frame.commands[3][0], 'fill');
      expect(frame.commands[14][0], 'restore');
    });
  });

  // -------------------------------------------------------------------------
  // 3. Panel geometry and the deliberate absence of scrim / catcher / header.
  // -------------------------------------------------------------------------
  group('panel geometry', () {
    test('panel fill is bounds = {width * 0.56 + 156, 674, 232, 232}', () {
      final LyricsSourceModalFrame frame = _modal().build();
      final List<Object?> fill = frame.commands[3];
      expect(fill[0], 'fill');
      expect(fill[1], _qtLightPanelFill);
      expect(fill[2] as double, closeTo(1920 * 0.56 + 156, 1e-9));
      expect(fill[3], 674.0);
      expect(fill[4], 232.0);
      expect(fill[5], 232.0);
    });

    test('panel x tracks width when the stage is not 1920 wide', () {
      final LyricsSourceModalFrame frame = _modal(width: 1280).build();
      expect(frame.commands[3][2] as double, closeTo(1280 * 0.56 + 156, 1e-9));
      expect(frame.commands[3][2] as double, closeTo(872.8000000000001, 1e-9));
      expect(frame.commands[3][3], 674.0);
      expect(frame.commands[3][4], 232.0);
      expect(frame.commands[3][5], 232.0);
    });

    test('no scrim: nothing fills the stage, nothing is 1080 tall '
        '(the scrim at NativeHudModal.cpp:163-165 belongs to the full-modal path)',
        () {
      final LyricsSourceModalFrame frame = _modal().build();
      for (final List<Object?> command in frame.commands) {
        if (command[0] != 'fill') {
          continue;
        }
        expect(command[5], isNot(_qtStageHeight));
        final bool coversStage = command[2] == 0.0 &&
            command[3] == 0.0 &&
            command[4] == _qtStageWidth;
        expect(coversStage, isFalse);
      }
      // The only fills are the panel plus the five row tints.
      expect(
        frame.commands.where((List<Object?> c) => c[0] == 'fill').length,
        6,
      );
    });

    test('no catcher: the hit table is cleared first and holds only the five '
        'rows (contrast the detail-sort catcher at NativeHudModal.cpp:128)',
        () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.hits.length, 5);
      for (final List<Object?> hit in frame.hits) {
        expect(hit[3], _qtRowH);
        expect(hit[3], isNot(_qtStageHeight));
        expect((hit[0] as double) >= _qtPanelX, isTrue);
        expect((hit[1] as double) >= _qtPanelY, isTrue);
      }
      expect(
        frame.hits.where((List<Object?> h) => h[4] == _qtCloseAction).length,
        0,
        reason: 'the popover ships no close-modal hit; Qt closes it via Escape',
      );
    });

    test('no generic header: the first text op starts at the first row, '
        'above it there is nothing but the panel fill', () {
      final LyricsSourceModalFrame frame = _modal().build();
      final int firstText = frame.commands
          .indexWhere((List<Object?> c) => c[0] == 'text');
      expect(firstText, 5);
      expect(frame.commands[firstText][3] as double,
          closeTo(674 + 11 + _qtTextDy, 1e-9));
      expect(
        frame.commands
            .where((List<Object?> c) => c[0] == 'text' && (c[3] as double) < 674)
            .length,
        0,
      );
    });

    test('panel sits 11 px above the first row and 11 px below the last',
        () {
      final double firstRowTop = _qtPanelY + 11;
      final double lastRowBottom = _qtPanelY + 11 + 4 * 42 + 42;
      expect(firstRowTop - _qtPanelY, 11);
      expect(_qtPanelY + _qtPanelH - lastRowBottom, 11);
      final LyricsSourceModalFrame frame = _modal().build();
      final List<Object?> last = frame.hits[4];
      expect(last[1] as double, closeTo(853, 1e-9));
      expect((last[1] as double) + (last[3] as double), 895);
      expect((last[1] as double) + (last[3] as double),
          lessThan(_qtPanelY + _qtPanelH));
    });
  });

  // -------------------------------------------------------------------------
  // 4. Rows: geometry, tint, text placement, fitted value.
  // -------------------------------------------------------------------------
  group('rows', () {
    test('row rect = panel.x + 10, panel.y + 11 + i*42, width - 20, 42', () {
      final LyricsSourceModalFrame frame = _modal().build();
      for (int index = 0; index < 5; index++) {
        final List<Object?> hit = frame.hits[index];
        expect(hit[0] as double, closeTo(_qtPanelX + 10, 1e-9));
        expect(hit[1] as double, closeTo(674 + 11 + index * 42, 1e-9));
        expect(hit[2], 212.0);
        expect(hit[3], 42.0);
      }
      expect(frame.hits[0][1], 685.0);
      expect(frame.hits[1][1], 727.0);
      expect(frame.hits[2][1], 769.0);
      expect(frame.hits[3][1], 811.0);
      expect(frame.hits[4][1], 853.0);
    });

    test('every row is tinted with the modal-control colour', () {
      final LyricsSourceModalFrame light = _modal().build();
      final LyricsSourceModalFrame dark = _modal(dark: true).build();
      for (int index = 0; index < 5; index++) {
        final int fillIndex = 4 + index * 2;
        expect(light.commands[fillIndex],
            <Object?>['fill', _qtLightButtonTint, _qtPanelX + 10,
                674 + 11 + index * 42, 212, 42]);
        expect(dark.commands[fillIndex][1], _qtDarkButtonTint);
      }
    });

    test('button text sits at x + inset, y + (h - size)/2 - 4 with size 15',
        () {
      final LyricsSourceModalFrame frame = _modal().build();
      for (int index = 0; index < 5; index++) {
        final List<Object?> text = frame.commands[5 + index * 2];
        final double x = _qtPanelX + 10;
        final double y = 674 + 11 + index * 42;
        expect(text[0], 'text');
        expect(text[2] as double, closeTo(x + 10, 1e-9));
        expect(text[3] as double, closeTo(y + (42 - 15) / 2 - 4, 1e-9));
        expect(text[4], 15.0);
        expect(text[5], 'regular');
        expect(text[6], 0);
        expect(text[7], _qtLightInk);
      }
    });

    test('text x is 1251.2 and first text y is 694.5 at the Qt width', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.commands[5][2] as double, closeTo(1251.2, 1e-9));
      expect(frame.commands[5][3] as double, closeTo(694.5, 1e-9));
      expect(frame.commands[13][3] as double, closeTo(862.5, 1e-9));
    });
  });

  // -------------------------------------------------------------------------
  // 5. Labels, check prefix and action strings.
  // -------------------------------------------------------------------------
  group('labels and actions', () {
    test('labels are the five Qt strings, unmarked when nothing matches', () {
      final LyricsSourceModalFrame frame = _modal().build();
      final List<Object?> values =
          frame.commands.where((List<Object?> c) => c[0] == 'text')
              .map((List<Object?> c) => c[1])
              .toList();
      expect(values, List<Object?>.from(_qtLabels));
    });

    test('the selected id gets the check prefix and the label field carries '
        'the marked text (NativeHudModal.cpp:152-154)', () {
      for (int index = 0; index < 5; index++) {
        final String id = _qtIds[index];
        final LyricsSourceModalFrame frame = _modal(localSource: id).build();
        final List<Object?> hit = frame.hits[index];
        expect(hit[5], _qtCheck + _qtLabels[index]);
        expect(hit[4], _qtActionPrefix + id);
        expect(hit[5], isNot(hit[4]));
        for (int other = 0; other < 5; other++) {
          if (other == index) {
            continue;
          }
          final List<Object?> text = frame.commands[5 + other * 2];
          expect(text[1], _qtLabels[other]);
        }
      }
    });

    test('an unknown localSource leaves every row unmarked', () {
      final LyricsSourceModalFrame frame =
          _modal(localSource: 'qqmusic').build();
      for (int index = 0; index < 5; index++) {
        expect(frame.commands[5 + index * 2][1], _qtLabels[index]);
      }
    });

    test('every emitted action is player:lyrics-source:<id> in Qt order', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        <Object?>[
          'player:lyrics-source:auto',
          'player:lyrics-source:local',
          'player:lyrics-source:netease',
          'player:lyrics-source:qq',
          'player:lyrics-source:kugou',
        ],
      );
      expect(lyricsSourceIds, _qtIds);
    });
  });

  // -------------------------------------------------------------------------
  // 6. Hit records: exactly six fields, in Qt order (NativeHud.cpp:102-109).
  // -------------------------------------------------------------------------
  group('hit records', () {
    test('each hit has exactly six fields', () {
      final LyricsSourceModalFrame frame = _modal().build();
      for (final List<Object?> hit in frame.hits) {
        expect(hit.length, 6);
      }
    });

    test('field order is x, y, width, height, action, label', () {
      final LyricsSourceModalFrame frame = _modal().build();
      for (int index = 0; index < 5; index++) {
        final List<Object?> hit = frame.hits[index];
        expect(hit[0], isA<double>());
        expect(hit[1], isA<double>());
        expect(hit[2], isA<double>());
        expect(hit[3], isA<double>());
        expect(hit[4], isA<String>());
        expect(hit[5], isA<String>());
        expect(hit[0] as double, closeTo(_qtPanelX + 10, 1e-9));
        expect(hit[1] as double, closeTo(674 + 11 + index * 42, 1e-9));
        expect(hit[2], 212.0);
        expect(hit[3], 42.0);
      }
      // Swapping the last two fields is caught: the label is never the action.
      expect(frame.hits[0][4], 'player:lyrics-source:auto');
      expect(frame.hits[0][5], '自动（本地优先）');
    });

    test('the whole hit table equals the Qt table, draw order included', () {
      expect(_modal().build().hits, _qtHits());
      expect(_modal(localSource: 'kugou').build().hits,
          _qtHits(selected: 'kugou'));
    });

    test('hits are appended after each row fill, not batched at the end', () {
      // Draw order means the hit for row i appears before the fill for row i+1
      // in Qt; the port collects hits in the same loop order, so the action
      // sequence alone is the observable contract.
      final LyricsSourceModalFrame frame = _modal().build();
      final List<Object?> actions =
          frame.hits.map((List<Object?> h) => h[4]).toList();
      expect(actions.length, 5);
      expect(actions.toSet().length, 5);
    });
  });

  // -------------------------------------------------------------------------
  // 7. fit(): truncation through the injected measurer only.
  // -------------------------------------------------------------------------
  group('fit', () {
    test('measures the full label first at size 15, regular, tracking 0', () {
      final _Measure measure = _Measure(0.5);
      _modal(measure: measure).build();
      expect(measure.calls.isNotEmpty, isTrue);
      expect(measure.calls.first,
          <Object?>['自动（本地优先）', 15.0, 'regular', 0.0]);
      // Five labels fit, so each is measured exactly once.
      expect(measure.calls.length, 5);
      expect(measure.calls.map((List<Object?> c) => c[2]).toSet(),
          <Object?>{'regular'});
      expect(measure.calls.map((List<Object?> c) => c[3]).toSet(),
          <Object?>{0.0});
    });

    test('keeps the label when it fits inside width - inset * 2 = 192', () {
      final _Measure measure = _Measure(0.5);
      final LyricsSourceModalFrame frame = _modal(measure: measure).build();
      // 8 chars * 15 * 0.5 = 60 <= 192.
      expect(frame.commands[5][1], '自动（本地优先）');
      expect(frame.commands[5][1].toString().contains('…'), isFalse);
    });

    test('binary-searches the longest fitting prefix, drops one character and '
        'appends U+2026 (NativeHud.cpp:57-74)', () {
      // Every character is 60 px wide at size 15 (scale 4.0); 192 / 60 => 3
      // characters fit, so Qt keeps left(3 - 1) = 2 and appends the ellipsis.
      final _Measure measure = _Measure(4);
      final LyricsSourceModalFrame frame = _modal(measure: measure).build();
      expect(frame.commands[5][1], '自动…');
      expect(frame.commands[5][1].toString().codeUnitAt(2), 0x2026);
      // The search really measured prefixes of the label.
      expect(measure.calls.length, greaterThan(5));
      expect(
        measure.calls.any((List<Object?> c) =>
            c[0] == '自动（本地优先）'.substring(0, 3)),
        isTrue,
      );
    });

    test('degrades to the bare ellipsis when not even one character fits', () {
      // 120 px per character: nothing fits, left(max(0, 1 - 1)) = '' + ellipsis.
      final _Measure measure = _Measure(8);
      final LyricsSourceModalFrame frame = _modal(measure: measure).build();
      expect(frame.commands[5][1], '…');
    });

    test('measures with the raw label, then emits the fitted value; the text '
        'x/y/size stay untouched by truncation', () {
      final _Measure measure = _Measure(4);
      final LyricsSourceModalFrame frame = _modal(measure: measure).build();
      final List<Object?> text = frame.commands[5];
      expect(text[1], '自动…');
      expect(text[2] as double, closeTo(1251.2, 1e-9));
      expect(text[3] as double, closeTo(694.5, 1e-9));
      expect(text[4], 15.0);
    });
  });

  // -------------------------------------------------------------------------
  // 8. Injected hooks: rectHook identity by default, never portrait pixels.
  // -------------------------------------------------------------------------
  group('rect hook', () {
    test('default is the identity, so stage coords stay exact', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(frame.commands[3][2] as double, closeTo(1231.2, 1e-9));
      expect(frame.commands[3][3], 674.0);
      expect(frame.hits[0][0] as double, closeTo(1241.2, 1e-9));
    });

    test('rectHook receives the panel and all five rows, in order', () {
      final _RectSpy spy = _RectSpy(100, 0);
      _modal(rectHook: spy.call).build();
      expect(spy.inputs.length, 6);
      expect(spy.inputs[0], <double>[1920 * 0.56 + 156, 674, 232, 232]);
      for (int index = 0; index < 5; index++) {
        expect(spy.inputs[1 + index], <double>[
          1920 * 0.56 + 156 + 10,
          674 + 11 + index * 42,
          212,
          42,
        ]);
      }
    });

    test('a hooked build moves the panel, the rows and the hits together', () {
      final LyricsSourceModalFrame frame =
          _modal(rectHook: _RectSpy(100, 7).call).build();
      expect(frame.commands[3][2] as double,
          closeTo(1920 * 0.56 + 156 + 100, 1e-9));
      expect(frame.commands[3][3], 681.0);
      expect(frame.commands[4][2] as double,
          closeTo(1920 * 0.56 + 156 + 10 + 100, 1e-9));
      expect(frame.commands[4][3], 692.0);
      expect(frame.hits[0][0] as double,
          closeTo(1920 * 0.56 + 156 + 10 + 100, 1e-9));
      expect(frame.hits[0][1], 692.0);
      // Sizes are never rescaled by the hook.
      expect(frame.hits[0][2], 212.0);
      expect(frame.hits[0][3], 42.0);
    });
  });

  // -------------------------------------------------------------------------
  // 9. Action table: exactly the Qt branches, nothing invented.
  // -------------------------------------------------------------------------
  group('action table', () {
    test('all five select actions resolve to select', () {
      for (final String id in _qtIds) {
        expect(lyricsSourceActionEffect('player:lyrics-source:' + id),
            lyricsSourceEffectSelect);
      }
    });

    test('select prefix never leaks into the toggle action', () {
      expect(lyricsSourceActionEffect(lyricsSourceToggleAction),
          lyricsSourceEffectToggle);
      expect(lyricsSourceToggleAction, 'player:lyrics-sources');
      expect(
        lyricsSourceActionEffect('player:lyrics-sources')
            == lyricsSourceEffectSelect,
        isFalse,
      );
    });

    test('close-modal resolves to close (NativeHudController.cpp:919)', () {
      expect(lyricsSourceActionEffect(_qtCloseAction), lyricsSourceEffectClose);
      expect(lyricsSourceCloseAction, 'close-modal');
    });

    test('unknown or malformed actions resolve to null', () {
      expect(lyricsSourceActionEffect('player:lyrics-source:'), isNull);
      expect(lyricsSourceActionEffect('player:lyrics-source:bogus'), isNull);
      expect(lyricsSourceActionEffect('player:lyrics-source:Auto'), isNull);
      expect(lyricsSourceActionEffect(''), isNull);
      expect(lyricsSourceActionEffect('player:back'), isNull);
    });

    test('the popover emits no close-modal action of its own; close arrives '
        'only from Escape or the host toggle', () {
      final LyricsSourceModalFrame frame = _modal().build();
      expect(
        frame.hits.where((List<Object?> h) => h[4] == _qtCloseAction).isEmpty,
        isTrue,
      );
      expect(
        frame.hits.where((List<Object?> h) => h[5] == '取消').isEmpty,
        isTrue,
        reason: 'Qt renders no 取消 button in this popover',
      );
      expect(
        frame.commands
            .where((List<Object?> c) => c[1] == '取消')
            .isEmpty,
        isTrue,
      );
    });
  });

  // -------------------------------------------------------------------------
  // 10. Key table (NativeHudController.cpp:913-925).
  // -------------------------------------------------------------------------
  group('key table', () {
    test('Escape closes the popover with close-modal', () {
      expect(lyricsSourceKeyAction('Escape'), 'close-modal');
    });

    test('every other key is swallowed (no Tab order, no arrow scroll)', () {
      for (final String key in <String>[
        'Tab',
        'Backtab',
        'Return',
        'Enter',
        'Space',
        'ArrowUp',
        'ArrowDown',
        'Left',
        'Right',
        'a',
      ]) {
        expect(lyricsSourceKeyAction(key), isNull, reason: key);
      }
    });
  });

  // -------------------------------------------------------------------------
  // 11. Motion: Qt UiMotion::SurfaceMotion, exact constants and curve values.
  // -------------------------------------------------------------------------
  group('motion', () {
    test('initial state: transparent, offset 12, settled', () {
      final LyricsSourceMotion motion = LyricsSourceMotion();
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
    });

    test('set(true) targets opacity 1, offset 0, 0.3 s', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      expect(motion.duration, 0.3);
      expect(motion.finished, isFalse);
      // Targets are reached by sampling, not by set().
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
    });

    test('set(false) targets opacity 0, offset 8, 0.2 s', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(false, 0);
      expect(motion.duration, 0.2);
      expect(motion.finished, isFalse);
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
    });

    test('entering curve: 0.22 / 1 / 0.36 / 1, half-way values from Qt',
        () {
      // Reference values recomputed from UiMotion.cpp:7-22 (24 bisections).
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      motion.sample(0.15); // progress = 0.5
      expect(motion.opacity, closeTo(0.96138255575218934, 1e-12));
      expect(motion.offset, closeTo(0.46340933097372883, 1e-12));
      motion.sample(0.075); // progress = 0.25, backwards clamp is fine
      expect(motion.opacity, closeTo(0.76486475245604313, 1e-12));
    });

    test('entering start is ~0, not exactly 0 (bezier(0) at p = 0)', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 7);
      motion.sample(7);
      expect(motion.opacity, closeTo(8.9406964498550705e-8, 1e-12));
      // 12 * (1 - bezierEnter(0)) = 11.999998927116426, not exactly 12.
      expect(motion.offset, closeTo(11.999998927116426, 1e-9));
    });

    test('entering end is exactly 1 and lands on offset 0, then finishes', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      motion.sample(0.3);
      expect(motion.opacity, 1);
      expect(motion.offset, 0);
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
    });

    test('leaving curve: 0.4 / 0 / 1 / 1, half-way values from Qt', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      motion.sample(0.3); // settle open
      motion.set(false, 1);
      expect(motion.duration, 0.2);
      motion.sample(1.1); // progress = 0.5
      expect(motion.opacity, closeTo(0.67518541414424427, 1e-12));
      expect(motion.offset, closeTo(2.5985166868460459, 1e-12));
    });

    test('leaving end: opacity ~0 and offset ~8, then finished', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      motion.sample(0.3);
      motion.set(false, 1);
      motion.sample(1.2);
      expect(motion.opacity, closeTo(0, 1e-12));
      expect(motion.offset, closeTo(8, 1e-12));
      expect(motion.opacity, closeTo(2.6645352591003757e-15, 1e-18));
      expect(motion.offset, closeTo(7.9999999999999787, 1e-12));
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
    });

    test('reduced snaps instantly and never runs', () {
      final LyricsSourceMotion motion = LyricsSourceMotion();
      motion.set(true, 0, reduced: true);
      expect(motion.duration, 0);
      expect(motion.opacity, 1);
      expect(motion.offset, 0);
      expect(motion.finished, isTrue);
      motion.set(false, 5, reduced: true);
      expect(motion.duration, 0);
      expect(motion.opacity, 0);
      expect(motion.offset, 8);
      expect(motion.finished, isTrue);
    });

    test('re-targeting mid-flight continues from the sampled values '
        '(UiMotion.cpp:108 samples before capturing)', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 0);
      motion.sample(0.15);
      final double midOpacity = motion.opacity;
      final double midOffset = motion.offset;
      expect(midOffset, closeTo(0.46340933097372883, 1e-12));
      motion.set(false, 0.15);
      expect(motion.duration, 0.2);
      expect(motion.opacity, closeTo(midOpacity, 1e-15));
      expect(motion.offset, closeTo(midOffset, 1e-15));
    });

    test('sample() clamps time before and after the window', () {
      final LyricsSourceMotion motion = LyricsSourceMotion()..set(true, 10);
      motion.sample(9); // before start: progress clamps to 0
      expect(motion.opacity, closeTo(8.9406964498550705e-8, 1e-12));
      expect(motion.finished, isFalse);
      motion.sample(100); // after end: progress clamps to 1
      expect(motion.opacity, 1);
      expect(motion.offset, 0);
      expect(motion.finished, isTrue);
    });

    test('sample() is a no-op once settled', () {
      final LyricsSourceMotion motion = LyricsSourceMotion();
      motion.sample(1);
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
      expect(motion.duration, 0);
    });
  });

  // -------------------------------------------------------------------------
  // 12. Toast-free integration of the injected state into the frame.
  // -------------------------------------------------------------------------
  group('injected state', () {
    test('opacity and offset flow into alpha/translate but not into the fill',
        () {
      final LyricsSourceModalFrame frame =
          _modal(opacity: 0.37, offset: -4.5).build();
      expect(frame.commands[1][1], 0.37);
      expect(frame.commands[2][1], 0);
      expect(frame.commands[2][2], -4.5);
      expect(frame.commands[3][3], 674.0); // panel y is stage-fixed
    });

    test('a full open frame with a checked row equals the Qt reference', () {
      final LyricsSourceModalFrame frame = _modal(
        opacity: 1,
        offset: 0,
        localSource: 'netease',
        dark: true,
      ).build();
      expect(
        frame.commands,
        _qtCommands(
          selected: 'netease',
          opacity: 1,
          offset: 0,
          dark: true,
        ),
      );
      expect(frame.hits, _qtHits(selected: 'netease'));
    });
  });
}
