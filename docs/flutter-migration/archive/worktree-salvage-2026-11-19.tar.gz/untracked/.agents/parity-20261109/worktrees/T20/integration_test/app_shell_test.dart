/// Shell/back-key slice for the Qt-to-Flutter parity plan (T20, slice S03).
///
/// This file is written as an integration test for a host that has
/// `integration_test` in its dev_dependencies and calls
/// `IntegrationTestWidgetsFlutterBinding.ensureInitialized()` before pumping the
/// real shell. That dependency is NOT declared in this tree's pubspec.yaml and
/// pubspec.yaml must not be edited by this slice, so the file deliberately imports
/// only `package:flutter_test`, `package:flutter/widgets` and the router under
/// test: it is statically compilable as a widget test today, and becomes a device
/// test once the host adds the dependency and the binding call. Nothing in this
/// atom executes it: RED/GREEN are NOT EXECUTED.
///
/// What is asserted, and what is deliberately not:
///
/// * Every Escape outcome is compared against NativeHud::key's branch order
///   (Qt/src/NativeHudController.cpp:887-943) and the actions it reaches
///   (:641-651, :682-683, :686-687, Qt/src/NativeViewer.cpp:131-135,
///   Qt/src/NativeHudDesktopLyrics.cpp:133-136).
/// * Mutual exclusion is asserted through port call counts, not through
///   Navigator behaviour: the shell harness has no Navigator and no PopScope at
///   all, which is the point - the back key is adjudicated by [BackRouter] and
///   executed through [RouterPorts], never by a Flutter route pop.
/// * No business data: the harness renders one neutral stage label and the last
///   outcome name. There is no song, lyric, account, cover, queue or QR payload
///   anywhere in this file.
library;

import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/app/router.dart';

/// The smallest shell stand-in this slice needs: a stage label plus the back-key
/// wiring into [BackRouter].
///
/// It exists to prove the wiring shape (one key in, at most one port out) and to
/// give the device test something to pump. It renders no business data - the only
/// text is the injected stage name and the last [BackOutcome] name.
class ShellHarness extends StatefulWidget {
  /// Creates the harness around a router and one fixed snapshot.
  const ShellHarness({
    super.key,
    required this.router,
    this.stage = 'shell',
    this.state = const BackState(mode: BackValues.archiveMode),
  });

  /// The router under test.
  final BackRouter router;

  /// Neutral stage name shown in the label.
  final String stage;

  /// The snapshot the host would hand over for the next back key.
  final BackState state;

  @override
  State<ShellHarness> createState() => ShellHarnessState();
}

/// State of [ShellHarness]; public so a test can drive the same entry point a
/// host's key handler would call.
class ShellHarnessState extends State<ShellHarness> {
  BackOutcome _last = BackOutcome.none;

  /// The last decision, as the label shows it.
  BackOutcome get last => _last;

  /// The shell's single back entry point: exactly one [BackRouter.handleEscape].
  BackOutcome pressBack({bool command = false}) {
    final BackOutcome outcome =
        widget.router.handleEscape(widget.state, command: command);
    setState(() {
      _last = outcome;
    });
    return outcome;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Text(
        '${widget.stage} / back=${_last.name}',
        textDirection: TextDirection.ltr,
      ),
    );
  }
}

/// Records which port fired, so exclusivity is a count, not an inference.
class _RecordingPorts implements RouterPorts {
  final List<String> calls = <String>[];

  int countOf(String port) =>
      calls.where((String call) => call.startsWith(port)).length;

  @override
  void viewerKey(String value, bool command) =>
      calls.add('viewerKey($value,$command)');

  @override
  void desktopLyricsBack() => calls.add('desktopLyricsBack');

  @override
  void closeModal() => calls.add('closeModal');

  @override
  void returnToDirectory() => calls.add('returnToDirectory');

  @override
  void leaveDirectory() => calls.add('leaveDirectory');

  @override
  void setSceneMode(String mode) => calls.add('setSceneMode($mode)');
}

/// One Qt branch, its snapshot, and the single port it may fire.
class _BackCase {
  const _BackCase({
    required this.name,
    required this.state,
    required this.outcome,
    this.port,
  });

  final String name;
  final BackState state;
  final BackOutcome outcome;

  /// null when [outcome] is [BackOutcome.none]: no port may fire.
  final String? port;
}

const List<_BackCase> _cases = <_BackCase>[
  _BackCase(
    name: 'viewer open closes the viewer first (NativeViewer.cpp:131-135, '
        'NativeHudController.cpp:909-912)',
    state: BackState(viewerOpen: true, mode: BackValues.archiveMode),
    outcome: BackOutcome.viewerClose,
    port: 'viewerKey(Escape,false)',
  ),
  _BackCase(
    name: 'viewer wins over an open modal and an open directory',
    state: BackState(
      viewerOpen: true,
      modal: 'settings',
      mode: BackValues.detailMode,
      directoryOpen: true,
    ),
    outcome: BackOutcome.viewerClose,
    port: 'viewerKey(Escape,false)',
  ),
  _BackCase(
    name: 'desktop-lyrics modal goes back to settings (:913-916)',
    state: BackState(modal: BackValues.desktopLyricsModal, mode: BackValues.archiveMode),
    outcome: BackOutcome.desktopLyricsBack,
    port: 'desktopLyricsBack',
  ),
  _BackCase(
    name: 'desktop-lyrics beats close-modal because it is a modal value (:913-920)',
    state: BackState(
      modal: BackValues.desktopLyricsModal,
      mode: BackValues.archiveMode,
      closing: false,
    ),
    outcome: BackOutcome.desktopLyricsBack,
    port: 'desktopLyricsBack',
  ),
  _BackCase(
    name: 'any other modal is closed (:917-920, :686-687)',
    state: BackState(modal: 'settings', mode: BackValues.archiveMode),
    outcome: BackOutcome.closeModal,
    port: 'closeModal',
  ),
  _BackCase(
    name: 'detail with a directory returns to the directory (:644-645)',
    state: BackState(mode: BackValues.detailMode, directoryOpen: true),
    outcome: BackOutcome.backReturnToDirectory,
    port: 'returnToDirectory',
  ),
  _BackCase(
    name: 'directory without detail leaves the directory (:646-648)',
    state: BackState(mode: BackValues.archiveMode, directoryOpen: true),
    outcome: BackOutcome.backLeaveDirectory,
    port: 'leaveDirectory',
  ),
  _BackCase(
    name: 'directory with an unknown mode leaves the directory (:644-648)',
    state: BackState(directoryOpen: true),
    outcome: BackOutcome.backLeaveDirectory,
    port: 'leaveDirectory',
  ),
  _BackCase(
    name: 'no directory falls through to archive (:682-683)',
    state: BackState(mode: BackValues.archiveMode),
    outcome: BackOutcome.backArchive,
    port: 'setSceneMode(archive)',
  ),
  _BackCase(
    name: 'detail without a directory still falls through to archive',
    state: BackState(mode: BackValues.detailMode),
    outcome: BackOutcome.backArchive,
    port: 'setSceneMode(archive)',
  ),
  _BackCase(
    name: 'no frame yet drops the key (:888-890)',
    state: BackState(hasFrame: false, mode: BackValues.archiveMode),
    outcome: BackOutcome.none,
  ),
  _BackCase(
    name: 'a modal that is already closing takes no second action',
    state: BackState(modal: 'settings', mode: BackValues.archiveMode, closing: true),
    outcome: BackOutcome.none,
  ),
];

void main() {
  group('decideBack mirrors NativeHudController::key', () {
    test('every branch matches its Qt line and its single outcome', () {
      for (final _BackCase c in _cases) {
        expect(decideBack(c.state), c.outcome, reason: c.name);
      }
    });

    test('an empty modal string means no modal, like Qt modal.isEmpty()', () {
      const BackState emptyModal = BackState(modal: '', mode: BackValues.archiveMode);
      const BackState nullModal = BackState(mode: BackValues.archiveMode);
      expect(emptyModal.hasModal, isFalse);
      expect(nullModal.hasModal, isFalse);
      expect(decideBack(emptyModal), decideBack(nullModal));
      expect(decideBack(emptyModal), BackOutcome.backArchive);

      const BackState emptyModalDirectory =
          BackState(modal: '', mode: BackValues.archiveMode, directoryOpen: true);
      expect(decideBack(emptyModalDirectory), BackOutcome.backLeaveDirectory);
    });

    test('lyricsMode is read but never changes the outcome (:642 only clears it)',
        () {
      for (final _BackCase c in _cases) {
        final BackState withLyricsMode = BackState(
          viewerOpen: c.state.viewerOpen,
          modal: c.state.modal,
          mode: c.state.mode,
          directoryOpen: c.state.directoryOpen,
          closing: c.state.closing,
          lyricsMode: true,
          hasFrame: c.state.hasFrame,
        );
        expect(decideBack(withLyricsMode), c.outcome,
            reason: '${c.name} (lyricsMode on)');
      }
    });

    test('decideBack is pure: same input, same outcome, input untouched', () {
      const BackState state = BackState(
        modal: 'settings',
        mode: BackValues.archiveMode,
        lyricsMode: true,
      );
      final BackOutcome first = decideBack(state);
      final BackOutcome second = decideBack(state);
      expect(first, second);
      expect(first, BackOutcome.closeModal);
      expect(state.modal, 'settings');
      expect(state.mode, BackValues.archiveMode);
      expect(state.lyricsMode, isTrue);
    });
  });

  group('BackRouter fires exactly one port', () {
    test('each outcome calls its own port once and no other port', () {
      for (final _BackCase c in _cases) {
        final _RecordingPorts ports = _RecordingPorts();
        final BackRouter router = BackRouter(ports);

        final BackOutcome outcome = router.handleEscape(c.state);
        final String? expectedPort = c.port;

        expect(outcome, c.outcome, reason: c.name);
        expect(outcome, decideBack(c.state), reason: c.name);
        if (expectedPort == null) {
          expect(ports.calls, isEmpty, reason: c.name);
        } else {
          expect(ports.calls, <String>[expectedPort], reason: c.name);
          expect(ports.calls.length, 1, reason: c.name);
        }
      }
    });

    test('viewer close forwards the command modifier (Engine.cpp:1003)', () {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);

      final BackOutcome outcome = router.handleEscape(
        const BackState(viewerOpen: true, mode: BackValues.archiveMode),
        command: true,
      );

      expect(outcome, BackOutcome.viewerClose);
      expect(ports.calls, <String>['viewerKey(Escape,true)']);
    });

    test('the modifier does not leak into the other ports', () {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);

      final BackOutcome outcome = router.handleEscape(
        const BackState(mode: BackValues.archiveMode),
        command: true,
      );

      expect(outcome, BackOutcome.backArchive);
      expect(ports.calls, <String>['setSceneMode(archive)']);
    });

    test('archive is the only scene mode the back action can set (:683)', () {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);

      for (final _BackCase c in _cases) {
        ports.calls.clear();
        router.handleEscape(c.state);
        expect(ports.countOf('setSceneMode('), c.port == 'setSceneMode(archive)' ? 1 : 0,
            reason: c.name);
      }
    });
  });

  group('shell harness', () {
    testWidgets('back goes through the router, not a Flutter route pop',
        (WidgetTester tester) async {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);
      final GlobalKey<ShellHarnessState> key = GlobalKey<ShellHarnessState>();

      await tester.pumpWidget(ShellHarness(key: key, router: router));

      // No Navigator and no PopScope exist, so nothing can pop a Flutter route:
      // the only way out of this shell is the port the router calls.
      expect(find.byType(Navigator), findsNothing);
      expect(find.byType(PopScope), findsNothing);

      final BackOutcome outcome = key.currentState!.pressBack();
      await tester.pump();

      expect(outcome, BackOutcome.backArchive);
      expect(ports.calls, <String>['setSceneMode(archive)']);
      expect(find.text('shell / back=backArchive'), findsOneWidget);
    });

    testWidgets('the harness renders a neutral label only',
        (WidgetTester tester) async {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);
      final GlobalKey<ShellHarnessState> key = GlobalKey<ShellHarnessState>();

      await tester.pumpWidget(
        ShellHarness(
          key: key,
          router: router,
          stage: 'booting',
          state: const BackState(modal: BackValues.desktopLyricsModal),
        ),
      );

      expect(find.text('booting / back=none'), findsOneWidget);

      key.currentState!.pressBack();
      await tester.pump();

      expect(ports.calls, <String>['desktopLyricsBack']);
      expect(find.text('booting / back=desktopLyricsBack'), findsOneWidget);
    });

    testWidgets('an empty frame produces no port call from the harness',
        (WidgetTester tester) async {
      final _RecordingPorts ports = _RecordingPorts();
      final BackRouter router = BackRouter(ports);
      final GlobalKey<ShellHarnessState> key = GlobalKey<ShellHarnessState>();

      await tester.pumpWidget(
        ShellHarness(
          key: key,
          router: router,
          state: const BackState(hasFrame: false),
        ),
      );

      final BackOutcome outcome = key.currentState!.pressBack();
      await tester.pump();

      expect(outcome, BackOutcome.none);
      expect(ports.calls, isEmpty);
      expect(find.text('shell / back=none'), findsOneWidget);
    });
  });
}
