import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/lyrics_offset_modal.dart';

// ---------------------------------------------------------------------------
// T40-C18-A6-LYROFFSET - tests for the Qt landscape popover "lyrics-offset".
//
// Every literal in this file is copied from the Qt sources, never from the
// Dart port, so a drift in the port fails the assertion:
//   Qt/src/NativeHud.cpp:10-15        ink()
//   Qt/src/NativeHud.cpp:37-43        fill()/text() default color = ink()
//   Qt/src/NativeHud.cpp:48-76        fit()
//   Qt/src/NativeHud.cpp:102-109      hit() (six fields, label falls back)
//   Qt/src/NativeHud.cpp:110-120      button() (hit first, inset, tint, fit)
//   Qt/src/NativeHud.cpp:140-159      modalBounds()
//   Qt/src/NativeHud.cpp:253-266      hits cleared before painting
//   Qt/src/NativeHudModal.cpp:81-121  the lyrics-offset popover branch
//   Qt/src/NativeHudController.cpp:324-335, 686-687, 898-904, 913-925
//   Qt/src/UiMotion.h:24-42, UiMotion.cpp:7-22, 86-120  SurfaceMotion
//
// NOT EXECUTED. This tree forbids flutter test, dart test and dart analyze;
// the RED/GREEN runs are deliberately left unexecuted and are reported as such.
// ---------------------------------------------------------------------------

/// Qt design-stage width (1920x1080 landscape).
const double _qtStageWidth = 1920;

/// Qt design-stage height; only used to prove no full-screen op exists.
const double _qtStageHeight = 1080;

/// modalBounds("lyrics-offset") - Qt/src/NativeHud.cpp:151.
const double _qtPanelRatio = 0.56;

/// modalBounds("lyrics-offset") y - Qt/src/NativeHud.cpp:151.
const double _qtPanelTop = 690;

/// modalBounds("lyrics-offset") width - Qt/src/NativeHud.cpp:151.
const double _qtPanelWidth = 320;

/// modalBounds("lyrics-offset") height - Qt/src/NativeHud.cpp:151.
const double _qtPanelHeight = 216;

/// bounds.x() + 16 - Qt/src/NativeHudModal.cpp:87.
const double _qtContentInsetX = 16;

/// Header - Qt/src/NativeHudModal.cpp:95.
const String _qtHeaderText = '歌词偏移';
const double _qtHeaderDy = 18;
const double _qtHeaderSize = 17;
const String _qtHeaderWeight = 'demibold';

/// Close button - Qt/src/NativeHudModal.cpp:96.
const String _qtCloseLabel = '关闭';
const double _qtCloseDx = 232;
const double _qtCloseDy = 8;
const double _qtCloseW = 56;
const double _qtCloseH = 36;
const double _qtCloseSize = 13;

/// Offset label - Qt/src/NativeHudModal.cpp:97-103.
const double _qtLabelDy = 58;
const double _qtLabelSize = 15;
const String _qtLabelUncalibrated = '未校准';
const String _qtLabelEarlierPrefix = '已提前 ';
const String _qtLabelLaterPrefix = '已延后 ';

/// The two 0.2 s offset buttons - Qt/src/NativeHudModal.cpp:104-105.
const String _qtEarlierLabel = '歌词提前 0.2s';
const String _qtLaterLabel = '歌词延后 0.2s';
const double _qtOffsetDy = 92;
const double _qtOffsetW = 138;
const double _qtOffsetH = 40;
const double _qtOffsetSize = 13;

/// Bottom row - Qt/src/NativeHudModal.cpp:108-117.
const String _qtResetLabel = '重置';
const String _qtApplyGlobalLabel = '全局应用';
const double _qtBottomDy = 152;
const double _qtBottomTextDy = 161;
const double _qtBottomSize = 13;
const double _qtColumnDx = 150;

/// muted = ink(); muted[3] = 0.45 - Qt/src/NativeHudModal.cpp:106-107.
const double _qtMutedAlpha = 0.45;

/// panelFill - Qt/src/NativeHudModal.cpp:91-92.
const List<Object?> _qtLightPanelFill = <Object?>[0.929, 0.922, 0.894, 1];
const List<Object?> _qtDarkPanelFill = <Object?>[
  0.15,
  0.15,
  0.15,
  1,
  'calibratedWhite',
];

/// Modal-control tint - Qt/src/NativeHud.cpp:116.
const List<Object?> _qtLightButtonTint = <Object?>[0.44, 0.49, 0.36, 0.1];
const List<Object?> _qtDarkButtonTint = <Object?>[0.55, 0.59, 0.46, 0.13];

/// ink() - Qt/src/NativeHud.cpp:11-14.
const List<Object?> _qtLightInk = <Object?>[
  0.08,
  0.085,
  0.075,
  1,
  'calibratedRGB',
];
const List<Object?> _qtDarkInk = <Object?>[
  0.92,
  0.92,
  0.92,
  1,
  'calibratedWhite',
];

/// Actions - Qt/src/NativeHudController.cpp:324-335, 686-687.
const String _qtCloseAction = 'close-modal';
const String _qtEarlierAction = 'player:lyrics-earlier';
const String _qtLaterAction = 'player:lyrics-later';
const String _qtResetAction = 'player:lyrics-reset';
const String _qtApplyGlobalAction = 'player:lyrics-apply-global';

/// Qt modal kind - Qt/src/NativeHudController.cpp:324-328.
const String _qtKind = 'lyrics-offset';

/// Escape key name - Qt/src/NativeHudController.cpp:913-925.
const String _qtEscapeKey = 'Escape';

/// One mutation of the offset: adjustOffset(+/-200)
/// - Qt/src/NativeHudController.cpp:330-331.
const double _qtOffsetStepMs = 200;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

double _qtMin(double a, double b) => a < b ? a : b;

/// Deterministic stand-in for NativeHud's glyph metrics.
///
/// width = text.length * size * scale + tracking; every request is recorded so
/// the tests can prove that fit() measured through the injected hook, with
/// fit's own default weight "regular" (Qt/src/NativeHud.h:249) and tracking 0.
class _Measure {
  _Measure(this.scale);

  /// Width per character, as a multiple of the font size.
  final double scale;

  /// Every measurement request in call order: [text, size, weight, tracking].
  final List<List<Object?>> calls = <List<Object?>>[];

  double call(String text, double size, String? weight, double tracking) {
    calls.add(<Object?>[text, size, weight, tracking]);
    return text.length * size * scale + tracking;
  }
}

/// Identity-rect injection (landscape default).
List<double> _identity(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

/// Rect spy: shifts by a fixed delta and records every input rect.
class _RectSpy {
  _RectSpy(this.dx, this.dy);

  final double dx;
  final double dy;

  /// Recorded [x, y, w, h] inputs in call order.
  final List<List<double>> inputs = <List<double>>[];

  List<double> call(double x, double y, double w, double h) {
    inputs.add(<double>[x, y, w, h]);
    return <double>[x + dx, y + dy, w, h];
  }
}

double _panelX([double width = _qtStageWidth]) => width * _qtPanelRatio;

/// Qt/src/NativeHud.cpp:48-76 fit(), re-written from the Qt source.
String _qtFit(
  String value,
  double size,
  double width,
  double scale,
) {
  final int original = value.length;
  int length = original;
  if (value.length * size * scale > width) {
    int low = 1;
    int high = original;
    while (low < high) {
      final int middle = (low + high + 1) ~/ 2;
      if (value.substring(0, middle).length * size * scale <= width) {
        low = middle;
      } else {
        high = middle - 1;
      }
    }
    length = low;
  }
  if (length == original) {
    return value;
  }
  final int end = length - 1 < 0 ? 0 : length - 1;
  return value.substring(0, end) + '…';
}

/// Qt/src/NativeHudModal.cpp:97-102 offset label.
String _qtOffsetLabel(double offsetMs) {
  if (offsetMs == 0) {
    return _qtLabelUncalibrated;
  }
  final String direction =
      offsetMs > 0 ? _qtLabelEarlierPrefix : _qtLabelLaterPrefix;
  final double seconds = (offsetMs < 0 ? -offsetMs : offsetMs) / 1000;
  return direction + seconds.toStringAsFixed(1) + 's';
}

/// The full Qt op stream for the lyrics-offset popover, written straight from
/// Qt/src/NativeHudModal.cpp:83-120.
List<List<Object?>> _qtCommands({
  double width = _qtStageWidth,
  double offsetMs = 200,
  double globalOffsetMs = 0,
  bool dark = false,
  double opacity = 0,
  double offset = 12,
  double scale = 0.5,
}) {
  final double panelX = width * _qtPanelRatio;
  final double x = panelX + _qtContentInsetX;
  const double y = _qtPanelTop;
  final List<Object?> ink = dark ? _qtDarkInk : _qtLightInk;
  final List<Object?> muted = <Object?>[
    ink[0],
    ink[1],
    ink[2],
    _qtMutedAlpha,
    ink[4],
  ];
  final List<List<Object?>> out = <List<Object?>>[];

  void button(
    String label,
    double bx,
    double by,
    double bw,
    double bh,
    double size,
  ) {
    final double inset = _qtMin(10, bw / 8);
    out.add(<Object?>[
      'fill',
      dark ? _qtDarkButtonTint : _qtLightButtonTint,
      bx,
      by,
      bw,
      bh,
    ]);
    out.add(<Object?>[
      'text',
      _qtFit(label, size, bw - inset * 2, scale),
      bx + inset,
      by + (bh - size) / 2 - 4,
      size,
      'regular',
      0,
      ink,
    ]);
  }

  out.add(const <Object?>['save']);
  out.add(<Object?>['alpha', opacity]);
  out.add(<Object?>['translate', 0, offset]);
  out.add(<Object?>[
    'fill',
    dark ? _qtDarkPanelFill : _qtLightPanelFill,
    panelX,
    y,
    _qtPanelWidth,
    _qtPanelHeight,
  ]);
  out.add(<Object?>[
    'text',
    _qtHeaderText,
    x,
    y + _qtHeaderDy,
    _qtHeaderSize,
    _qtHeaderWeight,
    0,
    ink,
  ]);
  button(_qtCloseLabel, x + _qtCloseDx, y + _qtCloseDy, _qtCloseW, _qtCloseH,
      _qtCloseSize);
  out.add(<Object?>[
    'text',
    _qtOffsetLabel(offsetMs),
    x,
    y + _qtLabelDy,
    _qtLabelSize,
    'regular',
    0,
    ink,
  ]);
  button(_qtEarlierLabel, x, y + _qtOffsetDy, _qtOffsetW, _qtOffsetH,
      _qtOffsetSize);
  button(_qtLaterLabel, x + _qtColumnDx, y + _qtOffsetDy, _qtOffsetW, _qtOffsetH,
      _qtOffsetSize);
  if (offsetMs != 0) {
    button(_qtResetLabel, x, y + _qtBottomDy, _qtOffsetW, _qtOffsetH,
        _qtOffsetSize);
  } else {
    out.add(<Object?>[
      'text',
      _qtResetLabel,
      x,
      y + _qtBottomTextDy,
      _qtBottomSize,
      'regular',
      0,
      muted,
    ]);
  }
  if (offsetMs != globalOffsetMs) {
    button(_qtApplyGlobalLabel, x + _qtColumnDx, y + _qtBottomDy, _qtOffsetW,
        _qtOffsetH, _qtOffsetSize);
  } else {
    out.add(<Object?>[
      'text',
      _qtApplyGlobalLabel,
      x + _qtColumnDx,
      y + _qtBottomTextDy,
      _qtBottomSize,
      'regular',
      0,
      muted,
    ]);
  }
  out.add(const <Object?>['restore']);
  return out;
}

/// The Qt hit table: controls only, draw order, six fields each
/// (Qt/src/NativeHudModal.cpp:93-117 + Qt/src/NativeHud.cpp:102-109).
List<List<Object?>> _qtHits({
  double width = _qtStageWidth,
  double offsetMs = 200,
  double globalOffsetMs = 0,
}) {
  final double x = width * _qtPanelRatio + _qtContentInsetX;
  const double y = _qtPanelTop;
  final List<List<Object?>> out = <List<Object?>>[];

  void hit(
    double hx,
    double hy,
    double hw,
    double hh,
    String action,
    String label,
  ) {
    out.add(<Object?>[hx, hy, hw, hh, action, label]);
  }

  hit(x + _qtCloseDx, y + _qtCloseDy, _qtCloseW, _qtCloseH, _qtCloseAction,
      _qtCloseLabel);
  hit(x, y + _qtOffsetDy, _qtOffsetW, _qtOffsetH, _qtEarlierAction,
      _qtEarlierLabel);
  hit(x + _qtColumnDx, y + _qtOffsetDy, _qtOffsetW, _qtOffsetH, _qtLaterAction,
      _qtLaterLabel);
  if (offsetMs != 0) {
    hit(x, y + _qtBottomDy, _qtOffsetW, _qtOffsetH, _qtResetAction,
        _qtResetLabel);
  }
  if (offsetMs != globalOffsetMs) {
    hit(x + _qtColumnDx, y + _qtBottomDy, _qtOffsetW, _qtOffsetH,
        _qtApplyGlobalAction, _qtApplyGlobalLabel);
  }
  return out;
}

/// Builds the port at the Qt design width with a non-truncating measurer.
LyricsOffsetModal _modal({
  double width = _qtStageWidth,
  _Measure? measure,
  double offsetMs = 200,
  double globalOffsetMs = 0,
  bool dark = false,
  bool reduced = false,
  bool closing = false,
  double opacity = 0,
  double offset = 12,
  LyricsOffsetRectHook? rectHook,
}) {
  final _Measure real = measure ?? _Measure(0.5);
  return LyricsOffsetModal(
    LyricsOffsetModalState(
      width: width,
      opacity: opacity,
      offset: offset,
      offsetMs: offsetMs,
      globalOffsetMs: globalOffsetMs,
      measureText: real.call,
      dark: dark,
      reduced: reduced,
      closing: closing,
      rectHook: rectHook ?? _identity,
    ),
  );
}

/// Qt UiMotion.cpp:7-22 bezier(), re-written from the Qt source.
double _refComponent(double t, double a, double b) {
  final double inverse = 1 - t;
  return 3 * inverse * inverse * t * a + 3 * inverse * t * t * b + t * t * t;
}

double _refBezier(double x, double x1, double y1, double x2, double y2) {
  double lower = 0;
  double upper = 1;
  for (int i = 0; i < 24; i++) {
    final double t = (lower + upper) / 2;
    if (_refComponent(t, x1, x2) < x) {
      lower = t;
    } else {
      upper = t;
    }
  }
  return _refComponent((lower + upper) / 2, y1, y2);
}

/// The entering curve of SurfaceMotion::sample (Qt/src/UiMotion.cpp:91-92).
double _enterAmount(double progress) =>
    _refBezier(progress, 0.22, 1, 0.36, 1);

/// The leaving curve of SurfaceMotion::sample (Qt/src/UiMotion.cpp:91-92).
double _leaveAmount(double progress) => _refBezier(progress, 0.4, 0, 1, 1);

void main() {
  // -------------------------------------------------------------------------
  // 1. Frame shape: the popover path draws 17 commands, no scrim, no catcher.
  // -------------------------------------------------------------------------
  group('frame shape', () {
    test('emits the Qt op order save, alpha, translate, panel, controls, '
        'restore (Qt/src/NativeHudModal.cpp:83-120)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands.length, 17);
      expect(frame.commands.first, <Object?>['save']);
      expect(frame.commands.last, <Object?>['restore']);
      expect(
        frame.commands.map((List<Object?> c) => c.first).toList(),
        <String>[
          'save',
          'alpha',
          'translate',
          'fill',
          'text',
          'fill',
          'text',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'fill',
          'text',
          'restore',
        ],
      );
    });

    test('there is no scrim and no generic header: the first fill after '
        'translate is the panel itself (NativeHudModal.cpp:91-92)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[3][0], 'fill');
      expect(frame.commands[3][1], _qtLightPanelFill);
      expect(frame.commands[3][2], closeTo(_panelX(), 1e-9));
      expect(frame.commands[3][3], _qtPanelTop);
      expect(frame.commands[3][4], _qtPanelWidth);
      expect(frame.commands[3][5], _qtPanelHeight);
    });

    test('every emitted rect stays inside the panel: no full-screen fill and '
        'no 1px header rule', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      for (final List<Object?> command in frame.commands) {
        if (command[0] != 'fill') {
          continue;
        }
        final double w = command[4]! as double;
        final double h = command[5]! as double;
        expect(w <= _qtPanelWidth, isTrue);
        expect(h <= _qtPanelHeight, isTrue);
        expect(h == 1, isFalse);
      }
      final List<String> ops = frame.commands
          .map((List<Object?> c) => c.first! as String)
          .toList();
      expect(ops.contains('clip'), isFalse);
      expect(ops.contains('image'), isFalse);
      expect(ops.contains('art'), isFalse);
      expect(ops.contains('scale'), isFalse);
    });

    test('no outside catcher exists: the popover owns only its controls and '
        '(contrast NativeHudModal.cpp:128) never the whole stage', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.hits.length, 5);
      for (final List<Object?> hit in frame.hits) {
        final double w = hit[2]! as double;
        final double h = hit[3]! as double;
        expect(w < _qtStageWidth, isTrue);
        expect(h < _qtStageHeight, isTrue);
      }
    });

    test('build() is pure: equal content, fresh lists, no shared state', () {
      final LyricsOffsetModal modal = _modal();
      final LyricsOffsetModalFrame first = modal.build();
      final LyricsOffsetModalFrame second = modal.build();
      expect(first.commands, second.commands);
      expect(first.hits, second.hits);
      expect(identical(first.commands, second.commands), isFalse);
      expect(identical(first.hits, second.hits), isFalse);
      expect(identical(first.commands[3], second.commands[3]), isFalse);
      expect(identical(first.hits[0], second.hits[0]), isFalse);
    });

    test('closing and reduced never change the drawn frame: the host keeps '
        'drawing until closing && motion.finished() (NativeHud.cpp:262-266)',
        () {
      final LyricsOffsetModalFrame settled = _modal().build();
      final LyricsOffsetModalFrame closing =
          _modal(closing: true, reduced: true).build();
      expect(closing.commands, settled.commands);
      expect(closing.hits, settled.hits);
    });

    test('alpha and translate still carry the injected motion values '
        '(NativeHudModal.cpp:84, 90)', () {
      final LyricsOffsetModalFrame frame =
          _modal(opacity: 0.42, offset: 5.5).build();
      expect(frame.commands[1], <Object?>['alpha', 0.42]);
      expect(frame.commands[2], <Object?>['translate', 0, 5.5]);
    });
  });

  // -------------------------------------------------------------------------
  // 2. Whole-stream equality against the Qt op order and Qt literals.
  // -------------------------------------------------------------------------
  group('command stream matches Qt', () {
    test('light, offset 200 ms / global 0', () {
      expect(_modal().build().commands, _qtCommands());
    });

    test('light, opacity 0.42 / offset 5.5', () {
      expect(
        _modal(opacity: 0.42, offset: 5.5).build().commands,
        _qtCommands(opacity: 0.42, offset: 5.5),
      );
    });

    test('dark uses the calibratedWhite panel fill, dark ink and dark tint',
        () {
      expect(
        _modal(dark: true).build().commands,
        _qtCommands(dark: true),
      );
    });

    test('offset 0 / global 0: reset and global-apply are muted texts, so the '
        'stream shortens to 15 commands', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 0, globalOffsetMs: 0).build();
      expect(frame.commands.length, 15);
      expect(frame.commands, _qtCommands(offsetMs: 0, globalOffsetMs: 0));
    });

    test('offset 0 / global 200: reset is quiet, so only global-apply is a '
        'button and the stream is 16 commands', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 0, globalOffsetMs: 200).build();
      expect(frame.commands.length, 16);
      expect(frame.commands, _qtCommands(offsetMs: 0, globalOffsetMs: 200));
    });

    test('offset 200 / global 200: global-apply is quiet, so only reset is a '
        'button and the stream is 16 commands', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 200, globalOffsetMs: 200).build();
      expect(frame.commands.length, 16);
      expect(frame.commands, _qtCommands(offsetMs: 200, globalOffsetMs: 200));
    });

    test('a narrower stage only moves the panel: bounds are width * 0.56 '
        '(NativeHud.cpp:151)', () {
      const double width = 1280;
      expect(
        _modal(width: width).build().commands,
        _qtCommands(width: width),
      );
    });
  });

  // -------------------------------------------------------------------------
  // 3. Geometry: panel, origin and every control rect.
  // -------------------------------------------------------------------------
  group('geometry', () {
    test('panel is {width * 0.56, 690, 320, 216} and content starts at '
        '+16 on x (NativeHud.cpp:151, NativeHudModal.cpp:86-88)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      final List<Object?> panel = frame.commands[3];
      expect(panel[2], closeTo(_qtStageWidth * _qtPanelRatio, 1e-9));
      expect(panel[3], 690);
      expect(panel[4], 320);
      expect(panel[5], 216);
      final double x = (panel[2]! as double) + _qtContentInsetX;
      expect(frame.commands[4][2], x);
      expect(frame.commands[4][3], 690 + _qtHeaderDy);
      final List<Object?> closeFill = frame.commands[5];
      expect(closeFill[2], x + _qtCloseDx);
      expect(closeFill[3], 690 + _qtCloseDy);
      expect(closeFill[4], _qtCloseW);
      expect(closeFill[5], _qtCloseH);
      expect(frame.commands[7][2], x);
      expect(frame.commands[7][3], 690 + _qtLabelDy);
      expect(frame.commands[8][2], x);
      expect(frame.commands[10][2], x + _qtColumnDx);
      expect(frame.commands[12][2], x);
      expect(frame.commands[14][2], x + _qtColumnDx);
    });

    test('the 0.2 s row sits at y + 92 and the bottom row at y + 152 '
        '(NativeHudModal.cpp:104-117)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[8][3], 690 + _qtOffsetDy);
      expect(frame.commands[10][3], 690 + _qtOffsetDy);
      expect(frame.commands[12][3], 690 + _qtBottomDy);
      expect(frame.commands[14][3], 690 + _qtBottomDy);
    });

    test('the muted fallback texts are at y + 161 and x + 150 for the second '
        'column (NativeHudModal.cpp:111, 116)', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 0, globalOffsetMs: 0).build();
      // 12 = quiet reset text, 13 = quiet global-apply text; index 11 is the
      // 歌词延后 0.2s renderer, which stays a button in this combination.
      expect(frame.commands[12][1], _qtResetLabel);
      expect(frame.commands[12][3], 690 + _qtBottomTextDy);
      expect(frame.commands[13][1], _qtApplyGlobalLabel);
      expect(frame.commands[13][3], 690 + _qtBottomTextDy);
      expect(frame.commands[13][2],
          (frame.commands[12][2]! as double) + _qtColumnDx);
    });
  });

  // -------------------------------------------------------------------------
  // 4. The offset label: the three states of Qt/src/NativeHudModal.cpp:97-102.
  // -------------------------------------------------------------------------
  group('offset label', () {
    String labelOf(double offsetMs) {
      final LyricsOffsetModalFrame frame = _modal(offsetMs: offsetMs).build();
      return frame.commands[7][1]! as String;
    }

    test('0 ms reads 未校准 and does not take the direction branch', () {
      expect(labelOf(0), '未校准');
      expect(labelOf(0), _qtOffsetLabel(0));
    });

    test('200 ms reads 已提前 0.2s', () {
      expect(labelOf(200), '已提前 0.2s');
      expect(labelOf(200), _qtOffsetLabel(200));
    });

    test('-200 ms reads 已延后 0.2s', () {
      expect(labelOf(-200), '已延后 0.2s');
      expect(labelOf(-200), _qtOffsetLabel(-200));
    });

    test('the magnitude is abs(ms)/1000 with one decimal, and the direction '
        'prefix is kept', () {
      expect(labelOf(1500), '已提前 1.5s');
      expect(labelOf(-1500), '已延后 1.5s');
      expect(labelOf(1234), '已提前 1.2s');
      expect(labelOf(1999), '已提前 2.0s');
      expect(labelOf(-99), '已延后 0.1s');
    });

    test('the label is a plain text op at x, y + 58, size 15, regular, ink '
        '(NativeHudModal.cpp:103)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      final List<Object?> label = frame.commands[7];
      expect(label[0], 'text');
      expect(label[2], (_panelX()) + _qtContentInsetX);
      expect(label[3], 690 + _qtLabelDy);
      expect(label[4], _qtLabelSize);
      expect(label[5], 'regular');
      expect(label[6], 0);
      expect(label[7], _qtLightInk);
    });

    test('a one-step change is exactly +/-200 ms, so the label moves by '
        '0.2 s (NativeHudController.cpp:330-331)', () {
      expect(labelOf(_qtOffsetStepMs), '已提前 0.2s');
      expect(labelOf(-_qtOffsetStepMs), '已延后 0.2s');
    });
  });

  // -------------------------------------------------------------------------
  // 5. Conditional reset / global-apply controls.
  // -------------------------------------------------------------------------
  group('reset and global-apply controls', () {
    test('offset != 0 makes 重置 a modal button at x, y + 152, 138x40, '
        'size 13 (NativeHudModal.cpp:108-109)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[12][0], 'fill');
      expect(frame.commands[12][1], _qtLightButtonTint);
      expect(frame.commands[12][3], 690 + _qtBottomDy);
      expect(frame.commands[12][4], _qtOffsetW);
      expect(frame.commands[12][5], _qtOffsetH);
      expect(frame.commands[13][1], _qtResetLabel);
      expect(frame.commands[13][4], _qtBottomSize);
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        contains(_qtResetAction),
      );
    });

    test('offset == 0 makes 重置 a muted text at x, y + 161, size 13, '
        'regular, tracking 0, alpha 0.45 (NativeHudModal.cpp:110-111)', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 0, globalOffsetMs: 0).build();
      final List<Object?> quiet = frame.commands[12];
      final List<Object?> color = quiet[7]! as List<Object?>;
      expect(quiet[0], 'text');
      expect(quiet[1], _qtResetLabel);
      expect(quiet[4], _qtBottomSize);
      expect(quiet[5], 'regular');
      expect(quiet[6], 0);
      expect(color[3], _qtMutedAlpha);
      expect(color.sublist(0, 3), _qtLightInk.sublist(0, 3));
      expect(color[4], 'calibratedRGB');
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        isNot(contains(_qtResetAction)),
      );
    });

    test('offset != globalOffset makes 全局应用 a button at x + 150, y + 152 '
        '(NativeHudModal.cpp:113-114)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[14][0], 'fill');
      expect(frame.commands[14][3], 690 + _qtBottomDy);
      expect(frame.commands[15][1], _qtApplyGlobalLabel);
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        contains(_qtApplyGlobalAction),
      );
    });

    test('offset == globalOffset makes 全局应用 a muted text at x + 150, '
        'y + 161 (NativeHudModal.cpp:115-116)', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 200, globalOffsetMs: 200).build();
      final List<Object?> quiet = frame.commands[14];
      expect(quiet[0], 'text');
      expect(quiet[1], _qtApplyGlobalLabel);
      expect(quiet[3], 690 + _qtBottomTextDy);
      expect((quiet[7]! as List<Object?>)[3], _qtMutedAlpha);
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        isNot(contains(_qtApplyGlobalAction)),
      );
      // reset is still a button in this combination
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        contains(_qtResetAction),
      );
    });

    test('both zero: three hits only (close, earlier, later)', () {
      final LyricsOffsetModalFrame frame =
          _modal(offsetMs: 0, globalOffsetMs: 0).build();
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        <String>[_qtCloseAction, _qtEarlierAction, _qtLaterAction],
      );
    });

    test('the mute is ink with alpha 0.45, and dark keeps calibratedWhite '
        '(NativeHudModal.cpp:106-107)', () {
      final LyricsOffsetModalFrame dark =
          _modal(offsetMs: 0, globalOffsetMs: 0, dark: true).build();
      final List<Object?> quiet = dark.commands[12][7]! as List<Object?>;
      expect(
        quiet,
        <Object?>[0.92, 0.92, 0.92, _qtMutedAlpha, 'calibratedWhite'],
      );
    });
  });

  // -------------------------------------------------------------------------
  // 6. The hit table: six fields, Qt order, label fallback, no catcher.
  // -------------------------------------------------------------------------
  group('hit table', () {
    test('five rows in draw order, six fields, label = visible label '
        '(NativeHud.cpp:102-109)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.hits, _qtHits());
      for (final List<Object?> hit in frame.hits) {
        expect(hit.length, 6);
        expect(hit[4] is String, isTrue);
        expect(hit[5] is String, isTrue);
      }
      expect(
        frame.hits.map((List<Object?> h) => h[4]).toList(),
        <String>[
          _qtCloseAction,
          _qtEarlierAction,
          _qtLaterAction,
          _qtResetAction,
          _qtApplyGlobalAction,
        ],
      );
      expect(
        frame.hits.map((List<Object?> h) => h[5]).toList(),
        <String>[
          _qtCloseLabel,
          _qtEarlierLabel,
          _qtLaterLabel,
          _qtResetLabel,
          _qtApplyGlobalLabel,
        ],
      );
    });

    test('hit rectangles are the button rectangles, in Qt geometry', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      final double x = _panelX() + _qtContentInsetX;
      expect(frame.hits[0].sublist(0, 4),
          <Object?>[x + _qtCloseDx, 690 + _qtCloseDy, _qtCloseW, _qtCloseH]);
      expect(frame.hits[1].sublist(0, 4),
          <Object?>[x, 690 + _qtOffsetDy, _qtOffsetW, _qtOffsetH]);
      expect(frame.hits[2].sublist(0, 4),
          <Object?>[x + _qtColumnDx, 690 + _qtOffsetDy, _qtOffsetW, _qtOffsetH]);
      expect(frame.hits[3].sublist(0, 4),
          <Object?>[x, 690 + _qtBottomDy, _qtOffsetW, _qtOffsetH]);
      expect(frame.hits[4].sublist(0, 4), <Object?>[
        x + _qtColumnDx,
        690 + _qtBottomDy,
        _qtOffsetW,
        _qtOffsetH,
      ]);
    });

    test('hit tables match Qt for every label / button combination', () {
      expect(_modal().build().hits, _qtHits());
      expect(_modal(offsetMs: 0, globalOffsetMs: 0).build().hits,
          _qtHits(offsetMs: 0, globalOffsetMs: 0));
      expect(_modal(offsetMs: 0, globalOffsetMs: 200).build().hits,
          _qtHits(offsetMs: 0, globalOffsetMs: 200));
      expect(_modal(offsetMs: 200, globalOffsetMs: 200).build().hits,
          _qtHits(offsetMs: 200, globalOffsetMs: 200));
      expect(_modal(width: 1280).build().hits, _qtHits(width: 1280));
    });

    test('an omitted label falls back to the action '
        '(Qt label.isNull() ? action : label - NativeHud.cpp:108)', () {
      expect(
        LyricsOffsetModal.hitRow(1, 2, 3, 4, 'player:lyrics-reset'),
        <Object?>[1, 2, 3, 4, 'player:lyrics-reset', 'player:lyrics-reset'],
      );
      expect(
        LyricsOffsetModal.hitRow(1, 2, 3, 4, 'close-modal', '关闭'),
        <Object?>[1, 2, 3, 4, 'close-modal', '关闭'],
      );
      expect(
        LyricsOffsetModal.hitRow(0, 0, 0, 0, _qtEscapeKey),
        <Object?>[0, 0, 0, 0, _qtEscapeKey, _qtEscapeKey],
      );
    });

    test('no row is empty and no row is a full-stage catcher '
        '(contrast NativeHudModal.cpp:128)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.hits, isNot(contains('关闭排序菜单')));
      for (final List<Object?> hit in frame.hits) {
        expect((hit[4]! as String).isEmpty, isFalse);
        expect((hit[5]! as String).isEmpty, isFalse);
        expect(hit[2]! as double > 0, isTrue);
        expect(hit[3]! as double > 0, isTrue);
      }
    });
  });

  // -------------------------------------------------------------------------
  // 7. Button mechanics (Qt/src/NativeHud.cpp:110-120).
  // -------------------------------------------------------------------------
  group('button mechanics', () {
    test('inset = min(10, width / 8): 7 px in the 56 px close button, 10 px in '
        'the 138 px buttons', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[6][2], (frame.commands[5][2]! as double) + 7);
      expect(frame.commands[9][2], (frame.commands[8][2]! as double) + 10);
      expect(frame.commands[13][2], (frame.commands[12][2]! as double) + 10);
      expect(_qtMin(10, _qtCloseW / 8), 7);
      expect(_qtMin(10, _qtOffsetW / 8), 10);
    });

    test('button text sits at y + (height - size) / 2 - 4', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(
        frame.commands[6][3],
        (frame.commands[5][3]! as double) + (_qtCloseH - _qtCloseSize) / 2 - 4,
      );
      expect(
        frame.commands[9][3],
        (frame.commands[8][3]! as double) +
            (_qtOffsetH - _qtOffsetSize) / 2 -
            4,
      );
      expect((_qtOffsetH - _qtOffsetSize) / 2 - 4, 9.5);
      expect((_qtCloseH - _qtCloseSize) / 2 - 4, 7.5);
    });

    test('button text is regular ink with tracking 0 and the fill is the '
        'modal tint, emitted after the hit (NativeHud.cpp:112-119)', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      final List<Object?> text = frame.commands[9];
      expect(text[5], 'regular');
      expect(text[6], 0);
      expect(text[7], _qtLightInk);
      expect(frame.commands[8][1], _qtLightButtonTint);
      expect(frame.hits.first[4], _qtCloseAction);
      expect(frame.commands[5][1], _qtLightButtonTint);
    });

    test('fit() measures through the injected hook, with fit default weight '
        'regular and tracking 0 (NativeHud.cpp:118, NativeHud.h:249)', () {
      final _Measure measure = _Measure(0.5);
      _modal(measure: measure).build();
      expect(
        measure.calls.map((List<Object?> c) => c[0]).toList(),
        <String>[
          _qtCloseLabel,
          _qtEarlierLabel,
          _qtLaterLabel,
          _qtResetLabel,
          _qtApplyGlobalLabel,
        ],
      );
      expect(
        measure.calls.every((List<Object?> c) => c[2] == 'regular'),
        isTrue,
      );
      expect(measure.calls.every((List<Object?> c) => c[3] == 0), isTrue);
      expect(measure.calls.first[1], _qtCloseSize);
    });

    test('a non-truncating measurer keeps the whole label', () {
      final LyricsOffsetModalFrame frame = _modal().build();
      expect(frame.commands[6][1], _qtCloseLabel);
      expect(frame.commands[9][1], _qtEarlierLabel);
      expect(frame.commands[11][1], _qtLaterLabel);
    });

    test('a wide measurer truncates to the Qt prefix + ellipsis: the close '
        'label becomes the bare ellipsis and the 0.2 s labels become 歌…', () {
      final _Measure measure = _Measure(4);
      final LyricsOffsetModalFrame frame =
          _modal(measure: measure, offsetMs: 0, globalOffsetMs: 0).build();
      expect(frame.commands[6][1], '…');
      expect(frame.commands[9][1], '歌…');
      expect(frame.commands[11][1], '歌…');
      expect(
        frame.commands[6][1],
        _qtFit(_qtCloseLabel, _qtCloseSize, _qtCloseW - 7 * 2, 4),
      );
      expect(
        frame.commands[9][1],
        _qtFit(_qtEarlierLabel, _qtOffsetSize, _qtOffsetW - 10 * 2, 4),
      );
      // the search starts from the whole label
      expect(measure.calls.first[0], _qtCloseLabel);
      expect(measure.calls.length > 3, isTrue);
    });

    test('the quiet fallback texts are never truncated: Qt text() takes no '
        'width (NativeHud.h:245)', () {
      final _Measure measure = _Measure(4);
      final LyricsOffsetModalFrame frame =
          _modal(measure: measure, offsetMs: 0, globalOffsetMs: 0).build();
      expect(frame.commands[7][1], _qtOffsetLabel(0));
      expect(frame.commands[12][1], _qtResetLabel);
      expect(frame.commands[13][1], _qtApplyGlobalLabel);
    });
  });

  // -------------------------------------------------------------------------
  // 8. SurfaceMotion (Qt/src/UiMotion.h:24-42, UiMotion.cpp:7-22, 86-120).
  // -------------------------------------------------------------------------
  group('motion', () {
    test('starts transparent, offset 12, settled (UiMotion.h:31-33, 28-30)',
        () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion();
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
    });

    test('set(true) targets opacity 1 / offset 0 with duration 0.3 and does '
        'not jump (UiMotion.cpp:101-115)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 0);
      expect(motion.duration, 0.3);
      expect(motion.finished, isFalse);
      expect(motion.opacity, 0);
      expect(motion.offset, 12);
    });

    test('sample() lerps along the entering bezier (UiMotion.cpp:86-98)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 0);
      motion.sample(0.15);
      final double amount = _enterAmount(0.5);
      expect(motion.opacity, closeTo(amount, 1e-12));
      expect(motion.offset, closeTo(12 * (1 - amount), 1e-12));
      expect(motion.duration, 0.3);
      // the entering control points are (0.22, 1) and (0.36, 1)
      expect(motion.opacity, isNot(closeTo(_leaveAmount(0.5), 1e-3)));
    });

    test('sample() clamps to the end and settles: opacity 1, offset 0, '
        'duration 0 (UiMotion.cpp:90-97)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 0);
      motion.sample(0.3);
      expect(motion.opacity, closeTo(1, 1e-9));
      expect(motion.offset, closeTo(0, 1e-9));
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
      motion.sample(5);
      expect(motion.opacity, closeTo(1, 1e-9));
      expect(motion.offset, closeTo(0, 1e-9));
    });

    test('set(false) targets opacity 0 / offset 8 with duration 0.2 and the '
        'leaving bezier (UiMotion.cpp:91-92, 113-114)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()
        ..set(true, 0)
        ..sample(0.3)
        ..set(false, 1);
      expect(motion.duration, 0.2);
      expect(motion.opacity, closeTo(1, 1e-9));
      expect(motion.offset, closeTo(0, 1e-9));
      motion.sample(1.1);
      final double amount = _leaveAmount(0.5);
      expect(motion.opacity, closeTo(1 - amount, 1e-12));
      expect(motion.offset, closeTo(8 * amount, 1e-12));
      // 1.3 - 1 is 0.30000000000000004, so the progress clamps to exactly 1.
      // 1.2 - 1 is 0.19999999999999996 and would leave the transition
      // unfinished, because Qt settles only at progress >= 1.
      motion.sample(1.3);
      expect(motion.opacity, closeTo(0, 1e-9));
      expect(motion.offset, closeTo(8, 1e-9));
      expect(motion.duration, 0);
      expect(motion.finished, isTrue);
    });

    test('reduced motion snaps: duration 0 and the target applied at once '
        '(UiMotion.cpp:109-119)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()
        ..set(true, 3.5, true);
      expect(motion.duration, 0);
      expect(motion.opacity, 1);
      expect(motion.offset, 0);
      expect(motion.finished, isTrue);
      motion.set(false, 4, true);
      expect(motion.duration, 0);
      expect(motion.opacity, 0);
      expect(motion.offset, 8);
      expect(motion.finished, isTrue);
    });

    test('a re-set samples the in-flight transition first, so a fast toggle '
        'continues instead of jumping (UiMotion.cpp:100-103)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 0);
      motion.sample(0.15);
      final double midOpacity = motion.opacity;
      final double midOffset = motion.offset;
      motion.set(false, 0.15);
      expect(motion.duration, 0.2);
      expect(motion.opacity, midOpacity);
      expect(motion.offset, midOffset);
      motion.sample(0.25);
      final double amount = _leaveAmount(0.5);
      expect(motion.opacity, closeTo(midOpacity * (1 - amount), 1e-12));
      expect(
        motion.offset,
        closeTo(midOffset + (8 - midOffset) * amount, 1e-12),
      );
    });

    test('progress is clamped below the start: the surface stays at the from '
        'state (UiMotion.cpp:90)', () {
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 10);
      motion.sample(0);
      expect(motion.opacity, closeTo(0, 1e-6));
      expect(motion.offset, closeTo(12, 1e-5));
      expect(motion.duration, 0.3);
    });

    test('the bezier helper is Qt 24-step bisection with midpoint evaluation '
        '(UiMotion.cpp:7-22)', () {
      expect(_refBezier(0, 0.22, 1, 0.36, 1), closeTo(0, 1e-6));
      expect(_refBezier(1, 0.22, 1, 0.36, 1), closeTo(1, 1e-9));
      expect(_refBezier(0, 0.4, 0, 1, 1), closeTo(0, 1e-6));
      expect(_refBezier(1, 0.4, 0, 1, 1), closeTo(1, 1e-9));
      final LyricsOffsetMotion motion = LyricsOffsetMotion()..set(true, 0);
      motion.sample(0.075);
      expect(motion.opacity, closeTo(_enterAmount(0.25), 1e-12));
      motion.sample(0.225);
      expect(motion.opacity, closeTo(_enterAmount(0.75), 1e-12));
    });
  });

  // -------------------------------------------------------------------------
  // 9. Injection: rect hook and measurement.
  // -------------------------------------------------------------------------
  group('injection', () {
    test('the rect hook is applied exactly once per emitted rect: panel plus '
        'every control, at the Qt coordinates', () {
      final _RectSpy spy = _RectSpy(0, 0);
      _modal(rectHook: spy.call).build();
      final double x = _panelX() + _qtContentInsetX;
      expect(spy.inputs, <List<double>>[
        <double>[_panelX(), _qtPanelTop, _qtPanelWidth, _qtPanelHeight],
        <double>[x + _qtCloseDx, _qtPanelTop + _qtCloseDy, _qtCloseW, _qtCloseH],
        <double>[x, _qtPanelTop + _qtOffsetDy, _qtOffsetW, _qtOffsetH],
        <double>[
          x + _qtColumnDx,
          _qtPanelTop + _qtOffsetDy,
          _qtOffsetW,
          _qtOffsetH,
        ],
        <double>[x, _qtPanelTop + _qtBottomDy, _qtOffsetW, _qtOffsetH],
        <double>[
          x + _qtColumnDx,
          _qtPanelTop + _qtBottomDy,
          _qtOffsetW,
          _qtOffsetH,
        ],
      ]);
    });

    test('with both bottom controls quiet the hook sees four rects only', () {
      final _RectSpy spy = _RectSpy(0, 0);
      _modal(rectHook: spy.call, offsetMs: 0, globalOffsetMs: 0).build();
      expect(spy.inputs.length, 4);
    });

    test('a translating hook moves commands and hits by the same delta', () {
      final LyricsOffsetModalFrame plain = _modal().build();
      final LyricsOffsetModalFrame shifted =
          _modal(rectHook: _RectSpy(100, 50).call).build();
      expect(shifted.commands[3][2], (plain.commands[3][2]! as double) + 100);
      expect(shifted.commands[3][3], (plain.commands[3][3]! as double) + 50);
      expect(shifted.hits.length, plain.hits.length);
      for (int i = 0; i < plain.hits.length; i++) {
        expect(shifted.hits[i][0], (plain.hits[i][0]! as double) + 100);
        expect(shifted.hits[i][1], (plain.hits[i][1]! as double) + 50);
        expect(shifted.hits[i][2], plain.hits[i][2]);
        expect(shifted.hits[i][3], plain.hits[i][3]);
      }
    });

    test('a hook that does not return four values is rejected', () {
      expect(
        () => _modal(
          rectHook: (double x, double y, double w, double h) => <double>[x, y, w],
        ).build(),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('a zero-width measurer never truncates, so no glyph constant is '
        'baked into the port', () {
      final LyricsOffsetModalFrame frame = _modal(measure: _Measure(0)).build();
      expect(frame.commands[6][1], _qtCloseLabel);
      expect(frame.commands[9][1], _qtEarlierLabel);
    });
  });

  // -------------------------------------------------------------------------
  // 10. Static contract: kind, actions, documented action table.
  // -------------------------------------------------------------------------
  group('static contract', () {
    test('the modal kind and the five actions are the Qt strings '
        '(NativeHudController.cpp:324-335, 686-687)', () {
      expect(LyricsOffsetModal.kind, _qtKind);
      expect(LyricsOffsetModal.actionClose, _qtCloseAction);
      expect(LyricsOffsetModal.actionEarlier, _qtEarlierAction);
      expect(LyricsOffsetModal.actionLater, _qtLaterAction);
      expect(LyricsOffsetModal.actionReset, _qtResetAction);
      expect(LyricsOffsetModal.actionApplyGlobal, _qtApplyGlobalAction);
      expect(LyricsOffsetModal.escapeKey, _qtEscapeKey);
    });

    test('the action table documents every action once, with the Qt labels '
        'and an evidence pointer', () {
      final List<LyricsOffsetActionEntry> table = LyricsOffsetModal.actionTable;
      expect(table.length, 6);
      expect(
        table.map((LyricsOffsetActionEntry e) => e.action).toList(),
        <String>[
          _qtCloseAction,
          _qtEscapeKey,
          _qtEarlierAction,
          _qtLaterAction,
          _qtResetAction,
          _qtApplyGlobalAction,
        ],
      );
      expect(
        table.map((LyricsOffsetActionEntry e) => e.label).toList(),
        <String>[
          _qtCloseLabel,
          '',
          _qtEarlierLabel,
          _qtLaterLabel,
          _qtResetLabel,
          _qtApplyGlobalLabel,
        ],
      );
      for (final LyricsOffsetActionEntry entry in table) {
        expect(entry.effect.isEmpty, isFalse);
        expect(entry.qtEvidence.isEmpty, isFalse);
        expect(entry.qtEvidence.contains('Qt/src/'), isTrue);
      }
    });

    test('Escape closes the popover: the documented escape row dispatches '
        'close-modal, and only desktop-lyrics / the empty modal differ '
        '(NativeHudController.cpp:913-925)', () {
      final LyricsOffsetActionEntry escape = LyricsOffsetModal.actionTable
          .firstWhere((LyricsOffsetActionEntry e) =>
              e.action == LyricsOffsetModal.escapeKey);
      expect(escape.label, isEmpty);
      expect(escape.effect, contains(_qtCloseAction));
      expect(escape.effect, contains('desktop-lyrics'));
    });

    test('the close action is the shared close-modal string, not a popover '
        'specific one (NativeHudController.cpp:686-687)', () {
      expect(LyricsOffsetModal.actionClose, 'close-modal');
      expect(_modal().build().hits.first[4], _qtCloseAction);
    });
  });
}
