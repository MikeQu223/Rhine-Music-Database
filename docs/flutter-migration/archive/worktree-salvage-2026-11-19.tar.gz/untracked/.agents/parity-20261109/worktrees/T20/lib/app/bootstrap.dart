/// Architecture-neutral bootstrap for the Qt to Flutter port (plan T20, atom
/// T20-C18-S02).
///
/// This file imports nothing. The shell knows only the ports a host injects, so
/// the same startup sequence drives the Flutter shell, an embedded engine or an
/// offline unit test. Wiring main, the router and the lifecycle machine is
/// deliberately out of scope: lib/app/lifecycle.dart already owns the one-time
/// initialization sequence (Qt/src/NativeApplication.cpp:44-90).
///
/// Ownership of the engine, so two machines never claim the same attach:
/// AppLifecycle owns the one attach of the process-scoped engine and the
/// initialization sequence that follows it (lib/app/lifecycle.dart:355-365,
/// Qt/src/Engine.cpp:53, Qt/src/Engine.cpp:66). [ShellBootstrap] owns only the
/// startup phases and the failure boundary, and reaches the engine through
/// [ShellPorts]. The composition root must implement those ports over the same
/// AppLifecycle instance and must never wire bootstrap to a second
/// attachEngine: an adapter whose attachEngine() delegates to
/// AppLifecycle.grantConsent() has already run the initialization, so its
/// initializeShell() must then report that single result instead of starting a
/// second sequence. Routes belong to lib/app/router.dart and composition belongs
/// to lib/main.dart; neither is this file's job.
///
/// Consent has three Qt paths, and all three are explicit here:
/// a grant writes the persistent mark and launches Qt
/// (Qt/android/src/rhine/music/database/ConsentActivity.java:122-127), a
/// decline finishes the task (Qt/android/src/rhine/music/database/
/// ConsentActivity.java:126), and outside mainland China and the EU, or when
/// the region probe times out, the Activity starts Qt without a dialog and
/// without writing a persistent mark (Qt/android/src/rhine/music/database/
/// ConsentActivity.java:100-105). The third path is
/// [ShellBootstrap.consentNotRequired]: it reaches the engine exactly like a
/// grant, but records nothing about a persistent grant, because Qt writes
/// nothing there and re-decides on the next start. [ShellPhase.consentPending]
/// is a phase, not a screen, so a host that already resolved consent may pass
/// through it without rendering anything.
///
/// Rules carried over from Qt, each with the source line it came from:
///
/// * Consent is a gate in front of the whole Qt process, not a screen inside it.
///   The consent Activity launches QtActivity only after the grant and finishes
///   the task on decline
///   (Qt/android/src/rhine/music/database/ConsentActivity.java:122-127,
///   Qt/android/src/rhine/music/database/ConsentActivity.java:148-156), so a
///   declined run never reaches the engine.
/// * Process identity and the graphics adjudication land before the first
///   window, and the capability snapshot is published from that adjudication
///   (Qt/src/main.cpp:880-882, Qt/src/main.cpp:906-908,
///   Qt/src/main.cpp:920-936). The matrix is injected here for the same reason:
///   bootstrap reads it and never invents one.
/// * The bridge process is the failure boundary. FailedToStart ends every
///   pending request with its own message, a finished child ends them with
///   another, and 32 MiB of unread stdout kills the child instead of growing the
///   buffer (Qt/src/Host.cpp:82-91, Qt/src/Host.cpp:110-117,
///   Qt/src/Host.cpp:92-98).
/// * Some Qt failures are process-fatal: qFatal in the renderer and glyph paths
///   (Qt/src/RhiScene.cpp:132, Qt/src/RhiScene.cpp:145, Qt/src/RhiScene.cpp:149,
///   Qt/src/render/SceneResources.h:38, Qt/src/Glyphs.cpp:31). A Flutter shell
///   cannot recover from those either, so the boundary records the phase, the
///   message and the cause and hands them to the host instead of pretending to
///   restart the failed step on its own.
library;

/// Startup phases of the shell, in the order a successful run passes them.
enum ShellPhase {
  /// Nothing started yet; no port may run, because Qt itself has not been
  /// launched (Qt/android/src/rhine/music/database/ConsentActivity.java:148-156).
  idle,

  /// Consent is being asked. Nothing business-related may run here.
  consentPending,

  /// Consent declined: the host exits and nothing else runs
  /// (Qt/android/src/rhine/music/database/ConsentActivity.java:126).
  consentDeclined,

  /// The process-scoped engine is being attached. Qt builds the bridge child
  /// once per process and treats a failure to start it as the first boundary
  /// (Qt/src/Host.cpp:82-91).
  ///
  /// The capability matrix is read in this phase too, because the matrix is the
  /// adjudication the engine is configured from (Qt/src/main.cpp:920-936). A
  /// failure here may therefore mean "the engine did not start" or "the matrix
  /// could not be read"; both are reported against this phase and both end in
  /// [ShellFallbackReason.engineMissing], because neither leaves the shell with
  /// a usable engine configuration.
  attaching,

  /// The one-time initialization is in flight
  /// (Qt/src/NativeApplication.cpp:44-90; driven by lib/app/lifecycle.dart).
  initializing,

  /// Engine attached and initialization finished; the UI may render.
  ready,

  /// A port threw. [ShellSnapshot.failure] and [ShellSnapshot.fallback] carry
  /// the record; only [ShellBootstrap.retry] may re-enter a single phase.
  failed,
}

/// Why the shell kept, or opened, its fallback entry.
enum ShellFallbackReason {
  /// Consent declined: the app closes before any business port runs
  /// (Qt/android/src/rhine/music/database/ConsentActivity.java:126).
  consentDeclined,

  /// The attaching step could not finish: either the engine failed to start,
  /// in which case Qt answers every pending request with the missing-component
  /// message (Qt/src/Host.cpp:82-91), or the capability matrix that decides how
  /// to start it could not be read. Without that adjudication the shell must
  /// not guess an engine configuration, so both cases land here.
  engineMissing,

  /// The music service exited after being attached; pending requests end with
  /// the retry message (Qt/src/Host.cpp:110-117).
  serviceExited,

  /// Initialization failed after the engine was attached.
  initializationFailed,
}

/// One failure captured at the startup boundary.
class ShellFailure {
  const ShellFailure({
    required this.phase,
    required this.message,
    this.cause,
    this.stackTrace,
  });

  /// Phase that was running when the port threw.
  final ShellPhase phase;

  /// Text the host may show. The port's own wording is forwarded verbatim so
  /// the product copy stays with the port that owns it (Qt/src/Host.cpp:89,
  /// Qt/src/Host.cpp:115); bootstrap never composes a message of its own.
  final String message;

  /// Captured exception, kept for diagnostics.
  final Object? cause;

  /// Stack trace of [cause], kept for diagnostics.
  final StackTrace? stackTrace;
}

/// Capability matrix the host adjudicated for this build.
///
/// Every value is injected. Bootstrap stores the matrix verbatim and never
/// substitutes a default, because the adjudication is an architecture decision
/// that lives outside this file. The frame-generation triple mirrors
/// RhineFg::CapabilitySnapshot (Qt/src/fg/FgCapability.h:20-32) and [notes]
/// carries the strings that snapshot publishes for the settings surface, for
/// example the "此构建未编入 Vulkan 帧生成" line from Qt/src/main.cpp:935.
class ShellCapabilities {
  ShellCapabilities({
    required this.backend,
    required this.vsync,
    required this.supersample,
    required this.renderScale,
    required this.antialiasing,
    required this.frameGeneration,
    required this.frameGenerationPresentLayer,
    required this.frameGenerationInterpolation,
    required List<String> notes,
    this.fallbackEntry,
  }) : notes = List<String>.unmodifiable(notes);

  /// Graphics backend the adjudication selected
  /// (RhineGraphics::activeBackend, Qt/src/main.cpp:921-923).
  final String backend;

  /// Vertical-sync preference applied before the first window
  /// (Qt/src/main.cpp:924).
  final bool vsync;

  /// Supersampling preference (Qt/src/main.cpp:925).
  final bool supersample;

  /// Render-scale multiplier (Qt/src/main.cpp:926).
  final double renderScale;

  /// Antialiasing preference (Qt/src/main.cpp:927).
  final bool antialiasing;

  /// Frame-generation component compiled into this build
  /// (Qt/src/fg/FgCapability.h:20-21, Qt/src/main.cpp:931-935).
  final bool frameGeneration;

  /// The presentation layer owns the swap chain
  /// (Qt/src/fg/FgCapability.h:22-28).
  final bool frameGenerationPresentLayer;

  /// Interpolation really runs; a runtime failure drops it back to false
  /// (Qt/src/fg/FgCapability.h:29-30).
  final bool frameGenerationInterpolation;

  /// Strings the snapshot publishes (Qt/src/main.cpp:929-936).
  final List<String> notes;

  /// Optional marker of the fallback entry the adjudication kept.
  ///
  /// Null means the matrix did not name one. In that case
  /// [ShellBootstrap.keepFallbackEntry] stays true, so the entry keeps being
  /// offered instead of being hidden behind an invented capability value
  /// (plan T20 line 520).
  final String? fallbackEntry;

  /// True only when the component is compiled in, the presentation layer is
  /// active and interpolation really runs (Qt/src/fg/FgCapability.h:60-63).
  bool get frameGenerationUsable =>
      frameGeneration &&
      frameGenerationPresentLayer &&
      frameGenerationInterpolation;

  /// Value equality over all nine injected fields, including the note strings.
  ///
  /// Without it a caller could only compare matrices by identity, which would
  /// make "the matrix the host adjudicated" untestable by value.
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    return other is ShellCapabilities &&
        other.backend == backend &&
        other.vsync == vsync &&
        other.supersample == supersample &&
        other.renderScale == renderScale &&
        other.antialiasing == antialiasing &&
        other.frameGeneration == frameGeneration &&
        other.frameGenerationPresentLayer == frameGenerationPresentLayer &&
        other.frameGenerationInterpolation == frameGenerationInterpolation &&
        other.fallbackEntry == fallbackEntry &&
        _sameNotes(other.notes);
  }

  @override
  int get hashCode => Object.hash(
    backend,
    vsync,
    supersample,
    renderScale,
    antialiasing,
    frameGeneration,
    frameGenerationPresentLayer,
    frameGenerationInterpolation,
    fallbackEntry,
    Object.hashAll(notes),
  );

  @override
  String toString() =>
      'ShellCapabilities(backend: ' +
      backend +
      ', renderScale: ' +
      renderScale.toString() +
      ', frameGenerationUsable: ' +
      frameGenerationUsable.toString() +
      ', fallbackEntry: ' +
      (fallbackEntry ?? 'none') +
      ')';

  bool _sameNotes(List<String> other) {
    if (other.length != notes.length) {
      return false;
    }
    for (int index = 0; index < notes.length; index += 1) {
      if (other[index] != notes[index]) {
        return false;
      }
    }
    return true;
  }
}

/// Host services the bootstrap drives.
///
/// Implementations adapt these calls to whatever host was adjudicated; the
/// bootstrap never constructs a host object itself. Every member can be faked,
/// and no test may reach a real engine.
abstract interface class ShellPorts {
  /// Builds the process-scoped engine. A throw here is the engine boundary:
  /// Qt ends every pending request with its missing-component message instead
  /// of continuing without a bridge (Qt/src/Host.cpp:82-91).
  void attachEngine();

  /// Runs the one-time initialization
  /// (Qt/src/NativeApplication.cpp:44-90).
  void initializeShell();

  /// Records a failure the shell cannot recover from on its own
  /// (Qt/src/RhiScene.cpp:132, Qt/src/render/SceneResources.h:38).
  void reportFailure(ShellFailure failure);

  /// Opens the fallback entry for [reason] instead of entering business
  /// (plan T20 line 520).
  void showFallback(ShellFallbackReason reason);

  /// Capability matrix of the running build. Injected, never derived here
  /// (Qt/src/main.cpp:929-936).
  ///
  /// A throw is treated like a failed attach: the matrix is the adjudication
  /// the engine is started from, so the shell reports
  /// [ShellFallbackReason.engineMissing] and never invents a default matrix.
  ShellCapabilities capabilities();
}

/// Sentinel that lets [ShellSnapshot.copyWith] tell "leave this field alone"
/// from "clear this nullable field".
const Object _unset = Object();

/// Immutable reading of the bootstrap, safe to hand to the UI layer.
class ShellSnapshot {
  ShellSnapshot({
    required this.phase,
    required this.failure,
    required this.retryCount,
    required this.engineAttached,
    required this.fallback,
    required this.capabilities,
    required List<ShellPhase> completedPhases,
  }) : completedPhases = List<ShellPhase>.unmodifiable(completedPhases);

  /// Current phase.
  final ShellPhase phase;

  /// Last captured failure, null until a port throws.
  final ShellFailure? failure;

  /// How many [ShellBootstrap.retry] calls ran, successful or not.
  final int retryCount;

  /// True once [ShellPorts.attachEngine] returned.
  final bool engineAttached;

  /// Reason the fallback entry was opened for, null while nothing failed and
  /// consent was not declined.
  final ShellFallbackReason? fallback;

  /// Injected matrix, null until it is read or when no matrix was supplied.
  final ShellCapabilities? capabilities;

  /// Phases that actually finished, in order.
  ///
  /// A phase is recorded only after its ports returned, so a failed step never
  /// appears here; [ShellPhase.ready] is recorded because it is the terminal
  /// success of this machine.
  ///
  /// The list is history, not the current verdict: a shell that reached
  /// [ShellPhase.ready] and then lost the music service keeps
  /// [ShellPhase.ready] here while [phase] reads [ShellPhase.failed]. Render
  /// from [phase]; use this list only for diagnostics.
  final List<ShellPhase> completedPhases;

  /// True when the shell may render business UI.
  bool get isReady => phase == ShellPhase.ready;

  /// True when a port threw.
  bool get isFailed => phase == ShellPhase.failed;

  /// Pure update. Passing null clears [failure], [fallback] or [capabilities]
  /// on purpose; omit the argument to keep the current value.
  ShellSnapshot copyWith({
    ShellPhase? phase,
    Object? failure = _unset,
    int? retryCount,
    bool? engineAttached,
    Object? fallback = _unset,
    Object? capabilities = _unset,
    List<ShellPhase>? completedPhases,
  }) {
    return ShellSnapshot(
      phase: phase ?? this.phase,
      failure: identical(failure, _unset)
          ? this.failure
          : failure as ShellFailure?,
      retryCount: retryCount ?? this.retryCount,
      engineAttached: engineAttached ?? this.engineAttached,
      fallback: identical(fallback, _unset)
          ? this.fallback
          : fallback as ShellFallbackReason?,
      capabilities: identical(capabilities, _unset)
          ? this.capabilities
          : capabilities as ShellCapabilities?,
      completedPhases: completedPhases ?? this.completedPhases,
    );
  }
}

/// Drives the startup phases and the error boundary over injected [ShellPorts].
///
/// The machine is synchronous on purpose: every step is a call the host makes,
/// so a unit test needs no binding, no engine and no event loop.
class ShellBootstrap {
  /// Creates the machine in [ShellPhase.idle].
  ///
  /// [initialCapabilities] wins over [ShellPorts.capabilities], so a host that
  /// already resolved the adjudication does not expose it twice.
  ShellBootstrap(this._ports, {ShellCapabilities? initialCapabilities})
    : _initialCapabilities = initialCapabilities;

  final ShellPorts _ports;
  final ShellCapabilities? _initialCapabilities;

  ShellPhase _phase = ShellPhase.idle;
  ShellFailure? _failure;
  int _retryCount = 0;
  bool _engineAttached = false;
  ShellFallbackReason? _fallback;
  ShellCapabilities? _capabilities;
  final List<ShellPhase> _completedPhases = <ShellPhase>[];

  /// Current immutable reading.
  ShellSnapshot get snapshot => ShellSnapshot(
    phase: _phase,
    failure: _failure,
    retryCount: _retryCount,
    engineAttached: _engineAttached,
    fallback: _fallback,
    capabilities: _capabilities,
    completedPhases: _completedPhases,
  );

  /// True while the injected matrix has not named a fallback entry.
  ///
  /// Covers both "no matrix at all" and "matrix without a fallback marker".
  /// The UI must keep showing the fallback entry in either case rather than
  /// filling the gap with a default, which is what plan T20 line 520 asks for.
  bool get keepFallbackEntry {
    final ShellCapabilities? caps = _capabilities;
    return caps == null || caps.fallbackEntry == null;
  }

  /// idle -> consentPending. No port is called: consent precedes the Qt
  /// process itself (Qt/android/src/rhine/music/database/ConsentActivity.java
  /// :148-156).
  void start() {
    _require(ShellPhase.idle, 'start');
    _phase = ShellPhase.consentPending;
    _recordPhase(ShellPhase.consentPending);
  }

  /// consentPending -> attaching -> initializing -> ready.
  ///
  /// This is the only entry point that ever attaches the engine, exactly like
  /// the consent grant is the only one that launches QtActivity
  /// (Qt/android/src/rhine/music/database/ConsentActivity.java:122-127).
  void grantConsent() {
    _require(ShellPhase.consentPending, 'grantConsent');
    _attachAndInitialize();
  }

  /// consentPending -> attaching -> initializing -> ready without a prompt.
  ///
  /// This is Qt's third consent path: outside mainland China and the EU, or
  /// when the region probe times out within three seconds, the Activity starts
  /// Qt without a dialog and without writing a persistent mark, so the next
  /// start decides again (Qt/android/src/rhine/music/database/
  /// ConsentActivity.java:100-105). The phase sequence is identical to
  /// [grantConsent] because the process starts identically; the difference is
  /// that nothing here may be read as "the user granted consent persistently".
  void consentNotRequired() {
    _require(ShellPhase.consentPending, 'consentNotRequired');
    _attachAndInitialize();
  }

  void _attachAndInitialize() {
    _attach();
    if (_phase == ShellPhase.failed) {
      return;
    }
    _initialize();
    if (_phase == ShellPhase.failed) {
      return;
    }
    _enterReady();
  }

  /// consentPending -> consentDeclined. The engine is never attached and the
  /// fallback entry is the only thing the host may show
  /// (Qt/android/src/rhine/music/database/ConsentActivity.java:126).
  void declineConsent() {
    _require(ShellPhase.consentPending, 'declineConsent');
    _phase = ShellPhase.consentDeclined;
    _recordPhase(ShellPhase.consentDeclined);
    _showFallback(ShellFallbackReason.consentDeclined);
  }

  /// The host observed the music service exit after it was attached.
  ///
  /// Qt ends every pending request with "音乐服务已退出，请重试" and keeps the
  /// process alive (Qt/src/Host.cpp:110-117), so the message is supplied by the
  /// port and forwarded verbatim. The failure is recorded against
  /// [ShellPhase.attaching], because the bridge child belongs to that step and
  /// that is the step [retry] may re-enter.
  void noteServiceExited({
    required String message,
    Object? cause,
    StackTrace? stackTrace,
  }) {
    final bool attached = _engineAttached;
    final bool live =
        _phase == ShellPhase.initializing || _phase == ShellPhase.ready;
    if (!attached || !live) {
      throw StateError(
        'noteServiceExited is only valid after the engine was attached, '
        'bootstrap is in ' + _phase.name,
      );
    }
    _fail(
      ShellFailure(
        phase: ShellPhase.attaching,
        message: message,
        cause: cause,
        stackTrace: stackTrace,
      ),
      ShellFallbackReason.serviceExited,
    );
  }

  /// Re-enters exactly one phase after a failure. Illegal in every other phase.
  ///
  /// A failure in [ShellPhase.attaching] re-runs [ShellPorts.attachEngine] and
  /// then continues with the phases that never ran; a failure in
  /// [ShellPhase.initializing] re-runs [ShellPorts.initializeShell] only and
  /// never touches the attached engine again. Nothing already finished is
  /// replayed.
  void retry() {
    if (_phase != ShellPhase.failed) {
      throw StateError(
        'retry is only valid in ' +
            ShellPhase.failed.name +
            ', bootstrap is in ' +
            _phase.name,
      );
    }
    final ShellFailure? failure = _failure;
    if (failure == null) {
      throw StateError('retry without a recorded failure');
    }
    final ShellPhase step = failure.phase;
    if (step != ShellPhase.attaching && step != ShellPhase.initializing) {
      throw StateError('retry has no phase to re-enter for ' + step.name);
    }
    _retryCount += 1;
    _failure = null;
    _fallback = null;
    final bool initialized = _completedPhases.contains(ShellPhase.initializing);
    if (step == ShellPhase.attaching) {
      _attach();
      if (_phase == ShellPhase.failed) {
        return;
      }
      if (initialized) {
        // The engine came back after the service exited; initialization had
        // already finished and must not run a second time.
        _enterReady();
        return;
      }
    }
    _initialize();
    if (_phase == ShellPhase.failed) {
      return;
    }
    _enterReady();
  }

  void _attach() {
    _phase = ShellPhase.attaching;
    final bool done = _guard(
      ShellPhase.attaching,
      ShellFallbackReason.engineMissing,
      () {
        // The matrix is published from the same adjudication that precedes the
        // first window (Qt/src/main.cpp:920-936), so it is read before the
        // engine is built. A throwing probe is a startup failure and stays
        // inside this boundary; the matrix is then unknown, not fabricated.
        _resolveCapabilities();
        _ports.attachEngine();
        _engineAttached = true;
      },
    );
    if (done) {
      _recordPhase(ShellPhase.attaching);
    }
  }

  void _initialize() {
    _phase = ShellPhase.initializing;
    final bool done = _guard(
      ShellPhase.initializing,
      ShellFallbackReason.initializationFailed,
      _ports.initializeShell,
    );
    if (done) {
      _recordPhase(ShellPhase.initializing);
    }
  }

  void _enterReady() {
    _phase = ShellPhase.ready;
    _recordPhase(ShellPhase.ready);
  }

  /// Records a phase at most once, so a retry of an earlier step cannot make
  /// the snapshot claim a phase finished twice.
  void _recordPhase(ShellPhase phase) {
    if (!_completedPhases.contains(phase)) {
      _completedPhases.add(phase);
    }
  }

  /// The single failure boundary. Every port call made by this machine runs
  /// through here, so no host exception can escape into the UI layer.
  bool _guard(
    ShellPhase step,
    ShellFallbackReason reason,
    void Function() body,
  ) {
    try {
      body();
      return true;
    } catch (error, stackTrace) {
      _fail(
        ShellFailure(
          phase: step,
          message: error.toString(),
          cause: error,
          stackTrace: stackTrace,
        ),
        reason,
      );
      return false;
    }
  }

  void _fail(ShellFailure failure, ShellFallbackReason reason) {
    _phase = ShellPhase.failed;
    _failure = failure;
    _fallback = reason;
    _report(failure);
    _showFallback(reason);
  }

  /// Read once: a matrix that is already injected is never probed again, and a
  /// probe that threw is retried with the step that failed.
  void _resolveCapabilities() {
    if (_capabilities != null) {
      return;
    }
    final ShellCapabilities? injected = _initialCapabilities;
    if (injected != null) {
      _capabilities = injected;
      return;
    }
    _capabilities = _ports.capabilities();
  }

  /// The reporter is called exactly once per failure. A reporter that throws
  /// must not lose the primary failure and is never called a second time; the
  /// snapshot stays the authoritative record.
  void _report(ShellFailure failure) {
    try {
      _ports.reportFailure(failure);
    } catch (_) {
      // Documented above: the boundary records, it does not retry.
    }
  }

  void _showFallback(ShellFallbackReason reason) {
    try {
      _ports.showFallback(reason);
    } catch (_) {
      // A broken fallback entry must not turn a decline into a business start,
      // and must not erase the recorded phase or failure.
    }
  }

  void _require(ShellPhase expected, String event) {
    if (_phase != expected) {
      throw StateError(
        event +
            ' is only valid in ' +
            expected.name +
            ', bootstrap is in ' +
            _phase.name,
      );
    }
  }
}
