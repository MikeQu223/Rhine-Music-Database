#!/usr/bin/env node
'use strict';

// 源码级生命周期合同（RETENTION-FIX-223 / HEAP-219 的**已证**缺陷）。
//
// 证据面（只读，不重跑设备）：reports/HEAP-219.json 证明同一 PID 13337 在
// 6×Back/重开 + 早 HOME/重开 之后，已销毁 MainActivity 仍被两个 jni_global 根钉住：
//   RhineQtView.mContext > TARGET
//   QtWindow.mContext     > TARGET
// 源码面（本 fixture 直接解析真实 .java 的方法体，不看注释）：
//   1. RhineQtViews.releaseSceneViews 只 retire 场景 + 注销监听，**从不**把旧视图从父容器摘掉
//      → QtView.onDetachedFromWindow 永不跑 → destroyWindow() 永不跑 →
//      native deleteWindow(parentWindowRef)（QWindow::deleteLater）永不跑 →
//      QAndroidPlatformForeignWindow 里的 QtJniTypes::View m_view 全局引用（= Java 的
//      RhineQtView 对象）永生 → 那条 jni_global 根永生 → 它的 mContext（已销毁 Activity）永生。
//   2. createWindow 里等布局的延迟 Runnable 只判 isAttachedToWindow()：陈旧世代（旧宿主那一次
//      post）仍会拿旧 parentWindowRef 调 JNI create，把已退役世代拉起来。
//
// 断言全部**锚在方法与顺序**上（不是"文件里出现了某段文字"），并配一份 prepatch 负对照：
// 同一批谓词在"修复前"的代码片段上必须返回 false（否则断言是空的）。
//
// 跑法：node scripts/qt-host-release.fixture-test.cjs
// 退出码：0 = 全绿；1 = 有合同失败。不改任何产品文件、不连设备、不跑 Gradle。

const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const source = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');

const VIEWS = 'android/app/src/main/java/org/qtproject/qt/android/RhineQtViews.java';
const VIEW = 'android/app/src/main/java/org/qtproject/qt/android/RhineQtView.java';
const QTV = 'android/app/javapatch/src/org/qtproject/qt/android/QtView.java';

/** 去注释：断言一律在去注释文本上做，注释里的同名文字不许把断言变成恒真。 */
function stripComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\/|(^|[^:])\/\/[^\n]*/gm, (match, prefix) => prefix || '');
}

function fail(message) {
  throw new Error(message);
}

/** 取一个方法/代码块的平衡大括号体（不含最外层括号）。 */
function bodyAfter(text, signature) {
  const clean = stripComments(text);
  const start = clean.indexOf(signature);
  if (start === -1) fail(`missing: ${signature}`);
  const open = clean.indexOf('{', start);
  if (open === -1) fail(`missing body: ${signature}`);
  let depth = 0;
  for (let i = open; i < clean.length; i += 1) {
    if (clean[i] === '{') depth += 1;
    if (clean[i] === '}') {
      depth -= 1;
      if (depth === 0) return clean.slice(open + 1, i);
    }
  }
  fail(`unbalanced body: ${signature}`);
}

/** 取 `stop` 之前的那一段（用来表达"在调用 X 之前必须已经……"）。 */
function before(text, stop) {
  const at = text.indexOf(stop);
  return at === -1 ? null : text.slice(0, at);
}

// "本 runnable 是不是当前这一代"的判定。两种极性都接受：`sceneGeneration == generation`
// 与 `sceneGeneration != generation`（后者以 early-return 表达同一件事）。这里只做源码级
// 形状检查，极性是否用对了由下面的"reset 之前必须已有该判定"顺序断言与人工复核兜住。
const GEN_EQ = /sceneGeneration\s*[!=]=\s*generation|generation\s*[!=]=\s*sceneGeneration/;

// 挂载判定：`isAttachedToWindow()` 或 token 版 `isCurrentAttachment(attachmentToken)`。
// 后者在 QtView.java 里的实现是 `m_isAttached && m_attachmentGeneration == generation`，
// 即**包含**挂载检查且更严（还要求 token 仍是当前那次）。与 JUnit fixture
// QtSceneHostRetirementContractTest 的等价判定保持一致；prepatch 负对照没有任何一种形状，
// 仍然必须失败。
const ATTACH_GUARD = /isAttachedToWindow\s*\(\s*\)|isCurrentAttachment\s*\(\s*attachmentToken\s*\)/;

// ---------------------------------------------------------------------------
// 谓词：全部是 (text) => string|null，null = 通过，字符串 = 失败原因。
// 同一个谓词既跑真实源码（期望 null），也跑 prepatch 片段（期望非 null）。
// ---------------------------------------------------------------------------

/** 场景先退役、父容器后摘除。 */
function retireBeforeParentRemoval(releaseViews) {
  const retire = releaseViews.indexOf('releaseSceneForHostDestroy()');
  if (retire < 0) return 'releaseSceneViews never retires the scene';
  const at = releaseViews.indexOf('removeView(view)');
  if (at < 0) return 'old view is never removed from its parent ViewGroup';
  if (at < retire) return 'parent removal happens before scene retirement';
  return null;
}

/** 摘除必须以"上下文 == 被销毁的那个 Activity"为门（不许把活宿主的视图摘掉）。 */
function removalGuardedByOldActivityIdentity(releaseViews) {
  const at = releaseViews.indexOf('removeView(view)');
  if (at < 0) return 'old view is never removed from its parent';
  if (!releaseViews.slice(0, at).includes('view.getContext() == activity')) {
    return 'parent removal is not guarded by old Activity identity';
  }
  return null;
}

/** 摘除必须以"父容器真的存在且是 ViewGroup"为门（幂等：已摘下时不再动）。 */
function removalGuardedByLiveParent(releaseViews) {
  const at = releaseViews.indexOf('removeView(view)');
  if (at < 0) return 'old view is never removed from its parent';
  if (!/instanceof\s+ViewGroup/.test(releaseViews.slice(0, at))) {
    return 'parent removal is not guarded by a live ViewGroup parent';
  }
  return null;
}

/** 监听注销先于摘除（先松 Qt 的 app-state 列表，再走正常 detach）。 */
function listenerUnregisteredBeforeRemoval(releaseViews) {
  const unregister = releaseViews.indexOf('unregisterAppStateListener');
  const at = releaseViews.indexOf('removeView(view)');
  if (unregister < 0) return 'app-state listener is never unregistered';
  if (at < 0) return 'old view is never removed from its parent';
  if (at < unregister) return 'parent removal happens before listener unregistration';
  return null;
}

/** 走的是 Qt 自己的正常 detach 路径：super.onDetachedFromWindow() 且 destroyWindow()。 */
function normalDetachReleasesNativeParentWindow(detach) {
  if (!/super\.onDetachedFromWindow\s*\(\s*\)\s*;/.test(detach)) {
    return 'detach does not chain to super.onDetachedFromWindow()';
  }
  if (!/destroyWindow\s*\(\s*\)\s*;/.test(detach)) {
    return 'detach does not call destroyWindow() (native deleteWindow never runs)';
  }
  return null;
}

/** 延迟 create 之前必须同时看住：当前请求、世代、挂载状态。 */
function stalePostGuardsBeforeCreate(delayedRun) {
  const before = delayedRun.slice(0, delayedRun.indexOf('createEmbeddedScene('));
  if (delayedRun.indexOf('createEmbeddedScene(') < 0) return 'delayed create call is absent';
  if (!/sceneRequested/.test(before)) return 'delayed create does not check the current request';
  if (!GEN_EQ.test(before)) return 'delayed create does not check its generation';
  if (!ATTACH_GUARD.test(before)) return 'delayed create does not check attachment';
  return null;
}

/** 陈旧 runnable 一律不碰字段：只允许清自己那一代，且必须在世代相等之后。 */
function stalePostCannotClearNewerGeneration(delayedRun) {
  const createAt = delayedRun.indexOf('createEmbeddedScene(');
  if (createAt < 0) return 'delayed create call is absent';
  const resetAt = delayedRun.indexOf('sceneGeneration = 0');
  if (resetAt < 0 || resetAt > createAt) return 'own detached generation is not retired before return';
  if (!GEN_EQ.test(delayedRun.slice(0, resetAt))) {
    return 'runnable may clear state owned by a newer generation';
  }
  const requestCheck = delayedRun.indexOf('sceneRequested');
  if (requestCheck < 0 || requestCheck > resetAt) {
    return 'runnable clears its own state without first checking the current request';
  }
  return null;
}

/** 退役不需要"先有活着的请求"才生效：否则空闲宿主永远不会被摘下父容器。 */
function hostDestroyNotSkippedWhenIdle(releaseScene) {
  if (/if\s*\(\s*!\s*sceneRequested\s*\)\s*\{?\s*return/.test(releaseScene)) {
    return 'release returns before detaching an inactive QtView';
  }
  return null;
}

/** 幂等：retireScene 以 sceneGeneration==0 为门，且先归零再发 native destroy。 */
function retireIsGenerationGated(retireScene) {
  const gate = retireScene.indexOf('generation == 0');
  const native = retireScene.indexOf('destroyEmbeddedScene(');
  if (gate < 0) return 'retireScene has no zero-generation gate';
  if (native < 0) return 'retireScene never issues the native destroy';
  if (gate > native) return 'retireScene issues the native destroy before the gate';
  const clear = retireScene.indexOf('sceneGeneration = 0');
  if (clear < 0 || clear > native) return 'retireScene does not clear its generation before the native call';
  return null;
}

// ---------------------------------------------------------------------------
// prepatch 负对照：修复前真实代码形状。谓词在这些片段上必须**失败**。
// ---------------------------------------------------------------------------

const PREPATCH = {
  releaseViews: `
    View first = views.isEmpty() ? null : views.get(0);
    for (View view : views) {
        if (view instanceof RhineQtView) {
            ((RhineQtView) view).releaseSceneForHostDestroy();
        }
        if (view instanceof QtNative.AppStateDetailsListener) {
            QtNative.unregisterAppStateListener((QtNative.AppStateDetailsListener) view);
        }
    }
    return first;`,
  releaseScene: `
    if (!sceneRequested) {
        return;
    }
    sceneRequested = false;
    retireScene();`,
  delayedRun: `
    if (!isAttachedToWindow()) {
        sceneRequested = false;
        return;
    }
    createEmbeddedScene(parentWindowRef, getWidth(), getHeight(), generation);`,
  retireScene: `
    final long generation = sceneGeneration;
    if (generation == 0) {
        return;
    }
    sceneGeneration = 0;
    destroyEmbeddedScene(generation);`,
};

// ---------------------------------------------------------------------------
// 真实源码解析
// ---------------------------------------------------------------------------

const viewsSource = stripComments(source(VIEWS));
const releaseViews = bodyAfter(viewsSource, 'private static View releaseSceneViews(Activity activity)');

const viewSource = stripComments(source(VIEW));
const releaseScene = bodyAfter(viewSource, 'public void releaseSceneForHostDestroy()');
// 定位方法定义本身（`private void createWindowOnMainThread`），不是它在别的 createWindow
// 重载里的调用点——调用点后面没有 `{`，旧写法会以 "missing body" 崩在模块加载期。
const mainThreadCreate = bodyAfter(viewSource, 'private void createWindowOnMainThread');
const delayedRun = bodyAfter(mainThreadCreate, 'post(() ->');
const retireScene = bodyAfter(viewSource, 'private void retireScene()');

const detach = bodyAfter(stripComments(source(QTV)), 'protected void onDetachedFromWindow()');

// ---------------------------------------------------------------------------
// 跑
// ---------------------------------------------------------------------------

const failures = [];
function check(name, fn) {
  try {
    const problem = fn();
    if (problem) throw new Error(problem);
    process.stdout.write(`PASS ${name}\n`);
  } catch (error) {
    failures.push({ name, message: error.message });
    process.stdout.write(`FAIL ${name}: ${error.message}\n`);
  }
}

// 合同（对真实源码）
check('host teardown retires scene before detaching the old view', () => retireBeforeParentRemoval(releaseViews));
check('host teardown rechecks destroyed Activity identity before removal', () => removalGuardedByOldActivityIdentity(releaseViews));
check('host teardown only removes through a live ViewGroup parent (idempotent)', () => removalGuardedByLiveParent(releaseViews));
check('host teardown unregisters the app-state listener before removal', () => listenerUnregisteredBeforeRemoval(releaseViews));
check('normal QtView detach releases the native parent window', () => normalDetachReleasesNativeParentWindow(detach));
check('stale size-post cannot create a retired generation', () => stalePostGuardsBeforeCreate(delayedRun));
check('stale runnable cannot clear a newer host generation', () => stalePostCannotClearNewerGeneration(delayedRun));
check('host destroy remains callable when no scene request is active', () => hostDestroyNotSkippedWhenIdle(releaseScene));
check('scene retirement is generation-gated before the native destroy (idempotent)', () => retireIsGenerationGated(retireScene));

// 负对照：同一批谓词在 prepatch 片段上必须判失败（证明断言不是空的）。
const controls = [
  ['prepatch: no parent removal', () => retireBeforeParentRemoval(PREPATCH.releaseViews)],
  ['prepatch: no old-Activity guard', () => removalGuardedByOldActivityIdentity(PREPATCH.releaseViews)],
  ['prepatch: release skipped when idle', () => hostDestroyNotSkippedWhenIdle(PREPATCH.releaseScene)],
  ['prepatch: stale post ignores generation', () => stalePostGuardsBeforeCreate(PREPATCH.delayedRun)],
  ['prepatch: stale post clears state unchecked', () => stalePostCannotClearNewerGeneration(PREPATCH.delayedRun)],
];
for (const [name, fn] of controls) {
  check(name, () => (fn() === null ? 'negative control passed — assertion is vacuous' : null));
}

// 退役路径的幂等门在真实源码里也必须成立（与 prepatch 同形，作为"没被顺手改坏"的锚）。
check('retireScene keeps its zero-generation gate', () => retireIsGenerationGated(PREPATCH.retireScene) === null
  ? null
  : 'prepatch retireScene shape is not the expected idempotent gate');

if (failures.length > 0) {
  process.stderr.write(`\n${failures.length} lifecycle contract(s) failed.\n`);
  process.exitCode = 1;
} else {
  process.stdout.write('\nAll Qt host lifecycle contracts passed.\n');
}
