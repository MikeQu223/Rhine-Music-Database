// integration_test/slice_dart_hud_test.dart
//
// T13 候选 C：Dart HUD + 3D 移植切片。atom T13-S03
// （plan T13 第 3 项「跑同一切片，记录字形/命中/时延差异」）。
//
// ── RED / GREEN 均未执行（NEVER EXECUTED）──────────────────────────────
// 阻塞 BLK-PUBSPEC-INTEGRATION：本树 pubspec.yaml 的 dev_dependencies 只有
//   flutter_test: sdk: flutter
//   flutter_lints: ^6.0.0
// 缺少 integration_test: sdk: flutter，且本树原本没有 integration_test/ 目录；
// 因此本文件在本树无法编译、无法执行。父 T13-C18 明令禁止改 pubspec.yaml，
// 本 atom 也不许新建 test/ 下文件（那是别的 atom 的写域）。
// → 下面每一组断言都只是「按 Qt 源码应当成立」的规格，不是已测量的结论；
//   RED 未执行、GREEN 未执行，本文件不声称任何一次通过。
//
// 禁令（本树，逐字遵守）：禁止执行 flutter build/test/analyze/run、dart
// test/analyze、Gradle/gradlew、pubget、formatter/代码生成/验证脚本、Qt 编译
// 运行、adb、APK/安装卸载/清数据/截图/性能/协议发布验证。
// → 一切时延、帧率、像素、字形栅格数字均为「未执行」，文件末尾 kSliceDiffs
//   只登记规格差异与验证入口，绝不填任何伪造的测量值。
//
// 对拍对象（Qt 侧，逐行亲核的源码行号；均为本文件断言的唯一依据）：
//   Qt/src/Glyphs.cpp:35-49      calibrated 第 5 项 → pow(v,1.8) → sRGB
//   Qt/src/Glyphs.cpp:65-90      四 weight + symbols 字体表 + misans-glyphs.json
//                                （glyph 用 "advance"）与 boot-lettering-art.json
//                                （letter 用 "width"）
//   Qt/src/Glyphs.cpp:266-311    glyph(): advance = advances/1000
//   Qt/src/Glyphs.cpp:286-311    width(): 逐 QChar，末尾 result - tracking
//   Qt/src/Glyphs.cpp:312-338    bounds(): translate(x, size*1.044) + scale(s,-s)
//   Qt/src/Glyphs.cpp:403-412    artWidth(): 逐 letter，末尾 result - tracking
//   Qt/src/Glyphs.cpp:530-563    text():  translate(x, y + size*1.044); scale(s, -s)
//   Qt/src/Glyphs.cpp:565-588    art():   translate(x, y);              scale(s, +s)
//   Qt/src/Glyphs.cpp:592-859    17 个 HUD op：save/restore/alpha/translate/scale/
//                                rotate/clip/fill/ellipse/text/art/fill-path/path/
//                                arc/right-mask/gradient/image
//   Qt/src/NativeHud.cpp:102-109 hit(): x,y,width,height,action,label（此顺序，六字段）
//   Qt/src/NativeHud.cpp:121-124 control(): hit(x-10, y, width+20, 54, ...)
//   Qt/src/NativeHud.cpp:404-497 archive() 命中几何
//   Qt/src/NativeHud.cpp:500-514 archiveTabButton()
//   Qt/src/NativeHudSearch.cpp:88-177 检索页 + HudScroll::clipHits
//   Qt/src/HudScroll.h:67-86     clipHits(): 只裁 index >= first，矩形与视口求交
//   Qt/src/SongDetailCard.cpp    详情卡片：primary@476 / secondary@532 / tabs@720
//   Qt/src/NativeHudDetail.cpp:118-215 详情页命中顺序
//   Qt/src/PlayerBar.cpp:46-53   hit(): 六字段 + fixed:true（全仓唯一 fixed 来源）
//   Qt/src/PlayerBar.cpp:55-253  PlayerBar::render 命中几何
//   Qt/src/PlaybackQueueCard.cpp 播放队列卡片命中几何
//   Qt/src/NativeScene.cpp:49-52  view=Matrix::camera(eye,aim).inverse()
//                                 projection=perspective(fov=6.15, w/h, 5, 300)
//                                 aoProjection=perspective(34, w/h, 5, 300)
//   Qt/src/NativeScene.cpp:76-78  cellPosition(cell) = {(lane-2)*5.2, -4.6, (row-15.5)*0.62}
//   Qt/src/NativeScene.h:123-132  eye/aim/fov/1920x1080/fogNear=22/fogFar=47
//   Qt/src/NativeSceneFrame.cpp:87-119,116  frame 键表；detail = smooth((m_detail-0.25)/0.55)
//   Qt/src/SceneMotion.cpp:42-49  smooth()=6v^5-15v^4+10v^3；ease()=v^2*(3-2v)
//
// 3D 侧（ARCH_BLOCKED）：真实 GLB 解码 + GLES/FlutterTexture 上传需要 android/
//   的 Kotlin+C++ 与 MainActivity 接线，属其它树的写域；本树只到「可注入端口 +
//   诚实 Unavailable 后端」为止（lib/spike/dart_hud/native_scene_surface.dart）。
//   因此本文件只断言 GLB 容器/资源事实与 Qt 场景数学，不做上传/绘制断言，
//   也绝不接受「静态背景图顶替真实 3D」。
//
// 覆盖切片四件事：① 17 命令经 HudPainter 走一遍；② hits 原序六字段 + PlayerBar
//   fixed；③ 字形 JSON 载入与 advance/path；④ archive 页 + 详情 + 搜索 + 队列的
//   最小绘制与命中；⑤ 字形/命中/时延差异登记（时延只能写「未执行」）。
//
// 资源类断言（G5/G6/G7/H4/H5/H6/I3）用 dart:io 相对路径读 Assets/、Resources/、
//   pubspec.yaml —— 这依赖 host 侧 `flutter test` 的 CWD = 包根。真机上 CWD 不是
//   包根、assets 也不在文件系统里，所以这些用例先调 _requirePackageRoot()：路径
//   不可见时以明确 reason 失败，而不是给出会误导的「文件不存在」。真机要走
//   AssetBundle（rootBundle.loadString），本 atom 无执行权限，故不在此实现。

import 'dart:convert';
import 'dart:io' as io;
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
// 本 import 在本树不可解析（pubspec 无 integration_test 依赖）——这正是
// BLK-PUBSPEC-INTEGRATION，见文件头。保留它是为了让「切片必须走
// IntegrationTestWidgetsFlutterBinding」这件事在源码上成立。
import 'package:integration_test/integration_test.dart';
import 'package:rhine_music_database/spike/dart_hud/glyph_loader.dart';
import 'package:rhine_music_database/spike/dart_hud/hud_painter.dart';

// ═══════════════════════════════════════════════════════════════════════════
// 0. Qt 常量（全部有 Qt 源证据；数值即断言基准）
// ═══════════════════════════════════════════════════════════════════════════

/// NativeScene.h:129-130 的舞台尺寸。
const double kStageWidth = 1920;
const double kStageHeight = 1080;

/// PlayerBar.h：RowHeight=96；PlayerBar.cpp:56 bounds={0,984,width,96}。
const double kPlayerTop = 984;
const double kPlayerRowHeight = 96;

/// NativeHud.h:96-98 ResultListTop=328 / ResultListBottom=758；
/// NativeHudSearch.cpp ResultRowHeight=72。
const double kResultListTop = 328;
const double kResultListBottom = 758;
const double kResultRowHeight = 72;

/// NativeHudSearch.cpp SearchInset=53。
const double kSearchInset = 53;

/// NativeScene.h:128-132。
const double kQtFov = 6.15;
const double kQtFogNear = 22;
const double kQtFogFar = 47;
const double kQtNearPlane = 5;
const double kQtFarPlane = 300;
const double kQtAoFov = 34;

/// Glyphs.cpp:65-90 / 286-311 / 530-563 的字形契约。
const double kQtBaselineFactor = 1.044;
const double kQtUnitsPerEm = 1000;
const int kQtAscent = 1044;
const int kQtDescent = -282;

/// Qt/src/Glyphs.cpp:592-859 的 17 个 op，顺序即 renderCommands 的分派顺序。
const List<String> kQtRenderOps = <String>[
  'save',
  'restore',
  'alpha',
  'translate',
  'scale',
  'rotate',
  'clip',
  'fill',
  'ellipse',
  'text',
  'art',
  'fill-path',
  'path',
  'arc',
  'right-mask',
  'gradient',
  'image',
];

// ═══════════════════════════════════════════════════════════════════════════
// 1. Qt 数学直译（切片自带，用于把 Qt 数值钉进断言）
// ═══════════════════════════════════════════════════════════════════════════

/// Glyphs.cpp:35-49 的 calibrated 通道：linear = pow(v, 1.8) 再转 sRGB。
double qtCalibratedChannel(double value) {
  final double linear = math.pow(value, 1.8).toDouble();
  if (linear <= 0.0031308) {
    return 12.92 * linear;
  }
  return 1.055 * math.pow(linear, 1 / 2.4).toDouble() - 0.055;
}

/// SceneMotion.cpp:42-45 smooth(v) = clamp 后 v^3*(10 + v*(-15 + 6v))
/// 即 smootherstep 6v^5 - 15v^4 + 10v^3。
double qtSmooth(double v) {
  final double t = v.clamp(0.0, 1.0).toDouble();
  return t * t * t * (10 + t * (-15 + 6 * t));
}

/// SceneMotion.cpp:46-49 ease(v) = clamp 后 v^2*(3 - 2v)，即 smoothstep。
double qtEase(double v) {
  final double t = v.clamp(0.0, 1.0).toDouble();
  return t * t * (3 - 2 * t);
}

/// NativeScene.cpp:76-78 cellPosition(cell)。
List<double> qtCellPosition(int lane, double row) {
  return <double>[(lane - 2) * 5.2, -4.6, (row - 15.5) * 0.62];
}

/// NativeSceneFrame.cpp:116 detail = SceneMotion::smooth((m_detail - 0.25) / 0.55)。
double qtDetailBlend(double detail) => qtSmooth((detail - 0.25) / 0.55);

/// HudScroll.h:67-86 clipHits()：只处理 index >= first，矩形与 area 求交，
/// 交集为空则删除，否则把 x/y/width/height 覆写成交集值；index < first 原样保留。
List<Map<String, Object?>> qtClipHits(List<Map<String, Object?>> hits, int first, ui.Rect area) {
  final List<Map<String, Object?>> clipped = <Map<String, Object?>>[];
  for (int index = 0; index < hits.length; index += 1) {
    final Map<String, Object?> hit = hits[index];
    if (index < first) {
      clipped.add(hit);
      continue;
    }
    final ui.Rect rect = ui.Rect.fromLTWH(
      (hit['x'] as num).toDouble(),
      (hit['y'] as num).toDouble(),
      (hit['width'] as num).toDouble(),
      (hit['height'] as num).toDouble(),
    );
    final ui.Rect intersection = rect.intersect(area);
    if (intersection.isEmpty) {
      continue;
    }
    clipped.add(<String, Object?>{
      'x': intersection.left,
      'y': intersection.top,
      'width': intersection.width,
      'height': intersection.height,
      'action': hit['action'],
      'label': hit['label'],
      if (hit.containsKey('fixed')) 'fixed': hit['fixed'],
    });
  }
  return clipped;
}

/// NativeHudSearch.cpp:150-161 的可见窗口：
/// first = max(0, floor(scroll/72) - 1)，last = min(n-1, ceil((scroll+430)/72) + 1)。
int qtVisibleFirst(double scroll) {
  final int first = (scroll / kResultRowHeight).floor() - 1;
  return first < 0 ? 0 : first;
}

int qtVisibleLast(double scroll, int count) {
  final int last = ((scroll + (kResultListBottom - kResultListTop)) / kResultRowHeight).ceil() + 1;
  return last > count - 1 ? count - 1 : last;
}

/// PlaybackQueueCard.cpp maximumOffset(n) = max(0, n - 1)。
int qtMaximumOffset(int trackCount) => math.max(0, trackCount - 1);

/// 资源类断言的前置：本文件用 dart:io 相对路径读包内文件，只有 host 侧
/// `flutter test`（CWD = 包根）成立；真机 CWD 不是包根、assets 也不在文件系统里。
/// 先以明确 reason 失败，避免给出误导性的「文件不存在」。
void _requirePackageRoot(String what) {
  expect(
    io.File('pubspec.yaml').existsSync(),
    isTrue,
    reason: what +
        '：本断言用 dart:io 相对路径读包内文件，只适用于 host `flutter test`'
        '（CWD = 包根）；真机须改走 AssetBundle，见文件头。',
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. 合成字形/字形图（切片自足，不依赖真机与真实资源解码）
// ═══════════════════════════════════════════════════════════════════════════

const List<Object?> kInkLight = <Object?>[0.08, 0.085, 0.075, 1, 'calibratedRGB'];
const List<Object?> kInkDark = <Object?>[0.92, 0.92, 0.92, 1, 'calibratedWhite'];

// PlayerBar.cpp 颜色表（render() 内联常量）。
const List<Object?> kPlayerPaper = <Object?>[0.933, 0.937, 0.894, 1];
const List<Object?> kPlayerInk = <Object?>[0.141, 0.161, 0.145, 1];
const List<Object?> kPlayerMuted = <Object?>[0.4, 0.439, 0.392, 1];
const List<Object?> kPlayerLine = <Object?>[0.8, 0.816, 0.761, 1];
const List<Object?> kPlayerAmber = <Object?>[0.863, 0.651, 0.227, 1];

// PlaybackQueueCard.cpp amber{0.83,0.64,0.27,1}。
const List<Object?> kQueueAmber = <Object?>[0.83, 0.64, 0.27, 1];

// NativeHudSearch.cpp accent()。
const List<Object?> kSearchAccent = <Object?>[0.835, 0.639, 0.282, 1];

Map<String, dynamic> _glyphEntry(double advance, String path) {
  return <String, dynamic>{'advance': advance, 'path': path};
}

/// 合成 misans-glyphs.json 结构：四 weight 同表，units/ascent/descent 取 Qt 真值。
Map<String, dynamic> syntheticGlyphs() {
  final Map<String, dynamic> table = <String, dynamic>{
    'A': _glyphEntry(0.666, 'M653 0 378 740H288L13 0H105L199 257H467L561 0ZM330 614H336L437 339H229Z'),
    'B': _glyphEntry(0.62, 'M120 0H420V740H120ZM200 80V660H340V80Z'),
    'M': _glyphEntry(0.9, 'M80 0H180L260 420L340 0H440L380 740H300L260 300L220 740H140Z'),
    '0': _glyphEntry(0.5, 'M250 0H750V740H250ZM330 80V660H670V80Z'),
    '1': _glyphEntry(0.5, 'M400 0H520V740H400ZM280 600H640V720H280Z'),
    '/': _glyphEntry(0.4, 'M300 0H420L180 740H60Z'),
    '音': _glyphEntry(1, 'M120 0H880V120H120ZM220 200H780V320H220Z'),
    '乐': _glyphEntry(1, 'M300 0H420V740H300ZM520 200H900V320H520Z'),
    '槽': _glyphEntry(1, 'M100 0H900V740H100ZM180 80V660H820V80Z'),
    '位': _glyphEntry(1, 'M200 0H320V740H200ZM420 180H820V300H420Z'),
    ' ': _glyphEntry(0.25, ''),
  };
  final Map<String, dynamic> out = <String, dynamic>{};
  for (final String weight in GlyphAtlas.weights) {
    out[weight] = <String, dynamic>{
      'units': 1000,
      'ascent': 1044,
      'descent': -282,
      'glyphs': table,
    };
  }
  return out;
}

/// 合成 boot-lettering-art.json 结构：letter 用 "width"（不是 "advance"）。
Map<String, dynamic> syntheticLettering() {
  return <String, dynamic>{
    'access': <String, dynamic>{
      'text': 'AC',
      'letters': <dynamic>[
        <String, dynamic>{
          'width': 0.732,
          'path': 'M543 614 621 800H708L410 100H321L23 800H110L188 614Z',
        },
        <String, dynamic>{'width': 0.5, 'path': 'M100 0H400V740H100Z'},
      ],
    },
    'brand': <String, dynamic>{
      'text': 'R',
      'letters': <dynamic>[
        <String, dynamic>{'width': 0.6, 'path': 'M100 0H500V740H100Z'},
      ],
    },
  };
}

GlyphAtlas syntheticAtlas() {
  return GlyphAtlas.fromMaps(glyphs: syntheticGlyphs(), lettering: syntheticLettering());
}

ui.Canvas recordingCanvas() => ui.Canvas(ui.PictureRecorder());

Future<ui.Image> onePixelImage() async {
  final ui.ImmutableBuffer buffer = await ui.ImmutableBuffer.fromUint8List(
    Uint8List.fromList(<int>[255, 0, 0, 255]),
  );
  final ui.ImageDescriptor descriptor = ui.ImageDescriptor.raw(
    buffer,
    width: 1,
    height: 1,
    pixelFormat: ui.PixelFormat.rgba8888,
  );
  final ui.Codec codec = await descriptor.instantiateCodec();
  final ui.FrameInfo frame = await codec.getNextFrame();
  return frame.image;
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. flatarray 命令构造（下标语义与 Qt renderCommands 完全一致）
// ═══════════════════════════════════════════════════════════════════════════

List<Object?> opSave() => <Object?>['save'];

List<Object?> opRestore() => <Object?>['restore'];

List<Object?> opAlpha(double value) => <Object?>['alpha', value];

List<Object?> opTranslate(double x, double y) => <Object?>['translate', x, y];

List<Object?> opScale(double x, double y) => <Object?>['scale', x, y];

List<Object?> opRotate(double radians) => <Object?>['rotate', radians];

List<Object?> opClip(double x, double y, double width, double height) {
  return <Object?>['clip', x, y, width, height];
}

List<Object?> opFill(List<Object?> color, double x, double y, double width, double height) {
  return <Object?>['fill', color, x, y, width, height];
}

List<Object?> opEllipse(List<Object?> color, double x, double y, double width, double height) {
  return <Object?>['ellipse', color, x, y, width, height];
}

List<Object?> opText(
  String text,
  double x,
  double y,
  double size, [
  String weight = 'regular',
  double tracking = 0,
  List<Object?>? color,
]) {
  return <Object?>['text', text, x, y, size, weight, tracking, color ?? kInkLight];
}

List<Object?> opArt(
  String key,
  double x,
  double y,
  double size, [
  int count = -1,
  double tracking = 0,
  List<Object?>? color,
]) {
  return <Object?>['art', key, x, y, size, count, tracking, color ?? kInkLight];
}

List<Object?> opFillPath(String svg, List<Object?> color) {
  return <Object?>['fill-path', svg, color];
}

List<Object?> opPath(
  String svg,
  double penWidth,
  List<Object?> color, [
  List<Object?>? dash,
  double dashOffset = 0,
]) {
  return <Object?>['path', svg, penWidth, color, dash ?? const <Object?>[], dashOffset];
}

List<Object?> opArc(
  double x,
  double y,
  double radius,
  double start,
  double sweep,
  double penWidth,
  List<Object?> color,
) {
  return <Object?>['arc', x, y, radius, start, sweep, penWidth, color];
}

List<Object?> opRightMask(
  List<Object?> color,
  double start,
  double span,
  double right,
  double height,
) {
  return <Object?>['right-mask', color, start, span, right, height];
}

List<Object?> opGradient(bool dark) => <Object?>['gradient', dark];

List<Object?> opImage(String key, double x, double y, double width, double height) {
  return <Object?>['image', key, x, y, width, height];
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. 切片容器：commands 与 hits 同代生成（NativeHud.cpp:224-311 的顺序语义）
// ═══════════════════════════════════════════════════════════════════════════

class HudSlice {
  HudSlice(this.name);

  final String name;
  final List<Object?> commands = <Object?>[];
  final List<Map<String, Object?>> hits = <Map<String, Object?>>[];

  void add(List<Object?> command) {
    commands.add(command);
  }

  /// NativeHud.cpp:102-109：恰好六字段，此顺序；label 缺省回落 action。
  Map<String, Object?> hit(
    double x,
    double y,
    double width,
    double height,
    String action,
    String label,
  ) {
    final Map<String, Object?> entry = <String, Object?>{
      'x': x,
      'y': y,
      'width': width,
      'height': height,
      'action': action,
      'label': label,
    };
    hits.add(entry);
    return entry;
  }

  /// PlayerBar.cpp:46-53：六字段 + fixed:true（全仓唯一 fixed 来源）。
  Map<String, Object?> playerHit(
    double x,
    double y,
    double width,
    double height,
    String action,
    String label,
  ) {
    final Map<String, Object?> entry = hit(x, y, width, height, action, label);
    entry['fixed'] = true;
    return entry;
  }

  /// NativeHud.cpp:110-120 button()：先 hit 再（modalControls 时）fill + text。
  Map<String, Object?> button(
    String label,
    double x,
    double y,
    double width,
    double height,
    String action,
    double size, [
    String weight = 'demibold',
  ]) {
    final Map<String, Object?> entry = hit(x, y, width, height, action, label);
    add(opText(label, x + 12, y + 12, size, weight, 0, kInkLight));
    return entry;
  }

  /// NativeHud.cpp:121-124 control()：命中区比可视区左右各宽 10、高 54。
  Map<String, Object?> control(String label, double x, double y, double width, String action) {
    final Map<String, Object?> entry = hit(x - 10, y, width + 20, 54, action, label);
    add(opText(label, x, y + 14, 20, 'demibold', 0, kInkLight));
    return entry;
  }

  /// NativeHud.cpp:125-129 rule()。
  void rule(double x, double y, double width, double opacity) {
    add(opFill(<Object?>[kInkLight[0], kInkLight[1], kInkLight[2], opacity], x, y, width, 1));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. 四个切片：archive 页 / 详情页 / 检索页 / 播放队列
// ═══════════════════════════════════════════════════════════════════════════

/// PlayerBar::render（PlayerBar.cpp:55-253）的命中段，顺序与 Qt 完全一致。
/// width = 1920 时：center=960、centerY=1032、favoriteX=441.6、songWidth=379.6。
void appendPlayerBar(HudSlice slice, {double width = kStageWidth}) {
  const double y = kPlayerTop;
  final double center = width / 2;
  const double centerY = y + kPlayerRowHeight / 2;
  final double favoriteX = width * 0.23;
  final double songWidth = favoriteX - 62;
  final double outputX = width - 300;

  // fill(bounds, paper)
  slice.add(opFill(kPlayerPaper, 0, y, width, kPlayerRowHeight));

  // song()：cover 6 条 ellipse 占位 + 三行 label + hasTrack 的 player:lyrics
  slice.add(opEllipse(kPlayerMuted, 28, y + 21, 54, 54));
  slice.add(opText('SLICE TRACK', 28 + 74, y + 32, 23, 'demibold', 0, kPlayerInk));
  slice.playerHit(28, y + 14, songWidth, 74, 'player:lyrics', '当前歌曲歌词');

  // favorite()
  slice.add(opPath('M0 -12 C -18 -30 -40 -8 0 20 C 40 -8 18 -30 0 -12Z', 1.5, kPlayerInk));
  slice.playerHit(favoriteX - 24, centerY - 24, 48, 48, 'music:like-current', '喜欢当前歌曲');

  // controls()
  slice.playerHit(center - 89, centerY - 24, 44, 48, 'player:prev', '上一首');
  slice.playerHit(center - 23, centerY - 23, 46, 46, 'player:toggle', '暂停');
  slice.playerHit(center + 45, centerY - 24, 44, 48, 'player:next', '下一首');

  // lyrics()
  slice.playerHit(width - 470 - 24, centerY - 24, 48, 48, 'player:lyrics', '当前歌曲歌词');

  // playbackMode()
  slice.playerHit(width - 380 - 24, centerY - 24, 48, 48, 'player:mode', '顺序播放，点击切换播放模式');

  // timeline()：seekable && durationMs > 0
  slice.playerHit(0, y - 6, width, 18, 'player:seek-fraction:0', '播放进度');

  // output()：applicationVolume 分支 + 队列入口
  slice.playerHit(outputX + 58, y + 47, 100, 28, 'player:volume-fraction:0', '音量');
  slice.playerHit(width - 65 - 14, y + 16, 54, 65, 'player:open', '播放队列');
}

/// archive 页（NativeHud.cpp:404-514）：directory 为空、selectedLane==1、
/// trackListMode==false 的最小态。命中 30 条 = nav 4 + 页内 16 + PlayerBar 10。
HudSlice buildArchiveSlice({double width = kStageWidth}) {
  final HudSlice slice = HudSlice('archive');
  final double x = width - 789; // navigationLeft(width)
  final double nav = width * 0.2625;
  final double col = width * 0.5234375;

  // brand() / navigation() / footer()
  // navigation() 内部 x = navigationLeft + 210，四个 control 分别落在
  // x-210 / x / x+200 / x+400，即 navigationLeft + 0 / 210 / 410 / 610。
  final double navBase = x + 210;
  slice.add(opText('RHINE LAB / MUSIC DATABASE', 59, 173, 14, 'demibold', 1, kInkLight));
  slice.control('发现音乐 ↗', navBase - 210, 118, 184, 'discover');
  slice.control('音乐检索  /', navBase, 118, 184, 'search');
  slice.control('＋ 我的音乐', navBase + 200, 118, 184, 'saved');
  slice.control('设置', navBase + 400, 118, 120, 'settings');
  slice.add(opFill(<Object?>[119 / 255, 123 / 255, 96 / 255, 1], 59, 971, 5, 5));

  // archive()：非 directory 且 selectedLane == 1 → 播放全部
  slice.control('播放全部 →', 59, 211, 310, 'music:play-loaded');
  slice.add(opText('MUSIC DATABASE / 我的音乐', x, 471, 12, 'regular', 0, kInkLight));
  slice.add(opText('音乐槽位', x, 509, 28, 'bold', 0, kInkLight));
  // 标题命中：414x37，不是整行（Qt: hit(x, 509, 414, 37, "open", title)）
  slice.hit(x, 509, 414, 37, 'open', '音乐槽位');
  slice.rule(x, 601, width - x - 59, 0.2);
  slice.add(opFill(<Object?>[0.47, 0.48, 0.38, 1], x - 12, 598, 6, 6));
  slice.add(opText('SLOT-3-1 / 音乐槽位', x, 624, 16, 'regular', 0, kInkLight));
  slice.add(opText('SONG', width - 170, 627, 11, 'regular', 0, kInkLight));
  slice.control('查看歌曲详情 →', x, 703, 300, 'open');
  slice.add(opText('点击打开 · ENTER 键也可打开', x, 771, 14, 'regular', 0, kInkLight));

  // 左列计数
  slice.add(opText('TRACK / SELECT', 60, 865, 11, 'regular', 0, kInkLight));
  slice.add(opText('03', 60, 901.2, 58, 'regular', 0, kInkLight));
  slice.add(opText('/', 141, 925, 32, 'light', 0, kInkLight));
  slice.add(opText('40', 172, 932, 22, 'regular', 0, kInkLight));

  // 选曲列：↑ / 8 槽 / ↓
  slice.button('↑', nav, 903, 46, 46, 'prev', 28);
  for (int index = 0; index < 8; index += 1) {
    final double slotX = nav + 85 + index * 26;
    final bool current = index == 2;
    slice.add(opFill(<Object?>[0.47, 0.48, 0.38, 1], slotX, current ? 909 : 920, 2, current ? 33 : 12));
    slice.hit(slotX - 6, 900, 26, 50, 'music:slot:' + index.toString(), '选曲 ' + (index + 1).toString());
  }
  slice.button('↓', nav + 320, 903, 46, 46, 'next', 28);

  // 曲目列：← / 来源标签 / →
  slice.button('←', col, 903, 46, 46, 'column-prev', 28);
  slice.add(opText('COLLECTION 02 / 05', col + 70, 904, 10, 'regular', 0, kInkLight));
  slice.add(opText('我的音乐', col + 70, 925, 15, 'regular', 0, kInkLight));
  slice.button('→', col + 310, 903, 46, 46, 'column-next', 28);

  // archiveTabButton(width)
  final double tabX = width - 340;
  slice.hit(tabX - 8, 854, 186, 48, 'archive:tab-mode', 'Tab Mode，按 Tab 切换');
  slice.add(opText('Tab Mode', tabX, 866, 18, 'regular', 0, kInkLight));
  slice.add(opPath('M0 0H34V34H0Z', 1.5, kInkLight));
  slice.add(opText('← → 切换来源 / ↑ ↓ 选曲 / ENTER 查看 / 检索', nav, 850, 12, 'regular', 0, kInkLight));

  appendPlayerBar(slice, width: width);
  return slice;
}

/// 详情页（NativeHudDetail.cpp:118-215 + SongDetailCard.cpp）：
/// 命中 25 条 = 页内 15 + PlayerBar 10。
HudSlice buildDetailSlice({double width = kStageWidth}) {
  final HudSlice slice = HudSlice('detail');
  final double x = width * 0.56;
  final double usable = width - x - 59;
  const double gap = 12;
  final double buttonWidth = (usable - 24) / 3;

  // 详情面板底色 + 左栏固定动作
  slice.add(opFill(<Object?>[0.973, 0.969, 0.933, 0.96], x - 24, 260, usable + 48, 696));
  slice.button('← 返回资料库   ESC', 59, 211, 360, 54, 'back', 20);
  slice.button('查看封面 ↗', 60, 944, 260, 35, 'viewer', 14);

  // SongDetailCard::paint 主体
  slice.add(opFill(<Object?>[0.47, 0.48, 0.38, 1], x - 24, 260, usable + 48, 3));
  slice.add(opText('TRACK RECORD / 歌曲档案', x + 36, 282, 11, 'regular', 0, kInkLight));
  slice.add(opText('AUDIO ARCHIVE / 音频档案', x, 332, 15, 'regular', 0, kInkLight));
  slice.add(opText('音乐槽位', x, 366, 32, 'bold', 0, kInkLight));

  // actions(primaryActions, 476, true)：三枚等宽，gap=12
  const List<List<String>> primary = <List<String>>[
    <String>['▶ 播放歌曲', 'music:play'],
    <String>['♡ 喜欢', 'music:like'],
    <String>['＋ 加入歌单', 'music:add-to-playlist'],
  ];
  for (int index = 0; index < primary.length; index += 1) {
    final double actionX = x + index * (buttonWidth + gap);
    slice.add(opFill(kSearchAccent, actionX, 476, buttonWidth, 44));
    slice.hit(actionX, 476, buttonWidth, 44, primary[index][1], primary[index][0]);
    slice.add(opText(primary[index][0], actionX + 12, 488, 14, 'demibold', 0, kInkLight));
  }

  // actions(secondaryActions, 532, false)
  const List<List<String>> secondary = <List<String>>[
    <String>['＋ 加入队列', 'music:enqueue'],
    <String>['▷ 下一首播放', 'music:play-next'],
    <String>['↗ 歌手作品', 'music:artist:0'],
  ];
  for (int index = 0; index < secondary.length; index += 1) {
    final double actionX = x + index * (buttonWidth + gap);
    slice.add(opPath('M0 0H10V10H0Z', 1, kInkLight));
    slice.hit(actionX, 532, buttonWidth, 44, secondary[index][1], secondary[index][0]);
    slice.add(opText(secondary[index][0], actionX + 12, 544, 14, 'regular', 0, kInkLight));
  }

  // 四字段：index == 1 是音质，带 quality:open 命中（y+18, 高 34）
  final double column = (usable - 12) / 2;
  slice.add(opText('ALBUM / 专辑', x, 631, 15, 'regular', 0, kInkLight));
  slice.add(opText('LOSSLESS / 无损', x + column + 12, 631, 15, 'regular', 0, kInkLight));
  slice.hit(x + column + 12, 627, column, 34, 'quality:open', '音质说明与切换');

  // tabs：tabsY = 720（非 albumTracks），w = width/3 - 12
  const List<List<String>> tabs = <List<String>>[
    <String>['歌曲百科', 'overview'],
    <String>['专辑信息', 'notes'],
    <String>['同专辑曲目', 'history'],
  ];
  for (int index = 0; index < tabs.length; index += 1) {
    final double tabX = x + index * usable / 3;
    final double tabWidth = usable / 3 - 12;
    slice.add(opText(tabs[index][0], tabX, 730, 14, 'regular', 0, kInkLight));
    slice.hit(tabX, 720, tabWidth, 38, 'tab:' + tabs[index][1], tabs[index][0]);
  }

  // 正文三行 + 复制命中（786, 高 min(3,lines)*31 = 93）
  slice.add(opText('点击复制完整内容', x, 790, 16, 'regular', 0, kInkLight));
  slice.hit(x, 786, usable, 93, 'detail:copy', '点击复制完整内容');

  // 底部三枚平台动作
  slice.rule(x, 898, usable, 0.18);
  slice.button('官方客户端 ↗', x, 910, buttonWidth, 44, 'music:official', 13);
  slice.button('试听片段', x + buttonWidth + gap, 910, buttonWidth, 44, 'music:preview', 13);

  appendPlayerBar(slice, width: width);
  return slice;
}

/// 检索页（NativeHudSearch.cpp:131-173）：8 行结果，行高 72，首行 y = 122+328。
HudSlice buildSearchSlice({double width = kStageWidth, double scroll = 0}) {
  final HudSlice slice = HudSlice('search');
  final double modalWidth = math.min<double>(
    width - 100,
    math.max<double>(760.0, math.min<double>(1000.0, width * 0.5 - 59)),
  );
  final double modalLeft = width - modalWidth - 59;
  final double left = modalLeft + kSearchInset;
  final double usable = modalWidth - 2 * kSearchInset;
  final double top = 122 + kResultListTop;
  const List<String> titles = <String>[
    '音乐槽位',
    '塞壬唱片',
    '我的歌单',
    '收藏专辑',
    '搜索结果',
    '喜欢的歌曲',
    '本地曲库',
    '播放队列',
  ];

  slice.add(opFill(<Object?>[0.973, 0.969, 0.933, 0.96], modalLeft, 122, modalWidth, 836));
  slice.add(opText('音乐检索', left, 172, 22, 'demibold', 0, kInkLight));

  for (int index = 0; index < titles.length; index += 1) {
    final double rowY = top + index * kResultRowHeight - scroll;
    slice.add(opText(titles[index], left, rowY + 22, 16, 'regular', 0, kInkLight));
    slice.hit(left, rowY, usable, kResultRowHeight, 'music:result:0:' + index.toString(), titles[index]);
  }

  // rail：track = (x + width - 24, viewport.top + 8, 3, 430 - 16)
  final double railX = modalLeft + modalWidth - 24;
  slice.add(opPath('M' + railX.toStringAsFixed(1) + ' 458 V872', 3, kInkLight));
  return slice;
}

/// 播放队列（PlaybackQueueCard.cpp）：bounds = modalBounds 默认分支 {330,122,1260,836}。
HudSlice buildQueueSlice({int trackCount = 3, int currentIndex = 0}) {
  final HudSlice slice = HudSlice('queue');
  const double boundsX = 330;
  const double boundsY = 122;
  const double boundsWidth = 1260;
  final double x = boundsX + 53;
  final double y = boundsY;
  final double width = boundsWidth - 106;
  final double modeWidth = (width - 24) / 4;

  slice.add(opText('RHINE LAB / MUSIC DATABASE / AUDIO TERMINAL', x, y + 37, 11, 'regular', 0, kInkLight));
  slice.hit(x + width - 167, y + 18, 167, 54, 'close-modal', '← 返回');
  slice.add(opText('Now Playing', x, y + 91, 38, 'demibold', 0, kInkLight));
  slice.add(opText('播放队列 / SESSION TRACKS', x, y + 147, 13, 'regular', 0, kInkLight));
  slice.add(opText('播放队列  ' + trackCount.toString(), x, y + 194, 20, 'demibold', 0, kInkLight));

  if (trackCount > 0) {
    slice.hit(x + width - 130, y + 185, 130, 40, 'player:clear', '清空队列');
  }
  slice.add(opFill(kPlayerInk, x, y + 233, width, 2));
  slice.add(opText('PLAYBACK MODE / 播放模式', x, y + 247, 10, 'regular', 0, kInkLight));

  const List<List<String>> modes = <List<String>>[
    <String>['顺序播放', 'off'],
    <String>['列表循环', 'all'],
    <String>['单曲循环', 'one'],
    <String>['随机播放', 'shuffle'],
  ];
  for (int index = 0; index < modes.length; index += 1) {
    final double modeX = x + index * (modeWidth + 8);
    slice.add(opText(modes[index][0], modeX + 12, y + 281, 14, 'regular', 0, kInkLight));
    slice.hit(modeX, y + 269, modeWidth, 40, 'player:mode:' + modes[index][1], modes[index][0]);
  }

  slice.add(opFill(kPlayerLine, x, y + 322, width, 1));
  slice.add(opText('#', x + 10, y + 334, 10, 'regular', 0, kInkLight));
  slice.add(opText('曲目 / TRACK', x + 44, y + 334, 10, 'regular', 0, kInkLight));
  slice.add(opText('时长', x + width - 100, y + 334, 10, 'regular', 0, kInkLight));

  final int offset = 0;
  for (int index = offset; index < trackCount; index += 1) {
    final int row = index - offset;
    final double top = y + 358 + row * 56;
    final bool current = index == currentIndex;
    if (current) {
      slice.add(opFill(kPlayerLine, x, top, width, 56));
      slice.add(opFill(kQueueAmber, x, top, 3, 56));
    }
    slice.add(opText(current ? '●' : (index + 1).toString(), x + 10, top + 18, 12, 'regular', 0, kInkLight));
    slice.add(opText('曲目 ' + (index + 1).toString(), x + 44, top + 7, 17, 'regular', 0, kInkLight));
    slice.add(opText('艺人', x + 44, top + 32, 11, 'regular', 0, kInkLight));
    slice.add(opText('03:21', x + width - 100, top + 18, 12, 'regular', 0, kInkLight));
    slice.hit(
      x + 5,
      top,
      width - 50,
      55,
      'player:queue:' + index.toString(),
      '播放 曲目 ' + (index + 1).toString(),
    );
    if (!current) {
      slice.add(opText('×', x + width - 26, top + 18, 14, 'regular', 0, kInkLight));
      slice.hit(x + width - 38, top + 6, 38, 42, 'player:remove:' + index.toString(), '×');
    }
    slice.add(opFill(kPlayerLine, x, top + 46, width, 1));
  }
  return slice;
}

// ═══════════════════════════════════════════════════════════════════════════
// 6. 命中期望表（x, y, width, height 全部来自 Qt 源码的实算，width=1920）
// ═══════════════════════════════════════════════════════════════════════════

void expectHits(List<Map<String, Object?>> actual, List<List<Object>> expected) {
  expect(actual.length, expected.length, reason: '命中条数必须与 Qt 同序一致');
  for (int index = 0; index < expected.length; index += 1) {
    final List<Object> row = expected[index];
    final Map<String, Object?> hit = actual[index];
    expect(hit['action'], row[0], reason: '第 ' + index.toString() + ' 条 action 顺序不符');
    expect(hit['label'], row[1], reason: '第 ' + index.toString() + ' 条 label 不符');
    expect((hit['x'] as num).toDouble(), closeTo(row[2] as double, 1e-6), reason: '第 ' + index.toString() + ' 条 x 不符');
    expect((hit['y'] as num).toDouble(), closeTo(row[3] as double, 1e-6), reason: '第 ' + index.toString() + ' 条 y 不符');
    expect((hit['width'] as num).toDouble(), closeTo(row[4] as double, 1e-6), reason: '第 ' + index.toString() + ' 条 width 不符');
    expect((hit['height'] as num).toDouble(), closeTo(row[5] as double, 1e-6), reason: '第 ' + index.toString() + ' 条 height 不符');
    final bool wantFixed = row.length > 6 && row[6] == true;
    expect(hit.containsKey('fixed'), wantFixed, reason: '第 ' + index.toString() + ' 条 fixed 标记不符');
  }
}

/// archive 页 30 条：nav 4 + 页内 16 + PlayerBar 10（后 10 条 fixed）。
List<List<Object>> archiveExpectedHits() {
  return <List<Object>>[
    <Object>['discover', '发现音乐 ↗', 1121.0, 118.0, 204.0, 54.0],
    <Object>['search', '音乐检索  /', 1331.0, 118.0, 204.0, 54.0],
    <Object>['saved', '＋ 我的音乐', 1531.0, 118.0, 204.0, 54.0],
    <Object>['settings', '设置', 1731.0, 118.0, 140.0, 54.0],
    <Object>['music:play-loaded', '播放全部 →', 49.0, 211.0, 330.0, 54.0],
    <Object>['open', '音乐槽位', 1131.0, 509.0, 414.0, 37.0],
    <Object>['open', '查看歌曲详情 →', 1121.0, 703.0, 320.0, 54.0],
    <Object>['prev', '↑', 504.0, 903.0, 46.0, 46.0],
    <Object>['music:slot:0', '选曲 1', 583.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:1', '选曲 2', 609.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:2', '选曲 3', 635.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:3', '选曲 4', 661.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:4', '选曲 5', 687.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:5', '选曲 6', 713.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:6', '选曲 7', 739.0, 900.0, 26.0, 50.0],
    <Object>['music:slot:7', '选曲 8', 765.0, 900.0, 26.0, 50.0],
    <Object>['next', '↓', 824.0, 903.0, 46.0, 46.0],
    <Object>['column-prev', '←', 1005.0, 903.0, 46.0, 46.0],
    <Object>['column-next', '→', 1315.0, 903.0, 46.0, 46.0],
    <Object>['archive:tab-mode', 'Tab Mode，按 Tab 切换', 1572.0, 854.0, 186.0, 48.0],
    ...playerBarExpectedHits(),
  ];
}

/// PlayerBar 10 条（PlayerBar.cpp:55-253），全部 fixed:true。
List<List<Object>> playerBarExpectedHits() {
  return <List<Object>>[
    <Object>['player:lyrics', '当前歌曲歌词', 28.0, 998.0, 379.6, 74.0, true],
    <Object>['music:like-current', '喜欢当前歌曲', 417.6, 1008.0, 48.0, 48.0, true],
    <Object>['player:prev', '上一首', 871.0, 1008.0, 44.0, 48.0, true],
    <Object>['player:toggle', '暂停', 937.0, 1009.0, 46.0, 46.0, true],
    <Object>['player:next', '下一首', 1005.0, 1008.0, 44.0, 48.0, true],
    <Object>['player:lyrics', '当前歌曲歌词', 1426.0, 1008.0, 48.0, 48.0, true],
    <Object>['player:mode', '顺序播放，点击切换播放模式', 1516.0, 1008.0, 48.0, 48.0, true],
    <Object>['player:seek-fraction:0', '播放进度', 0.0, 978.0, 1920.0, 18.0, true],
    <Object>['player:volume-fraction:0', '音量', 1678.0, 1031.0, 100.0, 28.0, true],
    <Object>['player:open', '播放队列', 1841.0, 1000.0, 54.0, 65.0, true],
  ];
}

/// 详情页 25 条：页内 15 + PlayerBar 10。
List<List<Object>> detailExpectedHits() {
  const double x = 1075.2;
  const double usable = 785.8;
  const double buttonWidth = (usable - 24) / 3; // 253.93333333333334
  const double column = (usable - 12) / 2; // 386.9
  const double tabWidth = usable / 3 - 12; // 249.93333333333334
  return <List<Object>>[
    <Object>['back', '← 返回资料库   ESC', 59.0, 211.0, 360.0, 54.0],
    <Object>['viewer', '查看封面 ↗', 60.0, 944.0, 260.0, 35.0],
    <Object>['music:play', '▶ 播放歌曲', x, 476.0, buttonWidth, 44.0],
    <Object>['music:like', '♡ 喜欢', x + buttonWidth + 12, 476.0, buttonWidth, 44.0],
    <Object>['music:add-to-playlist', '＋ 加入歌单', x + (buttonWidth + 12) * 2, 476.0, buttonWidth, 44.0],
    <Object>['music:enqueue', '＋ 加入队列', x, 532.0, buttonWidth, 44.0],
    <Object>['music:play-next', '▷ 下一首播放', x + buttonWidth + 12, 532.0, buttonWidth, 44.0],
    <Object>['music:artist:0', '↗ 歌手作品', x + (buttonWidth + 12) * 2, 532.0, buttonWidth, 44.0],
    <Object>['quality:open', '音质说明与切换', x + column + 12, 627.0, column, 34.0],
    <Object>['tab:overview', '歌曲百科', x, 720.0, tabWidth, 38.0],
    <Object>['tab:notes', '专辑信息', x + usable / 3, 720.0, tabWidth, 38.0],
    <Object>['tab:history', '同专辑曲目', x + usable / 3 * 2, 720.0, tabWidth, 38.0],
    <Object>['detail:copy', '点击复制完整内容', x, 786.0, usable, 93.0],
    <Object>['music:official', '官方客户端 ↗', x, 910.0, buttonWidth, 44.0],
    <Object>['music:preview', '试听片段', x + buttonWidth + 12, 910.0, buttonWidth, 44.0],
    ...playerBarExpectedHits(),
  ];
}

/// 检索页 8 条：left=1013、usable=795、首行 450、行高 72。
List<List<Object>> searchExpectedHits() {
  const List<String> titles = <String>[
    '音乐槽位',
    '塞壬唱片',
    '我的歌单',
    '收藏专辑',
    '搜索结果',
    '喜欢的歌曲',
    '本地曲库',
    '播放队列',
  ];
  final List<List<Object>> rows = <List<Object>>[];
  for (int index = 0; index < titles.length; index += 1) {
    rows.add(<Object>[
      'music:result:0:' + index.toString(),
      titles[index],
      1013.0,
      450.0 + index * 72,
      795.0,
      72.0,
    ]);
  }
  return rows;
}

/// 队列 11 条（trackCount=3、currentIndex=0）。
List<List<Object>> queueExpectedHits() {
  const double x = 383;
  const double y = 122;
  const double width = 1154;
  const double modeWidth = (width - 24) / 4; // 282.5
  return <List<Object>>[
    <Object>['close-modal', '← 返回', x + width - 167, y + 18, 167.0, 54.0],
    <Object>['player:clear', '清空队列', x + width - 130, y + 185, 130.0, 40.0],
    <Object>['player:mode:off', '顺序播放', x, y + 269, modeWidth, 40.0],
    <Object>['player:mode:all', '列表循环', x + modeWidth + 8, y + 269, modeWidth, 40.0],
    <Object>['player:mode:one', '单曲循环', x + (modeWidth + 8) * 2, y + 269, modeWidth, 40.0],
    <Object>['player:mode:shuffle', '随机播放', x + (modeWidth + 8) * 3, y + 269, modeWidth, 40.0],
    <Object>['player:queue:0', '播放 曲目 1', x + 5, y + 358, width - 50, 55.0],
    <Object>['player:queue:1', '播放 曲目 2', x + 5, y + 414, width - 50, 55.0],
    <Object>['player:remove:1', '×', x + width - 38, y + 420, 38.0, 42.0],
    <Object>['player:queue:2', '播放 曲目 3', x + 5, y + 470, width - 50, 55.0],
    <Object>['player:remove:2', '×', x + width - 38, y + 476, 38.0, 42.0],
  ];
}

// ═══════════════════════════════════════════════════════════════════════════
// 7. 差异登记（字形 / 命中 / 时延）——时延一律 NOT_MEASURED
// ═══════════════════════════════════════════════════════════════════════════

class SliceDiff {
  const SliceDiff(this.dimension, this.qt, this.dartSlice, this.verdict, this.evidence);

  final String dimension;
  final String qt;
  final String dartSlice;
  final String verdict;
  final String evidence;
}

const List<SliceDiff> kSliceDiffs = <SliceDiff>[
  SliceDiff(
    'HUD 命令流',
    '17 op，flatarray 原序，未知 op 跳过并继续',
    'HudPainter.paintAll 17 case 同序，unknownOps 计数后继续',
    'ALIGNED（静态）',
    'Qt/src/Glyphs.cpp:592-859 ↔ lib/spike/dart_hud/hud_painter.dart',
  ),
  SliceDiff(
    '命中六字段',
    'x,y,width,height,action,label 此顺序；label 缺省回落 action',
    'HudHit 同六字段 + listFromJson 保序 + 缺字段抛 FormatException',
    'ALIGNED（静态）',
    'Qt/src/NativeHud.cpp:102-109 ↔ HudHit',
  ),
  SliceDiff(
    'PlayerBar fixed',
    '六字段 + fixed:true（全仓唯一来源）',
    'playerHit() 追加 fixed:true，hitTest 对 fixed 不平移',
    'ALIGNED（静态）',
    'Qt/src/PlayerBar.cpp:46-53 ↔ HudHit.fixed',
  ),
  SliceDiff(
    '字形 advance/path',
    'units 1000 / ascent 1044 / descent -282；advance 为 em 比例',
    'GlyphAtlas.resourceMatchesQtContract 同契约，四 weight 1007 字形',
    'ALIGNED（静态）',
    'Qt/src/Glyphs.cpp:65-90,266-311 ↔ GlyphAtlas',
  ),
  SliceDiff(
    '文本 baseline',
    'translate(x, y + size*1.044); scale(size/1000, -size/1000)',
    'drawText: canvas.translate(cursor, y + size * baselineFactor)',
    'ALIGNED（静态）',
    'Qt/src/Glyphs.cpp:530-563 ↔ lib/spike/dart_hud/glyph_loader.dart:448',
  ),
  SliceDiff(
    'art 无偏移',
    'translate(x, y) 无 1.044；scale(size/1000, +size/1000)',
    'drawArt: canvas.translate(cursor, y)（无 baselineFactor）',
    'ALIGNED（静态）',
    'Qt/src/Glyphs.cpp:565-588 ↔ lib/spike/dart_hud/glyph_loader.dart:483',
  ),
  SliceDiff(
    '颜色校准',
    'calibrated 第 5 项：pow(v,1.8) → sRGB 分段',
    'GlyphAtlas.colorFromJson 同式（qtCalibratedChannel 复算）',
    'ALIGNED（静态）',
    'Qt/src/Glyphs.cpp:35-49 ↔ GlyphAtlas.colorFromJson',
  ),
  SliceDiff(
    '命中裁剪',
    'HudScroll::clipHits 只裁 index >= first，矩形与视口求交，空则删除',
    'qtClipHits 同语义（切片自证：第 5 行裁到高 70，第 6/7 行删除）',
    'ALIGNED（静态）',
    'Qt/src/HudScroll.h:67-86 ↔ 本文件 qtClipHits',
  ),
  SliceDiff(
    '3D 场景',
    '真实 GLB + GLES/FlutterTexture + 相机/拾取，禁止静态背景',
    '可注入 NativeSceneBackend 端口 + 诚实 Unavailable 后端（ARCH_BLOCKED）',
    'BLOCKED（架构）',
    '需 android/ Kotlin+C++ 与 MainActivity 接线，属其它树写域；本树只交端口',
  ),
  SliceDiff(
    'HUD 首帧时延',
    'Qt 侧未采集（本 atom 无设备验证权限）',
    '未执行（DEVICE_BLOCKED）',
    'NOT_MEASURED',
    '本树禁 flutter build/test/run 与性能验证 → 不得填任何毫秒数',
  ),
  SliceDiff(
    '字形栅格像素',
    'Qt 侧未采集',
    '未执行（DEVICE_BLOCKED）',
    'NOT_MEASURED',
    '本树禁截图/像素比对 → 只保留 advance/path 的数值契约',
  ),
];

// ═══════════════════════════════════════════════════════════════════════════
// 8. 测试
// ═══════════════════════════════════════════════════════════════════════════

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // ── A. 17 命令直译（Glyphs.cpp:592-859）───────────────────────────────
  group('A 17 命令直译', () {
    test('A1 op 表恰好 17 个且互不重复', () {
      expect(kQtRenderOps.length, 17);
      expect(kQtRenderOps.toSet().length, 17);
    });

    test('A2 每个 op 走一遍：commands 计数、trace 顺序与 Qt 分派顺序一致', () {
      final List<String> trace = <String>[];
      final HudPainter painter = HudPainter(atlas: syntheticAtlas(), trace: trace);
      final List<Object?> commands = <Object?>[
        opSave(),
        opRestore(),
        opAlpha(1),
        opTranslate(10, 20),
        opScale(1, 1),
        opRotate(HudPainter.pi / 2),
        opClip(0, 0, kStageWidth, 984),
        opFill(kInkLight, 0, 0, 100, 100),
        opEllipse(kInkLight, 10, 10, 20, 20),
        opText('A', 20, 100, 20, 'regular', 0, kInkLight),
        opArt('access', 5, 100, 20, 1, 0, kInkLight),
        opFillPath('M0 0H10V10H0Z', kInkLight),
        opPath('M0 0L10 10', 2, kInkLight, <Object?>[4, 2], 1),
        opArc(10, 20, 5, 0.5, 1.25, 2, kInkLight),
        opRightMask(kInkLight, 800, 300, 1200, 984),
        opGradient(false),
        opImage('cover', 0, 0, 54, 54),
      ];
      final HudPaintStats stats = painter.paintAll(recordingCanvas(), commands);
      expect(stats.commands, 17);
      expect(stats.unknownOps, 0);
      expect(stats.missingImages, 1, reason: '未注入 imageResolver 时 image op 必须记为缺失');
      expect(trace, kQtRenderOps.map((String op) => op + '@1.000').toList());
    });

    test('A3 alpha 是乘法而非替换（Glyphs.cpp:658 setOpacity(opacity*n)）', () {
      final List<String> trace = <String>[];
      final HudPainter painter = HudPainter(atlas: syntheticAtlas(), trace: trace);
      painter.paintAll(recordingCanvas(), <Object?>[
        opAlpha(0.5),
        opAlpha(0.5),
        opFill(kInkLight, 0, 0, 1, 1),
      ]);
      expect(trace, <String>['alpha@1.000', 'alpha@0.500', 'fill@0.250']);
    });

    test('A4 未知 op 记 unknownOps 且后续命令继续（Glyphs.cpp default 分支）', () {
      final List<String> trace = <String>[];
      final HudPainter painter = HudPainter(atlas: syntheticAtlas(), trace: trace);
      final HudPaintStats stats = painter.paintAll(recordingCanvas(), <Object?>[
        <Object?>['hologram', 1, 2],
        opFill(kInkLight, 0, 0, 1, 1),
      ]);
      expect(stats.unknownOps, 1);
      expect(stats.commands, 2);
      expect(trace, <String>['hologram@1.000', 'fill@1.000']);
    });

    test('A5 right-mask 17 stop + smoothstep（Glyphs.cpp:775-805 MaskSteps=16）', () {
      final List<double> stops = HudPainter.rightMaskStops();
      expect(stops.length, 17);
      expect(stops.first, 0);
      expect(stops.last, 1);
      expect(stops[4], closeTo(0.25, 1e-12));
      final List<ui.Color> colors = HudPainter.rightMaskColors(const ui.Color(0xFF808080));
      expect(colors.length, 17);
      expect(colors.first.a, closeTo(0, 1e-9));
      expect(colors[8].a, closeTo(0.5, 1e-9));
      expect(colors.last.a, closeTo(1, 1e-9));
    });

    test('A6 dash 除 penWidth 再乘回、arc 两次取负、径向渐变常量（:738-812）', () {
      expect(HudPainter.dashPattern(<Object?>[4, 2], penWidth: 2), <double>[4, 2]);
      expect(HudPainter.dashPattern(<Object?>[1], penWidth: 0.5), <double>[1]);
      expect(HudPainter.dashOffset(<Object?>[3], penWidth: 1.5), closeTo(3, 1e-9));
      expect(HudPainter.arcRect(10, 20, 5), ui.Rect.fromLTWH(5, 15, 10, 10));
      expect(HudPainter.arcStartRadians(1.25), 1.25);
      expect(HudPainter.arcSweepRadians(-0.75), -0.75);
      expect(HudPainter.rightMaskRect(800, 1100, 984), ui.Rect.fromLTWH(800, 0, 300, 984));
      expect(HudPainter.radialCenter, const ui.Offset(979.2, 518.4));
      expect(HudPainter.radialRadius, 1100);
      expect(HudPainter.radialStops, <double>[0, 0.76, 1]);
    });

    test('A7 gradient 双色表（Glyphs.cpp:806-812）', () {
      expect(HudPainter.radialColors(false), <ui.Color>[
        const ui.Color(0xFFE7E7E1),
        const ui.Color(0xFFE3E1DC),
        const ui.Color(0xFFE4DFDB),
      ]);
      expect(HudPainter.radialColors(true), <ui.Color>[
        const ui.Color(0xFF202A2F),
        const ui.Color(0xFF172125),
        const ui.Color(0xFF11181B),
      ]);
    });

    test('A8 image op 走 imageResolver，缺失才计 missingImages（:813-825）', () async {
      final ui.Image image = await onePixelImage();
      int calls = 0;
      final HudPainter painter = HudPainter(
        atlas: syntheticAtlas(),
        imageResolver: (String key) {
          calls += 1;
          return key.isEmpty ? null : image;
        },
      );
      final HudPaintStats present = painter.paintAll(
        recordingCanvas(),
        <Object?>[opImage('cover', 0, 0, 54, 54)],
      );
      expect(calls, 1);
      expect(present.missingImages, 0);
      final HudPaintStats absent = painter.paintAll(
        recordingCanvas(),
        <Object?>[opImage('', 0, 0, 1, 1)],
      );
      expect(absent.missingImages, 1);
      image.dispose();
    });
  });

  // ── B. 命中六字段（NativeHud.cpp:102-109 / PlayerBar.cpp:46-53）───────
  group('B 命中六字段', () {
    test('B1 六字段语义与 rect（NativeHud.cpp:102-109）', () {
      final HudHit hit = HudHit.fromJson(<String, Object?>{
        'x': 1.5,
        'y': 2.0,
        'width': 3.0,
        'height': 4.0,
        'action': 'open',
        'label': '打开',
      });
      expect(hit.x, 1.5);
      expect(hit.y, 2);
      expect(hit.width, 3);
      expect(hit.height, 4);
      expect(hit.action, 'open');
      expect(hit.label, '打开');
      expect(hit.fixed, isFalse);
      expect(hit.rect, ui.Rect.fromLTWH(1.5, 2, 3, 4));
    });

    test('B2 label 缺省回落 action（label.isNull() ? action : label）', () {
      final HudHit hit = HudHit.fromJson(<String, Object?>{
        'x': 0,
        'y': 0,
        'width': 1,
        'height': 1,
        'action': 'open',
        'label': null,
      });
      expect(hit.label, 'open');
    });

    test('B3 六字段缺一不可，缺则 FormatException', () {
      const List<String> required = <String>['x', 'y', 'width', 'height', 'action', 'label'];
      for (final String key in required) {
        final Map<String, Object?> json = <String, Object?>{
          'x': 0.0,
          'y': 0.0,
          'width': 1.0,
          'height': 1.0,
          'action': 'open',
          'label': '打开',
        };
        json.remove(key);
        expect(
          () => HudHit.fromJson(json),
          throwsA(isA<FormatException>()),
          reason: '缺 ' + key + ' 必须抛 FormatException',
        );
      }
    });

    test('B4 listFromJson 保序、不排序不查重（flatarray 原序）', () {
      final List<HudHit> hits = HudHit.listFromJson(<Object?>[
        <String, Object?>{'x': 0, 'y': 0, 'width': 1, 'height': 1, 'action': 'b', 'label': 'B'},
        <String, Object?>{'x': 0, 'y': 0, 'width': 1, 'height': 1, 'action': 'a', 'label': 'A'},
        <String, Object?>{'x': 0, 'y': 0, 'width': 1, 'height': 1, 'action': 'b', 'label': 'B'},
      ]);
      expect(hits.map((HudHit hit) => hit.action).toList(), <String>['b', 'a', 'b']);
      expect(HudHit.listFromJson(null), isEmpty);
    });

    test('B5 hitTest 反向扫描；modalOffset 平移非 fixed；fixed 不动', () {
      final List<HudHit> hits = HudHit.listFromJson(<Object?>[
        <String, Object?>{'x': 0, 'y': 900, 'width': 100, 'height': 50, 'action': 'page', 'label': '页'},
        <String, Object?>{
          'x': 0,
          'y': 900,
          'width': 100,
          'height': 50,
          'action': 'bar',
          'label': '栏',
          'fixed': true,
        },
      ]);
      expect(HudHit.hitTest(hits, const ui.Offset(10, 910))?.action, 'bar');
      expect(HudHit.hitTest(hits, const ui.Offset(10, 945), modalOffset: 40)?.action, 'bar');
      expect(HudHit.hitTest(hits, const ui.Offset(10, 975), modalOffset: 40)?.action, 'page');
      expect(HudHit.hitTest(hits, const ui.Offset(10, 975)), isNull);
    });
  });

  // ── C. archive 页（NativeHud.cpp:404-514）──────────────────────────────
  group('C archive 页', () {
    test('C1 命中 30 条原序钉住（nav 4 + 页内 16 + PlayerBar 10）', () {
      expectHits(buildArchiveSlice().hits, archiveExpectedHits());
    });

    test('C2 fixed 只出现在 PlayerBar 段（第 20 条起，0-based）', () {
      final HudSlice slice = buildArchiveSlice();
      expect(slice.hits.length, 30);
      for (int index = 0; index < 20; index += 1) {
        expect(
          slice.hits[index].containsKey('fixed'),
          isFalse,
          reason: '第 ' + index.toString() + ' 条不是 PlayerBar，不许带 fixed',
        );
      }
      for (int index = 20; index < slice.hits.length; index += 1) {
        expect(slice.hits[index]['fixed'], isTrue, reason: '第 ' + index.toString() + ' 条必须 fixed');
      }
    });

    test('C3 标题命中是 414x37 而不是整行，且与 command 同代生成', () {
      final HudSlice slice = buildArchiveSlice();
      final Map<String, Object?> title = slice.hits.firstWhere(
        (Map<String, Object?> hit) => hit['action'] == 'open' && hit['label'] == '音乐槽位',
      );
      expect(title['x'], 1131.0);
      expect(title['y'], 509.0);
      expect(title['width'], 414.0);
      expect(title['height'], 37.0);
      expect(slice.commands.whereType<List<Object?>>().isNotEmpty, isTrue);
      expect(slice.hits.length * 1.0, lessThanOrEqualTo(slice.commands.length * 1.0));
    });

    test('C4 播放栏固定在 y=984（NativeHud.cpp:224-311 末尾 playerBar(0,984,width)）', () {
      final HudSlice slice = buildArchiveSlice();
      for (final Map<String, Object?> hit in slice.hits.skip(20)) {
        expect((hit['y'] as num).toDouble(), greaterThanOrEqualTo(978.0));
      }
      expect(playerBarExpectedHits().length, 10);
      expect((playerBarExpectedHits()[0][3] as double), 998.0);
    });
  });

  // ── D. 详情页（NativeHudDetail.cpp:118-215 / SongDetailCard.cpp）──────
  group('D 详情页', () {
    test('D1 命中 25 条原序钉住（页内 15 + PlayerBar 10）', () {
      expectHits(buildDetailSlice().hits, detailExpectedHits());
    });

    test('D2 三枚主/次动作等宽且 gap=12（SongDetailCard.cpp actions()）', () {
      final HudSlice slice = buildDetailSlice();
      final List<Map<String, Object?>> primary = slice.hits
          .where((Map<String, Object?> hit) => hit['y'] == 476.0)
          .toList();
      expect(primary.length, 3);
      final double width = (primary[0]['width'] as num).toDouble();
      expect(width, closeTo(253.93333333333334, 1e-9));
      double previousRight = -1;
      for (final Map<String, Object?> hit in primary) {
        final double left = (hit['x'] as num).toDouble();
        if (previousRight >= 0) {
          expect(left - previousRight, closeTo(12, 1e-9));
        }
        previousRight = left + width;
      }
      final List<Map<String, Object?>> secondary = slice.hits
          .where((Map<String, Object?> hit) => hit['y'] == 532.0)
          .toList();
      expect(secondary.length, 3);
    });

    test('D3 tabs 三分栏宽 = usable/3 - 12（SongDetailCard.cpp tabs）', () {
      final HudSlice slice = buildDetailSlice();
      final List<Map<String, Object?>> tabs = slice.hits
          .where((Map<String, Object?> hit) => (hit['action'] as String).startsWith('tab:'))
          .toList();
      expect(tabs.map((Map<String, Object?> hit) => hit['action']).toList(), <String>[
        'tab:overview',
        'tab:notes',
        'tab:history',
      ]);
      expect((tabs[0]['width'] as num).toDouble(), closeTo(249.93333333333334, 1e-9));
      expect((tabs[1]['x'] as num).toDouble() - (tabs[0]['x'] as num).toDouble(), closeTo(785.8 / 3, 1e-9));
    });
  });

  // ── E. 检索页 + 命中裁剪（NativeHudSearch.cpp / HudScroll.h:67-86）─────
  group('E 检索页', () {
    test('E1 8 行结果命中钉住（left=1013、usable=795、首行 450、行高 72）', () {
      expectHits(buildSearchSlice().hits, searchExpectedHits());
    });

    test('E2 模态几何：modalWidth=901、left=960、viewport=(1013,450,795,430)', () {
      const double width = kStageWidth;
      final double modalWidth = math.min<double>(
        width - 100,
        math.max<double>(760.0, math.min<double>(1000.0, width * 0.5 - 59)),
      );
      final double modalLeft = width - modalWidth - 59;
      expect(modalWidth, closeTo(901, 1e-9));
      expect(modalLeft, closeTo(960, 1e-9));
      final ui.Rect viewport = ui.Rect.fromLTWH(
        modalLeft + kSearchInset,
        122 + kResultListTop,
        modalWidth - 2 * kSearchInset,
        kResultListBottom - kResultListTop,
      );
      expect(viewport.left, closeTo(1013, 1e-9));
      expect(viewport.top, closeTo(450, 1e-9));
      expect(viewport.width, closeTo(795, 1e-9));
      expect(viewport.height, closeTo(430, 1e-9));
      expect(viewport.bottom, closeTo(880, 1e-9));
    });

    test('E3 clipHits 只裁 index>=first：第 5 行裁到高 70，第 6/7 行删除', () {
      final HudSlice slice = buildSearchSlice();
      final List<Map<String, Object?>> withToolbar = <Map<String, Object?>>[
        <String, Object?>{
          'x': 1013.0,
          'y': 374.0,
          'width': 30.0,
          'height': 36.0,
          'action': 'music:kind:0',
          'label': '歌曲',
        },
        ...slice.hits,
      ];
      final ui.Rect viewport = ui.Rect.fromLTWH(1013, 450, 795, 430);
      final List<Map<String, Object?>> clipped = qtClipHits(withToolbar, 1, viewport);
      expect(clipped.length, 1 + 6);
      expect(clipped.first['action'], 'music:kind:0');
      expect((clipped.first['height'] as num).toDouble(), 36.0);
      final List<Map<String, Object?>> rows = clipped.skip(1).toList();
      expect(rows[4]['action'], 'music:result:0:4');
      expect((rows[4]['y'] as num).toDouble(), closeTo(738, 1e-9));
      expect((rows[4]['height'] as num).toDouble(), closeTo(72, 1e-9));
      expect(rows[5]['action'], 'music:result:0:5');
      expect((rows[5]['y'] as num).toDouble(), closeTo(810, 1e-9));
      expect((rows[5]['height'] as num).toDouble(), closeTo(70, 1e-9));
    });

    test('E4 可见窗口 first/last 与 Qt floor/ceil 一致', () {
      expect(qtVisibleFirst(0), 0);
      expect(qtVisibleLast(0, 8), 7);
      expect(qtVisibleFirst(144), 1);
      expect(qtVisibleLast(144, 8), 7);
      expect(qtVisibleFirst(1000), 12);
      expect(qtVisibleLast(1000, 8), 7);
    });
  });

  // ── F. 播放队列（PlaybackQueueCard.cpp）───────────────────────────────
  group('F 播放队列', () {
    test('F1 命中 11 条原序钉住（close/clear/4 mode/3 行 + 2 个删除）', () {
      expectHits(buildQueueSlice().hits, queueExpectedHits());
    });

    test('F2 modeWidth=(1154-24)/4=282.5，四个模式等距 8', () {
      final List<Map<String, Object?>> modes = buildQueueSlice()
          .hits
          .where((Map<String, Object?> hit) => (hit['action'] as String).startsWith('player:mode:'))
          .toList();
      expect(modes.length, 4);
      expect((modes[0]['width'] as num).toDouble(), closeTo(282.5, 1e-9));
      expect((modes[1]['x'] as num).toDouble() - (modes[0]['x'] as num).toDouble(), closeTo(290.5, 1e-9));
      expect(modes.map((Map<String, Object?> hit) => hit['action']).toList(), <String>[
        'player:mode:off',
        'player:mode:all',
        'player:mode:one',
        'player:mode:shuffle',
      ]);
    });

    test('F3 当前行不给删除命中，其余行给（PlaybackQueueCard.cpp !current）', () {
      final HudSlice slice = buildQueueSlice();
      expect(
        slice.hits.any((Map<String, Object?> hit) => hit['action'] == 'player:remove:0'),
        isFalse,
      );
      expect(
        slice.hits.any((Map<String, Object?> hit) => hit['action'] == 'player:remove:1'),
        isTrue,
      );
      expect(qtMaximumOffset(0), 0);
      expect(qtMaximumOffset(3), 2);
    });
  });

  // ── G. 字形 JSON 载入与 advance/path ──────────────────────────────────
  group('G 字形', () {
    test('G1 资源契约 units/ascent/descent = 1000/1044/-282', () {
      final GlyphAtlas atlas = syntheticAtlas();
      expect(atlas.resourceMatchesQtContract, isTrue);
      expect(GlyphAtlas.unitsPerEm, 1000);
      expect(GlyphAtlas.kQtUnitsPerEm, 1000);
      expect(GlyphAtlas.kQtAscent, 1044);
      expect(GlyphAtlas.kQtDescent, -282);
      expect(GlyphAtlas.baselineFactor, kQtBaselineFactor);
      expect(GlyphAtlas.weights, <String>['light', 'regular', 'demibold', 'bold']);
    });

    test('G2 width 末尾减 tracking、bounds 用 1.044（Glyphs.cpp:286-338）', () {
      final GlyphAtlas atlas = syntheticAtlas();
      expect(atlas.width('A', 20, 'regular'), closeTo(0.666 * 20, 1e-9));
      expect(atlas.width('AB', 20, 'regular'), closeTo((0.666 + 0.62) * 20, 1e-9));
      expect(atlas.width('AB', 20, 'regular', tracking: 4), closeTo((0.666 + 0.62) * 20 + 4, 1e-9));
      final ui.Rect bounds = atlas.bounds('A', 20, 'regular');
      expect(bounds.left, closeTo(13 * 0.02, 1e-9));
      expect(bounds.right, closeTo(653 * 0.02, 1e-9));
      expect(bounds.top, closeTo(20 * kQtBaselineFactor - 740 * 0.02, 1e-9));
      expect(bounds.bottom, closeTo(20 * kQtBaselineFactor, 1e-9));
    });

    test('G3 artWidth 用 lettering 的 width 且末尾减 tracking（:403-412）', () {
      final GlyphAtlas atlas = syntheticAtlas();
      expect(atlas.artWidth('access', 20), closeTo((0.732 + 0.5) * 20, 1e-9));
      expect(atlas.artWidth('access', 20, count: 1), closeTo(0.732 * 20, 1e-9));
      expect(atlas.artWidth('access', 20, tracking: 4), closeTo((0.732 + 0.5) * 20 + 4, 1e-9));
      expect(atlas.artWidth('missing', 20), 0);
      expect(atlas.art('access').length, 2);
      expect(atlas.artText['access'], 'AC');
    });

    test('G4 calibrated Gamma1.8 → sRGB（Glyphs.cpp:35-49）', () {
      expect(qtCalibratedChannel(0.5), closeTo(0.5723067531639353, 1e-12));
      expect(qtCalibratedChannel(0.08), closeTo(0.1036974505282458, 1e-12));
      expect(qtCalibratedChannel(0.92), closeTo(0.9360448981490523, 1e-12));
      expect(qtCalibratedChannel(0.35), closeTo(0.42506881227638155, 1e-12));
      final ui.Color calibrated = GlyphAtlas.colorFromJson(<Object?>[0.5, 0.5, 0.5, 1, 'calibrated']);
      expect(calibrated.r, closeTo(0.5723067531639353, 1 / 255));
      expect(calibrated.a, closeTo(1, 1e-9));
      final ui.Color plain = GlyphAtlas.colorFromJson(<Object?>[0.5, 0.5, 0.5, 1]);
      expect(plain.r, closeTo(0.5, 1 / 255));
      final ui.Color defaultAlpha = GlyphAtlas.colorFromJson(<Object?>[0, 0, 0]);
      expect(defaultAlpha.a, closeTo(1, 1e-9));
    });

    test('G5 真实 misans-glyphs.json：四 weight、1007 字形、A 的 advance/path', () {
      _requirePackageRoot('G5 真实字形资源检查');
      final Map<String, dynamic> root =
          jsonDecode(io.File('Assets/fonts/misans-glyphs.json').readAsStringSync()) as Map<String, dynamic>;
      expect(root.keys.toList(), <String>['light', 'regular', 'demibold', 'bold']);
      for (final String weight in GlyphAtlas.weights) {
        final Map<String, dynamic> table = root[weight] as Map<String, dynamic>;
        expect(table['units'], 1000);
        expect(table['ascent'], 1044);
        expect(table['descent'], -282);
        expect(
          (table['glyphs'] as Map<String, dynamic>).length,
          1007,
          reason: weight + ' 字形数必须与 Qt 资源一致',
        );
      }
      final Map<String, dynamic> a =
          (root['regular'] as Map<String, dynamic>)['glyphs']['A'] as Map<String, dynamic>;
      expect(a['advance'], 0.666);
      expect(a['path'], 'M653 0 378 740H288L13 0H105L199 257H467L561 0ZM330 614H336L437 339H229Z');
    });

    test('G6 真实 boot-lettering-art.json：letter 用 width，无 advance', () {
      _requirePackageRoot('G6 真实 lettering 资源检查');
      final Map<String, dynamic> root =
          jsonDecode(io.File('Resources/boot-lettering-art.json').readAsStringSync()) as Map<String, dynamic>;
      expect(root.keys.toList(), <String>[
        'access',
        'identity',
        'request',
        'processing',
        'processingGlitch',
        'permission',
        'brand',
        'welcome',
        'company',
        'database',
      ]);
      final Map<String, dynamic> access = root['access'] as Map<String, dynamic>;
      expect(access['text'], 'ACCESS PERMISSION REQUIRED');
      final List<dynamic> letters = access['letters'] as List<dynamic>;
      expect(letters.length, 26);
      final Map<String, dynamic> first = letters.first as Map<String, dynamic>;
      expect(first['width'], 0.732);
      expect(first.containsKey('advance'), isFalse);
      expect(
        (first['path'] as String).startsWith('M543 614.0 621 800.0H708L410 100.0H321L2'),
        isTrue,
      );
    });

    test('G7 真实资源装配 GlyphAtlas：A 的 width/bounds 与 Qt 数值一致', () {
      _requirePackageRoot('G7 真实资源装配检查');
      final GlyphAtlas atlas = GlyphAtlas.fromJsonStrings(
        glyphsJson: io.File(GlyphAtlas.kGlyphsAsset).readAsStringSync(),
        letteringJson: io.File(GlyphAtlas.kLetteringAsset).readAsStringSync(),
      );
      expect(atlas.resourceMatchesQtContract, isTrue);
      expect(atlas.width('A', 20, 'regular'), closeTo(0.666 * 20, 1e-9));
      final ui.Rect bounds = atlas.bounds('A', 20, 'regular');
      expect(bounds.left, closeTo(13 * 0.02, 1e-9));
      expect(bounds.right, closeTo(653 * 0.02, 1e-9));
      expect(bounds.top, closeTo(20 * kQtBaselineFactor - 740 * 0.02, 1e-9));
      expect(bounds.bottom, closeTo(20 * kQtBaselineFactor, 1e-9));
      expect(atlas.missingGlyphCount, 0);
      expect(atlas.artWidth('access', 20), greaterThan(0));
    });

    test('G8 drawText 带 1.044、drawArt 不带（静态核对 glyph_loader.dart）', () {
      final String source = io.File('lib/spike/dart_hud/glyph_loader.dart').readAsStringSync();
      expect(source.contains('canvas.translate(cursor, y + size * baselineFactor);'), isTrue,
          reason: 'Glyphs.cpp:530-563 text() 必须 translate(x, y + size*1.044)');
      expect(source.contains('canvas.translate(cursor, y);'), isTrue,
          reason: 'Glyphs.cpp:565-588 art() 必须 translate(x, y) 无 1.044');
      expect(GlyphAtlas.baselineFactor, 1.044);
    });
  });

  // ── H. 3D 场景（真实 GLB + Qt 相机数学；上传/绘制 ARCH_BLOCKED）───────
  group('H 3D 场景', () {
    test('H1 相机/投影/雾常量（NativeScene.h:123-132 / NativeScene.cpp:49-52）', () {
      expect(kQtFov, 6.15);
      expect(kQtFogNear, 22);
      expect(kQtFogFar, 47);
      expect(kQtNearPlane, 5);
      expect(kQtFarPlane, 300);
      expect(kQtAoFov, 34);
      expect(kStageWidth / kStageHeight, closeTo(16 / 9, 1e-9));
      expect(kStageWidth, 1920);
      expect(kStageHeight, 1080);
    });

    test('H2 cellPosition 公式（NativeScene.cpp:76-78）', () {
      expect(qtCellPosition(0, 12), <double>[-10.4, -4.6, -2.17]);
      expect(qtCellPosition(1, 12), <double>[-5.2, -4.6, -2.17]);
      expect(qtCellPosition(2, 12), <double>[0, -4.6, -2.17]);
      expect(qtCellPosition(3, 14), <double>[5.2, -4.6, -0.93]);
      expect(qtCellPosition(4, 15.5), <double>[10.4, -4.6, 0]);
    });

    test('H3 smooth/ease 与 detail 混合（SceneMotion.cpp:42-49 / NativeSceneFrame.cpp:116）', () {
      expect(qtSmooth(0), 0);
      expect(qtSmooth(1), 1);
      expect(qtSmooth(0.5), closeTo(0.5, 1e-12));
      expect(qtSmooth(0.25), closeTo(0.103515625, 1e-12));
      expect(qtSmooth(-3), 0);
      expect(qtSmooth(9), 1);
      expect(qtEase(0), 0);
      expect(qtEase(1), 1);
      expect(qtEase(0.5), closeTo(0.5, 1e-12));
      expect(qtEase(0.25), closeTo(0.15625, 1e-12));
      expect(qtDetailBlend(0.25), 0);
      expect(qtDetailBlend(0.8), closeTo(qtSmooth(1), 1e-12));
      expect(qtDetailBlend(0.525), closeTo(0.5, 1e-12));
    });

    test('H4 真实 GLB 容器事实：22/22/16、无 animations、非静态背景', () {
      _requirePackageRoot('H4 真实 GLB 检查');
      final GlbContainer assembly =
          GlbContainer.parse(io.File('Assets/models/archive-assembly.glb').readAsBytesSync());
      expect(assembly.magic, 'glTF');
      expect(assembly.version, 2);
      expect(assembly.length, 3343744);
      expect(assembly.jsonChunkType, 'JSON');
      expect(assembly.jsonChunkLength, 22768);
      final Map<String, dynamic> json = assembly.json;
      expect((json['nodes'] as List<dynamic>).length, 22);
      expect((json['meshes'] as List<dynamic>).length, 22);
      expect((json['materials'] as List<dynamic>).length, 16);
      expect(json.containsKey('animations'), isFalse, reason: '静态装配体没有动画轨道');
      expect((json['asset'] as Map<String, dynamic>)['version'], '2.0');
      expect((json['asset'] as Map<String, dynamic>)['generator'], 'Khronos glTF Blender I/O v4.5.51');
      final List<dynamic> nodes = json['nodes'] as List<dynamic>;
      expect((nodes.first as Map<String, dynamic>)['name'], 'cover__Frosted_Polymer.012');
      expect(json.containsKey('scenes'), isTrue);
    });

    test('H5 第二件 GLB 与 scene-fixture 运行时值', () {
      _requirePackageRoot('H5 第二件 GLB / scene-fixture 检查');
      final GlbContainer cassette =
          GlbContainer.parse(io.File('Assets/models/archive-cassette.glb').readAsBytesSync());
      expect(cassette.length, 3565116);
      expect(cassette.jsonChunkLength, 18252);
      expect((cassette.json['nodes'] as List<dynamic>).length, 17);
      expect((cassette.json['meshes'] as List<dynamic>).length, 17);
      expect((cassette.json['materials'] as List<dynamic>).length, 17);

      final Map<String, dynamic> fixture =
          jsonDecode(io.File('Resources/scene-fixture.json').readAsStringSync()) as Map<String, dynamic>;
      expect(fixture.keys.toList(), <String>['frame', 'rays']);
      final Map<String, dynamic> frame = fixture['frame'] as Map<String, dynamic>;
      expect(frame['near'], 5);
      expect(frame['far'], 300);
      expect(frame['detail'], 0);
      expect((frame['time'] as num).toDouble(), closeTo(3.861, 1e-9));
      expect((frame['fogNear'] as num).toDouble(), closeTo(144.99796976340926, 1e-9));
      expect((frame['fogFar'] as num).toDouble(), closeTo(164.99796976340926, 1e-9));
      expect(frame['mode'], 'archive');
      final List<dynamic> rays = fixture['rays'] as List<dynamic>;
      expect(rays.length, 4);
      final Map<String, dynamic> first = rays.first as Map<String, dynamic>;
      expect((first['x'] as num).toDouble(), closeTo(26.4, 1e-9));
      expect((first['y'] as num).toDouble(), 288);
      expect((first['hit'] as Map<String, dynamic>)['lane'], 3);
      expect((first['hit'] as Map<String, dynamic>)['row'], -1);
    });

    test('H6 真实资源存在，且没有用静态背景图顶替 3D', () {
      _requirePackageRoot('H6 真实资源存在性检查');
      expect(io.File('Assets/models/archive-assembly.glb').existsSync(), isTrue);
      expect(io.File('Assets/models/archive-cassette.glb').existsSync(), isTrue);
      expect(io.File('Resources/scene-fixture.json').existsSync(), isTrue);
      expect(io.File('Resources/slots.json').existsSync(), isTrue);
      final Map<String, dynamic> slots =
          jsonDecode(io.File('Resources/slots.json').readAsStringSync()) as Map<String, dynamic>;
      expect(slots.keys.toList(), <String>['categories', 'columns', 'records']);
      expect(slots['columns'], <String>['搜索结果', '喜欢的歌曲', '我的歌单', '收藏歌单', '收藏专辑']);
      expect((slots['records'] as List<dynamic>).length, 40);
      expect((slots['records'] as List<dynamic>).first, <String, dynamic>{
        'id': 'SLOT-3-1',
        'title': '音乐槽位',
        'category': '我的歌单',
      });
      expect(slots['categories'] is List<dynamic>, isTrue);
      // 3D 必须是真实 GLB：任何静态背景图都不接受。
      for (final String banned in <String>[
        'Assets/images/archive.png',
        'Assets/images/archive.webp',
        'Assets/images/scene-background.png',
        'assets/3d/static-background.png',
      ]) {
        expect(io.File(banned).existsSync(), isFalse, reason: '禁止用静态背景顶替真实 3D：' + banned);
      }
    });
  });

  // ── I. 差异登记（字形/命中/时延）───────────────────────────────────────
  group('I 差异登记', () {
    test('I1 三类差异全部登记，时延/像素明确为未执行', () {
      expect(kSliceDiffs.length, greaterThanOrEqualTo(9));
      expect(kSliceDiffs.map((SliceDiff diff) => diff.dimension), contains('HUD 首帧时延'));
      expect(kSliceDiffs.map((SliceDiff diff) => diff.dimension), contains('字形栅格像素'));
      expect(kSliceDiffs.map((SliceDiff diff) => diff.dimension), contains('命中六字段'));
      final List<SliceDiff> notMeasured =
          kSliceDiffs.where((SliceDiff diff) => diff.verdict == 'NOT_MEASURED').toList();
      expect(notMeasured.length, 2);
      for (final SliceDiff diff in notMeasured) {
        expect(diff.dartSlice.contains('未执行'), isTrue, reason: diff.dimension + ' 不得声称已测量');
      }
      for (final SliceDiff diff in kSliceDiffs) {
        expect(diff.evidence.isNotEmpty, isTrue);
        expect(diff.verdict.isNotEmpty, isTrue);
      }
    });

    test('I2 3D 差异如实标 BLOCKED（ARCH_BLOCKED，不伪通过）', () {
      final SliceDiff scene = kSliceDiffs.firstWhere((SliceDiff diff) => diff.dimension == '3D 场景');
      expect(scene.verdict, 'BLOCKED（架构）');
      expect(scene.dartSlice.contains('Unavailable'), isTrue);
      expect(scene.evidence.contains('android/'), isTrue);
    });

    test('I3 BLK-PUBSPEC-INTEGRATION：pubspec 仍无 integration_test 依赖', () {
      _requirePackageRoot('I3 pubspec 检查');
      final String content = io.File('pubspec.yaml').readAsStringSync();
      expect(
        content.contains('integration_test:'),
        isFalse,
        reason: '父 T13-C18 明令禁止改 pubspec.yaml；此断言失败说明依赖被改过，必须重跑 RED/GREEN',
      );
      expect(io.Directory('integration_test').existsSync(), isTrue);
    });
  });

  // ── J. 同一切片走真实 CustomPaint 管线（集成写法，未执行）─────────────
  group('J 切片集成', () {
    testWidgets('J1 archive 切片在 CustomPaint 里走完，stats 与 commands 对齐', (WidgetTester tester) async {
      final HudSlice slice = buildArchiveSlice();
      final HudSlicePainter painter = HudSlicePainter(
        HudPainter(atlas: syntheticAtlas()),
        slice.commands,
      );
      await tester.pumpWidget(
        Directionality(
          textDirection: TextDirection.ltr,
          child: Center(
            child: SizedBox(
              width: kStageWidth,
              height: kStageHeight,
              child: CustomPaint(painter: painter),
            ),
          ),
        ),
      );
      expect(painter.stats, isNotNull);
      expect(painter.stats?.commands, slice.commands.length);
      expect(painter.stats?.unknownOps, 0);
      expect(painter.stats?.missingImages, 0);
      expect(tester.takeException(), isNull);
    });

    testWidgets('J2 四个切片共用同一 HudPainter，命令数自洽', (WidgetTester tester) async {
      final HudPainter painter = HudPainter(atlas: syntheticAtlas());
      final List<HudSlice> slices = <HudSlice>[
        buildArchiveSlice(),
        buildDetailSlice(),
        buildSearchSlice(),
        buildQueueSlice(),
      ];
      for (final HudSlice slice in slices) {
        final HudSlicePainter widget = HudSlicePainter(painter, slice.commands);
        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SizedBox(
              width: kStageWidth,
              height: kStageHeight,
              child: CustomPaint(painter: widget),
            ),
          ),
        );
        expect(widget.stats?.unknownOps, 0, reason: slice.name + ' 不许出现未知 op');
        expect(widget.stats?.commands, slice.commands.length);
      }
    });
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// 9. 辅助类型
// ═══════════════════════════════════════════════════════════════════════════

/// 把 HudPainter 挂进真实 CustomPaint 管线（integration_test 写法）。
class HudSlicePainter extends CustomPainter {
  HudSlicePainter(this.painter, this.commands);

  final HudPainter painter;
  final List<Object?> commands;
  HudPaintStats? stats;

  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    stats = painter.paintAll(canvas, commands);
  }

  @override
  bool shouldRepaint(covariant HudSlicePainter oldDelegate) => oldDelegate.commands != commands;
}

/// 最小 GLB 容器解析（glTF 2.0 binary）：只读头部与 JSON chunk，不做解码/上传。
class GlbContainer {
  GlbContainer(this.magic, this.version, this.length, this.jsonChunkType, this.jsonChunkLength, this.json);

  final String magic;
  final int version;
  final int length;
  final String jsonChunkType;
  final int jsonChunkLength;
  final Map<String, dynamic> json;

  static GlbContainer parse(List<int> bytes) {
    final Uint8List data = Uint8List.fromList(bytes);
    final ByteData view = ByteData.sublistView(data);
    final String magic = String.fromCharCodes(data.sublist(0, 4));
    final int version = view.getUint32(4, Endian.little);
    final int length = view.getUint32(8, Endian.little);
    final int chunkLength = view.getUint32(12, Endian.little);
    final String chunkType = String.fromCharCodes(data.sublist(16, 20));
    final Map<String, dynamic> json =
        jsonDecode(utf8.decode(data.sublist(20, 20 + chunkLength))) as Map<String, dynamic>;
    return GlbContainer(magic, version, length, chunkType, chunkLength, json);
  }
}
