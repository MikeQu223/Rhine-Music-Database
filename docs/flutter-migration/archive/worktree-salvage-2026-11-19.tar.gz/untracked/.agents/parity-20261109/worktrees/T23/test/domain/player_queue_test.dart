/// 播放聚合根测试（未执行：本任务禁止 flutter test / dart test）。
/// 证据源：Qt/src/MusicPlayer.h、Qt/src/MusicPlayer.cpp；端口契约见 Qt/src/Host.h、
/// Qt/src/MusicApi.h、Qt/src/PlaybackConnection.h、Qt/src/PlatformFeatures.h。
library;

import 'dart:async';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/domain/lyrics/lyrics_controller.dart';
import 'package:rhine_music_database/domain/player/music_player.dart';
import 'package:rhine_music_database/domain/player/playback_queue.dart';

Map<String, Object?> song(
  String id, {
  String provider = 'netease',
  String title = '曲',
  Object? extra,
}) =>
    <String, Object?>{
      'kind': 'song',
      'id': id,
      'provider': provider,
      'title': title,
      'artist': '歌手',
      'album': '专辑',
      'duration': 1000.0,
      if (extra is Map) ...Map<String, Object?>.from(extra),
    };

/// 宿主端口替身，记录媒体会话调用而不产生任何真实播放副作用。
class FakeHost implements MusicPlayerHostPort {
  final Map<String, String> preferences = <String, String>{};
  final List<String> controls = <String>[];
  final List<Map<String, Object?>> metadata = <Map<String, Object?>>[];
  final List<String> loaded = <String>[];
  final List<Map<String, Object?>> loads = <Map<String, Object?>>[];
  final List<void Function()> scheduled = <void Function()>[];
  final List<String> covers = <String>[];
  Map<String, Object?> media = <String, Object?>{};
  bool readable = true;
  bool loadResult = true;
  String coverResult = '';
  PlaybackConnectionPort? connection;

  @override
  String preference(String key) => preferences[key] ?? '';

  @override
  void setPreference(String key, String value) => preferences[key] = value;

  @override
  Future<String> loadCover(String url) async {
    covers.add(url);
    return coverResult;
  }

  @override
  Future<Map<String, Object?>> requestJson(String path, Map<String, Object?> params) async =>
      <String, Object?>{};

  @override
  void schedule(int delayMs, void Function() action) => scheduled.add(action);

  @override
  Map<String, Object?> mediaState() => Map<String, Object?>.of(media);

  @override
  Future<bool> mediaLoad(
    String url,
    bool alternative, {
    double resumePosition = 0,
    bool resumePaused = false,
  }) async {
    loaded.add(url);
    loads.add(<String, Object?>{
      'url': url,
      'alternative': alternative,
      'position': resumePosition,
      'paused': resumePaused,
    });
    return loadResult;
  }

  @override
  void mediaControl(String action, [Object? value]) =>
      controls.add(value == null ? action : action + ':' + value.toString());

  @override
  void mediaMetadata(String title, String artist, String album, [String cover = '']) {
    metadata.add(<String, Object?>{'title': title, 'artist': artist, 'album': album, 'cover': cover});
  }

  @override
  PlaybackConnectionPort? playbackConnection() => connection;

  @override
  bool isReadableFile(String path) => readable;

  /// 排空宿主调度队列，模拟 QTimer::singleShot(0)。
  void drainScheduled() {
    final pending = List<void Function()>.of(scheduled);
    scheduled.clear();
    for (final action in pending) {
      action();
    }
  }
}

/// 音乐接口替身，默认返回可播放的远端地址。
class FakeApi extends MusicApiPort {
  FakeApi({this.provider = 'netease', MusicApiResult? result})
      : result = result ??
            MusicApiResult(
              ok: true,
              value: <String, Object?>{'url': 'https://cdn.example.com/a.mp3', 'level': 'exhigh'},
            );

  @override
  final String provider;

  MusicApiResult result;
  Future<MusicApiResult> Function(String operation, List<Object?> arguments)? handler;
  final List<Map<String, Object?>> calls = <Map<String, Object?>>[];

  @override
  Future<MusicApiResult> call(String operation, List<Object?> arguments) async {
    calls.add(<String, Object?>{'operation': operation, 'arguments': arguments});
    final custom = handler;
    if (custom != null) {
      return custom(operation, arguments);
    }
    return result;
  }
}

/// 后台播放连接替身。
class FakeConnection implements PlaybackConnectionPort {
  Map<String, Object?> data = <String, Object?>{};
  String failure = '';
  final List<Map<String, Object?>> commands = <Map<String, Object?>>[];
  final List<void Function()> snapshotListeners = <void Function()>[];
  final List<void Function()> disconnectedListeners = <void Function()>[];

  @override
  void call(String method, Map<String, Object?> arguments) {
    commands.add(<String, Object?>{'method': method, 'arguments': arguments});
  }

  @override
  Map<String, Object?> get snapshot => data;

  @override
  String get error => failure;

  @override
  void addSnapshotChangedListener(void Function() listener) => snapshotListeners.add(listener);

  @override
  void removeSnapshotChangedListener(void Function() listener) => snapshotListeners.remove(listener);

  @override
  void addDisconnectedListener(void Function() listener) => disconnectedListeners.add(listener);
}

/// 歌词接口替身：播放器只做转发，不在播放器内解析歌词。
class StubLyricsApi implements LyricsApiPort {
  StubLyricsApi(this.provider);

  @override
  final String provider;

  @override
  Future<Object?> call(String method, List<Object?> args) async => <String, Object?>{};
}

MusicPlayer buildPlayer({FakeHost? host, FakeApi? api, FakeConnection? connection}) =>
    MusicPlayer(
      host: host ?? FakeHost(),
      api: api ?? FakeApi(),
      playbackConnection: connection,
      lyricsApiFactory: (provider) => StubLyricsApi(provider),
    );

/// 让 play/prepare 的异步段跑完。
Future<void> settle() async {
  for (var index = 0; index < 6; index++) {
    await Future<void>.delayed(Duration.zero);
  }
}

void main() {
  group('构造与偏好', () {
    test('默认音质回落到 exhigh 并读取本地封面缓存与替代音源开关', () {
      final host = FakeHost()
        ..preferences['quality'] = 'nonsense'
        ..preferences['local-cover-cache'] = jsonEncode(<String, Object?>{'a:f': 'https://cdn/c.jpg'})
        ..preferences['alternate-source'] = 'on';
      final player = buildPlayer(host: host);
      expect(player.quality, 'exhigh');
      expect(player.localCovers, <String, Object?>{'a:f': 'https://cdn/c.jpg'});
      expect(player.alternative, isTrue);
      expect(player.mode, 'all');
      expect(player.state['volume'], 0.7);
      expect(player.queue.isEmpty, isTrue);
    });

    test('历史只保留合法 id 且截断 200 条', () {
      final entries = <Map<String, Object?>>[
        song('ok-1'),
        song('bad id'),
        song('ok-2'),
        <String, Object?>{'kind': 'album', 'id': 'ok-3'},
        for (var index = 0; index < 250; index++) song('x' + index.toString()),
      ];
      final host = FakeHost()..preferences['play-history'] = jsonEncode(entries);
      final player = buildPlayer(host: host);
      expect(player.history.length, MusicPlayer.historyLimit);
      expect(player.history.first['id'], 'ok-1');
      expect(player.history[1]['id'], 'ok-2');
    });

    test('损坏的偏好 JSON 退化为空缓存而不抛异常', () {
      final host = FakeHost()
        ..preferences['local-cover-cache'] = '{oops'
        ..preferences['play-history'] = 'not json';
      final player = buildPlayer(host: host);
      expect(player.localCovers, isEmpty);
      expect(player.history, isEmpty);
    });

    test('歌词控制器由播放器独有创建', () {
      final player = buildPlayer();
      expect(player.lyrics, isA<LyricsController>());
      expect(player.lyrics.localSource, 'auto');
    });
  });

  group('入队与选曲守卫', () {
    test('enqueue 拒绝非歌曲条目', () {
      final player = buildPlayer();
      expect(player.enqueue(<String, Object?>{'kind': 'album', 'id': '1'}), isFalse);
      expect(player.enqueue(song('1')), isTrue);
      expect(player.queue.size, 1);
    });

    test('play 拒绝非歌曲或与当前来源不一致的曲目', () {
      final player = buildPlayer();
      player.play(<String, Object?>{'kind': 'album', 'id': '1'});
      expect(player.loading, isFalse);
      expect(player.status, '');
      player.play(song('1', provider: 'local'));
      expect(player.loading, isFalse);
      expect(player.current, isEmpty);
    });

    test('播放器只持有唯一队列实例', () {
      final player = buildPlayer();
      player.queue.replace(<Track>[song('1')]);
      player.play(song('1'));
      expect(player.queue, same(player.queue));
      expect(player.queue.size, 1);
    });
  });

  group('后台服务模式', () {
    test('有连接时构造不读取本地音质偏好', () {
      final host = FakeHost()..preferences['quality'] = 'lossless';
      final player = buildPlayer(host: host, connection: FakeConnection());
      expect(player.quality, '');
    });

    test('播放操作只走唯一连接，不回退本地播放器', () {
      final host = FakeHost();
      final connection = FakeConnection();
      final player = buildPlayer(host: host, connection: connection);
      player.queue.replace(<Track>[song('1')]);
      player.stop();
      expect(connection.commands.map((command) => command['method']), contains('player.stop'));
      expect(host.controls, isEmpty);
    });

    test('连接报错时标记失败但仍是远程执行', () {
      final connection = FakeConnection()..failure = '服务不可用';
      final player = buildPlayer(connection: connection);
      player.setMode('shuffle');
      expect(player.failed, isTrue);
      expect(player.status, '服务不可用');
    });

    test('断开连接时给出重新打开应用的提示', () {
      final connection = FakeConnection();
      final player = buildPlayer(connection: connection);
      connection.disconnectedListeners.single();
      expect(player.failed, isTrue);
      expect(player.status, '后台播放服务已断开，请重新打开应用');
      expect(player.state['playing'], isFalse);
    });

    test('快照选择序号变化时通知选中曲目且不重复通知', () {
      final connection = FakeConnection();
      final player = buildPlayer(connection: connection);
      final selected = <Map<String, Object?>>[];
      player.addTrackSelectedListener(selected.add);
      connection.data = <String, Object?>{
        'queue': <Object?>[song('1')],
        'index': 0,
        'selectionSerial': 7,
        'selectedTrack': song('1'),
        'state': <String, Object?>{'playing': true},
        'lyrics': <String, Object?>{},
      };
      connection.snapshotListeners.single();
      expect(selected.length, 1);
      expect(selected.first['id'], '1');
      connection.snapshotListeners.single();
      expect(selected.length, 1);
    });
  });

  group('远端准备', () {
    test('成功路径写入历史并附带实际音质文案', () async {
      final host = FakeHost();
      final api = FakeApi(
        result: MusicApiResult(
          ok: true,
          value: <String, Object?>{'url': 'https://cdn/a.mp3', 'level': 'exhigh', 'quality': '320'},
        ),
      );
      final player = buildPlayer(host: host, api: api);
      player.play(song('1', title: '歌名'));
      await settle();
      expect(player.loading, isFalse);
      expect(player.failed, isFalse);
      expect(player.status, '正在播放：歌名（高品质）');
      expect(player.actualQuality, 'hq');
      expect(player.history.length, 1);
      expect(host.preferences['play-history'], isNotEmpty);
      final arguments = api.calls.first['arguments'] as List<Object?>;
      expect(api.calls.first['operation'], 'playback');
      expect(arguments[1], 'exhigh');
      expect(arguments[2], false);
      expect(host.loads.first['url'], 'https://cdn/a.mp3');
    });

    test('试听片段只给出试听提示且不追加档位后缀', () async {
      final api = FakeApi(
        result: MusicApiResult(
          ok: true,
          value: <String, Object?>{
            'url': 'https://cdn/a.mp3',
            'freeTrialInfo': <String, Object?>{'start': 0},
            'quality': '320',
          },
        ),
      );
      final player = buildPlayer(api: api);
      player.play(song('1', title: '歌名'));
      await settle();
      expect(player.trial, isTrue);
      expect(player.status, '当前音源为试听片段');
    });

    test('非网易云来源不使用专有档位', () async {
      final qqApi = FakeApi(provider: 'qq');
      final qq = buildPlayer(
        host: FakeHost()..preferences['quality'] = 'jymaster',
        api: qqApi,
      );
      qq.play(song('1'));
      await settle();
      expect((qqApi.calls.first['arguments'] as List<Object?>)[1], 'lossless');
      final sirenApi = FakeApi(provider: 'siren');
      final siren = buildPlayer(
        host: FakeHost()..preferences['quality'] = 'jymaster',
        api: sirenApi,
      );
      siren.play(song('1'));
      await settle();
      expect((sirenApi.calls.first['arguments'] as List<Object?>)[1], 'original');
    });

    test('音源地址为空时给出登录与权限提示', () async {
      final api = FakeApi(
        result: MusicApiResult(ok: true, value: <String, Object?>{'url': ''}),
      );
      final player = buildPlayer(api: api);
      player.play(song('1'));
      await settle();
      expect(player.failed, isTrue);
      expect(player.status, '此歌曲暂无可用音源，请检查登录和歌曲权限');
    });

    test('媒体装载失败时报音频地址不可用', () async {
      final host = FakeHost()..loadResult = false;
      final player = buildPlayer(host: host);
      player.play(song('1'));
      await settle();
      expect(player.status, '音频地址不可用');
      expect(player.loading, isFalse);
    });

    test('迟到的音源响应不覆盖新一代状态', () async {
      final completers = <Completer<MusicApiResult>>[];
      final api = FakeApi();
      api.handler = (operation, arguments) {
        final completer = Completer<MusicApiResult>();
        completers.add(completer);
        return completer.future;
      };
      final player = buildPlayer(api: api);
      player.play(song('1'));
      player.play(song('2'));
      await settle();
      expect(completers.length, 2);
      completers[1].complete(
        MusicApiResult(ok: true, value: <String, Object?>{'url': 'https://cdn/2.mp3'}),
      );
      await settle();
      expect(player.current['id'], '2');
      expect(player.loading, isFalse);
      completers[0].complete(
        MusicApiResult(ok: true, value: <String, Object?>{'url': 'https://cdn/1.mp3'}),
      );
      await settle();
      expect(player.current['id'], '2');
      expect(player.status, '正在播放：曲');
    });

    test('本地曲目不可读时提示重新扫描', () async {
      final host = FakeHost()..readable = false;
      final api = FakeApi(provider: 'local');
      final player = buildPlayer(host: host, api: api);
      player.play(song('1', provider: 'local', extra: <String, Object?>{
        'url': 'file:///music/a.flac',
        'format': 'flac',
      }));
      await settle();
      expect(player.failed, isTrue);
      expect(player.status, '本地文件无法访问，请检查文件位置或重新扫描');
      expect(api.calls, isEmpty);
      expect(host.metadata, isEmpty);
    });

    test('本地曲目可读时按格式给出音质', () async {
      final host = FakeHost();
      final api = FakeApi(provider: 'local');
      final player = buildPlayer(host: host, api: api);
      player.play(song('1', provider: 'local', extra: <String, Object?>{
        'url': 'file:///music/a.flac',
        'format': 'flac',
      }));
      await settle();
      expect(player.actualQuality, 'sq');
      expect(player.status, '正在播放本地文件：flac');
      expect(host.loads.first['url'], 'file:///music/a.flac');
      expect(api.calls, isEmpty);
    });
  });

  group('播放心跳', () {
    test('播放结束只触发一次 onEnd', () {
      final host = FakeHost()
        ..media = <String, Object?>{
          'playing': true,
          'position': 1.0,
          'duration': 10.0,
          'seekable': true,
          'ended': 0,
        };
      final player = buildPlayer(host: host);
      player.current = song('1');
      var ended = 0;
      player.onEnd = () {
        ended++;
      };
      host.media['ended'] = 1;
      player.tick(0.0, force: true);
      expect(ended, 1);
      player.tick(0.2, force: true);
      expect(ended, 1);
    });

    test('结束且没有回调时推进队列', () {
      final host = FakeHost()
        ..media = <String, Object?>{'ended': 0, 'duration': 10.0};
      final player = buildPlayer(host: host);
      player.queue.replace(<Track>[song('1'), song('2')]);
      player.queue.select(0);
      player.current = song('1');
      host.media['ended'] = 1;
      player.tick(0.0, force: true);
      expect(player.current['id'], '2');
    });

    test('可恢复错误先恢复播放，超过上限后失败', () async {
      final host = FakeHost()
        ..media = <String, Object?>{'error': 'boom', 'recoverable': true};
      final player = buildPlayer(host: host);
      player.current = song('1');
      player.tick(0.0, force: true);
      expect(player.status, '正在恢复播放（1/2）…');
      await settle();
      player.tick(1.0, force: true);
      expect(player.status, '正在恢复播放（2/2）…');
      await settle();
      player.tick(2.0, force: true);
      expect(player.failed, isTrue);
      expect(player.status, 'boom');
    });

    test('不可恢复错误直接失败', () {
      final host = FakeHost()
        ..media = <String, Object?>{'error': '解码失败'};
      final player = buildPlayer(host: host);
      player.current = song('1');
      player.tick(0.0, force: true);
      expect(player.failed, isTrue);
      expect(player.status, '解码失败');
    });

    test('恢复位置在可定位后回填并恢复暂停', () async {
      final host = FakeHost()
        ..media = <String, Object?>{
          'playing': false,
          'position': 0.0,
          'duration': 100.0,
          'seekable': true,
        };
      final api = FakeApi(result: MusicApiResult(ok: false, error: '无音源'));
      final player = buildPlayer(host: host, api: api);
      player.restoreSessionState(<String, Object?>{
        'position': 30.0,
        'requested': false,
        'mode': 'all',
        'current': song('1'),
        'queue': <Object?>[song('1')],
        'index': 0,
        'preview': false,
      });
      await settle();
      expect(player.failed, isTrue);
      expect(player.loading, isFalse);
      player.tick(0.0, force: true);
      expect(host.controls, contains('seek:30.0'));
      expect(host.controls, contains('pause'));
    });
  });

  group('传输控制', () {
    test('toggle 在失败态用会话快照重播当前曲目', () {
      final player = buildPlayer();
      player.failed = true;
      player.current = song('1');
      player.queue.replace(<Track>[song('1')]);
      player.toggle();
      expect(player.failed, isFalse);
      expect(player.current['id'], '1');
    });

    test('toggle 在可播放状态切换暂停', () {
      final host = FakeHost()..media = <String, Object?>{'playing': true};
      final player = buildPlayer(host: host);
      player.current = song('1');
      player.toggle();
      expect(host.controls, contains('pause'));
    });

    test('无逐应用音量的平台把音量固定为一并持久化', () {
      final host = FakeHost();
      final player = MusicPlayer(
        host: host,
        api: FakeApi(),
        features: const MusicPlatformFeatures(applicationVolume: false),
        lyricsApiFactory: (provider) => StubLyricsApi(provider),
      );
      player.volume(0.3);
      expect(host.controls, contains('volume:1.0'));
      expect(host.preferences['volume'], '1.0');
    });

    test('恢复期内 seek 只更新目标位置', () async {
      final host = FakeHost()
        ..media = <String, Object?>{'duration': 100.0, 'seekable': true};
      final api = FakeApi(result: MusicApiResult(ok: false, error: '无音源'));
      final player = buildPlayer(host: host, api: api);
      player.restoreSessionState(<String, Object?>{
        'position': 10.0,
        'requested': true,
        'current': song('1'),
        'queue': <Object?>[song('1')],
        'index': 0,
      });
      await settle();
      player.seek(0.5);
      expect(host.controls.where((control) => control.startsWith('seek')), isEmpty);
    });

    test('next 在队列结束时给出结束提示', () {
      final player = buildPlayer();
      player.next(-1);
      expect(player.status, '');
      player.queue.replace(<Track>[song('1')]);
      player.queue.select(0);
      player.next(1, true);
      expect(player.status, '队列已播放完');
    });

    test('setMode 只接受四种模式', () {
      final player = buildPlayer();
      player.setMode('nonsense');
      expect(player.mode, 'all');
      player.setMode('one');
      expect(player.mode, 'one');
    });

    test('setAlternative 持久化开关', () {
      final host = FakeHost();
      final player = buildPlayer(host: host);
      player.setAlternative(true);
      expect(player.alternative, isTrue);
      expect(host.preferences['alternate-source'], 'on');
    });
  });

  group('清理与会话', () {
    test('stop 清空队列与当前项并复位媒体会话', () {
      final host = FakeHost();
      final player = buildPlayer(host: host);
      player.queue.replace(<Track>[song('1'), song('2')]);
      player.current = song('1');
      player.state['playing'] = true;
      player.stop();
      expect(player.queue.isEmpty, isTrue);
      expect(player.current, isEmpty);
      expect(player.status, '');
      expect(player.state['playing'], isFalse);
      expect(host.controls, contains('stop'));
      expect(host.metadata.last['title'], '');
    });

    test('clearHistory 清空历史与偏好', () {
      final host = FakeHost();
      final player = buildPlayer(host: host);
      player.history = <Map<String, Object?>>[song('1')];
      player.clearHistory();
      expect(player.history, isEmpty);
      expect(host.preferences['play-history'], '[]');
    });

    test('clearCaches 清空历史与本地封面缓存', () {
      final host = FakeHost()
        ..preferences['local-cover-cache'] = jsonEncode(<String, Object?>{'a:f': 'u'});
      final player = buildPlayer(host: host);
      player.history = <Map<String, Object?>>[song('1')];
      player.clearCaches();
      expect(player.history, isEmpty);
      expect(player.localCovers, isEmpty);
      expect(host.preferences['local-cover-cache'], '{}');
      expect(host.preferences['play-history'], '[]');
    });

    test('sessionState 优先回报实时位置与期望播放态', () {
      final host = FakeHost()
        ..media = <String, Object?>{'position': 12.5, 'requested': false};
      final player = buildPlayer(host: host);
      player.current = song('1');
      player.queue.replace(<Track>[song('1')]);
      player.queue.select(0);
      player.state['position'] = 99.0;
      final snapshot = player.sessionState();
      expect(snapshot['position'], 12.5);
      expect(snapshot['requested'], isFalse);
      expect(snapshot['index'], 0);
      expect((snapshot['queue'] as List<Object?>).length, 1);
    });

    test('restoreSessionState 拒绝非法位置与非歌曲当前项', () {
      final player = buildPlayer();
      player.restoreSessionState(<String, Object?>{'position': -1.0, 'mode': 'shuffle'});
      expect(player.mode, 'all');
      player.queue.replace(<Track>[song('1')]);
      player.restoreSessionState(<String, Object?>{
        'position': 1.0,
        'mode': 'shuffle',
        'current': <String, Object?>{'kind': 'album', 'id': '1'},
        'queue': <Object?>[],
        'index': 0,
      });
      expect(player.mode, 'shuffle');
      expect(player.queue.size, 1);
    });

    test('restoreSessionState 在当前项为空时只恢复队列', () {
      final player = buildPlayer();
      var notified = 0;
      player.addListener(() {
        notified++;
      });
      player.restoreSessionState(<String, Object?>{
        'position': 5.0,
        'mode': 'one',
        'queue': <Object?>[song('1'), song('2')],
        'index': 1,
      });
      expect(player.queue.size, 2);
      expect(player.mode, 'one');
      expect(player.current, isEmpty);
      expect(notified, 1);
    });

    test('restoreSessionState 拒绝来源不一致的当前项', () {
      final player = buildPlayer();
      player.restoreSessionState(<String, Object?>{
        'position': 3.0,
        'current': song('1', provider: 'qq'),
        'queue': <Object?>[song('1', provider: 'qq')],
        'index': 0,
      });
      expect(player.current, isEmpty);
      expect(player.queue.isEmpty, isTrue);
    });
  });

  group('静态音质表', () {
    test('localQuality 识别母带、全景声、臻音、无损与高码率', () {
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/歌曲 [Master].flac', 'format': 'flac'}),
        'jymaster',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/歌 [Atmos].m4a', 'format': 'm4a'}),
        'sky',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/jyeffect 臻音.flac', 'format': 'flac'}),
        'jyeffect',
      );
      expect(
        MusicPlayer.localQuality(
          <String, Object?>{'path': '/m/a.flac', 'format': 'flac', 'sampleRate': 96000},
        ),
        'hires',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/a.flac', 'format': 'flac'}),
        'sq',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/a.mp3', 'format': 'mp3', 'bitrate': 320}),
        'hq',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/a.mp3', 'format': 'mp3', 'bitrate': 128}),
        'standard',
      );
    });

    test('sourceQuality 按来源与格式判定', () {
      expect(MusicPlayer.sourceQuality('netease', <String, Object?>{'url': ''}, false), '');
      expect(
        MusicPlayer.sourceQuality('siren', <String, Object?>{'url': 'https://x/a.flac'}, false),
        'sq',
      );
      expect(
        MusicPlayer.sourceQuality('siren', <String, Object?>{'url': 'https://x/a.mp3'}, false),
        'hq',
      );
      expect(
        MusicPlayer.sourceQuality('qq', <String, Object?>{'url': 'https://x/F000abc.mp3'}, false),
        'sq',
      );
      expect(
        MusicPlayer.sourceQuality('qq', <String, Object?>{'url': 'https://x/M800abc.mp3'}, false),
        'hq',
      );
      expect(
        MusicPlayer.sourceQuality('qq', <String, Object?>{'url': 'https://x/M500abc.mp3'}, false),
        'standard',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.mp3', 'br': 320000},
          false,
        ),
        'hq',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.mp3', 'br': 128000},
          false,
        ),
        'standard',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'sampleRate': 96000, 'bitDepth': 24},
          false,
        ),
        'hires',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'sampleRate': 44100, 'bitDepth': 16},
          false,
        ),
        'sq',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'level': 'jymaster'},
          false,
        ),
        'jymaster',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.mp3', 'br': 320000},
          true,
        ),
        '',
      );
    });

    test('qualityOptions 按来源给出档位', () {
      expect(
        MusicPlayer.qualityOptions('qq').map((option) => option.value).toList(),
        <String>['best', 'standard', 'exhigh', 'lossless', 'ape'],
      );
      expect(
        MusicPlayer.qualityOptions('kugou').map((option) => option.value).toList(),
        <String>['standard', 'exhigh', 'lossless', 'hires'],
      );
      expect(
        MusicPlayer.qualityOptions('siren').map((option) => option.value).toList(),
        <String>['lossless'],
      );
      expect(
        MusicPlayer.qualityOptions('netease').map((option) => option.value).toList(),
        <String>['standard', 'higher', 'exhigh', 'lossless', 'hires', 'jymaster'],
      );
    });

    test('setQuality 只接受当前来源给出的档位', () {
      final host = FakeHost();
      final player = buildPlayer(host: host);
      player.setQuality('ape');
      expect(player.quality, 'exhigh');
      player.setQuality('lossless');
      expect(player.quality, 'lossless');
      expect(host.preferences['quality'], 'lossless');
    });
  });

  group('音乐接口端口', () {
    test('默认 songs 使用位置参数数组并解析数组响应', () async {
      final api = FakeApi(
        result: MusicApiResult(
          ok: true,
          value: <Object?>[
            <String, Object?>{'id': '1'},
            'skip',
          ],
        ),
      );
      final tracks = await api.songs(<String>['1']);
      expect(api.calls.first['operation'], 'songs');
      expect((api.calls.first['arguments'] as List<Object?>).first, <String>['1']);
      expect(tracks.length, 1);
      expect(tracks.first['id'], '1');
    });

    test('songs 失败抛出异常供队列跳过批次', () async {
      final api = FakeApi(result: MusicApiResult(ok: false, error: '网络错误'));
      await expectLater(api.songs(<String>['1']), throwsA(isA<MusicApiException>()));
    });

    test('playbackSnapshot 覆盖服务端所需字段', () {
      final player = buildPlayer();
      final snapshot = player.playbackSnapshot();
      expect(
        snapshot.keys,
        containsAll(<String>[
          'current',
          'queue',
          'history',
          'index',
          'mode',
          'state',
          'loading',
          'failed',
          'trial',
          'preview',
          'status',
          'quality',
          'actualQuality',
          'alternative',
          'lyrics',
        ]),
      );
    });
  });

  // ---------------------------------------------------------------------------
  // T23-C18-player 补测：补足上面未覆盖的 Q_INVOKABLE 路由、心跳节流、会话恢复、
  // 历史/音量边界与静态音质表剩余分支。
  // RED/GREEN 未执行：本任务禁止执行 flutter test / flutter analyze / dart test。
  // ---------------------------------------------------------------------------

  group('远程命令路由', () {
    test('播放类命令经唯一连接转发为 player.* 且携带完整参数', () {
      final connection = FakeConnection();
      final player = buildPlayer(connection: connection);

      // Qt MusicPlayer.cpp:249-268：play 带上 track/preview/source/index/resume。
      player.play(
        song('1'),
        preview: true,
        resume: <String, Object?>{'position': 5.0, 'requested': true},
      );
      expect(connection.commands.last['method'], 'player.play');
      final playArguments = connection.commands.last['arguments']! as Map<String, Object?>;
      expect(playArguments['preview'], isTrue);
      expect(
        (playArguments['resume']! as Map<String, Object?>)['position'],
        5.0,
      );

      // Qt MusicPlayer.cpp:230-246：enqueue 的返回值由服务端同步后的队列镜像判定。
      expect(player.enqueue(song('1'), next: true), isFalse);

      // Qt MusicPlayer.cpp:294-299：loadQueue 转发 ids/known。
      player.loadQueue(<String>['1'], <Track>[song('1')]);
      expect(connection.commands.last['method'], 'player.loadQueue');
      expect(connection.commands.last['arguments'], <String, Object?>{
        'ids': <String>['1'],
        'known': <Map<String, Object?>>[song('1')],
      });
    });

    test('传输类命令经唯一连接转发，不回退本地播放器', () {
      final connection = FakeConnection();
      final host = FakeHost();
      final player = buildPlayer(host: host, connection: connection);

      player.toggle();
      expect(connection.commands.last['method'], 'player.toggle');

      player.setPaused(true);
      expect(connection.commands.last['method'], 'player.pause');
      expect(connection.commands.last['arguments'], <String, Object?>{'paused': true});

      player.seek(0.25);
      expect(connection.commands.last['method'], 'player.seek');
      expect(connection.commands.last['arguments'], <String, Object?>{'value': 0.25});

      player.volume(0.5);
      expect(connection.commands.last['method'], 'player.volume');
      expect(connection.commands.last['arguments'], <String, Object?>{'value': 0.5});

      player.next(1, true);
      expect(connection.commands.last['method'], 'player.next');
      expect(connection.commands.last['arguments'], <String, Object?>{
        'direction': 1,
        'ended': true,
      });

      player.remove(2);
      expect(connection.commands.last['method'], 'player.remove');
      expect(connection.commands.last['arguments'], <String, Object?>{'index': 2});

      player.clearUpcoming();
      expect(connection.commands.last['method'], 'player.clear');

      player.setMode('shuffle');
      expect(connection.commands.last['method'], 'player.mode');
      expect(connection.commands.last['arguments'], <String, Object?>{'value': 'shuffle'});

      player.setAlternative(true);
      expect(connection.commands.last['method'], 'player.alternative');
      expect(connection.commands.last['arguments'], <String, Object?>{'enabled': true});

      player.setQuality('lossless');
      expect(connection.commands.last['method'], 'player.quality');
      expect(connection.commands.last['arguments'], <String, Object?>{'value': 'lossless'});

      player.clearHistory();
      expect(connection.commands.last['method'], 'player.clearHistory');

      player.clearCaches();
      expect(connection.commands.last['method'], 'player.clearCaches');

      player.stop();
      expect(connection.commands.last['method'], 'player.stop');

      // 后台服务模式界面只保存快照，绝不自己解码（MusicPlayer.cpp:163-180）。
      expect(host.loaded, isEmpty);
      expect(host.controls, isEmpty);
    });

    test('连接报错与断开按 Qt 语义标记失败', () {
      // Qt MusicPlayer.cpp:628-641：remoteCommand 后 error() 非空即失败。
      final connection = FakeConnection()..failure = '后台播放服务不可用';
      final player = buildPlayer(connection: connection);

      player.toggle();
      expect(player.failed, isTrue);
      expect(player.status, '后台播放服务不可用');

      // Qt MusicPlayer.cpp:166-172：disconnected 提示重新打开应用。
      connection.disconnectedListeners.single();
      expect(player.failed, isTrue);
      expect(player.loading, isFalse);
      expect(player.state['playing'], isFalse);
      expect(player.status, '后台播放服务已断开，请重新打开应用');
    });

    test('selectionSerial 变化才通知 trackSelected', () {
      final connection = FakeConnection();
      final player = buildPlayer(connection: connection);
      final selected = <Map<String, Object?>>[];
      player.addTrackSelectedListener(selected.add);

      // Qt MusicPlayer.cpp:741-745：首个快照只记录 serial，不通知。
      connection.data = <String, Object?>{
        'selectionSerial': 1,
        'selectedTrack': song('7'),
      };
      connection.snapshotListeners.single();
      expect(selected.length, 1);
      expect(selected.single['id'], '7');

      connection.snapshotListeners.single();
      expect(selected.length, 1);

      connection.data = <String, Object?>{
        'selectionSerial': 2,
        'selectedTrack': song('8'),
      };
      connection.snapshotListeners.single();
      expect(selected.length, 2);
      expect(selected.last['id'], '8');
    });

    test('远端快照封面经 loadCover 解码，界面不发本地媒体指令', () async {
      final host = FakeHost()..coverResult = '封面字节';
      final connection = FakeConnection();
      final player = buildPlayer(host: host, connection: connection);

      connection.data = <String, Object?>{
        'current': song('1', extra: <String, Object?>{'cover': 'https://cdn/c.jpg'}),
      };
      connection.snapshotListeners.single();
      await settle();

      // Qt MusicPlayer.cpp:730-741：封面变化才重新解码，并按当前 cover 作废迟到结果。
      expect(host.covers, <String>['https://cdn/c.jpg']);
      expect(player.coverImage, '封面字节');
      expect(host.loaded, isEmpty);
      expect(host.controls, isEmpty);
    });
  });

  group('播放心跳补全', () {
    test('tick 按 0.1s 节流，连接模式下直接返回', () {
      // Qt MusicPlayer.cpp:471-479：连接模式不轮询，且两次轮询间隔小于 0.1s 时跳过。
      final host = FakeHost()..media = <String, Object?>{'position': 1.0};
      final player = buildPlayer(host: host);

      player.tick(0.05);
      expect(player.state['position'], 1.0);

      host.media = <String, Object?>{'position': 2.0};
      player.tick(0.1);
      expect(player.state['position'], 1.0);

      player.tick(0.2);
      expect(player.state['position'], 2.0);

      final connection = FakeConnection();
      final remoteHost = FakeHost()..media = <String, Object?>{'position': 9.0};
      final remote = buildPlayer(host: remoteHost, connection: connection);
      remote.tick(5.0, force: true);
      expect(remote.state, isEmpty);
      expect(remoteHost.controls, isEmpty);
    });

    test('本地源错误不进入恢复流程', () {
      // Qt MusicPlayer.cpp:508-517：current.provider == local 时不做自动恢复。
      final host = FakeHost()
        ..media = <String, Object?>{'error': '本地解码失败', 'recoverable': true};
      final player = buildPlayer(host: host, api: FakeApi(provider: 'local'));
      player.current = song('1', provider: 'local', extra: <String, Object?>{'url': 'file:///m/a.flac'});
      player.loading = false;

      player.tick(0.0, force: true);
      expect(player.failed, isTrue);
      expect(player.status, '本地解码失败');
    });

    test('可恢复错误先进入恢复流程而不是直接失败', () async {
      // Qt MusicPlayer.cpp:499-517：failed 为假且 recoverable 且未超 2 次时恢复。
      final host = FakeHost()..media = <String, Object?>{'error': 'boom', 'recoverable': true};
      final player = buildPlayer(host: host);
      player.current = song('1');
      player.loading = false;

      player.tick(0.0, force: true);
      expect(player.status, '正在恢复播放（1/2）…');
      expect(player.failed, isFalse);
      await settle();
    });
  });

  group('会话恢复与持久化补全', () {
    test('恢复未完成时 sessionState 用待恢复位置与请求状态', () async {
      // Qt MusicPlayer.cpp:749-758：m_resumePosition 优先于实时位置，requested 取 !m_resumePaused。
      final player = buildPlayer(api: FakeApi(result: MusicApiResult(ok: false, error: '无音源')));
      player.state['position'] = 99.0;
      player.play(song('1'), resume: <String, Object?>{'position': 30.0, 'requested': false});

      final snapshot = player.sessionState();
      expect(snapshot['position'], 30.0);
      expect(snapshot['requested'], isFalse);

      await settle();
      // Qt MusicPlayer.cpp:445-448：恢复会话期间失败不清除待恢复位置。
      expect(player.sessionState()['position'], 30.0);
    });

    test('加载中 sessionState 的 requested 为真', () async {
      // Qt MusicPlayer.cpp:754：requested = loading || live.requested || state.playing。
      final completer = Completer<MusicApiResult>();
      final api = FakeApi()
        ..handler = (String operation, List<Object?> arguments) => completer.future;
      final player = buildPlayer(api: api);

      player.play(song('1'));
      expect(player.loading, isTrue);
      expect(player.sessionState()['requested'], isTrue);

      completer.complete(MusicApiResult(ok: false, error: '取消'));
      await settle();
    });

    test('连接模式 restoreSessionState 只同步元数据，不触发本地加载', () {
      // Qt MusicPlayer.cpp:764-772：hydrate = !playbackConnection()；当前项为空时只恢复队列。
      final connection = FakeConnection();
      final host = FakeHost();
      final player = buildPlayer(host: host, connection: connection);
      var notified = 0;
      player.addListener(() => notified++);

      player.restoreSessionState(<String, Object?>{
        'position': 5.0,
        'mode': 'shuffle',
        'current': <String, Object?>{},
        'queue': <Map<String, Object?>>[song('1')],
        'index': 0,
      });

      expect(player.mode, 'shuffle');
      expect(notified, greaterThanOrEqualTo(1));
      expect(host.loaded, isEmpty);
      expect(host.metadata, isEmpty);
    });

    test('playbackSnapshot 返回快照副本，调用方改写不影响聚合根', () async {
      // Qt 返回 QJsonObject 值（写时复制），界面改返回值不会改到 MusicPlayer 内部状态。
      final player = buildPlayer();
      player.play(song('1'));
      final snapshot = player.playbackSnapshot();
      (snapshot['current']! as Map<String, Object?>)['title'] = '被改写';
      expect(player.current['title'], '曲');
      expect(player.queue.isEmpty, isTrue);
      await settle();
    });
  });

  group('历史与音量边界补全', () {
    test('历史按身份去重并剥离 wiki/description', () async {
      // Qt MusicPlayer.cpp:412-425：entry 清空 wiki/description，同身份只保留一条且封顶 200。
      final player = buildPlayer();
      player.play(song('1', extra: <String, Object?>{'wiki': 'w', 'description': 'd'}));
      await settle();
      expect(player.history.length, 1);
      expect(player.history.single['wiki'], '');
      expect(player.history.single['description'], '');

      player.play(song('1'));
      await settle();
      expect(player.history.length, 1);
      expect(player.history.single['id'], '1');
    });

    test('音量偏好串与 Qt QString::number 一致并钳制到 [0,1]', () {
      // Qt MusicPlayer.cpp:561-571：clamp 后 QString::number(volume) 落盘。
      final host = FakeHost();
      final player = MusicPlayer(
        host: host,
        api: FakeApi(),
        lyricsApiFactory: (String provider) => StubLyricsApi(provider),
        features: const MusicPlatformFeatures(applicationVolume: true),
      );

      player.volume(1.0);
      expect(host.preferences['volume'], '1');
      player.volume(0.7);
      expect(host.preferences['volume'], '0.7');
      player.volume(3.0);
      expect(host.controls.last, 'volume:1.0');
      expect(host.preferences['volume'], '1');
    });

    test('移动端目标拒绝逐应用音量（默认按 Android 平台特性）', () {
      // Qt/src/MobileTarget.h:12-16 + Qt/src/PlatformFeatures.h:7-11：
      // Android/iOS 上 ApplicationVolume 为 false，音量强制为 1.0。
      final host = FakeHost();
      final player = buildPlayer(host: host);

      player.volume(0.3);
      expect(host.controls.last, 'volume:1.0');
      expect(host.preferences['volume'], '1');
    });

    test('setQuality 切换音质时停播、置位加载态并按新档位重新准备', () async {
      // Qt MusicPlayer.cpp:146-157：记录恢复点、停播、清 actualQuality、重新 prepare(reload)。
      final host = FakeHost();
      final api = FakeApi();
      final player = buildPlayer(host: host, api: api);
      player.play(song('1'));
      await settle();
      host.controls.clear();
      api.calls.clear();

      player.setQuality('lossless');
      expect(player.quality, 'lossless');
      expect(host.preferences['quality'], 'lossless');
      expect(host.controls, contains('stop'));
      expect(player.loading, isTrue);
      expect(player.status, '正在切换音质…');

      await settle();
      final arguments = api.calls.last['arguments']! as List<Object?>;
      expect(api.calls.last['operation'], 'playback');
      expect(arguments[1], 'lossless');
    });
  });

  group('静态音质表补全', () {
    test('localQuality 的 Hi-Res 判定与无损/高品兜底', () {
      // Qt MusicPlayer.cpp:11-37。
      expect(
        MusicPlayer.localQuality(
          <String, Object?>{'path': '/m/a.flac', 'format': 'flac', 'bitrate': 1700},
        ),
        'hires',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/24bit 高解析.flac', 'format': 'flac'}),
        'hires',
      );
      expect(
        MusicPlayer.localQuality(
          <String, Object?>{'path': '/m/a.m4a', 'format': 'm4a', 'bitrate': 700},
        ),
        'sq',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/歌曲 [HQ].mp3', 'format': 'mp3'}),
        'hq',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/歌曲 320k.mp3', 'format': 'mp3'}),
        'hq',
      );
      expect(
        MusicPlayer.localQuality(<String, Object?>{'path': '/m/a.ape', 'format': 'ape'}),
        'sq',
      );
    });

    test('sourceQuality 的来源/等级/码率分支', () {
      // Qt MusicPlayer.cpp:40-102。
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'level': 'sky'},
          false,
        ),
        'sky',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'level': 'jyeffect'},
          false,
        ),
        'jyeffect',
      );
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.mp3', 'level': 'higher'},
          false,
        ),
        'hq',
      );
      expect(
        MusicPlayer.sourceQuality(
          'kugou',
          <String, Object?>{'url': 'https://x/a.mp3', 'br': 320000},
          false,
        ),
        'hq',
      );
      expect(
        MusicPlayer.sourceQuality(
          'kugou',
          <String, Object?>{'url': 'https://x/a.mp3', 'br': 128000},
          false,
        ),
        'standard',
      );
      expect(
        MusicPlayer.sourceQuality('netease', <String, Object?>{'url': 'https://x/a.mp3'}, true),
        '',
      );
      expect(
        MusicPlayer.sourceQuality('siren', <String, Object?>{'url': 'https://x/a.ape'}, false),
        'sq',
      );
      // 无损码率高不能证明 Hi-Res，必须同时具备采样率与位深。
      expect(
        MusicPlayer.sourceQuality(
          'netease',
          <String, Object?>{'url': 'https://x/a.flac', 'br': 1000000},
          false,
        ),
        'sq',
      );
      expect(
        MusicPlayer.qualityOptions('qq').first.label,
        '自动最高可用',
      );
    });
  });
}
