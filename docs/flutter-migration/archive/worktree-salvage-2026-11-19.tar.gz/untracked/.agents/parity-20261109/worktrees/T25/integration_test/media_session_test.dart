// 系统媒体会话的设备侧验收（integration_test）：只写不跑。
//
// 覆盖 T25 计划的三条 Pass 语义（锁屏/通知/耳机键/audio focus/暂停恢复、与播放器单向同步、
// 来电与焦点丢失/恢复路径），全部断言都对应 Qt 侧既有行为与行号，没有新增产品语义：
//   - 待机 vs 在播的分支顺序：Qt/src/PlatformAndroid.cpp:62-72
//   - 1000ms 上报节奏：Qt/src/Host.cpp:987-998
//   - 动作词表 resume/pause/toggle/next/prev 与 rhine.media.SEEK:<ms>：
//     Qt/src/AndroidMediaSession.h:9-10、Qt/src/NativeApplication.cpp:26-27,197-213
//   - 焦点丢失 → pause、CAN_DUCK 不暂停：Qt/android/src/rhine/music/database/RhineMediaService.java:248-254
//   - 拔耳机 → pause：同文件 :155-162
//   - 待机不结束前台服务（保活）：同文件 :101-114
//
// 本文件当前**不可执行**，两个独立原因（都是缺依赖，不是断言 RED）：
//   1. pubspec.yaml 的 dev_dependencies 没有 integration_test（SHARED-S5 已在其树登记，
//      尚未进本工作树），因此 import 'package:integration_test/integration_test.dart' 解析失败；
//   2. 移植层的 package:rhine_music_database/domain/models/media_snapshot.dart 仍不存在
//      （SHARED-S4 pending），lib/platform/media_session.dart 自身就编译不过。
// 按任务禁令，本文件未执行，也未声称通过；RED/GREEN 留待集成侧在依赖到位后记录。
//
// ARCH_BLOCKED（T21）：Dart ↔ Kotlin 的通道接线与 MainActivity 注册属 T21。本文件固定的契约面是
// 「通道名 + 三个通道方法名 + 入站事件名 + update 载荷键名」（见 [_channelName] 等常量与
// [_updatePayload]），不发明业务语义；其中 update 载荷键名是本文件对 T21 的**假设**，
// 不是既有事实，T21 若按冻结的 update(MediaSnapshot) 换一套键名，只需改 [_updatePayload]。
// DEVICE_BLOCKED：真机上前台服务存活、通知显示、锁屏进度、耳机/蓝牙按键与来电打断
// 全部需要设备执行，本环境禁 adb/安装/截图，一律 skip 并写明原因。
@TestOn('android')
library;

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:rhine_music_database/platform/media_session.dart';

/// T21 必须注册的通道名与**三个**通道方法名（ensureStarted / update / stop），逐字对应
/// android/app/src/main/kotlin/rhine/music/database/porting/MediaSessionHost.kt:130/155/192。
///
/// Kotlin 的 install(context, dispatch)（MediaSessionHost.kt:104）是原生侧 sink 注册入口，
/// 由 T21 在 MainActivity / FlutterEngine 装配时**本地调用**，不经 MethodChannel ——
/// 不要为它在通道上加方法，Qt 侧没有这种动作（Qt/src/AndroidMediaSession.h:14-25）。
///
/// 若 T21 最终采用别的命名，**只改这一处**；测试体不重复硬编码字符串。
const String _channelName = 'rhine.music.database/media_session';
const String _methodEnsureStarted = 'ensureStarted';
const String _methodUpdate = 'update';
const String _methodStop = 'stop';

/// update 门面的载荷键名：T21 契约的一部分，七项与 Qt 的参数逐个对应
/// （Qt/src/AndroidMediaSession.cpp:58-70：update(playing, positionMs, durationMs,
/// title, artist, album, coverPath)）。两处设备门用例共用这一个构造点，
/// 不允许各自硬编码；键名本身是对 T21 的假设（见文件头 ARCH_BLOCKED 段）。
Map<String, Object?> _updatePayload({
  required bool playing,
  required int positionMs,
  required int durationMs,
  required String title,
  String artist = '周杰伦',
  String album = '十一月的萧邦',
  String coverPath = '',
}) =>
    <String, Object?>{
      'playing': playing,
      'position': positionMs,
      'duration': durationMs,
      'title': title,
      'artist': artist,
      'album': album,
      'coverPath': coverPath,
    };

/// 平台 → Dart 的入站事件通道（动作串，词表见 [MediaSessionAction]）。
///
/// 故意声明为公开常量：它是留给 T21 的契约，本文件暂不订阅（订阅方是
/// MediaSessionPort 的平台实现）。若改名为私有，未被引用会被 lint 判成死代码，
/// 反而诱导后人删掉这条契约。
const String mediaActionEventChannel = 'rhine.music.database/media_session/actions';

/// 设备门用例的跳过原因：直接把两条硬阻塞写进测试报告，避免被误读成通过。
const String _deviceSkipReason =
    'ARCH_BLOCKED(T21): 通道与 MainActivity 注册未落地；'
    'DEVICE_BLOCKED: 需真机执行（本环境禁 adb/安装/截图）。';

/// 记录播放器四个出口的调用（NativeApplication.cpp:201,203,208,211），用于证明
/// 「媒体动作 → 播放器」是单向同步，不会反向写回媒体会话状态。
class _PlayerRecorder {
  final List<String> calls = <String>[];

  void setPaused(bool paused) => calls.add('setPaused:' + paused.toString());

  void stepTrack(int direction) => calls.add('stepTrack:' + direction.toString());

  void seekFraction(double fraction) => calls.add('seek:' + fraction.toStringAsFixed(3));

  void hudAction(String action) => calls.add('hudAction:' + action);

  MediaPlaybackDispatcher dispatcher() => MediaPlaybackDispatcher(
        setPaused: setPaused,
        stepTrack: stepTrack,
        seekFraction: seekFraction,
        hudAction: hudAction,
      );
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('媒体动作 → 播放器（单向同步，Qt NativeApplication.cpp:197-213）', () {
    testWidgets('四个动作词映射到四个播放器出口，seek 按 duration 折算成 0..1 比例',
        (tester) async {
      final recorder = _PlayerRecorder();
      final dispatcher = recorder.dispatcher();

      // 与 Qt 的 mediaAction 入口同一顺序：resume / pause / next / prev / SEEK。
      for (final wire in <String>['resume', 'pause', 'next', 'prev', 'rhine.media.SEEK:120000']) {
        dispatcher.dispatch(
          mediaPlaybackIntent(MediaSessionAction.parse(wire), durationMs: 240000),
        );
      }

      expect(recorder.calls, <String>[
        'setPaused:false', // resume
        'setPaused:true', // pause
        'stepTrack:1', // next（NativeApplication.cpp:203）
        'stepTrack:-1', // prev
        'seek:0.500', // 120000 / 240000，qBound(0,1) 同值
      ]);
    });

    testWidgets('duration 未知时 seek 不生效（Qt:只在 duration > 0 时 seek）', (tester) async {
      final recorder = _PlayerRecorder();
      final dispatcher = recorder.dispatcher();

      dispatcher.dispatch(
        mediaPlaybackIntent(MediaSessionAction.parse('rhine.media.SEEK:5000'), durationMs: 0),
      );

      // NativeApplication.cpp:205-210：duration <= 0 时整条 seek 被抑制，四个出口都不动。
      expect(recorder.calls, isEmpty);
    });

    testWidgets('未知动作退化成 hud.action("player:<raw>")，不猜播放器语义', (tester) async {
      final recorder = _PlayerRecorder();
      final dispatcher = recorder.dispatcher();

      dispatcher.dispatch(
        mediaPlaybackIntent(MediaSessionAction.parse('toggle'), durationMs: 240000),
      );

      // toggle 在 Qt 侧由 MusicPlayer::toggle 处理（MusicPlayer.cpp:520-536），
      // 不等于 setPaused(!playing)；本层只转交，不臆断。
      expect(recorder.calls, <String>['hudAction:player:toggle']);
    });
  });

  group('上报节奏与待机分支（Host.cpp:987-998 / PlatformAndroid.cpp:62-72）', () {
    testWidgets('真实时钟下 1000ms 内重复上报只放行一次', (tester) async {
      // 这里刻意不注入 clock：验证的正是 MediaSessionThrottle 默认走
      // DateTime.now().millisecondsSinceEpoch（Qt 的 currentMSecsSinceEpoch）时的行为。
      final throttle = MediaSessionThrottle();
      expect(throttle.due(), isTrue, reason: '初始 lastMediaUpdate=0，首帧必到点');

      // 立即连调 20 次，全部落在同一个 1000ms 窗口内（真实时钟，最坏 20 次调用远小于 1s）。
      var allowed = 0;
      for (var i = 0; i < 20; i++) {
        if (throttle.due()) {
          allowed++;
        }
      }
      expect(allowed, 0, reason: '同一窗口内不得重复上报（Host.cpp:993 的 >= 1000 守卫）');
    });

    testWidgets('待机判定与在播判定互斥，且待机不依赖时长精度', (tester) async {
      expect(mediaSessionStandby(title: '', durationMs: 240000), isTrue);
      expect(mediaSessionStandby(title: '夜曲', durationMs: 0), isTrue);
      expect(mediaSessionStandby(title: '夜曲', durationMs: 240000), isFalse);

      // PlatformAndroid.cpp:64 只用 isEmpty，不 trim。
      expect(mediaSessionStandby(title: '  ', durationMs: 240000), isFalse);
    });
  });

  // 以下为真机验收用例。契约（通道/方法/事件）已固定在上方常量里，
  // 阻塞项解除后应直接可执行，不需要重写测试体。
  group('设备门：系统媒体控件', () {
    testWidgets('三个门面经通道下发（通道冒烟，不含单向性断言）', (tester) async {
      final channel = const MethodChannel(_channelName);

      // 本用例唯一的失败方式：通道未注册 / 方法名不符时 invokeMethod 抛
      // MissingPluginException（以及平台侧 startForeground 失败时的 PlatformException）。
      final Object? started = await channel.invokeMethod<void>(_methodEnsureStarted);
      final Object? updated = await channel.invokeMethod<void>(
        _methodUpdate,
        _updatePayload(playing: true, positionMs: 1000, durationMs: 240000, title: '夜曲'),
      );
      final Object? stopped = await channel.invokeMethod<void>(_methodStop);

      expect(
        <Object?>[started, updated, stopped],
        everyElement(isNull),
        reason: '三个 void 门面均正常返回，未抛 PlatformException',
      );

      // 这里刻意**不**断言「上报路径不回调播放器」：本树没有可注入的 MediaSessionPort
      // 实现，任何 recorder 都接不进真实链路，那种断言必然恒真、不可能失败。
      // 单向性（NativeApplication.cpp:197-213 只有入站动作才碰播放器）待 T21 通道 +
      // T23 播放器落地后在此追加。
    }, skip: _deviceSkipReason);

    testWidgets('stop 门面在设备上正常返回（服务存活需设备侧观测）', (tester) async {
      final channel = const MethodChannel(_channelName);
      await channel.invokeMethod<void>(_methodEnsureStarted);
      await channel.invokeMethod<void>(
        _methodUpdate,
        _updatePayload(playing: true, positionMs: 40000, durationMs: 240000, title: '夜曲'),
      );

      // 待机分支：PlatformAndroid.cpp:64 命中 title.isEmpty() || duration<=0 时调
      // AndroidMediaSession::stop()，落到 Java 的 stop()（RhineMediaService.java:106-114）：
      // playing=false、positionMs=0、releaseFocus()、publish()，**不调用 stopSelf()**，
      // 前台服务按 :101-105 的注释继续存活（保住进程不被回收）。
      final Object? stopped = await channel.invokeMethod<void>(_methodStop);

      // 本层只能断言通道确实成功返回（void 方法回 null）；「服务仍在」必须由设备侧
      // dumpsys/通知栏观测，不在此伪造断言。
      expect(stopped, isNull, reason: 'stop 门面正常返回，未抛 PlatformException');
    }, skip: _deviceSkipReason);
  });
}
