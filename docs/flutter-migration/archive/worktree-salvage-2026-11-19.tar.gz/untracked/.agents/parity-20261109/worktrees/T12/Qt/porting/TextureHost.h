#pragma once

#include <QByteArray>
#include <QObject>
#include <QSize>
#include <QString>
#include <QUrl>

class QOpenGLContext;
class QQmlEngine;
class QQuickItem;
class QQuickRenderControl;
class QQuickWindow;
class QRhi;
class QRhiRenderPassDescriptor;
class QRhiTexture;
class QRhiTextureRenderTarget;
struct ANativeWindow;

/**
 * Qt 离屏纹理宿主（port-local，Android 专用）。
 *
 * 链路：QQuickRenderControl 把 QML 场景渲染到离屏 QRhiTexture，然后在同一个 EGL
 * 上下文里用自带的 GLES3 全屏 quad 把该纹理画到 SurfaceTexture 的生产端
 * （ANativeWindow），最后 eglSwapBuffers 交给 Flutter 的 Texture 组件合成。
 *
 * 与 Qt/src/render/SceneLayerHost 的差异：那边共享宿主窗口已有的 QRhi；这边是
 * 独立进程外宿主，必须自己建 QOpenGLContext（GLES3）并把 EGL 句柄借给 EGL 发布
 * 路径，因此只走 OpenGL 后端。Vulkan 不可用的退出条件见 TextureHost.cpp 顶部注释。
 *
 * 线程：所有方法必须在同一个线程调用（Kotlin 侧固定 HandlerThread）。Qt Quick 的
 * 离屏渲染不要求 GUI 主线程，但 QQmlEngine/QQuickWindow/QRhi 都要在同一线程内创建
 * 与销毁。
 */
class TextureHost : public QObject {
    Q_OBJECT

  public:
    /// 宿主生命周期。Ready 之后才允许 renderFrame()。
    enum class Phase { Idle, Ready, Released, Failed };

    /// 一次调用后回给 Kotlin/Dart 的快照；字段与冻结契约逐字对应。
    struct Report {
        /// ready / nativeUnavailable / archBlocked / deviceBlocked / failed / released
        QString status;
        /// opengl / none
        QString backend;
        QString lastError;
        bool rendered = false;
        quint64 frameSequence = 0;
        bool firstFrameRendered = false;
        int width = 0;
        int height = 0;
        int rotationQuarterTurns = 0;
        quint64 publishTimestampNanos = 0;
        bool surfaceAttached = false;

        /// 单行 JSON（字段名与 MethodChannel 契约一致）。
        QByteArray toJson() const;
    };

    /// engine 为 null 时内部自建（宿主线程上创建）；外部传入时生命周期由调用方负责。
    explicit TextureHost(QQmlEngine *engine, QObject *parent = nullptr);
    ~TextureHost() override;

    /// 绑定 Surface 并建立全部图形资源。window 是 fromSurface 取得的生产端窗口，
    /// 所有权归调用方（本类只借用，不会 release）。
    bool start(ANativeWindow *window, int width, int height, qreal devicePixelRatio);

    /// 重建离屏目标（换尺寸必须重建，QRhi 的纹理目标不可原地 resize）。
    void resize(int width, int height, qreal devicePixelRatio);

    /// 设置四分之一圈旋转（0..3）。像素旋转在本类的 blit 阶段完成，目标尺寸不变。
    bool setRotation(int quarterTurns);

    /// 渲染并发布一帧；frameTimeNanos 仅作���示（帧时间由 native 的单调钟给出）。
    Report renderFrame(qint64 frameTimeNanos);

    /// 不渲染，只取当前快照。
    Report report() const;

    /// 释放图形资源（保留 QML 场景，允许再次 start() 绑新 Surface）。
    void release();

    /// 设置根 QML；空 URL 时用内置最小探针场景（不冒充真实 HUD 像素）。
    void setRootUrl(const QUrl &url);

    /// 输入转发到离屏窗口。phase：0=down 1=move 2=up；buttons 用 Android 位掩码。
    bool sendPointer(qreal x, qreal y, int phase, int buttons);

    /// 按键转发。key 是 Android keyCode，映射不到时返回 false 并记 lastError。
    bool sendKey(int key, bool down, bool repeat);

    bool isStarted() const;

  private:
    /// 建 EGLDisplay/EGLConfig/EGLContext/EGLSurface 与 QOpenGLContext（同一套句柄）。
    bool initGraphics(ANativeWindow *window);
    /// 建离屏纹理 + render target + QQuickRenderTarget，并交给 QQuickWindow。
    bool rebuildTarget(int width, int height);
    /// 把 QRhiTexture 画到 EGL 窗口表面并 swap（同一 EGL 上下文，不新建）。
    bool publishTexture();
    /// 把 EGL 窗口表面设为当前（Qt 渲染完再切，避免和 QRhi 的 fallback surface 抢）。
    bool makeBlitCurrent();
    /// 交还当前上下文，让 QRhi 下一帧自己 makeCurrent。
    void doneBlitCurrent();
    /// 编译 blit 用的 GLES3 程序与全屏 quad。
    bool initBlitPipeline();
    void destroyGraphics();
    void destroyBlitPipeline();
    /// 载入 QML 场景（内置探针或 rootUrl）。
    bool loadScene();
    /// 统一失败出口：记状态 + lastError，方便宿主一次性看到根因。
    void fail(const QString &status, const QString &message);
    quint64 monotonicNanos() const;

    QQmlEngine *m_engine = nullptr;
    bool m_ownsEngine = false;
    QQuickRenderControl *m_control = nullptr;
    QQuickWindow *m_window = nullptr;
    QQuickItem *m_rootItem = nullptr;
    QOpenGLContext *m_glContext = nullptr;

    // EGL 句柄用 void* 保存，避免把 EGL 头文件带进本头。
    void *m_eglDisplay = nullptr;
    void *m_eglConfig = nullptr;
    void *m_eglContext = nullptr;
    void *m_eglSurface = nullptr;
    ANativeWindow *m_nativeWindow = nullptr;

    QRhi *m_rhi = nullptr;
    QRhiTexture *m_texture = nullptr;
    QRhiTextureRenderTarget *m_renderTarget = nullptr;
    QRhiRenderPassDescriptor *m_renderPass = nullptr;

    unsigned int m_blitProgram = 0;
    unsigned int m_blitVbo = 0;
    unsigned int m_blitVao = 0;
    int m_blitUvMatrixLocation = -1;
    int m_blitTextureLocation = -1;
    // GL 侧拷贝：RHI 纹理 -> 本类纹理 -> 窗口表面。尺寸变化时重建。
    unsigned int m_copyTexture = 0;
    unsigned int m_copyFbo = 0;
    QSize m_copySize;

    QUrl m_rootUrl;
    Phase m_phase = Phase::Idle;
    QString m_status = QStringLiteral("failed");
    QString m_backend = QStringLiteral("none");
    QString m_lastStatusError;
    int m_width = 0;
    int m_height = 0;
    qreal m_dpr = 1.0;
    int m_rotation = 0;
    quint64 m_frameSequence = 0;
    bool m_firstFrame = false;
    quint64 m_publishTimestampNanos = 0;
};
