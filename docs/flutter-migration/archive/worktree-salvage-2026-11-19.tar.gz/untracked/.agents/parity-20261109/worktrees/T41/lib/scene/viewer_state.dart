/// Faithful Dart port of the Qt 3D assembly viewer — the camera/pose state
/// machine behind the cassette viewer overlay.
///
/// Source of truth: `Qt/src/NativeViewer.h` (68 lines) and
/// `Qt/src/NativeViewer.cpp` (355 lines) at commit
/// 8ed3067b0812eb2612f7841ec127a6e8ca93231b. The maths are reused unchanged from
/// `lib/scene/scene_math.dart` (Vec3/Mat4/Spring) and the frame envelope from
/// `lib/scene/scene_frame.dart`.
///
/// Conventions copied verbatim from the C++:
///  * Every scalar is a double; the six assembly parts are an ordered table
///    (NativeViewer.cpp:9-11) and the template pass walks it outermost.
///  * The pose is spherical — {radius, phi, theta} with
///    phi = acos(clamp(y / r, -1, 1)) and theta = atan2(x, z)
///    (NativeViewer.cpp:26-36), so vector() rebuilds
///    (sin(phi)*r*sin(theta), cos(phi)*r, sin(phi)*r*cos(theta)).
///  * Requested pose and actual pose are separate: m_goal/m_target are what the
///    input writes, m_pose/m_focus/m_eye are what the camera uses.
///  * Two different lerps are in play and they are not interchangeable:
///    Vec3::lerp — from + (to - from) * amount (SceneMath.cpp:30-32) — for the
///    focus point, and the file-local (1 - amount) * from + amount * to
///    (NativeViewer.cpp:12-14) for the log-radius and phi of interpolate; see
///    _lerp below for why the distinction is observable.
///  * m_last == 0 is the "first frame" sentinel: the step is 1/60 instead of
///    time - m_last (NativeViewer.cpp:225) and is capped at 0.05.
///  * A closing viewer keeps its pose until m_closeAt; only then is the template
///    released (NativeViewer.cpp:214-221).
///
/// I/O is injected, never hard-wired: [NativeViewer.stateLoader] answers with the
/// text of <root>/archive-assembly.json and [NativeViewer.meshSource] answers
/// with an already parsed meshes array. [readStateFromDisk] is the only dart:io
/// call in this file, which keeps the state machine testable without a file
/// system and keeps this library free of any flutter import.
///
/// Wire notes that are easy to get wrong:
///  * viewerState.exploded is the *string* "true"/"false", not a bool
///    (NativeViewer.cpp:352).
///  * viewerState.stats is a *compact JSON string*, not an object
///    (NativeViewer.cpp:336-353); [SceneFrame.toJsonText] reproduces
///    QJsonDocument's sorted-key / integral-double rendering.
///  * The viewer pass rewrites view, projection, eye, near, far, fogNear, fogFar,
///    draws, actorTemplate, actors and viewerState — nothing else.
///
/// STATUS: written, deliberately NOT executed. dart analyze, dart format,
/// dart test, flutter test, flutter analyze and pub get are forbidden for this
/// atom, so RED and GREEN are both NOT RUN.
library;

import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'scene_frame.dart';
import 'scene_math.dart';

// ---------------------------------------------------------------------------
// Assembly depth table — NativeViewer.cpp:9-11.
// ---------------------------------------------------------------------------

/// One row of the assembly template table (NativeViewer.cpp:9-11): the GLB
/// assemblyPart name and the Z offset applied per unit of explode spread.
///
/// The list order *is* the template order — fasteners first, carrier last
/// (NativeViewer.cpp:297).
class ViewerPart {
  const ViewerPart(this.name, this.depth);

  /// assemblyPart value in archive-assembly.json.
  final String name;

  /// Exploded-view Z offset, added to every mesh of this part
  /// (NativeViewer.cpp:317, position.z += depth * m_spread.value).
  final double depth;

  @override
  String toString() => 'ViewerPart($name : $depth)';

  @override
  bool operator ==(Object other) =>
      other is ViewerPart && other.name == name && other.depth == depth;

  @override
  int get hashCode => Object.hash(name, depth);
}

/// The six assembly parts in template order — NativeViewer.cpp:9-11.
const List<ViewerPart> kViewerParts = <ViewerPart>[
  ViewerPart('fasteners', 2.75),
  ViewerPart('cover', 1.85),
  ViewerPart('optical-lenses', 0.75),
  ViewerPart('optical-core', -0.15),
  ViewerPart('substrate', -1.1),
  ViewerPart('carrier', -2.05),
];

// ---------------------------------------------------------------------------
// Constants. Every value cites the Qt line it was taken from.
// ---------------------------------------------------------------------------

/// The home pose {7.2, 3.8, 12}. Qt spells it three times: the m_eye field
/// initialiser (NativeViewer.h:55), reset() (NativeViewer.cpp:79) and the
/// coverFront() distance (NativeViewer.cpp:101).
const Vec3 kViewerHome = Vec3(7.2, 3.8, 12);

/// Opening fade before transition flips to open — NativeViewer.cpp:47.
const double kViewerOpenDelay = 0.38;

/// Closing fade before the viewer releases its template — NativeViewer.cpp:116.
const double kViewerCloseDelay = 0.22;

/// Lower orbit radius bound — NativeViewer.cpp:145, 185.
const double kViewerMinRadius = 5.0;

/// Upper orbit radius bound — NativeViewer.cpp:145, 185.
const double kViewerMaxRadius = 28.0;

/// Polar epsilon, used as the lower bound and as the upper-bound margin
/// (0.000001) — NativeViewer.cpp:178, 242.
const double kViewerMinPolar = 0.000001;

/// Pointer drag gain (0.65) — NativeViewer.cpp:176-177.
const double kViewerDragGain = 0.65;

/// Wheel zoom base (0.95) — NativeViewer.cpp:184.
const double kViewerWheelBase = 0.95;

/// Wheel zoom rate (0.7) — NativeViewer.cpp:184.
const double kViewerWheelRate = 0.7;

/// Wheel delta scale (0.01) — NativeViewer.cpp:184.
const double kViewerWheelStep = 0.01;

/// Pan focal-plane fov in degrees (34.0) — NativeViewer.cpp:198.
///
/// The same literal as [kViewerFov]; it stays a separate constant because Qt
/// spells it twice, once for the projection (NativeViewer.cpp:287) and once for
/// the pan span (:198).
const double kViewerPanFov = 34.0;

/// Reset animation duration — NativeViewer.cpp:251.
const double kViewerResetSeconds = 0.56;

/// Focus-target clamp radius (|target| <= 5) — NativeViewer.cpp:163-165,
/// 201-203.
const double kViewerFocusLimit = 5.0;

/// Arrow-key orbit step as a fraction of the requested radius (0.025)
/// — NativeViewer.cpp:152.
const double kViewerKeyStep = 0.025;

/// Radius multiplier of the +/- keys (1.12) — NativeViewer.cpp:145.
const double kViewerRadiusKey = 1.12;

/// Stage width before the first [NativeViewer.resize] — NativeViewer.h:43.
const double kViewerDefaultWidth = 1920;

/// Stage height before the first [NativeViewer.resize] — NativeViewer.h:44.
const double kViewerDefaultHeight = 1080;

/// File the viewer reads its meshes array from, appended to the root
/// (NativeViewer.cpp:56, m_root + "/archive-assembly.json").
const String kViewerAssemblyFile = '/archive-assembly.json';

/// Clip planes the viewer pass publishes — NativeViewer.cpp:283-284.
const double kViewerProjectionNear = 0.3;
const double kViewerProjectionFar = 120.0;

// ---------------------------------------------------------------------------
// Local helpers.
// ---------------------------------------------------------------------------

/// The file-local lerp of NativeViewer.cpp:12-14:
/// (1 - amount) * from + amount * to.
///
/// Deliberately *not* [lerpDouble] (from + (to - from) * amount,
/// SceneMath.cpp:30-32). The two agree for finite inputs up to the last bit,
/// but only this form degrades like Qt when from is infinite: a zero radius
/// gives log(0) == -inf, and (1 - a) * -inf + a * to stays -inf, so exp()
/// collapses the radius to 0, whereas from + (to - from) * amount evaluates
/// -inf + inf and yields NaN.
double _lerp(double from, double to, double amount) => (1 - amount) * from + amount * to;

/// std::clamp(value, minimum, maximum).
double _clamp(double value, double minimum, double maximum) =>
    value < minimum ? minimum : (value > maximum ? maximum : value);

/// QJsonValue::toInt() — numbers truncate toward zero, every other type answers
/// 0. Used for part["side"].toInt() (NativeViewer.cpp:314).
int _asInt(Object? value) => value is num ? value.toInt() : 0;

/// QJsonValue::toObject() — anything that is not an object reads as an empty
/// one, which makes its assemblyPart compare unequal and the mesh get skipped
/// (NativeViewer.cpp:301-304).
Map<String, Object?> _asObject(Object? value) =>
    value is Map<Object?, Object?> ? value.cast<String, Object?>() : const <String, Object?>{};

// ---------------------------------------------------------------------------
// Injected I/O.
// ---------------------------------------------------------------------------

/// Reads the text of archive-assembly.json.
///
/// Returning null means "cannot open", the branch NativeViewer.cpp:57 takes when
/// QFile::open fails; the caller then simply leaves the mesh list empty.
typedef StateLoader = String? Function(String path);

/// Supplies the parsed meshes array without a file system
/// (QJsonDocument::fromJson(...).object()["meshes"].toArray(),
/// NativeViewer.cpp:58).
typedef MeshSource = List<Object?> Function();

/// Stand-in for NativeCards::expand (NativeViewer.cpp:335,
/// NativeCards.cpp:242), which is outside atom D.
///
/// It is called exactly where Qt calls the card expander — after draws,
/// actorTemplate and actors are on the frame — and receives the 20-double actor
/// state ([NativeViewer.actorStateBytes]) plus the draw buffers the expander
/// fills. Without one the viewer publishes draws: [] and the caller expands the
/// template itself.
typedef ViewerCardExpander = void Function(
  SceneFrame frame,
  Uint8List actorState,
  SceneDrawBuffers buffers,
);

/// The dart:io [StateLoader] — the only disk access in this file.
///
/// Qt opens the file read-only and treats any failure as "no meshes"
/// (NativeViewer.cpp:56-60), so a missing file, a read error and undecodable
/// bytes all answer null here.
String? readStateFromDisk(String path) {
  final File file = File(path);
  try {
    if (!file.existsSync()) {
      return null;
    }
    return utf8.decode(file.readAsBytesSync(), allowMalformed: true);
  } on FileSystemException {
    return null;
  }
}

/// A [StateLoader] that answers the same document text for every path — the
/// asset-bundle / test stand-in for [readStateFromDisk].
StateLoader stateLoaderFromText(String text) => (String _) => text;

/// A [StateLoader] that never finds a file, used when a [MeshSource] is injected.
String? _missingFile(String _) => null;

// ---------------------------------------------------------------------------
// Camera pose — NativeViewer.h:28-32.
// ---------------------------------------------------------------------------

/// NativeViewer.h:28-32 — the orbit pose in spherical coordinates.
///
/// Mutable because the C++ struct is: interpolate writes m_pose.radius,
/// m_pose.phi and m_pose.theta field by field (NativeViewer.cpp:240-245), while
/// key/pointer write the same three fields of m_goal.
class ViewerSpherical {
  /// Defaults are the C++ member initialisers (radius = 1, phi = theta = 0,
  /// NativeViewer.h:29-31).
  ViewerSpherical({this.radius = 1, this.phi = 0, this.theta = 0});

  /// Distance from the focus point.
  double radius;

  /// Polar angle, 0 at +Y.
  double phi;

  /// Azimuth, atan2(x, z) convention.
  double theta;

  /// Value copy — the C++ struct is passed by value everywhere (see
  /// NativeViewer.cpp:240, interpolate(Spherical from, Spherical to, ...)), so
  /// the port must never alias.
  ViewerSpherical copy() => ViewerSpherical(radius: radius, phi: phi, theta: theta);

  @override
  bool operator ==(Object other) =>
      other is ViewerSpherical &&
      other.radius == radius &&
      other.phi == phi &&
      other.theta == theta;

  @override
  int get hashCode => Object.hash(radius, phi, theta);

  @override
  String toString() => 'ViewerSpherical($radius, $phi, $theta)';
}

// ---------------------------------------------------------------------------
// NativeViewer.
// ---------------------------------------------------------------------------

/// Port of NativeViewer (NativeViewer.h:9-68): the assembly viewer's open/close
/// envelope, orbit camera, reset animation, explode spread and surface clarity
/// springs.
///
/// One instance owns one viewer overlay. The HUD drives it with [open],
/// [action], [key], [pointer], [resize], [reduced] and [update], reads it back
/// through [frame], and mirrors Qt's memory-pressure hook with [trimMemory].
class NativeViewer {
  /// NativeViewer.cpp:16-19 — the constructor only seeds the pose from the
  /// default eye; nothing is loaded until [open].
  ///
  /// [root] is the asset directory Qt prefixes with /archive-assembly.json.
  /// [stateLoader] defaults to [readStateFromDisk]; [meshSource] bypasses the
  /// file system entirely.
  NativeViewer(this.root, {StateLoader? stateLoader, this.meshSource})
      : stateLoader = stateLoader ?? readStateFromDisk {
    _pose = _spherical(_eye);
    _goal = _pose.copy();
  }

  /// A viewer fed with an already parsed archive-assembly.json document.
  ///
  /// [meshes] is the meshes array itself. It is snapshotted into a [MeshSource],
  /// so a later [open] after [trimMemory] reloads the same list exactly like Qt
  /// re-reads the file (NativeViewer.cpp:55-60).
  factory NativeViewer.fromJson({required List<Object?> meshes, String root = ''}) =>
      NativeViewer(
        root,
        meshSource: () => List<Object?>.from(meshes),
        stateLoader: _missingFile,
      );

  /// Asset directory — NativeViewer.h:33 (m_root).
  final String root;

  /// Injected reader for archive-assembly.json (NativeViewer.cpp:56-59).
  final StateLoader stateLoader;

  /// Injected meshes supplier; when non-null no file is ever opened.
  final MeshSource? meshSource;

  /// The parsed meshes array. Kept between frames but dropped when the viewer
  /// closes (NativeViewer.cpp:218, 270-274).
  final List<Object?> _meshes = <Object?>[];

  // --- NativeViewer.h:33-63, same names without the m_ prefix. -------------
  bool _open = false;
  bool _closing = false;
  bool _reduced = false;
  bool _dragging = false;
  bool _resetting = false;
  bool _ready = false;
  double _previousX = 0;
  double _previousY = 0;
  double _width = kViewerDefaultWidth;
  double _height = kViewerDefaultHeight;
  double _last = 0;
  double _time = 0;
  double _pendingUntil = 0;
  double _closeAt = 0;
  double _resetElapsed = 0;
  double _theme = 0;
  Spring _clarity = Spring(1, 0);
  Spring _spread = Spring();
  double _targetClarity = 1;
  double _targetSpread = 0;
  Vec3 _eye = kViewerHome;
  Vec3 _focus = Vec3.zero;
  Vec3 _target = Vec3.zero;
  Vec3 _resetFocus = Vec3.zero;
  ViewerSpherical _pose = ViewerSpherical();
  ViewerSpherical _goal = ViewerSpherical();
  ViewerSpherical _resetFrom = ViewerSpherical();
  String _transition = 'closed';
  String _surface = 'clear';

  // --- Read-only introspection. Qt exposes none of this; the port needs it
  // --- for the HUD bridge and for parity tests.

  /// NativeViewer.cpp:20-22 — isOpen().
  bool get isOpen => _open;

  /// NativeViewer.cpp:23-25 — pending(): open, but still fading in or out.
  bool get pending => _open && (_closing || _time < _pendingUntil);

  /// NativeViewer.cpp:45, 115, 219, 223 — closed / opening / open / closing.
  String get transition => _transition;

  /// NativeViewer.cpp:52, 124 — clear or frosted.
  String get surface => _surface;

  /// The clarity spring value published as stats.clarity (NativeViewer.cpp:337).
  double get clarity => _clarity.value;

  /// The explode spring value published as stats.spread (NativeViewer.cpp:339).
  double get spread => _spread.value;

  /// The current camera eye (NativeViewer.cpp:268).
  Vec3 get eye => _eye;

  /// Stage width from [resize] (NativeViewer.h:43).
  double get width => _width;

  /// Stage height from [resize] (NativeViewer.h:44).
  double get height => _height;

  /// NativeViewer.cpp:61 — m_ready, i.e. the mesh template is loaded.
  bool get ready => _ready;

  // -------------------------------------------------------------------------
  // Spherical <-> cartesian — NativeViewer.cpp:26-36.
  // -------------------------------------------------------------------------

  /// NativeViewer.cpp:26-32 — spherical(Vector).
  ///
  /// A zero-length vector answers {0, 0, 0} rather than the struct's radius = 1
  /// default, and y / radius is clamped so floating point drift cannot push
  /// acos out of its domain.
  static ViewerSpherical _spherical(Vec3 value) {
    final double radius = value.length;
    if (radius == 0) {
      return ViewerSpherical(radius: 0, phi: 0, theta: 0);
    }
    return ViewerSpherical(
      radius: radius,
      phi: math.acos(_clamp(value.y / radius, -1.0, 1.0)),
      theta: math.atan2(value.x, value.z),
    );
  }

  /// NativeViewer.cpp:33-36 — vector(Spherical).
  static Vec3 _vector(ViewerSpherical value) {
    final double sine = math.sin(value.phi) * value.radius;
    return Vec3(
      sine * math.sin(value.theta),
      math.cos(value.phi) * value.radius,
      sine * math.cos(value.theta),
    );
  }

  // -------------------------------------------------------------------------
  // Envelope — NativeViewer.cpp:39-76, 270-274.
  // -------------------------------------------------------------------------

  /// NativeViewer.cpp:39-64 — open(time).
  ///
  /// Re-opening an already open viewer is a no-op. Both springs and the target
  /// values are reset before the pose reset, the pending window is 0.38 s (0
  /// when reduced motion is on), the mesh template is loaded lazily, and
  /// update(0, theme) runs so the eye is rebuilt from the freshly reset pose;
  /// m_time is then restored to the caller's time (NativeViewer.cpp:62-63).
  void open(double time) {
    if (_open) {
      return;
    }
    _open = true;
    _closing = false;
    _transition = 'opening';
    _time = time;
    _pendingUntil = _reduced ? time : time + kViewerOpenDelay;
    _spread = Spring();
    _targetSpread = 0;
    _clarity = Spring(1, 0);
    _targetClarity = 1;
    _surface = 'clear';
    _last = 0;
    _reset(false);
    if (_meshes.isEmpty) {
      final List<Object?>? loaded = _loadMeshes();
      if (loaded != null) {
        _meshes
          ..clear()
          ..addAll(loaded);
      }
    }
    _ready = _meshes.isNotEmpty;
    update(0, _theme);
    _time = time;
  }

  /// NativeViewer.cpp:55-61 — read the meshes array unless a [MeshSource] is
  /// injected.
  List<Object?>? _loadMeshes() {
    final MeshSource? source = meshSource;
    if (source != null) {
      return source();
    }
    final String? text = stateLoader('$root$kViewerAssemblyFile');
    return text == null ? null : _meshesFromDocument(text);
  }

  /// QJsonDocument::fromJson(text).object()["meshes"].toArray()
  /// (NativeViewer.cpp:58). Malformed JSON is not an error in Qt — the document
  /// is simply empty, so the mesh list stays empty too.
  static List<Object?> _meshesFromDocument(String text) {
    Object? decoded;
    try {
      decoded = jsonDecode(text);
    } on FormatException {
      return <Object?>[];
    }
    if (decoded is! Map<Object?, Object?>) {
      return <Object?>[];
    }
    final Object? meshes = decoded['meshes'];
    return meshes is List<Object?> ? meshes : <Object?>[];
  }

  /// NativeViewer.cpp:65-68 — resize(width, height). No clamping and no
  /// re-projection: the next [frame] picks the new size up.
  void resize(double width, double height) {
    _width = width;
    _height = height;
  }

  /// NativeViewer.cpp:69-76 — reduced(value).
  ///
  /// Turning reduced motion on also closes the pending window immediately and
  /// snaps both springs onto their targets, so the next [update] publishes the
  /// final values with zero velocity.
  void reduced(bool value) {
    _reduced = value;
    if (value) {
      _pendingUntil = _time;
      _clarity = Spring(_targetClarity, 0);
      _spread = Spring(_targetSpread, 0);
    }
  }

  /// NativeViewer.cpp:270-274 — trimMemory(): only a closed viewer drops its
  /// template, so a memory-pressure callback during playback is harmless.
  void trimMemory() {
    if (!_open) {
      _meshes.clear();
    }
  }

  // -------------------------------------------------------------------------
  // Pose commands — NativeViewer.cpp:77-205.
  // -------------------------------------------------------------------------

  /// NativeViewer.cpp:77-91 — reset(animated).
  ///
  /// The requested pose always returns home ({7.2, 3.8, 12}) and the focus to
  /// the origin. An animated reset on a non-reduced viewer snapshots the current
  /// pose/focus for [update] to play out over 0.56 s; otherwise it applies the
  /// pose immediately and rebuilds the eye.
  void _reset(bool animated) {
    _target = Vec3.zero;
    _goal = _spherical(kViewerHome);
    if (animated && !_reduced) {
      _resetFrom = _pose.copy();
      _resetFocus = _focus;
      _resetElapsed = 0;
      _resetting = true;
    } else {
      _pose = _goal.copy();
      _focus = _target;
      _eye = _vector(_pose) + _focus;
      _resetting = false;
    }
  }

  /// NativeViewer.cpp:92-98 — interrupt(): cancelling a reset freezes the
  /// requested pose at the pose that is on screen, so nothing snaps back.
  void _interrupt() {
    if (_resetting) {
      _resetting = false;
      _goal = _pose.copy();
      _target = _focus;
    }
  }

  /// NativeViewer.cpp:99-107 — coverFront(front): snap the camera straight onto
  /// the cover plane, [front] selecting the +Z or -Z side at the home distance.
  void coverFront(bool front) {
    _interrupt();
    final double distance = kViewerHome.length;
    _goal = _spherical(Vec3(0, 0, front ? distance : -distance));
    _target = Vec3.zero;
    _pose = _goal.copy();
    _focus = Vec3.zero;
    _eye = _vector(_pose);
  }

  /// NativeViewer.cpp:108-130 — action(action, time).
  ///
  /// close is handled before the readiness guard (a viewer that never loaded can
  /// still be dismissed); every other action needs the template and is ignored
  /// while closing.
  void action(String action, double time) {
    if (!_open || _closing) {
      return;
    }
    if (action == 'close') {
      _closing = true;
      _dragging = false;
      _transition = 'closing';
      _closeAt = _reduced ? time : time + kViewerCloseDelay;
      return;
    }
    if (!_ready) {
      return;
    }
    if (action == 'clear' || action == 'frosted') {
      _targetClarity = action == 'clear' ? 1 : 0;
      _surface = action;
    } else if (action == 'explode' || action == 'assemble') {
      _targetSpread = action == 'explode' ? 1 : 0;
    } else if (action == 'reset') {
      _reset(true);
    }
  }

  /// NativeViewer.cpp:131-166 — key(key, time).
  ///
  /// Escape closes even before the template is ready; Home resets; +, = and -
  /// scale the requested radius inside [5, 28]; the arrows move the focus point
  /// along the camera basis by 0.025 * radius and clamp it to a sphere of
  /// radius 5. An unknown key still interrupts a running reset — that is Qt's
  /// order (NativeViewer.cpp:143) and it is preserved.
  void key(String key, double time) {
    if (key == 'Escape') {
      action('close', time);
      return;
    }
    if (!_ready || _closing) {
      return;
    }
    if (key == 'Home') {
      _reset(true);
      return;
    }
    _interrupt();
    if (key == '+' || key == '=' || key == '-') {
      final double scale = key == '-' ? kViewerRadiusKey : 1 / kViewerRadiusKey;
      _goal.radius = _clamp(_goal.radius * scale, kViewerMinRadius, kViewerMaxRadius);
      return;
    }
    final Mat4 camera = Mat4.camera(_eye, _focus);
    final Vec3 right = Vec3(camera.values[0], camera.values[1], camera.values[2]);
    final Vec3 up = Vec3(camera.values[4], camera.values[5], camera.values[6]);
    Vec3 delta = Vec3.zero;
    final double step = _goal.radius * kViewerKeyStep;
    if (key == 'ArrowLeft') {
      delta = right * -step;
    } else if (key == 'ArrowRight') {
      delta = right * step;
    } else if (key == 'ArrowUp') {
      delta = up * step;
    } else if (key == 'ArrowDown') {
      delta = up * -step;
    }
    _target = _target + delta;
    if (_target.length > kViewerFocusLimit) {
      _target = _target.normalized() * kViewerFocusLimit;
    }
  }

  /// NativeViewer.cpp:167-205 — pointer(type, x, y, delta).
  ///
  /// A drag rotates the requested orbit (2 * pi * pixels * 0.65 / height), the
  /// wheel multiplies the radius by 0.95^(0.7 * |delta| * 0.01), and pan
  /// translates the focus point on the focal plane whose world height is
  /// 2 * radius * tan(34 / 2), so a finger drag tracks the picture roughly 1:1 at
  /// any zoom.
  void pointer(String type, double x, double y, double delta) {
    if (!_ready || _closing) {
      return;
    }
    if (type == 'pointerdown') {
      _interrupt();
      _dragging = true;
      _previousX = x;
      _previousY = y;
    } else if (type == 'pointermove' && _dragging) {
      _goal.theta -= 2 * math.pi * (x - _previousX) * kViewerDragGain / _height;
      _goal.phi = _clamp(
        _goal.phi - 2 * math.pi * (y - _previousY) * kViewerDragGain / _height,
        kViewerMinPolar,
        math.pi - kViewerMinPolar,
      );
      _previousX = x;
      _previousY = y;
    } else if (type == 'pointerup' || type == 'pointercancel') {
      _dragging = false;
    } else if (type == 'wheel') {
      _interrupt();
      final double scale =
          math.pow(kViewerWheelBase, kViewerWheelRate * delta.abs() * kViewerWheelStep).toDouble();
      _goal.radius = _clamp(
        _goal.radius * (delta < 0 ? scale : 1 / scale),
        kViewerMinRadius,
        kViewerMaxRadius,
      );
    } else if (type == 'pan') {
      // 双指拖动平移（Overlay.qml 的 PinchHandler 转发）：x/y 是舞台像素增量。
      // 沿相机右/上向量**一次合成**移动注视点——dx 与 dy 同时生效，任意斜向
      // 平移都是一条直线；不做轴向吸附，也不拆成两步（两步会被焦点弹簧插成折线）。
      // 语义是「拖动内容」：手指右移（dx>0）→ 内容右移 → 注视点沿 -right；
      // 手指下移（dy>0，屏幕 y 向下为正）→ 内容下移 → 注视点沿 +up。
      // 焦点平面的世界尺寸 = 2*radius*tan(fov/2)，与 frame() 的 perspective(34°)
      // 一致，保证手指位移与画面位移约 1:1 跟手；灵敏度随缩放半径自适应。
      _interrupt();
      final Mat4 camera = Mat4.camera(_eye, _focus);
      final Vec3 right = Vec3(camera.values[0], camera.values[1], camera.values[2]);
      final Vec3 up = Vec3(camera.values[4], camera.values[5], camera.values[6]);
      final double span = 2 * _goal.radius * math.tan(kViewerPanFov * math.pi / 360);
      final double worldPerPixel = span / _height;
      _target = _target + right * (-x * worldPerPixel) + up * (y * worldPerPixel);
      if (_target.length > kViewerFocusLimit) {
        _target = _target.normalized() * kViewerFocusLimit;
      }
    }
  }

  // -------------------------------------------------------------------------
  // Frame step — NativeViewer.cpp:208-269.
  // -------------------------------------------------------------------------

  /// NativeViewer.cpp:208-269 — update(time, theme).
  ///
  /// Order matters: closing drops the template and returns *before* the springs
  /// run; the transition flips to open once the pending window ends; the step is
  /// min(last ? time - last : 1/60, 0.05); the springs snap to their targets
  /// within 1e-4 / 1e-3; then the pose advances by either the reduced snap, the
  /// cubic reset curve 1 - (1 - t)^3, or exponential follow (1 - exp(-9s) angle,
  /// 1 - exp(-15s) log-radius, 1 - exp(-13s) focus). The eye is rebuilt last.
  void update(double time, double theme) {
    if (!_open) {
      return;
    }
    _time = time;
    _theme = theme;
    if (_closing && time >= _closeAt) {
      _open = false;
      _closing = false;
      _ready = false;
      _meshes.clear();
      _transition = 'closed';
      return;
    }
    if (!_closing && time >= _pendingUntil) {
      _transition = 'open';
    }
    final double seconds = math.min(_last != 0 ? time - _last : 1.0 / 60, 0.05);
    _last = time;
    if (_reduced) {
      _clarity = Spring(_targetClarity, 0);
      _spread = Spring(_targetSpread, 0);
    } else {
      _clarity.damp(_targetClarity, 8, seconds);
      _spread.damp(_targetSpread, 5.5, seconds);
    }
    if ((_clarity.value - _targetClarity).abs() < 0.0001 && _clarity.velocity.abs() < 0.001) {
      _clarity = Spring(_targetClarity, 0);
    }
    if ((_spread.value - _targetSpread).abs() < 0.0001 && _spread.velocity.abs() < 0.001) {
      _spread = Spring(_targetSpread, 0);
    }
    if (_reduced) {
      _pose = _goal.copy();
      _focus = _target;
    } else if (_resetting) {
      _resetElapsed += math.max(0.0, seconds);
      // Qt shadows the time parameter here (NativeViewer.cpp:251); the port names
      // the curve parameter t instead.
      final double t = math.min(1.0, _resetElapsed / kViewerResetSeconds);
      final double amount = 1 - math.pow(1 - t, 3).toDouble();
      _focus = _resetFocus.lerp(_target, amount);
      // NativeViewer.cpp:240 takes the spherical pose *by value*; the copy keeps
      // that explicit because [_interpolate] writes back into [_pose].
      _interpolate(_pose.copy(), _goal, amount, amount);
      if (t == 1) {
        _resetting = false;
      }
    } else {
      final double pan = 1 - math.exp(-13 * math.max(0.0, seconds));
      _focus = _focus.lerp(_target, pan);
      _interpolate(
        _pose.copy(),
        _goal,
        1 - math.exp(-9 * math.max(0.0, seconds)),
        1 - math.exp(-15 * math.max(0.0, seconds)),
      );
      final Vec3 delta = _focus - _target;
      if (delta.dot(delta) < 1e-10) {
        _focus = _target;
      }
    }
    _eye = _vector(_pose) + _focus;
  }

  /// The interpolate lambda of NativeViewer.cpp:240-245.
  ///
  /// Radius interpolates in log space (multiplicative zoom), phi is clamped to
  /// the same 1e-6 polar window as the drag path, and theta takes the shortest
  /// arc through atan2(sin(d), cos(d)) so a wrap-around never spins the long way
  /// round. All three results are computed before any assignment, which is what
  /// passing the struct by value buys in C++.
  void _interpolate(ViewerSpherical from, ViewerSpherical to, double angle, double radius) {
    final double nextRadius = math.exp(_lerp(math.log(from.radius), math.log(to.radius), radius));
    final double nextPhi = _clamp(
      _lerp(from.phi, to.phi, angle),
      kViewerMinPolar,
      math.pi - kViewerMinPolar,
    );
    final double nextTheta = from.theta +
        math.atan2(math.sin(to.theta - from.theta), math.cos(to.theta - from.theta)) * angle;
    _pose
      ..radius = nextRadius
      ..phi = nextPhi
      ..theta = nextTheta;
  }

  // -------------------------------------------------------------------------
  // Frame envelope — NativeViewer.cpp:276-355.
  // -------------------------------------------------------------------------

  /// NativeViewer.cpp:328-334 — the std::array<double, 20> handed to the card
  /// expander, as the same 160 host-order bytes
  /// (QByteArray(reinterpret_cast<const char *>(state.data()), sizeof(state))).
  ///
  /// Slots 0..15 hold compose({0, -1.85, 0}, {}) column-major, 16 the fixed
  /// quality 1, 17 the clarity spring, 18 the theme and 19 the reserved 0.
  Uint8List actorStateBytes() {
    final Mat4 rootMatrix = Mat4.compose(const Vec3(0, -1.85, 0), Vec3.zero);
    final Float64List state = SceneActorState(
      matrix: rootMatrix,
      quality: 1,
      clarity: _clarity.value,
      theme: _theme,
    ).toState();
    return state.buffer.asUint8List(state.offsetInBytes, state.lengthInBytes);
  }

  /// NativeViewer.cpp:276-355 — frame(base, appearance, buffers).
  ///
  /// Returns [base] untouched while the viewer is closed. Otherwise this pass
  /// owns viewer, viewerReady, near, far, view, eye, projection, fogNear,
  /// fogFar, draws, actorTemplate, actors and viewerState.
  ///
  /// [actorTemplate] is SceneAppearance::actorTemplate (SceneAppearance.h:9).
  /// The template pass walks the part table outermost and mesh = 0 .. size
  /// innermost, where mesh == size is the synthetic cover label
  /// (NativeViewer.cpp:297-323); the *first* matching template entry wins (the
  /// break at :320), so duplicate names are ignored.
  ///
  /// [expand] stands in for m_cards.expand (NativeCards.cpp:242), which is not
  /// part of this atom: without it draws stays empty, exactly as
  /// NativeViewer.cpp:324 leaves it.
  SceneFrame frame(
    SceneFrame base,
    List<Map<String, Object?>> actorTemplate, {
    SceneDrawBuffers? buffers,
    ViewerCardExpander? expand,
  }) {
    if (!_open) {
      return base;
    }
    base.viewer = true;
    base.viewerReady = _ready;
    base.near = kViewerProjectionNear;
    base.far = kViewerProjectionFar;
    base.setCamera(
      view: Mat4.camera(_eye, _focus).inverse(),
      projection: viewerProjection(width: _width, height: _height, spread: _spread.value),
      eye: _eye,
    );
    base.fogNear = math.max(0.0, _eye.length - 1);
    base.fogFar = _eye.length + 12;

    final List<Map<String, Object?>> templateParts = <Map<String, Object?>>[];
    for (final ViewerPart part in kViewerParts) {
      for (int mesh = 0; mesh <= _meshes.length; ++mesh) {
        final bool label = mesh == _meshes.length;
        final Map<String, Object?> entry = label
            ? <String, Object?>{'name': '', 'assemblyPart': 'cover'}
            : _asObject(_meshes[mesh]);
        if (entry['assemblyPart'] != part.name) {
          continue;
        }
        for (final Map<String, Object?> template in actorTemplate) {
          final bool templateLabel = template['label'] == true;
          if (templateLabel != label || (!label && template['name'] != entry['name'])) {
            continue;
          }
          final Map<String, Object?> draw = Map<String, Object?>.from(template);
          draw['partIndex'] = templateParts.length;
          draw['mesh'] = label ? -1 : mesh;
          draw['asset'] = label ? 'cassette' : 'assembly';
          // 封面纸片在装配视图里会转到背面：双面渲染，背面由着色器画成素面封底。
          draw['side'] = label ? 2 : _asInt(template['side']);
          draw['castShadow'] = false;
          final Vec3 position = label ? const Vec3(-1.36, 3.04, 0.255) : Vec3.zero;
          draw['localMatrix'] = Mat4.compose(
            Vec3(position.x, position.y, position.z + part.depth * _spread.value),
            Vec3.zero,
          ).toJson();
          templateParts.add(draw);
          break;
        }
      }
    }
    base.draws = <Map<String, Object?>>[];
    base.actorTemplate = templateParts;
    base.actors = <Map<String, Object?>>[
      <String, Object?>{'id': 100000, 'musicKey': null, 'selected': true, 'shadowOnly': false},
    ];

    if (expand != null) {
      expand(base, actorStateBytes(), buffers ?? <int, SceneDrawData>{});
    }

    final Map<String, Object?> stats = <String, Object?>{
      'ready': _ready,
      'clarity': _clarity.value,
      'targetClarity': _targetClarity,
      'spread': _spread.value,
      'target': _targetSpread,
      'distance': _pose.radius,
      'targetPosition': _focus.toJson(),
      'requestedTarget': _target.toJson(),
      'requestedDistance': _goal.radius,
      'cameraPosition': _eye.toJson(),
      'resetting': _resetting,
      'azimuth': _goal.theta,
      'polar': _goal.phi,
    };
    base.viewerState = <String, Object?>{
      'transition': _transition,
      'surface': _surface,
      // NativeViewer.cpp:352 — a *string*, not a bool: the HUD compares it with "true".
      'exploded': _targetSpread == 1 ? 'true' : 'false',
      // NativeViewer.cpp:336-353 — QJsonDocument(stats).toJson(Compact), nested as a string.
      'stats': SceneFrame(stats).toJsonText(),
    };
    return base;
  }
}
