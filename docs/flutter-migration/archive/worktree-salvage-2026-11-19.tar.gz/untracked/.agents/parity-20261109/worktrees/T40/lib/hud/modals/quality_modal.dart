/// Flutter HUD port of the Qt landscape modal `quality`.
///
/// One-to-one port of `NativeHud::modalDraw`'s generic (full-modal) layer plus
/// the `quality` branch, and of the `qualityPanel` / `qualityChoice` pair that
/// branch calls: Qt/src/NativeHudModal.cpp:80-257 (generic layer, branch at
/// :210-211), Qt/src/NativeHudModal.cpp:307-446 (`qualityDescriptions`,
/// `qualityChoice`, `qualityPanel`).
///
/// Everything below is Qt stage pixel data for the 1920x1080 design stage.
/// Strings, sizes, weights, colours, badge keys, hit order and command order are
/// copied from that source; this file invents no string and no pixel. Portrait
/// layout is not invented either: it can only arrive through the injected
/// [QualityModalRectHook], whose default is the identity.
///
/// Draw order copied from the C++ source (NativeHudModal.cpp:83-84, :162-174,
/// :198-211, :255-256) with the `quality` branch expanded in source order
/// (:383-445):
/// `save; alpha(opacity); scrim; translate(0, offset); panel; header; body;
/// restore`. The `quality` panel emits only fills, texts and badge images; it
/// emits no `clip`, no `scale` and no `art`, so those ops are not implemented
/// here.
///
/// Host order for `quality:set:<id>` (Qt/src/NativeHudController.cpp:709-710):
/// the action runs `music.player.setQuality(id)` and the modal stays open -- no
/// closeModal() call, unlike the confirm panel. The order lives in the host;
/// this draw model only emits the action string. The open guard
/// (Qt/src/NativeHudController.cpp:66-69) refuses `quality` for a local library;
/// that guard also lives in the host.
///
/// Domain values never live here: the provider, the player's quality state, the
/// ordered `MusicPlayer::qualityOptions(provider)` table and the badge-bitmap
/// availability all arrive through [QualityModalState].
library;

/// Signature of the injected text measurer.
///
/// Mirrors Qt `Glyphs::width(text, size, weight, tracking)`
/// (Qt/src/Glyphs.h:25, Qt/src/Glyphs.cpp:286). `fit()` passes the same
/// arguments Qt passes: Qt's `fit` measures through the 3-argument
/// `Glyphs::width` overload with tracking defaulting to 0
/// (Qt/src/NativeHud.cpp:48-76, :57), and `button()` measures its label with the
/// "regular" weight because Qt's `fit` default weight applies even when the
/// drawn text is "demibold" (Qt/src/NativeHud.h:249, Qt/src/NativeHud.cpp:118).
/// No glyph width is ever hardcoded in this file.
typedef QualityModalMeasureText = double Function(
  String text,
  double size,
  String? weight,
  double tracking,
);

/// Signature of the injected portrait hook.
///
/// Receives a landscape Qt stage rectangle `(x, y, w, h)` and returns the four
/// mapped values. The default is the identity, so the 1920x1080 Qt stage
/// coordinates stay exact; no portrait pixel value is invented here. The hook
/// must be affine: text origins are mapped as the zero-size rectangle
/// `(x, y, 0, 0)`, which an affine hook maps to the transformed origin.
typedef QualityModalRectHook = List<double> Function(
  double x,
  double y,
  double w,
  double h,
);

List<double> _identityRect(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

double _min(double a, double b) => a < b ? a : b;

/// Qt `UiMotion::SurfaceMotion` (Qt/src/UiMotion.h:24-42,
/// Qt/src/UiMotion.cpp:86-120), used by the HUD for the modal surface.
///
/// Offset starts at 12 (UiMotion.h:32). `set(true, t)` targets opacity 1 and
/// offset 0 over 0.3 s; `set(false, t)` targets opacity 0 and offset 8 over
/// 0.2 s (UiMotion.cpp:105-115). With `reduced` the duration becomes 0 and
/// opacity/offset snap to the target immediately (:109-119). `sample` clamps
/// progress to 0..1, eases with the entering/exiting cubic Bezier of :91-92 and
/// marks itself finished once progress reaches 1 (:95-97).
class QualityModalMotion {
  /// Current interpolated surface opacity; Qt starts at 0 (UiMotion.h:31).
  double opacity = 0;

  /// Current vertical offset in Qt stage pixels; Qt starts at 12
  /// (UiMotion.h:32).
  double offset = 12;

  /// Remaining transition length in seconds; 0 means settled/finished
  /// (UiMotion.h:28-33, UiMotion.cpp:95-97).
  double duration = 0;

  double _fromOpacity = 0;
  double _fromOffset = 12;
  double _targetOpacity = 0;
  double _targetOffset = 12;
  double _start = 0;
  bool _entering = true;

  /// Qt `finished()` is exactly `duration == 0` (UiMotion.h:28-30).
  bool get finished => duration == 0;

  /// Qt `SurfaceMotion::sample` (UiMotion.cpp:86-98).
  void sample(double time) {
    if (duration <= 0) {
      return;
    }
    final double progress =
        ((time - _start) / duration).clamp(0.0, 1.0).toDouble();
    final double amount = _bezier(
      progress,
      _entering ? 0.22 : 0.4,
      _entering ? 1.0 : 0.0,
      _entering ? 0.36 : 1.0,
      1.0,
    );
    opacity = _fromOpacity + (_targetOpacity - _fromOpacity) * amount;
    offset = _fromOffset + (_targetOffset - _fromOffset) * amount;
    if (progress >= 1) {
      duration = 0;
    }
  }

  /// Qt `SurfaceMotion::set` (UiMotion.cpp:101-120): samples the running
  /// transition first so a retarget continues from the current values.
  void set(bool shown, double time, [bool reduced = false]) {
    sample(time);
    _fromOpacity = opacity;
    _fromOffset = offset;
    _targetOpacity = shown ? 1.0 : 0.0;
    _targetOffset = shown ? 0.0 : 8.0;
    _entering = shown;
    _start = time;
    if (reduced) {
      duration = 0;
    } else if (shown) {
      duration = 0.3;
    } else {
      duration = 0.2;
    }
    if (reduced) {
      opacity = _targetOpacity;
      offset = _targetOffset;
    }
  }

  /// Qt `bezier(x, x1, y1, x2, y2)` (UiMotion.cpp:7-22): 24 bisection steps on
  /// the x component, then the y component at the found parameter.
  static double _bezier(double x, double x1, double y1, double x2, double y2) {
    double lower = 0;
    double upper = 1;
    for (int i = 0; i < 24; ++i) {
      final double t = (lower + upper) / 2;
      if (_component(t, x1, x2) < x) {
        lower = t;
      } else {
        upper = t;
      }
    }
    return _component((lower + upper) / 2, y1, y2);
  }

  /// Qt `component(t, a, b)` inside UiMotion.cpp:8-10.
  static double _component(double t, double a, double b) =>
      3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
}

/// Qt's anonymous-namespace `struct QualityDescription`
/// (Qt/src/NativeHudModal.cpp:308-313): the four strings one quality id owns.
///
/// `badge` is the bitmap suffix, not the drawn label: the drawn fallback label
/// ("AUTO" / "HQ" / "STD") is derived from it in [QualityModal.badgeLabel].
class QualityModalDescription {
  /// Wraps one description row.
  const QualityModalDescription({
    required this.title,
    required this.caption,
    required this.detail,
    required this.badge,
  });

  /// Drawn title ("标准", "超清母带", ...).
  final String title;

  /// Drawn caption ("STANDARD", "MASTER AUDIO", ...).
  final String caption;

  /// Drawn one-line detail, painted through `limited`.
  final String detail;

  /// Badge bitmap suffix ("", "hq", "sq", "hires", "jymaster").
  final String badge;
}

/// One `MusicPlayer::qualityOptions(provider)` entry
/// (Qt/src/MusicPlayer.cpp:104-124).
///
/// Qt's `qualityPanel` iterates the table in reverse and passes only `first`
/// (the id) to `qualityChoice` (Qt/src/NativeHudModal.cpp:418-424); the drawn
/// title comes from `qualityDescriptions`. The label is carried because the host
/// injects the table verbatim, and is deliberately never painted.
class QualityModalOption {
  /// Wraps one option row.
  const QualityModalOption(this.id, this.label);

  /// Option id, e.g. `standard`, `lossless`, `best`.
  final String id;

  /// Platform label, e.g. `SQ 无损 / FLAC`. Not painted in this modal.
  final String label;
}

/// Pixel size of one injected badge bitmap.
///
/// Qt keys badge availability and pixel size off the same `QImage`
/// (`m_host->image(key)`, Qt/src/NativeHudModal.cpp:347, :433) and both badge
/// rules divide by it -- `min(68, 21 * w / h)` for a card badge (:351) and
/// `18 * w / h` for a netease extra badge (:436). The host therefore injects the
/// bitmap size, not a bare flag.
class QualityModalBadgeImage {
  /// Wraps one bitmap size in pixels.
  const QualityModalBadgeImage({required this.width, required this.height});

  /// `QImage::width()`.
  final double width;

  /// `QImage::height()`.
  final double height;
}

/// Everything the quality modal is allowed to read.
///
/// The generic modal flags ([width], [dark], [reduced], [closing], [search],
/// [opacity], [offset], [rectHook], [measureText]) plus the injected player and
/// library state: [provider], [isSiren], [quality], [actualQuality], [failed],
/// [loading], [trial], the ordered [options] table and the badge-bitmap
/// [badgeImages]. No domain object and no credential enters this file.
class QualityModalState {
  /// Creates one immutable injection state.
  const QualityModalState({
    required this.width,
    required this.measureText,
    required this.provider,
    required this.options,
    this.isSiren = false,
    this.quality = '',
    this.actualQuality = '',
    this.failed = false,
    this.loading = false,
    this.trial = false,
    this.badgeImages = const <String, QualityModalBadgeImage>{},
    this.dark = false,
    this.reduced = false,
    this.closing = false,
    this.search = false,
    this.opacity = 1.0,
    this.offset = 0.0,
    this.rectHook = _identityRect,
  });

  /// Landscape stage width (Qt `NativeHud::width`). 1920 on the design stage;
  /// `modalBounds()` is the only place it is consumed
  /// (Qt/src/NativeHud.cpp:140-159).
  final double width;

  /// Contract: `fit()` must measure through this callback, never hardcode.
  final QualityModalMeasureText measureText;

  /// `MusicLibrary::provider` -- selects the featured set
  /// (Qt/src/NativeHudModal.cpp:405-412) and the badge key prefix (:346).
  final String provider;

  /// `MusicPlayer::qualityOptions(provider)` in Qt order
  /// (Qt/src/MusicPlayer.cpp:104-124). Iterated in reverse by the panel.
  final List<QualityModalOption> options;

  /// `MusicLibrary::isSiren()` (Qt/src/NativeHudModal.cpp:332, :402).
  final bool isSiren;

  /// `MusicPlayer::quality` -- the stored preference
  /// (Qt/src/NativeHudModal.cpp:332, :402). Also selects the description shown
  /// in the preference line.
  final String quality;

  /// `MusicPlayer::actualQuality` -- the source actually serving audio
  /// (Qt/src/NativeHudModal.cpp:389).
  final String actualQuality;

  /// `MusicPlayer::failed` -- overrides the actual-source line
  /// (Qt/src/NativeHudModal.cpp:390).
  final bool failed;

  /// `MusicPlayer::loading` -- overrides the actual-source line
  /// (Qt/src/NativeHudModal.cpp:392).
  final bool loading;

  /// `MusicPlayer::trial` -- overrides the actual-source line
  /// (Qt/src/NativeHudModal.cpp:394).
  final bool trial;

  /// Injected badge bitmaps keyed exactly like Qt `m_host->image(key)`
  /// (Qt/src/NativeHudModal.cpp:346, :432).
  ///
  /// A key absent from this map means Qt's `image(key)` returned a null
  /// `QImage`: the badge is not drawn and, for a non-featured row, the
  /// "AUTO" / "HQ" / "STD" fallback label is painted instead (:357-365).
  final Map<String, QualityModalBadgeImage> badgeImages;

  /// `NativeHud::dark`; selects every colour below
  /// (Qt/src/NativeHud.cpp:10-15).
  final bool dark;

  /// `NativeHud::reduced`. `modalDraw` never branches on it
  /// (Qt/src/NativeHudModal.cpp:80-257); it only reaches `motion.set` in the
  /// host, so it changes no command here.
  final bool reduced;

  /// `NativeHud::closing`. Also unused by `modalDraw`: the host starts the
  /// closing transition and drops the panel when the motion finishes
  /// (Qt/src/NativeHud.cpp:262-266). Carried because the host injects it.
  final bool closing;

  /// The generic layer computes `search = modal == "search"`
  /// (Qt/src/NativeHudModal.cpp:162). `quality` never equals "search", so this
  /// is false in practice; the field keeps the shared scrim formula exact.
  final bool search;

  /// `NativeHud::motion.opacity` (Qt/src/NativeHudModal.cpp:84).
  final double opacity;

  /// `NativeHud::motion.offset` (Qt/src/NativeHudModal.cpp:166).
  final double offset;

  /// Injected portrait hook; identity by default (see [QualityModalRectHook]).
  final QualityModalRectHook rectHook;

  /// Availability view of [badgeImages]: exactly the keys Qt's
  /// `m_host->image(key)` answers with a non-null bitmap.
  Set<String> get availableBadgeKeys => badgeImages.keys.toSet();

  /// True when Qt would draw a bitmap for [key]
  /// (Qt/src/NativeHudModal.cpp:350).
  bool hasBadge(String key) => badgeImages.containsKey(key);

  /// Size of the injected bitmap for [key], or null when Qt has none.
  QualityModalBadgeImage? badgeImage(String key) => badgeImages[key];
}

/// Flattened draw result of one quality-modal frame.
///
/// [commands] use the Qt `op()` shapes and [hits] use the six-field hit order
/// `[x, y, width, height, action, label]` (label falls back to the action when
/// none is drawn). Hits are appended in draw order
/// (Qt/src/NativeHud.cpp:102-120).
class QualityModalFrame {
  /// Wraps one built frame; the lists are freshly allocated per build.
  const QualityModalFrame({required this.commands, required this.hits});

  /// Draw commands in Qt draw order.
  final List<List<Object?>> commands;

  /// Hit rectangles in Qt draw order, six fields each.
  final List<List<Object?>> hits;
}

/// The Qt landscape modal `quality`: "AUDIO QUALITY" / "声音档案 / 播放音质".
///
/// Opened by the `quality:open` action (Qt/src/NativeHudController.cpp:707-708),
/// which `openModal("quality")` guards against local-only libraries (:66-69).
/// The panel is the generic full-modal path, so the scrim, the panel and the
/// shared header are drawn exactly as in Qt.
class QualityModal {
  /// Wraps one injected state; `build()` is pure.
  const QualityModal(this.state);

  /// The injected state.
  final QualityModalState state;

  /// Qt modal kind string (Qt/src/NativeHudController.cpp:84, :707-708).
  static const String kind = 'quality';

  /// Action that opens this modal (Qt/src/NativeHudController.cpp:707-708).
  static const String openAction = 'quality:open';

  /// Action prefix of every choice row
  /// (Qt/src/NativeHudController.cpp:709-710).
  static const String setActionPrefix = 'quality:set:';

  /// Action of the shared header back button
  /// (Qt/src/NativeHudModal.cpp:199-200).
  static const String closeAction = 'close-modal';

  /// `modalTitle("quality")` (Qt/src/NativeHudModal.cpp:30).
  static const String title = 'AUDIO QUALITY';

  /// `modalSubtitle("quality")` (Qt/src/NativeHudModal.cpp:56).
  static const String subtitle = '声音档案 / 播放音质';

  /// Category segment of the shared header line
  /// (Qt/src/NativeHudModal.cpp:195-196).
  static const String category = 'AUDIO SPECIFICATION';

  /// Shared header back button label (Qt/src/NativeHudModal.cpp:199).
  static const String backLabel = '← 返回';

  /// Generic modal top edge, `bounds.y()` (Qt/src/NativeHud.cpp:158).
  static const double modalTop = 122;

  /// Framebuffer height covered by the scrim (Qt/src/NativeHudModal.cpp:163).
  static const double stageHeight = 1080;

  /// Generic modal maximum width (Qt/src/NativeHud.cpp:153).
  static const double modalMaxWidth = 1260;

  /// Generic modal height, both in `modalBounds` and in the panel fill
  /// (Qt/src/NativeHud.cpp:158, Qt/src/NativeHudModal.cpp:171).
  static const double modalHeight = 836;

  /// `width - 100` inside `modalBounds` (Qt/src/NativeHud.cpp:153).
  static const double modalHorizontalMargin = 100;

  /// Header back button geometry and type size
  /// (Qt/src/NativeHudModal.cpp:199-200).
  static const double backButtonX = -220;
  static const double backButtonY = 18;
  static const double backButtonWidth = 167;
  static const double backButtonHeight = 54;
  static const double backButtonSize = 20;

  /// Header text anchors (Qt/src/NativeHudModal.cpp:198-202).
  static const double headerInset = 53;
  static const double categoryY = 37;
  static const double categorySize = 11;
  static const double titleY = 91;
  static const double titleSize = 38;
  static const double subtitleY = 147;
  static const double subtitleSize = 15;

  /// `qualityPanel` content inset: `left = x + 53`, `usable = width - 106`
  /// (Qt/src/NativeHudModal.cpp:383-384).
  static const double panelInset = 53;
  static const double panelContentInset = 106;

  /// Actual-source accent bar (Qt/src/NativeHudModal.cpp:398):
  /// `fill(left, y + 195, 3, 48, accent)`.
  static const double accentBarY = 195;
  static const double accentBarWidth = 3;
  static const double accentBarHeight = 48;

  /// `text("实际音源 / SOURCE", left + 17, y + 199, 10, "demibold", 0.6)`
  /// and `text(actual, left + 17, y + 219, 18, "demibold")`
  /// (Qt/src/NativeHudModal.cpp:399-400).
  static const String actualSourceLabel = '实际音源 / SOURCE';
  static const double actualSourceLabelX = 17;
  static const double actualSourceLabelY = 199;
  static const double actualSourceLabelSize = 10;
  static const double actualSourceLabelTracking = 0.6;
  static const double actualValueY = 219;
  static const double actualValueSize = 18;

  /// `limited("已选偏好：" + preference, left + usable * 0.52, y + 219, 14,
  /// usable * 0.48)` (Qt/src/NativeHudModal.cpp:403).
  static const String preferencePrefix = '已选偏好：';
  static const double preferenceX = 0.52;
  static const double preferenceSize = 14;
  static const double preferenceWidth = 0.48;

  /// `rule(left, y + 257, usable, 0.25)` (Qt/src/NativeHudModal.cpp:404).
  static const double sourceRuleY = 257;
  static const double sourceRuleOpacity = 0.25;

  /// Featured-card geometry (Qt/src/NativeHudModal.cpp:413-416):
  /// `cardWidth = (usable - 18) / 2`, cards at `left + i * (cardWidth + 18)`,
  /// `y + 278`, height 174.
  static const double cardGap = 18;
  static const double cardTop = 278;
  static const double cardHeight = 174;

  /// Compact-row geometry (Qt/src/NativeHudModal.cpp:420-424):
  /// `y + 474 + row * 58`, height 57, full `usable` width.
  static const double rowTop = 474;
  static const double rowPitch = 58;
  static const double rowHeight = 57;

  /// First row number handed to `qualityChoice`: featured cards start at 1
  /// (`index + 1`, :415) and compact rows at 3 (`row + 3`, :422). Numbers 1 and
  /// 2 are reserved for the two possible cards.
  static const int featuredNumberBase = 1;
  static const int rowNumberBase = 3;

  /// `qualityChoice` selection visuals (Qt/src/NativeHudModal.cpp:335-343).
  static const double selectedTintAlpha = 0.18;
  static const double unselectedTintAlpha = 0.055;
  static const double selectedRuleOpacity = 0.6;
  static const double unselectedRuleOpacity = 0.13;
  static const double selectedBarWidth = 3;

  /// Badge anchors (Qt/src/NativeHudModal.cpp:348-349):
  /// `badgeX = featured ? x + width - 104 : x + 30`,
  /// `badgeY = featured ? y + 19 : y + 16`.
  static const double featuredBadgeX = -104;
  static const double plainBadgeX = 30;
  static const double featuredBadgeY = 19;
  static const double plainBadgeY = 16;

  /// Card badge box limits (Qt/src/NativeHudModal.cpp:351-352):
  /// `badgeWidth = min(68, 21 * w / h)`.
  static const double badgeMaxWidth = 68;
  static const double badgeWidthFactor = 21;

  /// Kugou badge backing plate (Qt/src/NativeHudModal.cpp:353-355):
  /// `fill(badgeX - 4, badgeY - 4, w + 8, h + 8, {0.30, 0.33, 0.26, 1})`.
  static const double badgePlateInset = 4;
  static const double badgePlateGrow = 8;

  /// Fallback label anchor for a non-featured row without a bitmap
  /// (Qt/src/NativeHudModal.cpp:364).
  static const double fallbackLabelX = 30;
  static const double fallbackLabelY = 18;
  static const double fallbackLabelSize = 11;

  /// Featured card text block (Qt/src/NativeHudModal.cpp:367-370).
  static const double featuredTextInset = 22;
  static const double featuredCaptionY = 22;
  static const double featuredCaptionSize = 11;
  static const double featuredCaptionTracking = 0.8;
  static const double featuredTitleY = 62;
  static const double featuredTitleSize = 26;
  static const double featuredDetailY = 106;
  static const double featuredDetailSize = 13;
  static const double featuredDetailInset = 44;
  static const double featuredCtaY = 143;
  static const double featuredCtaSize = 12;

  /// Compact row text block (Qt/src/NativeHudModal.cpp:372-375).
  static const double plainIndexX = 10;
  static const double plainIndexY = 20;
  static const double plainIndexSize = 9;
  static const double plainTitleX = 112;
  static const double plainTitleY = 6;
  static const double plainTitleSize = 17;
  static const double plainDetailY = 32;
  static const double plainDetailSize = 12;
  static const double plainDetailInset = 256;
  static const double plainCaptionInset = -134;
  static const double plainCaptionY = 20;
  static const double plainCaptionSize = 10;

  /// Selected-row trailing text (Qt/src/NativeHudModal.cpp:370, :375).
  static const String selectedLabel = '✓ 已选择';

  /// Featured unselected call to action (Qt/src/NativeHudModal.cpp:370).
  static const String featuredCta = '选择此档 →';

  /// Netease extra-badge strip (Qt/src/NativeHudModal.cpp:427-441).
  static const String neteaseBadgeHeader = '其他音源标识';
  static const List<String> neteaseExtraBadges = <String>['jyeffect', 'sky'];
  static const double neteaseBadgeHeaderY = 738;
  static const double neteaseBadgeHeaderSize = 11;
  static const double neteaseBadgeX = 130;
  static const double neteaseBadgePitch = 235;
  static const double neteaseBadgeY = 735;
  static const double neteaseBadgeHeight = 18;
  static const double neteaseBadgeLabelGap = 12;
  static const double neteaseBadgeLabelY = 737;
  static const double neteaseBadgeLabelSize = 12;

  /// Footer (Qt/src/NativeHudModal.cpp:442-445).
  static const double footerRuleY = 775;
  static const double footerRuleOpacity = 0.22;
  static const String footerLead = '选择与设置同步 · 切换保留播放位置';
  static const double footerY = 791;
  static const double footerSize = 12;
  static const String footerDetail = '可用音质由歌曲与平台权益决定，以实际音源为准。';
  static const double footerDetailX = 0.47;
  static const double footerDetailWidth = 0.53;

  /// `qualityDescriptions` (Qt/src/NativeHudModal.cpp:314-322), verbatim.
  ///
  /// `QHash::value(id)` returns a default-constructed struct for an unknown id,
  /// so [descriptionFor] answers empty strings in that case, exactly as Qt does.
  static const Map<String, QualityModalDescription> qualityDescriptions =
      <String, QualityModalDescription>{
    'standard': QualityModalDescription(
      title: '标准',
      caption: 'STANDARD',
      detail: '日常聆听，兼顾音质与数据流量',
      badge: '',
    ),
    'higher': QualityModalDescription(
      title: '较高',
      caption: 'HIGH QUALITY',
      detail: '提升声音细节，保持轻量传输',
      badge: 'hq',
    ),
    'exhigh': QualityModalDescription(
      title: '极高',
      caption: 'HIGH QUALITY',
      detail: '更充分保留有损编码中的声音细节',
      badge: 'hq',
    ),
    'lossless': QualityModalDescription(
      title: '无损',
      caption: 'LOSSLESS / SQ',
      detail: '无损编码，保留更完整的录音细节',
      badge: 'sq',
    ),
    'ape': QualityModalDescription(
      title: '无损 / APE',
      caption: 'LOSSLESS / APE',
      detail: '以 APE 格式提供无损音源',
      badge: 'sq',
    ),
    'hires': QualityModalDescription(
      title: '高解析无损',
      caption: 'HI-RES AUDIO',
      detail: '还原高解析录音中的丰富层次',
      badge: 'hires',
    ),
    'jymaster': QualityModalDescription(
      title: '超清母带',
      caption: 'MASTER AUDIO',
      detail: '聆听母带版本中的细腻质感与动态',
      badge: 'jymaster',
    ),
    'best': QualityModalDescription(
      title: '自动最高可用',
      caption: 'BEST AVAILABLE',
      detail: '由平台选择当前可用的最高音质',
      badge: '',
    ),
  };

  /// Siren's `lossless` override (Qt/src/NativeHudModal.cpp:329-330).
  static const QualityModalDescription sirenOriginalSource =
      QualityModalDescription(
    title: '官网原始音源',
    caption: 'ORIGINAL SOURCE',
    detail: '直接使用塞壬唱片官网提供的音源文件',
    badge: '',
  );

  /// `names` map for the actual-source line and the netease strip
  /// (Qt/src/NativeHudModal.cpp:385-388).
  static const Map<String, String> names = <String, String>{
    'standard': '标准',
    'hq': '高品质 / HQ',
    'sq': '无损 / SQ',
    'hires': '高解析无损 / Hi-Res',
    'jymaster': '超清母带',
    'jyeffect': '高清臻音',
    'sky': '沉浸环绕声',
  };

  /// `actual = names.value(player.actualQuality, "尚未确认")` with the failed /
  /// loading / trial overrides of Qt/src/NativeHudModal.cpp:389-396, in that
  /// exact branch order.
  static String actualSourceLabelFor(QualityModalState state) {
    String actual = names[state.actualQuality] ?? '尚未确认';
    if (state.failed) {
      actual = '音源不可用';
    } else if (state.loading) {
      actual = '正在获取音源…';
    } else if (state.trial) {
      actual = '试听片段';
    }
    return actual;
  }

  /// `qualityDescriptions.value(id)` (Qt/src/NativeHudModal.cpp:331).
  static QualityModalDescription descriptionFor(String id) =>
      qualityDescriptions[id] ??
      const QualityModalDescription(
        title: '',
        caption: '',
        detail: '',
        badge: '',
      );

  /// The featured id list for one provider
  /// (Qt/src/NativeHudModal.cpp:405-412): `{jymaster, hires}` by default,
  /// `{best, lossless}` for qq, `{hires, lossless}` for kugou, `{}` for
  /// siren.
  static List<String> featuredFor(String provider) {
    if (provider == 'qq') {
      return <String>['best', 'lossless'];
    }
    if (provider == 'kugou') {
      return <String>['hires', 'lossless'];
    }
    if (provider == 'siren') {
      return <String>[];
    }
    return <String>['jymaster', 'hires'];
  }

  /// Badge bitmap key (Qt/src/NativeHudModal.cpp:346, :432):
  /// `"quality:" + provider + "-" + badge`.
  static String badgeKey(String provider, String badge) =>
      'quality:' + provider + '-' + badge;

  /// Fallback label of a non-featured row without a bitmap
  /// (Qt/src/NativeHudModal.cpp:357-364): `AUTO` for best, `HQ` for a hq badge,
  /// `STD` otherwise.
  static String badgeLabel(String id, String badge) {
    if (id == 'best') {
      return 'AUTO';
    }
    if (badge == 'hq') {
      return 'HQ';
    }
    return 'STD';
  }

  /// `QString::number(number).rightJustified(2, '0')`
  /// (Qt/src/NativeHudModal.cpp:345).
  static String indexLabel(int number) => number.toString().padLeft(2, '0');

  /// Action of one choice row (Qt/src/NativeHudController.cpp:709-710).
  static String setAction(String id) => setActionPrefix + id;

  /// Qt maps Escape to `action("close-modal")` whenever a modal is open
  /// (Qt/src/NativeHudController.cpp:913-921; the empty-modal "back" and
  /// "desktop-lyrics:back" branches do not apply to this panel).
  static const String escapeAction = closeAction;

  /// The only key Qt reaches while this modal is open.
  ///
  /// Qt swallows everything else: NativeHudController.cpp:923-925 returns for
  /// any key once a modal is open, and the arrow branches are limited to
  /// settings / desktop-lyrics. There is no Tab focus ring in Qt; do not invent
  /// one.
  static const Map<String, String> keyActions = <String, String>{
    'Escape': closeAction,
  };

  /// Action for a key press while this modal is open, or null when Qt swallows
  /// the key.
  static String? actionForKey(String key) => keyActions[key];

  /// Qt/src/NativeHud.cpp:140-159 generic modal bound
  /// `{left, 122, modalWidth, 836}` with `modalWidth = min(1260, width - 100)`.
  static List<double> boundsFor(double width) {
    final double modalWidth = _min(modalMaxWidth, width - modalHorizontalMargin);
    final double left = (width - modalWidth) / 2.0;
    return <double>[left, modalTop, modalWidth, modalHeight];
  }

  /// Every action string a frame with these rows can emit, in draw order:
  /// the header back button, then one `quality:set:<id>` per drawn row.
  static List<String> actionsFor(Iterable<String> ids) => <String>[
        closeAction,
        for (final String id in ids) setAction(id),
      ];

  /// Pure: builds the command and hit stream for the injected state.
  QualityModalFrame build() {
    final _QualityPainter painter = _QualityPainter(state);

    // Qt/src/NativeHudModal.cpp:83-84.
    painter.save();
    painter.alpha(state.opacity);

    // Scrim, generic path only (Qt/src/NativeHudModal.cpp:162-165).
    painter.fill(0.0, 0.0, state.width, stageHeight, painter.scrim());

    // Qt/src/NativeHudModal.cpp:166.
    painter.translate(0.0, state.offset);

    final List<double> bounds = boundsFor(state.width);
    final double x = bounds[0];
    final double y = bounds[1];
    final double usable = bounds[2];

    // Panel fill (Qt/src/NativeHudModal.cpp:171-172): full 836 height.
    painter.fill(x, y, usable, modalHeight, painter.panel());

    // Qt/src/NativeHudModal.cpp:173: the hit table is reset here, so the base
    // layer (brand, archive mask, ...) receives no event while this modal is
    // drawn. `m_modalControls` is then true through :174-221, which is why the
    // header back button paints a tint plate and a fitted label.
    painter.resetHits();
    painter.modalControls = true;

    // Shared header (Qt/src/NativeHudModal.cpp:198-202). "quality" is not
    // "settings" / "desktop-lyrics", so the category line is size 11, the
    // subtitle 15, and the back button closes the modal.
    painter.text(
      'RHINE LAB / MUSIC DATABASE / ' + category,
      x + headerInset,
      y + categoryY,
      categorySize,
      'regular',
      0,
      painter.ink(),
    );
    painter.button(
      backLabel,
      x + usable + backButtonX,
      y + backButtonY,
      backButtonWidth,
      backButtonHeight,
      closeAction,
      backButtonSize,
      'demibold',
    );
    painter.text(title, x + headerInset, y + titleY, titleSize, 'demibold', 0,
        painter.ink());
    painter.text(subtitle, x + headerInset, y + subtitleY, subtitleSize,
        'regular', 0, painter.ink());

    // quality branch (Qt/src/NativeHudModal.cpp:210-211 -> :380-446).
    painter.qualityPanel(x, y, usable);

    // Qt/src/NativeHudModal.cpp:255-256: the modal-controls guard is cleared
    // again before the restore. It changes no command here because nothing
    // after the shared header calls button().
    painter.modalControls = false;
    painter.restore();
    return QualityModalFrame(commands: painter.commands, hits: painter.hits);
  }
}

/// Draws one quality panel. Owns the two output lists for exactly one build.
class _QualityPainter {
  _QualityPainter(this.state);

  final QualityModalState state;

  /// Flat Qt `op()` stream in draw order.
  final List<List<Object?>> commands = <List<Object?>>[];

  /// Six-field hits in draw order.
  final List<List<Object?>> hits = <List<Object?>>[];

  /// `NativeHud::m_modalControls`, always true inside the generic modal path
  /// (Qt/src/NativeHudModal.cpp:174-221).
  bool modalControls = false;

  /// Qt/src/NativeHud.cpp:10-15.
  List<Object?> ink() => state.dark
      ? <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite']
      : <Object?>[0.08, 0.085, 0.075, 1.0, 'calibratedRGB'];

  /// `qualityPanel`'s accent (Qt/src/NativeHudModal.cpp:397) and
  /// `qualityChoice`'s accent (:334) are the same literal.
  List<Object?> accent() => state.dark
      ? <Object?>[0.69, 0.74, 0.53, 1.0]
      : <Object?>[0.43, 0.48, 0.34, 1.0];

  /// Panel fill (Qt/src/NativeHudModal.cpp:171-172).
  List<Object?> panel() => state.dark
      ? <Object?>[0.15, 0.15, 0.15, 1.0, 'calibratedWhite']
      : <Object?>[0.929, 0.922, 0.894, 1.0];

  /// Modal-control button tint (Qt/src/NativeHud.cpp:116).
  List<Object?> tint() => state.dark
      ? <Object?>[0.55, 0.59, 0.46, 0.13]
      : <Object?>[0.44, 0.49, 0.36, 0.1];

  /// Kugou badge backing plate (Qt/src/NativeHudModal.cpp:354).
  List<Object?> badgePlate() => <Object?>[0.30, 0.33, 0.26, 1.0];

  /// Scrim fill (Qt/src/NativeHudModal.cpp:163-165): `search ? 0.15 : 0.6` in
  /// dark and `search ? 0.12 : 0.45` in light.
  List<Object?> scrim() {
    if (state.dark) {
      return <Object?>[
        17.0 / 255.0,
        24.0 / 255.0,
        27.0 / 255.0,
        state.search ? 0.15 : 0.6,
      ];
    }
    return <Object?>[
      227.0 / 255.0,
      224.0 / 255.0,
      215.0 / 255.0,
      state.search ? 0.12 : 0.45,
    ];
  }

  void save() => commands.add(<Object?>['save']);

  void restore() => commands.add(<Object?>['restore']);

  void alpha(double value) => commands.add(<Object?>['alpha', value]);

  void translate(double x, double y) =>
      commands.add(<Object?>['translate', x, y]);

  /// Qt/src/NativeHudModal.cpp:173 (`hits = {}`).
  void resetHits() => hits.clear();

  /// `fill(x, y, width, height, color)` (Qt/src/NativeHud.cpp:37-39).
  void fill(List<Object?> color, double x, double y, double w, double h) {
    final List<double> rect = state.rectHook(x, y, w, h);
    commands.add(<Object?>['fill', color, rect[0], rect[1], rect[2], rect[3]]);
  }

  /// `text(value, x, y, size, weight, tracking, color)`
  /// (Qt/src/NativeHud.cpp:40-43). The origin is mapped through the same hook
  /// as the rectangles, as a zero-size rectangle.
  void text(String value, double x, double y, double size, String weight,
      double tracking, List<Object?> color) {
    final List<double> point = state.rectHook(x, y, 0.0, 0.0);
    commands.add(<Object?>[
      'text',
      value,
      point[0],
      point[1],
      size,
      weight,
      tracking,
      color,
    ]);
  }

  /// `image(key, x, y, width, height)` (Qt/src/NativeHud.cpp:130-134). Qt skips
  /// an empty key; every key reaching this method is non-empty.
  void image(String key, double x, double y, double w, double h) {
    if (key.isEmpty) {
      return;
    }
    final List<double> rect = state.rectHook(x, y, w, h);
    commands.add(<Object?>['image', key, rect[0], rect[1], rect[2], rect[3]]);
  }

  /// `hit(...)` (Qt/src/NativeHud.cpp:102-109): six fields in Qt order, the
  /// label falling back to the action when none is drawn.
  void hit(double x, double y, double w, double h, String action,
      [String? label]) {
    final List<double> rect = state.rectHook(x, y, w, h);
    hits.add(<Object?>[
      rect[0],
      rect[1],
      rect[2],
      rect[3],
      action,
      label ?? action,
    ]);
  }

  /// `rule(x, y, width, opacity)` (Qt/src/NativeHud.cpp:125-129).
  void rule(double x, double y, double width, double opacity) {
    final List<Object?> color = ink();
    color[3] = opacity;
    fill(color, x, y, width, 1);
  }

  /// `fit(value, size, width, weight)` (Qt/src/NativeHud.cpp:48-76): binary
  /// search for the longest prefix that fits, then drop one more code unit and
  /// append "...". `QString::size()/left()` count UTF-16 code units, which is
  /// what Dart `String.length/substring` counts as well.
  String fit(String value, double size, double width, String? weight) {
    int length = value.length;
    if (state.measureText(value, size, weight, 0) > width) {
      int low = 1;
      int high = length;
      while (low < high) {
        final int middle = (low + high + 1) ~/ 2;
        if (state.measureText(value.substring(0, middle), size, weight, 0) <=
            width) {
          low = middle;
        } else {
          high = middle - 1;
        }
      }
      length = low;
    }
    if (length == value.length) {
      return value;
    }
    final int keep = length - 1 < 0 ? 0 : length - 1;
    return value.substring(0, keep) + '…';
  }

  /// `limited(value, x, y, size, width, weight)` (Qt/src/NativeHud.cpp:77-79).
  void limited(String value, double x, double y, double size, double width,
      [String weight = 'regular']) {
    text(fit(value, size, width, weight), x, y, size, weight, 0, ink());
  }

  /// `button(label, x, y, w, h, action, size, weight)`
  /// (Qt/src/NativeHud.cpp:110-120) for the modal-controls state, which is
  /// always on inside `modalDraw`: hit first, then the tint, then the label at
  /// `x + inset` and `y + (h - size) / 2 - 4` with `inset = min(10, w / 8)`.
  /// The label is fitted to `w - inset * 2` with Qt's default "regular"
  /// measurement weight and drawn with the requested weight.
  void button(String label, double x, double y, double w, double h,
      String action, double size,
      [String weight = 'regular']) {
    hit(x, y, w, h, action, label);
    final double inset = modalControls ? _min(10.0, w / 8) : 0.0;
    if (modalControls) {
      fill(tint(), x, y, w, h);
    }
    text(
      modalControls ? fit(label, size, w - inset * 2, 'regular') : label,
      x + inset,
      y + (h - size) / 2 - 4,
      size,
      weight,
      0,
      ink(),
    );
  }

  /// `NativeHud::qualityPanel` (Qt/src/NativeHudModal.cpp:380-446).
  void qualityPanel(double x, double y, double width) {
    final double left = x + QualityModal.panelInset;
    final double usable = width - QualityModal.panelContentInset;
    final String actual = QualityModal.actualSourceLabelFor(state);
    final List<Object?> accent = this.accent();

    // Qt/src/NativeHudModal.cpp:397-400.
    fill(accent, left, y + QualityModal.accentBarY, QualityModal.accentBarWidth,
        QualityModal.accentBarHeight);
    text(
      QualityModal.actualSourceLabel,
      left + QualityModal.actualSourceLabelX,
      y + QualityModal.actualSourceLabelY,
      QualityModal.actualSourceLabelSize,
      'demibold',
      QualityModal.actualSourceLabelTracking,
      ink(),
    );
    text(actual, left + QualityModal.actualSourceLabelX,
        y + QualityModal.actualValueY, QualityModal.actualValueSize, 'demibold',
        0, ink());

    // Qt/src/NativeHudModal.cpp:401-403.
    final String preference = state.isSiren
        ? QualityModal.sirenOriginalSource.title
        : QualityModal.descriptionFor(state.quality).title;
    limited(
      QualityModal.preferencePrefix + preference,
      left + usable * QualityModal.preferenceX,
      y + QualityModal.actualValueY,
      QualityModal.preferenceSize,
      usable * QualityModal.preferenceWidth,
    );

    // Qt/src/NativeHudModal.cpp:404.
    rule(left, y + QualityModal.sourceRuleY, usable,
        QualityModal.sourceRuleOpacity);

    // Qt/src/NativeHudModal.cpp:405-417.
    final List<String> featured = QualityModal.featuredFor(state.provider);
    final double cardWidth = (usable - QualityModal.cardGap) / 2;
    for (int index = 0; index < featured.length; ++index) {
      qualityChoice(
        featured[index],
        QualityModal.featuredNumberBase + index,
        left + index * (cardWidth + QualityModal.cardGap),
        y + QualityModal.cardTop,
        cardWidth,
        true,
      );
    }

    // Qt/src/NativeHudModal.cpp:418-425: the compact rows walk
    // `MusicPlayer::qualityOptions(provider)` in REVERSE (crbegin..crend) and
    // skip every featured id.
    int row = 0;
    for (int index = state.options.length - 1; index >= 0; --index) {
      final QualityModalOption option = state.options[index];
      if (!featured.contains(option.id)) {
        qualityChoice(
          option.id,
          QualityModal.rowNumberBase + row,
          left,
          y + QualityModal.rowTop + row * QualityModal.rowPitch,
          usable,
          false,
        );
        ++row;
      }
    }

    // Qt/src/NativeHudModal.cpp:426-441: unselectable extra sources keep their
    // official icon and name; a missing bitmap draws neither.
    if (state.provider == 'netease') {
      text(
        QualityModal.neteaseBadgeHeader,
        left,
        y + QualityModal.neteaseBadgeHeaderY,
        QualityModal.neteaseBadgeHeaderSize,
        'demibold',
        0,
        ink(),
      );
      for (int index = 0;
          index < QualityModal.neteaseExtraBadges.length;
          ++index) {
        final String id = QualityModal.neteaseExtraBadges[index];
        final String key = QualityModal.badgeKey(state.provider, id);
        final QualityModalBadgeImage? pixels = state.badgeImage(key);
        if (pixels == null) {
          continue;
        }
        final double badgeX = left +
            QualityModal.neteaseBadgeX +
            index * QualityModal.neteaseBadgePitch;
        final double badgeWidth =
            QualityModal.neteaseBadgeHeight * pixels.width / pixels.height;
        image(key, badgeX, y + QualityModal.neteaseBadgeY, badgeWidth,
            QualityModal.neteaseBadgeHeight);
        text(
          QualityModal.names[id] ?? '',
          badgeX + badgeWidth + QualityModal.neteaseBadgeLabelGap,
          y + QualityModal.neteaseBadgeLabelY,
          QualityModal.neteaseBadgeLabelSize,
          'regular',
          0,
          ink(),
        );
      }
    }

    // Qt/src/NativeHudModal.cpp:442-445.
    rule(left, y + QualityModal.footerRuleY, usable,
        QualityModal.footerRuleOpacity);
    text(QualityModal.footerLead, left, y + QualityModal.footerY,
        QualityModal.footerSize, 'regular', 0, ink());
    limited(
      QualityModal.footerDetail,
      left + usable * QualityModal.footerDetailX,
      y + QualityModal.footerY,
      QualityModal.footerSize,
      usable * QualityModal.footerDetailWidth,
    );
  }

  /// `NativeHud::qualityChoice` (Qt/src/NativeHudModal.cpp:326-377).
  void qualityChoice(String id, int number, double x, double y, double width,
      bool featured) {
    final QualityModalDescription description =
        state.provider == 'siren' && id == 'lossless'
            ? QualityModal.sirenOriginalSource
            : QualityModal.descriptionFor(id);
    final bool selected =
        state.isSiren ? id == 'lossless' : state.quality == id;
    final double height =
        featured ? QualityModal.cardHeight : QualityModal.rowHeight;
    final List<Object?> accent = this.accent();
    final List<Object?> tint = <Object?>[
      accent[0],
      accent[1],
      accent[2],
      selected
          ? QualityModal.selectedTintAlpha
          : QualityModal.unselectedTintAlpha,
    ];

    // Qt/src/NativeHudModal.cpp:337-343.
    if (featured || selected) {
      fill(tint, x, y, width, height);
    }
    rule(
      x,
      y + height,
      width,
      selected
          ? QualityModal.selectedRuleOpacity
          : QualityModal.unselectedRuleOpacity,
    );
    if (selected) {
      fill(accent, x, y, QualityModal.selectedBarWidth, height);
    }

    // Qt/src/NativeHudModal.cpp:344: a RAW hit, never button(), so there is no
    // tint plate and no drawn label beyond the description strings below.
    hit(x, y, width, height, QualityModal.setAction(id), description.title);

    // Qt/src/NativeHudModal.cpp:345-349.
    final String index = QualityModal.indexLabel(number);
    final String key = QualityModal.badgeKey(state.provider, description.badge);
    final QualityModalBadgeImage? pixels =
        description.badge.isEmpty ? null : state.badgeImage(key);
    final double badgeX = featured
        ? x + width + QualityModal.featuredBadgeX
        : x + QualityModal.plainBadgeX;
    final double badgeY = featured
        ? y + QualityModal.featuredBadgeY
        : y + QualityModal.plainBadgeY;

    // Qt/src/NativeHudModal.cpp:350-365.
    if (pixels != null) {
      final double badgeWidth = _min(
        QualityModal.badgeMaxWidth,
        QualityModal.badgeWidthFactor * pixels.width / pixels.height,
      );
      final double badgeHeight = badgeWidth * pixels.height / pixels.width;
      if (state.provider == 'kugou') {
        fill(
          badgePlate(),
          badgeX - QualityModal.badgePlateInset,
          badgeY - QualityModal.badgePlateInset,
          badgeWidth + QualityModal.badgePlateGrow,
          badgeHeight + QualityModal.badgePlateGrow,
        );
      }
      image(key, badgeX, badgeY, badgeWidth, badgeHeight);
    } else if (!featured) {
      text(
        QualityModal.badgeLabel(id, description.badge),
        x + QualityModal.fallbackLabelX,
        y + QualityModal.fallbackLabelY,
        QualityModal.fallbackLabelSize,
        'demibold',
        0,
        ink(),
      );
    }

    // Qt/src/NativeHudModal.cpp:366-376.
    if (featured) {
      text(
        index + ' / ' + description.caption,
        x + QualityModal.featuredTextInset,
        y + QualityModal.featuredCaptionY,
        QualityModal.featuredCaptionSize,
        'demibold',
        QualityModal.featuredCaptionTracking,
        ink(),
      );
      text(description.title, x + QualityModal.featuredTextInset,
          y + QualityModal.featuredTitleY, QualityModal.featuredTitleSize,
          'demibold', 0, ink());
      limited(
        description.detail,
        x + QualityModal.featuredTextInset,
        y + QualityModal.featuredDetailY,
        QualityModal.featuredDetailSize,
        width - QualityModal.featuredDetailInset,
      );
      text(
        selected ? QualityModal.selectedLabel : QualityModal.featuredCta,
        x + QualityModal.featuredTextInset,
        y + QualityModal.featuredCtaY,
        QualityModal.featuredCtaSize,
        'demibold',
        0,
        ink(),
      );
    } else {
      text(index, x + QualityModal.plainIndexX, y + QualityModal.plainIndexY,
          QualityModal.plainIndexSize, 'regular', 0, ink());
      text(description.title, x + QualityModal.plainTitleX,
          y + QualityModal.plainTitleY, QualityModal.plainTitleSize,
          'demibold', 0, ink());
      limited(
        description.detail,
        x + QualityModal.plainTitleX,
        y + QualityModal.plainDetailY,
        QualityModal.plainDetailSize,
        width - QualityModal.plainDetailInset,
      );
      text(
        selected ? QualityModal.selectedLabel : description.caption,
        x + width + QualityModal.plainCaptionInset,
        y + QualityModal.plainCaptionY,
        QualityModal.plainCaptionSize,
        'demibold',
        0,
        ink(),
      );
    }
  }
}
