/// Qt back-key adjudication for the Flutter port (plan T20, slice S03).
///
/// The file imports nothing: the Qt decision order is expressed as pure Dart over
/// an injected port interface, so it can be reasoned about and unit-tested without
/// a widget tree, a Navigator, a PopScope or a Flutter binding. Owning the host,
/// wiring the shell and mapping the Android back gesture stay out of scope
/// (ARCH_BLOCKED): this file decides, the host calls.
///
/// The order below is NativeHud::key, Qt/src/NativeHudController.cpp:887-943, plus
/// the action bodies it can reach. Every branch keeps its Qt line beside it:
///
/// * :888-890  the frame is empty -> the key produces no action at all.
/// * :891-904  settings / desktop-lyrics arrow scrolling while not closing; not an
///             Escape outcome, but it is why `closing` gates those two modals.
/// * :905-908  Enter with the command modifier plays; not an Escape outcome.
/// * :909-912  an open viewer consumes the key before the Escape branch; the
///             viewer's own Escape is its close (Qt/src/NativeViewer.cpp:131-135).
/// * :913-916  Escape while the desktop-lyrics modal is up -> desktop-lyrics:back
///             (Qt/src/NativeHudDesktopLyrics.cpp:133-136).
/// * :917-920  Escape while any other modal is up -> close-modal
///             (Qt/src/NativeHudController.cpp:686-687 -> closeModal :132-143).
/// * :923-925  with a modal still up, nothing below runs.
/// * :641-651  action("back") clears lyricsMode first (:642); with a directory open
///             it calls music.returnToDirectory() for mode == "detail" (:644-645),
///             otherwise music.leaveDirectory() (:646-648), then returns.
/// * :682-683  action("back") with no directory open falls through the action chain
///             to m_scene.mode("archive").
///
/// The user-visible sample agrees: the detail page's button reads
/// "← 返回资料库   ESC" (Qt/src/NativeHudDetail.cpp:70), i.e.
/// Escape returns to the directory, never to a Flutter route.
library;

/// The literal strings Qt compares against in NativeHud::key and its actions.
abstract final class BackValues {
  /// Engine.cpp:990-991 maps Qt::Key_Escape to this value; Engine.cpp:930-932
  /// maps the gamepad b button to the same value.
  static const String escape = 'Escape';

  /// modal value handled by NativeHudController.cpp:913-916.
  static const String desktopLyricsModal = 'desktop-lyrics';

  /// frame["mode"] that takes the return-to-directory branch (:644).
  static const String detailMode = 'detail';

  /// The scene mode the back action falls back to (:682-683).
  static const String archiveMode = 'archive';
}

/// One immutable reading of the state NativeHud::key consults for a single key.
///
/// `modal` follows Qt's QString: null and the empty string both mean "no modal",
/// because Qt tests it with modal.isEmpty() (:916, :923) and closeModal never
/// clears it (:132-143). All comparisons are exact string matches, as in Qt.
///
/// `mode` is frame["mode"] (assigned in Qt/src/NativeHud.cpp:239). Only "detail"
/// changes the back branch (:644); every other mode, and null, take the
/// leave-directory branch when a directory is open.
///
/// `hasFrame` is the one member Qt has no counterpart for: Qt guards itself with
/// `if (frame.isEmpty()) return;` (:888-890). It defaults to true so the six
/// contract fields keep their exact meaning; a host sets it to false while the
/// shell has not rendered a frame yet.
class BackState {
  /// Creates a snapshot; the defaults describe an archive scene with no modal,
  /// no open viewer and no open directory.
  const BackState({
    this.viewerOpen = false,
    this.modal,
    this.mode,
    this.directoryOpen = false,
    this.closing = false,
    this.lyricsMode = false,
    this.hasFrame = true,
  });

  /// frame["viewer"] (:909-912).
  final bool viewerOpen;

  /// Current modal name; null and '' both mean no modal (:916, :923).
  final String? modal;

  /// frame["mode"]; null when the frame carries no scene mode.
  final String? mode;

  /// music.directory is set (:643).
  final bool directoryOpen;

  /// The current modal is animating out (:891, :898, :132-143).
  final bool closing;

  /// lyricsMode; Qt clears it before the back action branches (:642).
  final bool lyricsMode;

  /// False before the first frame exists (:888-890).
  final bool hasFrame;

  /// True when Qt's `!modal.isEmpty()` would hold for this state.
  bool get hasModal => (modal ?? '').isNotEmpty;
}

/// What one Escape must do, expressed as the Qt port that owns the behaviour.
enum BackOutcome {
  /// Qt returns before any action (:888-890), or the modal is already closing.
  none,

  /// The viewer is open, so the key belongs to it (:909-912) and closes it
  /// (Qt/src/NativeViewer.cpp:131-135).
  viewerClose,

  /// desktop-lyrics modal: back to settings (:913-916,
  /// Qt/src/NativeHudDesktopLyrics.cpp:133-136).
  desktopLyricsBack,

  /// Any other modal: close it (:917-920 -> :686-687 -> :132-143).
  closeModal,

  /// Directory open and mode == "detail": music.returnToDirectory() (:644-645).
  backReturnToDirectory,

  /// Directory open and mode != "detail": music.leaveDirectory() (:646-648).
  backLeaveDirectory,

  /// No directory open: m_scene.mode("archive") (:682-683).
  backArchive,
}

/// Decides what one Escape does, following NativeHud::key's branch order.
///
/// This is a pure function: it reads [state] and never mutates it, never calls a
/// port and never touches Flutter routing.
///
/// Qt's only Escape side effect that is not a port is `lyricsMode = false`
/// (:642), executed before the back branches. It does not change the outcome
/// here; the host must clear its own lyricsMode flag before the three back
/// outcomes fire, because [RouterPorts] deliberately has no lyrics method.
///
/// One deliberate, documented difference from Qt: Qt's Escape branch (:913-922)
/// has no `closing` guard, so pressing Escape while a modal animates out calls
/// closeModal() again (:132-143), which re-arms closing, bumps the search
/// generation and cancels a pending login. The terminal state is identical, and
/// the slice contract asks for a no-action gate, so [closing] is treated like an
/// absent frame. Deleting the `closing` line below restores the byte-exact Qt
/// call and changes nothing else.
BackOutcome decideBack(BackState state) {
  // :888-890 - no frame yet: the key is dropped.
  if (!state.hasFrame) {
    return BackOutcome.none;
  }
  // Slice rule 5 (see the note above): a modal that is already closing gets no
  // second action.
  if (state.closing) {
    return BackOutcome.none;
  }
  // :909-912 - the viewer consumes the key before the Escape branch runs.
  if (state.viewerOpen) {
    return BackOutcome.viewerClose;
  }
  // :913-916 - desktop-lyrics is a modal value, so it wins over close-modal.
  if (state.modal == BackValues.desktopLyricsModal) {
    return BackOutcome.desktopLyricsBack;
  }
  // :917-920 plus :923-925 - every other modal is closed and swallows the key.
  if (state.hasModal) {
    return BackOutcome.closeModal;
  }
  // :641-651 - action("back") with a directory open.
  if (state.directoryOpen) {
    return state.mode == BackValues.detailMode
        ? BackOutcome.backReturnToDirectory
        : BackOutcome.backLeaveDirectory;
  }
  // :682-683 - action("back") with no directory open.
  return BackOutcome.backArchive;
}

/// The six Qt actions a back key can reach, as one narrow interface.
///
/// Exactly one of these is called per Escape, chosen by [decideBack]; the host
/// implements them against its own scene/music objects. The names are the
/// contract other slices adapt to, so they are not renamed or trimmed.
abstract interface class RouterPorts {
  /// m_scene.viewerKey(value) (Qt/src/NativeHudController.cpp:909-912). Qt passes
  /// only the key text; `command` carries the Engine modifier (:1003) so a host
  /// that needs it is not forced to re-read it from elsewhere.
  void viewerKey(String value, bool command);

  /// action("desktop-lyrics:back") (:915).
  void desktopLyricsBack();

  /// action("close-modal") (:919).
  void closeModal();

  /// music.returnToDirectory() (:645).
  void returnToDirectory();

  /// music.leaveDirectory() (:647).
  void leaveDirectory();

  /// m_scene.mode(mode) (:683).
  void setSceneMode(String mode);
}

/// Turns one Escape into exactly one [RouterPorts] call.
///
/// This class never uses Navigator, PopScope or any other Flutter route-pop
/// mechanism: the back key is adjudicated here and executed through the ports,
/// which is what keeps the Android back behaviour identical to Qt instead of the
/// Flutter default pop.
class BackRouter {
  /// Creates a router over the host's ports.
  BackRouter(this._ports);

  final RouterPorts _ports;

  /// Adjudicates [state] once and fires the matching port at most once.
  ///
  /// The returned [BackOutcome] is exactly [decideBack]'s result, so a caller can
  /// log or test the decision without re-deriving it. Mutually exclusive outcomes
  /// mean mutually exclusive ports: one Escape can never call two of them.
  ///
  /// [command] is the Engine modifier flag (Qt/src/Engine.cpp:1003); it is only
  /// forwarded to [RouterPorts.viewerKey], the single port that declares it.
  BackOutcome handleEscape(BackState state, {bool command = false}) {
    final BackOutcome outcome = decideBack(state);
    if (outcome == BackOutcome.viewerClose) {
      _ports.viewerKey(BackValues.escape, command);
    } else if (outcome == BackOutcome.desktopLyricsBack) {
      _ports.desktopLyricsBack();
    } else if (outcome == BackOutcome.closeModal) {
      _ports.closeModal();
    } else if (outcome == BackOutcome.backReturnToDirectory) {
      _ports.returnToDirectory();
    } else if (outcome == BackOutcome.backLeaveDirectory) {
      _ports.leaveDirectory();
    } else if (outcome == BackOutcome.backArchive) {
      _ports.setSceneMode(BackValues.archiveMode);
    }
    return outcome;
  }
}
