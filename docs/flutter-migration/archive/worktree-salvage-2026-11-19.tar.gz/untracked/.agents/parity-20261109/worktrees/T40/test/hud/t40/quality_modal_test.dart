import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/quality_modal.dart';

// Written, never executed in this atom. Intended command:
//   flutter test test/hud/t40/quality_modal_test.dart
//
// RED and GREEN are both UNEXECUTED: this atom forbids running flutter/dart, so
// this file records the intended assertions only.
//
// Every literal below is copied from the Qt source, not from the Dart
// implementation under test:
//   geometry  Qt/src/NativeHud.cpp:140-159 (modalBounds)
//   drawing   Qt/src/NativeHudModal.cpp:80-257 (generic full-modal path),
//             :307-377 (qualityChoice), :379-446 (qualityPanel)
//   prims     Qt/src/NativeHud.cpp:10-15, :37-43, :48-79, :102-134
//   options   Qt/src/MusicPlayer.cpp:104-124
//   actions   Qt/src/NativeHudController.cpp:707-710, :887-925
//   motion    Qt/src/UiMotion.h:24-42, Qt/src/UiMotion.cpp:86-120

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// Deterministic stand-in for Glyphs::width (Qt/src/Glyphs.h:25). CJK units
/// cost one em, ASCII half an em: enough to exercise fit() with no font.
double _stageMeasure(String text, double size, String? weight, double tracking) {
  var width = 0.0;
  for (final unit in text.codeUnits) {
    width += unit >= 0x2E80 ? size : size * 0.5;
  }
  return width + tracking * text.length;
}

List<double> _identityRect(double x, double y, double width, double height) =>
    <double>[x, y, width, height];

/// Stand-in for the portrait adapter: doubles every landscape rect.
List<double> _doubleRect(double x, double y, double width, double height) =>
    <double>[x * 2, y * 2, width * 2, height * 2];

/// Qt/src/MusicPlayer.cpp:121-123 default table (netease and every other
/// provider that is not qq / kugou / siren).
const List<QualityModalOption> _neteaseOptions = <QualityModalOption>[
  QualityModalOption('standard', '标准'),
  QualityModalOption('higher', '较高'),
  QualityModalOption('exhigh', '极高'),
  QualityModalOption('lossless', 'SQ 无损'),
  QualityModalOption('hires', 'Hi-Res 高解析音质'),
  QualityModalOption('jymaster', '超清母带'),
];

/// Qt/src/MusicPlayer.cpp:105-110.
const List<QualityModalOption> _qqOptions = <QualityModalOption>[
  QualityModalOption('best', '自动最高可用'),
  QualityModalOption('standard', '标准'),
  QualityModalOption('exhigh', 'HQ 高品质'),
  QualityModalOption('lossless', 'SQ 无损 / FLAC'),
  QualityModalOption('ape', 'SQ 无损 / APE'),
];

/// Qt/src/MusicPlayer.cpp:112-116.
const List<QualityModalOption> _kugouOptions = <QualityModalOption>[
  QualityModalOption('standard', '标准'),
  QualityModalOption('exhigh', 'HQ 高品音质'),
  QualityModalOption('lossless', 'SQ 无损音质'),
  QualityModalOption('hires', 'Hi-Res 高解析音质'),
];

/// Qt/src/MusicPlayer.cpp:118-119.
const List<QualityModalOption> _sirenOptions = <QualityModalOption>[
  QualityModalOption('lossless', '官网原始音源'),
];

QualityModalState _state({
  double width = 1920.0,
  String provider = 'netease',
  List<QualityModalOption> options = _neteaseOptions,
  bool isSiren = false,
  String quality = 'standard',
  String actualQuality = 'hq',
  bool failed = false,
  bool loading = false,
  bool trial = false,
  Map<String, QualityModalBadgeImage> badgeImages =
      const <String, QualityModalBadgeImage>{},
  bool dark = false,
  bool reduced = false,
  bool closing = false,
  bool search = false,
  double opacity = 1.0,
  double offset = 0.0,
  QualityModalMeasureText? measureText,
  QualityModalRectHook? rectHook,
}) {
  return QualityModalState(
    width: width,
    provider: provider,
    options: options,
    isSiren: isSiren,
    quality: quality,
    actualQuality: actualQuality,
    failed: failed,
    loading: loading,
    trial: trial,
    badgeImages: badgeImages,
    dark: dark,
    reduced: reduced,
    closing: closing,
    search: search,
    opacity: opacity,
    offset: offset,
    measureText: measureText ?? _stageMeasure,
    rectHook: rectHook ?? _identityRect,
  );
}

QualityModalFrame _frame([QualityModalState? state]) =>
    QualityModal(state ?? _state()).build();

List<List<Object?>> _ops(List<List<Object?>> commands, String name) =>
    commands.where((command) => command[0] == name).toList();

List<List<Object?>> _fills(List<List<Object?>> commands) => _ops(commands, 'fill');

List<List<Object?>> _texts(List<List<Object?>> commands) => _ops(commands, 'text');

List<List<Object?>> _images(List<List<Object?>> commands) =>
    _ops(commands, 'image');

/// The text op drawn at (x, y), whatever it says.
List<Object?>? _textAt(List<List<Object?>> commands, double x, double y) {
  for (final command in _texts(commands)) {
    if (command[2] == x && command[3] == y) {
      return command;
    }
  }
  return null;
}

/// The first text op carrying [value].
List<Object?>? _textWith(List<List<Object?>> commands, String value) {
  for (final command in _texts(commands)) {
    if (command[1] == value) {
      return command;
    }
  }
  return null;
}

bool _hasTextValue(List<List<Object?>> commands, String value) =>
    _textWith(commands, value) != null;

/// The first fill whose colour equals [color].
List<Object?>? _fillOfColor(List<List<Object?>> commands, List<Object?> color) {
  for (final command in _fills(commands)) {
    final List<Object?> actual = command[1] as List<Object?>;
    if (actual.length != color.length) {
      continue;
    }
    var same = true;
    for (var index = 0; index < color.length; ++index) {
      if (actual[index] != color[index]) {
        same = false;
      }
    }
    if (same) {
      return command;
    }
  }
  return null;
}

List<Object?>? _hitOf(QualityModalFrame frame, String action) {
  for (final hit in frame.hits) {
    if (hit[4] == action) {
      return hit;
    }
  }
  return null;
}

List<String> _hitActions(QualityModalFrame frame) =>
    frame.hits.map((hit) => hit[4] as String).toList();

// Colours, copied from the Qt literals.
/// Qt/src/NativeHud.cpp:10-15.
const List<Object?> _inkLight = <Object?>[0.08, 0.085, 0.075, 1.0, 'calibratedRGB'];
const List<Object?> _inkDark = <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite'];
/// Qt/src/NativeHudModal.cpp:334 and :397 share one accent literal.
const List<Object?> _accentLight = <Object?>[0.43, 0.48, 0.34, 1.0];
const List<Object?> _accentDark = <Object?>[0.69, 0.74, 0.53, 1.0];
/// Qt/src/NativeHudModal.cpp:171-172.
const List<Object?> _panelLight = <Object?>[0.929, 0.922, 0.894, 1.0];
const List<Object?> _panelDark = <Object?>[0.15, 0.15, 0.15, 1.0, 'calibratedWhite'];
/// Qt/src/NativeHud.cpp:116 modal-control tint.
const List<Object?> _tintLight = <Object?>[0.44, 0.49, 0.36, 0.1];
const List<Object?> _tintDark = <Object?>[0.55, 0.59, 0.46, 0.13];
/// Qt/src/NativeHudModal.cpp:163-165.
const List<Object?> _scrimLight = <Object?>[227.0 / 255.0, 224.0 / 255.0, 215.0 / 255.0, 0.45];
const List<Object?> _scrimDark = <Object?>[17.0 / 255.0, 24.0 / 255.0, 27.0 / 255.0, 0.6];
/// Qt/src/NativeHudModal.cpp:354 kugou badge backing plate.
const List<Object?> _badgePlate = <Object?>[0.30, 0.33, 0.26, 1.0];

const double _panelX = 330.0;
const double _panelY = 122.0;
const double _panelWidth = 1260.0;
const double _panelHeight = 836.0;
const double _contentX = 383.0;
const double _contentWidth = 1154.0;

/// The six rows Qt draws for the default netease state, in draw order:
/// the two featured cards first (Qt/src/NativeHudModal.cpp:413-416) and then
/// the compact rows in reverse qualityOptions order (:418-425).
const List<String> _neteaseRowOrder = <String>[
  'jymaster',
  'hires',
  'lossless',
  'exhigh',
  'higher',
  'standard',
];

// ---------------------------------------------------------------------------
void main() {
  // -------------------------------------------------------------------------
  group('command stream', () {
    test('58 ops: save first, restore last, alpha then scrim then translate',
        () {
      final commands = _frame().commands;
      // The default fixture selects the standard row, so Qt/src/NativeHudModal.cpp:337-343
      // adds the tint fill and the 3px selected bar on top of the 56 commands an
      // unselected frame emits.
      expect(commands.length, 58);
      expect(commands.first, <Object?>['save']);
      expect(commands.last, <Object?>['restore']);
      expect(commands[1], <Object?>['alpha', 1.0]);
      // Qt/src/NativeHudModal.cpp:163-166: the scrim fill precedes the
      // translate, which precedes the panel fill of :171.
      expect(commands[2][0], 'fill');
      expect(commands[3], <Object?>['translate', 0.0, 0.0]);
      expect(commands[4][0], 'fill');
    });

    test('op vocabulary and per-op counts', () {
      final commands = _frame().commands;
      expect(_fills(commands).length, 16); // 14 + the selected row tint and bar
      expect(_texts(commands).length, 38);
      expect(_images(commands).length, 0);
      for (final command in commands) {
        expect(
          const <String>[
            'save',
            'restore',
            'alpha',
            'translate',
            'fill',
            'text',
            'image',
          ],
          contains(command[0]),
        );
      }
    });

    test('the quality panel never emits clip, scale or art', () {
      final commands = _frame().commands;
      for (final command in commands) {
        expect(command[0] == 'clip' || command[0] == 'scale' || command[0] == 'art',
            isFalse);
      }
    });

    test('alpha carries the injected motion opacity (Qt/src/NativeHudModal.cpp:84)',
        () {
      expect(_frame(_state(opacity: 0.4)).commands[1], <Object?>['alpha', 0.4]);
    });

    test('translate carries the injected motion offset (Qt/src/NativeHudModal.cpp:166)',
        () {
      expect(_frame(_state(offset: 7.5)).commands[3],
          <Object?>['translate', 0.0, 7.5]);
    });

    test('the netease badge header sits just before the footer rule', () {
      final commands = _frame().commands;
      // The selected compact row contributes two fills before this strip, so an
      // unselected frame would place these at 51 / 52 / 53 (58 ops in total).
      expect(commands[53][1], '其他音源标识');
      expect(commands[54][0], 'fill');
      expect(commands[55][1], '选择与设置同步 · 切换保留播放位置');
    });
  });

  // -------------------------------------------------------------------------
  group('scrim (Qt/src/NativeHudModal.cpp:163-165)', () {
    test('light scrim covers the whole stage', () {
      final commands = _frame().commands;
      expect(commands[2], <Object?>['fill', _scrimLight, 0.0, 0.0, 1920.0, 1080.0]);
    });

    test('dark scrim uses the dark literal', () {
      final commands = _frame(_state(dark: true)).commands;
      expect(commands[2], <Object?>['fill', _scrimDark, 0.0, 0.0, 1920.0, 1080.0]);
    });

    test('the shared search alpha stays reachable (12% light / 15% dark)', () {
      // Qt computes search from the modal id, so "quality" never takes this
      // branch; the field keeps the shared formula exact all the same.
      final light = _frame(_state(search: true)).commands;
      expect((light[2][1] as List<Object?>)[3], 0.12);
      final dark = _frame(_state(dark: true, search: true)).commands;
      expect((dark[2][1] as List<Object?>)[3], 0.15);
    });
  });

  // -------------------------------------------------------------------------
  group('panel and header (Qt/src/NativeHud.cpp:153-158, NativeHudModal.cpp:171-202)',
      () {
    test('modal bounds for 1920', () {
      expect(QualityModal.boundsFor(1920.0), <double>[330.0, 122.0, 1260.0, 836.0]);
    });

    test('a narrow stage keeps the 100px margin and re-centres', () {
      expect(QualityModal.boundsFor(1000.0), <double>[50.0, 122.0, 900.0, 836.0]);
      final commands = _frame(_state(width: 1000.0)).commands;
      expect(commands[4], <Object?>['fill', _panelLight, 50.0, 122.0, 900.0, 836.0]);
    });

    test('panel fill is the full 836 height (Qt/src/NativeHudModal.cpp:171-172)',
        () {
      final commands = _frame().commands;
      expect(commands[4],
          <Object?>['fill', _panelLight, _panelX, _panelY, _panelWidth, _panelHeight]);
    });

    test('dark panel uses the calibratedWhite literal', () {
      final commands = _frame(_state(dark: true)).commands;
      expect(commands[4],
          <Object?>['fill', _panelDark, _panelX, _panelY, _panelWidth, _panelHeight]);
    });

    test('category line (Qt/src/NativeHudModal.cpp:195-198)', () {
      final commands = _frame().commands;
      expect(
        commands[5],
        <Object?>[
          'text',
          'RHINE LAB / MUSIC DATABASE / AUDIO SPECIFICATION',
          383.0,
          159.0,
          11.0,
          'regular',
          0,
          _inkLight,
        ],
      );
    });

    test('back button: hit, tint then a fitted label (Qt/src/NativeHudModal.cpp:199-200)',
        () {
      final frame = _frame();
      expect(_hitOf(frame, 'close-modal'),
          <Object?>[1370.0, 140.0, 167.0, 54.0, 'close-modal', '← 返回']);
      // Qt/src/NativeHud.cpp:110-120: inset = min(10, w / 8) = 10, tint first.
      expect(_frame().commands[6],
          <Object?>['fill', _tintLight, 1370.0, 140.0, 167.0, 54.0]);
      // Qt/src/NativeHud.cpp:120: y + (h - size) / 2 - 4 = 140 + 17 - 4.
      expect(_frame().commands[7],
          <Object?>['text', '← 返回', 1380.0, 153.0, 20.0, 'demibold', 0, _inkLight]);
    });

    test('title and subtitle (Qt/src/NativeHudModal.cpp:201-202)', () {
      final commands = _frame().commands;
      expect(commands[8],
          <Object?>['text', 'AUDIO QUALITY', 383.0, 213.0, 38.0, 'demibold', 0, _inkLight]);
      expect(commands[9],
          <Object?>['text', '声音档案 / 播放音质', 383.0, 269.0, 15.0, 'regular', 0, _inkLight]);
    });

    test('kind, title, subtitle and category strings match Qt', () {
      expect(QualityModal.kind, 'quality');
      expect(QualityModal.title, 'AUDIO QUALITY'); // Qt/src/NativeHudModal.cpp:30
      expect(QualityModal.subtitle, '声音档案 / 播放音质'); // :56
      expect(QualityModal.category, 'AUDIO SPECIFICATION'); // :195-196
      expect(QualityModal.openAction, 'quality:open'); // :707-708
      expect(QualityModal.setActionPrefix, 'quality:set:');
    });
  });

  // -------------------------------------------------------------------------
  group('actual source line (Qt/src/NativeHudModal.cpp:389-403)', () {
    test('accent bar, label and value anchors', () {
      final commands = _frame().commands;
      expect(commands[10], <Object?>['fill', _accentLight, 383.0, 317.0, 3.0, 48.0]);
      expect(commands[11],
          <Object?>['text', '实际音源 / SOURCE', 400.0, 321.0, 10.0, 'demibold', 0.6, _inkLight]);
      expect(commands[12],
          <Object?>['text', '高品质 / HQ', 400.0, 341.0, 18.0, 'demibold', 0, _inkLight]);
    });

    test('the names table (Qt/src/NativeHudModal.cpp:385-388)', () {
      const Map<String, String> names = <String, String>{
        'standard': '标准',
        'hq': '高品质 / HQ',
        'sq': '无损 / SQ',
        'hires': '高解析无损 / Hi-Res',
        'jymaster': '超清母带',
        'jyeffect': '高清臻音',
        'sky': '沉浸环绕声',
      };
      names.forEach((String key, String value) {
        final commands = _frame(_state(actualQuality: key)).commands;
        expect(_textAt(commands, 400.0, 341.0)?[1], value);
      });
    });

    test('an unknown actual quality falls back to the pending text', () {
      final commands = _frame(_state(actualQuality: 'unknown-id')).commands;
      expect(_textAt(commands, 400.0, 341.0)?[1], '尚未确认');
    });

    test('failed beats loading beats trial (Qt/src/NativeHudModal.cpp:390-396)',
        () {
      expect(
        _textAt(
          _frame(_state(failed: true, loading: true, trial: true)).commands,
          400.0,
          341.0,
        )?[1],
        '音源不可用',
      );
      expect(
        _textAt(
          _frame(_state(loading: true, trial: true)).commands,
          400.0,
          341.0,
        )?[1],
        '正在获取音源…',
      );
      expect(
        _textAt(_frame(_state(trial: true)).commands, 400.0, 341.0)?[1],
        '试听片段',
      );
    });

    test('preference line carries the stored quality title', () {
      final commands = _frame().commands;
      expect(commands[13][1], '已选偏好：标准');
      expect(commands[13][2], 983.08); // left + usable * 0.52
      expect(commands[13][3], 341.0);
      expect(commands[13][4], 14.0);
    });

    test('a siren library always shows the original-source preference', () {
      final commands = _frame(
        _state(provider: 'siren', options: _sirenOptions, isSiren: true),
      ).commands;
      expect(_hasTextValue(commands, '已选偏好：官网原始音源'), isTrue);
    });
  });

  // -------------------------------------------------------------------------
  group('rules (Qt/src/NativeHudModal.cpp:404, :442)', () {
    test('source rule', () {
      final commands = _frame().commands;
      final List<Object?>? rule = _fillOfColor(commands, <Object?>[
        0.08,
        0.085,
        0.075,
        0.25,
      ]);
      expect(rule, <Object?>['fill', <Object?>[0.08, 0.085, 0.075, 0.25], 383.0, 379.0, 1154.0, 1.0]);
    });

    test('footer rule', () {
      final commands = _frame().commands;
      final List<Object?>? rule = _fillOfColor(commands, <Object?>[
        0.08,
        0.085,
        0.075,
        0.22,
      ]);
      expect(rule, <Object?>['fill', <Object?>[0.08, 0.085, 0.075, 0.22], 383.0, 897.0, 1154.0, 1.0]);
    });

    test('footer texts (Qt/src/NativeHudModal.cpp:443-445)', () {
      final commands = _frame().commands;
      expect(_textAt(commands, 383.0, 913.0)?[1], '选择与设置同步 · 切换保留播放位置');
      expect(_textAt(commands, 383.0, 913.0)?[4], 12.0);
      expect(commands[56][1], '可用音质由歌曲与平台权益决定，以实际音源为准。');
      expect(commands[56][2], 925.38); // left + usable * 0.47
      expect(commands[56][4], 12.0);
    });
  });

  // -------------------------------------------------------------------------
  group('featured cards (Qt/src/NativeHudModal.cpp:405-417)', () {
    test('default featured set is jymaster then hires', () {
      expect(QualityModal.featuredFor('netease'),
          <String>['jymaster', 'hires']);
      expect(_hitActions(_frame()).sublist(0, 3), <String>[
        'close-modal',
        'quality:set:jymaster',
        'quality:set:hires',
      ]);
    });

    test('provider featured sets (Qt/src/NativeHudModal.cpp:406-412)', () {
      expect(QualityModal.featuredFor('qq'), <String>['best', 'lossless']);
      expect(QualityModal.featuredFor('kugou'), <String>['hires', 'lossless']);
      expect(QualityModal.featuredFor('siren'), <String>[]);
    });

    test('card width and pitch: (usable - 18) / 2 and +18', () {
      final frame = _frame();
      expect(_hitOf(frame, 'quality:set:jymaster'),
          <Object?>[383.0, 400.0, 568.0, 174.0, 'quality:set:jymaster', '超清母带']);
      expect(_hitOf(frame, 'quality:set:hires'),
          <Object?>[969.0, 400.0, 568.0, 174.0, 'quality:set:hires', '高解析无损']);
    });

    test('qq cards', () {
      final frame = _frame(_state(provider: 'qq', options: _qqOptions));
      expect(_hitOf(frame, 'quality:set:best'),
          <Object?>[383.0, 400.0, 568.0, 174.0, 'quality:set:best', '自动最高可用']);
      expect(_hitOf(frame, 'quality:set:lossless'),
          <Object?>[969.0, 400.0, 568.0, 174.0, 'quality:set:lossless', '无损']);
    });

    test('kugou cards', () {
      final frame = _frame(_state(provider: 'kugou', options: _kugouOptions));
      expect(_hitOf(frame, 'quality:set:hires')?[1], 383.0);
      expect(_hitOf(frame, 'quality:set:lossless')?[1], 969.0);
    });

    test('featured text block (Qt/src/NativeHudModal.cpp:367-370)', () {
      final commands = _frame().commands;
      expect(_textAt(commands, 405.0, 422.0),
          <Object?>['text', '01 / MASTER AUDIO', 405.0, 422.0, 11.0, 'demibold', 0.8, _inkLight]);
      expect(_textAt(commands, 405.0, 462.0),
          <Object?>['text', '超清母带', 405.0, 462.0, 26.0, 'demibold', 0, _inkLight]);
      expect(_textAt(commands, 405.0, 506.0)?[1], '聆听母带版本中的细腻质感与动态');
      expect(_textAt(commands, 405.0, 506.0)?[4], 13.0);
      expect(_textAt(commands, 405.0, 543.0),
          <Object?>['text', '选择此档 →', 405.0, 543.0, 12.0, 'demibold', 0, _inkLight]);
    });

    test('a chosen card shows the selected label instead of the CTA', () {
      final commands = _frame(_state(quality: 'jymaster')).commands;
      expect(_textAt(commands, 405.0, 543.0)?[1], '✓ 已选择');
      // The other card keeps the call to action.
      expect(_textAt(commands, 991.0, 543.0)?[1], '选择此档 →');
    });

    test('cards are always tinted; unselected uses 0.055', () {
      final commands = _frame().commands;
      expect(
        _fillOfColor(commands, <Object?>[0.43, 0.48, 0.34, 0.055]),
        <Object?>[
          'fill',
          <Object?>[0.43, 0.48, 0.34, 0.055],
          383.0,
          400.0,
          568.0,
          174.0,
        ],
      );
    });
  });

  // -------------------------------------------------------------------------
  group('compact rows (Qt/src/NativeHudModal.cpp:418-425)', () {
    test('reverse qualityOptions order after the cards', () {
      expect(_hitActions(_frame()), <String>[
        'close-modal',
        'quality:set:jymaster',
        'quality:set:hires',
        'quality:set:lossless',
        'quality:set:exhigh',
        'quality:set:higher',
        'quality:set:standard',
      ]);
      expect(_neteaseRowOrder.length, 6);
    });

    test('row geometry: y + 474 + row * 58, height 57, full usable width', () {
      final frame = _frame();
      expect(_hitOf(frame, 'quality:set:lossless'),
          <Object?>[383.0, 596.0, 1154.0, 57.0, 'quality:set:lossless', '无损']);
      expect(_hitOf(frame, 'quality:set:exhigh')?[1], 654.0);
      expect(_hitOf(frame, 'quality:set:higher')?[1], 712.0);
      expect(_hitOf(frame, 'quality:set:standard')?[1], 770.0);
    });

    test('row numbers run 03..06 (Qt/src/NativeHudModal.cpp:422, :345)', () {
      final commands = _frame().commands;
      expect(_textAt(commands, 393.0, 616.0)?[1], '03');
      expect(_textAt(commands, 393.0, 616.0)?[4], 9.0);
      expect(_textAt(commands, 393.0, 674.0)?[1], '04');
      expect(_textAt(commands, 393.0, 732.0)?[1], '05');
      expect(_textAt(commands, 393.0, 790.0)?[1], '06');
    });

    test('plain row text block (Qt/src/NativeHudModal.cpp:372-375)', () {
      final commands = _frame().commands;
      expect(_textAt(commands, 495.0, 602.0),
          <Object?>['text', '无损', 495.0, 602.0, 17.0, 'demibold', 0, _inkLight]);
      expect(_textAt(commands, 495.0, 628.0)?[1], '无损编码，保留更完整的录音细节');
      expect(_textAt(commands, 495.0, 628.0)?[4], 12.0);
      expect(_textAt(commands, 1403.0, 616.0),
          <Object?>['text', 'LOSSLESS / SQ', 1403.0, 616.0, 10.0, 'demibold', 0, _inkLight]);
    });

    test('a featured id is skipped in the compact pass', () {
      final frame = _frame();
      expect(_hitActions(frame).where((action) => action == 'quality:set:jymaster').length, 1);
      expect(_hitActions(frame).where((action) => action == 'quality:set:hires').length, 1);
    });

    test('row rules are the unselected opacity', () {
      final commands = _frame().commands;
      expect(
        _fillOfColor(commands, <Object?>[0.08, 0.085, 0.075, 0.13]),
        <Object?>[
          'fill',
          <Object?>[0.08, 0.085, 0.075, 0.13],
          383.0,
          596.0,
          1154.0,
          1.0,
        ],
      );
    });
  });

  // -------------------------------------------------------------------------
  group('selected visuals (Qt/src/NativeHudModal.cpp:332-343)', () {
    test('the selected compact row is tinted 0.18, ruled 0.6 and barred 3px',
        () {
      final commands = _frame(_state(quality: 'lossless')).commands;
      expect(
        _fillOfColor(commands, <Object?>[0.43, 0.48, 0.34, 0.18]),
        <Object?>[
          'fill',
          <Object?>[0.43, 0.48, 0.34, 0.18],
          383.0,
          596.0,
          1154.0,
          57.0,
        ],
      );
      expect(
        _fillOfColor(commands, <Object?>[0.08, 0.085, 0.075, 0.6]),
        <Object?>[
          'fill',
          <Object?>[0.08, 0.085, 0.075, 0.6],
          383.0,
          653.0,
          1154.0,
          1.0,
        ],
      );
      expect(
        _fillOfColor(commands, _accentLight),
        <Object?>['fill', _accentLight, 383.0, 596.0, 3.0, 57.0],
      );
    });

    test('an unselected compact row stays untiled but keeps its rule', () {
      final commands = _frame(_state(quality: 'lossless')).commands;
      // Only one compact row is tinted: there is exactly one 0.18 fill.
      final tinted = _fills(commands).where((command) {
        final List<Object?> color = command[1] as List<Object?>;
        return color[3] == 0.18;
      }).toList();
      expect(tinted.length, 1);
    });

    test('the selected row shows the check label in its trailing slot', () {
      final commands = _frame(_state(quality: 'standard')).commands;
      // Qt/src/NativeHudModal.cpp:375: selected ? the check label : caption.
      expect(_textAt(commands, 1403.0, 790.0)?[1], '✓ 已选择');
      expect(_textAt(commands, 1403.0, 616.0)?[1], 'LOSSLESS / SQ');
    });

    test('a siren library selects lossless whatever the stored quality is', () {
      final commands = _frame(
        _state(
          provider: 'siren',
          options: _sirenOptions,
          isSiren: true,
          quality: 'standard',
        ),
      ).commands;
      expect(
        _fillOfColor(commands, <Object?>[0.43, 0.48, 0.34, 0.18]),
        <Object?>[
          'fill',
          <Object?>[0.43, 0.48, 0.34, 0.18],
          383.0,
          596.0,
          1154.0,
          57.0,
        ],
      );
      expect(_textWith(commands, '官网原始音源')?[2], 495.0);
      expect(_textWith(commands, 'ORIGINAL SOURCE'), isNull);
    });

    test('dark accent replaces the light literal', () {
      final commands = _frame(_state(dark: true, quality: 'lossless')).commands;
      expect(_fillOfColor(commands, _accentDark) != null, isTrue);
    });
  });

  // -------------------------------------------------------------------------
  group('badge rules (Qt/src/NativeHudModal.cpp:345-365)', () {
    test('badge key shape', () {
      expect(QualityModal.badgeKey('netease', 'hq'), 'quality:netease-hq');
      expect(QualityModal.badgeKey('kugou', 'hires'), 'quality:kugou-hires');
    });

    test('no bitmap and featured: neither badge nor fallback label', () {
      final commands = _frame().commands;
      expect(_images(commands), isEmpty);
      // The card area has no STD/HQ/AUTO label.
      expect(_textAt(commands, 413.0, 419.0), isNull);
      expect(_hasTextValue(commands, 'STD'), isTrue); // compact rows still get one
    });

    test('no bitmap and compact: STD / HQ (Qt/src/NativeHudModal.cpp:357-364)',
        () {
      final commands = _frame().commands;
      // Qt/src/NativeHudModal.cpp:364 draws the fallback label at y + 18, not at
      // the y + 16 badge-image anchor of :349, so the rows read 614/672/730/788.
      expect(_textAt(commands, 413.0, 614.0),
          <Object?>['text', 'STD', 413.0, 614.0, 11.0, 'demibold', 0, _inkLight]);
      expect(_textAt(commands, 413.0, 672.0)?[1], 'HQ'); // exhigh, badge hq
      expect(_textAt(commands, 413.0, 730.0)?[1], 'HQ'); // higher, badge hq
      expect(_textAt(commands, 413.0, 788.0)?[1], 'STD'); // standard, no badge
    });

    test('an id of best falls back to AUTO', () {
      final commands = _frame(
        _state(options: const <QualityModalOption>[
          QualityModalOption('best', '自动最高可用'),
        ]),
      ).commands;
      expect(_textAt(commands, 413.0, 614.0)?[1], 'AUTO'); // label anchor y + 18
    });

    test('an injected bitmap draws the badge and suppresses the label', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-sq': QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      expect(_textAt(commands, 413.0, 614.0), isNull); // no label at the y + 18 anchor
      expect(_images(commands), <List<Object?>>[
        <Object?>['image', 'quality:netease-sq', 413.0, 612.0, 42.0, 21.0],
      ]);
    });

    test('the badge box is clamped to 68 wide', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-sq': QualityModalBadgeImage(width: 10, height: 1),
          },
        ),
      ).commands;
      expect(_images(commands).first, <Object?>[
        'image',
        'quality:netease-sq',
        413.0,
        612.0,
        68.0,
        6.8,
      ]);
    });

    test('a featured badge sits at x + width - 104, y + 19', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-hires': QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      expect(_images(commands).first, <Object?>[
        'image',
        'quality:netease-hires',
        1433.0,
        419.0,
        42.0,
        21.0,
      ]);
    });

    test('kugou paints the backing plate before the bitmap', () {
      final commands = _frame(
        _state(
          provider: 'kugou',
          options: _kugouOptions,
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:kugou-hq': QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      final int plateIndex = commands.indexWhere((command) {
        final Object? color = command[0] == 'fill' ? command[1] : null;
        return color is List<Object?> && color[3] == 1.0 && color[0] == 0.30;
      });
      final int imageIndex =
          commands.indexWhere((command) => command[0] == 'image');
      expect(plateIndex, greaterThanOrEqualTo(0));
      expect(imageIndex, plateIndex + 1);
      expect(commands[plateIndex],
          <Object?>['fill', _badgePlate, 409.0, 608.0, 50.0, 29.0]);
      expect(commands[imageIndex],
          <Object?>['image', 'quality:kugou-hq', 413.0, 612.0, 42.0, 21.0]);
    });

    test('a non-kugou provider has no plate', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-sq': QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      expect(
        _fills(commands)
            .where((command) => (command[1] as List<Object?>)[0] == 0.30)
            .isEmpty,
        isTrue,
      );
    });
  });

  // -------------------------------------------------------------------------
  group('netease extra badges (Qt/src/NativeHudModal.cpp:427-441)', () {
    test('the header line belongs to netease only', () {
      final netease = _frame().commands;
      expect(_textAt(netease, 383.0, 860.0),
          <Object?>['text', '其他音源标识', 383.0, 860.0, 11.0, 'demibold', 0, _inkLight]);
      final qq = _frame(_state(provider: 'qq', options: _qqOptions)).commands;
      expect(_hasTextValue(qq, '其他音源标识'), isFalse);
    });

    test('both bitmaps draw image then name at a 235px pitch', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-jyeffect':
                QualityModalBadgeImage(width: 2, height: 1),
            'quality:netease-sky': QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      expect(_images(commands), <List<Object?>>[
        <Object?>['image', 'quality:netease-jyeffect', 513.0, 857.0, 36.0, 18.0],
        <Object?>['image', 'quality:netease-sky', 748.0, 857.0, 36.0, 18.0],
      ]);
      expect(_textAt(commands, 561.0, 859.0),
          <Object?>['text', '高清臻音', 561.0, 859.0, 12.0, 'regular', 0, _inkLight]);
      expect(_textAt(commands, 796.0, 859.0)?[1], '沉浸环绕声');
    });

    test('a missing bitmap draws neither image nor name', () {
      final commands = _frame(
        _state(
          badgeImages: const <String, QualityModalBadgeImage>{
            'quality:netease-jyeffect':
                QualityModalBadgeImage(width: 2, height: 1),
          },
        ),
      ).commands;
      expect(_images(commands).length, 1);
      expect(_hasTextValue(commands, '高清臻音'), isTrue);
      expect(_hasTextValue(commands, '沉浸环绕声'), isFalse);
    });

    test('the strip stays empty when no bitmap exists at all', () {
      final commands = _frame().commands;
      expect(_images(commands), isEmpty);
      expect(_hasTextValue(commands, '高清臻音'), isFalse);
    });
  });

  // -------------------------------------------------------------------------
  group('hits (Qt/src/NativeHud.cpp:102-109, NativeHudModal.cpp:344)', () {
    test('seven hits in draw order, back button first', () {
      final frame = _frame();
      expect(frame.hits.length, 7);
      expect(frame.hits.first,
          <Object?>[1370.0, 140.0, 167.0, 54.0, 'close-modal', '← 返回']);
      expect(_hitActions(frame), <String>[
        'close-modal',
        'quality:set:jymaster',
        'quality:set:hires',
        'quality:set:lossless',
        'quality:set:exhigh',
        'quality:set:higher',
        'quality:set:standard',
      ]);
    });

    test('every hit has exactly six fields with numeric geometry', () {
      for (final hit in _frame().hits) {
        expect(hit.length, 6);
        expect(hit[0], isA<double>());
        expect(hit[1], isA<double>());
        expect(hit[2], isA<double>());
        expect(hit[3], isA<double>());
        expect(hit[4], isA<String>());
        expect(hit[5], isA<String>());
      }
    });

    test('choice labels are the description titles', () {
      final frame = _frame();
      expect(_hitOf(frame, 'quality:set:lossless')?[5], '无损');
      expect(_hitOf(frame, 'quality:set:higher')?[5], '较高');
      expect(_hitOf(frame, 'quality:set:standard')?[5], '标准');
    });

    test('a choice hit is raw: no tint plate and no button label', () {
      final commands = _frame().commands;
      // The only modal-control tint belongs to the header back button.
      final tinted = _fills(commands)
          .where((command) => (command[1] as List<Object?>)[3] == 0.1)
          .toList();
      expect(tinted.length, 1);
      expect(tinted.first[3], 140.0);
    });

    test('no full-stage outside catcher is installed', () {
      for (final hit in _frame().hits) {
        expect(hit[2] == 1920.0 && hit[3] == 1080.0, isFalse);
      }
    });

    test('hits follow the injected rect hook', () {
      final frame = _frame(_state(rectHook: _doubleRect));
      expect(frame.hits.first,
          <Object?>[2740.0, 280.0, 334.0, 108.0, 'close-modal', '← 返回']);
    });
  });

  // -------------------------------------------------------------------------
  group('action table and close path (Qt/src/NativeHudController.cpp:707-710, :913-925)',
      () {
    test('set action strings', () {
      expect(QualityModal.setAction('lossless'), 'quality:set:lossless');
      expect(QualityModal.setAction('best'), 'quality:set:best');
    });

    test('Escape closes; every other key is swallowed', () {
      expect(QualityModal.actionForKey('Escape'), 'close-modal');
      expect(QualityModal.escapeAction, 'close-modal');
      expect(QualityModal.closeAction, 'close-modal');
      for (final String key in <String>[
        'Tab',
        'ArrowDown',
        'ArrowUp',
        'Enter',
        'a',
        'Q',
        'Backspace',
      ]) {
        expect(QualityModal.actionForKey(key), isNull);
      }
    });

    test('the key table has exactly one entry', () {
      expect(QualityModal.keyActions.length, 1);
      expect(QualityModal.keyActions['Escape'], 'close-modal');
    });

    test('actionsFor lists the back action then every row', () {
      expect(QualityModal.actionsFor(<String>['a', 'b']),
          <String>['close-modal', 'quality:set:a', 'quality:set:b']);
    });

    test('choosing a quality never emits a close: setQuality keeps it open',
        () {
      final frame = _frame();
      expect(
        _hitActions(frame).where((action) => action == 'close-modal').length,
        1,
      );
      for (final String action in _hitActions(frame).sublist(1)) {
        expect(action.startsWith('quality:set:'), isTrue);
      }
    });
  });

  // -------------------------------------------------------------------------
  group('fit through the injected measurement (Qt/src/NativeHud.cpp:48-79)', () {
    test('measurement is always asked with tracking 0', () {
      final calls = <List<Object?>>[];
      final commands = _frame(_state(measureText: (
        String text,
        double size,
        String? weight,
        double tracking,
      ) {
        calls.add(<Object?>[text, size, weight, tracking]);
        return _stageMeasure(text, size, weight, tracking);
      })).commands;
      expect(commands.isEmpty, isFalse);
      expect(calls.isEmpty, isFalse);
      for (final call in calls) {
        expect(call[3], 0.0);
      }
    });

    test('the preference box is usable * 0.48 wide', () {
      // A measurer of 100 per code unit makes the box legible: the longest
      // fitting prefix is floor(553.92 / 100) = 5, minus the drop-one rule.
      final commands = _frame(_state(measureText: (
        String text,
        double size,
        String? weight,
        double tracking,
      ) =>
          text.length * 100.0)).commands;
      expect(_textAt(commands, 983.08, 341.0)?[1], '已选偏好…');
    });

    test('the footer detail box is usable * 0.53 wide', () {
      final commands = _frame(_state(measureText: (
        String text,
        double size,
        String? weight,
        double tracking,
      ) =>
          text.length * 100.0)).commands;
      expect(commands[56][1], '可用音质由…');
    });

    test('a featured detail box is the card width minus 44', () {
      final commands = _frame(_state(measureText: (
        String text,
        double size,
        String? weight,
        double tracking,
      ) =>
          text.length * 100.0)).commands;
      final List<Object?>? detail = _textAt(commands, 405.0, 506.0);
      expect(detail?[1], '聆听母带…');
      expect(detail?[1].toString().endsWith('…'), isTrue);
    });

    test('the compact detail box is the row width minus 256', () {
      final commands = _frame(_state(measureText: (
        String text,
        double size,
        String? weight,
        double tracking,
      ) =>
          text.length * 100.0)).commands;
      // Row width 1154 - 256 = 898: the longest fitting prefix is left(8) =
      // 800 units, so fit() keeps 7 units and appends the ellipsis
      // (Qt/src/NativeHud.cpp:48-76).
      expect(_textAt(commands, 495.0, 628.0)?[1], '无损编码，保留…');
    });

    test('text that fits is drawn verbatim', () {
      final commands = _frame().commands;
      expect(_textAt(commands, 405.0, 506.0)?[1], '聆听母带版本中的细腻质感与动态');
    });
  });

  // -------------------------------------------------------------------------
  group('motion (Qt/src/UiMotion.h:24-42, UiMotion.cpp:86-120)', () {
    test('the entering transition is 0.3s from offset 12', () {
      final motion = QualityModalMotion();
      expect(motion.offset, 12.0); // UiMotion.h:32
      expect(motion.opacity, 0.0); // UiMotion.h:31
      motion.set(true, 10.0);
      expect(motion.duration, 0.3);
      expect(motion.finished, isFalse);
    });

    test('progress 0 keeps the start values and progress 1 lands on the target',
        () {
      final motion = QualityModalMotion();
      motion.set(true, 10.0);
      motion.sample(10.0);
      expect(motion.opacity, closeTo(0.0, 1e-9));
      expect(motion.offset, closeTo(12.0, 1e-9));
      motion.sample(10.3);
      expect(motion.opacity, closeTo(1.0, 1e-9));
      expect(motion.offset, closeTo(0.0, 1e-9));
      expect(motion.finished, isTrue);
    });

    test('the closing transition is 0.2s toward offset 8', () {
      final motion = QualityModalMotion();
      motion.set(false, 20.0);
      expect(motion.duration, 0.2);
      motion.sample(20.2);
      expect(motion.opacity, closeTo(0.0, 1e-9));
      expect(motion.offset, closeTo(8.0, 1e-9));
      expect(motion.finished, isTrue);
    });

    test('reduced snaps straight to the target', () {
      final motion = QualityModalMotion();
      motion.set(false, 30.0, true);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
      motion.set(true, 31.0, true);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
    });

    test('sampling before the start time clamps to the start values', () {
      final motion = QualityModalMotion();
      motion.set(true, 10.0);
      motion.sample(5.0);
      expect(motion.opacity, closeTo(0.0, 1e-9));
      expect(motion.offset, closeTo(12.0, 1e-9));
    });
  });

  // -------------------------------------------------------------------------
  group('purity and injection', () {
    test('build is pure: equal frames, distinct lists', () {
      final QualityModal modal = QualityModal(_state());
      final first = modal.build();
      final second = modal.build();
      expect(first.commands, second.commands);
      expect(first.hits, second.hits);
      expect(identical(first.commands, second.commands), isFalse);
    });

    test('reduced and closing change no command', () {
      final plain = _frame().commands;
      expect(_frame(_state(reduced: true)).commands, plain);
      expect(_frame(_state(closing: true)).commands, plain);
    });

    test('portrait arrives only through the injected rect hook', () {
      final commands = _frame(_state(rectHook: _doubleRect)).commands;
      expect(commands[2],
          <Object?>['fill', _scrimLight, 0.0, 0.0, 3840.0, 2160.0]);
      expect(commands[4],
          <Object?>['fill', _panelLight, 660.0, 244.0, 2520.0, 1672.0]);
      expect(commands[5][2], 766.0);
      expect(commands[5][3], 318.0);
    });

    test('the identity hook leaves the Qt stage coordinates untouched', () {
      expect(_frame().commands[4],
          <Object?>['fill', _panelLight, 330.0, 122.0, 1260.0, 836.0]);
    });

    test('static tables mirror Qt verbatim', () {
      expect(QualityModal.qualityDescriptions.length, 8); // :314-322
      expect(QualityModal.qualityDescriptions['standard']?.caption, 'STANDARD');
      expect(QualityModal.qualityDescriptions['lossless']?.badge, 'sq');
      expect(QualityModal.qualityDescriptions['ape']?.title, '无损 / APE');
      expect(QualityModal.qualityDescriptions['jymaster']?.detail,
          '聆听母带版本中的细腻质感与动态');
      expect(QualityModal.names.length, 7); // :385-388
      expect(QualityModal.names['sky'], '沉浸环绕声');
      expect(QualityModal.neteaseExtraBadges, <String>['jyeffect', 'sky']);
      expect(QualityModal.descriptionFor('nope').title, '');
      expect(QualityModal.indexLabel(3), '03');
      expect(QualityModal.indexLabel(12), '12');
      expect(QualityModal.selectedLabel, '✓ 已选择');
      expect(QualityModal.featuredCta, '选择此档 →');
      expect(QualityModal.sirenOriginalSource.caption, 'ORIGINAL SOURCE');
    });
  });
}
