#!/usr/bin/env python3
"""Landscape parity comparator for the Qt -> Flutter migration (T50 skeleton).

WHAT THIS IS
    A per-ROI comparison helper for the landscape (horizontal) parity acceptance
    defined by docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md
    ("T50 横屏逐页验收", plan lines 702-708): page x state x action x orientation
    coverage, per-ROI manual comparison of glyph / layout / action / timing.

WHAT THIS IS NOT
    It never decides acceptance. Plan section 9.2 states that SSIM >= 0.97,
    deltaE <= 3, pixel tolerances and performance ratios are PROPOSED metrics
    that must be frozen against a same-device, same-scene Qt baseline before they
    may be quoted in acceptance; they never replace the per-ROI human comparison
    and large masks are forbidden (plan section 9.2, section 8). Consequently:
      * without an explicit frozen threshold file every metric verdict is
        UNMEASURED_THRESHOLDS_NOT_FROZEN;
      * an aggregate/global score can never produce a pass (see overall_verdict);
      * a case without ROIs is rejected, because global-only comparison is the
        exact failure mode the plan forbids;
      * hits and commands are protocol facts, not metrics: one mismatch fails
        the case without any threshold, because the frozen Qt array contract
        needs no measurement baseline to be checked (plan section 9.1 item 3).
    The authoritative verdict for every page remains a human per-ROI review.

COORDINATES (plan section 2.4, plan lines 116-128)
    physical (device px)  <-APK / screenshots
    logical  (Flutter/QML px) = physical / dpr
    stage    (1080-normalised draw space) = logical / stageScale
    stageScale = logical_height / 1080 ; stageWidth = logical_width / stageScale
    Never treat the 1800 physical screenshot height as a QML height, never treat
    screenshot coordinates as dp, and never mix physical with logical in one
    comparison.

CONTRACT EVIDENCE
    Every constant below is grounded in Qt source or in the plan. Earlier drafts
    of this file cited docs/flutter-migration/contracts/layout.md and
    contracts/hud-protocol.md; those files do not exist in this repository (only
    docs/flutter-migration/contracts/settings-platform.md does), so they must
    not be cited as evidence.
    * plan section 4.2 (plan lines 183-207): 17 command ops, array shape,
      parameter order, Gamma 1.8 calibrated marker.
    * plan section 4.3 (plan lines 209-215) plus Qt/src/NativeHud.cpp:101-109:
      hits are exactly {x, y, width, height, action, label}; hits are rebuilt
      every draw (Qt/src/NativeHud.cpp:253) and the player bar is appended last
      (Qt/src/NativeHud.cpp:310), so PlayerBar hits are the tail of the list.
    * Qt/src/PlayerBar.cpp:46-53: PlayerBar hits alone add fixed:true.
    * plan section 4.4 (plan lines 216-222) plus Qt/src/Glyphs.cpp:37-47 and
      Glyphs.cpp:316 / 316 / 536 / 547 / 558 / 910: text baseline is
      y + size * 1.044; calibrated colour is gated on the a[4] marker string.
    * plan section 9.1 item 3 (plan line 763) is the protocol gate; plan section
      9.2 (plan lines 767-770) keeps SSIM/DeltaE proposed and forbids big masks.
    * plan section 9.4 (plan lines 792-801): without a same-APK device frame no
      visual alignment may be claimed. The 12 baseline PNGs are recorded lost in
      the plan (section 2.2, plan lines 84-100), so no pixel pass is claimable
      from this repository alone.

STATUS OF THIS FILE
    Written only; never executed in this task (user ban on build/test/analyze/
    formatter/verification runs). Any run happens later, under separate
    authorisation.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
import sys
import zlib
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# 1. Frozen contract constants
# ---------------------------------------------------------------------------

STAGE_HEIGHT = 1080.0
"""Landscape stage height in stage units (plan section 4.1)."""

TEXT_BASELINE_FACTOR = 1.044
"""text op baseline: y + size * 1.044 (plan section 4.2 text row;
Qt/src/Glyphs.cpp:316, 536, 910)."""

GAMMA_CALIBRATED = 1.8
"""calibrated colour Gamma before sRGB encoding (plan section 4.2;
Qt/src/Glyphs.cpp:37-47)."""

STAGE_TOLERANCE = 1e-6
"""Absolute tolerance for stageScale / stageWidth assertions (plan appendix B.1)."""

DEVICE_DPR = 1.96875
"""Reference device 526f6b6d: density 315, DPR = 315 / 160 (plan section 2.1)."""

PLAYER_BAR_TOP = 984.0
PLAYER_BAR_BOTTOM = 1080.0
"""Player bar band in stage units (plan section 4.1; Qt/src/NativeHud.cpp:310)."""

HIT_REQUIRED_FIELDS = ("x", "y", "width", "height", "action", "label")
"""hits base fields in source order (Qt/src/NativeHud.cpp:101-109, plan 4.3)."""

HIT_OPTIONAL_FIELDS = ("fixed",)
"""The only legal extra hit key; Qt/src/PlayerBar.cpp:46-53 writes it."""

HIT_FORBIDDEN_FIELDS = ("z", "id", "opcode", "args", "seq", "frameId")
"""plan section 4.3 forbids inventing depth or frame identity on hits."""

HIT_GEOMETRY_TOLERANCE = 1e-3
"""Stage units. 1e-3 stage units is 0.0017 device px on the reference device, so
this absorbs JSON float formatting noise and nothing else (plan section 2.4)."""

PLAYER_BAR_ACTIONS = (
    "player:prev", "player:toggle", "player:next", "player:lyrics",
    "player:mode", "player:open", "music:like-current",
)
"""Actions only Qt/src/PlayerBar.cpp emits (hit sites at lines 85-87, 136, 170,
198, 204, 224 of that file)."""

PLAYER_BAR_ACTION_PREFIXES = ("player:seek-fraction:", "player:volume-fraction:")
"""Slider hits carry a fraction suffix (Qt/src/PlayerBar.cpp:150, 217)."""

HIT_COMPARE_MODES = ("exact", "subset")
"""exact: the fixture is a complete golden. subset: every fixture hit must appear
in the frame, in the same relative order, with identical fields; extra frame hits
are reported, not failed. Fixtures use subset because label widths come from glyph
metrics at runtime (Qt/src/Glyphs.cpp width()), so a statically frozen complete
hit list is not derivable from source alone.""

COMMAND_OPS = (
    "save", "restore", "alpha", "translate", "scale", "rotate", "clip",
    "fill", "ellipse", "text", "art", "fill-path", "path", "arc",
    "right-mask", "gradient", "image",
)
"""The 17 frozen command op names (plan section 4.2). Order is only a checklist."""

MAX_MASK_AREA_RATIO = 0.05
"""Hard cap on masked area per ROI. Large masks are forbidden (plan section 9.2)."""

PROPOSED_THRESHOLDS = {
    "ssim_min": 0.97,
    "delta_e_max": 3.0,
    "pixel_tolerance": 0.02,
}
"""PROPOSED ONLY, not frozen. Keys here document the intended shape of a frozen
threshold file; they must never be used as an implicit default."""


class ParityError(Exception):
    """Raised for contract violations that must abort the comparison."""


# ---------------------------------------------------------------------------
# 2. Coordinate system
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class StageMetrics:
    """One conversion frame shared by drawing, hits and IME (plan section 4.3)."""

    physical_w: float
    physical_h: float
    dpr: float

    @property
    def logical_w(self) -> float:
        return self.physical_w / self.dpr

    @property
    def logical_h(self) -> float:
        return self.physical_h / self.dpr

    @property
    def stage_scale(self) -> float:
        return self.logical_h / STAGE_HEIGHT

    @property
    def stage_width(self) -> float:
        return self.logical_w / self.stage_scale

    @property
    def physical_per_stage(self) -> float:
        return self.stage_scale * self.dpr

    def physical_to_logical(self, x: float, y: float) -> Tuple[float, float]:
        return x / self.dpr, y / self.dpr

    def logical_to_stage(self, x: float, y: float) -> Tuple[float, float]:
        return x / self.stage_scale, y / self.stage_scale

    def stage_to_logical(self, x: float, y: float) -> Tuple[float, float]:
        return x * self.stage_scale, y * self.stage_scale

    def stage_to_physical(self, x: float, y: float) -> Tuple[float, float]:
        return x * self.physical_per_stage, y * self.physical_per_stage

    def stage_rect_to_logical(self, rect: Sequence[float]) -> Tuple[float, ...]:
        x, y, w, h = rect
        return (x * self.stage_scale, y * self.stage_scale,
                w * self.stage_scale, h * self.stage_scale)


def metrics_from_physical(width: float, height: float, dpr: float = DEVICE_DPR) -> StageMetrics:
    if dpr <= 0:
        raise ParityError("dpr must be positive, got %r" % (dpr,))
    if width <= 0 or height <= 0:
        raise ParityError("physical size must be positive, got %rx%r" % (width, height))
    return StageMetrics(float(width), float(height), float(dpr))


def assert_device_metrics() -> Dict[str, float]:
    """Reference assertion from plan appendix B.1 (tolerance 1e-6)."""
    metrics = metrics_from_physical(2880.0, 1800.0, DEVICE_DPR)
    checks = {
        "logical_w": (metrics.logical_w, 1462.8571428571),
        "logical_h": (metrics.logical_h, 914.2857142857),
        "stage_scale": (metrics.stage_scale, 0.846560846561),
        "stage_width": (metrics.stage_width, 1728.0),
        "physical_per_stage": (metrics.physical_per_stage, 1.666666666667),
    }
    for name, (got, want) in checks.items():
        if abs(got - want) > 1e-6:
            raise ParityError("stage metric %s: got %.12f want %.12f" % (name, got, want))
    desktop = metrics_from_physical(1280.0, 720.0, 1.0)
    if abs(desktop.stage_scale - 0.666666666667) > 1e-6:
        raise ParityError("desktop stageScale mismatch: %.12f" % desktop.stage_scale)
    if abs(desktop.stage_width - 1920.0) > 1e-6:
        raise ParityError("desktop stageWidth mismatch: %.12f" % desktop.stage_width)
    return {name: got for name, (got, _want) in checks.items()}


def text_baseline(y: float, size: float) -> float:
    """Baseline of a text op; art ops do NOT get this offset (plan section 4.2)."""
    return y + size * TEXT_BASELINE_FACTOR


def art_baseline(y: float, _size: float) -> float:
    """art (icon glyph) ops have no 1.044 baseline offset."""
    return y


# ---------------------------------------------------------------------------
# 3. Colour and command / hit protocol checks
# ---------------------------------------------------------------------------

def calibration_to_srgb(value: float) -> float:
    """calibrated -> sRGB, per channel (plan section 4.2; Qt/src/Glyphs.cpp:37-47)."""
    if value < 0.0:
        value = 0.0
    if value > 1.0:
        value = 1.0
    linear = math.pow(value, GAMMA_CALIBRATED)
    if linear <= 0.0031308:
        return 12.92 * linear
    return 1.055 * math.pow(linear, 1.0 / 2.4) - 0.055


def parse_color(args: Sequence) -> Tuple[float, float, float, float, bool]:
    """Return (r, g, b, a, calibrated) from a raw command colour slot.

    a[3] is alpha and defaults to 1; a[4] is a colour-space marker, never alpha:
    only a string starting with "calibrated" activates Gamma 1.8 -> sRGB.
    """
    if len(args) < 3:
        raise ParityError("colour needs at least rgb, got %r" % (list(args),))
    red, green, blue = (float(args[0]), float(args[1]), float(args[2]))
    alpha = float(args[3]) if len(args) > 3 else 1.0
    calibrated = len(args) > 4 and isinstance(args[4], str) and args[4].startswith("calibrated")
    return red, green, blue, alpha, calibrated


def color_to_rgb8(args: Sequence) -> Tuple[int, int, int]:
    red, green, blue, _alpha, calibrated = parse_color(args)
    if calibrated:
        red, green, blue = (calibration_to_srgb(red), calibration_to_srgb(green),
                            calibration_to_srgb(blue))
    return tuple(int(round(max(0.0, min(1.0, channel)) * 255.0)) for channel in (red, green, blue))


def is_player_bar_action(action: str) -> bool:
    """True for every action string Qt/src/PlayerBar.cpp can emit."""
    if action in PLAYER_BAR_ACTIONS:
        return True
    return any(action.startswith(prefix) for prefix in PLAYER_BAR_ACTION_PREFIXES)


def player_bar_segment_start(hits: Sequence[dict], declared: Optional[int] = None) -> int:
    """Return the index where the contiguous PlayerBar tail of hits starts.

    Qt appends the player bar after the page and modal drawing
    (Qt/src/NativeHud.cpp:310), so PlayerBar hits are always the suffix, and the
    suffix contains nothing else. The segment is therefore the maximal run of
    PlayerBar actions at the end of the list; a declared count must agree with it.
    """
    start = len(hits)
    while start > 0:
        candidate = hits[start - 1]
        if not isinstance(candidate, dict):
            break
        if not is_player_bar_action(str(candidate.get("action", ""))):
            break
        start -= 1
    if declared is not None:
        if not isinstance(declared, int) or isinstance(declared, bool):
            raise ParityError("player_bar_hits must be an integer")
        if declared < 0 or declared > len(hits):
            raise ParityError("declared player-bar hit count %d is out of range 0..%d"
                              % (declared, len(hits)))
        declared_start = len(hits) - declared
        if declared_start != start:
            raise ParityError(
                "declared %d PlayerBar hits but the PlayerBar action tail starts at "
                "index %d of %d (Qt/src/NativeHud.cpp:310 draws the player bar last)"
                % (declared, start, len(hits)))
    return start


def validate_hits(hits: Sequence[dict], page: str = "",
                  player_bar_hits: Optional[int] = None,
                  require_fixed: Optional[bool] = None) -> List[str]:
    """Validate the frozen hits shape; return notes, raise on any violation.

    Rules (plan section 4.3, plan lines 209-215; Qt/src/NativeHud.cpp:101-109):
    six required fields, no invented keys, finite positive geometry, source order
    preserved (never sorted, never de-duplicated), fixed:true only inside the
    PlayerBar tail and uniform there, because Qt writes it from one helper
    (Qt/src/PlayerBar.cpp:46-53).

    require_fixed=True demands the exact Qt emission; False demands no fixed at
    all; None accepts plan section 9.1 "optional for PlayerBar" but records a
    note, because Qt always writes it.
    """
    if not isinstance(hits, list):
        raise ParityError("%s: hits must be a list" % page)
    notes: List[str] = []
    tail = player_bar_segment_start(hits, player_bar_hits)
    tail_fixed: List[bool] = []
    for index, hit in enumerate(hits):
        if not isinstance(hit, dict):
            raise ParityError("%s: hit %d must be an object" % (page, index))
        for name in HIT_REQUIRED_FIELDS:
            if name not in hit:
                raise ParityError("%s: hit %d missing required field %r" % (page, index, name))
        for name in HIT_FORBIDDEN_FIELDS:
            if name in hit:
                raise ParityError("%s: hit %d carries forbidden field %r" % (page, index, name))
        unknown = sorted(name for name in hit
                         if name not in HIT_REQUIRED_FIELDS
                         and name not in HIT_OPTIONAL_FIELDS)
        if unknown:
            raise ParityError("%s: hit %d carries unknown field(s) %s"
                              % (page, index, ", ".join(unknown)))
        action = hit["action"]
        if not isinstance(action, str) or not action:
            raise ParityError("%s: hit %d action must be a non-empty string" % (page, index))
        if not isinstance(hit["label"], str):
            raise ParityError("%s: hit %d label must be a string" % (page, index))
        for name in ("x", "y", "width", "height"):
            value = hit[name]
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                raise ParityError("%s: hit %d field %s must be numeric" % (page, index, name))
            if not math.isfinite(float(value)):
                raise ParityError("%s: hit %d field %s must be finite" % (page, index, name))
        if float(hit["width"]) <= 0 or float(hit["height"]) <= 0:
            raise ParityError("%s: hit %d has a non-positive rect width=%r height=%r"
                              % (page, index, hit["width"], hit["height"]))
        in_tail = index >= tail
        fixed = hit.get("fixed")
        if fixed is not None and not isinstance(fixed, bool):
            raise ParityError("%s: hit %d fixed must be a boolean" % (page, index))
        if fixed and not in_tail:
            raise ParityError(
                "%s: hit %d carries fixed:true but action %r is outside the PlayerBar "
                "tail (Qt/src/PlayerBar.cpp:46-53 writes fixed only there)"
                % (page, index, action))
        if in_tail:
            if not is_player_bar_action(action):
                raise ParityError("%s: hit %d action %r sits in the PlayerBar tail but is "
                                  "not a PlayerBar action" % (page, index, action))
            tail_fixed.append(bool(fixed))
            if float(hit["y"]) + float(hit["height"]) < PLAYER_BAR_TOP:
                notes.append("%s: PlayerBar hit %d ends above the band top %.0f"
                             % (page, index, PLAYER_BAR_TOP))
        elif fixed is False:
            notes.append("%s: hit %d states fixed:false; page hits omit the key entirely"
                         % (page, index))
        if hit["label"] == "":
            notes.append("%s: hit %d empty label falls back to action "
                         "(Qt/src/NativeHud.cpp:101-109)" % (page, index))
    if tail < len(hits):
        if any(tail_fixed) and not all(tail_fixed):
            raise ParityError(
                "%s: PlayerBar hits mix fixed:true with an omitted fixed; Qt writes it "
                "from one helper for every PlayerBar hit (PlayerBar.cpp:46-53)" % page)
        if require_fixed is True and not all(tail_fixed):
            raise ParityError("%s: PlayerBar hits must carry fixed:true" % page)
        if require_fixed is False and any(tail_fixed):
            raise ParityError("%s: PlayerBar hits must not carry fixed" % page)
        if require_fixed is None and not any(tail_fixed):
            notes.append("%s: PlayerBar tail omits fixed; plan section 9.1 allows it but "
                         "Qt always writes it, so a reference frame must not omit it" % page)
    elif require_fixed is True:
        raise ParityError("%s: require_fixed set but the frame has no PlayerBar hits" % page)
    return notes


_COMMAND_SHAPES = {
    "save": (1, 1), "restore": (1, 1),
    "alpha": (2, 2), "translate": (3, 3), "scale": (3, 3), "rotate": (2, 2),
    "clip": (5, 5),
    "fill": (6, 6), "ellipse": (6, 6),
    "text": (8, 8),
    "art": (8, 8),
    "fill-path": (3, 3),
    "path": (4, 6),
    "arc": (8, 8),
    "right-mask": (6, 6),
    "gradient": (1, 2),
    "image": (6, 6),
}
"""Accepted array lengths per op, a[0] included, read off the Qt parser
(Qt/src/Glyphs.cpp:644-825) and the plan table (plan lines 185-205).

Almost every op is exact, because the Qt emitters always write the full tuple:
text and art are always 8 (Qt/src/NativeHud.cpp:40-43, :135-138), fill is 6
(:37-39), image is 6 (:132), right-mask is 6 (:325). Exactly two documented
exceptions exist:
  * path accepts 4..6 because Qt itself emits the 4-entry form with an empty dash
    array (Qt/src/NativeHud.cpp:507 keycap, :513 symbol, :619 saddle) while the
    6-entry form appears at Qt/src/NativeHudBoot.cpp:151;
  * gradient accepts 1..2 because the parser guards a[1] with a.size() > 1
    (Qt/src/Glyphs.cpp:807-808); every current emitter sends 2
    (Qt/src/NativeHudBoot.cpp:167).

Any accepted short form is still reported by validate_commands, never silently
defaulted."""


def validate_commands(commands: Sequence) -> List[str]:
    """Validate the 17-op command array shape; return notes, raise on violation."""
    notes: List[str] = []
    for index, command in enumerate(commands):
        if not isinstance(command, list) or not command:
            raise ParityError("command %d must be a non-empty array" % index)
        op = command[0]
        if op not in COMMAND_OPS:
            raise ParityError("command %d unknown op %r" % (index, op))
        low, high = _COMMAND_SHAPES[op]
        if not (low <= len(command) <= high):
            raise ParityError("command %d op %s has %d entries, expected %d..%d"
                              % (index, op, len(command), low, high))
        if len(command) < high:
            notes.append("command %d op %s uses a short tail" % (index, op))
    return notes


def _signature_key(hit: dict) -> Tuple[float, float, float, float, str, str, bool]:
    """Order-insensitive identity of one hit, for detecting a pure reordering."""
    return (round(float(hit["x"]), 6), round(float(hit["y"]), 6),
            round(float(hit["width"]), 6), round(float(hit["height"]), 6),
            str(hit["action"]), str(hit["label"]), bool(hit.get("fixed", False)))


def _same_rect(left: dict, right: dict, tolerance: float) -> bool:
    for name in ("x", "y", "width", "height"):
        if abs(float(left[name]) - float(right[name])) > tolerance:
            return False
    return True


def diff_hits(reference: Sequence[dict], current: Sequence[dict], page: str = "",
              tolerance: float = HIT_GEOMETRY_TOLERANCE,
              mode: str = "exact") -> Dict[str, object]:
    """Compare two hit lists field by field, preserving source order.

    mode="exact"  the reference is a complete golden: equal length, index-wise
                  equality, and a reordering is named as such (plan section 4.3
                  forbids sorting or regrouping hits).
    mode="subset" every reference hit must appear in current in the same relative
                  order with identical fields; extra current hits are reported as
                  notes. Fixtures use this because label widths come from glyph
                  metrics at runtime, so a complete static golden is impossible.

    Every finding is a protocol defect (plan section 9.1 item 3) and fails the
    case without any frozen threshold: the Qt array contract is not a metric.
    """
    if mode not in HIT_COMPARE_MODES:
        raise ParityError("unknown hit comparison mode %r" % mode)
    findings: List[Dict[str, object]] = []
    notes: List[str] = []

    def fail(kind: str, index: int, detail: str, expected=None, actual=None) -> None:
        findings.append({"severity": "FAIL", "kind": kind, "index": index,
                         "detail": detail, "expected": expected, "actual": actual})

    def compare_at(ref_hit: dict, cur_hit: dict, ref_index: int) -> None:
        if str(ref_hit["action"]) != str(cur_hit["action"]):
            fail("hit_action", ref_index, "action differs",
                 ref_hit["action"], cur_hit["action"])
        if str(ref_hit["label"]) != str(cur_hit["label"]):
            fail("hit_label", ref_index, "label differs",
                 ref_hit["label"], cur_hit["label"])
        if bool(ref_hit.get("fixed", False)) != bool(cur_hit.get("fixed", False)):
            fail("hit_fixed", ref_index, "fixed differs",
                 bool(ref_hit.get("fixed", False)), bool(cur_hit.get("fixed", False)))
        if not _same_rect(ref_hit, cur_hit, tolerance):
            fail("hit_geometry", ref_index,
                 "rect differs beyond %.6f stage units" % tolerance,
                 [ref_hit["x"], ref_hit["y"], ref_hit["width"], ref_hit["height"]],
                 [cur_hit["x"], cur_hit["y"], cur_hit["width"], cur_hit["height"]])

    if mode == "exact":
        if len(reference) != len(current):
            fail("hit_count", min(len(reference), len(current)),
                 "hit count differs: reference %d, current %d"
                 % (len(reference), len(current)), len(reference), len(current))
        for index in range(min(len(reference), len(current))):
            compare_at(reference[index], current[index], index)
        if len(reference) == len(current) and findings:
            ref_keys = sorted(_signature_key(hit) for hit in reference)
            cur_keys = sorted(_signature_key(hit) for hit in current)
            if ref_keys == cur_keys:
                fail("hit_order", 0,
                     "the same hits appear in a different order; plan section 4.3 "
                     "requires source order and forbids sorting or regrouping")
    else:
        cursor = 0
        for ref_index, ref_hit in enumerate(reference):
            matched = None
            same_action = None
            for scan in range(cursor, len(current)):
                candidate = current[scan]
                if str(candidate.get("action")) != str(ref_hit.get("action")):
                    continue
                if same_action is None:
                    same_action = scan
                if (str(candidate.get("label")) == str(ref_hit.get("label"))
                        and bool(candidate.get("fixed", False))
                        == bool(ref_hit.get("fixed", False))
                        and _same_rect(ref_hit, candidate, tolerance)):
                    matched = scan
                    break
            if matched is None:
                if same_action is None:
                    fail("hit_missing", ref_index,
                         "reference hit action %r is absent from the frame"
                         % ref_hit.get("action"), _signature_key(ref_hit), None)
                else:
                    compare_at(ref_hit, current[same_action], ref_index)
                continue
            cursor = matched + 1
        if len(current) > len(reference):
            notes.append("%s: frame carries %d hit(s) beyond the fixture subset; "
                         "allowed only in subset mode"
                         % (page, len(current) - len(reference)))
    return {"page": page, "mode": mode, "findings": findings, "notes": notes,
            "reference_hits": len(reference), "current_hits": len(current)}


def roi_hit_coverage(roi: Roi, hits: Sequence[dict], page: str = "") -> Dict[str, object]:
    """Check every ROI-declared action exists and its hit centre lands in the ROI.

    A ROI that claims an element is visible but no hit reaches it is exactly the
    "picture without the action" failure the per-ROI review exists to catch, so a
    miss is a FAIL, not a note.
    """
    findings: List[Dict[str, object]] = []
    matched: List[str] = []
    for expected in roi.expect_visible:
        if isinstance(expected, dict):
            action = str(expected.get("action", ""))
            label = expected.get("label")
        else:
            action = str(expected)
            label = None
        if not action:
            raise ParityError("ROI %s has an expect_visible entry without an action" % roi.name)
        candidates = [hit for hit in hits
                      if str(hit.get("action")) == action
                      and (label is None or str(hit.get("label")) == str(label))]
        if not candidates:
            findings.append({"severity": "FAIL", "kind": "expect_visible_missing",
                             "roi": roi.name,
                             "detail": "no hit with action %r in the frame" % action,
                             "expected": expected, "actual": None})
            continue
        inside = [hit for hit in candidates
                  if _rect_contains(roi.rect,
                                    (float(hit["x"]) + float(hit["width"]) / 2.0,
                                     float(hit["y"]) + float(hit["height"]) / 2.0,
                                     0.0, 0.0))]
        if not inside:
            findings.append({"severity": "FAIL",
                             "kind": "expect_visible_outside_roi", "roi": roi.name,
                             "detail": "hit %r exists but its centre is outside the ROI"
                                       % action,
                             "expected": list(roi.rect),
                             "actual": [[hit["x"], hit["y"], hit["width"], hit["height"]]
                                        for hit in candidates]})
            continue
        matched.append(action)
    return {"roi": roi.name, "page": page, "findings": findings, "matched": matched,
            "expected": len(roi.expect_visible)}


def validate_frame_envelope(envelope: dict, previous_generation: Optional[int] = None) -> List[str]:
    """commands/hits/state must come from one step; generation only checks that."""
    notes: List[str] = []
    for name in ("commands", "hits", "state"):
        if name not in envelope:
            raise ParityError("frame envelope missing %r" % name)
    generation = envelope.get("generation")
    if generation is not None:
        if not isinstance(generation, int) or isinstance(generation, bool):
            raise ParityError("generation must be an integer")
        if previous_generation is not None and generation <= previous_generation:
            notes.append("generation %d did not advance past %d"
                         % (generation, previous_generation))
    else:
        notes.append("no generation field: Qt emits none (plan section 4.3); a generation "
                         "may only verify same-generation publication")
    validate_commands(envelope["commands"])
    validate_hits(envelope["hits"])
    return notes


# ---------------------------------------------------------------------------
# 4. Minimal image IO (stdlib only)
# ---------------------------------------------------------------------------

def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def read_png(path: str) -> Tuple[int, int, List[bytes]]:
    with open(path, "rb") as handle:
        data = handle.read()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ParityError("not a PNG: %s" % path)
    pos = 8
    idat = bytearray()
    palette = b""
    width = height = bit_depth = color_type = None
    interlace = 0
    while pos + 8 <= len(data):
        (length,) = struct.unpack(">I", data[pos:pos + 4])
        ctype = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctype == b"IHDR":
            (width, height, bit_depth, color_type, _comp, _filt, interlace) = \
                struct.unpack(">IIBBBBB", chunk)
        elif ctype == b"PLTE":
            palette = chunk
        elif ctype == b"IDAT":
            idat.extend(chunk)
        elif ctype == b"IEND":
            break
    if width is None:
        raise ParityError("no IHDR in %s" % path)
    if interlace != 0:
        raise ParityError("interlaced PNG unsupported: %s" % path)
    if bit_depth != 8:
        raise ParityError("only 8-bit PNG supported, got %d: %s" % (bit_depth, path))
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(color_type)
    if channels is None:
        raise ParityError("unsupported PNG colour type %d" % color_type)
    raw = zlib.decompress(bytes(idat))
    stride = width * channels
    rows: List[bytes] = []
    previous = bytearray(stride)
    offset = 0
    for _row in range(height):
        filter_type = raw[offset]
        offset += 1
        line = bytearray(raw[offset:offset + stride])
        offset += stride
        if filter_type == 1:
            for i in range(channels, stride):
                line[i] = (line[i] + line[i - channels]) & 0xFF
        elif filter_type == 2:
            for i in range(stride):
                line[i] = (line[i] + previous[i]) & 0xFF
        elif filter_type == 3:
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                line[i] = (line[i] + ((left + previous[i]) >> 1)) & 0xFF
        elif filter_type == 4:
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                upleft = previous[i - channels] if i >= channels else 0
                line[i] = (line[i] + _paeth(left, previous[i], upleft)) & 0xFF
        elif filter_type != 0:
            raise ParityError("bad PNG filter type %d in %s" % (filter_type, path))
        rows.append(bytes(line))
        previous = line
    rgb_rows: List[bytes] = []
    for line in rows:
        out = bytearray()
        if color_type == 2:
            out = bytearray(line)
        elif color_type == 6:
            for i in range(0, len(line), 4):
                out.extend(line[i:i + 3])
        elif color_type in (0, 4):
            step = 2 if color_type == 4 else 1
            for i in range(0, len(line), step):
                out.extend(bytes((line[i], line[i], line[i])))
        elif color_type == 3:
            for i in range(len(line)):
                index = line[i] * 3
                out.extend(palette[index:index + 3])
        rgb_rows.append(bytes(out))
    return width, height, rgb_rows


def read_ppm(path: str) -> Tuple[int, int, List[bytes]]:
    with open(path, "rb") as handle:
        blob = handle.read()
    if not blob.startswith(b"P6"):
        raise ParityError("only binary P6 PPM supported: %s" % path)
    fields: List[bytes] = []
    pos = 2
    while len(fields) < 3:
        while pos < len(blob) and blob[pos:pos + 1].isspace():
            pos += 1
        if blob[pos:pos + 1] == b"#":
            while pos < len(blob) and blob[pos:pos + 1] != b"\n":
                pos += 1
            continue
        start = pos
        while pos < len(blob) and not blob[pos:pos + 1].isspace():
            pos += 1
        fields.append(blob[start:pos])
    pos += 1
    width, height, maximum = (int(field) for field in fields)
    if maximum != 255:
        raise ParityError("only 8-bit PPM supported: %s" % path)
    pixels = blob[pos:pos + width * height * 3]
    rows = [pixels[row * width * 3:(row + 1) * width * 3] for row in range(height)]
    return width, height, rows


def load_image(path: str) -> Tuple[int, int, List[bytes]]:
    lowered = path.lower()
    if lowered.endswith(".png"):
        return read_png(path)
    if lowered.endswith(".ppm"):
        return read_ppm(path)
    raise ParityError("unsupported image type (use PNG or PPM): %s" % path)


# ---------------------------------------------------------------------------
# 5. Cases, ROIs and masks
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Mask:
    """A small, justified exclusion region inside one ROI. Large masks are banned."""

    rect: Tuple[float, float, float, float]
    reason: str
    source: str


@dataclass(frozen=True)
class Roi:
    """One comparison region, in stage units unless stated otherwise."""

    name: str
    rect: Tuple[float, float, float, float]
    source: str
    expect_visible: Tuple[str, ...] = ()
    masks: Tuple[Mask, ...] = ()
    space: str = "stage"


@dataclass
class Case:
    """One parity case: geometry frame, ROIs, and an optional frozen hit subset."""

    case_id: str
    page: str
    state: str
    orientation: str
    rois: List[Roi]
    notes: str = ""
    hits: List[dict] = field(default_factory=list)
    hits_mode: str = "exact"
    hits_scope: str = ""
    hits_excluded: List[str] = field(default_factory=list)
    player_bar_hits: Optional[int] = None
    anchors: List[dict] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)
    evidence: Dict[str, object] = field(default_factory=dict)
    manual_review: Dict[str, object] = field(default_factory=dict)
    physical: Tuple[int, int] = (2880, 1800)
    dpr: float = DEVICE_DPR
    stage: Dict[str, float] = field(default_factory=dict)


def _case_geometry(raw: dict, case_id: str) -> Tuple[Tuple[int, int], float, Dict[str, float]]:
    """Parse the case geometry frame and refuse a self-contradicting one."""
    physical = raw.get("physical", [2880, 1800])
    if not isinstance(physical, list) or len(physical) != 2:
        raise ParityError("case %s: physical must be [width, height]" % case_id)
    dpr = float(raw.get("dpr", DEVICE_DPR))
    if dpr <= 0:
        raise ParityError("case %s: dpr must be positive" % case_id)
    metrics = metrics_from_physical(float(physical[0]), float(physical[1]), dpr)
    stage = raw.get("stage") or {}
    derived = {"height": STAGE_HEIGHT, "width": metrics.stage_width,
               "scale": metrics.stage_scale}
    for key, value in derived.items():
        if key in stage and abs(float(stage[key]) - float(value)) > STAGE_TOLERANCE:
            raise ParityError(
                "case %s: stage.%s=%r contradicts %r derived from physical %r at "
                "dpr %.6f (plan section 2.4)" % (case_id, key, stage[key], value,
                                                 physical, dpr))
    return (int(physical[0]), int(physical[1])), dpr, derived


def _validate_case_claims(case: Case) -> None:
    """Reject a case that claims evidence it cannot have (plan section 9.4)."""
    if not case.sources:
        raise ParityError("case %s must cite at least one Qt source path" % case.case_id)
    for source in case.sources:
        if not isinstance(source, str) or ":" not in source:
            raise ParityError("case %s source %r must read path:line" % (case.case_id, source))
    status = str(case.evidence.get("screenshots", ""))
    if not status:
        raise ParityError("case %s must state evidence.screenshots" % case.case_id)
    if not case.manual_review:
        raise ParityError("case %s must carry manual_review" % case.case_id)
    review_status = str(case.manual_review.get("status", ""))
    verdict = str(case.manual_review.get("verdict", ""))
    if review_status == "PASSED" or verdict == "PASS":
        raise ParityError(
            "case %s claims a manual PASS; this repository holds no device frame, so "
            "plan section 9.4 forbids that claim" % case.case_id)
    if status != "AVAILABLE" and not verdict.startswith("UNMEASURED"):
        raise ParityError("case %s has screenshots=%r but claims verdict %r"
                          % (case.case_id, status, verdict))
    if case.orientation != "landscape":
        raise ParityError("case %s: T50 covers landscape only, got %r"
                          % (case.case_id, case.orientation))
    if case.hits_mode not in HIT_COMPARE_MODES:
        raise ParityError("case %s: hits_mode must be one of %s"
                          % (case.case_id, ", ".join(HIT_COMPARE_MODES)))
    if case.hits and not case.hits_scope:
        raise ParityError("case %s declares hits but no hits_scope: a golden hit list "
                          "must say what it covers" % case.case_id)
    for roi in case.rois:
        if roi.space != "stage":
            raise ParityError("case %s ROI %s: only stage space is frozen for landscape "
                              "parity" % (case.case_id, roi.name))
        if not roi.source:
            raise ParityError("case %s ROI %s must cite a source" % (case.case_id, roi.name))


def load_cases(path: str) -> List[Case]:
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ParityError("%s must hold a JSON object" % path)
    schema = payload.get("schema")
    if schema is not None and schema != "parity-case/1":
        raise ParityError("%s: unsupported schema %r" % (path, schema))
    raw_cases = payload.get("cases")
    if raw_cases is None:
        raw_cases = [payload]
    cases: List[Case] = []
    for raw in raw_cases:
        case_id = str(raw.get("id") or raw.get("case") or "?")
        rois: List[Roi] = []
        for raw_roi in raw.get("rois", []):
            masks = tuple(
                Mask(tuple(float(v) for v in mask["rect"]), mask.get("reason", ""),
                     mask.get("source", ""))
                for mask in raw_roi.get("masks", [])
            )
            rois.append(Roi(
                name=raw_roi["name"],
                rect=tuple(float(v) for v in raw_roi["rect"]),
                source=raw_roi.get("source", ""),
                expect_visible=tuple(raw_roi.get("expect_visible", [])),
                masks=masks,
                space=raw_roi.get("space", "stage"),
            ))
        if not rois:
            raise ParityError(
                "case %s has no ROIs: a global-only comparison is forbidden "
                "(plan section 9.2)" % case_id)
        physical, dpr, stage = _case_geometry(raw, case_id)
        hits = list(raw.get("hits") or [])
        player_bar_hits = raw.get("player_bar_hits")
        if hits:
            validate_hits(hits, case_id + " fixture", player_bar_hits)
        case = Case(
            case_id=case_id,
            page=str(raw.get("page", "")),
            state=str(raw.get("state", "")),
            orientation=str(raw.get("orientation", "landscape")),
            rois=rois,
            notes=str(raw.get("notes", "")),
            hits=hits,
            hits_mode=str(raw.get("hits_mode", "exact")),
            hits_scope=str(raw.get("hits_scope", "")),
            hits_excluded=[str(item) for item in raw.get("hits_excluded", [])],
            player_bar_hits=int(player_bar_hits) if player_bar_hits is not None else None,
            anchors=list(raw.get("anchors", [])),
            sources=[str(item) for item in raw.get("sources", [])],
            evidence=dict(raw.get("evidence", {})),
            manual_review=dict(raw.get("manual_review", {})),
            physical=physical,
            dpr=dpr,
            stage=stage,
        )
        _validate_case_claims(case)
        cases.append(case)
    if not cases:
        raise ParityError("no cases in %s" % path)
    return cases


def _rect_area(rect: Sequence[float]) -> float:
    return float(rect[2]) * float(rect[3])


def _rect_contains(outer: Sequence[float], inner: Sequence[float]) -> bool:
    return (inner[0] >= outer[0] - 1e-9 and inner[1] >= outer[1] - 1e-9
            and inner[0] + inner[2] <= outer[0] + outer[2] + 1e-9
            and inner[1] + inner[3] <= outer[1] + outer[3] + 1e-9)


def validate_masks(roi: Roi) -> Dict[str, float]:
    """Reject large or unjustified masks; return coverage statistics."""
    if roi.space == "global":
        raise ParityError("ROI %s declared space=global: global masks are forbidden" % roi.name)
    total = 0.0
    for mask in roi.masks:
        if not mask.reason or not mask.source:
            raise ParityError("ROI %s mask %r lacks reason/source" % (roi.name, mask.rect))
        if not _rect_contains(roi.rect, mask.rect):
            raise ParityError("ROI %s mask %r escapes the ROI rect" % (roi.name, mask.rect))
        total += _rect_area(mask.rect)
    ratio = total / _rect_area(roi.rect) if _rect_area(roi.rect) > 0 else 0.0
    if ratio > MAX_MASK_AREA_RATIO:
        raise ParityError(
            "ROI %s masks cover %.4f of the area (cap %.3f): large masks are forbidden"
            % (roi.name, ratio, MAX_MASK_AREA_RATIO))
    return {"mask_area_ratio": ratio}


# ---------------------------------------------------------------------------
# 6. Per-ROI metrics
# ---------------------------------------------------------------------------

def crop(rows: List[bytes], rect: Sequence[float], channels: int = 3) -> List[bytes]:
    x, y, width, height = (int(round(v)) for v in rect)
    if x < 0 or y < 0 or x + width > len(rows[0]) // channels or y + height > len(rows):
        raise ParityError("rect %r escapes the image" % (list(rect),))
    return [row[x * channels:(x + width) * channels] for row in rows[y:y + height]]


def masked_pixels(roi: Roi) -> Dict[Tuple[int, int], bool]:
    """Rasterise ROI masks into ROI-local pixel coordinates."""
    marks: Dict[Tuple[int, int], bool] = {}
    for mask in roi.masks:
        mx, my, mw, mh = (int(round(v)) for v in mask.rect)
        rx, ry = int(round(roi.rect[0])), int(round(roi.rect[1]))
        for py in range(my - ry, my - ry + mh):
            for px in range(mx - rx, mx - rx + mw):
                marks[(px, py)] = True
    return marks


def _srgb_to_lab(rgb: Tuple[float, float, float]) -> Tuple[float, float, float]:
    def linearize(channel: float) -> float:
        channel = channel / 255.0
        if channel <= 0.04045:
            return channel / 12.92
        return math.pow((channel + 0.055) / 1.055, 2.4)

    red, green, blue = (linearize(value) for value in rgb)
    x = red * 0.4124564 + green * 0.3575761 + blue * 0.1804375
    y = red * 0.2126729 + green * 0.7151522 + blue * 0.0721750
    z = red * 0.0193339 + green * 0.1191920 + blue * 0.9503041
    xn, yn, zn = 0.95047, 1.0, 1.08883

    def lab_f(value: float) -> float:
        return value ** (1.0 / 3.0) if value > 0.008856 else (7.787 * value + 16.0 / 116.0)

    fx, fy, fz = lab_f(x / xn), lab_f(y / yn), lab_f(z / zn)
    return 116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz)


def delta_e_2000(lab1: Tuple[float, float, float], lab2: Tuple[float, float, float]) -> float:
    """CIEDE2000 colour difference (documented, local implementation)."""
    l1, a1, b1 = lab1
    l2, a2, b2 = lab2
    c1 = math.hypot(a1, b1)
    c2 = math.hypot(a2, b2)
    c_bar = (c1 + c2) / 2.0
    g = 0.5 * (1.0 - math.sqrt(c_bar ** 7 / (c_bar ** 7 + 25.0 ** 7))) if c_bar > 0 else 0.5
    a1p = (1.0 + g) * a1
    a2p = (1.0 + g) * a2
    c1p = math.hypot(a1p, b1)
    c2p = math.hypot(a2p, b2)

    def hue(a: float, b: float) -> float:
        if a == 0.0 and b == 0.0:
            return 0.0
        angle = math.degrees(math.atan2(b, a))
        return angle + 360.0 if angle < 0 else angle

    h1p = hue(a1p, b1)
    h2p = hue(a2p, b2)
    dlp = l2 - l1
    dcp = c2p - c1p
    if c1p * c2p == 0.0:
        dhp = 0.0
    elif abs(h2p - h1p) <= 180.0:
        dhp = h2p - h1p
    elif h2p - h1p > 180.0:
        dhp = h2p - h1p - 360.0
    else:
        dhp = h2p - h1p + 360.0
    dHp = 2.0 * math.sqrt(c1p * c2p) * math.sin(math.radians(dhp) / 2.0)
    l_bar = (l1 + l2) / 2.0
    c_bar_p = (c1p + c2p) / 2.0
    if c1p * c2p == 0.0:
        h_bar = h1p + h2p
    elif abs(h1p - h2p) <= 180.0:
        h_bar = (h1p + h2p) / 2.0
    elif h1p + h2p < 360.0:
        h_bar = (h1p + h2p + 360.0) / 2.0
    else:
        h_bar = (h1p + h2p - 360.0) / 2.0
    t = (1.0 - 0.17 * math.cos(math.radians(h_bar - 30.0))
         + 0.24 * math.cos(math.radians(2.0 * h_bar))
         + 0.32 * math.cos(math.radians(3.0 * h_bar + 6.0))
         - 0.20 * math.cos(math.radians(4.0 * h_bar - 63.0)))
    delta_theta = 30.0 * math.exp(-(((h_bar - 275.0) / 25.0) ** 2))
    rc = 2.0 * math.sqrt(c_bar_p ** 7 / (c_bar_p ** 7 + 25.0 ** 7))
    sl = 1.0 + (0.015 * (l_bar - 50.0) ** 2) / math.sqrt(20.0 + (l_bar - 50.0) ** 2)
    sc = 1.0 + 0.045 * c_bar_p
    sh = 1.0 + 0.015 * c_bar_p * t
    rt = -math.sin(math.radians(2.0 * delta_theta)) * rc
    return math.sqrt((dlp / sl) ** 2 + (dcp / sc) ** 2 + (dHp / sh) ** 2
                     + rt * (dcp / sc) * (dHp / sh))


def roi_metrics(reference: List[bytes], current: List[bytes], roi: Roi,
                tolerance: Optional[float] = None) -> Dict[str, float]:
    """Per-ROI metrics; masked pixels are skipped and reported as coverage."""
    marks = masked_pixels(roi)
    ref_crop = crop(reference, roi.rect)
    cur_crop = crop(current, roi.rect)
    height = len(ref_crop)
    width = len(ref_crop[0]) // 3 if ref_crop else 0
    compared = 0
    abs_sum = 0
    max_abs = 0
    over_tolerance = 0
    delta_e_sum = 0.0
    delta_e_max = 0.0
    luma_ref: List[List[float]] = [[0.0] * width for _ in range(height)]
    luma_cur: List[List[float]] = [[0.0] * width for _ in range(height)]
    for py in range(height):
        ref_row, cur_row = ref_crop[py], cur_crop[py]
        for px in range(width):
            if marks.get((px, py)):
                continue
            base = px * 3
            ref_px = (ref_row[base], ref_row[base + 1], ref_row[base + 2])
            cur_px = (cur_row[base], cur_row[base + 1], cur_row[base + 2])
            diffs = [abs(float(ref_px[i]) - float(cur_px[i])) for i in range(3)]
            worst = max(diffs)
            abs_sum += sum(diffs) / 3.0
            max_abs = max(max_abs, worst)
            compared += 1
            if tolerance is not None and worst / 255.0 > tolerance:
                over_tolerance += 1
            delta_e = delta_e_2000(_srgb_to_lab(ref_px), _srgb_to_lab(cur_px))
            delta_e_sum += delta_e
            delta_e_max = max(delta_e_max, delta_e)
            luma_ref[py][px] = 0.2126 * ref_px[0] + 0.7152 * ref_px[1] + 0.0722 * ref_px[2]
            luma_cur[py][px] = 0.2126 * cur_px[0] + 0.7152 * cur_px[1] + 0.0722 * cur_px[2]
    if compared == 0:
        raise ParityError("ROI %s has no unmasked pixels" % roi.name)
    return {
        "pixels_compared": float(compared),
        "masked_ratio": 1.0 - compared / float(max(1, width * height)),
        "mean_abs_diff": abs_sum / compared,
        "max_abs_diff": max_abs,
        "pixel_mismatch_ratio": over_tolerance / compared if tolerance is not None else -1.0,
        "delta_e_mean": delta_e_sum / compared,
        "delta_e_max": delta_e_max,
        "ssim": ssim(luma_ref, luma_cur),
    }


def ssim(reference: List[List[float]], current: List[List[float]], window: int = 8) -> float:
    """Simplified windowed SSIM on luma; local implementation, not a reference one.

    Reported only as an auxiliary metric (plan section 9.2); a high value never
    authorises a pass.
    """
    height = len(reference)
    width = len(reference[0]) if height else 0
    if height == 0 or width == 0:
        raise ParityError("empty ROI in ssim")
    c1 = (0.01 * 255.0) ** 2
    c2 = (0.03 * 255.0) ** 2
    total = 0.0
    windows = 0
    for top in range(0, height, window):
        for left in range(0, width, window):
            values_ref: List[float] = []
            values_cur: List[float] = []
            for py in range(top, min(top + window, height)):
                for px in range(left, min(left + window, width)):
                    values_ref.append(reference[py][px])
                    values_cur.append(current[py][px])
            count = float(len(values_ref))
            if count < 2:
                continue
            mean_ref = sum(values_ref) / count
            mean_cur = sum(values_cur) / count
            var_ref = sum((v - mean_ref) ** 2 for v in values_ref) / (count - 1.0)
            var_cur = sum((v - mean_cur) ** 2 for v in values_cur) / (count - 1.0)
            covariance = sum((values_ref[i] - mean_ref) * (values_cur[i] - mean_cur)
                             for i in range(len(values_ref))) / (count - 1.0)
            numerator = (2.0 * mean_ref * mean_cur + c1) * (2.0 * covariance + c2)
            denominator = (mean_ref ** 2 + mean_cur ** 2 + c1) * (var_ref + var_cur + c2)
            total += numerator / denominator if denominator else 0.0
            windows += 1
    if windows == 0:
        raise ParityError("no SSIM windows could be formed")
    return total / windows


# ---------------------------------------------------------------------------
# 7. Verdicts: auxiliary only, never a global pass
# ---------------------------------------------------------------------------

FAIL = "FAIL"
UNMEASURED = "UNMEASURED_THRESHOLDS_NOT_FROZEN"
AUX_PASS = "AUX_METRIC_PASS_MANUAL_REVIEW_REQUIRED"
HIT_MATCH = "HIT_PROTOCOL_MATCH_NOT_VISUAL"
"""The hit/command contract matches. It is a protocol statement, never a visual
pass: plan section 9.4 still forbids claiming alignment without a device frame."""
HIT_NOT_COMPARED = "HIT_PROTOCOL_NOT_COMPARED"


def load_thresholds(path: Optional[str]) -> Optional[dict]:
    """A threshold file counts only when it is explicitly frozen."""
    if not path:
        return None
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if payload.get("frozen") is not True:
        return None
    for key in ("ssim_min", "delta_e_max", "pixel_tolerance"):
        if key not in payload:
            raise ParityError("frozen threshold file missing %r" % key)
        if "baseline" not in payload:
            raise ParityError("frozen threshold file must name the Qt baseline it was frozen on")
    return payload


def roi_verdict(metrics: Dict[str, float], thresholds: Optional[dict]) -> str:
    if thresholds is None:
        return UNMEASURED
    failures: List[str] = []
    if metrics["ssim"] < float(thresholds["ssim_min"]):
        failures.append("ssim")
    if metrics["delta_e_mean"] > float(thresholds["delta_e_max"]):
        failures.append("delta_e_mean")
    if metrics["pixel_mismatch_ratio"] > float(thresholds["pixel_tolerance"]):
        failures.append("pixel_mismatch_ratio")
    if failures:
        return FAIL
    return AUX_PASS


def overall_verdict(rows: Sequence[dict]) -> str:
    """Worst-of per-ROI verdicts. It is structurally impossible to return PASS.

    Plan section 9.2 forbids releasing a page on a global score; the strongest
    statement this tool may make is that the auxiliary metrics cleared their
    frozen thresholds and a human per-ROI review is still required.
    """
    if not rows:
        raise ParityError("no ROI rows: refusing to emit an overall verdict")
    verdicts = {row["verdict"] for row in rows}
    if FAIL in verdicts:
        return FAIL
    if UNMEASURED in verdicts:
        return UNMEASURED
    return AUX_PASS


def compare_case_hits(case: Case, reference_frame: Optional[dict] = None,
                      current_frame: Optional[dict] = None) -> Dict[str, object]:
    """Protocol-level hit comparison; needs no screenshot and no threshold.

    This is the part the plan section 9.1 item 3 gate can actually decide offline:
    six-field shape, fixed only on the PlayerBar tail, source order, label and
    geometry equality, and every ROI-declared action really reaching its ROI.
    A visual pass still needs a device frame (plan section 9.4).
    """
    reference_hits = list((reference_frame or {}).get("hits") or case.hits)
    current_hits = list((current_frame or {}).get("hits") or [])
    notes: List[str] = []
    if reference_hits:
        notes.extend(validate_hits(reference_hits, case.case_id + " reference",
                                  case.player_bar_hits))
    if current_hits:
        notes.extend(validate_hits(current_hits, case.case_id + " current",
                                   case.player_bar_hits))
    findings: List[Dict[str, object]] = []
    coverage: List[Dict[str, object]] = []
    for roi in case.rois:
        if not roi.expect_visible:
            continue
        for side, side_hits in (("reference", reference_hits), ("current", current_hits)):
            if not side_hits:
                continue
            result = roi_hit_coverage(roi, side_hits, case.case_id)
            coverage.append({"roi": roi.name, "side": side,
                             "expected": result["expected"],
                             "matched": result["matched"],
                             "findings": result["findings"]})
            findings.extend(result["findings"])
    if reference_hits and current_hits:
        diff = diff_hits(reference_hits, current_hits, case.case_id,
                         mode=case.hits_mode)
        findings.extend(diff["findings"])
        notes.extend(diff["notes"])
        if case.hits_mode == "subset" and case.hits_excluded:
            notes.append("%s: fixture hit subset excludes %s"
                         % (case.case_id, "; ".join(case.hits_excluded)))
    elif reference_hits:
        notes.append("%s: no current frame supplied, so no hit was compared; that is "
                     "not evidence of alignment (plan section 9.4)" % case.case_id)
    if findings:
        verdict = FAIL
    elif reference_hits and current_hits:
        verdict = HIT_MATCH
    else:
        verdict = HIT_NOT_COMPARED
    return {"mode": case.hits_mode, "scope": case.hits_scope,
            "excluded": list(case.hits_excluded),
            "reference_hits": len(reference_hits), "current_hits": len(current_hits),
            "findings": findings, "notes": notes, "coverage": coverage,
            "verdict": verdict}


def compare_case(case: Case, reference_path: str, current_path: str,
                 thresholds: Optional[dict], dpr: float,
                 reference_frame: Optional[dict] = None,
                 current_frame: Optional[dict] = None) -> Dict[str, object]:
    ref_w, ref_h, ref_rows = load_image(reference_path)
    cur_w, cur_h, cur_rows = load_image(current_path)
    if (ref_w, ref_h) != (cur_w, cur_h):
        raise ParityError("size mismatch: reference %dx%d vs current %dx%d "
                          "(comparison must stay in one coordinate system, plan section 2.4)"
                          % (ref_w, ref_h, cur_w, cur_h))
    metrics = metrics_from_physical(ref_w, ref_h, dpr)
    rows: List[Dict[str, object]] = []
    for roi in case.rois:
        if roi.space != "stage":
            raise ParityError("ROI %s: only stage space is frozen for landscape parity" % roi.name)
        mask_stats = validate_masks(roi)
        physical_rect = (
            metrics.stage_to_physical(roi.rect[0], roi.rect[1])
            + tuple(v * metrics.physical_per_stage for v in roi.rect[2:])
        )
        metrics_row = roi_metrics(ref_rows, cur_rows, roi,
                                  tolerance=float(thresholds["pixel_tolerance"])
                                  if thresholds else None)
        verdict = roi_verdict(metrics_row, thresholds)
        rows.append({
            "roi": roi.name,
            "source": roi.source,
            "stage_rect": list(roi.rect),
            "physical_rect": [round(v, 6) for v in physical_rect],
            "mask_area_ratio": mask_stats["mask_area_ratio"],
            "metrics": metrics_row,
            "verdict": verdict,
        })
    hits_report = compare_case_hits(case, reference_frame, current_frame)
    metric_verdict = overall_verdict(rows)
    protocol_failed = any(finding.get("severity") == "FAIL"
                          for finding in hits_report["findings"])
    overall = FAIL if protocol_failed else metric_verdict
    return {
        "case": case.case_id,
        "page": case.page,
        "state": case.state,
        "orientation": case.orientation,
        "physical": [ref_w, ref_h],
        "dpr": dpr,
        "stage_scale": metrics.stage_scale,
        "stage_width": metrics.stage_width,
        "thresholds_frozen": thresholds is not None,
        "thresholds": thresholds,
        "rois": rows,
        "hits": hits_report,
        "metric_verdict": metric_verdict,
        "overall": overall,
        "manual_review_required": True,
        "note": "auxiliary metrics only; the hit protocol verdict is deterministic but "
                "the per-ROI human comparison remains authoritative (plan section 9.1/9.2)",
    }


# ---------------------------------------------------------------------------
# 8. Self-check and CLI
# ---------------------------------------------------------------------------

def run_selfcheck() -> Dict[str, object]:
    """Pure in-process assertions, runnable only in a later authorised step."""
    checks: List[Dict[str, object]] = []

    def record(name: str, function) -> None:
        try:
            detail = function()
            checks.append({"check": name, "ok": True, "detail": detail})
        except Exception as error:  # noqa: BLE001 - report, do not abort the suite
            checks.append({"check": name, "ok": False, "detail": str(error)})

    record("stage_metrics", assert_device_metrics)
    record("text_baseline", lambda: text_baseline(115.425, 44.0))
    record("art_baseline", lambda: art_baseline(100.0, 20.0))
    record("calibrated_white", lambda: calibration_to_srgb(1.0))

    def hit_rules() -> Dict[str, object]:
        hits = [
            {"x": 0, "y": 0, "width": 44, "height": 48, "action": "player:prev",
             "label": "上一首", "fixed": True},
        ]
        notes = validate_hits(hits, "selfcheck")
        try:
            validate_hits([{"x": 1, "y": 1, "width": 1, "height": 1,
                            "action": "settings", "label": "设置", "fixed": True}], "selfcheck")
        except ParityError:
            pass
        else:
            raise ParityError("fixed:true outside PlayerBar was accepted")
        return {"notes": notes}

    record("hit_rules", hit_rules)

    def mask_rules() -> Dict[str, object]:
        roi = Roi("r", (0.0, 0.0, 100.0, 100.0), "test", masks=(
            Mask((0.0, 0.0, 40.0, 40.0), "justified", "file:1"),
        ))
        try:
            validate_masks(roi)
        except ParityError:
            return {"large_mask_rejected": True}
        raise ParityError("a 16% mask was accepted")

    record("mask_rules", mask_rules)

    def command_rules() -> Dict[str, object]:
        validate_commands([["fill", [0.9, 0.9, 0.9, 1, "calibratedRGB"], 0, 0, 1728, 1080],
                           ["path", "icon-arrow", 2, [0.13, 0.16, 0.14, 1]]])
        return {"notes": "short-tail path accepted"}

    record("command_rules", command_rules)

    def tail_rules() -> Dict[str, object]:
        page_hits = [
            {"x": 24, "y": 140, "width": 120, "height": 28, "action": "music:tab:0",
             "label": "歌曲"},
            {"x": 150, "y": 140, "width": 120, "height": 28, "action": "music:tab:1",
             "label": "专辑"},
        ]
        bar_hits = [
            {"x": 28, "y": 998, "width": 335.44, "height": 74, "action": "player:lyrics",
             "label": "当前歌曲歌词", "fixed": True},
            {"x": 775, "y": 1008, "width": 44, "height": 48, "action": "player:prev",
             "label": "上一首", "fixed": True},
            {"x": 1649, "y": 1000, "width": 54, "height": 65, "action": "player:open",
             "label": "播放队列", "fixed": True},
        ]
        frame = page_hits + bar_hits
        start = player_bar_segment_start(frame)
        if start != 2:
            raise ParityError("PlayerBar tail should start at 2, got %d" % start)
        validate_hits(frame, "selfcheck", player_bar_hits=3, require_fixed=True)
        refusal = []
        bad_tail = page_hits + [dict(hit, fixed=False) for hit in bar_hits]
        try:
            validate_hits(bad_tail, "selfcheck", require_fixed=True)
        except ParityError:
            refusal.append("tail_without_fixed")
        else:
            raise ParityError("a PlayerBar tail without fixed:true was accepted although "
                              "Qt always writes it (PlayerBar.cpp:46-53)")
        mixed = page_hits + [dict(bar_hits[0]), dict(bar_hits[1], fixed=False), bar_hits[2]]
        try:
            validate_hits(mixed, "selfcheck")
        except ParityError:
            refusal.append("mixed_fixed")
        else:
            raise ParityError("a PlayerBar tail mixing fixed and omitted fixed was accepted")
        page_fixed = [dict(page_hits[0], fixed=True)] + page_hits[1:] + bar_hits
        try:
            validate_hits(page_fixed, "selfcheck")
        except ParityError:
            refusal.append("page_fixed")
        else:
            raise ParityError("fixed:true outside the PlayerBar tail was accepted")
        try:
            player_bar_segment_start(frame, 2)
        except ParityError:
            refusal.append("declared_count_mismatch")
        else:
            raise ParityError("a wrong declared PlayerBar count was accepted")
        return {"tail_start": start, "refusals": refusal}

    record("tail_rules", tail_rules)

    def diff_rules() -> Dict[str, object]:
        base = [
            {"x": 0, "y": 978, "width": 1728, "height": 18,
             "action": "player:seek-fraction:0", "label": "播放进度", "fixed": True},
            {"x": 841, "y": 1009, "width": 46, "height": 46,
             "action": "player:toggle", "label": "暂停", "fixed": True},
        ]
        swapped = [base[1], base[0]]
        order = diff_hits(base, swapped, "selfcheck", mode="exact")
        if not any(item["kind"] == "hit_order" for item in order["findings"]):
            raise ParityError("a pure reordering was not reported as hit_order")
        shifted = [dict(base[0], x=12.0), base[1]]
        geometry = diff_hits(base, shifted, "selfcheck", mode="exact")
        if not any(item["kind"] == "hit_geometry" for item in geometry["findings"]):
            raise ParityError("a 12 stage-unit drift was not reported as hit_geometry")
        relabeled = [dict(base[0], label="进度"), base[1]]
        label = diff_hits(base, relabeled, "selfcheck", mode="exact")
        if not any(item["kind"] == "hit_label" for item in label["findings"]):
            raise ParityError("a label change was not reported as hit_label")
        missing = diff_hits(base, [base[0]], "selfcheck", mode="subset")
        if not any(item["kind"] == "hit_missing" for item in missing["findings"]):
            raise ParityError("a missing subset hit was not reported as hit_missing")
        excess = diff_hits(base, base + [dict(base[0], action="player:next",
                                            label="下一首")], "selfcheck", mode="subset")
        if excess["findings"]:
            raise ParityError("subset mode failed on an extra frame hit")
        return {"order": len(order["findings"]), "geometry": len(geometry["findings"]),
                "label": len(label["findings"]), "missing": len(missing["findings"])}

    record("diff_rules", diff_rules)

    def coverage_rules() -> Dict[str, object]:
        roi = Roi("bar", (0.0, 984.0, 1728.0, 96.0), "Qt/src/NativeHud.cpp:310",
                  expect_visible=("player:toggle", "music:like-current"))
        hits = [{"x": 841, "y": 1009, "width": 46, "height": 46,
                 "action": "player:toggle", "label": "暂停", "fixed": True}]
        result = roi_hit_coverage(roi, hits, "selfcheck")
        kinds = [item["kind"] for item in result["findings"]]
        if "expect_visible_missing" not in kinds:
            raise ParityError("a missing expected action was not reported")
        if result["matched"] != ["player:toggle"]:
            raise ParityError("a present expected action was not matched: %r" % result["matched"])
        outside = [{"x": 0, "y": 0, "width": 10, "height": 10,
                    "action": "player:toggle", "label": "暂停", "fixed": True}]
        result_outside = roi_hit_coverage(roi, outside, "selfcheck")
        if not any(item["kind"] == "expect_visible_outside_roi"
                   for item in result_outside["findings"]):
            raise ParityError("a hit outside its ROI was not reported")
        return {"kinds": kinds}

    record("coverage_rules", coverage_rules)
    return {"checks": checks, "all_passed": all(check["ok"] for check in checks)}


def load_frame(path: Optional[str]) -> Optional[dict]:
    """Load a frame envelope, or a bare hit array for convenience."""
    if not path:
        return None
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if isinstance(payload, list):
        return {"hits": payload}
    if isinstance(payload, dict):
        return payload
    raise ParityError("%s must hold a hit array or a frame object" % path)


def _iter_cases(args: argparse.Namespace) -> Iterable[Case]:
    cases = load_cases(args.cases)
    override = getattr(args, "player_bar_hits", None)
    if override is not None:
        for case in cases:
            case.player_bar_hits = int(override)
    return cases


def _hits_of(frame: Optional[dict], label: str) -> List[dict]:
    if not frame:
        raise ParityError("%s: no frame supplied" % label)
    hits = frame.get("hits")
    if not isinstance(hits, list) or not hits:
        raise ParityError("%s: frame carries no hits" % label)
    return hits


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="compare.py",
        description="Per-ROI landscape parity comparator; auxiliary metrics plus the "
                    "frozen hits/commands protocol gate.")
    parser.add_argument("--dpr", type=float, default=DEVICE_DPR,
                        help="device pixel ratio; defaults to the reference device %.5f" % DEVICE_DPR)
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("selfcheck", help="run the in-process contract self-checks")

    compare = subparsers.add_parser(
        "compare",
        help="compare reference vs current screenshots plus optional frame hits")
    compare.add_argument("--ref", required=True, help="reference PNG/PPM (Qt capture)")
    compare.add_argument("--cur", required=True, help="current PNG/PPM (Flutter capture)")
    compare.add_argument("--cases", required=True)
    compare.add_argument("--ref-hits", default=None,
                         help="reference frame JSON (a frame object or a bare hit array)")
    compare.add_argument("--cur-hits", default=None,
                         help="current frame JSON; without it no hit is compared")
    compare.add_argument("--player-bar-hits", type=int, default=None,
                         help="PlayerBar tail length when the cases do not declare it")
    compare.add_argument("--thresholds", default=None,
                         help="frozen threshold JSON; without it every metric verdict is %s"
                         % UNMEASURED)
    compare.add_argument("--out", default=None)

    hits_parser = subparsers.add_parser(
        "validate-hits", help="validate a hits JSON array (a frame object also works)")
    hits_parser.add_argument("--json", required=True)
    hits_parser.add_argument("--player-bar-hits", type=int, default=None)
    hits_parser.add_argument("--require-fixed", choices=("yes", "no"), default=None,
                             help="demand or forbid fixed:true on the PlayerBar tail")

    diff_parser = subparsers.add_parser(
        "diff-hits", help="compare two hit lists field by field, in source order")
    diff_parser.add_argument("--ref", required=True)
    diff_parser.add_argument("--cur", required=True)
    diff_parser.add_argument("--mode", choices=HIT_COMPARE_MODES, default="exact")
    diff_parser.add_argument("--tolerance", type=float, default=HIT_GEOMETRY_TOLERANCE)
    diff_parser.add_argument("--out", default=None)

    args = parser.parse_args(argv)

    if args.command == "selfcheck":
        report = run_selfcheck()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["all_passed"] else 1

    if args.command == "validate-hits":
        reference = load_frame(args.json)
        hits = _hits_of(reference, args.json)
        require_fixed = None if args.require_fixed is None else args.require_fixed == "yes"
        notes = validate_hits(hits, args.json, args.player_bar_hits, require_fixed)
        print(json.dumps({"hits": len(hits), "notes": notes}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "diff-hits":
        report = diff_hits(_hits_of(load_frame(args.ref), args.ref),
                           _hits_of(load_frame(args.cur), args.cur),
                           args.cur, args.tolerance, args.mode)
        text = json.dumps(report, ensure_ascii=False, indent=2)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as handle:
                handle.write(text + "\n")
        print(text)
        return 0 if not report["findings"] else 2

    thresholds = load_thresholds(args.thresholds)
    if thresholds is None:
        print("thresholds not frozen: every metric verdict will be %s "
              "(plan section 9.2)" % UNMEASURED, file=sys.stderr)
    reference_frame = load_frame(args.ref_hits)
    current_frame = load_frame(args.cur_hits)
    if current_frame is None:
        print("no --cur-hits: hit protocol not compared; this is not evidence of "
              "alignment (plan section 9.4)", file=sys.stderr)
    reports = [compare_case(case, args.ref, args.cur, thresholds, args.dpr,
                            reference_frame, current_frame)
               for case in _iter_cases(args)]
    payload = {
        "tool": "tool/parity/compare.py",
        "mode": "auxiliary-per-roi-plus-hit-protocol",
        "thresholds_frozen": thresholds is not None,
        "hit_protocol_compared": current_frame is not None,
        "reports": reports,
    }
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    print(text)
    return 0 if all(report["overall"] != FAIL for report in reports) else 2


if __name__ == "__main__":
    raise SystemExit(main())
