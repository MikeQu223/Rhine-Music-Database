# tool/perf — Flutter 帧时间采集与导出（T52-C18，接管 T52-S01-M12 草稿）

> **状态：源码已写，从未执行。** 本目录新增的 `collect_frame_times.dart` 在 T52-C18
> 中未运行过（`dart analyze` / `dart run` / `flutter …` / Gradle / adb 全部禁止），
> 仓库里没有任何真实样本，也没有任何报告产物。因此：**不得引用本工具宣称任何帧率、
> p95、jank 或性能对齐结论。** 记录的只有“怎么采、采到什么形状、哪些字段必须带”。

## 1. 这个工具是什么，不是什么

| 是 | 不是 |
| --- | --- |
| 离线把一份 JSONL 采集（真实 `FrameTiming` 字段）折算成一份可复核的 JSON 报告 | 不是 CI 性能门，不产出通过/失败 |
| 把**来源、窗口、单位、未测状态**写进报告，缺一项就标 `provenance.gaps` | 不是阈值判定器，不内置 60 fps / 16.6 ms / jank 1% |
| 只依赖 `dart:` 库（`dart:io` / `dart:convert` / `dart:math`），未来可 `dart run` 直接跑 | 不是生产采集代码，**不接应用启动路径** |
| 排除非 active app 样本、可裁剪热身窗口 | 不把协议/内存上限（如 Node 堆 48 MiB）当性能阈值 |

阈值口径来自计划：
`docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md` §9.2 —— 所有性能比例
（以及 SSIM/ΔE）都是**拟议辅助指标**，必须用 Qt 同设备同场景基线冻结后才可写入验收；
§9.4 进一步禁止把未取证的东西写成结论。

## 2. 为什么口径必须跟 Qt 对齐

Qt 侧已有实测脚手架 `tools/perf/`（`bench2.sh` / `analyze2.py` / `README.md`），它给出的
口径是本次 Flutter 采集的唯一参照：

- **内容帧/s = `节拍诊断` 的 `render/s`（`Engine::m_renderFrames`）**，即画面内容真正
  更新的次数，才是流畅度的正确口径。
- **上屏 presented 会高估**：`fg=off` 时 Vulkan 的 presented ≈ 内容帧 × 1.86
  （同一内容被重录重渲多次），拿 presented 当帧率是错的。
  证据：`tools/perf/README.md:13-23`。
- 场景脚本的真实顺序（每一步都是脚本里的动作，不是描述性概括）：启动 → 等首条
  `节拍诊断` → **热身 5 s**（`WARMUP` 默认 5）→ 聚焦窗口 → `ESC` 关设置弹窗 →
  `→` 切「收藏专辑」(COLLECTION 04，98 条，列表循环不会滚到头) → `F11` 全屏 →
  按住 ↓ 20 s → 截图 → 杀进程。
  证据：`tools/perf/bench2.sh:37-55`、`tools/perf/README.md:53-55`、
  `tools/perf/README.md:65-69`。
- 注意热身的位置：它在**所有交互动作之前**，是启动后的墙钟前置段（`bench2.sh:38`）。
  热身锚点是**首条 `节拍诊断`（≈首帧）**，不是脚本/App 启动时刻：
  - 给了 `meta.captureWindow` 时，`startWallUs` 必须钉在首条 `节拍诊断`（或首帧）那一刻，
    再设 `warmupUs = 5000000`。若把 `startWallUs` 取成脚本启动（含 App 冷启动），
    裁剪段就变成 [启动, +5 s]，与 Qt 的 [首条诊断, +5 s] 差一个启动时长，保留窗口起点不同源。
  - 不给 `captureWindow` 时，工具用帧墙钟 `min(rasterFinishWallUs)` 推导起点（≈首帧），
    天然以首帧为热身锚点，反而更接近 Qt；此时不要再把“脚本启动”当参照。
  - 把热身写成“切场景之后”会得到错误的裁剪点。
- 静止时低帧率是**正常现象**（原 Qt 按需绘制），不能据此判 jank。

Flutter 的 `FrameTiming` 是引擎帧，它与 Qt 的“内容帧”是否一一对应**没有验证过**，
所以本工具输出的帧率字段叫 `engineFramesPerSecond`，并在 `rate.note` 与
`comparison.equivalence` 里写明“未证明等价”。同设备同场景对比时，比的应该是
**同一段动作脚本下的帧间隔分布**，而不是把两个 fps 数字直接相减。

## 3. 输入：`rhine.frame-timings.samples/1`（JSONL）

一行一个 JSON 记录；空行与 `#` 开头的行忽略（便于人工加注释）。

### 3.1 `meta` 记录（必须有且只有一条）

```json
{
  "type": "meta",
  "schema": "rhine.frame-timings.samples/1",
  "recorder": {
    "api": "SchedulerBinding.instance.addTimingsCallback",
    "buildMode": "debug",
    "flutterVersion": "3.x.y",
    "engineCommit": "optional"
  },
  "device": { "model": "…", "androidApi": 34, "soc": "…" },
  "app": { "applicationId": "rhine.music.database", "versionName": "1.0.0", "buildMode": "debug" },
  "scene": {
    "id": "collection04_hold_down_20s",
    "description": "热身5s → ESC关设置弹窗 → →切收藏专辑(98条) → F11全屏 → 长按↓20s",
    "script": "见 tools/perf/README.md:53-55"
  },
  "captureWindow": { "startWallUs": 0, "endWallUs": 0 },
  "warmupUs": 5000000,
  "notes": "free text"
}
```

| 字段 | 必需 | 作用 |
| --- | --- | --- |
| `recorder.api` / `recorder.buildMode` | 建议 | 证明采集 API 与调试构建；缺 `buildMode:"debug"` 会进 `provenance.gaps` |
| `recorder.flutterVersion` | 建议 | 引擎差异会影响帧时间，缺了报告不完整 |
| `device` | 建议 | **同设备对比的前提**；缺了写不了 Qt 对照 |
| `app` | 建议 | 构建身份（versionName/versionCode/buildMode） |
| `scene.id` + `scene.description` | 建议 | 分布必须绑定到一段脚本化场景，否则数字无意义 |
| `captureWindow` | 可选 | 墙钟窗口（µs），两端 `startWallUs` + `endWallUs` **必须同时给**（全有全无）。缺一或整体缺省时用帧 `rasterFinishWallUs` 的 min/max 推导；`window.source` ∈ `meta.captureWindow` / `derived_from_rasterFinishWallUs` / `unavailable`。块存在但不是 JSON 对象时直接 exit 3 |
| `warmupUs` | 可选 | 热身裁剪；缺省 0 = 不裁剪，同时进 `gaps` |

`schema` 若存在且不等于 `rhine.frame-timings.samples/1`，工具直接以 exit 3 拒绝（版本契约）。

### 3.2 `frame` 记录（一帧一条）

```json
{"type":"frame","vsyncStartUs":0,"buildStartUs":900,"buildFinishUs":4200,
 "rasterStartUs":4300,"rasterFinishUs":9800,"rasterFinishWallUs":1730000000000,
 "appState":"active"}
```

字段与 Flutter `FrameTiming` 的对应关系（单位统一为**微秒**，即
`timestampInMicroseconds(...)` 的原值）：

| JSONL 字段 | FrameTiming 来源 | 必需 |
| --- | --- | --- |
| `vsyncStartUs` | `FramePhase.vsyncStart` | 是 |
| `buildStartUs` | `FramePhase.buildStart` | 是 |
| `buildFinishUs` | `FramePhase.buildFinish` | 是 |
| `rasterStartUs` | `FramePhase.rasterStart` | 是 |
| `rasterFinishUs` | `FramePhase.rasterFinish` | 是 |
| `rasterFinishWallUs` | `FramePhase.rasterFinishWallTime` | 否（缺则窗口退化为不可用/推导） |
| `appState` | `WidgetsBinding.instance.lifecycleState` 折算为 `active`/`inactive` | 否，但强烈建议 |
| `type` | 字面量 `"frame"` | 否；**缺键**按 frame 处理。键存在但不是字符串 → `record_type_is_not_a_string`；是字符串但不是 `frame`/`meta` → `unknown_record_type` |

派生量由工具计算，**不要求输入**，也不假设跨阶段交错：

```
buildUs        = buildFinishUs - buildStartUs
rasterUs       = rasterFinishUs - rasterStartUs
totalSpanUs    = rasterFinishUs - vsyncStartUs
vsyncOverheadUs= buildStartUs - vsyncStartUs
```

任一派生量为负 → 该行记 `non_monotonic_phase_span` 并剔除（报告 `counts.invalid` 里留证据，
最多 8 条样例）。无效行的 `reason` 是**固定键**（这样 `byReason` 才能跨次聚合），可变文本
一律进 `detail`，样例里另带 `recordIndex`（跳过空行/注释后的记录序号，不是物理行号）：

| `reason` | 含义 |
| --- | --- |
| `json_parse_error` | 该行不是合法 JSON；`detail` = 解析器消息 |
| `record_is_not_a_json_object` | JSON 合法但不是对象（数组/标量） |
| `record_type_is_not_a_string` | 有 `type` 键但不是字符串（如 `type: 5`）；只有**缺键**才按 `frame` 处理 |
| `duplicate_meta_record` | 第二条 `meta` |
| `unknown_record_type` | `type` 既非 `meta` 也非 `frame`；`detail` = 原值 |
| `missing_or_non_integer_phase_timestamp` | 五个相位时间戳缺一或非整数 |
| `non_monotonic_phase_span` | 任一派生量为负 |

这七个固定键在 `counts.invalid.byReason` 里**始终存在**（没出现就是 `0`），
所以多份报告可以按 reason 直接相加，不需要补键。

## 4. 输出：`rhine.frame-timings.report/1`

报告是**一份 JSON**，字段顺序固定（便于 diff），要点：

| 区块 | 关键字段 | 说明 |
| --- | --- | --- |
| `tool` | `path` / `revision` / `atom` / `plan` / `planSection` | 来源：哪个工具、哪条计划的哪一节 |
| `input` | `path` / `bytes` / `linesRead` / `encoding` / `samplesSchema` | 输入指纹（**不含哈希**：本工具不引第三方包） |
| `scene` | `id` / `description` / `source` | `source` ∈ `meta` / `cli_label_override` / `missing` |
| `measurement` | `status` / `thresholds` / `deviceGate` / `productionWiring` | **未测状态就在这里** |
| `window` | `source` / `startWallUs` / `endWallUs` / `spanMs` / `unit` / `warmupUs` / `warmupTrimApplied` | `warmupTrimApplied` 只在热身**真的裁掉了帧**（`droppedWarmup + droppedWarmupUnknownWall > 0`）时为 `true`；规则启用但没裁到帧是 `false`，数量看 `counts.droppedWarmup*` |
| `counts` | `framesKept` / `dropped*` / `appStateCounts` / `invalid` / `metaRecordsUsed` | 每条丢弃都有理由字段；`metaRecordsUsed` 恒为 1（重复 `meta` 会被判无效） |
| `distribution` | `buildMs` / `rasterMs` / `totalSpanMs` / `vsyncOverheadMs` | 每个阶段 count/min/p50/p90/p95/p99/max/mean/stdDev/sum |
| `rate` | `engineFramesPerSecond` / `busyRatio` / `spanUs` / `spanMs` / `spanBasis` / `framesInRate` / `note` | 分母来源写在 `spanBasis`；`framesInRate` 是分子：`kept_frame_wall_span` 时只数带墙钟保留帧（与分母同批），`capture_window` 时是全部保留帧（分母含被裁帧，所以不同批），见下方说明 |
| `provenance` | `complete` / `gaps` / `recorder` / `device` / `app` / `scene` / `activeOnlyFilter` / `appStateCounts` | 缺证据就 `complete:false` 并逐条列出；`scene` 原样回显 meta 里的块 |
| `comparison` | `available` / `deltaMs` / `ratio` / `verdict` | `verdict` 恒为 `NOT_EVALUATED` |
| `nonClaims` | 字符串数组 | 报告自带“不能宣称什么” |
| `capture` | 原始 `meta` | 原样回显，便于审计 |

`measurement` 的取值是硬约定：

```json
{
  "status": "NO_VALID_SAMPLES | SAMPLED_UNFROZEN",
  "thresholds": { "frozen": false, "evaluated": false,
                  "provenance": "…plan §9.2…", "reuseForbidden": ["…48 MiB…"] },
  "deviceGate": "DEVICE_BLOCKED",
  "productionWiring": "NOT_WIRED",
  "captureMode": "debug-only; non-active-app samples excluded"
}
```

- `frozen/evaluated` 永远是 `false`：**没有阈值可判**，也没有 Qt 基线。
- `deviceGate: DEVICE_BLOCKED`：真机采集与像素/性能验收仍未做，本工具不会替它开门。
- `sampled` 只表示“有样本可读”，不等于“达标”。

### 4.1 统计口径（可手工复核）

- 单位：内部微秒，输出毫秒，3 位小数（1 µs 分辨率）。`distribution.unit = "ms"`，
  `sourceUnit` 的字面量是 `us (dart:ui FrameTiming.timestampInMicroseconds)`——
  说明原始时间戳取自 `dart:ui` 的微秒字段，不是自造时钟。
- 百分位：**线性插值**，`rank = (n-1)*q`，在升序数组上取相邻两名插值；
  `p50 = q0.50`、`p90 = q0.90`、`p95 = q0.95`、`p99 = q0.99`。
- 标准差：**总体**（除以 n），不是样本标准差。
- 速率分母 `span`：**优先用保留帧自身的墙钟跨度**（`max(rasterFinishWallUs) -
  min(rasterFinishWallUs)`，记 `spanBasis: "kept_frame_wall_span"`）；样本没有墙钟
  或跨度不为正时，退化为采集窗口 `windowSpanUs`（`spanBasis: "capture_window"`），
  两者都不可得则 `spanBasis: "unavailable"` 且速率字段为 null。
  这样在裁掉热身后，分子（保留帧数）与分母（这些帧的时间跨度）描述的是同一批帧；
  若用含热身的窗口做分母，热身期的帧被剔掉却仍占时间，速率会被系统性低估。
- `busyRatio = Σ totalSpanUs / span`：可 >1（相邻帧跨度重叠），**只作负载描述**；
  静止时它很低是正常的，不代表掉帧。分子是**全部保留帧**的 `totalSpanUs` 之和
  （含没有墙钟的帧），分母见 `spanBasis`，两者子集可能不同（`kept_frame_wall_span`
  的分母只覆盖带墙钟帧），所以它是负载描述而不是严格占空比。
- `engineFramesPerSecond = framesInRate * 1e6 / span`：引擎帧产出率，
  **不等于** Qt 的 `render/s` 内容帧口径（见 §2）。分子默认等于 `framesKept`；
  当 `spanBasis = kept_frame_wall_span` 时只数**带墙钟**的保留帧，避免分母只覆盖部分帧
  而分子全算导致偏高。
- 小数位：毫秒类 3 位（1 µs 分辨率），`engineFramesPerSecond` 3 位，`busyRatio` 与
  `ratio` 4 位；`null` 表示该量不可计算，不是 0。
- `spanBasis = capture_window` 时，被热身裁掉的帧仍占窗口时间，`engineFramesPerSecond`
  与 `busyRatio` **都会**被系统性低估（不只是速率）。
- 边界 `n == 1`：百分位与 min/max 都等于该帧，`stdDev = 0`；单帧自身跨度为 0，
  所以速率只能靠 `captureWindow`，没有窗口则 `spanBasis = unavailable` 且速率为 `null`。
- 边界 `n == 0`（保留帧为空：全被热身裁掉、全非 active、或全缺墙钟）：`status` 为
  `NO_VALID_SAMPLES`，`rate.engineFramesPerSecond` 与 `rate.busyRatio` 都是 `null`——
  **不写 0.0**，零样本不能被读成“测得 0 fps”。`spanUs`/`spanMs`/`spanBasis` 仍会给出，
  因为它们描述的是采集窗口而不是样本；此时 `framesInRate = 0`。
- 偏差提示：速率是“帧数 ÷ 首末墙钟跨度”，跨度只覆盖 n−1 个帧间隔，因此读数比
  “帧间隔均值的倒数”高约 n/(n−1)（n=10 约 11%，n=1200 约 0.08%）。短采集对比时
  要记住这个量级，也不要拿它和 Qt 的 `render/s` 直接相减。

### 4.2 窗口与热身裁剪算法（照此实现，无隐藏分支）

窗口是**全有全无**：`meta.captureWindow` 的 `startWallUs` 与 `endWallUs` 都给出才
用 meta，缺任何一个就两端一起丢弃、改用帧墙钟的 min/max。不做逐字段回退：
一端来自 meta、另一端来自数据时会形成混合时间基准，跨度不再是同一口径，
且 `window.source` 会与事实不符。

```
if meta.captureWindow.startWallUs != null and meta.captureWindow.endWallUs != null:
    windowStart    = meta.captureWindow.startWallUs
    windowEnd      = meta.captureWindow.endWallUs
    windowFromMeta = true
else:
    windowStart    = min(frame.rasterFinishWallUs)
    windowEnd      = max(frame.rasterFinishWallUs)
    windowFromMeta = false
warmupUs    = --warmup-ms*1000 ?? meta.warmupUs ?? 0   # 必须 ≥ 0，负值直接报错
cutoff      = windowStart + warmupUs
逐帧（按文件顺序）：
  1) warmupUs > 0 时：帧无 rasterFinishWallUs 或 cutoff 不可得 → droppedWarmupUnknownWall
                     帧 wall < cutoff                                  → droppedWarmup
  2) appState 存在且 != "active"                                      → droppedInactiveAppState
  3) appState 缺失且给了 --active-only                                 → droppedMissingAppState
  4) 其余进入统计
windowSpanUs = (windowEnd > windowStart) ? windowEnd - windowStart : null

# 速率分母（在保留帧集合上再算一次，避免热处理后分子/分母不同源）
keptMinWall  = min(kept.rasterFinishWallUs)   # 只含有墙钟的保留帧
keptMaxWall  = max(kept.rasterFinishWallUs)
span         = (keptMaxWall > keptMinWall) ? keptMaxWall - keptMinWall
                                            : windowSpanUs
spanBasis    = span 来自保留帧 ? "kept_frame_wall_span"
             : span 来自窗口 ? "capture_window" : "unavailable"
```

裁剪顺序是固定的（热身 → 状态 → 缺失），因此同一输入的报告可复现；
唯一非确定字段是 `generatedAtUtc`。

## 5. 采集片段（未来用，**未接入任何生产路径**）

下面只是文档里的参考实现，**没有**写进 `lib/`，也**没有**在应用启动时注册。
理由：非 active app 的帧没有结论价值，生产埋点会污染功耗与帧时间，也违反本轮的
“非activeapp不接生产”约束。

```dart
// 仅示意，不是可直接编译的成品：
//  - 需要 WidgetsFlutterBinding.ensureInitialized() 之后才注册；
//  - _frameTrace 必须有界（示例未加上界，长跑会撑爆内存），到量就落盘/轮转；
//  - scheduler 的 import 省略（package:flutter/scheduler.dart）。
// 仅调试构建 + 显式开关（例如 --dart-define=RHINE_FRAME_TRACE=1）。
// 不要放进 main()、不要放进任何生产 initState。
import 'dart:convert';

final List<String> _frameTrace = <String>[];

void startFrameTimingCapture() {
  SchedulerBinding.instance.addTimingsCallback((List<FrameTiming> timings) {
    final AppLifecycleState? state = WidgetsBinding.instance.lifecycleState;
    final String appState = state == AppLifecycleState.resumed ? 'active' : 'inactive';
    for (final FrameTiming timing in timings) {
      _frameTrace.add(jsonEncode(<String, Object?>{
        'type': 'frame',
        'vsyncStartUs': timing.timestampInMicroseconds(FramePhase.vsyncStart),
        'buildStartUs': timing.timestampInMicroseconds(FramePhase.buildStart),
        'buildFinishUs': timing.timestampInMicroseconds(FramePhase.buildFinish),
        'rasterStartUs': timing.timestampInMicroseconds(FramePhase.rasterStart),
        'rasterFinishUs': timing.timestampInMicroseconds(FramePhase.rasterFinish),
        'rasterFinishWallUs': timing.timestampInMicroseconds(FramePhase.rasterFinishWallTime),
        'appState': appState,
      }));
    }
  });
}
```

落盘方式（adb pull / 应用内导出 / `run-as`）由未来的设备授权决定，本工具不关心，
只要最终是一份 JSONL。若某个 SDK 版本没有 `FramePhase.rasterFinishWallTime`，
该字段留空即可，窗口改由 `meta.captureWindow` 提供。

## 6. 用法（未来模板，本轮不执行）

```bash
# 分析一份采集（stdout）
dart run tool/perf/collect_frame_times.dart --input /tmp/frames.jsonl

# 写文件 + 标注场景 + 丢掉热身
dart run tool/perf/collect_frame_times.dart \
  --input /tmp/frames.jsonl --out /tmp/report.json \
  --label collection04_hold_down_20s --warmup-ms 5000 --active-only

# 与另一份同 schema 报告做描述性对比（不给结论）
dart run tool/perf/collect_frame_times.dart \
  --input /tmp/new.jsonl --out /tmp/new.json --baseline /tmp/old.json
```

退出码：`0` 产出报告，`2` 用法错误，`3` 输入/内部错误（缺 `meta`、schema 版本不符、文件不存在）。

## 7. 明确不做的事（硬约束）

| 禁止 | 原因 |
| --- | --- |
| 输出 p95/帧率“通过/不通过” | 计划 §9.2：阈值未冻结；本工具连阈值参数都不接受 |
| 把 48 MiB Node 堆等协议/内存上限当帧时间阈值 | 那是契约边界，不是性能门；报告 `thresholds.reuseForbidden` 明写 |
| 用 `presented` 口径算帧率 | Qt 侧已证明 fg=off 下会高估 ≈1.86×（`tools/perf/README.md:22-23`） |
| 把静止低 fps 判为 jank | 原 Qt 按需绘制，静止低帧率正常 |
| 把 Flutter 引擎帧率直接当 Qt 内容帧/s | 等价性未验证，报告里标 `UNVERIFIED` |
| 在应用生产路径注册采集 | 非 active app 不接生产；采集仅限调试构建 + 显式开关 |
| 用本工具的报告替代真机验收 | `deviceGate: DEVICE_BLOCKED`，DEVICE_BLOCKED 只能由真机采集解除 |

## 8. 与 Qt 对比的前置条件（现在还不可用）

1. Qt 侧目前**没有** `rhine.frame-timings.report/1` 导出器：`tools/perf/` 输出的是
   `节拍诊断` 文本行与 `FG diag` 行（`tools/perf/README.md:98-108`），不是本 schema。
   未给 `--baseline` 时，报告的 `comparison.qtAdapter` 字段如实写 `NOT_IMPLEMENTED`。
2. `--baseline` 只接受**同 schema** 的报告：`schema` 不等于
   `rhine.frame-timings.report/1` 时直接返回 `available: false` +
   `reason: baseline schema mismatch`（不会拿旧格式硬比）。同 schema 但
   `distribution.totalSpanMs` 连 `p50Ms`/`p95Ms` 都没有时，也返回
   `available: false`，`reason` 明说缺的是基线指标，而不是“没有阈值”。
   `comparison` 的形状是**固定**的：八键
   `available/path/baselineSchema/metric/deltaMs/ratio/verdict/reason` **总是存在**，
   不可比时 `deltaMs` 与 `ratio` 为 `null`、`verdict` 恒为
   `NOT_EVALUATED`；只有“未给 `--baseline`”这一种不可比情形会额外带
   `qtAdapter: NOT_IMPLEMENTED…` 说明。可比时 `deltaMs` 与 `ratio` 是
   **对象**且各含 `p50`/`p95` 两个键：`deltaMs.p95 = current.p95Ms − baseline.p95Ms`
   （正数表示本次比基线大/更慢），`ratio.p95 = current.p95Ms / baseline.p95Ms`
   （基线为 0 或任一缺失时为 `null`），`p50` 同理；`metric` 恒为
   `distribution.totalSpanMs`，具体比的是它下面的 `p50Ms`/`p95Ms`。可比时还会附
   `equivalence: UNVERIFIED…`，明说 Qt 内容帧/s 与 Flutter 引擎帧不等价。
3. 同设备对照还要求：同一台 Android 设备、同一场景脚本（§2）、Qt 与 Flutter 都跑满
   同一段动作；桌面 `tools/perf/`（niri/grim/uinput）那套不等价于 Android 真机。
4. 现状：`deviceGate = DEVICE_BLOCKED`，**没有**任何同设备样本，因此没有对比结论。

## 9. 未执行验证记录（RED/GREEN 均未执行）

| 项 | 状态 |
| --- | --- |
| `dart analyze tool/perf/collect_frame_times.dart` | 未执行（本轮禁止） |
| `dart run tool/perf/…` | 未执行（本轮禁止） |
| `flutter test` / `flutter build` / `gradle` / `adb` | 未执行（本轮禁止） |
| 真实设备采集 | 未做（无授权、无真机会话） |
| 单元测试 | 未新增（本轮写域只有采集器与文档，且不得执行测试） |

因此本工具的正确性只经过**独立只读审查**（读 diff 与契约），没有运行时证据。
任何“跑通了 / p95 是多少”的说法都必须是未来某次被授权的真机会话的产物。

## 10. 边界与计划映射

- 本卡（T52-C18，接管 T52-S01-M12 草稿）共写三个文件，分属两个原子：
  `tool/perf/collect_frame_times.dart` 与 `tool/perf/README.md` 属采集器原子
  T52-C18-A1；`docs/flutter-migration/03-performance.md` 属文档原子 T52-C18-A2
  （未测量的基线方案台账）。
- 分工不重叠：本 README 只描述采集器契约与用法；指标状态、未测项与门状态在
  `docs/flutter-migration/03-performance.md`，本文件不替它下任何结论。
- 计划映射：`docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md` 的
  “T52 性能与稳定性基线”卡（Files 段列本工具与 README）与 §9.2（拟议指标待冻结）、
  §9.4（不得宣称未取证结论）。
- 旧 Qt 脚手架 `tools/perf/`（注意是复数 `tools`）保持只读，未改一行；
  本目录 `tool/perf/`（单数）是 Flutter 侧新增。
