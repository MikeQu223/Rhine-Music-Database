// web/rhine_replica/three_scene.js
// T15-C18-A2 (plan T15 candidate E) — 本地 WebView 切片真实 Three.js 3D 场景。
// 唯一 route: provider="vclib-cn" / model="deepseek-v4.1-flash" / reasoning_effort="max"。
//
// 规格来源: Qt 是规格 (Qt/src/*), 本文件只“重推导”同一批常数, 绝不发明协议。
// 每一条常数都在行尾或上方标注 Qt 行号。没有 Qt 证据的地方显式写 “无证据(缺口)”。
//
// ================= 证据表 (常数 -> Qt 行号) =================
// near/far = 5/300                Qt/src/NativeScene.cpp:52, :267 ; NativeSceneCamera.cpp:98
// AO 视锥 fov 34deg               Qt/src/NativeScene.cpp:52, :267  (Matrix::perspective(34, w/h, 5, 300))
// perspective 公式                Qt/src/SceneMath.cpp:64-78
//   top = near*tan(pi/180*0.5*fov) ; height = 2*top ; width = aspect*height
//   left = -0.5*width ; right = left+width ; bottom = top-height
//   x = 2n/(r-l) ; y = 2n/(t-b) ; a = (r+l)/(r-l) ; b = (t+b)/(t-b)
//   c = -(f+n)/(f-n) ; d = -2fn/(f-n) ; 列主序 {{x,0,0,0, 0,y,0,0, a,b,c,-1, 0,0,d,0}}
// Matrix::camera(pos,target)      Qt/src/SceneMath.cpp:79-95  (up={0,1,0}, 与 three lookAt 等价)
// 列主序 values[column*4+row]     Qt/src/SceneMath.cpp:96-108 (multiply), :158-164 (point)
// camera 姿态 (yaw/elevation/aim) Qt/src/NativeSceneCamera.cpp:14-25
// cinema 分支                     Qt/src/NativeSceneCamera.cpp:26-54
// span/distance 推导              Qt/src/NativeSceneCamera.cpp:21-22, :58-83, :92-93
// fov = 2*atan(desiredSpan/(2*distance))  Qt/src/NativeSceneCamera.cpp:93
// fov 平滑 blend=1-exp(-seconds*5)        Qt/src/NativeSceneCamera.cpp:89-91
// renderedDistance = |eye-aim|            Qt/src/NativeSceneCamera.cpp:94
// fogNear/fogFar                          Qt/src/NativeSceneCamera.cpp:96-97
// projection = perspective(fov,aspect,5,300)  Qt/src/NativeSceneCamera.cpp:98
// archiveOffset = (cinema || mode=="boot") ? 0 : 1-detailProgress
//                                         Qt/src/NativeSceneCamera.cpp:100-101
//   detailProgress = smooth((detail-0.25)/0.55)
//   values[8] += 0.16*archiveOffset        Qt/src/NativeSceneCamera.cpp:102
//   values[9] += 0.20*archiveOffset        Qt/src/NativeSceneCamera.cpp:103
//   写入 w=-z 投影的 x/y 平移, 无剪切 (见本文件 projectionMatrixQt 注释)
// 视锥裁剪 (visibleCells)                 Qt/src/NativeSceneCamera.cpp:113-140
//   projection = perspective(fov, w/h, 5, min(300, max(6, fogFar+8)))  :115
//   values[0] /= 1.18 ; values[5] /= 1.18                              :116-117
//   values[8]/[9] 复用真实投影偏移                                     :119-120
//   卡片 AABB 相对 cell position: +-2.8 / +-6.5 / +-1.2                :111, :119-140
// cellPosition(cell) = {(lane-2)*5.2, -4.6, (row-15.5)*0.62}   Qt/src/NativeScene.cpp:76-78
// 固定模式网格 cells {index/32, index%32}                       Qt/src/NativeSceneUpdate.cpp:233-234
// 卡片旋转 matrix=compose(pos,{slope*0.024*(1-m_detail),0,0})    Qt/src/NativeSceneUpdate.cpp:263-264
// Actor 默认 cell {2,12}                                       Qt/src/NativeScene.h:83-96
// field() 默认恒 0 (scanBlend=0,idleGain=0)                      Qt/src/SceneMotion.h:33-45 ; SceneMotion.cpp:123-147
// floor: compose({0,-4.63,0},{-pi/2,0,0}), roughness 0.95       Qt/src/NativeSceneFrame.cpp:62 ; SceneAppearance.cpp:225-258
// 阴影光位置 {-6,14,-5}                                          Qt/src/NativeSceneFrame.cpp:123
// 光学点光 colour {1,0.72,0.38}, decay 0.62                      Qt/src/RhiScene.cpp:1405, :1412-1419
// dark(name) 表 (subdued 用)                                    Qt/src/RhiScene.cpp:1422-1433
// 材质 overlay 表 (per-part name)                               Qt/src/SceneAppearance.cpp:86-103
// 材质总表 material()                                           Qt/src/SceneAppearance.cpp:33-52
// sRGB->linear                                                  Qt/src/SceneAppearance.cpp:17-22
// blend(light,dark,t) 线性空间插值                              Qt/src/SceneAppearance.cpp:25-32
// background = blend(#eae5e1, #11181b, theme)                    Qt/src/NativeSceneFrame.cpp:110-111
// fogColor   = blend(#eae5e1, #263136, theme)                    Qt/src/NativeSceneFrame.cpp:112-113
// frame.detail 已是 smooth((m_detail-0.25)/0.55)                 Qt/src/NativeSceneFrame.cpp:116
// boot: m_bootStart = m_clock - 1.76 ; 35s 后转 detail           Qt/src/NativeScene.cpp:178, :54 ; NativeSceneFrame.cpp:19-20
// ================= 缺口 (无证据, 按注明的替代处理) =================
// GAP-1 表面烘焙图集 (surfaceAtlas 1024x1024) 与光照场 (lightAtlas 24 层 3D) 不在仓库
//       证据: Qt/src/RhiScene.cpp:725-820 (archive-baked-surface*.bin / archive-baked-light.bin)
//       -> 本文件不伪造贴图, 用 draw 字段 + 固定光, 见 GAP-1 注释。
// GAP-2 Qt 无 tonemap/exposure 标识 -> NoToneMapping + outputColorSpace=sRGB。
// GAP-3 每实例变换未发布 (fixture 全部 draws[].matrices=[] , matrixBuffer=-1)
//       -> 实例摆位按 NativeScene.cpp:76-78 + NativeSceneUpdate.cpp:233-234 重推导。
// GAP-4 Qt 顶点布局只有 position/normal/uv (Qt/src/RhiScene.cpp:2215-2330, stride 32),
//       无 COLOR_0 顶点色 -> 不启用 vertexColors。
//
// 安全: 只用同源相对路径 (./vendor, ./assets/models)。无 fetch(远程)/XHR/eval/new Function/input。
// GLTFLoader/FileLoader 内部的 fetch 由 vendor 提供, 仅请求同源相对 URL (contract 6)。

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

/* ============================================================
 * 1. Qt 常数 (只读, 全部有行号)
 * ============================================================ */
const DEG = Math.PI / 180;
const NEAR_PLANE = 5;              // Qt/src/NativeScene.cpp:52
const FAR_PLANE = 300;             // Qt/src/NativeScene.cpp:52
const CLIP_SHRINK = 1.18;          // Qt/src/NativeSceneCamera.cpp:116-117
const ARCHIVE_SHIFT_X = 0.16;      // Qt/src/NativeSceneCamera.cpp:102
const ARCHIVE_SHIFT_Y = 0.20;      // Qt/src/NativeSceneCamera.cpp:103
const DEFAULT_SHOT = 29.1;         // Qt/src/NativeSceneCamera.cpp:14
const DEFAULT_SPAN = 10.8;         // Qt/src/NativeSceneCamera.cpp:21 lerp(10.8,10.3,orbit)
const SHOT_ORBIT_START = 22.6;     // Qt/src/NativeSceneCamera.cpp:15
const SHOT_SETTLE_START = 24.25;   // Qt/src/NativeSceneCamera.cpp:16
const LANE_STEP = 5.2;             // Qt/src/NativeScene.cpp:76-78
const ROW_STEP = 0.62;             // Qt/src/NativeScene.cpp:76-78
const CELL_BASE_Y = -4.6;          // Qt/src/NativeScene.cpp:76-78
const FLOOR_Y = -4.63;             // Qt/src/NativeSceneFrame.cpp:62
const FLOOR_TILT_X = -Math.PI / 2; // Qt/src/NativeSceneFrame.cpp:62
const CARD_HALF_X = 2.8;           // Qt/src/NativeSceneCamera.cpp:111
const CARD_HALF_Y = 6.5;           // Qt/src/NativeSceneCamera.cpp:111
const CARD_HALF_Z = 1.2;           // Qt/src/NativeSceneCamera.cpp:111
const CELLS_PER_BAND = 160;        // Qt/src/NativeSceneUpdate.cpp:233-234 (5 x 32)
const CELLS_PER_ROW_BAND = 32;     // Qt/src/NativeSceneUpdate.cpp:233-234 (index%32)
const CARD_SLOPE_SCALE = 0.024;    // Qt/src/NativeSceneUpdate.cpp:263-264
const BOOT_SHIFT = -1.76;          // Qt/src/NativeScene.h:137 m_bootStart=-1.76
const BOOT_TO_DETAIL_SECONDS = 35; // Qt/src/NativeSceneFrame.cpp:19-20
const DIRECTION_DETAIL = { x: -0.277, y: 0.238, z: 0.931 };  // Qt/src/NativeSceneCamera.cpp:34, :38-40
const AO_FOV_DEG = 34;             // Qt/src/NativeScene.cpp:52, :267
const SHADOW_LIGHT_POS = { x: -6, y: 14, z: -5 };            // Qt/src/NativeSceneFrame.cpp:123
const EMISSION_COLOR = { r: 1.0, g: 0.72, b: 0.38 };         // Qt/src/RhiScene.cpp:1412-1419
const OPTICAL_DECAY = 0.62;        // Qt/src/RhiScene.cpp:1405 opticalLight.z
const BACKGROUND_DAY = 0xeae5e1;   // Qt/src/NativeSceneFrame.cpp:110-111
const BACKGROUND_NIGHT = 0x11181b; // Qt/src/NativeSceneFrame.cpp:110-111
const FOG_DAY = 0xeae5e1;          // Qt/src/NativeSceneFrame.cpp:112-113
const FOG_NIGHT = 0x263136;        // Qt/src/NativeSceneFrame.cpp:112-113
const FLOOR_DAY = 0xd8c9b9;        // Qt/src/SceneAppearance.cpp:225-258
const FLOOR_NIGHT = 0x192125;      // Qt/src/SceneAppearance.cpp:225-258
const FLOOR_ROUGHNESS = 0.95;      // Qt/src/SceneAppearance.cpp:225-258 (roughnessFactor 0.95)
// Qt/src/RhiScene.cpp:1422-1433 dark(name): subdued 时使用的暗基色 (sRGB)
const DARK_BY_PART = {
  Frosted_Polymer: 0x626b70,
  Ivory_Edges: 0x687277,
  Optical_Diffuser: 0x192226,
  Titanium_Fasteners: 0xb1b9bb,
  Index_Inlay: 0xc6a36b,
  Printed_Label: 0x303a3e,
  Subsurface_Optics: 0x939e9f,
  Optical_Edges: 0xbbc3bc,
  Carbon_Ink: 0xb6bdb8
};
const DARK_DEFAULT = 0x969f9f;     // Qt/src/RhiScene.cpp:1430 default
const DARK_ORANGE = 0xbb8850;      // Qt/src/RhiScene.cpp:1430 name.contains("Orange")
// Qt/src/SceneAppearance.cpp:86-103 逐名覆盖 (低 LOD / 选卡状态)
const PART_OVERRIDES = {
  Frosted_Polymer: { color: 0xfffdfa, transmission: 0.9, thickness: 0.12, roughness: 0.21, ior: 1.46, attenuation: 0xeee6df, attenuationDistance: 2 },
  Ivory_Edges: { color: 0xf0e7df, roughness: 0.31, transmission: 0.65, thickness: 0.04 },
  Optical_Diffuser: { color: 0xe2dad4, transmission: 0, roughness: 0.7 }
};
// Qt/src/SceneAppearance.cpp:105-123 低 LOD (instanced) 覆盖
const LOW_LOD_OVERRIDES = {
  Frosted_Polymer: { transmission: 0.78, color: 0xfff7ed, roughness: 0.28, clearcoat: 0.3, clearcoatRoughness: 0.25 },
  Optical_Diffuser: { color: 0x806447 },
  Ivory_Edges: { transmission: 0, color: 0xfff5e9, roughness: 0.38 },
  Index_Inlay: { color: 0xe4d6c5, metalness: 0.05 }
};
// Qt/src/SceneAppearance.cpp:10-11 hidden 部件 (不参与渲染)
const HIDDEN_PARTS = ['Internal_Ceramic', 'Optical_Edges', 'Subsurface_Optics', 'Optical_Film_Edge','Amber_Optical_Inlay', 'Champagne_Index', 'Printed_Label'];
// Qt/src/SceneAppearance.cpp:66-68 始终跳过
const ALWAYS_SKIP_PARTS = ['Carbon_Ink'];

/* ============================================================
 * 2. 数学 (逐行对齐 Qt/src/SceneMath.cpp + SceneMotion.cpp)
 * ============================================================ */
function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
function lerp(a, b, t) { return a + (b - a) * t; }
function lerp3(a, b, t) { return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), z: lerp(a.z, b.z, t) }; }
function dot3(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
function cross3(a, b) { return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }; }
function length3(a) { return Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z); }
function normalize3(a) { const l = length3(a); return l > 0 ? { x: a.x / l, y: a.y / l, z: a.z / l } : { x: 0, y: 0, z: 1 }; }
function isFinite3(a) { return !!a && Number.isFinite(a.x) && Number.isFinite(a.y) && Number.isFinite(a.z); }

// Qt/src/SceneMotion.cpp:42-45 smooth (五次曲线), 与 Qt 完全一致
function smooth(value) {
  const v = clamp01(value);
  return v * v * v * (10 + v * (-15 + 6 * v));
}
// Qt/src/SceneMotion.cpp:46-49 ease (smoothstep)
function ease(value) {
  const v = clamp01(value);
  return v * v * (3 - 2 * v);
}

// Qt/src/SceneAppearance.cpp:17-22 单通道 sRGB -> linear
function srgbToLinear1(c) { return c < 0.04045 ? c * 0.0773993808 : Math.pow(c * 0.9478672986 + 0.0521327014, 2.4); }
function hexToLinear(hex) {
  const r = ((hex >> 16) & 255) / 255, g = ((hex >> 8) & 255) / 255, b = (hex & 255) / 255;
  return { r: srgbToLinear1(r), g: srgbToLinear1(g), b: srgbToLinear1(b) };
}
// Qt/src/SceneAppearance.cpp:25-32 blend: 线性空间逐通道插值
function blendLinear(light, dark, t) {
  return { r: lerp(light.r, dark.r, t), g: lerp(light.g, dark.g, t), b: lerp(light.b, dark.b, t) };
}
// theme 标量反解: frame.background = blend(linear(#eae5e1), linear(#11181b), theme)
// (Qt/src/NativeSceneCamera.cpp:95 的 m_theme.background(clock) 是标量, 未发布; 用发布值反推)
const BG_LIGHT = hexToLinear(BACKGROUND_DAY);
const BG_DARK = hexToLinear(BACKGROUND_NIGHT);
function recoverTheme(background) {
  if (!Array.isArray(background) || background.length < 3) return 0;
  let acc = 0, n = 0;
  for (let i = 0; i < 3; i++) {
    const span = BG_LIGHT[('rgb')[i]] - BG_DARK[('rgb')[i]];
    if (Math.abs(span) < 1e-6) continue;
    acc += (BG_LIGHT[('rgb')[i]] - background[i]) / span;
    n++;
  }
  return n > 0 ? clamp01(acc / n) : 0;
}

// Qt/src/NativeSceneCamera.cpp:100 detailProgress = smooth((m_detail-0.25)/0.55)
// frame.detail 已经是该值 (Qt/src/NativeSceneFrame.cpp:116), 相机内部还需要 m_detail,
// 故对 smooth 做二分反解; 平坦区 (<=0.25 / >=0.8) 不可逆 -> 夹到端点 (缺口, 已在报告记录)。
function invertSmooth(progress) {
  const p = clamp01(progress);
  if (p <= 0) return 0.25;
  if (p >= 1) return 0.8;
  let lo = 0.25, hi = 0.8;
  for (let i = 0; i < 48; i++) {
    const mid = 0.5 * (lo + hi);
    if (smooth((mid - 0.25) / 0.55) < p) lo = mid; else hi = mid;
  }
  return 0.5 * (lo + hi);
}

/* ------------------------------------------------------------
 * 投影矩阵: 逐行复制 Qt/src/SceneMath.cpp:64-78
 *   fov 为垂直视角(度), aspect = width/height。
 *   等价性证明 (three PerspectiveCamera):
 *   three r160 Matrix4.makePerspective (vendor three.module.js:6652-6684) 用同一套
 *   x=2n/(r-l), y=2n/(t-b), a=(r+l)/(r-l), b=(t+b)/(t-b), c=-(f+n)/(f-n), d=-2fn/(f-n),
 *   写入列主序 te[0]=x, te[5]=y, te[8]=a, te[9]=b, te[10]=c, te[11]=-1, te[14]=d。
 *   当 fov 相同时 Qt SceneMath.cpp:64-66 的 top = near*tan(pi/180*0.5*fov) 与 three
 *   PerspectiveCamera.updateProjectionMatrix (three.module.js:12684-12712) 的
 *   top = near*tan(DEG2RAD*0.5*fov)/zoom (zoom=1) 完全相同 -> 两矩阵逐元素相等。
 *   y 轴方向: three 与 Qt 都是右手系 +Y 上, NDC 均为 OpenGL 风格 z in [-1,1],
 *   且 Qt 投影到屏幕时 ((x+1)*w/2, (1-y)*h/2) (Qt/src/NativeSceneFrame.cpp:192-193),
 *   与 three 的 NDC 约定一致 => 不需要 Y 翻转。
 *   故直接使用 makePerspective, 不走 PerspectiveCamera.updateProjectionMatrix,
 *   因为后者在 filmOffset/filmGauge 分支会平移 left (three.module.js:12695-12700),
 *   而 Qt 无此机制, 会有偏差。
 * ------------------------------------------------------------ */
const _qtPerspective = new THREE.Matrix4();
function projectionMatrixQt(fovDeg, aspect, near, far) {
  const top = near * Math.tan(Math.PI / 180 * 0.5 * fovDeg);   // SceneMath.cpp:65
  const height = 2 * top;                                       // SceneMath.cpp:65
  const width = aspect * height;                                // SceneMath.cpp:66
  const left = -0.5 * width;                                    // SceneMath.cpp:66
  const right = left + width;                                   // SceneMath.cpp:66
  const bottom = top - height;                                  // SceneMath.cpp:66
  _qtPerspective.makePerspective(left, right, top, bottom, near, far);
  return _qtPerspective;
}

// Qt/src/NativeSceneCamera.cpp:102-103 values[8] += 0.16*k ; values[9] += 0.20*k
// 列主序下 values[8] 与 values[9] 就是 three 的 m.elements[8]/[9] (均为 a/b 项)。
// w_clip = -z_view, 故给元素 8 加常数 k 等价于 NDC x 平移 -k (仅平移, 不产生剪切)。
function applyArchiveShift(matrix, archiveOffset) {
  matrix.elements[8] += ARCHIVE_SHIFT_X * archiveOffset;   // NativeSceneCamera.cpp:102
  matrix.elements[9] += ARCHIVE_SHIFT_Y * archiveOffset;   // NativeSceneCamera.cpp:103
  return matrix;
}

const _lookAtMatrix = new THREE.Matrix4();
const _lookUp = new THREE.Vector3(0, 1, 0);
function viewMatrixQt(eye, aim) {
  // Qt/src/SceneMath.cpp:79-95 Matrix::camera(pos,target) == three lookAt(up=(0,1,0))
  return _lookAtMatrix.lookAt(new THREE.Vector3(eye.x, eye.y, eye.z), new THREE.Vector3(aim.x, aim.y, aim.z), _lookUp);
}

/* ============================================================
 * 3. 相机姿态 (逐行对齐 Qt/src/NativeSceneCamera.cpp:14-98)
 * ============================================================ */
function cinemaState(elapsed) {
  // Qt/src/NativeSceneFrame.cpp:23-27 Cinema = {elapsed, ease((e-22)/0.4), 0.55*ease((e-27.3)/1.65)+0.45*ease((e-29)/5)}
  return {
    time: elapsed,
    zoom: ease((elapsed - 22) / 0.4),
    track: 0.55 * ease((elapsed - 27.3) / 1.65) + 0.45 * ease((elapsed - 29) / 5)
  };
}

function computePose(input) {
  const cinema = input.cinema;            // null 或 {time,zoom,track}
  const mDetail = input.detail;           // Qt m_detail (0..1)
  const width = input.width;              // 逻辑宽 (stage.width)
  const height = input.height;            // 逻辑高 (stage.height)
  const shot = cinema ? cinema.time : DEFAULT_SHOT;             // NativeSceneCamera.cpp:14
  const orbit = smooth((shot - SHOT_ORBIT_START) / 1.6);        // :15
  const settle = smooth((shot - SHOT_SETTLE_START) / 2.25);     // :16
  const yaw = (89 - 22 * orbit - 8 * settle) * DEG;             // :18
  const elevation = (3 + 40 * smooth((shot - 21.96) / 0.22) - 8 * orbit - 16 * settle) * DEG; // :19-20
  const span = lerp(lerp(DEFAULT_SPAN, 10.3, orbit), 7.33, settle);   // :21
  const distance = lerp(lerp(28 + 7 * orbit, 140, settle), 72, mDetail); // :22
  let aim = {
    x: -1.091,
    y: lerp(-2.55 + 0.4 * orbit, -0.045, settle),
    z: lerp(2.48, 0.481, settle)
  };                                                             // :23
  let direction = {                                              // :24-25
    x: -Math.sin(yaw) * Math.cos(elevation),
    y: Math.sin(elevation),
    z: Math.cos(yaw) * Math.cos(elevation)
  };
  let detailHandoff = 0;
  if (cinema) {                                                  // :26-32
    const earlyTurn = smooth((shot - 27.3) / 1.3);
    const finalTurn = smooth((shot - 28.6) / 5.4);
    const shotYaw = yaw - (9 * earlyTurn + 32 * finalTurn) * DEG;
    const shotElevation = elevation - (1.5 * earlyTurn + 3.7 * finalTurn) * DEG;
    direction = {
      x: -Math.sin(shotYaw) * Math.cos(shotElevation),
      y: Math.sin(shotElevation),
      z: Math.cos(shotYaw) * Math.cos(shotElevation)
    };
  } else {                                                       // :34
    direction = normalize3(lerp3(direction, DIRECTION_DETAIL, mDetail));
  }
  if (cinema) {                                                  // :37-40
    detailHandoff = smooth((shot - 27.3) / 1.55);
    direction = normalize3(lerp3(direction, DIRECTION_DETAIL, detailHandoff));
  }
  const right = normalize3(cross3({ x: 0, y: 1, z: 0 }, direction));   // :41
  const up = normalize3(cross3(direction, right));                     // :42
  if (cinema) {                                                  // :44-46
    const pan = smooth((shot - 25.4) / 0.95);
    const shift = -2.05 * (1 - pan) * smooth((shot - 24.2) / 0.8);
    aim = { x: aim.x + right.x * shift, y: aim.y + right.y * shift, z: aim.z + right.z * shift };
  }
  // :47-54 cinema && shot>=25.05 的锚点跟随: 需要 actor.position, 未在 frame 发布;
  //     本文件按 NativeScene.h:83-96 的默认 actor cell {2,12} 的基座位置重算 (缺口 GAP-5)。
  if (cinema && shot >= 25.05) {
    const pan = smooth((shot - 25.4) / 1.05);
    const pixelScale = 1080 / span;
    const actorPos = input.actorPosition;
    const anchorAim = { x: actorPos.x - 2.5, y: actorPos.y + 3.7, z: actorPos.z };
    const dx = -(lerp(840, 518, pan) - 960) / pixelScale;
    const dy = -(540 - lerp(340, 288, pan)) / pixelScale;
    const follow = {
      x: anchorAim.x + right.x * dx + up.x * dy,
      y: anchorAim.y + right.y * dx + up.y * dy,
      z: anchorAim.z + right.z * dx + up.z * dy
    };
    aim = lerp3(aim, follow, smooth((shot - 25.05) / 0.35));
  }
  const aspect = width / height;                                 // :55
  const portrait = aspect < 1.05;                                // :56
  const compact = !portrait && width < 1100;                     // :57
  const baseSpan = lerp(span, 5.9, mDetail);                     // :58
  const portraitDetail = Math.max(6.3 / aspect, 3.7 * height / Math.max(100.0, 0.54 * height - 156)); // :59-60
  let anchorX = 550 / 1920, anchorY = 560 / 1080;                // :62-63
  let viewSpan = Math.max(baseSpan, baseSpan * (16.0 / 9) / aspect);   // :61
  if (portrait) {                                                // :64-67
    viewSpan = Math.max(baseSpan, lerp(8.4 / aspect, portraitDetail, mDetail));
    anchorX = 0.5;
    anchorY = 0.27 + 34 / height;
  } else if (compact) {                                          // :68-71
    anchorX = 0.27;
    anchorY = 0.49;
  }
  if (!cinema || detailHandoff > 0) {                            // :72-83
    const pixelScale = height / viewSpan;
    if (portrait && !cinema) {                                   // :73-79 portrait 专用基准 aim
      // cinematicField(12,2,26.56) 依赖 ArchiveField, 默认场恒 0 -> 该项为 0 (缺口 GAP-6)
      const cinematicField = 0;
      const baseAim = { x: 0, y: -4.6 + cinematicField + 0.4 + 1.85, z: -2.17 };
      const portraitShift = (0.36 - 0.5) * height / pixelScale;   // :83 up*((0.36-0.5)*h/scale)
      aim = {
        x: baseAim.x + up.x * portraitShift,
        y: baseAim.y + up.y * portraitShift,
        z: baseAim.z + up.z * portraitShift
      };
    }
    // :80-83 detailAim = actor.position + {0,1.85,0} + right*(...width...) + up*(...height...)
    const detailAim = {
      x: input.actorPosition.x + right.x * ((0.5 - anchorX) * width / pixelScale) + up.x * ((anchorY - 0.5) * height / pixelScale),
      y: input.actorPosition.y + 1.85 + right.y * ((0.5 - anchorX) * width / pixelScale) + up.y * ((anchorY - 0.5) * height / pixelScale),
      z: input.actorPosition.z + right.z * ((0.5 - anchorX) * width / pixelScale) + up.z * ((anchorY - 0.5) * height / pixelScale)
    };
    aim = lerp3(aim, detailAim, cinema ? detailHandoff : mDetail);
  }
  let position = {                                               // :84
    x: aim.x + direction.x * distance,
    y: aim.y + direction.y * distance,
    z: aim.z + direction.z * distance
  };
  // :85-88 指针偏移 (m_pointer) — rail 根节点 pointer-events:none 且不转发指针,
  //        故本文件该项恒为 0 (缺口 GAP-7, 已在报告记录)。
  const desiredSpan = cinema ? lerp(baseSpan, viewSpan, detailHandoff) : viewSpan;  // :92
  const targetFov = 2 * Math.atan(desiredSpan / (2 * distance)) / DEG;              // :93
  return { eye: position, aim: aim, viewSpan: viewSpan, distance: distance, targetFov: targetFov, direction: direction, right: right, up: up };
}

/* ============================================================
 * 4. renderer / scene 初始化
 * ============================================================ */
const state = {
  renderer: null,
  scene: null,
  camera: null,
  canvas: null,
  glbLoaded: false,
  loadedKeys: [],
  renderClock: 0,
  webgl2: false,
  lastError: null,
  frame: null,
  stage: { width: 1920, height: 1080, scale: 1 },
  fov: 6.15,                       // Qt/src/NativeScene.h:128 m_fov=6.15 (起始值)
  eye: { x: -62.26, y: 35.98, z: 43.28 },   // Qt/src/NativeScene.h:123
  aim: { x: -0.5, y: 1.1, z: 0.4 },         // Qt/src/NativeScene.h:124
  lastTime: 0,
  rafId: 0,
  drawSignature: null,
  nodesByAsset: { cassette: null, assembly: null },
  partIndex: { cassette: null, assembly: null },
  audit: { hasBlend: false, appliedDraws: 0, skippedParts: [], assetUrls: [], missingParts: [] },
  actorCell: { lane: 2, row: 12 }           // Qt/src/NativeScene.h:83-96 默认 Actor cell
};

function recordError(message) {
  state.lastError = String(message);
}

function createRenderer() {
  const canvas = document.getElementById('rhine-webgl-canvas');
  if (!canvas) { recordError('canvas-missing:#rhine-webgl-canvas'); return false; }
  try {
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setPixelRatio(1);   // index.html 已按 devicePixelRatio 计算像素尺寸, 见 resize()
    renderer.outputColorSpace = THREE.SRGBColorSpace;   // 缺口 GAP-2: Qt 无明确 tonemap
    renderer.toneMapping = THREE.NoToneMapping;         // 缺口 GAP-2
    renderer.autoClear = true;
    renderer.sortObjects = true;
    state.renderer = renderer;
    state.canvas = canvas;
    const gl = renderer.getContext();
    state.webgl2 = !!(renderer.capabilities && renderer.capabilities.isWebGL2) || (typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext);
    return true;
  } catch (err) {
    recordError('renderer-init:' + (err && err.message ? err.message : String(err)));
    state.renderer = null;
    return false;
  }
}

function createScene() {
  const scene = new THREE.Scene();
  state.scene = scene;
  const camera = new THREE.PerspectiveCamera(state.fov, 16 / 9, NEAR_PLANE, FAR_PLANE);
  camera.matrixAutoUpdate = true;
  state.camera = camera;
  // 固定光照: 只有 Qt 有证据的两项 + 一项显式标注的近似环境光 (缺口 GAP-1)
  const key = new THREE.DirectionalLight(0xffffff, 1.0);
  key.position.set(SHADOW_LIGHT_POS.x, SHADOW_LIGHT_POS.y, SHADOW_LIGHT_POS.z);  // Qt/src/NativeSceneFrame.cpp:123
  key.name = 'qt-shadow-light';
  scene.add(key);
  const ambient = new THREE.AmbientLight(0xffffff, 0.55);   // 无 Qt 证据(近似), GAP-1
  ambient.name = 'approx-ambient';
  scene.add(ambient);
  const optical = new THREE.PointLight(new THREE.Color(EMISSION_COLOR.r, EMISSION_COLOR.g, EMISSION_COLOR.b), 1.0);
  optical.decay = OPTICAL_DECAY;          // Qt/src/RhiScene.cpp:1405 opticalLight.z = 0.62
  optical.name = 'qt-optical-light';      // Qt/src/RhiScene.cpp:1412-1419
  optical.position.set(0, -1, -2.17);
  scene.add(optical);
  return scene;
}

if (!createRenderer()) {
  createSceneWithoutRenderer();
} else {
  createScene();
}
function createSceneWithoutRenderer() {
  state.scene = new THREE.Scene();
}

/* ============================================================
 * 5. GLB 加载 (真实模型, 同源相对路径)
 * ============================================================ */
// Kotlin 宿主把 ./assets/models/* 映射到仓库 Assets/models/*。
// 绝不用假几何替代: 加载失败必须 glbLoaded=false 且 lastError 记录真实原因。
const ASSET_URLS = {
  cassette: './assets/models/archive-cassette.glb',
  assembly: './assets/models/archive-assembly.glb'
};
const ASSET_KEYS = ['cassette', 'assembly'];
state.audit.assetUrls = [ASSET_URLS.cassette, ASSET_URLS.assembly];

const gltfLoader = new GLTFLoader();
const loadingPromises = {};
let pendingLoads = 0;

function loadAsset(key) {
  const url = ASSET_URLS[key];
  if (!url) return Promise.resolve(null);
  if (loadingPromises[key]) return loadingPromises[key];
  pendingLoads++;
  const promise = gltfLoader.loadAsync(url).then(function (gltf) {
    state.nodesByAsset[key] = gltf.scene;
    state.partIndex[key] = indexParts(gltf.scene);
    if (state.loadedKeys.indexOf(key) < 0) state.loadedKeys.push(key);
    pendingLoads--;
    if (pendingLoads === 0 && state.loadedKeys.length === ASSET_KEYS.length) state.glbLoaded = true;
    state.drawSignature = null;   // 触发重建
    return gltf;
  }).catch(function (err) {
    pendingLoads--;
    const message = (err && err.message) ? err.message : String(err);
    recordError(key + ':' + message);
    state.glbLoaded = false;
    return null;
  });
  loadingPromises[key] = promise;
  return promise;
}

function loadAllAssets() {
  return Promise.all(ASSET_KEYS.map(loadAsset));
}
loadAllAssets();

// 部件名归一化: assembly 节点形如 cover__Frosted_Polymer.012 (资产前缀 + Blender 后缀)
// cassette 节点形如 Frosted_Polymer.025  ->  统一得到 Frosted_Polymer
function normalizePartName(raw) {
  if (!raw) return '';
  let name = String(raw).trim();
  const cut = name.lastIndexOf('__');
  if (cut >= 0) name = name.slice(cut + 2);
  const dot = name.lastIndexOf('.');
  if (dot > 0) {
    const tail = name.slice(dot + 1);
    let numeric = tail.length > 0;
    for (let i = 0; i < tail.length; i++) {
      const c = tail.charCodeAt(i);
      if (c < 48 || c > 57) { numeric = false; break; }
    }
    if (numeric) name = name.slice(0, dot);
  }
  return name;
}

// 建立“归一化部件名 -> Mesh”索引。GLB 的 node/mesh 顺序与 Qt json mesh 数组不同,
// 因此只能按名字绑定 (证据: Assets/models/archive-cassette.glb nodes[] 名称 + draw.name)。
function indexParts(root) {
  const index = {};
  if (!root) return index;
  root.traverse(function (child) {
    if (!child.isMesh) return;
    const key = normalizePartName(child.name);
    if (!key) return;
    if (!index[key]) index[key] = [];
    index[key].push(child);
  });
  return index;
}

function lookupPart(assetKey, partName) {
  const index = state.partIndex[assetKey];
  if (!index || !partName) return null;
  const list = index[partName];
  if (list && list.length > 0) return list[0];
  return null;
}

/* ============================================================
 * 6. 材质: Qt 烘焙材质表现 (SceneAppearance.cpp + RhiScene.cpp Surface)
 * ============================================================ */
function linearColorOf(hex) {
  const c = hexToLinear(hex);
  return new THREE.Color().setRGB(c.r, c.g, c.b, THREE.LinearSRGBColorSpace);
}
function darkColorFor(partName) {
  if (Object.prototype.hasOwnProperty.call(DARK_BY_PART, partName)) return DARK_BY_PART[partName];
  if (partName && partName.indexOf('Orange') >= 0) return DARK_ORANGE;
  return DARK_DEFAULT;
}
function drawColorToThree(draw) {
  const c = Array.isArray(draw.color) ? draw.color : [1, 1, 1];
  // draw.color 已是线性空间 (Qt/src/RhiScene.cpp:1434-1440 Surface.color)
  return new THREE.Color().setRGB(c[0], c[1], c[2], THREE.LinearSRGBColorSpace);
}
function threeSideOf(side) {
  if (side === 1) return THREE.BackSide;      // Qt: side=1 背面
  if (side === 2) return THREE.DoubleSide;    // Qt: side=2 双面
  return THREE.FrontSide;                     // Qt: side=0 正面 (default)
}
function materialForDraw(draw) {
  const partName = normalizePartName(draw.name);
  const instanced = !!draw.instanced;
  const override = instanced ? (LOW_LOD_OVERRIDES[partName] || null) : (PART_OVERRIDES[partName] || null);
  const params = {
    roughness: (draw.roughness === undefined || draw.roughness === null) ? 1 : draw.roughness,   // SceneAppearance.cpp:34-35 default 1
    metalness: (draw.metalness === undefined || draw.metalness === null) ? 1 : draw.metalness,   // SceneAppearance.cpp:36-37 default 1
    transmission: Number(draw.transmission) || 0,
    thickness: Number(draw.thickness) || 0,
    ior: Number(draw.ior) || 1.5,               // SceneAppearance.cpp:44-45 default 1.5
    clearcoat: Number(draw.clearcoat) || 0,     // SceneAppearance.cpp:48-49
    clearcoatRoughness: Number(draw.clearcoatRoughness) || 0,
    side: threeSideOf(draw.side),
    transparent: !!draw.transparent,
    depthWrite: draw.depthWrite !== false,
    opacity: (draw.opacity === undefined || draw.opacity === null) ? 1 : draw.opacity,
    depthFunc: THREE.LessEqualDepth,            // Qt/src/RhiScene.cpp setDepthOp(LessOrEqual)
    blending: THREE.NormalBlending,             // Qt/src/RhiScene.cpp blend SrcAlpha/OneMinusSrcAlpha
    vertexColors: false                         // 缺口 GAP-4: Qt 顶点无 COLOR_0
  };
  const material = new THREE.MeshPhysicalMaterial(params);
  if (draw.subdued) {
    material.color = new THREE.Color();
    const dark = linearColorOf(darkColorFor(partName));   // Qt/src/RhiScene.cpp:1422-1433
    material.color.setRGB(dark.r, dark.g, dark.b, THREE.LinearSRGBColorSpace);
  } else {
    material.color = drawColorToThree(draw);
  }
  const attenuation = Array.isArray(draw.attenuation) ? draw.attenuation : [1, 1, 1];
  material.attenuationColor = new THREE.Color().setRGB(attenuation[0], attenuation[1], attenuation[2], THREE.LinearSRGBColorSpace);
  const attenuationDistance = Number(draw.attenuationDistance);
  material.attenuationDistance = (Number.isFinite(attenuationDistance) && attenuationDistance > 0) ? Math.min(attenuationDistance, 1e8) : 1e9;
  if (override) {
    if (override.color !== undefined) material.color = linearColorOf(override.color);
    if (override.transmission !== undefined) material.transmission = override.transmission;
    if (override.thickness !== undefined) material.thickness = override.thickness;
    if (override.roughness !== undefined) material.roughness = override.roughness;
    if (override.ior !== undefined) material.ior = override.ior;
    if (override.metalness !== undefined) material.metalness = override.metalness;
    if (override.clearcoat !== undefined) material.clearcoat = override.clearcoat;
    if (override.clearcoatRoughness !== undefined) material.clearcoatRoughness = override.clearcoatRoughness;
    if (override.attenuation !== undefined) {
      const a = hexToLinear(override.attenuation);
      material.attenuationColor = new THREE.Color().setRGB(a.r, a.g, a.b, THREE.LinearSRGBColorSpace);
    }
    if (override.attenuationDistance !== undefined) material.attenuationDistance = override.attenuationDistance;
  }
  if (draw.musicSelected) {
    // Qt emission = {1,0,0,0} -> 红色自发光通道 (Qt/src/RhiScene.cpp:1434-1471 emission)
    material.emissive = new THREE.Color().setRGB(EMISSION_COLOR.r, EMISSION_COLOR.g, EMISSION_COLOR.b, THREE.LinearSRGBColorSpace);
    material.emissiveIntensity = 0.15;   // 无 Qt 强度证据(近似), 缺口 GAP-1
  }
  material.name = 'qt-draw:' + (partName || draw.id);
  return material;
}

/* ============================================================
 * 7. 场景图: 完全由 frame.draws 构建 (无发布矩阵, 按 Qt 重新推导)
 * ============================================================ */
// Qt/src/NativeScene.cpp:76-78
function cellPosition(lane, row) {
  return { x: (lane - 2) * LANE_STEP, y: CELL_BASE_Y, z: (row - 15.5) * ROW_STEP };
}
// Qt/src/NativeSceneUpdate.cpp:233-234 固定模式: cell = {index/32, index%32},
// 每 160 格为一个 band (5 lane x 32 row)。
function cellForInstance(index) {
  const band = Math.floor(index / CELLS_PER_BAND);
  const inBand = index - band * CELLS_PER_BAND;
  const lane = Math.floor(inBand / CELLS_PER_ROW_BAND);
  const row = (inBand - lane * CELLS_PER_ROW_BAND) + CELLS_PER_ROW_BAND * band;
  return { lane: lane, row: row };
}

function actorPositionForFrame(frame) {
  // Qt/src/NativeSceneUpdate.cpp:224-226 m_actor.position (静止态: trackX=0, entryZ=0, m_rail=0)
  const base = cellPosition(state.actorCell.lane, state.actorCell.row);
  return { x: base.x, y: base.y, z: base.z };
}

function drawsSignature(draws) {
  if (!Array.isArray(draws)) return 'none';
  const parts = [];
  for (let i = 0; i < draws.length; i++) {
    const d = draws[i] || {};
    parts.push([d.asset, d.name, d.mesh, d.count, d.instanced ? 1 : 0, d.floor ? 1 : 0, d.transparent ? 1 : 0, d.subdued ? 1 : 0, d.musicSelected ? 1 : 0].join('|'));
  }
  return parts.join(';');
}

function disposeSceneGraph() {
  const scene = state.scene;
  if (!scene) return;
  const removals = [];
  scene.traverse(function (obj) {
    if (obj.userData && obj.userData.rhineDraw) removals.push(obj);
  });
  for (let i = 0; i < removals.length; i++) {
    const obj = removals[i];
    if (obj.parent) obj.parent.remove(obj);
    if (obj.geometry && obj.geometry.dispose) obj.geometry.dispose();
    if (obj.material) {
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      for (let m = 0; m < mats.length; m++) if (mats[m] && mats[m].dispose) mats[m].dispose();
    }
  }
}

function buildSceneGraph(frame) {
  disposeSceneGraph();
  state.audit.appliedDraws = 0;
  state.audit.skippedParts = [];
  state.audit.missingParts = [];
  const draws = Array.isArray(frame.draws) ? frame.draws : [];
  const mDetail = invertSmooth(clamp01(Number(frame.detail) || 0));
  const actor = actorPositionForFrame(frame);
  for (let i = 0; i < draws.length; i++) {
    const draw = draws[i] || {};
    const partName = normalizePartName(draw.name);
    if (draw.floor) { addFloor(draw); continue; }
    if (draw.label || (typeof draw.mesh === 'number' && draw.mesh < 0)) {
      // mesh -1 floor 已处理; -2..-5 圆盘, -6/-7 字面 (Case_Lettering_*) 在 GLB 中无几何
      state.audit.skippedParts.push(draw.name || String(draw.mesh));
      continue;
    }
    if (ALWAYS_SKIP_PARTS.indexOf(partName) >= 0 || HIDDEN_PARTS.indexOf(partName) >= 0) {
      // Qt/src/SceneAppearance.cpp:66-68 (skip) 与 :10-11 (hidden)
      state.audit.skippedParts.push(partName);
      continue;
    }
    const assetKey = draw.asset === 'assembly' ? 'assembly' : 'cassette';
    const source = lookupPart(assetKey, partName);
    if (!source || !source.geometry) {
      state.audit.missingParts.push(assetKey + ':' + partName);
      continue;
    }
    if (draw.instanced) {
      addInstancedDraw(draw, partName, source, mDetail);
    } else {
      addSingleDraw(draw, partName, source, actor, mDetail);
    }
  }
}

function markDrawObject(obj, draw) {
  obj.userData.rhineDraw = true;
  obj.userData.drawId = draw.id;
  obj.renderOrder = Number(draw.order) || 0;   // Qt/src/RhiScene.cpp part order
  obj.matrixAutoUpdate = true;
  return obj;
}

function addFloor(draw) {
  // Qt/src/NativeSceneFrame.cpp:62 compose({0,-4.63,0},{-pi/2,0,0})
  // Qt/src/SceneAppearance.cpp:225-258 floor material: roughness 0.95, metalness 0,
  //   color = blend(#d8c9b9,#192125,theme), size plane(-100,-100,100,100) (RhiScene.cpp:820)
  const geometry = new THREE.PlaneGeometry(200, 200);
  const theme = state.frame ? recoverTheme(state.frame.background) : 0;
  const light = hexToLinear(FLOOR_DAY), dark = hexToLinear(FLOOR_NIGHT);
  const mixed = blendLinear(light, dark, theme);
  const material = new THREE.MeshStandardMaterial({
    color: new THREE.Color().setRGB(mixed.r, mixed.g, mixed.b, THREE.LinearSRGBColorSpace),
    roughness: FLOOR_ROUGHNESS,
    metalness: 0,
    side: threeSideOf(draw.side),
    transparent: !!draw.transparent,
    depthWrite: draw.depthWrite !== false,
    depthFunc: THREE.LessEqualDepth
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(0, FLOOR_Y, 0);
  mesh.rotation.x = FLOOR_TILT_X;
  mesh.name = 'qt-floor';
  state.scene.add(markDrawObject(mesh, draw));
  state.audit.appliedDraws++;
}

// 卡片旋转: Qt/src/NativeSceneUpdate.cpp:263-264 matrix=compose(position,{slope*0.024*(1-m_detail),0,0})
// slope = field(row+.5)-field(row-.5), 默认场恒 0 (Qt/src/SceneMotion.h:33-45) -> 旋转为 0
function cardRotationX() { return 0; }

function addInstancedDraw(draw, partName, source, mDetail) {
  // 每实例摆位: 发布帧没有 matrices (GAP-3), 按 cellPosition + 固定网格重推导,
  // 并复用 Qt visibleCells 的视锥裁剪 (NativeSceneCamera.cpp:113-140)。
  const count = Math.max(1, Number(draw.count) || 1);
  const candidates = [];
  for (let i = 0; i < count; i++) candidates.push(cellForInstance(i));
  const visible = candidates.filter(function (cell) { return cellVisible(cell); });
  if (visible.length === 0) return;
  const material = materialForDraw(draw);
  const instancedMesh = new THREE.InstancedMesh(source.geometry, material, visible.length);
  const matrix = new THREE.Matrix4();
  const quaternion = new THREE.Quaternion();
  const scale = new THREE.Vector3(1, 1, 1);
  const rotationEuler = new THREE.Euler(cardRotationX(), 0, 0);
  quaternion.setFromEuler(rotationEuler);
  for (let i = 0; i < visible.length; i++) {
    const cell = visible[i];
    const pos = cellPosition(cell.lane, cell.row);
    matrix.compose(new THREE.Vector3(pos.x, pos.y, pos.z), quaternion, scale);
    instancedMesh.setMatrixAt(i, matrix);
  }
  instancedMesh.instanceMatrix.needsUpdate = true;
  instancedMesh.name = 'qt-instanced:' + partName;
  instancedMesh.castShadow = !!draw.castShadow;   // Qt/src/SceneAppearance.cpp:124-144 castShadow
  instancedMesh.frustumCulled = false;            // 已按 Qt visibleCells 自行裁剪
  state.scene.add(markDrawObject(instancedMesh, draw));
  state.audit.appliedDraws++;
}

function addSingleDraw(draw, partName, source, actor, mDetail) {
  const material = materialForDraw(draw);
  const mesh = new THREE.Mesh(source.geometry, material);
  mesh.position.set(actor.x, actor.y, actor.z);   // Qt/src/NativeSceneUpdate.cpp:224-226 (静止态)
  mesh.rotation.x = cardRotationX();
  mesh.name = 'qt-part:' + partName;
  mesh.castShadow = !!draw.castShadow;
  state.scene.add(markDrawObject(mesh, draw));
  state.audit.appliedDraws++;
}

/* ============================================================
 * 8. 视锥裁剪 (Qt/src/NativeSceneCamera.cpp:113-140)
 * ============================================================ */
const _clipProjection = new THREE.Matrix4();
const _clipViewProjection = new THREE.Matrix4();
const _clipFrustum = new THREE.Frustum();
const _clipBox = new THREE.Box3();
const _clipIdentity = new THREE.Matrix4();
function buildClipFrustum(fov, width, height, fogFar) {
  const far = Math.min(300, Math.max(6, fogFar + 8));   // NativeSceneCamera.cpp:115
  _clipProjection.copy(projectionMatrixQt(fov, width / height, NEAR_PLANE, far));
  _clipProjection.elements[0] /= CLIP_SHRINK;           // :116
  _clipProjection.elements[5] /= CLIP_SHRINK;           // :117
  if (state.camera) {
    _clipProjection.elements[8] = state.camera.projectionMatrix.elements[8];  // :119
    _clipProjection.elements[9] = state.camera.projectionMatrix.elements[9];  // :120
  }
  // 保证 matrixWorldInverse 与刚设置的位姿一致 (three 只在 render 时刷新)
  if (state.camera) state.camera.updateMatrixWorld(true);
  _clipViewProjection.multiplyMatrices(_clipProjection, state.camera ? state.camera.matrixWorldInverse : _clipIdentity);
  _clipFrustum.setFromProjectionMatrix(_clipViewProjection);
  return _clipFrustum;
}
function cellVisible(cell) {
  if (!_clipFrustum || !_clipPrepared) return true;
  const pos = cellPosition(cell.lane, cell.row);
  _clipBox.min.set(pos.x - CARD_HALF_X, pos.y - 0.3, pos.z - CARD_HALF_Z);   // NativeSceneCamera.cpp:109-111
  _clipBox.max.set(pos.x + CARD_HALF_X, pos.y + 4.1, pos.z + CARD_HALF_Z);
  return _clipFrustum.intersectsBox(_clipBox);
}
let _clipPrepared = false;

/* ============================================================
 * 9. resize / update / status (rail 契约)
 * ============================================================ */
function resize(pixelWidth, pixelHeight, devicePixelRatio) {
  try {
    const w = Math.max(1, Math.round(Number(pixelWidth) || 1));
    const h = Math.max(1, Math.round(Number(pixelHeight) || 1));
    const dpr = Number(devicePixelRatio) > 0 ? Number(devicePixelRatio) : 1;
    state.pixelWidth = w;
    state.pixelHeight = h;
    state.dpr = dpr;
    if (state.renderer) {
      state.renderer.setPixelRatio(1);   // rail 已把 canvas 尺寸设成设备像素 (index.html:114-147)
      state.renderer.setSize(w, h, false);
    }
    return true;
  } catch (err) {
    recordError('resize:' + (err && err.message ? err.message : String(err)));
    return false;
  }
}

function frameTimeSeconds(frame) {
  const t = Number(frame && frame.time);
  return Number.isFinite(t) ? t : 0;
}

function applyCamera(frame, pose) {
  const camera = state.camera;
  if (!camera) return;
  // 发布帧自带 Qt 的 eye (authoritative); aim 未发布 -> 用 Qt 端口推导的 aim。
  const publishedEye = frame.eye;
  const eye = (Array.isArray(publishedEye) && publishedEye.length >= 3 && publishedEye.every(function (v) { return Number.isFinite(Number(v)); }))
    ? { x: Number(publishedEye[0]), y: Number(publishedEye[1]), z: Number(publishedEye[2]) }
    : pose.eye;
  state.eye = eye;
  state.aim = pose.aim;
  camera.position.set(eye.x, eye.y, eye.z);
  camera.up.set(0, 1, 0);
  camera.lookAt(pose.aim.x, pose.aim.y, pose.aim.z);
  camera.near = NEAR_PLANE;
  camera.far = FAR_PLANE;
  // fov 平滑: Qt/src/NativeSceneCamera.cpp:89-91 blend = cinema||reduced ? 1 : 1-exp(-seconds*5)
  const blend = 1 - Math.exp(-(state.deltaSeconds || 0.016) * 5);
  state.fov = lerp(state.fov, pose.targetFov, clamp01(blend));
  camera.fov = state.fov;
  camera.aspect = (state.stage.width || 1920) / (state.stage.height || 1080);
  // 手动构造投影矩阵 (Qt/src/SceneMath.cpp:64-78), 带 archive 偏移 (:102-103):
  // 绝不调用 camera.updateProjectionMatrix() —— 其 filmOffset 分支会平移 left。
  const mode = typeof frame.mode === 'string' ? frame.mode : 'archive';
  const detailProgress = clamp01(Number(frame.detail) || 0);
  const archiveOffset = (pose.cinema || mode === 'boot') ? 0 : 1 - detailProgress;   // :100-101
  const projection = projectionMatrixQt(state.fov, camera.aspect, NEAR_PLANE, FAR_PLANE);  // :98
  applyArchiveShift(projection, archiveOffset);
  camera.projectionMatrix.copy(projection);
  camera.projectionMatrixInverse.copy(projection).invert();
}

function applyFog(frame, theme, mDetail, pose, renderedDistance) {
  const fogNearPublished = Number(frame.fogNear);
  const fogFarPublished = Number(frame.fogFar);
  const fogColorLinear = Array.isArray(frame.fogColor) && frame.fogColor.length >= 3
    ? { r: Number(frame.fogColor[0]), g: Number(frame.fogColor[1]), b: Number(frame.fogColor[2]) }
    : blendLinear(hexToLinear(FOG_DAY), hexToLinear(FOG_NIGHT), theme);   // NativeSceneFrame.cpp:112-113
  const color = new THREE.Color().setRGB(fogColorLinear.r, fogColorLinear.g, fogColorLinear.b, THREE.LinearSRGBColorSpace);
  let near, far;
  if (Number.isFinite(fogNearPublished) && Number.isFinite(fogFarPublished)) {
    near = fogNearPublished;   // 发布值即 Qt 输出 (NativeSceneFrame.cpp frame.fogNear/Far)
    far = fogFarPublished;
  } else {
    near = renderedDistance + lerp(5 - 4 * theme, -1, mDetail);      // NativeSceneCamera.cpp:96
    far = renderedDistance + lerp(25 - 9 * theme, 12, mDetail);      // :97
  }
  if (state.scene) state.scene.fog = new THREE.Fog(color, near, far);
  state.fogNear = near;
  state.fogFar = far;
  return far;
}

let lastFrameEnd = 0;
function update(frame, stage) {
  try {
    const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    state.deltaSeconds = lastFrameEnd > 0 ? Math.min(0.25, Math.max(0.0001, (now - lastFrameEnd) / 1000)) : 0.016;
    lastFrameEnd = now;
    state.frame = frame || null;
    if (stage && Number.isFinite(Number(stage.width)) && Number.isFinite(Number(stage.height))) {
      state.stage = { width: Number(stage.width), height: Number(stage.height), scale: Number(stage.scale) || 1 };
    }
    const f = frame || {};
    if (!state.scene) { recordError('scene-absent'); return false; }
    const theme = recoverTheme(f.background);
    const detailProgress = clamp01(Number(f.detail) || 0);
    const mDetail = invertSmooth(detailProgress);
    const mode = typeof f.mode === 'string' ? f.mode : 'archive';
    // 缺口 GAP-5: boot 起点 -1.76 (NativeScene.h:137 / NativeScene.cpp:178)
    const elapsed = frameTimeSeconds(f) + Math.abs(BOOT_SHIFT);
    let cinema = null;
    if (mode === 'boot' && elapsed >= 21.9) cinema = cinemaState(elapsed);   // NativeSceneFrame.cpp:28-30
    const actorPosition = actorPositionForFrame(f);
    const pose = computePose({
      cinema: cinema,
      detail: mDetail,
      width: state.stage.width,
      height: state.stage.height,
      actorPosition: actorPosition
    });
    pose.cinema = cinema;
    applyCamera(f, pose);
    const renderedDistance = length3({ x: state.eye.x - state.aim.x, y: state.eye.y - state.aim.y, z: state.eye.z - state.aim.z });  // :94
    const fogFar = applyFog(f, theme, mDetail, pose, renderedDistance);
    if (state.scene) {
      if (f.background && f.background.length >= 3) {
        state.scene.background = new THREE.Color().setRGB(Number(f.background[0]), Number(f.background[1]), Number(f.background[2]), THREE.LinearSRGBColorSpace);
      } else {
        const bg = blendLinear(BG_LIGHT, BG_DARK, theme);
        state.scene.background = new THREE.Color().setRGB(bg.r, bg.g, bg.b, THREE.LinearSRGBColorSpace);
      }
    }
    // 视锥 (用于实例裁剪): Qt/src/NativeSceneCamera.cpp:113-120
    buildClipFrustum(state.fov, state.stage.width || 1920, state.stage.height || 1080, fogFar);
    _clipPrepared = true;
    const signature = drawsSignature(f.draws) + '#' + (state.glbLoaded ? '1' : '0') + '#' + mode;
    if (signature !== state.drawSignature) {
      if (state.glbLoaded) {
        state.drawSignature = signature;
        buildSceneGraph(f);
      }
    }
    if (mode === 'boot' && elapsed >= BOOT_TO_DETAIL_SECONDS) state.audit.bootFinished = true;
    return true;
  } catch (err) {
    recordError('update:' + (err && err.message ? err.message : String(err)));
    return false;
  }
}

function renderFrame() {
  if (!state.renderer || !state.scene || !state.camera) return;
  try {
    state.renderer.render(state.scene, state.camera);
  } catch (err) {
    recordError('render:' + (err && err.message ? err.message : String(err)));
  }
}

/* ============================================================
 * 10. rAF 渲染循环 (renderClock 秒)
 * ============================================================ */
function tick() {
  state.rafId = requestAnimationFrame(tick);
  const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  if (state.clockStart === 0) state.clockStart = now;
  state.renderClock = (now - state.clockStart) / 1000;
  renderFrame();
}
if (typeof requestAnimationFrame === 'function') {
  state.clockStart = 0;
  state.rafId = requestAnimationFrame(tick);
}

function status() {
  return {
    glbLoaded: !!state.glbLoaded,
    loadedKeys: state.loadedKeys.slice(),
    renderClock: Number(state.renderClock) || 0,
    webgl2: !!state.webgl2,
    lastError: state.lastError,
    audit: {
      appliedDraws: state.audit.appliedDraws,
      skippedParts: state.audit.skippedParts.slice(0, 32),
      missingParts: state.audit.missingParts.slice(0, 32),
      assetUrls: state.audit.assetUrls.slice(),
      fov: state.fov,
      fogNear: state.fogNear,
      fogFar: state.fogFar,
      eye: [state.eye.x, state.eye.y, state.eye.z],
      aim: [state.aim.x, state.aim.y, state.aim.z],
      stage: [state.stage.width, state.stage.height]
    }
  };
}

window.RhineScene3D = {
  resize: resize,
  update: update,
  status: status,
  // 只读辅助 (rail 不要求, 供报告/复核取证)
  _internals: { state: state, projectionMatrixQt: projectionMatrixQt, computePose: computePose, recoverTheme: recoverTheme, normalizePartName: normalizePartName, invertSmooth: invertSmooth }
};
