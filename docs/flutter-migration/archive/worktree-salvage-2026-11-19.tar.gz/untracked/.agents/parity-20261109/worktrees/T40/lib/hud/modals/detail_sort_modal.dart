/// Qt 详情页「排序方式」弹出菜单（Qt/src/NativeHudModal.cpp:122-141）的逐像素端口。
///
/// 这是 popover 路径：没有遮罩、没有通用标题栏，唯一的外部点击出口是全屏捕获区
/// （Qt/src/NativeHudModal.cpp:128）。所有坐标都是 Qt 的 1920x1080 设计舞台像素，
/// 竖屏等其它布局只能经注入的 [DetailSortModal.rectHook] 换算；默认恒等，
/// 因此舞台数值保持精确，本文件不发明任何显示串或像素。
///
/// 绘制栈沿用 Qt：save → alpha(motion.opacity) → translate(0, motion.offset) →
/// popover 面板与四行按钮 → restore（NativeHudModal.cpp:83-84、:124-139）。
library;

/// Qt `QJsonArray` 颜色字面量：`[r, g, b, a]` 或 `[r, g, b, a, colorSpace]`。
///
/// 分量是 0..1 的 double，颜色空间只在 Qt 源写了 `calibratedWhite` /
/// `calibratedRGB` 的地方出现（Qt/src/NativeHud.cpp:10-15）。
typedef DetailSortColor = List<Object?>;

/// Qt `Glyphs::width` 的注入替代：返回 [text] 在 [size]/[weight]/[tracking] 下的宽度。
///
/// fit() 的省略号截断与按钮文本都必须经过它，绝不写死字宽
/// （Qt/src/NativeHud.cpp:57、:62、:118）。
typedef DetailSortMeasureText = double Function(
    String text, double size, String? weight, double tracking);

/// 竖屏等非舞台布局的矩形重映射钩子；默认恒等 `[x, y, w, h]`。
typedef DetailSortRectHook = List<double> Function(
    double x, double y, double w, double h);

/// 默认测量：0 宽，永不截断。真实调用方必须注入 [DetailSortMeasureText]。
double _zeroMeasure(String text, double size, String? weight, double tracking) => 0.0;

/// 默认矩形钩子：恒等。舞台数值因此逐位保持 Qt 原样。
List<double> _identityRect(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

double _clamp(double value, double lower, double upper) {
  if (value < lower) {
    return lower;
  }
  if (value > upper) {
    return upper;
  }
  return value;
}

double _min(double a, double b) => a < b ? a : b;

/// Qt `UiMotion::bezier`（Qt/src/UiMotion.cpp:7-22）：24 次二分求 x 的参数，再取 y。
double _bezier(double x, double x1, double y1, double x2, double y2) {
  double component(double t, double a, double b) {
    return 3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
  }

  var lower = 0.0;
  var upper = 1.0;
  for (var i = 0; i < 24; i++) {
    final t = (lower + upper) / 2;
    if (component(t, x1, x2) < x) {
      lower = t;
    } else {
      upper = t;
    }
  }
  return component((lower + upper) / 2, y1, y2);
}

/// 深色主题的主色（Qt/src/NativeHud.cpp:12）。
const List<Object?> _inkDark = <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite'];

/// 浅色主题的主色（Qt/src/NativeHud.cpp:14）。
const List<Object?> _inkLight = <Object?>[
  0.08,
  0.085,
  0.075,
  1.0,
  'calibratedRGB'
];

/// 弹层内按钮的深色 tint（Qt/src/NativeHud.cpp:116）。
const List<Object?> _tintDark = <Object?>[0.55, 0.59, 0.46, 0.13];

/// 弹层内按钮的浅色 tint（Qt/src/NativeHud.cpp:116）。
const List<Object?> _tintLight = <Object?>[0.44, 0.49, 0.36, 0.1];

/// 深色面板底色：排序菜单分支是四分量，没有颜色空间（Qt/src/NativeHudModal.cpp:130）。
const List<Object?> _panelFillDark = <Object?>[0.15, 0.15, 0.15, 1.0];

/// 浅色面板底色（Qt/src/NativeHudModal.cpp:130）。
const List<Object?> _panelFillLight = <Object?>[0.929, 0.922, 0.894, 1.0];

/// 一次绘制的结果：扁平命令表（Qt `commands`）与按绘制顺序排列的命中区（Qt `hits`）。
class DetailSortModalFrame {
  const DetailSortModalFrame({required this.commands, required this.hits});

  /// Qt `NativeHud::commands`：每条命令都是 `List<Object?>`，形状见 [DetailSortModal]。
  final List<List<Object?>> commands;

  /// Qt `NativeHud::hits`：每条命中区恰好 6 项 `[x, y, width, height, action, label]`。
  final List<List<Object?>> hits;
}

/// Qt `UiMotion::SurfaceMotion`（Qt/src/UiMotion.h:24-42、Qt/src/UiMotion.cpp:86-120）。
///
/// 起始 `offset` 为 12；`set(true)` 目标不透明 1 / 偏移 0 / 时长 0.3；
/// `set(false)` 目标不透明 0 / 偏移 8 / 时长 0.2；`reduced` 则时长 0 并瞬时到位。
/// `sample` 先按 `cubic-bezier(0.22, 1, 0.36, 1)`（进出相反）求量，再线性插值。
class DetailSortMotion {
  /// 当前不透明度，起始 0（Qt/src/UiMotion.h:31）。
  double opacity = 0;

  /// 当前纵向偏移，起始 12（Qt/src/UiMotion.h:32）。
  double offset = 12;

  /// 当前过渡时长，秒；0 即已结束（Qt/src/UiMotion.h:33）。
  double duration = 0;

  double _fromOpacity = 0;
  double _fromOffset = 12;
  double _targetOpacity = 0;
  double _targetOffset = 12;
  double _start = 0;
  bool _entering = true;

  /// Qt `SurfaceMotion::finished()`（Qt/src/UiMotion.h:28-30）：时长归零。
  ///
  /// `sample` 在 progress >= 1 时把 duration 置 0，因此「progress 跑到 1」也由它表达。
  bool get finished => duration == 0;

  /// 当前过渡是否处于进入方向（只对曲线选择有意义）。
  bool get entering => _entering;

  /// 当前过渡的目标不透明度（测试与宿主判定用）。
  double get targetOpacity => _targetOpacity;

  /// 当前过渡的目标偏移。
  double get targetOffset => _targetOffset;

  /// Qt `SurfaceMotion::sample`（Qt/src/UiMotion.cpp:86-98）。
  void sample(double time) {
    if (duration <= 0) {
      return;
    }
    final progress = _clamp((time - _start) / duration, 0.0, 1.0);
    final amount = _bezier(
      progress,
      _entering ? 0.22 : 0.4,
      _entering ? 1.0 : 0.0,
      _entering ? 0.36 : 1.0,
      1.0,
    );
    opacity = _fromOpacity + (_targetOpacity - _fromOpacity) * amount;
    offset = _fromOffset + (_targetOffset - _fromOffset) * amount;
    if (progress >= 1) {
      duration = 0;
    }
  }

  /// Qt `SurfaceMotion::set`（Qt/src/UiMotion.cpp:101-120）。
  ///
  /// 先采样旧过渡再换目标，快速开关弹窗时透明度与偏移因此从当前值接续。
  void set(bool shown, double time, [bool reduced = false]) {
    sample(time);
    _fromOpacity = opacity;
    _fromOffset = offset;
    _targetOpacity = shown ? 1 : 0;
    _targetOffset = shown ? 0 : 8;
    _entering = shown;
    _start = time;
    if (reduced) {
      duration = 0;
    } else if (shown) {
      duration = 0.3;
    } else {
      duration = 0.2;
    }
    if (reduced) {
      opacity = _targetOpacity;
      offset = _targetOffset;
    }
  }
}

/// 关闭弹层时要执行的清理语句名（Qt/src/NativeHudMusic.cpp:51-55）。
///
/// Qt 逐字：`if (modal == "detail-sort") { modal.clear(); closing = false;
/// ++m_searchGeneration; }`。列表里存的是语句名，宿主据此执行；本文件不持有
/// modal / closing / searchGeneration 自身。
class DetailSortCleanup {
  const DetailSortCleanup._();

  /// 当时 `modal == "detail-sort"`：清空弹层、清掉关闭中标志、推进搜索代号。
  static const List<String> whenOpen = <String>[
    'modal.clear',
    'closing=false',
    'searchGeneration++',
  ];

  /// 弹层已不在：Qt 的 if 不成立，不执行任何清理。
  static const List<String> whenClosed = <String>[];
}

/// 一个被接受的 sort 动作在宿主侧的效果计划（Qt/src/NativeHudMusic.cpp:56-59）。
///
/// Qt 逐字：`detailSort = field; trackOffset = 0; music.setDirectorySort(field);
/// beginSort();`。本文件只描述计划，自身不持有 detailSort / trackOffset / 排序
/// 状态——它们由宿主注入 [DetailSortModal] 或由宿主执行。
class DetailSortActionEffect {
  const DetailSortActionEffect({required this.field, required this.cleanup});

  /// `parts.value(3)`：被接受的字段，必为 [DetailSortModal.fields] 之一。
  final String field;

  /// 应用前要先执行的清理语句，见 [DetailSortCleanup]。
  final List<String> cleanup;

  /// 是否需要先关掉已打开的排序菜单（`modal == "detail-sort"`）。
  bool get clearsModal => cleanup.isNotEmpty;

  /// `detailSort = field`。
  String get detailSort => field;

  /// `trackOffset = 0`（Qt/src/NativeHudMusic.cpp:57）。
  double get trackOffset => 0.0;

  /// `music.setDirectorySort(field)`（Qt/src/NativeHudMusic.cpp:58）。
  bool get setDirectorySort => true;

  /// `beginSort()`（Qt/src/NativeHudMusic.cpp:59）。
  bool get beginSort => true;
}

/// Qt 排序菜单的注入状态与纯绘制入口（Qt/src/NativeHudModal.cpp:122-141）。
///
/// 注入项：舞台宽度、主题、动效降级、关闭中、当前不透明度与偏移、当前排序字段，
/// 以及文本测量与矩形钩子。`build()` 不读写任何外部状态，也不修改这些字段。
class DetailSortModal {
  const DetailSortModal({
    required this.width,
    this.dark = false,
    this.reduced = false,
    this.closing = false,
    this.opacity = 1.0,
    this.offset = 0.0,
    this.detailSort = 'none',
    this.measureText = _zeroMeasure,
    this.rectHook = _identityRect,
  });

  /// Qt `stageWidth`：landscape 设计舞台宽度（1920）。
  final double width;

  /// Qt `NativeHud::dark`：决定 ink、tint 与面板底色。
  final bool dark;

  /// Qt `NativeHud::reduced`：只影响 [DetailSortMotion.set] 的时长；
  /// 本弹层没有任何命令依赖它（Qt/src/NativeHudModal.cpp:122-141 不读 reduced）。
  final bool reduced;

  /// Qt `NativeHud::closing`：退出曲线播放期间仍照常绘制。
  final bool closing;

  /// Qt `motion.opacity`，来自 [DetailSortMotion] 的采样结果。
  final double opacity;

  /// Qt `motion.offset`，来自 [DetailSortMotion] 的采样结果。
  final double offset;

  /// Qt `NativeHud::detailSort`：`none` / `title` / `album` / `artist`。
  final String detailSort;

  /// 注入的文本测量，fit() 的省略号截断必须经过它。
  final DetailSortMeasureText measureText;

  /// 注入的矩形钩子，默认恒等（舞台坐标原样输出）。
  final DetailSortRectHook rectHook;

  /// 四个排序字段，顺序即菜单行顺序（Qt/src/NativeHudModal.cpp:131）。
  static const List<String> fields = <String>[
    'none',
    'title',
    'album',
    'artist'
  ];

  /// 四行标签，顺序与 [fields] 对应（Qt/src/NativeHudModal.cpp:132）。
  static const List<String> labels = <String>[
    '默认排序',
    '按歌曲名排序',
    '按专辑名排序',
    '按歌手名排序'
  ];

  /// 关闭动作：外部捕获区与 Escape 都落到它（Qt/src/NativeHudModal.cpp:128、
  /// Qt/src/NativeHudController.cpp:913-922）。
  static const String closeAction = 'close-modal';

  /// 外部捕获区的无障碍标签（Qt/src/NativeHudModal.cpp:128）。
  static const String catcherLabel = '关闭排序菜单';

  /// 打开与动作守卫里的两个字面量（Qt/src/NativeHudMusic.cpp:41）。
  static const String playlistKind = 'playlist';
  static const String detailMode = 'detail';

  /// 本弹层在 Qt 里的 modal 名称（Qt/src/NativeHudMusic.cpp:51）。
  static const String popoverKind = 'detail-sort';

  /// 本弹层暴露的按键动作表：任何弹层打开时 Escape 映射到 close-modal
  /// （Qt/src/NativeHudController.cpp:913-922；desktop-lyrics 的例外不属于本文件）。
  static const Map<String, String> keyActions = <String, String>{
    'Escape': 'close-modal'
  };

  /// 面板几何：x 依赖容器布局，y/宽/高是常量（Qt/src/NativeHud.cpp:141-144）。
  static const double panelOffsetX = 195;
  static const double panelTop = 391;
  static const double panelWidth = 240;
  static const double panelHeight = 184;

  /// 行高、左右缩进与字号（Qt/src/NativeHudModal.cpp:135-136）。
  static const double rowHeight = 42;
  static const double rowInset = 8;
  static const double rowTextSize = 14;

  /// 容器布局常量：左边距、侧栏夹取范围与间隔（Qt/src/NativeHud.cpp:160-166，
  /// 默认 `Layout::left = 40` 见 Qt/src/NativeHud.h:38）。
  static const double containerLeft = 40;
  static const double sidebarMinimum = 250;
  static const double sidebarMaximum = 340;
  static const double sidebarGap = 36;

  /// 某字段对应的动作串（Qt/src/NativeHudModal.cpp:136）。
  static String actionFor(String field) => 'music:sort:detail:$field';

  /// Qt `NativeHud::containerLayout`（Qt/src/NativeHud.cpp:160-166）。
  ///
  /// 返回 `[left, sidebar, x, width]`；排序菜单只用 x。
  static List<double> containerLayout(double width) {
    final sidebar = _clamp(
      width * 0.23 - 40,
      sidebarMinimum,
      sidebarMaximum,
    );
    final x = containerLeft + sidebar + sidebarGap;
    return <double>[containerLeft, sidebar, x, width - x - 40];
  }

  /// Qt `NativeHud::modalBounds` 的 detail-sort 分支（Qt/src/NativeHud.cpp:141-144）。
  ///
  /// 返回 `[x, y, width, height]`。
  static List<double> popoverBounds(double width) {
    final layout = containerLayout(width);
    return <double>[
      layout[2] + panelOffsetX,
      panelTop,
      panelWidth,
      panelHeight,
    ];
  }

  /// Qt `music:sort-menu` 的打开守卫（Qt/src/NativeHudMusic.cpp:40-43）。
  ///
  /// 逐字：`if (music.current["kind"] == "playlist" && frame["mode"] == "detail")
  /// openModal("detail-sort");`——任一门不满足时该动作不放任何弹层。
  static bool opensSortMenu({
    required String currentKind,
    required String frameMode,
  }) =>
      currentKind == playlistKind && frameMode == detailMode;

  /// 解析 `music:sort:<mode>:<field>` 动作（Qt/src/NativeHudMusic.cpp:44-60）。
  ///
  /// 四个前提全部满足才返回效果，否则返回 null（对应 Qt 的 `return`）：[field]
  /// 属于 [fields]；`parts.value(2)` 与 `frame["mode"]` 都是 `detail`；
  /// `music.current["kind"]` 是 `playlist`。清理语句按当时 [modal] 是否为
  /// [popoverKind] 决定（Qt/src/NativeHudMusic.cpp:51-55）。
  static DetailSortActionEffect? sortActionEffect({
    required String field,
    required String mode,
    required String frameMode,
    required String currentKind,
    required String modal,
  }) {
    if (!fields.contains(field)) {
      return null;
    }
    if (mode != detailMode || frameMode != detailMode) {
      return null;
    }
    if (currentKind != playlistKind) {
      return null;
    }
    return DetailSortActionEffect(
      field: field,
      cleanup: modal == popoverKind
          ? DetailSortCleanup.whenOpen
          : DetailSortCleanup.whenClosed,
    );
  }

  /// 纯绘制入口：按 Qt 的 modalDraw 顺序产出命令与命中区。
  ///
  /// [closing] 在这里是惰性的：Qt 只在 `closing && motion.finished()` 时由宿主清空
  /// modal（Qt/src/NativeHud.cpp:262-266），而 modalDraw 只在 modal 非空时才被调用
  /// （Qt/src/NativeHud.cpp:306-308）。因此退出曲线播放期间本函数照常绘制完全相同的
  /// 帧；opacity 归零并不等于曲线结束，不得据此提前返回空帧。
  DetailSortModalFrame build() {
    final commands = <List<Object?>>[];
    final hits = <List<Object?>>[];
    final panel = dark ? _panelFillDark : _panelFillLight;
    final bounds = popoverBounds(width);

    commands.add(<Object?>['save']); // Qt/src/NativeHudModal.cpp:83
    commands.add(<Object?>['alpha', opacity]); // :84
    commands.add(<Object?>['translate', 0.0, offset]); // :124
    // :125 命中表在此清空——popover 覆盖底层，底层不再接收事件。
    // :128 全屏外部捕获区。此时 translate 已把后续绘制整体下移 offset，
    // 捕获区 y 取 -offset 抵消该位移，落在舞台 0..1080 上，与面板同处一个坐标系。
    final catcher = _rect(0, -offset, width, 1080);
    _hit(hits, catcher, closeAction, catcherLabel);
    final panelRect = _rect(bounds[0], bounds[1], bounds[2], bounds[3]);
    commands.add(<Object?>[
      'fill',
      panel,
      panelRect[0],
      panelRect[1],
      panelRect[2],
      panelRect[3],
    ]); // :129-130
    for (var index = 0; index < fields.length; index++) {
      // :133-137 当前字段前缀 `✓ `，其余原样。
      final label = (detailSort == fields[index] ? '✓ ' : '') + labels[index];
      _button(
        commands,
        hits,
        label,
        bounds[0] + rowInset,
        bounds[1] + rowInset + index * rowHeight,
        bounds[2] - rowInset * 2,
        rowHeight,
        actionFor(fields[index]),
        rowTextSize,
      );
    }
    commands.add(<Object?>['restore']); // :139
    return DetailSortModalFrame(commands: commands, hits: hits);
  }

  /// Qt `NativeHud::hit`（Qt/src/NativeHud.cpp:102-108）：6 项定序，label 缺省回落动作串。
  void _hit(
    List<List<Object?>> hits,
    List<double> rect,
    String action,
    String? label,
  ) {
    hits.add(<Object?>[
      rect[0],
      rect[1],
      rect[2],
      rect[3],
      action,
      label ?? action,
    ]);
  }

  /// Qt `NativeHud::button` 在 `m_modalControls` 打开时的分支（Qt/src/NativeHud.cpp:110-120）。
  ///
  /// 先登记命中区，再按 `min(10, w/8)` 内缩填 tint，最后写 fit 后的文本；
  /// 文本纵向位置是 `y + (h - size) / 2 - 4`。
  void _button(
    List<List<Object?>> commands,
    List<List<Object?>> hits,
    String label,
    double x,
    double y,
    double w,
    double h,
    String action,
    double size, [
    String weight = 'regular',
  ]) {
    final rect = _rect(x, y, w, h);
    _hit(hits, rect, action, label); // :112
    final inset = _min(10.0, w / 8); // :113
    commands.add(<Object?>[
      'fill',
      dark ? _tintDark : _tintLight,
      rect[0],
      rect[1],
      rect[2],
      rect[3],
    ]); // :115-117
    commands.add(<Object?>[
      'text',
      // :118 Qt 的 fit 不传 weight，走默认 `regular`；本弹层唯一调用点同样用默认值。
      _fit(label, size, w - inset * 2, 'regular'),
      rect[0] + inset,
      rect[1] + (h - size) / 2 - 4,
      size,
      weight,
      0.0,
      _ink(),
    ]);
  }

  /// Qt `NativeHud::fit`（Qt/src/NativeHud.cpp:48-76）。
  ///
  /// 超宽时二分出可容纳的前缀长度，再回退一个字符补 `…`；测量全部走注入函数。
  String _fit(String value, double size, double width, String weight) {
    var length = value.length;
    if (measureText(value, size, weight, 0) > width) {
      var low = 1;
      var high = length;
      while (low < high) {
        final middle = (low + high + 1) ~/ 2;
        if (measureText(value.substring(0, middle), size, weight, 0) <= width) {
          low = middle;
        } else {
          high = middle - 1;
        }
      }
      length = low;
    }
    if (length == value.length) {
      return value;
    }
    final cut = length - 1 < 0 ? 0 : length - 1;
    return value.substring(0, cut) + '…';
  }

  /// 主色（Qt/src/NativeHud.cpp:10-15）。
  List<Object?> _ink() => dark ? _inkDark : _inkLight;

  /// 经注入钩子映射的矩形；默认恒等，舞台数值原样输出。
  List<double> _rect(double x, double y, double w, double h) {
    final mapped = rectHook(x, y, w, h);
    return <double>[mapped[0], mapped[1], mapped[2], mapped[3]];
  }
}
