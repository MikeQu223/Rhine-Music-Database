/*
 * T15-C18-A4 — Android 本地 WebView 复刻宿主（计划候选 E，native 宿主侧）
 *
 * 角色：本文件只做「宿主」这一侧的事——把 Qt 已经发布的 commands / hits / frame 原样转交给页面，
 * 把页面唯一暴露的 rail 反过来调用一遍，并且把页面限制在一个虚拟 https origin 后面。
 * 宿主不重画 HUD、不解释命令、不改写 hits、不重新计算舞台（Qt 是规格，本文件只重推导，绝不发明协议）。
 *
 * 契约来源（Qt 是规格）：
 *   Qt/src/NativeHud.h:74-76                        commands / hits / frame 是唯一被发布的 HUD 值
 *   Qt/src/NativeHud.cpp:102-109                    hits 元素恰好 {x,y,width,height,action,label}
 *   Qt/src/Engine.cpp:841-849                       resize：stageScale = height/1080；同一尺寸直接返回
 *   Qt/src/Engine.cpp:674-690,1378-1387             publishHudFrame 只 emit hudUpdated（宿主不重画）
 *   Qt/src/NativeApplication.cpp:147-151,187-191    发布对象是 {commands,hits,state,current,cover}
 *   docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:213
 *                                                   generation 只做一致性校验，禁止去重合法相同的命令
 *   docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:178
 *                                                   横屏 stageScale = heightLogical/1080，旋转只重算舞台
 *   web/rhine_replica/index.html:6                   CSP 原文（响应头必须与它逐字相同）
 *   web/rhine_replica/index.html:114-147             resize 入参是逻辑宽高，stage 由页面自己算
 *   web/rhine_replica/index.html:215-254             publish 的三元组校验
 *   web/rhine_replica/index.html:378-391             window.__rhineRail 方法表 + ready 信号
 *   web/rhine_replica/index.html:76-87               页面出站只走 __rhineHost / RhineHostBridge.postMessage
 *   web/rhine_replica/index.html:286-293             loadAssets 只用同源相对路径 fetch
 *   integration_test/slice_webview_test.dart:81-107  H1..H5 宿主断言（本文件的目标）
 *
 * 【RED-not-executed】本文件从未在设备上运行，也没有执行 flutter / dart / gradle 任何命令（本卡硬禁令）。
 * 所有 Build.VERSION / WebView 版本差异分支只是代码与注释，不构成实测结论。
 *
 * 【禁改】不碰 pubspec.yaml、AndroidManifest.xml、MainActivity.kt、CMakeLists、models、HUD 协议定义。
 * 本文件不注册 Activity、不建进程、不启动 Node。
 */

package rhine.music.database.porting

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.content.res.AssetManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * 出站事件接收端（Flutter 侧通常接到 MethodChannel）。
 *
 * 只是一根管子：宿主不解析、不合并、不改写页面发来的 JSON。
 */
interface ReplicaHostSink {
    /** 页面出站消息（原样 JSON 文本，index.html:76-87 的 {type,payload}）。 */
    fun onHostEvent(json: String)

    /** 宿主自己发现的错误（拒绝的请求、异常），只给诊断用。 */
    fun onHostError(code: String, detail: String)

    companion object {
        val NONE: ReplicaHostSink = object : ReplicaHostSink {
            override fun onHostEvent(json: String) {}
            override fun onHostError(code: String, detail: String) {}
        }
    }
}

/**
 * 素材来源抽象。
 *
 * 为什么不直接写死 assets.open()：pubspec.yaml:60-63 与 :71-89 的 assets / fonts 段目前是注释状态，
 * web/ 与 Assets/ 还不会被打进 APK；而这两个文件是共享文件，本卡不许改。把来源抽象出来，
 * 接线的人换一个实现就能在打包修好前继续跑（FlutterReplicaAssetSource 两种相对路径都试）。
 */
interface ReplicaAssetSource {
    /** 打开仓库相对路径；不存在返回 null。 */
    fun open(repoRelativePath: String): InputStream?

    /** 是否打包了这份素材（诊断用）。 */
    fun exists(repoRelativePath: String): Boolean
}

/** 从 APK 的 assets 里读：先按 flutter_assets/ 前缀，再按裸路径（打包方式两种都可能）。 */
class FlutterReplicaAssetSource(context: Context) : ReplicaAssetSource {

    private val assets: AssetManager = context.applicationContext.assets

    override fun open(repoRelativePath: String): InputStream? {
        val candidates = arrayOf("flutter_assets/" + repoRelativePath, repoRelativePath)
        for (candidate in candidates) {
            try {
                return assets.open(candidate)
            } catch (e: IOException) {
                // 试下一个候选；都失败就是真的没有。
            }
        }
        return null
    }

    override fun exists(repoRelativePath: String): Boolean {
        val stream = open(repoRelativePath)
        if (stream == null) return false
        try {
            stream.close()
        } catch (e: IOException) {
            // 关闭失败不影响"存在"这个结论。
        }
        return true
    }
}

/** 页面 rail 的方法名。**编译期常量**，外部字符串永远进不了这里。 */
enum class ReplicaRailMethod(val jsName: String) {
    RESIZE("resize"),
    PUBLISH("publish"),
    STATE("state"),
    CONFORMANCE("conformance"),
    HELLO("hello"),
    ATTACH_ASSET("attachAsset"),
    ATTACH_IMAGE("attachImage"),
    LOAD_ASSETS("loadAssets"),
}

/** 计数器（诊断用，全部原子）。 */
class ReplicaCounters {
    val intercepts = AtomicInteger()
    val served = AtomicInteger()
    val deniedOrigin = AtomicInteger()
    val deniedPath = AtomicInteger()
    val deniedDocumentEntry = AtomicInteger()
    val deniedMethod = AtomicInteger()
    val missingAsset = AtomicInteger()
    val pageMessages = AtomicInteger()
    val droppedNotReady = AtomicInteger()
    val droppedNoView = AtomicInteger()
    val droppedOversize = AtomicInteger()
    val droppedUntrusted = AtomicInteger()
    val droppedQueueFull = AtomicInteger()
    val railCalls = AtomicInteger()
    val railResults = AtomicInteger()
}

/**
 * 本地 WebView 复刻的宿主。
 *
 * ## 安全模型（四条，缺一条就不算通过）
 * 1. **虚拟 origin，无网络**：页面只从 ORIGIN 加载；shouldInterceptRequest 是唯一出站口，
 *    它**永远**返回响应、永不返回 null（null 等于把请求交给网络栈）。
 * 2. **白名单路径**：先百分号单遍解码，再按段校验（拒绝空段、点段、两点段、反斜杠、NUL、二次编码残留），
 *    规范化后**精确查表** VIRTUAL_PATHS；没有前缀通配、不接受绝对路径，未命中就是 404 且不读磁盘。
 * 3. **MIME 精确**：按扩展名查 CONTENT_TYPE_BY_EXTENSION；查不到就是 404，未知扩展名**永远不回** text/html。
 * 4. **入站参数必须转义**：所有 evaluateJavascript 的参数都过 jsStringLiteral；方法名来自
 *    ReplicaRailMethod 编译期常量。
 *
 * ## 状态机（H1/H2 的落地）
 * start() → 加载 INDEX_URL → 页面发 ready（index.html:391）→ isRailReady() 变真
 * → resize 至少投递过一次（sizingDelivered）→ 之后 publish 才被接受。
 *
 * 两种"早到"的处理**故意不同**：
 *   * 尺寸是**状态**：可安全延后重放（只留最后一组，H2 要求 resize 先于任何 publish）；
 *   * 帧三元组是**代次**：绝不排队补发，早到就丢弃并计数（plan:213 禁止拿上一代的 commands 配这一代的 frame）。
 *
 * ## 线程
 * WebView 不是线程安全的：本类所有公开方法都必须在主线程调用（checkMainThread）。
 * shouldInterceptRequest 与 JS 桥回调跑在 WebView 自己的线程，这两处只做纯计算，
 * 需要回调 Flutter 时一律 post 回主线程。
 *
 * ## 单例
 * 进程内只应有一个宿主（Qt 单 surface 语义；integration_test H5：resume 不重建）。
 * liveInstance 只用于**诊断**：发现第二个实例时记 singletonConflicts 并打日志，不抛异常
 * （热重启、widget 重建会合法地重建）。Node 进程单例 / 48 MiB 上限 / 30 s 超时 / 8 MiB 栈是 T21
 * NodeRuntimeHost 的契约（plan:525-528），**不在本文件**：这里只标注边界，不建进程、不持栈。
 *
 * ## IME / 无障碍边界
 * WebView 不得获得焦点去接管输入法：页面 root 是 pointer-events:none + touch-action:none
 * （index.html:19），指针本来就归 Flutter；configureSettings 里再把焦点与无障碍节点摘掉，
 * 保证软键盘不会被一次点击抢走，TalkBack 读到的只有 Flutter 的语义树（页面不提供 semantic 节点）。
 */
class WebViewReplicaHost @JvmOverloads constructor(
    context: Context,
    private val sink: ReplicaHostSink = ReplicaHostSink.NONE,
    private val webViewFactory: ((Context) -> WebView)? = null,
    private val assetSource: ReplicaAssetSource = FlutterReplicaAssetSource(context),
    private val blockNetworkLoads: Boolean = true,
) {

    companion object {
        private const val TAG = "RhineWebView"

        /** 虚拟 origin。.localhost 是保留 TLD，永不出网，真机上也解析不到任何公网地址。 */
        const val ORIGIN_SCHEME = "https"
        const val ORIGIN_HOST = "rhine-replica.localhost"
        const val ORIGIN = "https://rhine-replica.localhost"

        /** 唯一的文档入口。 */
        const val INDEX_PATH = "/index.html"
        const val INDEX_URL = "https://rhine-replica.localhost/index.html"

        /**
         * 响应头 CSP = index.html:6 的 meta **逐字相同**。
         *
         * 为什么不能更严：这个文档有三块内联内容——
         *   index.html:17-23   内联 style 块
         *   index.html:30      内联 importmap
         *   index.html:33-393  内联 rail（window.__rhineRail 就在这里）
         * 把 script-src 收紧成 'self'（或把 style-src 收紧成 'self'）会同时打掉这三块，
         * rail 根本不会注册，之后所有 evaluateJavascript 全部落空。所以这里是**与 meta 对齐**，
         * 是"不发更松的策略"，不是"放宽"。
         *
         * 为什么不再追加 frame-ancestors / worker-src：与 meta 逐字相同才可审计（一字不差的等号）。
         * 被嵌 frame 的风险由 shouldOverrideUrlLoading 恒返回 true 与本 WebView 只被本应用持有覆盖；
         * 子 frame 也因为 default-src 'none' 无法创建。
         */
        const val CSP_DOCUMENT =
            "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'unsafe-inline'; " +
                "img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; " +
                "form-action 'none'"

        /** 单条出站消息上限（UTF-16 字符数）。宿主自定，不是 Qt 值：出站只传元数据，不传像素。 */
        private const val MAX_OUTBOUND_CHARS = 1048576

        /** 桥回调排队上限：超过就丢，避免页面刷屏把主线程打满。 */
        private const val MAX_PENDING_OUTBOUND = 512

        /** attachImage 的 data URL 上限（字符数）。宿主自定；封面远小于此。 */
        private const val MAX_IMAGE_DATA_URL_CHARS = 4194304

        /** 路径长度上限，防病态输入。 */
        private const val MAX_PATH_CHARS = 512

        /** 逻辑尺寸上限（Qt 只见过 1920x1080 级别；这个上限只拒绝明显坏值）。 */
        private const val MAX_LOGICAL_PX = 20000.0

        /** 页面传入的素材 key（attachAsset / attachImage）长度上限。 */
        private const val MAX_KEY_CHARS = 128

        /**
         * 虚拟路径 → 仓库相对路径。**逐条列出，没有任何前缀通配**（父指令 m00150 的硬要求）。
         *
         * 为什么必须逐条：通配放行等于把"目录里有什么"变成攻击面——多放一个文件就多一条可读路径。
         * 这里每条都对应仓库里真实存在、且页面真的会请求的文件：
         *
         *   /                                        index.html:26-32 的文档根
         *   /index.html                              web/rhine_replica/index.html（395 行）
         *   /renderer.js                             index.html:31 的 <script src>
         *   /three_scene.js                          index.html:32 的 module script（本原子尚未交付该文件）
         *   /vendor/three/build/three.module.js      index.html:42 的 importmap 目标 "three"
         *   /vendor/three/examples/jsm/loaders/GLTFLoader.js         importmap 的 "three/addons/" 前缀
         *   /vendor/three/examples/jsm/utils/BufferGeometryUtils.js  GLTFLoader.js:68 的唯一相对 import
         *   /assets/fonts/misans-glyphs.json         index.html:315 的 fetchJson
         *   /assets/fonts/boot-lettering-art.json    index.html:320 的 fetchJson —— **非对称映射，见下**
         *   /assets/models/archive-assembly.glb      Assets/models/ 里的自包含 GLB（3 343 744 B）
         *   /assets/models/archive-cassette.glb      Assets/models/ 里的自包含 GLB（3 565 116 B）
         *
         * vendor/ 实测只有这三个 .js（外加 LICENSE 与 VENDOR.md，二者不供页面加载）；
         * GLTFLoader.js:68 只 import '../utils/BufferGeometryUtils.js'，其余只 import 'three'，
         * 所以两个 addons 条目足够，不为 vendor 开放任何目录。
         *
         * 两个 GLB 都是自包含的（magic 'glTF'，前 200 KB 内没有 "uri"），不会连带请求 .bin 或贴图，
         * 因此白名单里**不为模型开放任何目录**，也不提供 .bin 映射。
         *
         * 【非对称映射，必须保留】index.html:312 把 lettering 的默认基址也设成 './assets/fonts/'
         * （base 与 artPrefix 共用同一个 prefix），于是页面请求
         * /assets/fonts/boot-lettering-art.json；但磁盘上这份文件在 Resources/，Assets/fonts/ 下没有。
         * 所以这一条**故意映射到 Resources/boot-lettering-art.json**，而不是"先找 Assets/fonts 再回退"
         * ——单一来源，不做二级回退。漏掉它首帧文字必然 404，并被 renderer 记进 assetErrors
         * （index.html:320-322）。
         */
        private val VIRTUAL_PATHS: Map<String, String> = mapOf(
            "/" to "web/rhine_replica/index.html",
            INDEX_PATH to "web/rhine_replica/index.html",
            "/renderer.js" to "web/rhine_replica/renderer.js",
            "/three_scene.js" to "web/rhine_replica/three_scene.js",
            "/vendor/three/build/three.module.js" to "web/rhine_replica/vendor/three/build/three.module.js",
            "/vendor/three/examples/jsm/loaders/GLTFLoader.js" to
                "web/rhine_replica/vendor/three/examples/jsm/loaders/GLTFLoader.js",
            "/vendor/three/examples/jsm/utils/BufferGeometryUtils.js" to
                "web/rhine_replica/vendor/three/examples/jsm/utils/BufferGeometryUtils.js",
            "/assets/fonts/misans-glyphs.json" to "Assets/fonts/misans-glyphs.json",
            // 非对称：虚拟路径在 fonts/，磁盘在 Resources/。理由见上（index.html:312 的默认基址）。
            "/assets/fonts/boot-lettering-art.json" to "Resources/boot-lettering-art.json",
            "/assets/models/archive-assembly.glb" to "Assets/models/archive-assembly.glb",
            "/assets/models/archive-cassette.glb" to "Assets/models/archive-cassette.glb",
        )

        /** 允许承载文档的两个虚拟路径（"/" 与 "/index.html" 指向同一个文件）。 */
        private val DOCUMENT_PATHS: Set<String> = setOf("/", INDEX_PATH)

        /**
         * 扩展名 → Content-Type。表里没有的扩展名**直接 404**（父指令 m00150：未知扩展名不回退，
         * 尤其不回退 text/html——把未知字节当文档执行就是 XSS 的入口）。
         *
         * VIRTUAL_PATHS 现在只用到 .html / .js / .json / .glb 四种；多列出的几项（css / 字体 / 图片）
         * 是给后续原子加路径时用的，而且必须**同时**加进 VIRTUAL_PATHS 才会生效。
         *
         * text/* 与 application/json 显式带 charset=utf-8：index.html 与 renderer.js 里全是中文。
         */
        private val CONTENT_TYPE_BY_EXTENSION: Map<String, String> = mapOf(
            "html" to "text/html; charset=utf-8",
            "htm" to "text/html; charset=utf-8",
            "js" to "text/javascript; charset=utf-8",
            "mjs" to "text/javascript; charset=utf-8",
            "css" to "text/css; charset=utf-8",
            "json" to "application/json; charset=utf-8",
            "glb" to "model/gltf-binary",
            "gltf" to "model/gltf+json",
            "wasm" to "application/wasm",
            "otf" to "font/otf",
            "ttf" to "font/ttf",
            "woff" to "font/woff",
            "woff2" to "font/woff2",
            "png" to "image/png",
            "jpg" to "image/jpeg",
            "jpeg" to "image/jpeg",
            "webp" to "image/webp",
            "svg" to "image/svg+xml",
            "txt" to "text/plain; charset=utf-8",
        )

        /** index.html:300-308 允许的素材基址；其它基址一律拒绝（远程基址、绝对文件路径都不在白名单）。 */
        private val ALLOWED_ASSET_BASES: Set<String> = setOf(
            "./assets/fonts/",
            "./assets/letters/",
            "/assets/fonts/",
            "/assets/letters/",
        )

        /** 允许 attachAsset 的 kind（index.html:326-337 的 kind 表）。 */
        private val ALLOWED_ASSET_KINDS: Set<String> = setOf("glyphs", "lettering", "image")

        /** 诊断用；只读，不做强制。 */
        @Volatile
        private var liveInstance: WebViewReplicaHost? = null
    }

    // ── 状态 ────────────────────────────────────────────────────────────────────────────────────

    /**
     * 创建 WebView 用的 Context。第一次创建后立刻置空：WebView 自己要持有 activity 上下文，
     * 但宿主不该为它多留一份引用（否则 Flutter 侧重建 Activity 时这里就是泄漏点）。
     */
    private var creationContext: Context? = context

    private val applicationContext: Context = context.applicationContext

    private val mainHandler = Handler(Looper.getMainLooper())

    private val counters = ReplicaCounters()

    private var webView: WebView? = null

    /** 页面发过 ready（index.html:391）之后为真。只认第一次，后面重复的 ready 只计数。 */
    @Volatile
    private var railReady = false

    /** resize 至少投递过一次。publish 之前的硬性前提（H2）。 */
    @Volatile
    private var sizingDelivered = false

    /** 早到（ready 之前）的尺寸：只留最后一组，ready 后重放。 */
    private var pendingResize: Pair<Double, Double>? = null

    /** 页面 ready 时带出来的 hello 结果（原样 JSON）。 */
    private var helloJson: String? = null

    /**
     * 早到（ready 之前）的素材加载请求。
     *
     * 与 resize 同类：loadAssets 是**命令**不是帧，重复投递最多多读一次文件，不会产生错误代次，
     * 所以可以安全地延后重放；而 publish 是代次，早到必须丢弃。
     */
    private var pendingAssetLoad: Pair<String, String>? = null

    /** 桥回调排队数；只在主线程读写。 */
    private var pendingOutbound = 0

    @Volatile
    private var destroyed = false

    @Volatile
    private var rendererGone = false

    @Volatile
    private var singletonConflicts = 0

    private var lastConsoleLevel = ""
    private var lastConsoleMessage = ""

    init {
        val previous = liveInstance
        if (previous != null && previous !== this) {
            singletonConflicts = (previous.singletonConflicts + 1)
            Log.w(TAG, "第二个 WebViewReplicaHost 实例；首实例=" + previous + "（Qt 单 surface 语义要求进程内只有一个）")
        }
        liveInstance = this
    }

    // ── 公开 API ───────────────────────────────────────────────────────────────────────────────

    /** 持有者要显示的 WebView（首次调用时创建并硬化）。必须在主线程调用。 */
    fun obtainView(): WebView {
        checkMainThread()
        val existing = webView
        if (existing != null) return existing

        val creation = creationContext
        val base = creation ?: applicationContext
        val created = webViewFactory?.invoke(base) ?: WebView(base)
        creationContext = null

        configureSettings(created)
        installClients(created)
        installBridge(created)

        webView = created
        Log.i(TAG, "WebView 创建完成；origin=" + ORIGIN + " 版本=" + describeWebViewVersion(created))
        return created
    }

    /** 当前 WebView（未创建为 null）。 */
    fun viewOrNull(): WebView? = webView

    /**
     * 加载 index.html。重复调用是 no-op（H5：resume 不重建页面）。
     *
     * 只在 url 还是 null 时 loadUrl：已经加载过、甚至已经加载失败，都不重来一遍——
     * 重来会造成页面状态与 Flutter 侧 generation 脱节，这正是 H5 要防的。
     */
    fun start() {
        checkMainThread()
        if (destroyed) return
        val view = obtainView()
        if (view.url != null) {
            Log.i(TAG, "start() 忽略：页面已在 " + view.url + "（不 reload）")
            return
        }
        view.loadUrl(INDEX_URL)
    }

    /** 对应 Flutter 的 AppLifecycleState.resumed：只恢复，不 reload（H5）。 */
    fun onResume() {
        checkMainThread()
        if (destroyed) return
        val view = webView ?: return
        view.onResume()
        view.resumeTimers()
    }

    /**
     * 对应 AppLifecycleState.paused / inactive：只暂停渲染与定时器，不销毁、不 reload。
     * 页面里的 requestAnimationFrame 会自然停摆；WS/GL 资源留在原地。
     */
    fun onPause() {
        checkMainThread()
        if (destroyed) return
        val view = webView ?: return
        view.onPause()
        view.pauseTimers()
    }

    /** 幂等销毁。之后本实例不可再用。 */
    fun destroy() {
        checkMainThread()
        if (destroyed) return
        destroyed = true
        railReady = false
        sizingDelivered = false
        pendingResize = null
        pendingAssetLoad = null
        pendingOutbound = 0

        val view = webView
        webView = null
        if (view != null) {
            // 顺序有意义：先摘桥（否则页面还能回调），再停加载，再离开文档，最后才 destroy。
            runCatching { view.removeJavascriptInterface(BRIDGE_NAME_PRIMARY) }
            runCatching { view.removeJavascriptInterface(BRIDGE_NAME_ALIAS) }
            runCatching { view.stopLoading() }
            runCatching { view.loadUrl("about:blank") }
            runCatching { view.setWebChromeClient(null) }
            runCatching { view.setWebViewClient(WebViewClient()) }
            runCatching { view.destroy() }
        }
        if (liveInstance === this) liveInstance = null
    }

    /** 页面 ready 过没有（H1 的宿主侧观察点）。 */
    fun isRailReady(): Boolean = railReady

    /** resize 投递过没有（H2）。 */
    fun isSizingDelivered(): Boolean = sizingDelivered

    fun isDestroyed(): Boolean = destroyed

    fun isRendererGone(): Boolean = rendererGone

    fun diagnostics(): ReplicaCounters = counters

    // ── rail 出站调用（宿主 → 页面） ─────────────────────────────────────────────────────────────

    /**
     * 舞台尺寸。**参数是逻辑像素**，与 Qt/src/Engine.cpp:841-849 的入参同义；
     * 舞台换算（stageScale = height/1080）由页面自己做（index.html:114-147），宿主不重算。
     *
     * 早到（ready 之前）时只记最后一组，ready 后重放：尺寸是状态，重复投递幂等（H2）。
     */
    fun resize(logicalWidth: Double, logicalHeight: Double): Boolean {
        checkMainThread()
        if (!isUsableSize(logicalWidth) || !isUsableSize(logicalHeight)) {
            sink.onHostError("bad-size", "width=" + logicalWidth + " height=" + logicalHeight)
            return false
        }
        pendingResize = Pair(logicalWidth, logicalHeight)
        return flushResizeIfReady()
    }

    /**
     * 发布一帧 HUD。payload 必须是带 generation 的对象（index.html:215-254 的校验）。
     *
     * 传的是**字符串**而不是 JSONObject：本宿主不重新序列化调用方的 JSON，避免把 1728 写成 1728.0。
     *
     * 返回 false 表示**没有投递**（未 ready / 无视图 / 参数不合法），不表示页面执行失败。
     * 未 ready 的帧直接丢弃、不排队：代次不能补发（plan:213）。
     */
    fun publish(payloadJson: String): Boolean {
        checkMainThread()
        if (!validatePublishPayload(payloadJson)) return false
        if (!railReady) {
            counters.droppedNotReady.incrementAndGet()
            return false
        }
        if (!sizingDelivered) {
            // H2 硬约束：舞台还没定就不许发帧，否则 hits 会按上一尺寸解释。
            counters.droppedNotReady.incrementAndGet()
            sink.onHostError("publish-before-resize", "resize 尚未投递")
            return false
        }
        return callObjectRail(ReplicaRailMethod.PUBLISH, payloadJson)
    }

    /**
     * 三元组便捷入口：generation + commands + hits + frame 一起走（H3）。
     *
     * 这里**不做去重**：plan:213 明确 generation 只做一致性校验，不得去掉合法的相同命令。
     */
    fun publishParts(generation: Long, commandsJson: String, hitsJson: String, frameJson: String): Boolean {
        checkMainThread()
        if (!isJsonArray(commandsJson)) {
            sink.onHostError("bad-commands", "commands 必须是 JSON 数组")
            return false
        }
        if (!isJsonArray(hitsJson)) {
            sink.onHostError("bad-hits", "hits 必须是 JSON 数组")
            return false
        }
        if (!isJsonObject(frameJson)) {
            sink.onHostError("bad-frame", "frame 必须是 JSON 对象")
            return false
        }
        val composed = StringBuilder(payloadJsonLengthHint(commandsJson, hitsJson, frameJson))
        composed.append("{\"generation\":").append(generation.toString())
        composed.append(",\"commands\":").append(commandsJson)
        composed.append(",\"hits\":").append(hitsJson)
        composed.append(",\"frame\":").append(frameJson)
        composed.append("}")
        return publish(composed.toString())
    }

    /** 页面当前状态（index.html:282-284 的 state）。 */
    fun requestState(): Boolean = callRail(ReplicaRailMethod.STATE, emptyList(), forwardResult = true)

    /** 一致性自检（index.html:666-696 的 12 条）；结果上报给 sink。 */
    fun conformance(): Boolean = callRail(ReplicaRailMethod.CONFORMANCE, emptyList(), forwardResult = true)

    /** hello()（index.html:358-376）；正常路径下页面 ready 时已经自带一份。 */
    fun hello(): Boolean = callRail(ReplicaRailMethod.HELLO, emptyList(), forwardResult = true)

    /** 喂素材：kind ∈ glyphs | lettering | image（index.html:326-337）。value 是 JSON 文本。 */
    fun attachAsset(kind: String, key: String, valueJson: String): Boolean {
        checkMainThread()
        if (!ALLOWED_ASSET_KINDS.contains(kind)) {
            sink.onHostError("unknown-kind", kind)
            return false
        }
        if (!isUsableKey(key)) {
            sink.onHostError("bad-key", "key 长度非法")
            return false
        }
        if (!isValidJson(valueJson)) {
            sink.onHostError("bad-asset", "value 不是合法 JSON")
            return false
        }
        return callRail(
            ReplicaRailMethod.ATTACH_ASSET,
            listOf(jsStringLiteral(kind), jsStringLiteral(key), jsonParseExpression(valueJson)),
            forwardResult = false,
        )
    }

    /**
     * 喂图片：只接受 data:image/* 的 base64 data URL（index.html:339-356）。
     * http / https / file / blob 一律拒绝——那些等于让页面去取外部资源。
     */
    fun attachImage(key: String, dataUrl: String): Boolean {
        checkMainThread()
        if (!isUsableKey(key)) {
            sink.onHostError("bad-key", "key 长度非法")
            return false
        }
        if (dataUrl.length > MAX_IMAGE_DATA_URL_CHARS) {
            sink.onHostError("image-too-large", "chars=" + dataUrl.length)
            return false
        }
        // 头部（scheme + media type + 编码段）统一降成小写再比对：data URL 的 "BASE64" 大小写不敏感，
        // 但 base64 正文本身必须原样保留（因此只降头部，不碰逗号之后的内容）。
        val headLength = minOf(64, dataUrl.length)
        val head = dataUrl.substring(0, headLength).lowercase(Locale.ROOT)
        if (!head.startsWith("data:image/") || !head.contains(";base64,")) {
            sink.onHostError("bad-image-source", "只接受 data:image/*;base64,")
            return false
        }
        return callRail(
            ReplicaRailMethod.ATTACH_IMAGE,
            listOf(jsStringLiteral(key), jsStringLiteral(dataUrl)),
            forwardResult = false,
        )
    }

    /** 让页面自己去取素材（index.html:299-324）；基址必须在白名单里。 */
    fun loadAssets(base: String, letteringBase: String): Boolean {
        checkMainThread()
        if (!ALLOWED_ASSET_BASES.contains(base) || !ALLOWED_ASSET_BASES.contains(letteringBase)) {
            sink.onHostError("bad-asset-base", base + " / " + letteringBase)
            return false
        }
        pendingAssetLoad = Pair(base, letteringBase)
        return flushAssetLoadIfReady()
    }

    // ── 出站拦截（页面 → 虚拟磁盘） ─────────────────────────────────────────────────────────────

    /**
     * 唯一的资源入口。**永远返回非 null**：返回 null 等于把请求交给网络栈，
     * 那正是本卡要杜绝的第 0 号漏洞。
     *
     * 判定顺序固定为 origin → 规范化 → 精确查表 → 读盘，任何一步失败都在读盘之前返回：
     *   * origin 不符（scheme / host / port / userInfo）           → 403（这是"另一个站点"，不是路径问题）
     *   * query / fragment / 大写 path / 未命中表 / MIME 未知        → 404（同一个规范化结果上的未命中）
     *   * 主文档却不在 DOCUMENT_PATHS                             → 403（禁止页面导航到别的路径）
     *   * 素材不存在（真的没打包）                                 → 404
     */
    private fun intercept(request: WebResourceRequest?): WebResourceResponse {
        counters.intercepts.incrementAndGet()
        if (request == null) return deny(400, "null-request")

        val uri: Uri = request.url
        if (uri == null) return deny(400, "null-url")

        // 1) origin：三要素全等才继续。https 的默认端口就是 -1，显式写 443 也算不符（不给第二个来源）。
        if (uri.scheme != ORIGIN_SCHEME || uri.host != ORIGIN_HOST || uri.port != -1 || uri.userInfo != null) {
            counters.deniedOrigin.incrementAndGet()
            return deny(403, "origin")
        }

        val method = request.method
        if (method != null && method != "GET") {
            // 页面只会 GET；POST/HEAD 之类一律拒绝，避免把拦截器当成上传通道。
            counters.deniedMethod.incrementAndGet()
            return deny(405, "method")
        }

        // 2) query / fragment：两者都让"同一个路径"产生多个地址，直接 404，不做兼容。
        if (uri.query != null || uri.fragment != null) return deny(404, "query")

        val rawPath = uri.encodedPath ?: return deny(404, "empty-path")
        val path = normalizePath(rawPath)
        if (path == null) {
            counters.deniedPath.incrementAndGet()
            return deny(404, "path")
        }

        // 3) 主文档只允许两个入口（"/" 与 "/index.html"），否则一次导航就能把 WebView 带去别的路径。
        if (request.isForMainFrame && !DOCUMENT_PATHS.contains(path)) {
            counters.deniedDocumentEntry.incrementAndGet()
            return deny(403, "document-entry")
        }

        // 4) 精确查表：没有前缀匹配，没有目录拼接。
        val repoPath = VIRTUAL_PATHS[path]
        if (repoPath == null) {
            counters.deniedPath.incrementAndGet()
            return deny(404, "not-whitelisted")
        }

        // 5) MIME 必须在**读盘之前**就确定：未知扩展名不打开文件，直接 404。
        val contentType = contentTypeOf(repoPath)
        if (contentType == null) {
            counters.deniedPath.incrementAndGet()
            return deny(404, "unknown-type")
        }

        // 6) 只有白名单 + 已知 MIME 才真正碰磁盘。
        val stream = try {
            assetSource.open(repoPath)
        } catch (e: IOException) {
            Log.w(TAG, "读素材失败 " + repoPath + "：" + e.message)
            null
        }
        if (stream == null) {
            counters.missingAsset.incrementAndGet()
            return deny(404, "missing-asset")
        }

        counters.served.incrementAndGet()
        return serve(contentType, stream)
    }

    /**
     * 路径规范化：**单遍**百分号解码 + 逐段校验，结果要么是干净的绝对路径，要么 null。
     *
     * 拒绝的一切（都落到调用方的 404）：
     *   * 不以 / 开头（绝对路径 / 相对路径注入）
     *   * 空段与 "//"（目录歧义）、"." 与 ".."（穿越）
     *   * 反斜杠（Windows 分隔符绕过）、冒号（盘符 / URL scheme 残留）、NUL 与全部控制字符
     *   * 解码后仍然含 %（二次编码：%252e%252e 之类）
     *   * 解码产生 / 或 \ 或 NUL（%2f、%5c、%00 —— 编码过的分隔符就是在拆段）
     *   * 长度超 MAX_PATH_CHARS，或含非 ASCII（本卡的路径全是 ASCII；中文只出现在文件内容里）
     *
     * 大小写**不归一化**：表里全是小写，/INDEX.HTML 查不到就是 404。这样"大小写不同"不会变成第二个来源。
     */
    private fun normalizePath(rawPath: String): String? {
        if (rawPath.isEmpty() || rawPath.length > MAX_PATH_CHARS) return null
        if (!rawPath.startsWith("/")) return null
        if (rawPath.contains("//")) return null

        val decoded = StringBuilder(rawPath.length)
        var index = 0
        while (index < rawPath.length) {
            val ch = rawPath[index]
            val code = ch.code
            if (code == 0x25) { // '%'
                if (index + 2 >= rawPath.length) return null
                val hi = hexValue(rawPath[index + 1])
                val lo = hexValue(rawPath[index + 2])
                if (hi < 0 || lo < 0) return null
                val byte = (hi shl 4) or lo
                if (byte <= 0x1f || byte == 0x7f) return null // %00-%1f, %7f
                if (byte == 0x25 || byte == 0x2f || byte == 0x5c) return null // %25 %2f %5c
                if (byte > 0x7e) return null // 只允许 ASCII，杜绝编码混淆
                decoded.append(byte.toChar())
                index += 3
                continue
            }
            if (code < 0x21 || code > 0x7e) return null // 控制字符 / 空格 / 非 ASCII
            if (code == 0x5c) return null // '\'
            if (code == 0x3a) return null // ':'
            decoded.append(ch)
            index += 1
        }

        val normalized = decoded.toString()
        if (normalized.isEmpty() || normalized.length > MAX_PATH_CHARS) return null
        if (!normalized.startsWith("/")) return null

        val segments = normalized.split("/")
        // split("/") 对 "/a/b" 给出 ["", "a", "b"]；首段必须是空串（已经校验过开头是 /）。
        for (position in 1 until segments.size) {
            val segment = segments[position]
            if (segment.isEmpty()) return null
            if (segment == "." || segment == "..") return null
        }
        return normalized
    }

    private fun hexValue(ch: Char): Int {
        val code = ch.code
        if (code >= 0x30 && code <= 0x39) return code - 0x30
        if (code >= 0x41 && code <= 0x46) return code - 0x41 + 10
        if (code >= 0x61 && code <= 0x66) return code - 0x61 + 10
        return -1
    }

    /** 按扩展名取 Content-Type；未知扩展名返回 null（调用方 404，绝不回退 text/html）。 */
    private fun contentTypeOf(repoPath: String): String? {
        val dot = repoPath.lastIndexOf('.')
        if (dot < 0 || dot == repoPath.length - 1) return null
        val extension = repoPath.substring(dot + 1).lowercase(Locale.ROOT)
        return CONTENT_TYPE_BY_EXTENSION[extension]
    }

    /**
     * 正常响应。所有响应都带同一组硬化头：
     *   X-Content-Type-Options: nosniff      不许浏览器猜类型
     *   Cache-Control: no-store              复刻页每次都是新的，不许缓存留旧版
     *   Referrer-Policy: no-referrer         不泄漏虚拟 origin
     *   Cross-Origin-Resource-Policy: same-origin  连跨 origin 被读都不允许
     * 另外**不发** Access-Control-Allow-Origin：同源页面不需要它，发了就是给别的 origin 开门。
     *
     * CSP 只在文档响应上发（父指令 m00150 的要求），值与 index.html:6 的 meta 逐字相同。
     */
    private fun serve(contentType: String, stream: InputStream): WebResourceResponse {
        val headers = HashMap<String, String>()
        headers["X-Content-Type-Options"] = "nosniff"
        headers["Cache-Control"] = "no-store"
        headers["Referrer-Policy"] = "no-referrer"
        headers["Cross-Origin-Resource-Policy"] = "same-origin"
        if (contentType.startsWith("text/html")) {
            headers["Content-Security-Policy"] = CSP_DOCUMENT
        }
        val response = WebResourceResponse(contentType, null, 200, "OK", headers, stream)
        response.setImmutable(true)
        return response
    }

    /**
     * 拒绝响应。body 恒为空、reason 恒为固定串：**绝不回显请求路径**，不给探测者任何反馈。
     * 同样带 nosniff 与 no-store，且不带 CORS 头。
     */
    private fun deny(status: Int, reason: String): WebResourceResponse {
        val headers = HashMap<String, String>()
        headers["X-Content-Type-Options"] = "nosniff"
        headers["Cache-Control"] = "no-store"
        headers["Referrer-Policy"] = "no-referrer"
        headers["Cross-Origin-Resource-Policy"] = "same-origin"
        val response = WebResourceResponse(
            "text/plain; charset=utf-8",
            null,
            status,
            denyReasonPhrase(status),
            headers,
            ByteArrayInputStream(ByteArray(0)),
        )
        response.setImmutable(true)
        Log.w(TAG, "拒绝请求：" + reason + " status=" + status)
        return response
    }

    private fun denyReasonPhrase(status: Int): String {
        return when (status) {
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            else -> "Denied"
        }
    }

    // ── 客户端（导航 / 错误 / 渲染进程 / 控制台） ────────────────────────────────────────────────

    private fun installClients(view: WebView) {
        view.webViewClient = ReplicaClient()
        view.webChromeClient = ReplicaChromeClient()
    }

    private inner class ReplicaClient : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse {
            // 注意：这里**不**判断 request.url 之外的任何东西，也绝不返回 null。
            return this@WebViewReplicaHost.intercept(request)
        }

        /**
         * 任何导航都拦下：页面只允许停在 INDEX_URL。
         * 返回 true 而不是靠白名单 403，是为了让 <a target> / location 赋值这类导航也彻底没有出口。
         */
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            Log.w(TAG, "拦下导航：" + request.url)
            sink.onHostError("navigation-blocked", request.url?.toString() ?: "null")
            return true
        }

        override fun onPageFinished(view: WebView, url: String) {
            // 只记日志：pageMessages 这个计数器专用于**桥消息**，导航完成不该混进同一个指标。
            Log.i(TAG, "onPageFinished " + url)
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            // 主文档失败要上报；子资源失败（例如 three_scene.js 还没交付）只记录，不影响宿主状态机。
            val detail = error.errorCode.toString() + " " + error.description
            if (request.isForMainFrame) {
                sink.onHostError("main-document-error", detail)
            } else {
                Log.w(TAG, "子资源失败 " + request.url + "：" + detail)
            }
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
            if (request.isForMainFrame) {
                sink.onHostError("main-document-http", response.statusCode.toString())
            }
        }

        /**
         * 渲染进程挂了：返回 true 表示"我自己处理"，于是系统不杀掉整个应用。
         * 这里**不重建** WebView——重建会得到一张白页，与 Flutter 侧的 generation 彻底脱节。
         * 正确做法是上报，由上层决定是否整体重建（本卡不实现上层策略）。
         */
        @TargetApi(Build.VERSION_CODES.O)
        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            rendererGone = true
            railReady = false
            sizingDelivered = false
            sink.onHostError("renderer-gone", "didCrash=" + detail.didCrash())
            return true
        }
    }

    private inner class ReplicaChromeClient : WebChromeClient() {

        override fun onPermissionRequest(request: PermissionRequest) {
            // 页面不需要摄像头/麦克风；一律拒绝，绝不放行。
            request.deny()
            sink.onHostError("permission-denied", request.origin.toString())
        }

        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
            lastConsoleLevel = message.messageLevel().toString()
            lastConsoleMessage = message.message()
            return true
        }

        override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
            // 页面不该弹 alert；真弹了也自动确认，避免把主线程卡住。
            result.confirm()
            return true
        }
    }

    // ── WebSettings 硬化 ───────────────────────────────────────────────────────────────────────

    /**
     * 设置一次，之后不再变（H5：resume 不重建页面，也就不重配设置）。
     *
     * 每条都写"为什么"，因为这些都是失败关闭（fail-closed）的选择，不是随手抄的安全清单。
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureSettings(view: WebView) {
        val settings = view.settings

        // 页面本身就是 JS 复刻层（renderer.js + rail），必须开。
        settings.javaScriptEnabled = true

        // 三条 file 通道全关：内容只走虚拟 https origin，任何 file:// 直读都是绕过点。
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false

        // 页面状态全在内存里（index.html:55-70 的 state 对象），不需要 DOM storage。
        // 关掉可以少一条持久化面；真需要时再开，但那时要同时确认不与 Flutter 侧状态重复。
        settings.domStorageEnabled = false

        // 不许 window.open 造新窗口（新窗口没有我们的 shouldInterceptRequest 保护）。
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)

        // 自动播放需要用户手势：复刻页只有画面，没有音频需求。
        settings.mediaPlaybackRequiresUserGesture = true

        // 定位权限直接不给；ChromeClient 里也不实现 onGeolocationPermissionsShowPrompt 的放行。
        settings.setGeolocationEnabled(false)

        // 缩放全关：页面按逻辑像素自适应（index.html:114-147），缩放会让命中坐标与 Flutter 对不上。
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.supportZoom = false
        settings.textZoom = 100

        // 不缓存：素材换版本时必须立刻生效，不能读到上一次进程的旧字节。
        settings.cacheMode = WebSettings.LOAD_NO_CACHE

        // 混合内容一律不许：虚拟 origin 是 https，任何 http 子资源都不该出现。
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        /**
         * blockNetworkLoads 默认 true（构造参数可关）。
         *
         * 关键在于：**shouldInterceptRequest 命中的响应不是网络请求**，它不受这个开关影响，
         * 所以置 true 不会妨碍页面加载本地素材。置 true 的收益是失败关闭——
         * 万一将来有人加了一条没被拦截的 URL（比如漏写白名单后想"先让它跑起来"），
         * 它只会立刻失败，而不是悄悄出网。
         *
         * 另注：置 false 需要 INTERNET 权限（Manifest 主文件没有，只有 debug 变体有），
         * 置 true 在任何情况下都合法。这就是默认值的理由。
         */
        settings.blockNetworkLoads = blockNetworkLoads

        // Safe Browsing 对"全部资源都来自本地拦截器"的页面没有意义，且它会在 API 26+ 引入额外网络探测。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.safeBrowsingEnabled = false
        }

        // 不设置 setWebContentsDebuggingEnabled：那是进程级静态开关，改了会影响同进程其他 WebView，
        // 属于宿主之外的全局状态，本卡不碰。

        // 焦点与无障碍：页面 root 已 pointer-events:none（index.html:19），指针归 Flutter；
        // 这里再把焦点与语义节点摘掉，保证一次点击不会把 IME 抢走，TalkBack 也不会读到页面节点。
        view.isFocusable = false
        view.isFocusableInTouchMode = false
        view.isClickable = false
        view.isLongClickable = false
        view.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        view.setBackgroundColor(0xFF000000.toInt()) // index.html:18 的背景就是 #000
        view.overScrollMode = View.OVER_SCROLL_NEVER
        view.isVerticalScrollBarEnabled = false
        view.isHorizontalScrollBarEnabled = false
    }

    // ── JS 桥（页面 → 宿主） ────────────────────────────────────────────────────────────────────

    /**
     * 页面出站通道：window.__rhineHost.postMessage(json) 或 window.RhineHostBridge.postMessage(json)
     * （index.html:76-87 两个名字都试）。
     *
     * 桥对象必须是**public 的静态嵌套类实例**，方法必须带 @JavascriptInterface，
     * 否则 API 17+ 不会把它暴露给页面（这也是安全模型的一部分：只有显式标注的方法可达）。
     *
     * 回调跑在 WebView 自己的 JavaBridge 线程，**不是主线程**：
     * 所以这里只做三步纯计算（大小上限 / 排队上限 / JSON 解析出 type），
     * 真正碰 WebView 与 sink 的动作一律 post 回主线程。
     */
    class Bridge internal constructor(private val host: WebViewReplicaHost) {
        @JavascriptInterface
        fun postMessage(json: String?) {
            host.onBridgeMessage(json)
        }
    }

    private fun installBridge(view: WebView) {
        val bridge = Bridge(this)
        // 两个名字指向同一个对象：页面 index.html:77 先看 __rhineHost 再看 RhineHostBridge。
        view.addJavascriptInterface(bridge, BRIDGE_NAME_PRIMARY)
        view.addJavascriptInterface(bridge, BRIDGE_NAME_ALIAS)
    }

    /** 桥线程入口：只做长度与 JSON 校验，不做任何 UI/WebView 操作。 */
    private fun onBridgeMessage(json: String?) {
        if (json == null) return
        counters.pageMessages.incrementAndGet()
        if (json.length > MAX_OUTBOUND_CHARS) {
            counters.droppedOversize.incrementAndGet()
            return
        }
        val type = readMessageType(json)
        if (type == null) {
            // 不是合法 {type, payload} 形状：既不转发也不崩，只计数。
            counters.droppedUntrusted.incrementAndGet()
            return
        }
        mainHandler.post { handleBridgeMessageOnMainThread(json, type) }
    }

    /** 只认有字符串 type 的 JSON 对象；其它一律视为坏消息。 */
    private fun readMessageType(json: String): String? {
        return try {
            val parsed = JSONObject(json)
            val type = parsed.opt("type")
            if (type is String) type else null
        } catch (e: JSONException) {
            null
        }
    }

    /**
     * 主线程处理桥消息。这里才允许读 WebView 状态（isTrustedDocument 要读 view.url）。
     *
     * 未 ready 之前的 publish/firstFrame 一律丢弃：帧是代次，不排队（plan:213）。
     * ready 本身则推进状态机，并重放早到的 resize（H2）。
     */
    private fun handleBridgeMessageOnMainThread(json: String, type: String) {
        if (destroyed) return
        if (!isTrustedDocument()) {
            counters.droppedUntrusted.incrementAndGet()
            Log.w(TAG, "桥消息来自非受信文档，已丢弃")
            return
        }
        if (pendingOutbound >= MAX_PENDING_OUTBOUND) {
            counters.droppedQueueFull.incrementAndGet()
            return
        }
        pendingOutbound += 1
        try {
            if (type == "ready") {
                railReady = true
                helloJson = json
                flushResizeIfReady()
                flushAssetLoadIfReady()
            }
            sink.onHostEvent(json)
        } finally {
            pendingOutbound -= 1
        }
    }

    /**
     * 早到的尺寸在这里补投。只补**最后一组**（尺寸是状态，重复投递幂等）；
     * 补投成功即置 sizingDelivered，之后 publish 才被允许（H2）。
     */
    private fun flushResizeIfReady(): Boolean {
        if (!railReady) return false
        val pending = pendingResize ?: return false
        val delivered = callRail(
            ReplicaRailMethod.RESIZE,
            listOf(formatNumber(pending.first), formatNumber(pending.second)),
            forwardResult = true,
        )
        if (delivered) sizingDelivered = true
        return delivered
    }

    /**
     * 早到的 loadAssets 在这里补投。语义与 resize 相同（命令可重放），但**顺序**不同：
     * 先 resize 后 loadAssets —— 页面先要知道舞台多大，才谈得上按舞台准备素材
     * （index.html:315-322 的 fetch 本身与尺寸无关，但保持宿主投递顺序稳定，便于审查）。
     */
    private fun flushAssetLoadIfReady(): Boolean {
        if (!railReady) return false
        val pending = pendingAssetLoad ?: return false
        return callRail(
            ReplicaRailMethod.LOAD_ASSETS,
            listOf(jsStringLiteral(pending.first), jsStringLiteral(pending.second)),
            forwardResult = true,
        )
    }

    /**
     * 受信文档判定：当前 url 必须是 INDEX_URL（或同 origin 下的路径）。
     *
     * 页面自身被 shouldOverrideUrlLoading 锁死，所以正常情况下永远成立；
     * 这道检查防的是"拦截器将来被改松"或"某版本 WebView 让 data: 文档也拿到桥"之类的情形。
     */
    private fun isTrustedDocument(): Boolean {
        val current = webView?.url ?: return false
        if (current == INDEX_URL) return true
        return current.startsWith(ORIGIN + "/")
    }

    // ── rail 调用（宿主 → 页面） ────────────────────────────────────────────────────────────────

    /**
     * rail 调用的唯一实现。
     *
     * 脚本形状：(function(){var r=window.__rhineRail;if(!r||typeof r.METHOD!=='function'){return null;}
     * return r.METHOD(ARGS);})()
     *
     * 三条硬性质：
     *   1. METHOD 来自 ReplicaRailMethod（编译期常量），永远不是用户串；
     *   2. 参数由调用方**已经转义**（jsStringLiteral / formatNumber / jsonParseExpression），
     *      这里只做逗号拼接，不再做任何字符串插入；
     *   3. 页面若还没挂上 rail，脚本返回 null 而不是抛异常——宿主不会因此崩，也不会静默改状态。
     */
    private fun callRail(method: ReplicaRailMethod, args: List<String>, forwardResult: Boolean): Boolean {
        checkMainThread()
        if (!railReady) {
            counters.droppedNotReady.incrementAndGet()
            return false
        }
        val view = webView
        if (view == null) {
            counters.droppedNoView.incrementAndGet()
            return false
        }
        val script = buildRailScript(method, args)
        counters.railCalls.incrementAndGet()
        if (!forwardResult) {
            view.evaluateJavascript(script, null)
            return true
        }
        view.evaluateJavascript(script, ValueCallback<String> { value ->
            counters.railResults.incrementAndGet()
            sink.onHostEvent(
                "{\"type\":\"railResult\",\"method\":" + jsStringLiteral(method.jsName) +
                    ",\"value\":" + normalizeRailResult(value) + "}",
            )
        })
        return true
    }

    /** publish / attachAsset 这类"参数就是一个 JSON 对象"的调用。 */
    private fun callObjectRail(method: ReplicaRailMethod, payloadJson: String): Boolean {
        return callRail(method, listOf(jsonParseExpression(payloadJson)), forwardResult = false)
    }

    private fun buildRailScript(method: ReplicaRailMethod, args: List<String>): String {
        val builder = StringBuilder(96 + args.size * 32)
        builder.append("(function(){var r=window.__rhineRail;")
        builder.append("if(!r||typeof r.").append(method.jsName).append("!=='function'){return null;}")
        builder.append("return r.").append(method.jsName).append('(')
        for (position in args.indices) {
            if (position > 0) builder.append(',')
            builder.append(args[position])
        }
        builder.append(");})()")
        return builder.toString()
    }

    /** evaluateJavascript 的结果是"已是 JSON 的文本"；只把 null 与空串归一成 null，其余原样。 */
    private fun normalizeRailResult(value: String?): String {
        if (value == null) return "null"
        val trimmed = value.trim()
        if (trimmed.isEmpty() || trimmed == "null") return "null"
        return trimmed
    }

    // ── 转义与 JSON 工具 ──────────────────────────────────────────────────────────────────────

    /**
     * 把任意字符串变成**一个 JS 字符串字面量**（含两侧引号）。这是"不许裸拼接"的唯一出口：
     * 宿主所有把外部数据塞进 evaluateJavascript 的地方都必须经过它。
     *
     * 覆盖：双引号 / 反斜杠、\n \r \t \b \f、U+2028 / U+2029（JS 里算换行，会截断语句）、
     * 其余 C0 控制字符（按 \u00XX 输出）、孤立代理项（换成 U+FFFD，避免产生非法 UTF-16 字面量）。
     * 合法代理对原样保留（转义反而会把它拆坏）。
     */
    private fun jsStringLiteral(value: String): String {
        val out = StringBuilder(value.length + 16)
        out.append('"')
        var index = 0
        while (index < value.length) {
            val ch = value[index]
            val code = ch.code
            when {
                ch == '"' -> out.append("\\\"")
                ch == '\\' -> out.append("\\\\")
                code == 0x08 -> out.append("\\b")
                code == 0x09 -> out.append("\\t")
                code == 0x0a -> out.append("\\n")
                code == 0x0c -> out.append("\\f")
                code == 0x0d -> out.append("\\r")
                code == 0x2028 -> out.append("\\u2028")
                code == 0x2029 -> out.append("\\u2029")
                code < 0x20 -> out.append("\\u").append(hex4(code))
                code == 0x7f -> out.append("\\u007f")
                Character.isHighSurrogate(ch) -> {
                    if (index + 1 < value.length && Character.isLowSurrogate(value[index + 1])) {
                        out.append(ch).append(value[index + 1])
                        index += 1
                    } else {
                        out.append("\\ufffd")
                    }
                }
                Character.isLowSurrogate(ch) -> out.append("\\ufffd")
                else -> out.append(ch)
            }
            index += 1
        }
        out.append('"')
        return out.toString()
    }

    /**
     * 把一段**已经验证过**是合法 JSON 的文本变成 JS 表达式 JSON.parse("…")。
     *
     * 为什么不直接内联 JSON 文本：JSON 与 JS 字面量不是同一套语法（例如含 U+2028 的 JSON
     * 内联后会截断语句）。JSON.parse 加字面量参数只有一条路径，且能保证页面拿到的对象
     * 与调用方给的文本同值（1728 不会被写成 1728.0）。
     */
    private fun jsonParseExpression(json: String): String {
        return "JSON.parse(" + jsStringLiteral(json) + ")"
    }

    private fun hex4(code: Int): String {
        val digits = "0123456789abcdef"
        val builder = StringBuilder(4)
        builder.append(digits[(code shr 12) and 0xF])
        builder.append(digits[(code shr 8) and 0xF])
        builder.append(digits[(code shr 4) and 0xF])
        builder.append(digits[code and 0xF])
        return builder.toString()
    }

    /** 数字进 JS 前一律走这里：整数值不带小数点，其余用 Kotlin 自己的定点/科学计数（无本地化逗号）。 */
    private fun formatNumber(value: Double): String {
        if (value == Math.floor(value) && !value.isInfinite() && Math.abs(value) < 1.0E15) {
            return value.toLong().toString()
        }
        return value.toString()
    }

    // ── 校验器 ────────────────────────────────────────────────────────────────────────────────

    private fun isJsonArray(text: String): Boolean {
        if (text.isEmpty()) return false
        return try {
            JSONArray(text)
            true
        } catch (e: JSONException) {
            false
        }
    }

    private fun isJsonObject(text: String): Boolean {
        if (text.isEmpty()) return false
        return try {
            JSONObject(text)
            true
        } catch (e: JSONException) {
            false
        }
    }

    private fun isValidJson(text: String): Boolean {
        if (text.isEmpty()) return false
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return false
        val first = trimmed[0]
        if (first == '[') return isJsonArray(trimmed)
        if (first == '{') return isJsonObject(trimmed)
        // 标量（字符串 / 数字 / true / false / null）：用 JSONArray 包一层做语法校验，避免自己写解析器。
        return try {
            JSONArray("[" + trimmed + "]")
            true
        } catch (e: JSONException) {
            false
        }
    }

    /**
     * publish 的入参校验，**镜像** index.html:215-254 的页面侧规则（页面才是最终裁判）：
     * 必须是对象、generation 是有限数、commands 与 hits 是数组、frame 是对象。
     * 宿主先挡一遍是为了不在页面里制造异常路径，不是替代页面校验。
     */
    private fun validatePublishPayload(payloadJson: String): Boolean {
        if (payloadJson.isEmpty()) {
            sink.onHostError("bad-publish", "payload 为空")
            return false
        }
        if (!isJsonObject(payloadJson)) {
            sink.onHostError("bad-publish", "payload 不是 JSON 对象")
            return false
        }
        return try {
            val payload = JSONObject(payloadJson)
            val generation = payload.opt("generation")
            if (generation !is Number) {
                sink.onHostError("bad-generation", "generation 缺失或不是数字")
                return false
            }
            if (payload.optJSONArray("commands") == null) {
                sink.onHostError("bad-commands", "commands 不是数组")
                return false
            }
            if (payload.optJSONArray("hits") == null) {
                sink.onHostError("bad-hits", "hits 不是数组")
                return false
            }
            if (payload.optJSONObject("frame") == null) {
                sink.onHostError("bad-frame", "frame 不是对象")
                return false
            }
            true
        } catch (e: JSONException) {
            sink.onHostError("bad-publish", "payload 解析失败")
            false
        }
    }

    private fun payloadJsonLengthHint(commands: String, hits: String, frame: String): Int {
        return commands.length + hits.length + frame.length + 64
    }

    private fun isUsableSize(value: Double): Boolean {
        return !value.isNaN() && !value.isInfinite() && value > 0.0 && value <= MAX_LOGICAL_PX
    }

    private fun isUsableKey(key: String): Boolean {
        return key.isNotEmpty() && key.length <= MAX_KEY_CHARS
    }

    // ── 线程与版本 ────────────────────────────────────────────────────────────────────────────

    private fun checkMainThread() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw IllegalStateException("WebViewReplicaHost 必须在主线程调用，当前线程=" + Thread.currentThread().name)
        }
    }

    /**
     * 只描述版本，**不做行为分支**：
     * 本卡没有设备验证（硬禁令），所以任何"某版本 WebView 需要特判"的假设都不写进代码。
     * API 26+ 可以问系统当前 WebView 包；更低版本没有这个 API，从 UA 里截 Chrome/ 之后的版本号。
     */
    private fun describeWebViewVersion(view: WebView): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val info = WebView.getCurrentWebViewPackage()
                if (info != null) return info.packageName + " " + info.versionName
            } catch (e: RuntimeException) {
                // 某些 ROM 上这个调用会抛；退回到 UA 探测。
            }
        }
        val userAgent = view.settings.userAgentString ?: ""
        val marker = userAgent.indexOf("Chrome/")
        if (marker < 0) return "unknown"
        var end = marker + 7
        while (end < userAgent.length) {
            val ch = userAgent[end]
            if (ch == ' ' || ch == ';' || ch == ')') break
            end += 1
        }
        return "chrome/" + userAgent.substring(marker + 7, end)
    }

    // ── 诊断 ──────────────────────────────────────────────────────────────────────────────────

    /**
     * 给测试/日志看的一份快照。**不改任何状态**，也不读磁盘。
     *
     * 故意把白名单表、CSP、MIME 表都吐出来：审查者要能只看这份 JSON 就核对
     * "origin / path / MIME / CSP 四项严格"是否真的成立，而不必相信我写的注释。
     */
    fun diagnosticsJson(): String {
        val diagnostics = JSONObject()
        diagnostics.put("origin", ORIGIN)
        diagnostics.put("indexUrl", INDEX_URL)
        diagnostics.put("csp", CSP_DOCUMENT)
        diagnostics.put("blockNetworkLoads", blockNetworkLoads)
        diagnostics.put("railReady", railReady)
        diagnostics.put("sizingDelivered", sizingDelivered)
        diagnostics.put("destroyed", destroyed)
        diagnostics.put("rendererGone", rendererGone)
        diagnostics.put("singletonConflicts", singletonConflicts)
        diagnostics.put("hasPendingResize", pendingResize != null)
        diagnostics.put("hasHello", helloJson != null)

        val paths = JSONArray()
        for (entry in VIRTUAL_PATHS.entries.sortedBy { it.key }) {
            val item = JSONObject()
            item.put("virtual", entry.key)
            item.put("repo", entry.value)
            item.put("contentType", contentTypeOf(entry.value) ?: "missing")
            paths.put(item)
        }
        diagnostics.put("paths", paths)

        val countersJson = JSONObject()
        countersJson.put("intercepts", counters.intercepts.get())
        countersJson.put("served", counters.served.get())
        countersJson.put("deniedOrigin", counters.deniedOrigin.get())
        countersJson.put("deniedPath", counters.deniedPath.get())
        countersJson.put("deniedDocumentEntry", counters.deniedDocumentEntry.get())
        countersJson.put("deniedMethod", counters.deniedMethod.get())
        countersJson.put("missingAsset", counters.missingAsset.get())
        countersJson.put("pageMessages", counters.pageMessages.get())
        countersJson.put("droppedNotReady", counters.droppedNotReady.get())
        countersJson.put("droppedNoView", counters.droppedNoView.get())
        countersJson.put("droppedOversize", counters.droppedOversize.get())
        countersJson.put("droppedUntrusted", counters.droppedUntrusted.get())
        countersJson.put("droppedQueueFull", counters.droppedQueueFull.get())
        countersJson.put("railCalls", counters.railCalls.get())
        countersJson.put("railResults", counters.railResults.get())
        diagnostics.put("counters", countersJson)

        val consoleJson = JSONObject()
        consoleJson.put("level", lastConsoleLevel)
        consoleJson.put("message", lastConsoleMessage)
        diagnostics.put("lastConsole", consoleJson)

        val view = webView
        diagnostics.put("webViewVersion", if (view == null) "none" else describeWebViewVersion(view))
        diagnostics.put("currentUrl", view?.url ?: "none")
        return diagnostics.toString()
    }
}

/** 桥对象对页面暴露的两个名字（index.html:77 两个都试）。 */
private const val BRIDGE_NAME_PRIMARY = "__rhineHost"
private const val BRIDGE_NAME_ALIAS = "RhineHostBridge"
