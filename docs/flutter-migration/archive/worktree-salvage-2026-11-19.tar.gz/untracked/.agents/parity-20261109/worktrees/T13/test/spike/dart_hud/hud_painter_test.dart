// T13-S01 source-level parity tests for the Dart mirror of the 17 HUD
// commands in Qt/src/Glyphs.cpp:637-825.
//
// Authored before the implementation, NEVER EXECUTED in this stage (plan run
// gate closed). Assertions encode Qt behaviour rather than Flutter idioms:
//   * flat array commands, a[0] is the op name, no sorting and no de-duplication
//   * alpha multiplies the current painter opacity (Qt:658-659)
//   * clip intersects (Qt:676-678)
//   * dash values are divided by pen width then multiplied back by Qt, so the
//     stage-space lengths are the raw values (Qt:748-757)
//   * arc angles are negated twice on the way to Flutter's clockwise sweep
//     (Qt:770-771)
//   * right-mask builds 17 smoothstep stops from start to start+span (Qt:792-805)
//   * radial gradient center (979.2, 518.4) radius 1100 (Qt:807-811)
//   * image keys resolve through a supplied port; a null image is skipped
//     (Qt:813-824) and NativeHud::image() already drops empty keys
import 'dart:ui' as ui;

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/spike/dart_hud/glyph_loader.dart';
import 'package:rhine_music_database/spike/dart_hud/hud_painter.dart';

GlyphAtlas _atlas() {
  Map<String, dynamic> weight() => <String, dynamic>{
        'units': 1000,
        'ascent': 1044,
        'descent': -282,
        'glyphs': <String, dynamic>{
          'A': <String, dynamic>{'advance': 0.5, 'path': 'M0 0 L500 0 L500 700 Z'},
        },
      };
  return GlyphAtlas.fromMaps(
    glyphs: <String, dynamic>{
      'light': weight(),
      'regular': weight(),
      'demibold': weight(),
      'bold': weight(),
    },
    lettering: <String, dynamic>{
      't13-test': <String, dynamic>{
        'text': 'A',
        'weight': 'Normal',
        'units': 1000,
        'letters': <dynamic>[
          <String, dynamic>{'width': 0.5, 'path': 'M0 0 L500 0 L500 700 Z'},
        ],
      },
    },
  );
}

HudPainter _painter({List<String>? trace, HudImageResolver? resolver}) =>
    HudPainter(atlas: _atlas(), trace: trace, imageResolver: resolver);

void main() {
  group('command stream', () {
    test('trace keeps source order and duplicates (no sort, no de-dup)', () {
      final List<String> trace = <String>[];
      final HudPainter painter = _painter(trace: trace);
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      final HudPaintStats stats = painter.paintAll(canvas, <Object?>[
        <Object?>['fill', <dynamic>[0.1, 0.2, 0.3, 1], 0, 0, 10, 10],
        <Object?>['fill', <dynamic>[0.1, 0.2, 0.3, 1], 0, 0, 10, 10],
        <Object?>['ellipse', <dynamic>[0.1, 0.2, 0.3, 1], 0, 0, 4, 4],
      ]);
      expect(trace, <String>['fill@1.000', 'fill@1.000', 'ellipse@1.000']);
      expect(stats.commands, 3);
      expect(stats.unknownOps, 0);
      recorder.endRecording().dispose();
    });

    test('alpha multiplies and save/restore restores the opacity', () {
      final List<String> trace = <String>[];
      final HudPainter painter = _painter(trace: trace);
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      painter.paintAll(canvas, <Object?>[
        <Object?>['alpha', 0.5],
        <Object?>['save'],
        <Object?>['alpha', 0.5],
        <Object?>['fill', <dynamic>[1, 0, 0, 1], 0, 0, 1, 1],
        <Object?>['restore'],
        <Object?>['fill', <dynamic>[1, 0, 0, 1], 0, 0, 1, 1],
      ]);
      expect(trace, <String>['alpha@1.000', 'save@0.500', 'alpha@0.500',
        'fill@0.250', 'restore@0.250', 'fill@0.500']);
      recorder.endRecording().dispose();
    });

    test('unknown ops are ignored without stopping the frame', () {
      final List<String> trace = <String>[];
      final HudPainter painter = _painter(trace: trace);
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      final HudPaintStats stats = painter.paintAll(canvas, <Object?>[
        <Object?>['fill', <dynamic>[1, 1, 1, 1], 0, 0, 1, 1],
        <Object?>['future-op', 1, 2, 3],
        <Object?>['ellipse', <dynamic>[1, 1, 1, 1], 0, 0, 1, 1],
      ]);
      expect(stats.unknownOps, 1);
      expect(trace.last, 'ellipse@1.000');
      recorder.endRecording().dispose();
    });

    test('all seventeen contract ops paint without throwing', () {
      final List<String> trace = <String>[];
      final HudPainter painter = _painter(trace: trace);
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      final HudPaintStats stats = painter.paintAll(canvas, <Object?>[
        <Object?>['save'],
        <Object?>['alpha', 0.5],
        <Object?>['translate', 10, 20],
        <Object?>['scale', 2, 2],
        <Object?>['rotate', 0.5],
        <Object?>['clip', 0, 0, 100, 100],
        <Object?>['fill', <dynamic>[0.9, 0.9, 0.9, 1], 0, 0, 10, 10],
        <Object?>['ellipse', <dynamic>[0.1, 0.1, 0.1, 1], 5, 5, 4, 4],
        <Object?>['text', 'A', 10, 30, 20, 'regular', 1,
          <dynamic>[0.08, 0.085, 0.075, 1, 'calibratedRGB']],
        <Object?>['art', 't13-test', 10, 20, 20, -1, 1,
          <dynamic>[0.9, 0.9, 0.9, 1]],
        <Object?>['fill-path', 'M0 0 L10 0 L10 10 Z', <dynamic>[1, 0, 0, 1]],
        <Object?>['path', 'M0 0 L10 10', 2, <dynamic>[0, 0, 0, 1], <dynamic>[4, 2], 3],
        <Object?>['arc', 50, 50, 10, 0.5, 1.5, 3, <dynamic>[0, 0, 0, 1]],
        <Object?>['right-mask', <dynamic>[0.9, 0.89, 0.86, 0.4], 100, 300, 400, 984],
        <Object?>['gradient', false],
        <Object?>['image', 'cover', 0, 0, 54, 54],
        <Object?>['restore'],
      ]);
      expect(stats.commands, 17);
      expect(stats.unknownOps, 0);
      expect(stats.missingImages, 1);
      recorder.endRecording().dispose();
    });
  });

  group('color resolution', () {
    test('delegates to the Qt calibrated rule', () {
      expect(HudPainter.resolveColor(<dynamic>[0.2, 0.3, 0.4, 0.5, 'srgb']).r,
          closeTo(0.2, 1e-6));
      final ui.Color calibrated =
          HudPainter.resolveColor(<dynamic>[0.92, 0.92, 0.92, 1, 'calibratedWhite']);
      expect(calibrated.r, closeTo(0.9361, 5e-3));
    });
  });

  group('stroke, arc and mask geometry', () {
    test('dash lengths are stage space regardless of pen width', () {
      expect(HudPainter.dashPattern(<dynamic>[4, 2], penWidth: 2),
          <double>[4, 2]);
      expect(HudPainter.dashPattern(<dynamic>[4, 2], penWidth: 0.5),
          <double>[4, 2]);
      expect(HudPainter.dashOffset(3, penWidth: 0.5), closeTo(3, 1e-9));
      expect(HudPainter.dashOffset(3, penWidth: 0), closeTo(3, 1e-9));
    });

    test('arc rect is centered on the pen origin', () {
      expect(HudPainter.arcRect(10, 20, 5), ui.Rect.fromLTRB(5, 15, 15, 25));
    });

    test('arc angles keep the double negation applied by Qt', () {
      expect(HudPainter.arcStartRadians(0.75), closeTo(0.75, 1e-9));
      expect(HudPainter.arcSweepRadians(-1.25), closeTo(-1.25, 1e-9));
    });

    test('right mask rect spans start..right at full height', () {
      expect(HudPainter.rightMaskRect(100, 400, 984),
          ui.Rect.fromLTRB(100, 0, 400, 984));
    });

    test('right mask emits 17 smoothstep stops with eased alpha', () {
      final List<double> stops = HudPainter.rightMaskStops();
      final List<ui.Color> colors =
          HudPainter.rightMaskColors(const ui.Color.fromARGB(102, 230, 227, 219));
      expect(stops.length, 17);
      expect(colors.length, 17);
      expect(stops.first, closeTo(0, 1e-9));
      expect(stops.last, closeTo(1, 1e-9));
      expect(colors.first.a, closeTo(0, 1e-6));
      expect(colors[8].a, closeTo(0.4 * 0.5, 1e-6));
      expect(colors.last.a, closeTo(0.4, 1e-6));
      for (int i = 1; i < colors.length; i += 1) {
        expect(colors[i].a >= colors[i - 1].a, isTrue);
      }
    });

    test('radial gradient constants match Qt', () {
      expect(HudPainter.radialCenter, const ui.Offset(979.2, 518.4));
      expect(HudPainter.radialRadius, 1100);
      expect(HudPainter.radialStops, <double>[0, 0.76, 1]);
      expect(HudPainter.radialColors(false),
          <ui.Color>[const ui.Color(0xFFE7E7E1), const ui.Color(0xFFE3E1DC),
            const ui.Color(0xFFE4DFDB)]);
      expect(HudPainter.radialColors(true),
          <ui.Color>[const ui.Color(0xFF202A2F), const ui.Color(0xFF172125),
            const ui.Color(0xFF11181B)]);
    });
  });

  group('image port', () {
    test('null image is skipped and counted', () {
      int calls = 0;
      final HudImageResolver resolver = (String key) {
        calls += 1;
        return null;
      };
      final HudPainter painter = _painter(resolver: resolver);
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      final HudPaintStats stats =
          painter.paintAll(canvas, <Object?>[<Object?>['image', 'rg-cover', 0, 0, 54, 54]]);
      expect(calls, 1);
      expect(stats.missingImages, 1);
      recorder.endRecording().dispose();
    });
  });

  group('hits', () {
    Map<String, dynamic> hit({
      required double x,
      required double y,
      required String action,
      bool fixed = false,
    }) =>
        <String, dynamic>{
          'x': x,
          'y': y,
          'width': 40.0,
          'height': 40.0,
          'action': action,
          'label': action,
          if (fixed) 'fixed': true,
        };

    test('six mandatory fields are enforced', () {
      expect(
          () => HudHit.fromJson(<String, dynamic>{
                'x': 1.0,
                'y': 2.0,
                'width': 3.0,
                'height': 4.0,
                'action': 'search',
              }),
          throwsFormatException);
      final HudHit parsed = HudHit.fromJson(hit(x: 1, y: 2, action: 'search'));
      expect(parsed.rect, ui.Rect.fromLTWH(1, 2, 40, 40));
      expect(parsed.fixed, isFalse);
      expect(HudHit.fromJson(hit(x: 0, y: 0, action: 'player:toggle', fixed: true)).fixed,
          isTrue);
    });

    test('hit testing is topmost first', () {
      final List<HudHit> hits = HudHit.listFromJson(<dynamic>[
        hit(x: 0, y: 0, action: 'under'),
        hit(x: 0, y: 0, action: 'over'),
      ]);
      expect(HudHit.hitTest(hits, const ui.Offset(10, 10))!.action, 'over');
      expect(HudHit.hitTest(hits, const ui.Offset(100, 100)), isNull);
    });

    test('modal offset pushes only non fixed hits', () {
      final List<HudHit> hits = HudHit.listFromJson(<dynamic>[
        hit(x: 0, y: 900, action: 'player:toggle', fixed: true),
        hit(x: 0, y: 100, action: 'row:1'),
      ]);
      expect(HudHit.hitTest(hits, const ui.Offset(10, 110), modalOffset: 100)!.action,
          'row:1');
      expect(HudHit.hitTest(hits, const ui.Offset(10, 110)), isNull);
      expect(HudHit.hitTest(hits, const ui.Offset(10, 910), modalOffset: 100)!.action,
          'player:toggle');
    });
  });
}
