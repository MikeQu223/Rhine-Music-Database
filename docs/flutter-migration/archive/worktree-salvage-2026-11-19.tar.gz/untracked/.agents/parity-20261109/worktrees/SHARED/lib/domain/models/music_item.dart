/// Qt 侧 Qt/src/MusicData.h 与 Qt/src/MusicData.cpp 的 Dart 1:1 移植。
///
/// 结构对应：
/// * [MusicItem] —— Qt MusicData::item() 产出的 QJsonObject 形状（16 个键，
///   见 Qt/src/MusicData.cpp:22-39），外加 parse() 填充的字段（:41-80）。
/// * [ArtistRef] —— parse() 里 artists 数组的单个条目（:62）。
/// * [MusicData] —— Qt 命名空间 MusicData 的纯函数集合（:10-184）。
///
/// 解耦约束：
/// * 本文件零 import，不依赖 provider_id.dart，provider 一律用 [String]，
///   因为 Qt 侧就是裸字符串（QString provider = "netease"）。
/// * 不引入任何第三方依赖。
///
/// 字符串取值语义（全文件统一）：Qt 的 QJsonValue::toString() / toObject()
/// 对类型不符的值返回空串 / 空对象，从不做隐式类型转换；本文件的 _jsonString 与
/// _asMap 逐字复刻这一点。
///
/// ## 数值取值语义（已核实到 Qt 6.12.0 源码，不是文档摘要）
///
/// * identifier()（Qt/src/MusicData.cpp:10-18）用 QJsonValue::toInteger()：
///   String 分支原样返回（:11-13，不 trim、不做数字规范化）；isDouble() 分支返回
///   QString::number(value.toInteger())（:14-16）。Qt 6 的 isDouble() 对
///   QCborValue::Integer 与 QCborValue::Double 都为真
///   （serialization/qjsonvalue.cpp:31-52 的 convertFromCborType 把 Integer 映射成
///   QJsonValue::Double）。
/// * toInteger()（qjsonvalue.cpp:714-729）：Integer 分支原样返回 qint64（:717-718）；
///   Double 分支必须 convertDoubleTo<qint64> 成功（:719-723），否则返回默认值 0
///   （:728）。convertDoubleTo 的整型重载（global/qnumeric_p.h:164-289）先做范围门
///   （v >= 2^63 或 v < -2^63 直接 false，:277-284；x86-64 内联版同判，:214-221），
///   再用 return *value == v;（:286）判整性——所以 3.7 得 false、1e300 得 false，
///   两者都回落到默认值 0，最终字符串是 "0"，不是向零截断。
/// * 其它类型（null / bool / List / Map）连 isDouble() 都不成立，直接走
///   return {};（MusicData.cpp:17），得到空串。
/// * QJsonValue::toDouble()（qjsonvalue.cpp:736-738）只接受 Double/Integer
///   （Integer 按 double(qint64) 转换，可能损失 >2^53 的精度），其它类型返回默认值
///   ——数字字符串不参与任何转换。
/// * publishTime 的门槛是 toDouble() > 0，取值是 toInteger()（MusicData.cpp:75-77），
///   两者语义不同：3.7 过门但取值得 0，于是日期是 epoch 当天。
///
/// 凡是纯 Dart 无法完全复刻的地方都以 PARITY_RISK 标注，不做静默近似。
library;

/// Qt 侧 QJsonObject 的 Dart 等价物：字符串键 + 动态值。
typedef JsonMap = Map<String, dynamic>;

/// parse() 输出的人名条目（Qt/src/MusicData.cpp:62）。
class ArtistRef {
  const ArtistRef({required this.id, required this.name});

  /// identifier(artist["id"])（:10-18, :62）：String 原样；Integer/整数值 Double
  /// 转十进制文本；非整数或超出 qint64 的 Double 得 "0"；其它类型得空串。
  final String id;

  /// artist["name"]，入选项已由调用侧保证是 String（:60）。
  final String name;

  /// 与 Qt 侧条目同形：{"id": ..., "name": ...}（:62）。
  JsonMap toJson() => <String, dynamic>{'id': id, 'name': name};

  @override
  String toString() => 'ArtistRef($id, $name)';
}

/// 单条曲目 / 专辑 / 歌单 / 歌手档案（Qt 侧是 16 键的 QJsonObject）。
///
/// 键名含大写 ID（creatorID / albumID），与 Qt/src/MusicData.cpp:28-29 一致，
/// 因此 Dart 字段名是 [creatorId] / [albumId]，而 [toJson] 输出 creatorID / albumID。
class MusicItem {
  const MusicItem({
    required this.kind,
    required this.id,
    this.title = '',
    this.artist = '',
    this.creatorId = '',
    this.albumId = '',
    this.album = '',
    this.cover = '',
    this.description = '',
    this.wiki = '',
    this.date = '',
    this.provider = 'netease',
    this.artists = const <ArtistRef>[],
    this.duration = 0,
    this.trackCount = 0,
  });

  /// kind：song / album / playlist / artist（Qt 调用点取值集合，见
  /// MusicDiscover.cpp:63-87、MusicDirectory.cpp:251、MusicLibrary.cpp:894、
  /// LocalCollections.cpp:140）。
  final String kind;

  /// id：parse() 保证匹配 ^[0-9]{1,20}$（:43-44）。
  final String id;
  final String title;

  /// 非 playlist：人名以 " / " 拼接；playlist：creator.nickname 或 暂无创建者（:65-66）。
  final String artist;
  final String creatorId;
  final String albumId;
  final String album;
  final String cover;
  final String description;

  /// parse() 不写 wiki，恒为空串（Qt item() 有该键、parse 不赋值，:33 vs :67-78）。
  final String wiki;

  /// 本地时区 yyyy-MM-dd，或空串（:75-78）。publishTime 过 toDouble()>0 门但
  /// toInteger() 得 0 时（3.7、1e300 等），日期是 epoch 当天。
  final String date;
  final String provider;

  /// 已过滤的人名条目：仅保留 name 为 String 的元素（:58-64）。
  final List<ArtistRef> artists;

  /// duration 毫秒；raw["dt"] 优先于 raw["duration"]（:72）。
  ///
  /// 取值语义 = QJsonValue::toDouble(默认值)（qjsonvalue.cpp:736-738）：JSON 整数经
  /// double(qint64) 变 double（>2^53 丢低位，与 Qt 一致），小数保持原值不截断，
  /// 数字字符串不转换而回落默认值。parse() 产物恒为 double；直接构造时 [num] 入参
  /// 原样保存（Dart 侧便利，Qt 无对应构造）。
  final num duration;

  /// trackCount；raw["trackCount"] 优先于 raw["size"]（:73），语义同 [duration]。
  final num trackCount;

  /// 逐字等于 provider + ":" + kind + ":" + id（Qt/src/MusicData.cpp:38）。
  String get key => provider + ':' + kind + ':' + id;

  /// 键集合、键名、值类型与 Qt item() 一致（:22-39），可被 [MusicData.item] 的产物
  /// 深比较。
  ///
  /// 注意：Qt 的 QJsonObject 内部按 key 字典序存放，序列化顺序是字典序
  /// （album, albumID, artist, artists, cover, creatorID, date, description,
  /// duration, id, key, kind, provider, title, trackCount, wiki）；Dart Map 保留下面
  /// 的字面量插入序。两者键与值相同，只有遍历顺序不同。
  JsonMap toJson() => <String, dynamic>{
        'kind': kind,
        'id': id,
        'title': title,
        'artist': artist,
        'artists': <JsonMap>[for (final ArtistRef entry in artists) entry.toJson()],
        'creatorID': creatorId,
        'albumID': albumId,
        'album': album,
        'cover': cover,
        'description': description,
        'wiki': wiki,
        'date': date,
        'duration': duration,
        'trackCount': trackCount,
        'provider': provider,
        'key': key,
      };

  /// Qt MusicData::item(kind, id) 的占位答复（:22-39）：
  /// title=正在读取…、artist 空、provider=netease，artists 为空数组。
  factory MusicItem.placeholder(
    String kind,
    String id, {
    String title = '正在读取…',
    String artist = '',
    String provider = 'netease',
  }) =>
      MusicItem(kind: kind, id: id, title: title, artist: artist, provider: provider);

  /// Qt MusicData::parse 的模型封装；解析失败返回 null（Qt 返回空对象 {}）。
  static MusicItem? parse(JsonMap raw, String kind) => MusicData.parse(raw, kind);

  @override
  String toString() => 'MusicItem($key, $title / $artist)';
}

/// Qt 命名空间 MusicData 的纯函数集合，行号对应 Qt/src/MusicData.cpp。
///
/// 全部函数无副作用：不修改入参列表，返回值是新集合（Qt 侧 slice / unique /
/// ordered / sortOrder 同样是拷贝语义，:82-123、:161-184）。
class MusicData {
  const MusicData._();

  /// Qt identifier()（:10-18），逐条对齐 Qt 6.12.0：
  ///
  /// * String -> 原样返回（:11-13，不 trim、不规范化）；
  /// * Integer / Double -> QString::number(toInteger())（:14-16）；
  /// * 其它（null / bool / List / Map）-> 空串（:17）。
  ///
  /// 数值分支按 Qt 真实语义处理，而不是向零截断：3.0 -> "3"、3.7 -> "0"、
  /// 1e300 -> "0"、-5 -> "-5"（qjsonvalue.cpp:714-729 + qnumeric_p.h:277-286）。
  static String identifier(Object? value) {
    if (value is String) {
      return value;
    }
    if (value is num) {
      return _integerText(value);
    }
    return '';
  }

  /// Qt item()（:22-39）：16 个键，键集合与键名同 Qt 字面量。
  ///
  /// 注意键名是 creatorID / albumID（大写 ID，:28-29）。Qt 的 QJsonObject 在内部按
  /// key 字典序存放，因此 Qt 序列化后的顺序与这里的插入序不同（键与值相同）。
  /// artists 此时是空数组，由 [parse] 覆盖（:67）。
  static JsonMap item(
    String kind,
    String id, {
    String title = '正在读取…',
    String artist = '',
    String provider = 'netease',
  }) =>
      <String, dynamic>{
        'kind': kind,
        'id': id,
        'title': title,
        'artist': artist,
        'artists': <Object?>[],
        'creatorID': '',
        'albumID': '',
        'album': '',
        'cover': '',
        'description': '',
        'wiki': '',
        'date': '',
        'duration': 0,
        'trackCount': 0,
        'provider': provider,
        'key': provider + ':' + kind + ':' + id,
      };

  /// Qt parse()（:41-80）。返回 null 等价于 Qt 返回空对象 {}。
  ///
  /// 前置校验（:42-46）：id = identifier(raw["id"]) 必须匹配 ^[0-9]{1,20}$，
  /// 且 raw["name"] 是 String，否则 null。
  static MusicItem? parse(JsonMap raw, String kind) {
    // :42-46 前置校验。
    final String id = identifier(raw['id']);
    if (!_identifierPattern.hasMatch(id)) {
      return null;
    }
    final Object? name = raw['name'];
    if (name is! String) {
      return null;
    }

    // :47-53 artists 来源：先取 raw["ar"]（非数组 -> 空数组）；只有 ar 为 null
    // **或键缺失** 才回退 raw["artists"]；若 artists 同样为 null/缺失且
    // raw["artist"] 是 Map，才用单元素数组。[] 或类型不符的值都不算 null，故不回退。
    final List<Object?> rawArtists;
    final Object? ar = raw['ar'];
    if (ar == null) {
      final Object? fallback = raw['artists'];
      if (fallback == null) {
        final Object? single = raw['artist'];
        rawArtists = single is Map ? <Object?>[single] : const <Object?>[];
      } else {
        rawArtists = fallback is List ? fallback : const <Object?>[];
      }
    } else {
      rawArtists = ar is List ? ar : const <Object?>[];
    }

    // :54 creator；:55 album（al 优先，其次 album，都不是 Map 则为空 Map）。
    final Map<Object?, Object?> creator = _asMap(raw['creator']);
    final Map<Object?, Object?> album =
        raw['al'] is Map ? _asMap(raw['al']) : _asMap(raw['album']);

    // :56-64 逐元素过滤：只有 Map 且 ["name"] 是 String 才入选；id 走 identifier。
    final List<String> names = <String>[];
    final List<ArtistRef> artists = <ArtistRef>[];
    for (final Object? element in rawArtists) {
      if (element is! Map) {
        continue;
      }
      final Object? elementName = element['name'];
      if (elementName is! String) {
        continue;
      }
      names.add(elementName);
      artists.add(ArtistRef(id: identifier(element['id']), name: elementName));
    }

    // :65-66 title，以及 artist：playlist 用 creator.nickname（空串保留空串，
    // 只看类型、不做真值判断），类型不符时才用默认 暂无创建者；其它 kind 是 " / " 拼接。
    final Object? nickname = creator['nickname'];
    final String artistText = kind == 'playlist'
        ? (nickname is String ? nickname : '暂无创建者')
        : names.join(' / ');

    // :68-71 creatorID / albumID / album 名称。
    final Object? albumName = album['name'];

    // :71 cover 三层默认：类型不符即跳过该层，绝不转换。
    final Object? picUrl = raw['picUrl'];
    final Object? coverImgUrl = raw['coverImgUrl'];
    final Object? albumPicUrl = album['picUrl'];
    final String cover = picUrl is String
        ? picUrl
        : (coverImgUrl is String ? coverImgUrl : (albumPicUrl is String ? albumPicUrl : ''));

    // :72-73 duration / trackCount：QJsonValue::toDouble(默认值) 的嵌套默认链。
    // 数字字符串不转换、小数不截断；JSON 整数按 double(qint64) 转换（>2^53 丢低位，
    // 与 Qt 一致），所以结果恒为 double（qjsonvalue.cpp:736-738）。
    final double durationValue = _jsonDouble(raw['dt'], _jsonDouble(raw['duration'], 0));
    // :73 trackCount：trackCount 优先，其次 size，同 toDouble 语义。
    final double trackCountValue = _jsonDouble(raw['trackCount'], _jsonDouble(raw['size'], 0));

    // :74 description：description -> briefDesc -> ""。
    final Object? description = raw['description'];
    final Object? briefDesc = raw['briefDesc'];
    final String descriptionText =
        description is String ? description : (briefDesc is String ? briefDesc : '');

    // :75-78 date：门槛是 toDouble() > 0，取值是 toInteger()，两条语义不同——
    // 3.7 过门但 toInteger 得 0（epoch 当天）；1e300 过门但超出 qint64，同样是 0；
    // 数字字符串 toDouble 得默认 0，不过门，date 留空。
    final String dateText = _publishDate(raw['publishTime']);

    return MusicItem(
      kind: kind,
      id: id,
      title: name,
      artist: artistText,
      creatorId: identifier(creator['userId']),
      albumId: identifier(album['id']),
      album: albumName is String ? albumName : '',
      cover: cover,
      description: descriptionText,
      // :67 有 "wiki" 键（由 item() 给空串），但 parse 全程不赋值（:67-78）。
      wiki: '',
      date: dateText,
      // :65 item() 未传 provider，因此走默认 "netease"（:22-23）。
      provider: 'netease',
      artists: artists,
      duration: durationValue,
      trackCount: trackCountValue,
    );
  }

  /// Qt unique()（:82-96）：按 key 去重。existing 原序保留在前，
  /// values 里未出现过的 key 按序追加；key 相同（含退化 key）只保留第一次出现。
  static List<MusicItem> unique(List<MusicItem> existing, List<MusicItem> values) {
    final Set<String> keys = <String>{for (final MusicItem value in existing) value.key};
    final List<MusicItem> result = <MusicItem>[...existing];
    for (final MusicItem value in values) {
      if (keys.add(value.key)) {
        result.add(value);
      }
    }
    return result;
  }

  /// Qt ordered()（:98-114）：按 ids 顺序取曲目并拼接。
  ///
  /// * 先用 songs 建 id -> 首现曲目 的表（重复 id 只保留第一个，:103-105）。
  /// * ids 元素经 QJsonValue::toString() 取键，即非字符串一律变空串（:109），
  ///   所以 ids 里的数字 123 查不到 id 为 "123" 的曲目。
  /// * ids 里查不到的跳过（:109）；重复 id 会重复输出同一曲目（:107-112 未去重）。
  static List<MusicItem> ordered(List<Object?> ids, List<MusicItem> songs) {
    final Map<String, MusicItem> entries = <String, MusicItem>{};
    for (final MusicItem song in songs) {
      // :102-105 只有 !contains 才插入，故重复 id 保留首现。
      entries.putIfAbsent(song.id, () => song);
    }
    final List<MusicItem> result = <MusicItem>[];
    for (final Object? id in ids) {
      final MusicItem? found = entries[_jsonString(id)];
      if (found != null) {
        result.add(found);
      }
    }
    return result;
  }

  /// Qt slice()（:116-123）。
  ///
  /// 逐字语义：end = min(len, start + count)（用**未抬正的 start** 计算），
  /// 循环从 max(0, start) 到 end。因此：
  /// * start + count <= 0 时 end <= 0，结果为空；
  /// * start < 0 < start + count 时得到前 start + count 个元素；
  /// * count <= 0 时结果为空（end <= start）。
  static List<T> slice<T>(List<T> values, int start, int count) {
    final int end = start + count < values.length ? start + count : values.length;
    final List<T> result = <T>[];
    int index = start < 0 ? 0 : start;
    while (index < end) {
      result.add(values[index]);
      index++;
    }
    return result;
  }

  /// Qt sortOrder()（:161-184）：返回稳定显示索引。
  ///
  /// * field 不在 {title, album, artist} 时返回恒等排列（:167-169）。
  /// * key 取 value[field].toString().trimmed()（:174-176）；空串排最后（:178-180）。
  /// * 相同 key 保持原下标顺序（std::stable_sort，:177）。
  ///
  /// [compare] 注入后**完全取代** Qt 的 QCollator 比较步骤，但仍保留
  /// “空串排最后”的外层规则（与 :178-181 的结构一致）。
  ///
  /// PARITY_RISK: Qt 用 QCollator(QLocale("zh_CN")) + CaseInsensitive + NumericMode
  /// （:170-172）。纯 Dart SDK 没有 ICU 排序表，默认回退比较器只做
  /// “大小写不敏感 + 数字段按数值”的近似，**中文按 code unit 排序而非拼音**，
  /// 与 Qt 中文排序结果不一致。需要严格一致时由调用方注入 [compare]。
  static List<int> sortOrder(
    List<MusicItem> values,
    String field, {
    int Function(String a, String b)? compare,
  }) {
    final List<int> indices = List<int>.generate(values.length, (int index) => index);
    if (field != 'title' && field != 'album' && field != 'artist') {
      return indices;
    }
    final List<String> names = <String>[
      for (final MusicItem value in values) _fieldText(value, field).trim(),
    ];
    final int Function(String a, String b) collate = compare ?? _naturalCompare;

    // :177-182 稳定排序：空名在末尾，其余交给比较器；相等保持原序。
    bool less(int left, int right) {
      final String a = names[left];
      final String b = names[right];
      final bool aEmpty = a.isEmpty;
      final bool bEmpty = b.isEmpty;
      if (aEmpty != bEmpty) {
        return !aEmpty;
      }
      return collate(a, b) < 0;
    }

    return _stableSort(indices, less);
  }

  /// Qt cursor()（:143-146），逐字：
  ///
  ///     const auto index = songs.isEmpty() ? -1 : indexOf(ids, songs.last().toObject()["id"]);
  ///     return index < 0 ? int(songs.size()) : index + 1;
  ///
  /// 关键点：用的是 [indexOf]（类型敏感逐值比较），且取的是**原始** id 值、不经
  /// toString；songs 为空时返回 songs.size() 即 0；找不到时返回 songs.size()。
  static int cursor(List<MusicItem> songs, List<Object?> ids) {
    final int index = songs.isEmpty ? -1 : indexOf(ids, songs.last.id);
    return index < 0 ? songs.length : index + 1;
  }

  /// Qt indexOf()（:125-132），语义 = QJsonValue::operator==：
  ///
  /// * 类型不同一律不等（"1" != 1、true != 1、null != ""）；
  /// * 同为数字比数值（1 == 1.0）；
  /// * 同为数组按元素逐个深比较，同为对象按键值深比较（:127 用 QJsonValue 的相等）；
  /// * 找不到返回 -1。
  static int indexOf(List<Object?> values, Object? value) {
    for (int index = 0; index < values.length; index++) {
      if (_jsonEquals(values[index], value)) {
        return index;
      }
    }
    return -1;
  }

  /// Qt indexOfId()（:134-141）：元素的 ["id"].toString() 与 id 比较。
  ///
  /// 因为是 toString() 而非 identifier()，元素 id 是数字时得到空串，
  /// 只有 id == "" 才会命中（与 :136 逐字一致）。非 Map 元素视为空 Map。
  static int indexOfId(List<Object?> values, String id) {
    for (int index = 0; index < values.length; index++) {
      if (_jsonString(_asMap(values[index])['id']) == id) {
        return index;
      }
    }
    return -1;
  }

  /// Qt pad()（:148-150）：十进制文本长度不足 width 时在**最左**补 '0'。
  ///
  /// Qt 是 QString::number(value).rightJustified(width, '0')，补齐在左端，
  /// 所以负号会被推到后面：pad(-1, 3) == "0-1"。width <= 文本长度时原样返回。
  static String pad(int value, [int width = 2]) {
    final String text = value.toString();
    if (text.length >= width) {
      return text;
    }
    return '0' * (width - text.length) + text;
  }

  /// Qt time()（:152-158）：duration <= 0 -> 暂无；
  /// 否则 pad(int(duration / 60000)) + ":" + pad(int(duration / 1000) % 60)。
  ///
  /// 两次独立截断（各自向零截断，不是先算总秒再除）：3599999 -> "59:59"、
  /// 239999 -> "3:59"、60000 -> "1:00"、59999 -> "0:59"。
  ///
  /// PARITY_RISK: Qt 侧 int(duration / 60000) 与 int(duration / 1000) 是 32 位 int
  /// 截断，duration 超过约 2^31 分钟会溢出（C++ 未定义行为）；Dart 的 int 是 64 位，
  /// 不会溢出。真实曲目时长不可能触及该区间。
  static String time(num duration) {
    if (duration <= 0) {
      return '暂无';
    }
    final int minutes = (duration / 60000).toInt();
    final int seconds = (duration / 1000).toInt() % 60;
    return pad(minutes) + ':' + pad(seconds);
  }

  /// :43 的正则：^[0-9]{1,20}$。
  ///
  /// PARITY_RISK: Qt 的 QRegularExpression 走 PCRE，$ 默认允许匹配串尾单个换行，
  /// 因此 "123\n" 在 Qt 里算命中；Dart RegExp 的 $ 严格贴串尾，"123\n" 不命中。
  /// 真实接口 payload 不会出现带换行的 id，故按严格版实现。
  static final RegExp _identifierPattern = RegExp(r'^[0-9]{1,20}$');
}

// ---------------------------------------------------------------------------
// 以下为 Qt QJsonValue / QString / QCollator 语义的私有复刻。
// ---------------------------------------------------------------------------

/// QJsonValue::toString()：非字符串一律空串（从不做隐式转换）。
String _jsonString(Object? value) => value is String ? value : '';

/// QJsonValue::toObject()：非对象一律空对象。
Map<Object?, Object?> _asMap(Object? value) => value is Map ? value : const <Object?, Object?>{};

/// qint64 的 double 边界（qnumeric_p.h:277-284）：上界 2^63 是开区间，
/// 下界 -2^63 是闭区间。
const double _qint64Supremum = 9223372036854775808.0;
const double _qint64Min = -9223372036854775808.0;

/// QJsonValue::toInteger()（qjsonvalue.cpp:714-729）的 Dart 复刻。
///
/// Integer 分支原样返回（:717-718）；Double 分支只有 convertDoubleTo<qint64> 成功
/// 才返回（:719-723），否则默认值 0（:728）。convertDoubleTo 的整型重载
/// （qnumeric_p.h:164-289）：范围门 :277-284 + 整性判定 return *value == v;（:286）。
int _toInteger(Object? value) {
  if (value is int) {
    // QCborValue::Integer：精确 qint64，不经 double。
    return value;
  }
  if (value is double) {
    // 非有限（inf / -inf / NaN）：范围门必然失败 -> 默认值 0。
    if (!value.isFinite) {
      return 0;
    }
    // :286 return *value == v; 非整数 double 一律失败 -> 默认值 0。
    if (value != value.truncateToDouble()) {
      return 0;
    }
    // :277-284 范围门：v >= 2^63 或 v < -2^63 -> false。
    if (value >= _qint64Supremum || value < _qint64Min) {
      return 0;
    }
    return value.toInt();
  }
  // 非 Double/Integer（null / bool / List / Map）：:725-728 默认值 0。
  return 0;
}

/// QString::number(value.toInteger())（MusicData.cpp:15）的十进制文本。
///
/// 关键：非整数或超出 qint64 的数值经 toInteger() 得 0，因此文本是 "0"
/// （3.7 -> "0"、1e300 -> "0"），不是向零截断。
String _integerText(num value) => _toInteger(value).toString();

/// QJsonValue::toDouble(defaultValue)（qjsonvalue.cpp:736-738）的 Dart 复刻。
///
/// Double 原样返回；Integer 按 double(qint64) 转换（>2^53 丢低位，与 C++ 一致）；
/// 其它类型返回 fallback。数字字符串不参与转换。
double _jsonDouble(Object? value, double fallback) {
  if (value is int) {
    return value.toDouble();
  }
  if (value is double) {
    return value;
  }
  return fallback;
}

/// MusicData.cpp:75-78 的日期列：门槛 toDouble() > 0，取值 toInteger()。
///
/// 两条语义不同，所以 3.7 过门但取值 0（epoch 当天），1e300 同理；
/// 数字字符串 toDouble 得默认 0，不过门。
String _publishDate(Object? publishTime) {
  final bool positive;
  if (publishTime is int) {
    // toDouble 走 double(qint64)。
    positive = publishTime.toDouble() > 0;
  } else if (publishTime is double) {
    // NaN / -inf 均为 false。
    positive = publishTime > 0;
  } else {
    // 非数字：toDouble 得默认 0，不过门。
    positive = false;
  }
  if (!positive) {
    return '';
  }
  return _dateText(_toInteger(publishTime));
}

/// QDateTime::fromMSecsSinceEpoch(ms).date().toString("yyyy-MM-dd")（:76-77）。
///
/// fromMSecsSinceEpoch 默认 Qt::LocalTime（time/qdatetime.cpp:5749-5759），date()
/// 取本地日期，故这里同样用本地时间。
///
/// PARITY_RISK: Dart 的 DateTime 只覆盖约 ±8.64e15 毫秒（公元 ±275760 年），Qt 的
/// QDateTime 覆盖更宽；超出该范围的毫秒值（例如 publishTime = 9e18）Dart 会抛
/// RangeError。真实 publishTime 是发行日期毫秒，不可能触及。
String _dateText(int milliseconds) {
  final DateTime value = DateTime.fromMillisecondsSinceEpoch(milliseconds);
  return MusicData.pad(value.year, 4) +
      '-' +
      MusicData.pad(value.month) +
      '-' +
      MusicData.pad(value.day);
}

/// value.toObject()[field].toString()（:175），仅限三个合法字段。
String _fieldText(MusicItem value, String field) {
  switch (field) {
    case 'title':
      return value.title;
    case 'album':
      return value.album;
    case 'artist':
      return value.artist;
  }
  return '';
}

/// QJsonValue::operator== 的复刻（用于 :127）。
///
/// 与 Dart 原生 == 的差别：需显式判类型，跨类型一律不等（"1" vs 1、true vs 1）。
bool _jsonEquals(Object? left, Object? right) {
  if (left == null || right == null) {
    // Qt 里 Null 与 Undefined 相等；Dart 侧两者都映射为 null。
    return left == null && right == null;
  }
  if (left is bool || right is bool) {
    return left is bool && right is bool && left == right;
  }
  if (left is num || right is num) {
    return left is num && right is num && left == right;
  }
  if (left is String || right is String) {
    return left is String && right is String && left == right;
  }
  if (left is List || right is List) {
    if (left is! List || right is! List || left.length != right.length) {
      return false;
    }
    for (int index = 0; index < left.length; index++) {
      if (!_jsonEquals(left[index], right[index])) {
        return false;
      }
    }
    return true;
  }
  if (left is Map || right is Map) {
    if (left is! Map || right is! Map || left.length != right.length) {
      return false;
    }
    for (final Object? key in left.keys) {
      if (!right.containsKey(key) || !_jsonEquals(left[key], right[key])) {
        return false;
      }
    }
    return true;
  }
  return false;
}

/// 数字位判定：返回 0-9 的数值，非数字返回 -1。
int _digitValue(int codeUnit) {
  if (codeUnit >= 0x30 && codeUnit <= 0x39) {
    return codeUnit - 0x30;
  }
  return -1;
}

/// 默认回退比较器：大小写不敏感 + 数字段按数值（近似 QCollator 的
/// CaseInsensitive + NumericMode）。
///
/// PARITY_RISK: 中文按 code unit 比较，不是 zh_CN 拼音序；这是纯 Dart 无法复刻
/// ICU collation 的已知差距，已在 [MusicData.sortOrder] 文档中标注，
/// 需要严格一致时请注入 compare。
int _naturalCompare(String a, String b) {
  final String x = a.toLowerCase();
  final String y = b.toLowerCase();
  int i = 0;
  int j = 0;
  while (i < x.length && j < y.length) {
    final int cx = x.codeUnitAt(i);
    final int cy = y.codeUnitAt(j);
    final int dx = _digitValue(cx);
    final int dy = _digitValue(cy);
    if (dx >= 0 && dy >= 0) {
      int startX = i;
      int startY = j;
      while (startX < x.length && x.codeUnitAt(startX) == 0x30) {
        startX++;
      }
      while (startY < y.length && y.codeUnitAt(startY) == 0x30) {
        startY++;
      }
      int endX = startX;
      int endY = startY;
      while (endX < x.length && _digitValue(x.codeUnitAt(endX)) >= 0) {
        endX++;
      }
      while (endY < y.length && _digitValue(y.codeUnitAt(endY)) >= 0) {
        endY++;
      }
      final int lengthX = endX - startX;
      final int lengthY = endY - startY;
      if (lengthX != lengthY) {
        return lengthX < lengthY ? -1 : 1;
      }
      for (int offset = 0; offset < lengthX; offset++) {
        final int diff = x.codeUnitAt(startX + offset) - y.codeUnitAt(startY + offset);
        if (diff != 0) {
          return diff < 0 ? -1 : 1;
        }
      }
      // 数值相等（含 "01" vs "1"）：继续比后续字符。
      i = endX;
      j = endY;
      continue;
    }
    if (cx != cy) {
      return cx < cy ? -1 : 1;
    }
    i++;
    j++;
  }
  final int restX = x.length - i;
  final int restY = y.length - j;
  if (restX == restY) {
    return 0;
  }
  return restX < restY ? -1 : 1;
}

/// 稳定归并排序（std::stable_sort 的等价物，:177）。
///
/// 不依赖 List.sort（Dart 不保证稳定）；相等元素保持原下标顺序。
List<int> _stableSort(List<int> indices, bool Function(int left, int right) less) {
  final int length = indices.length;
  if (length < 2) {
    return List<int>.of(indices);
  }
  List<int> source = List<int>.of(indices);
  List<int> target = List<int>.filled(length, 0);
  int width = 1;
  while (width < length) {
    int base = 0;
    while (base < length) {
      final int middle = base + width < length ? base + width : length;
      final int end = base + width + width < length ? base + width + width : length;
      int left = base;
      int right = middle;
      int out = base;
      while (left < middle && right < end) {
        // 只有严格小于才取右侧，保证稳定。
        if (less(source[right], source[left])) {
          target[out++] = source[right++];
        } else {
          target[out++] = source[left++];
        }
      }
      while (left < middle) {
        target[out++] = source[left++];
      }
      while (right < end) {
        target[out++] = source[right++];
      }
      base = end;
    }
    final List<int> swap = source;
    source = target;
    target = swap;
    width *= 2;
  }
  return source;
}
