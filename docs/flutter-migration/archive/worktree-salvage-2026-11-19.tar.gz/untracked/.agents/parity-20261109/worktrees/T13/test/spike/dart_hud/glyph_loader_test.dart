// T13-S01 source-level parity tests for the Dart mirror of Qt/src/Glyphs.cpp.
//
// Authored before the implementation (tests-first) but NEVER EXECUTED in this
// stage: the migration plan forbids dart test/analyze/build until the Lead
// opens the run gate. Expected values are derived from the Qt source:
//   Qt/src/Glyphs.cpp:190-265  path(svg) parser
//   Qt/src/Glyphs.cpp:286-311  width()
//   Qt/src/Glyphs.cpp:312-338  bounds()
//   Qt/src/Glyphs.cpp:339-349  inset()
//   Qt/src/Glyphs.cpp:403-412  artWidth()
//   Qt/src/Glyphs.cpp:35-49    color() calibrated gamma 1.8 -> sRGB
//   Qt/src/Glyphs.cpp:530-588  text() / art() baseline handling
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/spike/dart_hud/glyph_loader.dart';

const String _aPath =
    'M624 2 350 738H289L15 2H77L175 268H465L563 2ZM318 653H322L444 323H196Z';

Map<String, dynamic> _syntheticGlyphs() {
  Map<String, dynamic> weight(Map<String, dynamic> glyphs) => <String, dynamic>{
        'units': 1000,
        'ascent': 1044,
        'descent': -282,
        'glyphs': glyphs,
      };
  final Map<String, dynamic> glyphs = <String, dynamic>{
    'A': <String, dynamic>{'advance': 0.5, 'path': 'M0 0 L500 0 L500 700 Z'},
    'B': <String, dynamic>{
      'advance': 0.6,
      'path': 'M100 0 L600 0 L600 700 Z',
    },
    'C': <String, dynamic>{'advance': 0.7, 'path': 'M0 0 L300 0 L300 400 Z'},
  };
  return <String, dynamic>{
    'light': weight(glyphs),
    'regular': weight(glyphs),
    'demibold': weight(glyphs),
    'bold': weight(glyphs),
  };
}

Map<String, dynamic> _syntheticLettering() => <String, dynamic>{
      't13-test': <String, dynamic>{
        'text': 'ABC',
        'weight': 'Normal',
        'units': 1000,
        'letters': <dynamic>[
          <String, dynamic>{'width': 0.5, 'path': 'M0 0 L500 0 L500 700 Z'},
          <String, dynamic>{'width': 0.6, 'path': 'M100 0 L600 0 L600 700 Z'},
          <String, dynamic>{'width': 0.7, 'path': 'M0 0 L300 0 L300 400 Z'},
        ],
      },
    };

GlyphAtlas _atlas() => GlyphAtlas.fromMaps(
      glyphs: _syntheticGlyphs(),
      lettering: _syntheticLettering(),
    );

void main() {
  group('parseSvgText mirrors Qt/src/Glyphs.cpp:190-265', () {
    test('implicit lineto after absolute moveto and H/V/L, WindingFill', () {
      final ui.Path path = GlyphAtlas.parseSvgText(_aPath);
      final ui.Rect bounds = path.getBounds();
      expect(path.fillType, ui.PathFillType.nonZero);
      expect(bounds.left, closeTo(15, 1e-6));
      expect(bounds.top, closeTo(2, 1e-6));
      expect(bounds.right, closeTo(624, 1e-6));
      expect(bounds.bottom, closeTo(738, 1e-6));
    });

    test('relative command origin is captured before the coordinate pair', () {
      final ui.Path path = GlyphAtlas.parseSvgText('m10 10 5 5');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.left, closeTo(10, 1e-6));
      expect(bounds.top, closeTo(10, 1e-6));
      expect(bounds.right, closeTo(15, 1e-6));
      expect(bounds.bottom, closeTo(15, 1e-6));
    });

    test('relative h/v keep the other axis', () {
      final ui.Path path = GlyphAtlas.parseSvgText('M100 100 h50 v25');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.left, closeTo(100, 1e-6));
      expect(bounds.bottom, closeTo(125, 1e-6));
      expect(bounds.right, closeTo(150, 1e-6));
    });

    test('quadratic end point becomes the new current point', () {
      final ui.Path path = GlyphAtlas.parseSvgText('M0 0 Q100 100 200 0 L200 300');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.right, closeTo(200, 1e-6));
      expect(bounds.bottom, closeTo(300, 1e-6));
    });

    test('cubic end point becomes the new current point', () {
      final ui.Path path =
          GlyphAtlas.parseSvgText('M0 0 C100 100 200 100 300 0 L300 400');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.right, closeTo(300, 1e-6));
      expect(bounds.bottom, closeTo(400, 1e-6));
    });

    test('Z closes the subpath and a following letter starts a new one', () {
      final ui.Path path =
          GlyphAtlas.parseSvgText('M0 0 L100 0 L100 100 Z M200 200 L300 200');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.right, closeTo(300, 1e-6));
      expect(bounds.bottom, closeTo(200, 1e-6));
    });

    test('numbers after Z abort the remainder but keep the built path', () {
      final ui.Path path = GlyphAtlas.parseSvgText('M0 0 L10 0 Z 5 5');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.right, closeTo(10, 1e-6));
      expect(bounds.bottom, closeTo(0, 1e-6));
    });

    test('unsupported command letters abort the remainder', () {
      final ui.Path path = GlyphAtlas.parseSvgText('M0 0 L50 0 S100 100 150 150');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.right, closeTo(50, 1e-6));
    });

    test('exhausted coordinate tokens read as zero instead of throwing', () {
      late ui.Path path;
      expect(() => path = GlyphAtlas.parseSvgText('M0 0 L'), returnsNormally);
      expect(path.getBounds().right, closeTo(0, 1e-6));
    });

    test('signs and exponents are parsed by the shared token regex', () {
      final ui.Path path = GlyphAtlas.parseSvgText('M-1e2 +5 L0 0');
      final ui.Rect bounds = path.getBounds();
      expect(bounds.left, closeTo(-100, 1e-6));
      expect(bounds.bottom, closeTo(5, 1e-6));
    });

    test('blank input yields an empty path', () {
      expect(GlyphAtlas.parseSvgText('').getBounds(), ui.Rect.zero);
    });
  });

  group('colorFromJson mirrors Qt/src/Glyphs.cpp:35-49', () {
    test('calibrated fifth channel applies gamma 1.8 then sRGB transfer', () {
      final ui.Color color =
          GlyphAtlas.colorFromJson(<dynamic>[0.92, 0.92, 0.92, 1, 'calibratedWhite']);
      final double linear = math.pow(0.92, 1.8).toDouble();
      final double expected = linear <= 0.0031308
          ? 12.92 * linear
          : 1.055 * math.pow(linear, 1 / 2.4) - 0.055;
      expect(color.r, closeTo(expected, 1e-6));
      expect(color.r, closeTo(0.9361, 5e-3));
      expect(color.a, closeTo(1, 1e-6));
    });

    test('unmarked rgba is passed through untouched', () {
      final ui.Color color = GlyphAtlas.colorFromJson(<dynamic>[0.141, 0.161, 0.145, 1]);
      expect(color.r, closeTo(0.141, 1e-6));
      expect(color.g, closeTo(0.161, 1e-6));
      expect(color.b, closeTo(0.145, 1e-6));
    });

    test('three channel colors default to opaque', () {
      expect(GlyphAtlas.colorFromJson(<dynamic>[1, 0, 0]).a, closeTo(1, 1e-6));
    });

    test('a non calibrated fifth item leaves channels linear', () {
      final ui.Color color = GlyphAtlas.colorFromJson(<dynamic>[0.2, 0.3, 0.4, 0.5, 'srgb']);
      expect(color.r, closeTo(0.2, 1e-6));
      expect(color.a, closeTo(0.5, 1e-6));
    });

    test('missing channels read as zero', () {
      final ui.Color color = GlyphAtlas.colorFromJson(<dynamic>[]);
      expect(color.r, closeTo(0, 1e-6));
      expect(color.a, closeTo(1, 1e-6));
    });
  });

  group('metrics mirror Glyphs::width/bounds/inset/artWidth', () {
    test('width adds tracking between characters only', () {
      final GlyphAtlas atlas = _atlas();
      expect(atlas.width('A', 20, 'regular'), closeTo(10, 1e-6));
      expect(atlas.width('A', 20, 'regular', tracking: 1), closeTo(10, 1e-6));
      expect(atlas.width('AB', 20, 'regular', tracking: 1), closeTo(23, 1e-6));
      expect(atlas.width('', 20, 'regular', tracking: 1), closeTo(0, 1e-6));
    });

    test('missing glyph falls back to advance 1 and an empty contour', () {
      final GlyphAtlas atlas = _atlas();
      final GlyphShape shape = atlas.glyph('Z', 'regular');
      expect(shape.advance, closeTo(1, 1e-6));
      expect(shape.hasContour, isFalse);
      expect(atlas.width('Z', 20, 'regular'), closeTo(20, 1e-6));
      expect(atlas.missingGlyphCount, 1);
    });

    test('bounds apply baseline 1.044 and the y flip', () {
      final GlyphAtlas atlas = _atlas();
      final ui.Rect bounds = atlas.bounds('A', 20, 'regular');
      expect(bounds.left, closeTo(0, 1e-6));
      expect(bounds.right, closeTo(10, 1e-6));
      expect(bounds.top, closeTo(20.88 - 14, 1e-6));
      expect(bounds.bottom, closeTo(20.88, 1e-6));
    });

    test('bounds accumulate advance without tracking', () {
      final GlyphAtlas atlas = _atlas();
      final ui.Rect bounds = atlas.bounds('AB', 20, 'regular');
      expect(bounds.left, closeTo(0, 1e-6));
      expect(bounds.right, closeTo(10 + 12, 1e-6));
    });

    test('inset is the first contour left edge scaled to the em size', () {
      final GlyphAtlas atlas = _atlas();
      expect(atlas.inset('A', 20, 'regular'), closeTo(0, 1e-6));
      expect(atlas.inset('B', 20, 'regular'), closeTo(2, 1e-6));
      expect(atlas.inset('', 20, 'regular'), closeTo(0, 1e-6));
    });

    test('artWidth subtracts one trailing tracking step', () {
      final GlyphAtlas atlas = _atlas();
      expect(atlas.artWidth('t13-test', 20, tracking: 1), closeTo(38, 1e-6));
      expect(atlas.artWidth('t13-test', 20, tracking: 1, count: 2), closeTo(23, 1e-6));
      expect(atlas.artWidth('missing-key', 20, tracking: 1), closeTo(0, 1e-6));
    });

    test('baseline factor and em units match the Qt contract', () {
      expect(GlyphAtlas.baselineFactor, 1.044);
      expect(GlyphAtlas.unitsPerEm, 1000);
      expect(GlyphAtlas.weights,
          <String>['light', 'regular', 'demibold', 'bold']);
    });

    test('drawText and drawArt are callable without a live engine', () {
      final GlyphAtlas atlas = _atlas();
      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final ui.Canvas canvas = ui.Canvas(recorder);
      expect(
          () => atlas.drawText(canvas, 'AB', 10, 20, 20, 'regular',
              const ui.Color(0xFF111111),
              tracking: 1),
          returnsNormally);
      expect(
          () => atlas.drawArt(canvas, 't13-test', 10, 20, 20,
              const ui.Color(0xFF111111),
              count: -1, tracking: 1),
          returnsNormally);
      recorder.endRecording().dispose();
    });
  });

  group('requiresShapedLayout mirrors Glyphs::needsLayout', () {
    test('latin and CJK stay on the per-glyph path', () {
      final GlyphAtlas atlas = _atlas();
      expect(atlas.requiresShapedLayout('RHINE LAB / MUSIC DATABASE'), isFalse);
      expect(atlas.requiresShapedLayout('莱茵生命'), isFalse);
      expect(atlas.requiresShapedLayout('カタカナ'), isFalse);
      expect(atlas.requiresShapedLayout('한국'), isFalse);
    });

    test('astral, combining, jamo, joiners and RTL scripts need layout', () {
      final GlyphAtlas atlas = _atlas();
      expect(atlas.requiresShapedLayout('a\u0301'), isTrue);
      expect(atlas.requiresShapedLayout('\u1100'), isTrue);
      expect(atlas.requiresShapedLayout('\u200d'), isTrue);
      expect(atlas.requiresShapedLayout('\u05d0'), isTrue);
      expect(atlas.requiresShapedLayout('\u{1F600}'), isTrue);
    });
  });

  test('load() reads the two Qt resource files when they exist', () async {
    final File glyphs = File('Assets/fonts/misans-glyphs.json');
    final File lettering = File('Resources/boot-lettering-art.json');
    if (!glyphs.existsSync() || !lettering.existsSync()) {
      return;
    }
    final GlyphAtlas atlas = GlyphAtlas.fromJsonStrings(
      glyphsJson: glyphs.readAsStringSync(),
      letteringJson: lettering.readAsStringSync(),
    );
    expect(atlas.width('A', 20, 'regular'), closeTo(0.639 * 20, 1e-6));
    final ui.Rect bounds = atlas.bounds('A', 20, 'regular');
    expect(bounds.left, closeTo(15 * 0.02, 1e-6));
    expect(bounds.right, closeTo(624 * 0.02, 1e-6));
    expect(atlas.missingGlyphCount, 0);
  });
}
