// Qt Android 离屏 Texture 的 Dart 端口（T12 候选 B「Qt 离屏 Texture 切片」）。
//
// ---------------------------------------------------------------------------
// 这套 API 是 **port-local** 的：本仓库 Flutter 移植层自定义的宿主适配接口，
// 不是 Qt 既有的远程/本地协议字段，也不得在任何对照报告里被描述成 Qt 原协议的一部分。
// 真值来源只有 Qt 业务侧（commands/hits/frame 等）与 native 渲染器；本文件只做通道与合成。
// ---------------------------------------------------------------------------
//
// 冻结契约 v1 —— Dart / Kotlin TextureBridge / native TextureHost 三方逐字对称，全字段不可改：
//
//   channel         : rhine.music.database/porting/qt_texture
//   protocolVersion : 1
//
//   "probe"        {}                                                       -> {status, backend, protocolVersion, reason}
//   "create"       {width:int, height:int, dpr:double, rotationQuarterTurns:int}
//                                                                           -> {textureId:int, status, backend, width:int, height:int}
//   "render"       {textureId:int, frameTimeNanos:int}                      -> {textureId:int, rendered:bool, frameSequence:int, firstFrame:bool,
//                                                                               width:int, height:int, rotationQuarterTurns:int,
//                                                                               publishTimestampNanos:int, status}
//   "resize"       {textureId:int, width:int, height:int, dpr:double}       -> {width:int, height:int}
//   "setRotation"  {textureId:int, quarterTurns:int}                        -> {rotationQuarterTurns:int}
//   "status"       {textureId:int}                                          -> {status, textureId:int, frameSequence:int, firstFrameRendered:bool,
//                                                                               width:int, height:int, rotationQuarterTurns:int, backend,
//                                                                               lastError, publishTimestampNanos:int}
//   "dispose"      {textureId:int}                                          -> {released:bool}
//   "sendPointer"  {textureId:int, x:double, y:double, phase:"down"|"move"|"up", buttons:int}
//                                                                           -> {accepted:bool}
//   "sendKey"      {textureId:int, key:int, down:bool, repeat:bool}         -> {accepted:bool}
//
//   status 枚举  : "ready" | "nativeUnavailable" | "archBlocked" | "deviceBlocked" | "failed" | "released"
//   backend 枚举 : "opengl" | "vulkan" | "none"
//
// JNI 侧（Kotlin，类 rhine.music.database.porting.TextureBridge，companion object + @JvmStatic）：
//   nativeProbe / nativeCreate / nativeResize / nativeSetRotation / nativeRender / nativeStatus /
//   nativeSendPointer / nativeSendKey / nativeDestroy，符号 Java_rhine_music_database_porting_TextureBridge_<name>。
//   System.loadLibrary 依次试 "RhineMusicDatabase_arm64-v8a"、"RhineMusicDatabase"；全失败 => status="nativeUnavailable"，
//   reason 含两个库名与异常 message，绝不把异常抛给 Dart（Dart 侧因此只需处理通道异常与契约违约）。
//
// ---------------------------------------------------------------------------
// 边界与失败出口（不许假成功）
//
// ARCH_BLOCKED —— 宿主接线未落地：MainActivity.kt / FlutterEngine 的 MethodChannel 注册、
//   build.gradle.kts 的 externalNativeBuild、pubspec 的 integration_test 依赖，都是共享文件域，
//   本原子无权修改。因此：
//     * 宿主完全没接线时，通道抛 MissingPluginException —— [QtTextureController.probe] 把它映射成
//       state = nativeUnavailable、protocolVersion = 0（0 = 未知，不冒充 1）、reason 带通道名与原始异常；
//     * .so 未随 APK 打包（或 ABI 不匹配）时，由 Kotlin 侧返回 nativeUnavailable / archBlocked（Dart 侧原样透传）；
//     * 其它方法不做这种映射：platform 异常原样抛出，绝不把“没有通道”伪装成“已渲染”。
//
// DEVICE_BLOCKED —— 离屏首帧、像素正确性、旋转、时序、性能全部需要真机证据；本树所有验证均为
//   NOT_EXECUTED（禁 flutter/dart/gradle/adb）。Dart 侧永远不产生 "ready"：ready 只能是 native 回传的字符串。
//
// 线程 / 生命周期 ——
//   * MethodChannel 只能在 UI isolate 调用（默认 messenger 绑定 Flutter 绑定）；不要在本类外用后台 isolate 调。
//   * 真实渲染在平台侧 GL 线程；render() 返回时并不保证该帧已被合成（publishTimestampNanos 由 native 给出）。
//   * create 分配 SurfaceTexture 并返回 textureId；每帧必须由调用方显式 render()，Dart 侧不自动驱动、不插帧、不补帧。
//   * dispose 之后 textureId 立即视为失效；是否真的释放只能看 native 返回的 released，Dart 侧不会自行把状态改成 released。
//   * [QtTextureSurface] 只做合成与占位：不 probe、不 create、不轮询、不插帧（避免隐式副作用），
//     状态由调用方把 native 快照传进来；它持有 textureId 的 ownership，卸载时尽力调用 controller.dispose。
// ---------------------------------------------------------------------------

import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// 通道名（冻结契约 v1）。
const String qtTextureChannelName = 'rhine.music.database/porting/qt_texture';

/// 协议版本（冻结契约 v1）。
const int qtTextureProtocolVersion = 1;

/// probe 方法名。
const String qtTextureMethodProbe = 'probe';

/// create 方法名。
const String qtTextureMethodCreate = 'create';

/// render 方法名。
const String qtTextureMethodRender = 'render';

/// resize 方法名。
const String qtTextureMethodResize = 'resize';

/// setRotation 方法名。
const String qtTextureMethodSetRotation = 'setRotation';

/// status 方法名。
const String qtTextureMethodStatus = 'status';

/// dispose 方法名。
const String qtTextureMethodDispose = 'dispose';

/// sendPointer 方法名。
const String qtTextureMethodSendPointer = 'sendPointer';

/// sendKey 方法名。
const String qtTextureMethodSendKey = 'sendKey';

/// native 侧 status / probe.status 的取值（冻结枚举，只有这六个字符串）。
///
/// 未知字符串一律落到 [QtTextureState.failed]，并把原始字符串保留在模型的 rawStatus 上
/// （见 [parse]），绝不静默映射成 ready。
enum QtTextureState {
  /// 纹理已创建且 native 认为可用。
  ready('ready'),

  /// native 库未加载 / JNI 不可用（宿主未接线或 .so 未随包）。
  nativeUnavailable('nativeUnavailable'),

  /// 架构性阻塞（例如宿主接线缺失、后端不兼容等需要上层改共享文件的阻塞）。
  archBlocked('archBlocked'),

  /// 设备侧阻塞（无真机证据、驱动/ABI 不满足等）。
  deviceBlocked('deviceBlocked'),

  /// 失败（含未知 status 字符串的落点）。
  failed('failed'),

  /// 已释放。
  released('released');

  const QtTextureState(this.wire);

  /// 线上字符串，必须与冻结契约逐字一致。
  final String wire;

  /// 解析 native 回传的 status 字符串。
  ///
  /// 未知字符串 => [QtTextureState.failed]，返回记录的 unknown 非 null 即表示“未识别”，
  /// 调用方应把它保留到模型的 rawStatus，不要吞掉。
  static ({QtTextureState state, String? unknown}) parse(String raw) {
    for (final QtTextureState candidate in values) {
      if (candidate.wire == raw) {
        return (state: candidate, unknown: null);
      }
    }
    return (state: QtTextureState.failed, unknown: raw);
  }
}

/// native 渲染后端（冻结枚举）。
///
/// 未知 backend 不属于“可容忍降级”：契约只允许这三个值，遇到别的字符串一律抛
/// [QtTextureProtocolException]（不映射成 none，避免把“未知后端”伪装成“无后端”）。
enum QtTextureBackend {
  /// OpenGL / GLES（本切片的主路径）。
  opengl('opengl'),

  /// Vulkan。
  vulkan('vulkan'),

  /// 没有可用后端。
  none('none');

  const QtTextureBackend(this.wire);

  /// 线上字符串，必须与冻结契约逐字一致。
  final String wire;

  /// 解析 native 回传的 backend 字符串；未知值返回 null（是否抛异常由调用点决定）。
  static QtTextureBackend? tryParse(String raw) {
    for (final QtTextureBackend candidate in values) {
      if (candidate.wire == raw) {
        return candidate;
      }
    }
    return null;
  }
}

/// sendPointer 的 phase（冻结契约里的 "down" | "move" | "up"）。
enum QtPointerPhase {
  /// 按下。
  down('down'),

  /// 移动。
  move('move'),

  /// 抬起。
  up('up');

  const QtPointerPhase(this.wire);

  /// 线上字符串。
  final String wire;
}

/// 契约违约：方法回传的 Map 缺键、类型不符，或取值超出冻结枚举。
///
/// 只用于“native 与冻结契约不一致”的情况；platform 侧异常（[PlatformException]）原样透传，
/// 不会被包装成本异常（避免把两种失败混为一谈）。
class QtTextureProtocolException implements Exception {
  /// 创建异常。
  const QtTextureProtocolException({
    required this.method,
    required this.key,
    this.expected,
    this.actual,
    this.detail,
  });

  /// 出错的方法名（[qtTextureMethodProbe] 等）。
  final String method;

  /// 出错的 Map 键；<result> 表示整个结果不是 Map。
  final String key;

  /// 期望的类型 / 取值集合。
  final String? expected;

  /// 实际拿到的值（用于诊断）。
  final Object? actual;

  /// 额外说明（例如 key 缺失）。
  final String? detail;

  @override
  String toString() {
    final StringBuffer buffer = StringBuffer('QtTextureProtocolException(')
      ..write('method: ')
      ..write(method)
      ..write(', key: ')
      ..write(key);
    if (expected != null) {
      buffer
        ..write(', expected: ')
        ..write(expected);
    }
    buffer
      ..write(', actual: ')
      ..write(actual)
      ..write(' (')
      ..write(actual.runtimeType)
      ..write(')');
    if (detail != null) {
      buffer
        ..write(', detail: ')
        ..write(detail);
    }
    buffer.write(')');
    return buffer.toString();
  }
}

/// probe 的结果（{status, backend, protocolVersion, reason}）。
///
/// rawStatus 是 Dart 侧诊断字段（不在 wire 契约里）：未知 status 字符串时保留原始值，
/// 宿主通道缺失时由 Dart 侧填入 nativeUnavailable。
class QtTextureProbe {
  /// 创建 probe 结果。
  const QtTextureProbe({
    required this.state,
    required this.backend,
    required this.protocolVersion,
    required this.reason,
    required this.rawStatus,
  });

  /// 解析后的状态。
  final QtTextureState state;

  /// native 后端。
  final QtTextureBackend backend;

  /// native 报告的协议版本；宿主管道缺失时由 Dart 侧填 0（未知，不冒充 1）。
  final int protocolVersion;

  /// native 给的原因（通常只在非 ready 时有内容）。
  final String reason;

  /// 原样保留的 status 字符串（未知枚举值 / 宿主缺失时用于诊断）。
  final String rawStatus;

  /// 协议版本是否与本端一致。
  bool get isProtocolCompatible => protocolVersion == qtTextureProtocolVersion;

  /// native 是否报告 ready。
  bool get isReady => state == QtTextureState.ready;
}

/// render / create 的结果（render 的响应字段 + Dart 侧诊断字段）。
///
/// rendered 是 render 响应里的 rendered（create 时恒为 false，因为 create 不产帧）。
/// 冻结契约里的 render 响应不含 backend，因此本类也不含 backend —— 需要 backend 请用
/// [QtTextureController.status] 或 [QtTextureController.probe]。
/// rawStatus 是 Dart 侧诊断字段（不在 wire 契约里）。
class QtTextureFrame {
  /// 创建一帧的记录。
  const QtTextureFrame({
    required this.textureId,
    required this.rendered,
    required this.sequence,
    required this.firstFrame,
    required this.width,
    required this.height,
    required this.rotationQuarterTurns,
    required this.publishTimestampNanos,
    required this.state,
    required this.rawStatus,
  });

  /// Flutter textureId（与 create 返回一致）。
  final int textureId;

  /// 本次 render 是否真的产出了新帧（native 的 rendered）。
  final bool rendered;

  /// native 的帧序号（frameSequence）。
  final int sequence;

  /// 是否首帧（native 的 firstFrame）。
  final bool firstFrame;

  /// 帧宽度（物理像素，native 报）。
  final int width;

  /// 帧高度（物理像素，native 报）。
  final int height;

  /// 四分之一圈旋转，取值 0..3（native 报；create 返回时是请求值的回填，见 [QtTextureController.create]）。
  final int rotationQuarterTurns;

  /// native 给出的发布时刻（纳秒）；Dart 侧不推算、不覆盖。
  final int publishTimestampNanos;

  /// 解析后的状态。
  final QtTextureState state;

  /// 原样保留的 status 字符串（未知枚举值时用于诊断）。
  final String rawStatus;
}

/// status 的结果（完整快照）。
///
/// rawStatus 是 Dart 侧诊断字段（不在 wire 契约里）：未知 status 字符串时保留原始值。
class QtTextureInfo {
  /// 创建快照。
  const QtTextureInfo({
    required this.state,
    required this.textureId,
    required this.sequence,
    required this.firstFrameRendered,
    required this.width,
    required this.height,
    required this.rotationQuarterTurns,
    required this.backend,
    required this.lastError,
    required this.publishTimestampNanos,
    required this.rawStatus,
  });

  /// 解析后的状态。
  final QtTextureState state;

  /// Flutter textureId。
  final int textureId;

  /// native 的帧序号（frameSequence）。
  final int sequence;

  /// native 是否已渲染过首帧（firstFrameRendered）。
  final bool firstFrameRendered;

  /// 当前缓冲宽度（物理像素）。
  final int width;

  /// 当前缓冲高度（物理像素）。
  final int height;

  /// 四分之一圈旋转，0..3。
  final int rotationQuarterTurns;

  /// native 后端。
  final QtTextureBackend backend;

  /// native 记录的最后一条错误（契约允许 null / 空串 => 这里归一成空串）。
  final String lastError;

  /// native 给出的发布时刻（纳秒）。
  final int publishTimestampNanos;

  /// 原样保留的 status 字符串（未知枚举值时用于诊断）。
  final String rawStatus;
}

/// 冻结契约 v1 的 Dart 客户端。
///
/// 可注入 [MethodChannel]（测试用 mock messenger）或 [BinaryMessenger]（不依赖 Activity / 静态单例）。
/// 所有方法都严格校验回传 Map：缺键、类型不符、backend 越界 => [QtTextureProtocolException]；
/// 不静默兜底、不伪造 ready / rendered / released。
class QtTextureController {
  /// 创建控制器。
  ///
  /// [channel] 优先；否则用 [messenger] 建一个同名通道；都没有时用默认 messenger 的常量通道。
  QtTextureController({MethodChannel? channel, BinaryMessenger? messenger})
    : _channel =
          channel ??
          (messenger == null
              ? const MethodChannel(qtTextureChannelName)
              : MethodChannel(
                  qtTextureChannelName,
                  const StandardMethodCodec(),
                  messenger,
                ));

  /// 协议版本常量（= 1）。
  static const int protocolVersion = qtTextureProtocolVersion;

  /// 通道名常量。
  static const String channelName = qtTextureChannelName;

  final MethodChannel _channel;

  /// 实际使用的通道（便于调用方/测试断言）。
  MethodChannel get channel => _channel;

  /// probe：探测 native 是否可用。
  ///
  /// 宿主完全未接线时通道会抛 [MissingPluginException]；这里把它映射成
  /// state = nativeUnavailable、protocolVersion = 0、reason = 通道名 + 原始异常
  /// —— 这是 ARCH_BLOCKED 的显式出口，不是 ready，也不会伪造任何像素/版本号。
  /// 其它异常（[PlatformException] 等）原样透传。
  Future<QtTextureProbe> probe() async {
    final ({Map<Object?, Object?>? result, String? missingPlugin}) raw =
        await _probeRaw();
    final Map<Object?, Object?>? result = raw.result;
    if (result == null) {
      return QtTextureProbe(
        state: QtTextureState.nativeUnavailable,
        backend: QtTextureBackend.none,
        protocolVersion: 0,
        reason:
            'MethodChannel "$qtTextureChannelName" 无宿主实现'
            '（宿主接线属 ARCH_BLOCKED）: ${raw.missingPlugin}',
        rawStatus: QtTextureState.nativeUnavailable.wire,
      );
    }

    final _Wire wire = _Wire(qtTextureMethodProbe, result);
    final ({QtTextureState state, String raw}) status = wire.state('status');
    return QtTextureProbe(
      state: status.state,
      backend: wire.backend('backend'),
      protocolVersion: wire.integer('protocolVersion'),
      reason: wire.text('reason', allowNull: true),
      rawStatus: status.raw,
    );
  }

  /// 只把 MissingPluginException 收敛成“通道缺失”，其它异常照旧抛出。
  Future<({Map<Object?, Object?>? result, String? missingPlugin})>
  _probeRaw() async {
    try {
      return (
        result: await _invoke(qtTextureMethodProbe, const <String, Object?>{}),
        missingPlugin: null,
      );
    } on MissingPluginException catch (error) {
      return (result: null, missingPlugin: error.message ?? '(no message)');
    }
  }

  /// create：分配一个离屏纹理并返回 textureId。
  ///
  /// [width] / [height] 是 buffer 的物理像素（native 侧 setDefaultBufferSize 的口径）；
  /// [dpr] 是设备像素比，原样交给 native，用于其内部几何换算。
  ///
  /// 返回的 [QtTextureFrame] 里：rendered = false、sequence = 0、firstFrame = false、
  /// publishTimestampNanos = 0（create 不产帧，这些都是“还没有帧”的事实，不是占位数据）；
  /// rotationQuarterTurns 回填调用方请求的值（create 响应契约不含该键，native 确认请用 [status]）。
  /// create 响应里的 backend 只做契约校验，不保留（[QtTextureFrame] 的冻结字段不含 backend）。
  Future<QtTextureFrame> create({
    required int width,
    required int height,
    required double dpr,
    int rotationQuarterTurns = 0,
  }) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodCreate,
      <String, Object?>{
        'width': width,
        'height': height,
        'dpr': dpr,
        'rotationQuarterTurns': rotationQuarterTurns,
      },
    );
    final _Wire wire = _Wire(qtTextureMethodCreate, result);
    final int textureId = wire.integer('textureId');
    final ({QtTextureState state, String raw}) status = wire.state('status');
    // 校验 backend 的类型与取值，但不保留：见方法文档。
    wire.backend('backend');
    final int createdWidth = wire.integer('width');
    final int createdHeight = wire.integer('height');
    return QtTextureFrame(
      textureId: textureId,
      rendered: false,
      sequence: 0,
      firstFrame: false,
      width: createdWidth,
      height: createdHeight,
      rotationQuarterTurns: rotationQuarterTurns,
      publishTimestampNanos: 0,
      state: status.state,
      rawStatus: status.raw,
    );
  }

  /// render：让 native 渲染一帧。
  ///
  /// [frameTimeNanos] 缺省时用 DateTime.now().microsecondsSinceEpoch * 1000：
  /// Dart 侧没有可移植的绝对单调时钟（Stopwatch 只有 elapsed），墙钟会被 NTP / 手动改时间跳变，
  /// 因此这个值只当“提示时间”用；**单调性与夹取必须由 native 侧校正**（System.nanoTime() / CLOCK_MONOTONIC），
  /// Dart 侧不做补偿、不重排帧、不伪造 rendered / publishTimestampNanos。
  Future<QtTextureFrame> render(int textureId, {int? frameTimeNanos}) async {
    final int stamp =
        frameTimeNanos ?? DateTime.now().microsecondsSinceEpoch * 1000;
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodRender,
      <String, Object?>{'textureId': textureId, 'frameTimeNanos': stamp},
    );
    final _Wire wire = _Wire(qtTextureMethodRender, result);
    final ({QtTextureState state, String raw}) status = wire.state('status');
    return QtTextureFrame(
      textureId: wire.integer('textureId'),
      rendered: wire.boolean('rendered'),
      sequence: wire.integer('frameSequence'),
      firstFrame: wire.boolean('firstFrame'),
      width: wire.integer('width'),
      height: wire.integer('height'),
      rotationQuarterTurns: wire.integer('rotationQuarterTurns'),
      publishTimestampNanos: wire.integer('publishTimestampNanos'),
      state: status.state,
      rawStatus: status.raw,
    );
  }

  /// resize：改 buffer 尺寸（textureId 不变）。
  Future<({int width, int height})> resize(
    int textureId, {
    required int width,
    required int height,
    required double dpr,
  }) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodResize,
      <String, Object?>{
        'textureId': textureId,
        'width': width,
        'height': height,
        'dpr': dpr,
      },
    );
    final _Wire wire = _Wire(qtTextureMethodResize, result);
    return (width: wire.integer('width'), height: wire.integer('height'));
  }

  /// setRotation：设置四分之一圈旋转，返回 native 确认后的值。
  Future<int> setRotation(int textureId, int quarterTurns) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodSetRotation,
      <String, Object?>{'textureId': textureId, 'quarterTurns': quarterTurns},
    );
    return _Wire(
      qtTextureMethodSetRotation,
      result,
    ).integer('rotationQuarterTurns');
  }

  /// status：取完整快照（真实状态只能来自 native）。
  Future<QtTextureInfo> status(int textureId) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodStatus,
      <String, Object?>{'textureId': textureId},
    );
    final _Wire wire = _Wire(qtTextureMethodStatus, result);
    final ({QtTextureState state, String raw}) status = wire.state('status');
    return QtTextureInfo(
      state: status.state,
      textureId: wire.integer('textureId'),
      sequence: wire.integer('frameSequence'),
      firstFrameRendered: wire.boolean('firstFrameRendered'),
      width: wire.integer('width'),
      height: wire.integer('height'),
      rotationQuarterTurns: wire.integer('rotationQuarterTurns'),
      backend: wire.backend('backend'),
      lastError: wire.text('lastError', allowNull: true),
      publishTimestampNanos: wire.integer('publishTimestampNanos'),
      rawStatus: status.raw,
    );
  }

  /// dispose：释放纹理；只有 native 回 released: true 才算释放成功。
  Future<bool> dispose(int textureId) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodDispose,
      <String, Object?>{'textureId': textureId},
    );
    return _Wire(qtTextureMethodDispose, result).boolean('released');
  }

  /// sendPointer：把指针事件转发给 Qt 离屏窗口。
  ///
  /// [buttons] 沿用 Android MotionEvent 的按钮位掩码，由调用方按原始事件传，Dart 侧不猜测。
  Future<bool> sendPointer(
    int textureId,
    double x,
    double y, {
    required QtPointerPhase phase,
    int buttons = 0,
  }) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodSendPointer,
      <String, Object?>{
        'textureId': textureId,
        'x': x,
        'y': y,
        'phase': phase.wire,
        'buttons': buttons,
      },
    );
    return _Wire(qtTextureMethodSendPointer, result).boolean('accepted');
  }

  /// sendKey：把按键事件转发给 Qt 离屏窗口。
  ///
  /// [key] 是 Android keyCode（Qt 侧的映射由 Kotlin/native 完成，Dart 不做翻译）。
  Future<bool> sendKey(
    int textureId,
    int key, {
    required bool down,
    bool repeat = false,
  }) async {
    final Map<Object?, Object?> result = await _invoke(
      qtTextureMethodSendKey,
      <String, Object?>{
        'textureId': textureId,
        'key': key,
        'down': down,
        'repeat': repeat,
      },
    );
    return _Wire(qtTextureMethodSendKey, result).boolean('accepted');
  }

  Future<Map<Object?, Object?>> _invoke(
    String method,
    Map<String, Object?> arguments,
  ) async {
    final Object? result = await _channel.invokeMethod<Object?>(
      method,
      arguments,
    );
    if (result is! Map) {
      throw QtTextureProtocolException(
        method: method,
        key: '<result>',
        expected: 'Map<Object?, Object?>',
        actual: result,
        detail: 'native 必须回 Map；null 或其它类型都属契约违约，不静默兜底',
      );
    }
    return result;
  }
}

/// 对回传 Map 的严格读取器：缺键 / 类型不符 / backend 越界一律抛 [QtTextureProtocolException]。
class _Wire {
  const _Wire(this.method, this.raw);

  final String method;
  final Map<Object?, Object?> raw;

  int integer(String key) {
    final Object? value = raw[key];
    if (value is! int) {
      throw QtTextureProtocolException(
        method: method,
        key: key,
        expected: 'int',
        actual: value,
        detail: raw.containsKey(key) ? null : 'key 缺失',
      );
    }
    return value;
  }

  bool boolean(String key) {
    final Object? value = raw[key];
    if (value is! bool) {
      throw QtTextureProtocolException(
        method: method,
        key: key,
        expected: 'bool',
        actual: value,
        detail: raw.containsKey(key) ? null : 'key 缺失',
      );
    }
    return value;
  }

  /// 读字符串；[allowNull] 时把**显式 null** 归一成空串（仅用于 reason / lastError 这类可空字段）。
  ///
  /// 注意：只放行「键存在且值为 null」。键缺失仍然是契约违约 —— 否则 native 少发字段
  /// 会被伪装成「native 回了空串」，严格校验就白做了。
  String text(String key, {bool allowNull = false}) {
    final Object? value = raw[key];
    if (value == null && allowNull && raw.containsKey(key)) {
      return '';
    }
    if (value is! String) {
      throw QtTextureProtocolException(
        method: method,
        key: key,
        expected: allowNull ? 'String?' : 'String',
        actual: value,
        detail: raw.containsKey(key) ? null : 'key 缺失',
      );
    }
    return value;
  }

  ({QtTextureState state, String raw}) state(String key) {
    final String value = text(key);
    final ({QtTextureState state, String? unknown}) parsed =
        QtTextureState.parse(value);
    return (state: parsed.state, raw: value);
  }

  QtTextureBackend backend(String key) {
    final String value = text(key);
    final QtTextureBackend? parsed = QtTextureBackend.tryParse(value);
    if (parsed == null) {
      throw QtTextureProtocolException(
        method: method,
        key: key,
        expected: 'opengl|vulkan|none',
        actual: value,
        detail: 'backend 只有三种冻结取值；未知值不映射为 none（不静默兜底）',
      );
    }
    return parsed;
  }
}

/// 用 Flutter 原生 [Texture] 合成 native 离屏渲染结果的显示组件。
///
/// 行为约定（刻意的“无隐式副作用”）：
///   * 不在 initState / didChangeDependencies 里 create、probe、轮询或插帧；
///     状态由调用方驱动后通过 [info]（native 的 status 快照）与 [textureId] 传入。
///   * 只有 info.state == ready 且 info.textureId == textureId 时才真正挂 [Texture]；
///     其余情况一律显示带 status / reason 的占位块 —— 不铺静态图、不假造像素。
///   * 像素旋转由 native（setRotation）负责，本组件只用 [rotationQuarterTurns] 决定外框纵横比，
///     绝不叠加 [RotatedBox]，否则会二次旋转。
///   * 组件持有 textureId 的 ownership：卸载时（[disposeOnDetach]）尽力调用 controller.dispose，
///     失败不冒泡（widget 已卸载，无人 await），也不在 Dart 侧伪造 released。
///
/// 典型调用序列（全部由调用方驱动，组件本身不发起任何平台调用）：
///   1. probe()  —— 拿到 state / reason，非 ready 时直接渲染占位；
///   2. create(width: 物理宽, height: 物理高, dpr: dpr)  —— 拿到 textureId；
///   3. render(textureId)  —— 由帧循环/测试逐帧驱动；
///   4. status(textureId)  —— 把快照传给 info，组件据此决定挂 Texture 还是占位；
///   5. 卸载时组件调用 dispose(textureId)（disposeOnDetach = false 时由调用方自己管）。
///
/// 使用注意（都是 Flutter 侧的真实约束，不是本组件的额外发明）：
///   * [Texture] 只合成“Flutter 引擎已注册过的 textureId”；未注册的 id 不会画出任何像素，
///     因此本组件宁可显示占位也不假装 ready。
///   * 占位块含 [Text]，需要祖先 [Directionality]（MaterialApp / WidgetsApp 会提供）；
///     单独 pump 本组件时请自行包一层 Directionality，否则布局期会报缺少 Directionality。
///   * textureId 从 A 换成 B 时，本组件会释放 A（ownership 随参数转移）；只换 info / 尺寸则不会释放。
///   * 尺寸变化不会自动 resize：组件只按 width / height / dpr 做布局，缓冲区尺寸必须由调用方
///     显式调用 controller.resize（否则会拿旧尺寸的帧拉伸显示）——这是刻意避免的隐式副作用。
class QtTextureSurface extends StatefulWidget {
  /// 创建组件。
  const QtTextureSurface({
    super.key,
    this.controller,
    this.textureId,
    this.info,
    this.reason,
    this.state,
    this.width = 0,
    this.height = 0,
    this.dpr = 1.0,
    this.rotationQuarterTurns = 0,
    this.disposeOnDetach = true,
    this.placeholderColor = const Color(0x33000000),
  });

  /// 用于卸载时释放纹理；为 null 时组件不碰通道（纯占位）。
  final QtTextureController? controller;

  /// create 返回的 textureId；为 null 时只显示占位。
  final int? textureId;

  /// 最近一次 native status 快照（调用方驱动 status/create 后传入）；null 表示未知，绝不推断成 ready。
  final QtTextureInfo? info;

  /// 占位块上额外展示的原因（例如 probe.reason）；优先级高于 info.lastError。
  final String? reason;

  /// 调用方声明的状态（例如 probe.state）：仅用于占位块把状态显示出来。
  ///
  /// 这是**显示用的声明**，不参与 ready 判定 —— ready 只认 [info] 里 native 的
  /// status 快照（见 [build]）。为 null 且 [info] 也为 null 时占位显示 unknown。
  final QtTextureState? state;

  /// buffer 宽度（物理像素，与 create 的 width 同口径）。
  ///
  /// 取值优先级：本参数（> 0 时）> [info] 里 native 报的 width > 交给父约束。
  /// 与 [height] 都拿不到时组件不包 [SizedBox]，直接铺满父约束
  /// （避免默认 0×0 把占位块压成不可见）。
  final int width;

  /// buffer 高度（物理像素，与 create 的 height 同口径）；优先级同 [width]。
  final int height;

  /// 设备像素比，用于把物理像素换算成逻辑尺寸布局。
  final double dpr;

  /// 四分之一圈旋转（0..3）；仅影响占位/外框纵横比，像素旋转在 native。
  final int rotationQuarterTurns;

  /// 卸载时是否调用 [QtTextureController.dispose]。
  final bool disposeOnDetach;

  /// 占位块背景色（默认半透明黑，不含任何伪造画面）。
  final Color placeholderColor;

  @override
  State<QtTextureSurface> createState() => _QtTextureSurfaceState();
}

class _QtTextureSurfaceState extends State<QtTextureSurface> {
  /// dpr 的卫生下限：dpr <= 0 属调用方错误，这里只避免除零 / NaN 布局。
  double get _dpr => widget.dpr > 0 ? widget.dpr : 1.0;

  /// 逻辑外框：奇数个 quarter turn 时交换宽高（缓冲已由 native 旋转，外框要跟着换）。
  ///
  /// 旋转值先归一化到 0..3（Dart 的 % 对正除数恒返回非负余数），这样越界输入
  /// 也不会让纵横比算错；像素旋转仍完全由 native 负责。
  ///
  /// 用的是「这次真的该显示的缓冲尺寸」：显式 width / height（> 0）优先，
  /// 否则退回 [QtTextureInfo] 里 native 报的尺寸（resize 之后外框才不过期），
  /// 两者都拿不到才交给父约束 —— 绝不拿旧尺寸硬撑。
  ({double width, double height})? get _layoutExtent {
    final int bufferWidth =
        widget.width > 0 ? widget.width : (widget.info?.width ?? 0);
    final int bufferHeight =
        widget.height > 0 ? widget.height : (widget.info?.height ?? 0);
    if (bufferWidth <= 0 || bufferHeight <= 0) {
      return null;
    }
    final double logicalWidth = bufferWidth / _dpr;
    final double logicalHeight = bufferHeight / _dpr;
    if ((widget.rotationQuarterTurns % 4).isOdd) {
      return (width: logicalHeight, height: logicalWidth);
    }
    return (width: logicalWidth, height: logicalHeight);
  }

  @override
  void didUpdateWidget(QtTextureSurface oldWidget) {
    super.didUpdateWidget(oldWidget);
    // textureId 被换成新纹理时，旧纹理的 ownership 仍在本组件手里：这里释放旧的，
    // 否则每次重建都会漏一个 SurfaceTexture。相同 id 的重建（只换 info / 尺寸）不释放。
    final int? previousId = oldWidget.textureId;
    if (previousId != null &&
        previousId != widget.textureId &&
        oldWidget.disposeOnDetach) {
      // 只用旧 widget 的 controller：新 controller 从未拥有过 previousId，
      // 借它释放可能误伤别人持有的纹理，也违反「controller 为 null 时不碰通道」。
      _detachTexture(oldWidget.controller, previousId);
    }
  }

  @override
  void dispose() {
    if (widget.disposeOnDetach) {
      _detachTexture(widget.controller, widget.textureId);
    }
    super.dispose();
  }

  /// 尽力而为地释放一个 textureId：widget 即将卸载 / 纹理已换掉，没有人 await 这个
  /// Future，失败只由 native 侧记录。Dart 侧绝不伪造 released，也不把异常抛进 framework。
  void _detachTexture(QtTextureController? controller, int? textureId) {
    if (controller == null || textureId == null) {
      return;
    }
    unawaited(
      controller.dispose(textureId).then<void>(
        (bool released) {
          // released 是 native 的结论，这里不改变任何 Dart 侧状态。
        },
        onError: (Object error, StackTrace stackTrace) {
          // 释放失败不冒泡（没有调用方在等这个 Future），但必须留下可诊断的痕迹：
          // 静默会让「native 真的没释放」永远查不到。
          debugPrint('QtTexture dispose($textureId) 失败: $error');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final QtTextureInfo? info = widget.info;
    final int? textureId = widget.textureId;
    final ({double width, double height})? extent = _layoutExtent;

    if (info != null &&
        textureId != null &&
        info.state == QtTextureState.ready &&
        info.textureId == textureId) {
      // 真用 Flutter Texture 合成：像素由 native 提供，这里不做任何替代绘制。
      // 注意这里不带 placeholder key：只有占位路径才有那个 key。
      final Widget surface = Texture(textureId: textureId);
      if (extent == null) {
        return surface;
      }
      return SizedBox(
        width: extent.width,
        height: extent.height,
        child: surface,
      );
    }
    final Widget placeholder = _buildPlaceholder(info, textureId);
    if (extent == null) {
      return placeholder;
    }
    return SizedBox(
      width: extent.width,
      height: extent.height,
      child: placeholder,
    );
  }

  Widget _buildPlaceholder(QtTextureInfo? info, int? textureId) {
    // status 的取值来源优先级：native 的 status 快照（权威） > 调用方声明的 state > unknown。
    // 两者都没有时绝不写成 ready —— 宁可 unknown。
    final String statusLabel =
        info?.rawStatus ?? widget.state?.wire ?? 'unknown';

    String reasonLabel;
    if (widget.reason != null && widget.reason!.isNotEmpty) {
      reasonLabel = widget.reason!;
    } else if (info != null &&
        info.state == QtTextureState.ready &&
        info.textureId != textureId) {
      reasonLabel =
          'status 报告 textureId=${info.textureId}，组件持有 '
          'textureId=${textureId ?? 'null'}；不一致时不合成，避免错帧';
    } else if (info != null && info.lastError.isNotEmpty) {
      reasonLabel = info.lastError;
    } else if (info == null && widget.state != null) {
      reasonLabel = '调用方声明 state=${widget.state!.wire}；'
          '未提供 native status 快照（Dart 侧不推断为 ready）';
    } else if (info == null) {
      reasonLabel = '未提供 QtTextureInfo：Dart 侧不推断状态（不假造 ready）';
    } else {
      reasonLabel = 'native 未给出 lastError';
    }

    return ColoredBox(
      // 占位块的稳定标识：测试与外部探针靠它确认「现在画的是占位而不是 Texture」。
      key: const Key('qt-texture-placeholder'),
      color: widget.placeholderColor,
      child: ClipRect(
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    'Qt texture 未就绪',
                    style: TextStyle(fontSize: 12, color: Color(0xFFFFFFFF)),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'status: $statusLabel',
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFFB0B0B0),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'reason: $reasonLabel',
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFFB0B0B0),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
