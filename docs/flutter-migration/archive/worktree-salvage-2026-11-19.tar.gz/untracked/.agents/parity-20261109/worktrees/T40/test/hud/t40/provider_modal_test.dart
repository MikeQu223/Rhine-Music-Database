// Written but NOT executed. This writer task forbids running flutter/dart test,
// analyze, build, gradle, pub get and the formatter, so RED and GREEN are both
// UNRECORDED: this file has never been compiled or executed.
//
// Intended command (never run):
//   flutter test test/hud/t40/provider_modal_test.dart
//
// Every expected number below is copied from, or computed with exactly the same
// arithmetic as, the Qt source cited next to it (Qt/src/NativeHudModal.cpp,
// Qt/src/NativeHud.cpp, Qt/src/UiMotion.h/.cpp, Qt/src/NativeHudController.cpp,
// Qt/src/Glyphs.cpp). Nothing is read back from the Dart implementation; where a
// value is re-derived instead of hardcoded, the comment says so and the two
// expressions are operation-for-operation identical so double equality holds.
//
// The measurable text is injected (Qt Glyphs::width, Qt/src/Glyphs.cpp:286-311);
// the port must never hardcode a glyph width, so the fixtures below decide every
// fit/wrap outcome and the tests name which fixture produced which row count.

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/provider_modal.dart';

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// One UTF-16 code unit measures size, tracking adds tracking per unit. With
/// size 14 and the Qt wrap limit cardWidth - 32 = 189.2 this yields 13 units per
/// detail row, which is what the row-count expectations below are computed from.
double _measure(String text, double size, String? weight, double tracking) =>
    text.length * size + tracking * text.length;

/// Half-width fixture: 27 units per detail row.
double _halfMeasure(String text, double size, String? weight, double tracking) =>
    text.length * size * 0.5 + tracking * text.length;

/// Inflated fixture: 6 units per detail row, used to prove the 3-row cap
/// (Qt/src/NativeHudModal.cpp:278).
double _inflated(String text, double size, String? weight, double tracking) =>
    text.length * size * 2;

/// Identity placement seam: Qt has no portrait transform here, so this is the
/// default and every number stays a raw 1920x1080 design-stage pixel.
List<double> _identity(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

/// Proves every rect and text origin travels through the injected hook once.
List<double> _shift(double x, double y, double w, double h) =>
    <double>[x + 100, y + 50, w * 2, h];

// Qt/src/NativeHud.cpp:10-15.
const List<Object?> _darkInk = <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite'];
const List<Object?> _lightInk = <Object?>[0.08, 0.085, 0.075, 1.0, 'calibratedRGB'];

// Qt/src/NativeHudModal.cpp:171-172.
const List<Object?> _darkPanel = <Object?>[0.15, 0.15, 0.15, 1.0, 'calibratedWhite'];
const List<Object?> _lightPanel = <Object?>[0.929, 0.922, 0.894, 1.0];

// Qt/src/NativeHud.cpp:116.
const List<Object?> _darkButtonTint = <Object?>[0.55, 0.59, 0.46, 0.13];
const List<Object?> _lightButtonTint = <Object?>[0.44, 0.49, 0.36, 0.1];

// Qt/src/NativeHudModal.cpp:267-268 card tint, unselected and selected.
const List<Object?> _darkCardIdle = <Object?>[0.55, 0.59, 0.46, 0.12];
const List<Object?> _darkCardActive = <Object?>[0.55, 0.59, 0.46, 0.3];
const List<Object?> _lightCardIdle = <Object?>[0.44, 0.49, 0.36, 0.09];
const List<Object?> _lightCardActive = <Object?>[0.44, 0.49, 0.36, 0.23];

// Qt/src/NativeHudModal.cpp:272 selected stripe.
const List<Object?> _darkStripe = <Object?>[0.7, 0.75, 0.53, 1.0];
const List<Object?> _lightStripe = <Object?>[0.44, 0.49, 0.36, 1.0];

// ---------------------------------------------------------------------------
// Geometry helpers (Qt/src/NativeHud.cpp:153,157,158 and
// Qt/src/NativeHudModal.cpp:260-261, :294) - re-derived, not read back.
// ---------------------------------------------------------------------------

const double _stage = 1920.0;
const double _modalMaxWidth = 1260.0;
const double _modalTop = 122.0;
const double _modalHeight = 836.0;

/// modalWidth = min(1260, width - 100) (Qt/src/NativeHud.cpp:153).
double _usable(double width) => 1260.0 < width - 100.0 ? 1260.0 : width - 100.0;

/// left = (width - modalWidth) / 2 (Qt/src/NativeHud.cpp:157).
double _panelX(double width) => (width - _usable(width)) / 2.0;

/// The provider panel body always starts at panel x + 53
/// (Qt/src/NativeHudModal.cpp:293-304).
double _contentX(double width) => _panelX(width) + 53.0;

/// width - 106 (Qt/src/NativeHudModal.cpp:294).
double _contentWidth(double width) => _usable(width) - 106.0;

/// (width - gap * (n - 1)) / n (Qt/src/NativeHudModal.cpp:260-261).
double _cardWidth(double contentWidth, int n) =>
    (contentWidth - 12.0 * (n - 1)) / n;

/// x + index * (cardWidth + gap) (Qt/src/NativeHudModal.cpp:264).
double _cardLeft(double contentX, double contentWidth, int index, int n) =>
    contentX + index * (_cardWidth(contentWidth, n) + 12.0);

/// The five Qt table rows (Qt/src/NativeHudModal.cpp:12-18) in draw order.
const List<String> _ids = <String>['siren', 'netease', 'qq', 'kugou', 'local'];
const List<String> _names = <String>[
  '塞壬唱片',
  '网易云音乐',
  'QQ 音乐',
  '酷狗音乐',
  '本地音乐',
];
const List<String> _labels = <String>[
  'MONSTER SIREN',
  'NETEASE',
  'QQ MUSIC',
  'KUGOU',
  'LOCAL',
];
const List<String> _details = <String>[
  '官网曲库',
  '搜索 · 个人音乐 · 推荐 · 播放 · 歌单编辑',
  '全类搜索 · 每日推荐 · 个人音乐 · 歌单编辑',
  '标准版 / 概念版 · 个人歌单 · 推荐与榜单 · 播放',
  '文件夹管理 · 导入与索引 · 本地检索 · 播放',
];

/// Row count per card under [_measure] at limit 189.2 and size 14: 13 units fit
/// per row, and the wrap breaks before an overflowing unit
/// (Qt/src/Glyphs.cpp:381-398). Detail code-unit counts are 4, 26, 25, 29, 25.
const List<int> _rowsAtMeasure = <int>[1, 2, 2, 3, 2];

ProviderModal _modal({
  double width = 1920.0,
  bool dark = true,
  bool reduced = false,
  bool closing = false,
  bool search = false,
  double opacity = 1.0,
  double offset = 0.0,
  String provider = 'netease',
  ProviderModalMeasureText? measure,
  bool isLocal = false,
  bool isSiren = false,
  String providerName = '网易云音乐',
  Set<String> credentials = const <String>{},
  bool platformFeaturesLocalMusic = true,
  bool cardExpanded = true,
  ProviderModalWrapText? wrapText,
  ProviderModalRectHook? rectHook,
}) =>
    ProviderModal(
      width: width,
      dark: dark,
      reduced: reduced,
      closing: closing,
      search: search,
      opacity: opacity,
      offset: offset,
      provider: provider,
      measureText: measure ?? _measure,
      isLocal: isLocal,
      isSiren: isSiren,
      providerName: providerName,
      credentials: credentials,
      platformFeaturesLocalMusic: platformFeaturesLocalMusic,
      cardExpanded: cardExpanded,
      wrapText: wrapText,
      rectHook: rectHook,
    );

// ---------------------------------------------------------------------------
// Command-list helpers
// ---------------------------------------------------------------------------

List<List<Object?>> _withOp(ProviderModalFrame frame, String op) =>
    frame.commands.where((List<Object?> c) => c[0] == op).toList();

List<List<Object?>> _fills(ProviderModalFrame frame) =>
    _withOp(frame, 'fill');

List<List<Object?>> _texts(ProviderModalFrame frame) =>
    _withOp(frame, 'text');

/// The first text command whose value is [value].
List<Object?> _textValue(ProviderModalFrame frame, String value) =>
    frame.commands.firstWhere(
      (List<Object?> c) => c[0] == 'text' && c[1] == value,
      orElse: () => throw StateError('no text command for ' + value),
    );

bool _hasText(ProviderModalFrame frame, String value) =>
    frame.commands.any((List<Object?> c) => c[0] == 'text' && c[1] == value);

/// Every text command with this value (card names and notes are unique here).
List<List<Object?>> _allTextValue(ProviderModalFrame frame, String value) =>
    frame.commands
        .where((List<Object?> c) => c[0] == 'text' && c[1] == value)
        .toList();

/// The fill commands whose rect is exactly [x, y, w, h]; used to assert what is
/// painted at a Qt coordinate without depending on command indices.
List<List<Object?>> _fillsAt(
        ProviderModalFrame frame, double x, double y, double w, double h) =>
    frame.commands
        .where((List<Object?> c) =>
            c[0] == 'fill' &&
            c[2] == x &&
            c[3] == y &&
            c[4] == w &&
            c[5] == h)
        .toList();

List<Object?> _hitFor(ProviderModalFrame frame, String action) =>
    frame.hits.firstWhere(
      (List<Object?> h) => h[4] == action,
      orElse: () => throw StateError('no hit for ' + action),
    );

bool _hasHit(ProviderModalFrame frame, String action) =>
    frame.hits.any((List<Object?> h) => h[4] == action);

/// Deep value comparison for the colour lists: every primitive builds a fresh
/// list per command, so they are never identical by reference.
bool _colorEq(Object? actual, List<Object?> expected) {
  if (actual is! List) {
    return false;
  }
  if (actual.length != expected.length) {
    return false;
  }
  for (int i = 0; i < expected.length; i++) {
    if (actual[i] != expected[i]) {
      return false;
    }
  }
  return true;
}

void main() {
  // -------------------------------------------------------------------------
  group('provider modal: generic full-modal envelope', () {
    test('draw order is save, alpha, scrim, translate, panel ... restore '
        '(NativeHudModal.cpp:83-84, :162-174, :255-256)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(frame.commands.first, <Object?>['save']);
      expect(frame.commands[1], <Object?>['alpha', 1.0]);
      expect(frame.commands[2][0], 'fill');
      expect(frame.commands[3], <Object?>['translate', 0.0, 0.0]);
      expect(frame.commands[4][0], 'fill');
      expect(frame.commands.last, <Object?>['restore']);
      // One save/restore scope for the whole modal.
      expect(_withOp(frame, 'save').length, 1);
      expect(_withOp(frame, 'restore').length, 1);
    });

    test('scrim covers the whole 1920x1080 stage and precedes the offset '
        'translate (NativeHudModal.cpp:163-166)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(frame.commands[2], <Object?>[
        'fill',
        <Object?>[17.0 / 255.0, 24.0 / 255.0, 27.0 / 255.0, 0.6],
        0.0,
        0.0,
        1920.0,
        1080.0,
      ]);
      // The scrim must not travel with the panel.
      final int scrim = frame.commands
          .indexWhere((List<Object?> c) => c[0] == 'fill' && c[3] == 0.0);
      final int translate =
          frame.commands.indexWhere((List<Object?> c) => c[0] == 'translate');
      expect(scrim, lessThan(translate));
    });

    test('light theme scrim alpha is 0.45 (NativeHudModal.cpp:163-165)', () {
      final ProviderModalFrame frame = _modal(dark: false).build();
      expect(frame.commands[2], <Object?>[
        'fill',
        <Object?>[227.0 / 255.0, 224.0 / 255.0, 215.0 / 255.0, 0.45],
        0.0,
        0.0,
        1920.0,
        1080.0,
      ]);
    });

    test('injected search flag switches the scrim alpha to 0.15 / 0.12 '
        '(NativeHudModal.cpp:164-165; the provider branch never sets it, the '
        'flag is host-injected)', () {
      final ProviderModalFrame darkFrame = _modal(search: true).build();
      expect(darkFrame.commands[2][1], <Object?>[
        17.0 / 255.0,
        24.0 / 255.0,
        27.0 / 255.0,
        0.15,
      ]);
      final ProviderModalFrame lightFrame =
          _modal(search: true, dark: false).build();
      expect(lightFrame.commands[2][1], <Object?>[
        227.0 / 255.0,
        224.0 / 255.0,
        215.0 / 255.0,
        0.12,
      ]);
    });

    test('panel: min(1260, width-100) wide, centred, top 122, height 836 '
        '(NativeHud.cpp:153-158, NativeHudModal.cpp:171-172)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(frame.commands[4],
          <Object?>['fill', _darkPanel, 330.0, 122.0, 1260.0, 836.0]);
    });

    test('narrow stage 1200: modalWidth 1100 at left 50, body at x 103 with '
        'content width 994 (NativeHud.cpp:153-158, NativeHudModal.cpp:294)', () {
      final ProviderModalFrame frame = _modal(width: 1200.0).build();
      expect(frame.commands[4],
          <Object?>['fill', _darkPanel, 50.0, 122.0, 1100.0, 836.0]);
      expect(_usable(1200.0), 1100.0);
      expect(_contentX(1200.0), 103.0);
      expect(_contentWidth(1200.0), 994.0);
      expect(_textValue(frame, ProviderModal.category)[2], 103.0);
    });

    test('wide stage 1600 clamps the modal to 1260 at left 170 '
        '(NativeHud.cpp:153)', () {
      final ProviderModalFrame frame = _modal(width: 1600.0).build();
      expect(frame.commands[4],
          <Object?>['fill', _darkPanel, 170.0, 122.0, 1260.0, 836.0]);
      expect(_contentX(1600.0), 223.0);
    });

    test('opacity and offset are injected, never recomputed '
        '(NativeHudModal.cpp:84, :166)', () {
      final ProviderModalFrame frame =
          _modal(opacity: 0.42, offset: 18.0).build();
      expect(frame.commands[1], <Object?>['alpha', 0.42]);
      expect(frame.commands[3], <Object?>['translate', 0.0, 18.0]);
    });

    test('light theme ink, panel and button tint (NativeHud.cpp:10-15, :116, '
        'NativeHudModal.cpp:171-172)', () {
      final ProviderModalFrame frame = _modal(dark: false).build();
      expect(frame.commands[4], <Object?>['fill', _lightPanel, 330.0, 122.0, 1260.0, 836.0]);
      expect(_textValue(frame, ProviderModal.category)[7], _lightInk);
      expect(_fillsAt(frame, 1370.0, 140.0, 167.0, 54.0).single[1],
          _lightButtonTint);
      expect(_fillsAt(frame, 383.0, 782.0, 330.0, 48.0).single[1],
          _lightButtonTint);
    });

    test('every command is one of the Qt op shapes '
        '(NativeHud.cpp:19-43, :102-129)', () {
      const Set<String> ops = <String>{
        'save',
        'restore',
        'alpha',
        'translate',
        'scale',
        'clip',
        'fill',
        'text',
        'image',
        'art',
      };
      for (final List<Object?> command in _modal().build().commands) {
        expect(ops.contains(command[0]), isTrue,
            reason: 'unexpected op ' + command[0].toString());
      }
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: shared header (NativeHudModal.cpp:188, :198-202)', () {
    test('category line keeps the MUSIC DIRECTORY default at x+53, y+37, 11', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_textValue(frame, 'RHINE LAB / MUSIC DATABASE / MUSIC DIRECTORY'),
          <Object?>[
        'text',
        'RHINE LAB / MUSIC DATABASE / MUSIC DIRECTORY',
        383.0, // x + 53
        159.0, // y + 37
        11.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      // provider is not one of the four special header branches (:188-202).
      expect(ProviderModal.category, 'MUSIC DIRECTORY');
    });

    test('back button: x+usable-220, y+18, 167x54, close-modal, 20, demibold '
        '(NativeHudModal.cpp:199-200)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_hitFor(frame, 'close-modal'),
          <Object?>[1370.0, 140.0, 167.0, 54.0, 'close-modal', '← 返回']);
      expect(_fillsAt(frame, 1370.0, 140.0, 167.0, 54.0).single,
          <Object?>['fill', _darkButtonTint, 1370.0, 140.0, 167.0, 54.0]);
      // inset = min(10, 167 / 8) = 10; text y = y + (54 - 20) / 2 - 4 = 153.
      expect(_textValue(frame, '← 返回'), <Object?>[
        'text',
        '← 返回',
        1380.0,
        153.0,
        20.0,
        'demibold',
        0.0,
        _darkInk,
      ]);
    });

    test('title MUSIC PLATFORM at 38 demibold and subtitle at 15 '
        '(NativeHudModal.cpp:27, :53, :201-202)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_textValue(frame, 'MUSIC PLATFORM'), <Object?>[
        'text',
        'MUSIC PLATFORM',
        383.0,
        213.0, // y + 91
        38.0,
        'demibold',
        0.0,
        _darkInk,
      ]);
      expect(ProviderModal.title, 'MUSIC PLATFORM');
      expect(ProviderModal.subtitle, '直接选择音乐平台 / 各平台账号独立保存');
      expect(_textValue(frame, ProviderModal.subtitle), <Object?>[
        'text',
        ProviderModal.subtitle,
        383.0,
        269.0, // y + 147
        15.0,
        'regular',
        0.0,
        _darkInk,
      ]);
    });

    test('narrow stage header: back button shifts with usable, title x stays '
        'x + 53 (NativeHudModal.cpp:199)', () {
      final ProviderModalFrame frame = _modal(width: 1200.0).build();
      // x + usable - 220 = 50 + 1100 - 220 = 930.
      expect(_hitFor(frame, 'close-modal')[0],
          _panelX(1200.0) + _usable(1200.0) - 220.0);
      expect(_hitFor(frame, 'close-modal')[0], 930.0);
      expect(_textValue(frame, 'MUSIC PLATFORM')[2], 103.0);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: PROVIDER ACCESS section '
      '(NativeHudModal.cpp:292-306)', () {
    test('section heading at x+53, y+222, 13, demibold', () {
      final ProviderModalFrame frame = _modal().build();
      expect(ProviderModal.bodyTitle, 'PROVIDER ACCESS / 音乐平台');
      expect(_textValue(frame, ProviderModal.bodyTitle), <Object?>[
        'text',
        ProviderModal.bodyTitle,
        383.0,
        344.0, // y + 222
        13.0,
        'demibold',
        0.0,
        _darkInk,
      ]);
    });

    test('rule at x+53, y+490, width-106, opacity 0.2, one pixel tall '
        '(NativeHudModal.cpp:295, NativeHud.cpp:125-129)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_fillsAt(frame, 383.0, 612.0, 1154.0, 1.0).single,
          <Object?>[
        'fill',
        <Object?>[0.92, 0.92, 0.92, 0.2, 'calibratedWhite'],
        383.0,
        612.0,
        1154.0,
        1.0,
      ]);
    });

    test('three explanation lines at y+520 / y+558 / y+590, size 15 '
        '(NativeHudModal.cpp:296-298)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_textValue(frame, ProviderModal.hint1), <Object?>[
        'text',
        ProviderModal.hint1,
        383.0,
        642.0,
        15.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(_textValue(frame, ProviderModal.hint2), <Object?>[
        'text',
        ProviderModal.hint2,
        383.0,
        680.0,
        15.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(_textValue(frame, ProviderModal.hint3), <Object?>[
        'text',
        ProviderModal.hint3,
        383.0,
        712.0,
        15.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(ProviderModal.hint1, '切换平台会停止当前播放，各平台账号与个人音乐独立保存。');
      expect(ProviderModal.hint2, '网易云与 QQ 支持歌单编辑；酷狗支持读取与播放。');
      expect(ProviderModal.hint3, '塞壬唱片');
    });

    test('section order is heading, cards, rule, hints, action row '
        '(NativeHudModal.cpp:293-304)', () {
      final ProviderModalFrame frame = _modal().build();
      final int heading =
          frame.commands.indexWhere((List<Object?> c) => c[1] == ProviderModal.bodyTitle);
      final int firstHitCard = frame.hits.indexWhere(
          (List<Object?> h) => (h[4] as String).startsWith('provider:'));
      final int rule =
          frame.commands.indexWhere((List<Object?> c) => c[0] == 'fill' && c[3] == 612.0);
      final int hint1 =
          frame.commands.indexWhere((List<Object?> c) => c[1] == ProviderModal.hint1);
      final int action =
          frame.commands.indexWhere((List<Object?> c) => c[0] == 'text' && c[3] == 794.0);
      expect(heading, lessThan(firstHitCard));
      expect(heading, lessThan(rule));
      expect(rule, lessThan(hint1));
      expect(hint1, lessThan(action));
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: platform cards (NativeHudModal.cpp:259-291)', () {
    test('five cards, gap 12, cardWidth = (width - gap*(n-1))/n, left = '
        'x + i*(cardWidth+gap) (NativeHudModal.cpp:260-264)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double contentWidth = _contentWidth(1920.0);
      final double cw = _cardWidth(contentWidth, 5);
      expect(contentX, 383.0);
      expect(contentWidth, 1154.0);
      expect(cw, 221.2);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, contentWidth, i, 5);
        expect(left, closeTo(383.0 + i * 233.2, 1e-9));
        expect(_fillsAt(frame, left, 380.0, cw, 190.0).length, 1,
            reason: 'card ' + _ids[i] + ' tint fill');
        expect(_fillsAt(frame, left, 380.0, cw, 190.0).single[1],
            i == 1 ? _darkCardActive : _darkCardIdle,
            reason: 'selected is provider == card id (:265-268)');
      }
    });

    test('card height is 190 when expanded (NativeHudModal.cpp:266)', () {
      final ProviderModalFrame frame = _modal().build();
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      // No compact 66-high card exists in the expanded panel.
      expect(_fills(frame).where((List<Object?> c) => c[5] == 66.0).length, 0);
      expect(_fillsAt(frame, 383.0, 380.0, cw, 190.0).length, 1);
      expect(ProviderModal.cardExpandedHeight, 190.0);
      expect(ProviderModal.cardCompactHeight, 66.0);
      expect(ProviderModal.cardGap, 12.0);
    });

    test('selected card gets the 3 pixel left stripe in the Qt colours '
        '(NativeHudModal.cpp:271-273)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      final double left = _cardLeft(contentX, _contentWidth(1920.0), 1, 5);
      expect(_fillsAt(frame, left, 380.0, 3.0, 190.0).single,
          <Object?>['fill', _darkStripe, left, 380.0, 3.0, 190.0]);
      // Exactly one stripe: only the selected card paints one.
      expect(
          _fills(frame)
              .where((List<Object?> c) => c[4] == 3.0 && c[5] == 190.0)
              .length,
          1);
    });

    test('light theme card tints and stripe (NativeHudModal.cpp:267-273)', () {
      final ProviderModalFrame frame = _modal(dark: false).build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        expect(_fillsAt(frame, left, 380.0, cw, 190.0).single[1],
            i == 1 ? _lightCardActive : _lightCardIdle);
      }
      expect(
          _fillsAt(frame, _cardLeft(contentX, _contentWidth(1920.0), 1, 5),
                  380.0, 3.0, 190.0)
              .single[1],
          _lightStripe);
    });

    test('caption at left+16, y+10, size 10, default weight, with the ACTIVE '
        'suffix only on the selected card (NativeHudModal.cpp:274)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        final String expected =
            _labels[i] + (i == 1 ? ProviderModal.activeSuffix : '');
        expect(_textValue(frame, expected), <Object?>[
          'text',
          expected,
          left + 16.0,
          390.0, // y + 10
          10.0,
          'regular',
          0.0,
          _darkInk,
        ]);
      }
      expect(ProviderModal.activeSuffix, ' / ACTIVE');
      // No bare NETEASE caption survives next to the ACTIVE one.
      expect(_hasText(frame, 'NETEASE'), isFalse);
    });

    test('name at left+16, y+29, size 22 demibold when expanded '
        '(NativeHudModal.cpp:275)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        expect(_textValue(frame, _names[i]), <Object?>[
          'text',
          _names[i],
          left + 16.0,
          409.0, // y + 29
          22.0,
          'demibold',
          0.0,
          _darkInk,
        ]);
      }
    });

    test('card hit carries the display name as label, not the caption, and is '
        'emitted after the tint and before the stripe '
        '(NativeHudModal.cpp:269-270)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double contentWidth = _contentWidth(1920.0);
      final double cw = _cardWidth(contentWidth, 5);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, contentWidth, i, 5);
        expect(_hitFor(frame, 'provider:' + _ids[i]),
            <Object?>[left, 380.0, cw, 190.0, 'provider:' + _ids[i], _names[i]]);
        expect(_hitFor(frame, 'provider:' + _ids[i])[5], isNot(_labels[i]));
      }
      // Draw order inside the selected card: tint fill, hit, stripe fill.
      final int tint = frame.commands.indexWhere((List<Object?> c) =>
          c[0] == 'fill' && c[3] == 380.0 && c[5] == 190.0 && c[4] == cw);
      final int stripe = frame.commands.indexWhere((List<Object?> c) =>
          c[0] == 'fill' && c[3] == 380.0 && c[5] == 190.0 && c[4] == 3.0);
      expect(tint, lessThan(stripe));
    });

    test('selected stripe is painted on the selected card only, whatever it is '
        '(NativeHudModal.cpp:265,271)', () {
      for (int selected = 0; selected < 5; selected++) {
        final ProviderModalFrame frame = _modal(provider: _ids[selected]).build();
        final double contentX = _contentX(1920.0);
        final double cw = _cardWidth(_contentWidth(1920.0), 5);
        for (int i = 0; i < 5; i++) {
          final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
          expect(_fillsAt(frame, left, 380.0, 3.0, 190.0).length,
              i == selected ? 1 : 0,
              reason: 'stripe on card ' + _ids[i]);
          expect(_fillsAt(frame, left, 380.0, cw, 190.0).single[1],
              i == selected ? _darkCardActive : _darkCardIdle);
        }
      }
    });

    test('compact mode: height 66, name 17, no wrapped detail and no note '
        '(NativeHudModal.cpp:266,275-289)', () {
      final ProviderModalFrame frame = _modal(cardExpanded: false).build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        expect(_fillsAt(frame, left, 380.0, cw, 66.0).length, 1);
        expect(_textValue(frame, _names[i])[2], left + 16.0);
        expect(_textValue(frame, _names[i])[3], 409.0);
        expect(_textValue(frame, _names[i])[4], 17.0);
      }
      expect(_texts(frame).where((List<Object?> c) => c[4] == 14.0).length, 0);
      for (final String detail in _details) {
        expect(_hasText(frame, detail), isFalse);
      }
      expect(_hasText(frame, '独立本地库 / 无需登录'), isFalse);
      expect(_hasText(frame, '未登录 / 可选择后扫码'), isFalse);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: local row removal '
      '(NativeHudModal.cpp:20-22, :261)', () {
    test('!PlatformFeatures::LocalMusic drops the local card and recomputes '
        'cardWidth for the remaining four', () {
      final ProviderModalFrame frame =
          _modal(platformFeaturesLocalMusic: false).build();
      final double contentWidth = _contentWidth(1920.0);
      final double cw = _cardWidth(contentWidth, 4);
      expect(cw, 279.5); // (1154 - 36) / 4
      for (int i = 0; i < 4; i++) {
        final double left = _cardLeft(_contentX(1920.0), contentWidth, i, 4);
        expect(_fillsAt(frame, left, 380.0, cw, 190.0).length, 1);
        expect(_hitFor(frame, 'provider:' + _ids[i]),
            <Object?>[left, 380.0, cw, 190.0, 'provider:' + _ids[i], _names[i]]);
      }
      // Nothing of the fifth row survives.
      expect(_hasHit(frame, 'provider:local'), isFalse);
      expect(_hasText(frame, '本地音乐'), isFalse);
      expect(_hasText(frame, 'LOCAL'), isFalse);
      expect(_hasText(frame, '文件夹管理 · 导入与索引 · 本地检索 · 播放'), isFalse);
      expect(frame.hits.length, 6); // back button + four cards + login button
    });

    test('the surviving rows keep their Qt order and their own details', () {
      final ProviderModalFrame frame =
          _modal(platformFeaturesLocalMusic: false).build();
      final List<String> hitIds = frame.hits
          .where((List<Object?> h) => (h[4] as String).startsWith('provider:'))
          .map((List<Object?> h) => h[4] as String)
          .toList();
      expect(hitIds,
          <String>['provider:siren', 'provider:netease', 'provider:qq', 'provider:kugou']);
      expect(_hasText(frame, _details[0]), isTrue);
      expect(_hasText(frame, _details[1]), isTrue);
      expect(_hasText(frame, _details[2]), isTrue);
      expect(_hasText(frame, _details[3]), isTrue);
    });

    test('LocalMusic true keeps all five rows '
        '(Qt/src/PlatformFeatures.h:10,15)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(
          frame.hits
              .where((List<Object?> h) =>
                  (h[4] as String).startsWith('provider:'))
              .length,
          5);
      expect(_hasHit(frame, 'provider:local'), isTrue);
      expect(_hasText(frame, '本地音乐'), isTrue);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: expanded card details '
      '(NativeHudModal.cpp:276-280, Glyphs.cpp:350-402)', () {
    test('wrap is called once per card with limit cardWidth - 32, size 14 and '
        'the default regular weight', () {
      final List<String> calls = <String>[];
      List<String> spy(String text, double limit, double size, String weight) {
        calls.add(text + '|' + limit.toString() + '|' + size.toString() + '|' + weight);
        return <String>[text];
      }

      final String expectedLimit =
          (_cardWidth(_contentWidth(1920.0), 5) - 32.0).toString();
      _modal(wrapText: spy).build();
      expect(calls.length, 5);
      for (int i = 0; i < 5; i++) {
        expect(calls[i], _details[i] + '|' + expectedLimit + '|14.0|regular');
      }
      expect(expectedLimit, '189.2');
      expect(ProviderModal.detailHorizontalInset, 32.0);
      expect(ProviderModal.detailRowStride, 21.0);
      expect(ProviderModal.detailMaxRows, 3);
    });

    test('rows sit at left+16, y+75+row*21, size 14 (NativeHudModal.cpp:279)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      final double cw = _cardWidth(_contentWidth(1920.0), 5);
      final int kugou = 3;
      final double left = _cardLeft(contentX, _contentWidth(1920.0), kugou, 5);
      final List<List<Object?>> kugouRows = _texts(frame)
          .where((List<Object?> c) => c[4] == 14.0 && c[2] == left + 16.0)
          .toList();
      expect(kugouRows.length, _rowsAtMeasure[kugou]);
      for (int row = 0; row < kugouRows.length; row++) {
        expect(kugouRows[row][3], 380.0 + 75.0 + row * 21.0);
        expect(kugouRows[row][4], 14.0);
        expect(kugouRows[row][5], 'regular');
        expect(kugouRows[row][6], 0.0);
        expect(kugouRows[row][7], _darkInk);
      }
    });

    test('row counts per card under the injected measure: 1, 2, 2, 3, 2 '
        '(13 code units fit per row at size 14 and limit 189.2)', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(1920.0);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        expect(
            _texts(frame)
                .where((List<Object?> c) => c[4] == 14.0 && c[2] == left + 16.0)
                .length,
            _rowsAtMeasure[i],
            reason: 'rows for ' + _ids[i]);
      }
      expect(_details[0].length, 4);
      expect(_details[1].length, 26);
      expect(_details[2].length, 25);
      expect(_details[3].length, 29);
      expect(_details[4].length, 25);
    });

    test('the painted rows are a prefix of the Qt detail and the third row is '
        'the last one painted (cap of 3, NativeHudModal.cpp:278)', () {
      final ProviderModalFrame frame = _modal(measure: _inflated).build();
      final double contentX = _contentX(1920.0);
      final double left = _cardLeft(contentX, _contentWidth(1920.0), 3, 5);
      final List<List<Object?>> rows = _texts(frame)
          .where((List<Object?> c) => c[4] == 14.0 && c[2] == left + 16.0)
          .toList();
      expect(rows.length, 3);
      expect(_details[3].startsWith(rows[0][1] as String), isTrue);
      expect(_details[3].startsWith(rows[1][1] as String), isTrue);
      expect(rows[0][3], 455.0); // y + 75
      expect(rows[1][3], 476.0); // y + 96
      expect(rows[2][3], 497.0); // y + 117
      // A fourth row would sit at y + 138 and must not exist.
      expect(
          _texts(frame)
              .where((List<Object?> c) => c[4] == 14.0 && c[3] == 518.0)
              .length,
          0);
    });

    test('a narrower measure produces fewer rows, not different rows '
        '(the wrap is injected, not baked in)', () {
      final ProviderModalFrame frame = _modal(measure: _halfMeasure).build();
      final double contentX = _contentX(1920.0);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        final int rows = _texts(frame)
            .where((List<Object?> c) => c[4] == 14.0 && c[2] == left + 16.0)
            .length;
        expect(rows, lessThanOrEqualTo(_rowsAtMeasure[i]),
            reason: 'rows for ' + _ids[i] + ' shrink with a narrower measure');
      }
      // kugou needs 27.03 units per row at 0.5, so 29 units still take 2 rows.
      final double left = _cardLeft(contentX, _contentWidth(1920.0), 3, 5);
      expect(
          _texts(frame)
              .where((List<Object?> c) => c[4] == 14.0 && c[2] == left + 16.0)
              .length,
          2);
    });

    test('the default wrapper is the code-unit port: it breaks before the '
        'overflowing unit and always appends the final line '
        '(Glyphs.cpp:381-398)', () {
      final ProviderModalWrapText wrap = codeUnitWrap(_measure);
      // 13 units at size 14 measure 182 <= 189.2; the 14th would exceed it.
      // 26 units take two rows of 13, the second ending exactly at the limit.
      final List<String> rows =
          wrap('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 189.2, 14.0, 'regular');
      expect(rows.length, 2);
      expect(rows[0].length, 13);
      expect(rows[1].length, 13);
      // A 27th unit cannot join the full second row and opens a third one.
      final List<String> more =
          wrap('ABCDEFGHIJKLMNOPQRSTUVWXYZ0', 189.2, 14.0, 'regular');
      expect(more.length, 3);
      expect(more[0].length, 13);
      expect(more[1].length, 13);
      expect(more[2], '0');
      // A newline is code unit 0x0A and starts a new line.
      expect(wrap('AB' + String.fromCharCode(0x0A) + 'CD', 189.2, 14.0, 'regular'),
          <String>['AB', 'CD']);
      // An empty run is still one (empty) line, like Qt's always-appended line.
      expect(wrap('', 189.2, 14.0, 'regular'), <String>['']);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: per-card status note '
      '(NativeHudModal.cpp:281-288)', () {
    test('local and siren notes win over the credential branch', () {
      final ProviderModal modal = _modal();
      expect(modal.noteFor(ProviderModalCatalog.all[4]),
          '独立本地库 / 无需登录'); // local
      expect(modal.noteFor(ProviderModalCatalog.all[0]),
          '官网曲库 / 无需登录'); // siren
    });

    test('credential branch: 本机已保存登录 when hasCredential(id), otherwise '
        '未登录 / 可选择后扫码', () {
      expect(
          _modal().noteFor(ProviderModalCatalog.all[1]), '未登录 / 可选择后扫码');
      expect(
          _modal(credentials: <String>{'netease'})
              .noteFor(ProviderModalCatalog.all[1]),
          '本机已保存登录');
      expect(
          _modal(credentials: <String>{'qq', 'kugou'})
              .noteFor(ProviderModalCatalog.all[1]),
          '未登录 / 可选择后扫码',
          reason: 'the predicate is per provider id (Host::hasCredential)');
      expect(
          _modal(credentials: <String>{'qq'}).noteFor(ProviderModalCatalog.all[2]),
          '本机已保存登录');
    });

    test('local and siren ignore a stored credential for their own id '
        '(the branch order is fixed at :282-287)', () {
      expect(
          _modal(credentials: <String>{'local'})
              .noteFor(ProviderModalCatalog.all[4]),
          '独立本地库 / 无需登录');
      expect(
          _modal(credentials: <String>{'siren'})
              .noteFor(ProviderModalCatalog.all[0]),
          '官网曲库 / 无需登录');
    });

    test('note is painted through limited at left+16, y+150, size 12, width '
        'cardWidth-32, after the detail rows (NativeHudModal.cpp:288)', () {
      final ProviderModalFrame frame = _modal().build();
      final ProviderModal modal = _modal();
      final double contentX = _contentX(1920.0);
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, _contentWidth(1920.0), i, 5);
        // The note strings repeat across cards, so the card is selected by
        // geometry: size 12 at left + 16 is exactly this card's limited() note.
        final List<List<Object?>> notes = _texts(frame)
            .where((List<Object?> c) => c[4] == 12.0 && c[2] == left + 16.0)
            .toList();
        expect(notes.length, 1, reason: 'one note for ' + _ids[i]);
        final List<Object?> note = notes.single;
        expect(note[1], modal.noteFor(ProviderModalCatalog.all[i]));
        expect(note[3], 530.0); // y + 150
        expect(note[5], 'regular');
        final int noteIndex = frame.commands.indexOf(note);
        final int lastDetail = frame.commands.lastIndexWhere((List<Object?> c) =>
            c[0] == 'text' && c[4] == 14.0 && c[2] == left + 16.0);
        expect(lastDetail, lessThan(noteIndex));
      }
      expect(_textValue(_modal().build(), '未登录 / 可选择后扫码')[4], 12.0);
    });

    test('a wide measure truncates the note through fit, keeping the Qt rule '
        'length - 1 plus an ellipsis (NativeHud.cpp:48-79)', () {
      final ProviderModalFrame frame = _modal(measure: _inflated).build();
      // 12 code units at size 12 measure 288 > 189.2; the longest fitting
      // prefix is 7 units, so Qt keeps 6 (未登录 / ) and appends the ellipsis.
      final List<Object?> note = _textValue(frame, '未登录 / …');
      expect(note[4], 12.0);
      expect(_hasText(frame, '未登录 / 可选择后扫码'), isFalse);
      expect((note[1] as String).endsWith('…'), isTrue);
      expect((note[1] as String).length, 7);
    });

    test('the note line is cardWidth - 32 wide, not the full card width '
        '(NativeHudModal.cpp:288)', () {
      // 16 px per code unit: the 12-unit note measures 192, which overflows the
      // 189.2 note line but would still fit inside the 221.2 card, so a drawn
      // ellipsis proves the -32 inset reached fit().
      double sixteen(String text, double size, String? weight, double tracking) =>
          text.length * 16.0;

      final ProviderModalFrame frame = _modal(measure: sixteen).build();
      final List<Object?> note = _textValue(frame, '未登录 / 可选择后…');
      expect(note[4], 12.0);
      expect((note[1] as String).length, 11);
      expect(sixteen('未登录 / 可选择后扫码', 12.0, 'regular', 0.0), 192.0);
      expect(192.0, lessThan(_cardWidth(_contentWidth(1920.0), 5)));
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: bottom action row '
      '(NativeHudModal.cpp:299-304)', () {
    test('default branch: 账号登录 / providerName button at x+53, y+660, '
        '330x48, music:login, 16', () {
      final ProviderModalFrame frame = _modal().build();
      expect(_hitFor(frame, 'music:login'),
          <Object?>[383.0, 782.0, 330.0, 48.0, 'music:login', '账号登录 / 网易云音乐']);
      expect(_fillsAt(frame, 383.0, 782.0, 330.0, 48.0).single,
          <Object?>['fill', _darkButtonTint, 383.0, 782.0, 330.0, 48.0]);
      // inset = min(10, 330/8) = 10; text y = y + (48 - 16)/2 - 4 = 794.
      expect(_textValue(frame, '账号登录 / 网易云音乐'), <Object?>[
        'text',
        '账号登录 / 网易云音乐',
        393.0,
        794.0,
        16.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(ProviderModal.loginLabelPrefix, '账号登录 / ');
    });

    test('isLocal branch: 文件夹管理 ＋ button with action discover, and no '
        'login button at all (NativeHudModal.cpp:299-300)', () {
      final ProviderModalFrame frame =
          _modal(isLocal: true, provider: 'local', providerName: '本地音乐').build();
      expect(_hitFor(frame, 'discover'),
          <Object?>[383.0, 782.0, 330.0, 48.0, 'discover', '文件夹管理 ＋']);
      expect(_textValue(frame, '文件夹管理 ＋'), <Object?>[
        'text',
        '文件夹管理 ＋',
        393.0,
        794.0,
        16.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(_hasHit(frame, 'music:login'), isFalse);
      expect(_hasText(frame, '账号登录 / 本地音乐'), isFalse);
      expect(_hasText(frame, '塞壬唱片官网曲库'), isFalse);
      expect(ProviderModal.localButtonLabel, '文件夹管理 ＋');
    });

    test('isSiren branch: a plain text line at x+53, y+675, size 15 and no '
        'hit and no button fill (NativeHudModal.cpp:301-302)', () {
      final ProviderModalFrame frame =
          _modal(isSiren: true, provider: 'siren', providerName: '塞壬唱片').build();
      expect(_textValue(frame, '塞壬唱片官网曲库'), <Object?>[
        'text',
        '塞壬唱片官网曲库',
        383.0,
        797.0, // y + 675
        15.0,
        'regular',
        0.0,
        _darkInk,
      ]);
      expect(_fillsAt(frame, 383.0, 782.0, 330.0, 48.0), isEmpty);
      expect(frame.hits.length, 6); // back button + five cards, nothing else
      expect(_hasHit(frame, 'music:login'), isFalse);
      expect(_hasHit(frame, 'discover'), isFalse);
      expect(ProviderModal.sirenLibraryText, '塞壬唱片官网曲库');
    });

    test('isLocal is tested before isSiren, so a local siren provider still '
        'gets the discover button (NativeHudModal.cpp:299-301)', () {
      final ProviderModalFrame frame =
          _modal(isLocal: true, isSiren: true, provider: 'local').build();
      expect(_hasHit(frame, 'discover'), isTrue);
      expect(_hasText(frame, '塞壬唱片官网曲库'), isFalse);
    });

    test('the login label follows the injected MusicLibrary::providerName, '
        'including the kugou lite edition (MusicLibrary.cpp:106-111)', () {
      final ProviderModalFrame frame =
          _modal(provider: 'kugou', providerName: '酷狗概念版').build();
      expect(_hasText(frame, '账号登录 / 酷狗概念版'), isTrue);
      expect(_hasHit(frame, 'music:login')[5], '账号登录 / 酷狗概念版');
      expect(_hasText(frame, '账号登录 / 酷狗音乐'), isFalse);
    });

    test('a wide measure refits the button label to width - inset*2 = 310, '
        'keeping length - 1 plus an ellipsis (NativeHud.cpp:48-76, :110-120)', () {
      final ProviderModalFrame frame = _modal(measure: _inflated).build();
      final List<Object?> text = _textValue(frame, '账号登录 / 网…');
      expect(text[2], 393.0);
      expect(text[4], 16.0);
      expect(_hasText(frame, '账号登录 / 网易云音乐'), isFalse);
      expect((text[1] as String).length, 9);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: hit table contract '
      '(NativeHud.cpp:102-109, NativeHudModal.cpp:173, :270)', () {
    test('hits come in draw order: back button, five cards, bottom action row', () {
      final ProviderModalFrame frame = _modal().build();
      final double contentX = _contentX(_stage);
      final double contentWidth = _contentWidth(_stage);
      final double cw = _cardWidth(contentWidth, 5);
      final List<Object?> expected = <Object?>[
        <Object?>[1370.0, 140.0, 167.0, 54.0, 'close-modal', '← 返回'],
      ];
      for (int i = 0; i < 5; i++) {
        final double left = _cardLeft(contentX, contentWidth, i, 5);
        expected.add(
            <Object?>[left, 380.0, cw, 190.0, 'provider:' + _ids[i], _names[i]]);
      }
      expected.add(<Object?>[
        383.0,
        782.0,
        330.0,
        48.0,
        'music:login',
        '账号登录 / 网易云音乐',
      ]);
      expect(frame.hits, expected);
      expect(frame.hits.length, 7);
    });

    test('every hit is exactly six fields, x, y, width, height, action, label '
        '(NativeHud.cpp:102-109)', () {
      for (final ProviderModalFrame frame in <ProviderModalFrame>[
        _modal().build(),
        _modal(isLocal: true, provider: 'local').build(),
        _modal(isSiren: true, provider: 'siren').build(),
        _modal(dark: false, platformFeaturesLocalMusic: false).build(),
      ]) {
        expect(frame.hits, isNotEmpty);
        for (final List<Object?> hit in frame.hits) {
          expect(hit.length, 6, reason: 'hit ' + hit.toString());
          expect(hit[0], isA<double>());
          expect(hit[1], isA<double>());
          expect(hit[2], isA<double>());
          expect(hit[3], isA<double>());
          expect(hit[4], isA<String>());
          expect(hit[5], isA<String>());
          expect(hit[5], isNotEmpty);
          if ((hit[4] as String).startsWith('provider:')) {
            // Card hits label with the display name, never the caption.
            expect(_labels.contains(hit[5]), isFalse);
          }
        }
      }
    });

    test('the popover outside-catcher is not installed by this modal kind: '
        'nothing outside the panel is hit (NativeHud.cpp:102-109)', () {
      final ProviderModalFrame frame = _modal().build();
      for (final List<Object?> hit in frame.hits) {
        final double x = hit[0] as double;
        final double y = hit[1] as double;
        // Every hit lies inside the centred panel or its header/action row.
        expect(x, greaterThanOrEqualTo(330.0));
        expect(x + (hit[2] as double), lessThanOrEqualTo(330.0 + 1260.0));
        expect(y, greaterThanOrEqualTo(122.0));
        expect(y + (hit[3] as double), lessThanOrEqualTo(122.0 + 836.0));
      }
    });

    test('the full-modal path owns its hits: the frame never reports an empty '
        'hit list while the panel is open (NativeHudModal.cpp:173)', () {
      expect(_modal().build().hits.length, greaterThan(0));
      expect(_modal(closing: true).build().hits.length, greaterThan(0));
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: action strings '
      '(NativeHudController.cpp:508-524, :913-943)', () {
    test('open and select actions', () {
      expect(ProviderModalActionTable.open, 'provider');
      expect(ProviderModalActionTable.providerPrefix, 'provider:');
      for (final String id in _ids) {
        expect(ProviderModalActionTable.select(id), 'provider:' + id);
      }
      expect(ProviderModalActionTable.select('netease'), 'provider:netease');
      expect(ProviderModalActionTable.login, 'music:login');
      expect(ProviderModalActionTable.discover, 'discover');
      expect(ProviderModalActionTable.closeModal, 'close-modal');
    });

    test('selecting a different provider runs the eight Qt steps in order and '
        'does not close the modal (NativeHudController.cpp:512-524)', () {
      expect(ProviderModalActionTable.selectSequence, <String>[
        'searchGeneration++',
        'activeGroup.clear',
        'query.clear',
        'listOffset=0',
        'resetResultViews',
        'trackOffset=0',
        'switchProvider',
      ]);
      for (final String step in ProviderModalActionTable.selectSequence) {
        expect(step.toLowerCase().contains('close'), isFalse);
        expect(step.toLowerCase().contains('modal'), isFalse);
      }
    });

    test('shouldSwitch is provider != id, so re-tapping the active card is a '
        'no-op (NativeHudController.cpp:512-513)', () {
      expect(ProviderModalActionTable.shouldSwitch('netease', 'netease'), isFalse);
      expect(ProviderModalActionTable.shouldSwitch('netease', 'qq'), isTrue);
      expect(ProviderModalActionTable.shouldSwitch('local', 'netease'), isTrue);
    });

    test('Escape maps to close-modal and nothing else does; there is no Tab '
        'focus ring and this modal owns no arrow keys '
        '(NativeHudController.cpp:913-942)', () {
      expect(ProviderModalActionTable.keyActions,
          <String, String>{'Escape': 'close-modal'});
      expect(ProviderModalActionTable.escapeAction, 'close-modal');
      expect(ProviderModalActionTable.keyActions.containsKey('Tab'), isFalse);
      expect(ProviderModalActionTable.keyActions.containsKey('ArrowDown'), isFalse);
      expect(ProviderModalActionTable.keyActions.containsKey('ArrowUp'), isFalse);
      // The 66 px arrow scrolling belongs to settings / desktop-lyrics only.
      expect(ProviderModalActionTable.keyActions.length, 1);
    });

    test('a card hit action is a provider switch, never a modal close', () {
      for (final String id in _ids) {
        final String action = ProviderModalActionTable.select(id);
        expect(action.startsWith(ProviderModalActionTable.providerPrefix), isTrue);
        expect(action.contains('close'), isFalse);
      }
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: SurfaceMotion port '
      '(UiMotion.h:24-42, UiMotion.cpp:86-120)', () {
    test('a fresh motion starts hidden with the Qt offset 12 and is finished '
        '(UiMotion.h:24-42)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
    });

    test('entering: duration 0.3, target opacity 1 and offset 0 '
        '(UiMotion.cpp:105-113)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0);
      expect(motion.duration, 0.3);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      motion.sample(0.15);
      expect(motion.opacity, greaterThan(0.0));
      expect(motion.opacity, lessThan(1.0));
      expect(motion.offset, greaterThan(0.0));
      expect(motion.offset, lessThan(12.0));
      expect(motion.finished, isFalse);
      motion.sample(0.3);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      expect(motion.finished, isTrue);
    });

    test('the bezier is clamped at both ends and never overshoots '
        '(UiMotion.cpp:86-104)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 1.0);
      motion.sample(1.0);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      motion.sample(0.5); // before the start: progress clamps to 0
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      motion.sample(9.9); // far past the end: progress clamps to 1
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      expect(motion.finished, isTrue);
    });

    test('closing: duration 0.2, target opacity 0 and offset 8 '
        '(UiMotion.cpp:105-113)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0);
      motion.sample(0.3);
      motion.set(shown: false, time: 0.3);
      expect(motion.duration, 0.2);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      motion.sample(0.4);
      expect(motion.opacity, lessThan(1.0));
      expect(motion.opacity, greaterThan(0.0));
      expect(motion.offset, greaterThan(0.0));
      expect(motion.offset, lessThan(8.0));
      motion.sample(0.5);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
      expect(motion.finished, isTrue);
    });

    test('a new transition captures the sampled opacity and offset, so an '
        'interrupted animation continues from where it is '
        '(UiMotion.cpp:105-120)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0);
      motion.sample(0.15);
      final double mid = motion.opacity;
      final double midOffset = motion.offset;
      expect(mid, greaterThan(0.0));
      expect(mid, lessThan(1.0));
      motion.set(shown: false, time: 0.15);
      expect(motion.opacity, mid);
      expect(motion.offset, midOffset);
      expect(motion.duration, 0.2);
      motion.sample(0.25);
      expect(motion.opacity, lessThan(mid));
      expect(motion.opacity, greaterThan(0.0));
    });

    test('reduced motion snaps to the target with duration 0 and never '
        'animates (UiMotion.cpp:107-119)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0, reduced: true);
      expect(motion.duration, 0.0);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      expect(motion.finished, isTrue);
      motion.set(shown: false, time: 0.0, reduced: true);
      expect(motion.duration, 0.0);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
      expect(motion.finished, isTrue);
    });

    test('sampling a finished motion is a no-op, which is how the host keeps '
        'a stable frame after the transition (UiMotion.cpp:88-92)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0);
      motion.sample(0.3);
      final double opacity = motion.opacity;
      final double offset = motion.offset;
      motion.sample(5.0);
      expect(motion.opacity, opacity);
      expect(motion.offset, offset);
      expect(motion.finished, isTrue);
    });

    test('the closing animation only clears the panel once the host sees '
        'closing and finished; the port keeps painting until then '
        '(NativeHud.cpp:262-266)', () {
      final ProviderModalMotion motion = ProviderModalMotion();
      motion.set(shown: true, time: 0.0);
      motion.sample(0.3);
      motion.set(shown: false, time: 0.3);
      motion.sample(0.4);
      expect(motion.finished, isFalse);
      expect(motion.opacity, greaterThan(0.0));
      expect(motion.opacity, lessThan(1.0));
      final ProviderModalFrame mid =
          _modal(closing: true, opacity: motion.opacity, offset: motion.offset)
              .build();
      // Half-way through the fade the whole panel is still emitted.
      expect(_hasText(mid, 'MUSIC PLATFORM'), isTrue);
      expect(mid.commands[1], <Object?>['alpha', motion.opacity]);
      expect(mid.commands[3], <Object?>['translate', 0.0, motion.offset]);
      motion.sample(0.5);
      expect(motion.finished, isTrue);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
    });

    test('closing and reduced are host-injected and never recomputed inside '
        'the port (NativeHud.h:140,146, NativeHud.cpp:262-266)', () {
      final ProviderModalFrame frame =
          _modal(closing: true, reduced: true, opacity: 0.0, offset: 8.0).build();
      expect(frame.commands[1], <Object?>['alpha', 0.0]);
      expect(frame.commands[3], <Object?>['translate', 0.0, 8.0]);
      // Even at full fade the host, not the port, decides to drop the frame.
      expect(_hasText(frame, 'MUSIC PLATFORM'), isTrue);
      expect(frame.commands.last, <Object?>['restore']);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: placement hook and purity', () {
    test('the identity hook is the default and changes nothing', () {
      expect(_modal().build().commands, _modal(rectHook: _identity).build().commands);
    });

    test('a portrait hook transforms every rect and text origin exactly once '
        '(panel, header, cards, hits, action row)', () {
      final ProviderModalFrame frame = _modal(rectHook: _shift).build();
      expect(frame.commands[4],
          <Object?>['fill', _darkPanel, 430.0, 172.0, 2520.0, 1672.0]);
      expect(frame.commands[2], <Object?>[
        'fill',
        <Object?>[17.0 / 255.0, 24.0 / 255.0, 27.0 / 255.0, 0.6],
        100.0,
        50.0,
        3840.0,
        2160.0,
      ]);
      final double cw = _cardWidth(_contentWidth(_stage), 5) * 2.0;
      expect(_hitFor(frame, 'provider:siren'),
          <Object?>[483.0, 430.0, cw, 380.0, 'provider:siren', '塞壬唱片']);
      expect(_textValue(frame, 'MUSIC PLATFORM')[2], 483.0);
      expect(_textValue(frame, 'MUSIC PLATFORM')[3], 263.0);
      expect(_textValue(frame, '账号登录 / 网易云音乐')[2], 493.0);
      expect(_textValue(frame, '账号登录 / 网易云音乐')[3], 844.0);
    });

    test('a hook that does not return four numbers is rejected', () {
      List<double> bad(double x, double y, double w, double h) => <double>[x, y];
      expect(() => _modal(rectHook: bad).build(), throwsArgumentError);
    });

    test('build is pure: two builds agree and share no list instances', () {
      final ProviderModal modal = _modal();
      final ProviderModalFrame first = modal.build();
      final ProviderModalFrame second = modal.build();
      expect(first.commands, second.commands);
      expect(first.hits, second.hits);
      expect(identical(first.commands, second.commands), isFalse);
      expect(identical(first.hits, second.hits), isFalse);
      expect(_allTextValue(first, 'MUSIC PLATFORM').length, 1);
      expect(_allTextValue(second, 'MUSIC PLATFORM').length, 1);
    });

    test('the generic bounds constants are exposed and match Qt '
        '(NativeHud.cpp:153-158, NativeHudModal.cpp:163)', () {
      expect(ProviderModal.modalMaxWidth, _modalMaxWidth);
      expect(ProviderModal.modalTop, _modalTop);
      expect(ProviderModal.modalHeight, _modalHeight);
      expect(ProviderModal.modalHorizontalMargin, 100.0);
      expect(ProviderModal.stageHeight, 1080.0);
      expect(ProviderModal.modalMaxWidth, 1260.0);
      expect(ProviderModal.modalTop, 122.0);
      expect(ProviderModal.modalHeight, 836.0);
    });

    test('modal controls are tinted buttons with the Qt inset; nothing else '
        'in the panel gets a button tint (NativeHudModal.cpp:174,255, '
        'NativeHud.cpp:110-120)', () {
      final ProviderModalFrame frame = _modal().build();
      expect(
          _fills(frame)
              .where((List<Object?> c) => _colorEq(c[1], _darkButtonTint))
              .length,
          2);
      final ProviderModalFrame siren =
          _modal(isSiren: true, provider: 'siren').build();
      expect(
          _fills(siren)
              .where((List<Object?> c) => _colorEq(c[1], _darkButtonTint))
              .length,
          1);
      final ProviderModalFrame light = _modal(dark: false).build();
      expect(
          _fills(light)
              .where((List<Object?> c) => _colorEq(c[1], _lightButtonTint))
              .length,
          2);
    });
  });

  // -------------------------------------------------------------------------
  group('provider modal: provider table (NativeHudModal.cpp:12-24)', () {
    test('five rows, Qt order, verbatim id, name, label and detail', () {
      expect(ProviderModalCatalog.all.length, 5);
      for (int i = 0; i < 5; i++) {
        final ProviderModalCard card = ProviderModalCatalog.all[i];
        expect(card.id, _ids[i]);
        expect(card.name, _names[i]);
        expect(card.label, _labels[i]);
        expect(card.detail, _details[i]);
      }
      expect(ProviderModalCatalog.all[0].label, 'MONSTER SIREN');
      expect(ProviderModalCatalog.all[3].detail,
          '标准版 / 概念版 · 个人歌单 · 推荐与榜单 · 播放');
    });

    test('forFeatures keeps all rows when local music is enabled and drops the '
        'last one otherwise (NativeHudModal.cpp:20-22)', () {
      expect(ProviderModalCatalog.forFeatures(localMusic: true).length, 5);
      final List<ProviderModalCard> four =
          ProviderModalCatalog.forFeatures(localMusic: false);
      expect(four.length, 4);
      expect(four.last.id, 'kugou');
      expect(four.map((ProviderModalCard c) => c.id).toList(),
          <String>['siren', 'netease', 'qq', 'kugou']);
      expect(identical(four[0], ProviderModalCatalog.all[0]), isTrue);
    });

    test('forFeatures returns a fresh list, so a mutated result cannot corrupt '
        'the static table (NativeHudModal.cpp:20-22)', () {
      final List<ProviderModalCard> rows =
          ProviderModalCatalog.forFeatures(localMusic: false);
      rows.clear();
      expect(ProviderModalCatalog.all.length, 5);
      expect(ProviderModalCatalog.forFeatures(localMusic: true).length, 5);
    });

    test('the modal exposes the filtered table it draws '
        '(Qt/src/PlatformFeatures.h:10,15)', () {
      expect(_modal().cards.length, 5);
      expect(_modal(platformFeaturesLocalMusic: false).cards.length, 4);
      expect(_modal(platformFeaturesLocalMusic: false).cards.last.id, 'kugou');
    });
  });
}
