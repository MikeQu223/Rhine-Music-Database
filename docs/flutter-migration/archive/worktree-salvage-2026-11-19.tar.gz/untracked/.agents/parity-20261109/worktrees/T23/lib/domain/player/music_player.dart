/// Qt 移植源：Qt/src/MusicPlayer.h、Qt/src/MusicPlayer.cpp
///
/// 播放聚合根。持有唯一的 PlaybackQueue（禁止第二个队列）与 LyricsController，
/// 负责音质选择、地址解码、播放代数隔离、断点恢复与 audio focus 会话存档。
/// 后台服务模式下所有播放操作都转发给唯一的 PlaybackConnection，本地不持有解码器。
library;

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import '../lyrics/lyrics_controller.dart';
import 'playback_queue.dart';

/// 播放宿主端口，对齐 Qt Host：偏好、封面解码、媒体会话与调度。
///
/// Qt 直接在 C++ 内用 QFileInfo/QUrl 做本地文件校验；Flutter 领域层不持有文件系统，
/// 因此 isReadableFile 把同一语义表达为可注入端口。
abstract class MusicPlayerHostPort {
  /// 对齐 Qt Host::preference。
  String preference(String key);

  /// 对齐 Qt Host::setPreference。
  void setPreference(String key, String value);

  /// 对齐 Qt Host::loadCover：解码失败回空串。
  Future<String> loadCover(String url);

  /// 对齐 Qt Host::requestJson，供歌词侧车等请求使用。
  Future<Map<String, Object?>> requestJson(String path, Map<String, Object?> params);

  /// 对齐 Qt Host::schedule。
  void schedule(int delayMs, void Function() action);

  /// 对齐 Qt Host::mediaState。
  Map<String, Object?> mediaState();

  /// 对齐 Qt Host::mediaLoad，返回是否成功开始播放。
  Future<bool> mediaLoad(
    String url,
    bool alternative, {
    double resumePosition = 0,
    bool resumePaused = false,
  });

  /// 对齐 Qt Host::mediaControl。
  void mediaControl(String action, [Object? value]);

  /// 对齐 Qt Host::mediaMetadata。
  void mediaMetadata(String title, String artist, String album, [String cover = '']);

  /// 对齐 Qt Host::playbackConnection：唯一后台播放服务通道。
  PlaybackConnectionPort? playbackConnection();

  /// 对齐 Qt QFileInfo(path).isReadable()。
  bool isReadableFile(String path);
}

/// 对齐 Qt MusicReply；value 为 QJsonValue，可能是对象或数组。
class MusicApiResult {
  const MusicApiResult({this.ok = false, this.error = '', this.value});

  final bool ok;
  final String error;
  final Object? value;

  /// 对齐 Qt result.value.toObject()。
  Map<String, Object?> get objectValue =>
      value is Map ? Map<String, Object?>.from(value as Map) : <String, Object?>{};

  /// 对齐 Qt result.value.toArray()。
  List<Object?> get arrayValue =>
      value is List ? List<Object?>.from(value as List) : <Object?>[];
}

/// 对齐 Qt MusicReply.error 的失败表达，供队列按批次跳过。
class MusicApiException implements Exception {
  const MusicApiException(this.message);

  final String message;

  @override
  String toString() => 'MusicApiException: ' + message;
}

/// 音乐接口端口，同时满足队列补全所需的 [QueueMetadataPort]。
///
/// 对齐 Qt MusicApi::call(operation, arguments, reply, valid)：arguments 是位置参数
/// 数组（MusicApi.h:22），失败以 [MusicApiResult.error] 表达。
abstract class MusicApiPort implements QueueMetadataPort {
  @override
  String get provider;

  /// 对齐 Qt MusicApi::call。
  Future<MusicApiResult> call(String operation, List<Object?> arguments);

  /// 对齐 Qt PlaybackQueue::fetchNext 的 call("songs", {batch})：
  /// result.value.toArray() 直接就是歌曲数组（PlaybackQueue.cpp:374-386）。
  @override
  Future<List<Track>> songs(List<String> ids) async {
    final result = await call('songs', <Object?>[ids]);
    if (!result.ok) {
      throw MusicApiException(result.error);
    }
    return <Track>[
      for (final value in result.arrayValue)
        if (value is Map) Map<String, Object?>.from(value),
    ];
  }
}

/// 对齐 Qt PlaybackConnection：用户私有的唯一后台播放服务。
abstract class PlaybackConnectionPort {
  /// 对齐 Qt PlaybackConnection::call。
  void call(String method, Map<String, Object?> arguments);

  /// 对齐 Qt PlaybackConnection::snapshot。
  Map<String, Object?> get snapshot;

  /// 对齐 Qt PlaybackConnection::error。
  String get error;

  void addSnapshotChangedListener(void Function() listener);

  void removeSnapshotChangedListener(void Function() listener);

  void addDisconnectedListener(void Function() listener);
}

/// 对齐 Qt PlatformFeatures（Qt/src/PlatformFeatures.h:7-11）。
///
/// Qt 的 RHINE_MOBILE 在 Android/iOS 上恒为真（Qt/src/MobileTarget.h:12-16：
/// Q_OS_IOS || Q_OS_ANDROID），此时 PlatformFeatures::ApplicationVolume == false，
/// 音量交给系统音量键处理；桌面目标才为 true。
/// 本迁移的目标平台是 Android（Qt Android -> Flutter），因此默认取移动端取值；
/// 桌面宿主若需要逐应用音量，必须显式注入 MusicPlatformFeatures(applicationVolume: true)。
class MusicPlatformFeatures {
  const MusicPlatformFeatures({this.applicationVolume = false});

  /// 对齐 PlatformFeatures::ApplicationVolume；移动端为 false，音量交给系统
  /// （MusicPlayer.cpp:561-571 在 false 时把目标音量强制为 1.0）。
  final bool applicationVolume;
}

/// 对齐 Qt qualityOptions 的 (值, 文案) 对。
class QualityOption {
  const QualityOption(this.value, this.label);

  final String value;
  final String label;
}

/// 播放聚合根；对齐 Qt MusicPlayer 的全部公开行为与状态字段。
class MusicPlayer {
  MusicPlayer({
    required MusicPlayerHostPort host,
    required MusicApiPort api,
    PlaybackQueue? queue,
    LyricsController? lyrics,
    PlaybackConnectionPort? playbackConnection,
    LyricsApiPort Function(String provider)? lyricsApiFactory,
    MusicPlatformFeatures features = const MusicPlatformFeatures(),
    math.Random? random,
  })  : _host = host,
        _api = api,
        _features = features,
        // Qt 的 MusicPlayer 每次用到时都重新调用 m_host->playbackConnection()
        // （MusicPlayer.cpp:163/232/472/629/706/770/778），但 Host 的 remote 只在
        // Host 构造时赋值一次、之后永不改变（Qt/src/Host.h:85-87 返回 remote、
        // Qt/src/Host.h:148 声明、Qt/src/Host.cpp:45 初始化列表 remote(test ? nullptr : connection)）。
        // 因此这里在 MusicPlayer 构造时缓存一次与 Qt 语义完全等价。
        _connection = playbackConnection ?? host.playbackConnection() {
    this.queue = queue ?? PlaybackQueue(api, random: random);
    this.lyrics = lyrics ??
        LyricsController(
          _PlayerLyricsHost(host),
          apiFactory: lyricsApiFactory ?? _defaultLyricsApiFactory(api),
        );
    state = <String, Object?>{
      'playing': false,
      'position': 0.0,
      'duration': 0.0,
      'volume': 0.7,
      'seekable': false,
    };
    this.queue.addListener(_emitChanged);
    final connection = _connection;
    if (connection != null) {
      // 后台服务模式：界面只保存快照，不持有解码器或服务进程（MusicPlayer.cpp:163-180）。
      // Qt 用 Qt::QueuedConnection 连接 snapshotChanged 以避免在服务回调栈内重入
      // （MusicPlayer.cpp:164-167）；Flutter 侧端口约定在 UI isolate 上投递快照，
      // 与 QueuedConnection 的"下一次事件循环执行"等价，故这里直接注册回调。
      connection.addSnapshotChangedListener(applyPlaybackSnapshot);
      connection.addDisconnectedListener(_connectionLost);
      applyPlaybackSnapshot();
      // 等资料库完成来源初始化后再解码封面，避免初始化的账号代数作废首次加载。
      // 对应 Qt 的 QTimer::singleShot(0, ...)（MusicPlayer.cpp:176-180）；
      // 宿主用 Host::schedule 注入延时策略（Qt/src/Host.h:28）。
      _host.schedule(0, () {
        _remoteCover = '';
        applyPlaybackSnapshot();
      });
    } else {
      var stored = _host.preference('quality');
      if (!qualityValues.contains(stored)) {
        stored = 'exhigh';
      }
      quality = stored;
      localCovers = _decodeObject(_host.preference('local-cover-cache'));
      alternative = _host.preference('alternate-source') == 'on';
      history = _decodeHistory(_host.preference('play-history'));
      this.lyrics.addListener(_emitChanged);
      this.lyrics.addCoverMatchedListener(_coverMatched);
    }
  }

  /// 与目录分页一致的历史上限（Qt 截断在 history.size() == 200）。
  static const int historyLimit = 200;

  /// 本地封面缓存上限（Qt while (localCovers.size() > 200)）。
  static const int localCoverLimit = 200;

  /// Qt constexpr int maxRecoveryAttempts = 2。
  static const int maxRecoveryAttempts = 2;

  /// Qt 构造里接受的音质集合（MusicPlayer.cpp:182-185）。
  static const Set<String> qualityValues = <String>{
    'standard',
    'higher',
    'exhigh',
    'lossless',
    'hires',
    'jymaster',
    'best',
    'ape',
  };

  static const List<String> modes = <String>['off', 'all', 'one', 'shuffle'];

  static const Map<String, String> _reportedQualities = <String, String>{
    '128': '标准',
    '320': '高品质',
    'flac': '无损',
  };

  static const Set<String> _losslessFormats = <String>{
    'flac',
    'ape',
    'wav',
    'aif',
    'aiff',
    'alac',
    'wv',
    'dsf',
    'dff',
  };

  static final RegExp _identifier = RegExp(r'^[a-zA-Z0-9_-]{1,80}$');

  final MusicPlayerHostPort _host;
  final MusicApiPort _api;
  final PlaybackConnectionPort? _connection;
  final MusicPlatformFeatures _features;

  /// 唯一播放队列；界面与服务共用同一份顺序，禁止建立第二个队列。
  late PlaybackQueue queue;

  /// 歌词控制器；只在这里创建，界面不得自行解析歌词。
  late LyricsController lyrics;

  Map<String, Object?> current = <String, Object?>{};
  Map<String, Object?> state = <String, Object?>{};
  Map<String, Object?> localCovers = <String, Object?>{};
  List<Map<String, Object?>> history = <Map<String, Object?>>[];
  bool loading = false;
  bool failed = false;
  bool trial = false;
  bool alternative = false;
  bool previewRequested = false;
  String coverImage = '';
  String mode = 'all';
  String status = '';
  String quality = '';
  String actualQuality = '';

  /// 播放自然结束时由界面接手；为空则推进队列下一首。
  void Function()? onEnd;

  final List<void Function()> _changedListeners = <void Function()>[];
  final List<void Function(Map<String, Object?>)> _trackSelectedListeners =
      <void Function(Map<String, Object?>)>[];

  int _generation = 0;
  int _endSerial = 0;
  double _lastPoll = -1;
  double? _resumePosition;
  bool _resumePaused = false;
  bool _restoringSession = false;
  int _recoveryAttempts = 0;
  int _selectionSerial = 0;
  bool _receivedSnapshot = false;
  String _remoteCover = '';

  /// 订阅 changed（Qt MusicPlayer::changed）。
  void addListener(void Function() listener) => _changedListeners.add(listener);

  void removeListener(void Function() listener) => _changedListeners.remove(listener);

  /// 订阅 trackSelected（Qt MusicPlayer::trackSelected）。
  void addTrackSelectedListener(void Function(Map<String, Object?> track) listener) =>
      _trackSelectedListeners.add(listener);

  void removeTrackSelectedListener(void Function(Map<String, Object?> track) listener) =>
      _trackSelectedListeners.remove(listener);

  void _emitChanged() {
    for (final listener in List<void Function()>.of(_changedListeners)) {
      listener();
    }
  }

  void _emitTrackSelected(Map<String, Object?> track) {
    for (final listener in List<void Function(Map<String, Object?>)>.of(_trackSelectedListeners)) {
      listener(track);
    }
  }

  /// 对齐 Qt MusicPlayer::valid(generation)（MusicPlayer.cpp:225-227）：迟到的异步回调必须作废。
  ///
  /// Qt 侧是同步调用链：MusicApi::call(..., valid(generation)) 与紧随其后的
  /// mediaLoad/mediaMetadata 之间没有让出点，代数只在 ++m_generation 时变化。
  /// Dart 端口（MusicApiPort.call / MusicPlayerHostPort.mediaLoad）是 Future 异步的，
  /// 每次 await 之后重新检查代数才等价于 Qt 在回调里检查 Valid：
  /// 中途 play()/setQuality()/stop()/recoverPlayback() 递增 _generation 后，
  /// 迟到结果必须被丢弃，不能覆盖新的播放状态。
  bool Function() _valid(int generation) => () => _generation == generation;

  /// 对齐 Qt 构造里 PlaybackConnection::disconnected 的处理（MusicPlayer.cpp:166-172）。
  void _connectionLost() {
    loading = false;
    failed = true;
    state['playing'] = false;
    status = '后台播放服务已断开，请重新打开应用';
    _emitChanged();
  }

  /// 对齐 Qt 构造里 LyricsController::coverMatched 的处理（MusicPlayer.cpp:200-222）。
  void _coverMatched(String key, String url) {
    if (current['provider'] != 'local' ||
        LyricsController.trackKey(current) != key ||
        _text(current['cover']).isNotEmpty) {
      return;
    }
    final alive = _valid(_generation);
    _host.loadCover(url).then((image) {
      if (!alive() || image.isEmpty) {
        return;
      }
      coverImage = image;
      current['cover'] = url;
      final cacheKey = _text(current['id']) + ':' + _text(current['fingerprint']);
      localCovers[cacheKey] = url;
      while (localCovers.length > localCoverLimit) {
        localCovers.remove(localCovers.keys.first);
      }
      _host.setPreference('local-cover-cache', _encodeCompact(localCovers));
      queue.updateCurrent(current);
      _emitChanged();
    });
  }

  /// 对齐 Qt MusicPlayer::qualityOptions。
  static List<QualityOption> qualityOptions(String provider) {
    if (provider == 'qq') {
      return const <QualityOption>[
        QualityOption('best', '自动最高可用'),
        QualityOption('standard', '标准'),
        QualityOption('exhigh', 'HQ 高品质'),
        QualityOption('lossless', 'SQ 无损 / FLAC'),
        QualityOption('ape', 'SQ 无损 / APE'),
      ];
    }
    if (provider == 'kugou') {
      return const <QualityOption>[
        QualityOption('standard', '标准'),
        QualityOption('exhigh', 'HQ 高品音质'),
        QualityOption('lossless', 'SQ 无损音质'),
        QualityOption('hires', 'Hi-Res 高解析音质'),
      ];
    }
    if (provider == 'siren') {
      return const <QualityOption>[QualityOption('lossless', '官网原始音源')];
    }
    return const <QualityOption>[
      QualityOption('standard', '标准'),
      QualityOption('higher', '较高'),
      QualityOption('exhigh', '极高'),
      QualityOption('lossless', 'SQ 无损'),
      QualityOption('hires', 'Hi-Res 高解析音质'),
      QualityOption('jymaster', '超清母带'),
    ];
  }

  /// 对齐 Qt MusicPlayer::localQuality（MusicPlayer.cpp:11-37）。
  static String localQuality(Map<String, Object?> track) {
    final name = _baseName(_text(track['path']));
    final format = _text(track['format']).toLowerCase();
    final bitrateKbps = _int(track['bitrate']);
    if (name.contains('jymaster') ||
        name.contains('母带') ||
        name.contains('[master]') ||
        name.contains('master quality')) {
      return 'jymaster';
    }
    if (name.contains('全景声') ||
        name.contains('沉浸') ||
        name.contains('dolby atmos') ||
        name.contains('[atmos]') ||
        name.contains('[sky]')) {
      return 'sky';
    }
    if (name.contains('jyeffect') || name.contains('臻音')) {
      return 'jyeffect';
    }
    final lossless = _losslessFormats.contains(format) || (format == 'm4a' && bitrateKbps >= 700);
    if (lossless) {
      final highResolution = name.contains('hi-res') ||
          name.contains('hires') ||
          name.contains('高解析') ||
          name.contains('24bit') ||
          name.contains('24-bit') ||
          _int(track['sampleRate']) > 48000 ||
          bitrateKbps > 1600;
      return highResolution ? 'hires' : 'sq';
    }
    return bitrateKbps >= 192 || name.contains('320k') || name.contains('[hq]') ? 'hq' : 'standard';
  }

  /// 对齐 Qt MusicPlayer::sourceQuality（MusicPlayer.cpp:40-102）。
  static String sourceQuality(String provider, Map<String, Object?> audio, bool trial) {
    if (trial || _text(audio['url']).isEmpty) {
      return '';
    }
    final url = _text(audio['url']);
    final file = _fileName(url).toUpperCase();
    var format = _text(audio['type']).toLowerCase();
    if (format.isEmpty) {
      format = _text(audio['extName']).toLowerCase();
    }
    if (format.isEmpty) {
      format = _extension(_urlPath(url));
    }
    if (provider == 'siren') {
      if (format == 'wav' || format == 'flac' || format == 'ape' || format == 'alac') {
        return 'sq';
      }
      if (format == 'mp3' || format == 'm4a' || format == 'aac') {
        return 'hq';
      }
      return '';
    }
    if (provider == 'qq') {
      // 登录接口可能没有 quality；前缀是实际获准播放的媒体文件类型。
      if (file.startsWith('F000') || file.startsWith('A000')) {
        return 'sq';
      }
      if (file.startsWith('M800')) {
        return 'hq';
      }
      if (file.startsWith('M500') || file.startsWith('C400')) {
        return 'standard';
      }
      return '';
    }
    final bitrate = _num(audio['br']);
    final lossy = format == 'mp3' || format == 'm4a' || format == 'aac';
    if (lossy && bitrate > 0) {
      // 替代音源可能保留原等级；已返回的有损格式与码率优先于等级标签。
      return bitrate >= 192000 ? 'hq' : 'standard';
    }
    if (provider == 'netease') {
      final level = _text(audio['level']);
      const levels = <String, String>{
        'standard': 'standard',
        'higher': 'hq',
        'exhigh': 'hq',
        'lossless': 'sq',
        'hires': 'hires',
        'jyeffect': 'jyeffect',
        'sky': 'sky',
        'jymaster': 'jymaster',
      };
      final resolved = levels[level];
      if (resolved != null && (!lossy || resolved == 'standard' || resolved == 'hq')) {
        return resolved;
      }
    }
    final lossless = format == 'flac' || format == 'ape' || format == 'alac';
    if (lossless) {
      // 无损码率高不能证明 Hi-Res；必须同时取得采样率与位深。
      if (_num(audio['sampleRate']) > 48000 && _int(audio['bitDepth']) > 16) {
        return 'hires';
      }
      return 'sq';
    }
    return '';
  }

  /// 对齐 Qt MusicPlayer::setQuality（MusicPlayer.cpp:127-157）。
  void setQuality(String value) {
    if (_remoteCommand('quality', <String, Object?>{'value': value})) {
      return;
    }
    final options = qualityOptions(_api.provider);
    final known = options.any((option) => option.value == value);
    if (!known || quality == value) {
      return;
    }
    quality = value;
    _recoveryAttempts = 0;
    _host.setPreference('quality', value);
    if (current.isEmpty || (loading && _resumePosition == null)) {
      _emitChanged();
      return;
    }
    if (_resumePosition == null) {
      _resumePosition = _num(state['position']);
      _resumePaused = !_bool(state['playing']);
    }
    final generation = ++_generation;
    _host.mediaControl('stop');
    actualQuality = '';
    failed = false;
    trial = false;
    loading = true;
    status = '正在切换音质…';
    _emitChanged();
    unawaited(prepare(current, generation, reload: true));
  }

  /// 对齐 Qt MusicPlayer::enqueue（MusicPlayer.cpp:230-246）。
  ///
  /// Qt 在 remoteCommand 为真后直接解引用 m_host->playbackConnection() 读 error()，
  /// 因为 remoteCommand 为真蕴含连接存在；这里缓存局部 connection 做同样的判空。
  bool enqueue(Map<String, Object?> track, {bool next = false}) {
    final connection = _connection;
    if (_remoteCommand('enqueue', <String, Object?>{'track': track, 'next': next})) {
      if (connection != null && connection.error.isNotEmpty) {
        return false;
      }
      final key = PlaybackQueue.identity(track);
      if (next) {
        final position = math.max(0, queue.index + 1);
        return position < queue.size && PlaybackQueue.identity(queue.at(position)) == key;
      }
      return !queue.isEmpty && PlaybackQueue.identity(queue.at(queue.size - 1)) == key;
    }
    if (track['kind'] != 'song') {
      return false;
    }
    return queue.enqueue(track, next: next);
  }

  /// 对齐 Qt MusicPlayer::play（MusicPlayer.cpp:249-292）。
  void play(
    Map<String, Object?> track, {
    List<Track>? source,
    int? queueIndex,
    bool preview = false,
    Map<String, Object?>? resume,
  }) {
    final arguments = <String, Object?>{'track': track, 'preview': preview};
    if (source != null) {
      arguments['source'] = source;
    }
    if (queueIndex != null) {
      arguments['index'] = queueIndex;
    }
    if (resume != null) {
      arguments['resume'] = resume;
    }
    if (_remoteCommand('play', arguments)) {
      return;
    }
    final provider = _api.provider;
    if (track['kind'] != 'song' ||
        (provider == 'local' && track['provider'] != 'local') ||
        (provider != 'local' && track['provider'] == 'local')) {
      return;
    }
    if (source != null) {
      queue.replace(source);
    }
    queue.selectTrack(track);
    if (queueIndex != null) {
      queue.select(queueIndex);
    }
    final generation = ++_generation;
    _resumePosition = resume == null ? null : _num(resume['position']);
    _resumePaused = resume != null && !_bool(resume['requested']);
    _restoringSession = resume != null;
    _recoveryAttempts = 0;
    previewRequested = preview && provider == 'qq';
    _host.mediaControl('stop');
    current = Map<String, Object?>.of(track);
    actualQuality = '';
    lyrics.clear();
    coverImage = '';
    loading = true;
    failed = false;
    trial = false;
    status = '正在准备：' + _text(track['title']);
    _emitChanged();
    unawaited(prepare(track, generation));
  }

  /// 对齐 Qt MusicPlayer::loadQueue（MusicPlayer.cpp:294-299）。
  void loadQueue(List<String> ids, List<Track> known) {
    if (_remoteCommand('loadQueue', <String, Object?>{'ids': ids, 'known': known})) {
      return;
    }
    unawaited(queue.load(ids, known));
  }

  /// 对齐 Qt MusicPlayer::prepare（MusicPlayer.cpp:301-443）。
  Future<void> prepare(Map<String, Object?> source, int generation, {bool reload = false}) async {
    // Qt 的 track 是值拷贝（QJsonObject 写时复制），本地封面回填不会改到调用方对象。
    final track = Map<String, Object?>.of(source);
    if (track['provider'] == 'local') {
      final url = _text(track['url']);
      if (_api.provider != 'local' || !_isLocalFile(url) || !_host.isReadableFile(_localPath(url))) {
        fail('本地文件无法访问，请检查文件位置或重新扫描');
        return;
      }
    }
    if (track['provider'] == 'local' && _text(track['cover']).isEmpty) {
      final key = _text(track['id']) + ':' + _text(track['fingerprint']);
      final cached = localCovers[key];
      if (cached != null) {
        track['cover'] = cached;
        current = track;
      }
    }
    if (!reload) {
      if (_text(track['cover']).isNotEmpty) {
        final alive = _valid(generation);
        _host.loadCover(_text(track['cover'])).then((image) {
          if (!alive()) {
            return;
          }
          coverImage = image;
          if (image.isEmpty && current['provider'] == 'local') {
            current['cover'] = '';
            final cacheKey = _text(current['id']) + ':' + _text(current['fingerprint']);
            localCovers.remove(cacheKey);
            _host.setPreference('local-cover-cache', _encodeCompact(localCovers));
            // 下一轮再补图，确保同步失败回调不会早于本次歌词初始化。
            _host.schedule(0, () {
              if (alive()) {
                unawaited(lyrics.matchCover(current));
              }
            });
          }
          _emitChanged();
        });
      }
      if (!_restoringSession) {
        _emitTrackSelected(current);
      }
      unawaited(lyrics.load(current));
    }
    if (track['provider'] == 'local') {
      final url = _text(track['url']);
      if (_api.provider != 'local' || !_isLocalFile(url) || !_host.isReadableFile(_localPath(url))) {
        fail('本地文件无法访问，请检查文件位置或重新扫描');
        return;
      }
      _host.mediaMetadata(
        _text(track['title']),
        _text(track['artist']),
        _text(track['album']),
        _text(track['cover']),
      );
      final loaded = await _host.mediaLoad(
        url,
        false,
        resumePosition: _resumePosition ?? 0,
        resumePaused: _resumePosition != null && _resumePaused,
      );
      // 端口是异步的（Qt MusicPlayer.cpp:389-397 同步调用 mediaLoad 后立刻继续），
      // 这里恢复 Qt 的代数语义：等待期间被一次新的 play()/stop() 作废则丢弃结果。
      if (!_valid(generation)()) {
        return;
      }
      if (!loaded) {
        fail('本地音频无法加载');
        return;
      }
      _resumePosition = null;
      _endSerial = _int(_host.mediaState()['ended']);
      actualQuality = localQuality(track);
      status = '正在播放本地文件：' + _text(track['format']);
      loading = false;
      _emitChanged();
      return;
    }
    // QQ 专有音质在其他平台转换为通用无损
    final qqQuality = quality == 'best' || quality == 'ape';
    var effectiveQuality = qqQuality && _api.provider != 'qq' ? 'lossless' : quality;
    // 网易云专有音质在其他平台转换为对应档位
    if (_api.provider != 'netease') {
      if (quality == 'jymaster' || quality == 'jyeffect' || quality == 'sky') {
        effectiveQuality = 'lossless';
      } else if (quality == 'higher') {
        effectiveQuality = 'standard';
      }
    }
    // 酷狗不支持 ape，转换为通用无损
    if (_api.provider == 'kugou' && quality == 'ape') {
      effectiveQuality = 'lossless';
    }
    if (_api.provider == 'siren') {
      effectiveQuality = 'original';
    }
    // 对齐 Qt MusicPlayer.cpp:361-368：call(previewRequested ? "preview" : "playback",
    // {track, effectiveQuality, alternative}, cb, valid(generation))。
    // Qt 的 valid(generation) 由 MusicApi 在回调时求值，等价于这里的 await 后检查。
    final result = await _api.call(
      previewRequested ? 'preview' : 'playback',
      <Object?>[track, effectiveQuality, alternative],
    );
    if (!_valid(generation)()) {
      return;
    }
    if (!result.ok) {
      fail(result.error);
      return;
    }
    final audio = result.objectValue;
    final url = _text(audio['url']);
    if (url.isEmpty) {
      fail('此歌曲暂无可用音源，请检查登录和歌曲权限');
      return;
    }
    _host.mediaMetadata(
      _text(track['title']),
      _text(track['artist']),
      _text(track['album']),
      _text(track['cover']),
    );
    final loaded = await _host.mediaLoad(
      url,
      _api.provider == 'netease' && alternative,
      resumePosition: _resumePosition ?? 0,
      resumePaused: _resumePosition != null && _resumePaused,
    );
    // Qt MusicPlayer.cpp:398-406 是同步调用；异步端口下必须重新校验代数，
    // 否则一次迟到的 mediaLoad 会在新播放开始后覆盖状态。
    if (!_valid(generation)()) {
      return;
    }
    if (!loaded) {
      fail('音频地址不可用');
      return;
    }
    _resumePosition = null;
    _endSerial = _int(_host.mediaState()['ended']);
    final entry = Map<String, Object?>.of(track)
      ..['wiki'] = ''
      ..['description'] = '';
    final recent = <Map<String, Object?>>[entry];
    for (final value in history) {
      if (PlaybackQueue.identity(value) != PlaybackQueue.identity(track) &&
          recent.length < historyLimit) {
        recent.add(value);
      }
    }
    history = recent;
    _host.setPreference('play-history', _encodeCompact(history));
    final preview = audio['freeTrialInfo'];
    trial = _bool(audio['preview']) ||
        preview is Map ||
        preview is List ||
        (preview is String && preview.isNotEmpty && preview != 'null') ||
        (preview is bool && preview) ||
        (preview is num && preview != 0);
    actualQuality = sourceQuality(_api.provider, audio, trial);
    status = trial ? '当前音源为试听片段' : '正在播放：' + _text(track['title']);
    final reported = _reportedQualities[_text(audio['quality'])];
    if (!trial && reported != null) {
      status = status + '（' + reported + '）';
    }
    final fallback = _text(audio['qualityFallback']);
    if (fallback.isNotEmpty) {
      status = status + '（已切换为' + fallback + '音质）';
    }
    loading = false;
    _emitChanged();
  }

  /// 对齐 Qt MusicPlayer::fail（MusicPlayer.cpp:445-454）。
  void fail(String error) {
    if (!_restoringSession) {
      _resumePosition = null;
    }
    failed = true;
    actualQuality = '';
    status = error;
    loading = false;
    _emitChanged();
  }

  /// 对齐 Qt MusicPlayer::recoverPlayback（MusicPlayer.cpp:456-469）。
  void recoverPlayback() {
    ++_recoveryAttempts;
    final generation = ++_generation;
    _resumePosition = _num(state['position']);
    _resumePaused = !_bool(state['requested']);
    loading = true;
    failed = false;
    actualQuality = '';
    status = '正在恢复播放（' + _recoveryAttempts.toString() + '/2）…';
    _host.mediaControl('stop');
    _emitChanged();
    unawaited(prepare(current, generation, reload: true));
  }

  /// 对齐 Qt MusicPlayer::tick（MusicPlayer.cpp:471-518）。
  void tick(double time, {bool force = false}) {
    if (_connection != null) {
      return;
    }
    if (!force && time - _lastPoll < 0.1) {
      return;
    }
    _lastPoll = time;
    final previous = Map<String, Object?>.of(state);
    for (final entry in _host.mediaState().entries) {
      state[entry.key] = entry.value;
    }
    if (_resumePosition != null && !loading && _bool(state['seekable'])) {
      final position = _clamp(_resumePosition!, 0, _num(state['duration']));
      _resumePosition = null;
      _host.mediaControl('seek', position);
      if (_resumePaused) {
        _host.mediaControl('pause');
      }
    }
    lyrics.sync(_num(state['position']));
    // 播放结束或错误状态只在播放中或加载完成后触发
    if (current.isNotEmpty &&
        !loading &&
        state.containsKey('ended') &&
        _int(state['ended']) != _endSerial) {
      _endSerial = _int(state['ended']);
      final handler = onEnd;
      if (handler != null) {
        handler();
      } else {
        next(1, ended: true);
      }
      return;
    }
    final playbackError = _text(state['error']);
    if (!loading &&
        current.isNotEmpty &&
        playbackError.isNotEmpty &&
        (!failed || actualQuality.isNotEmpty || status != playbackError)) {
      if (!failed &&
          _bool(state['recoverable']) &&
          _recoveryAttempts < maxRecoveryAttempts &&
          current['provider'] != 'local') {
        recoverPlayback();
        return;
      }
      fail(playbackError);
    } else if (!_deepEquals(state, previous)) {
      _emitChanged();
    }
  }

  /// 对齐 Qt MusicPlayer::toggle（MusicPlayer.cpp:520-536）。
  void toggle() {
    if (_remoteCommand('toggle', const <String, Object?>{})) {
      return;
    }
    if (failed && current.isNotEmpty) {
      play(
        current,
        queueIndex: queue.index,
        preview: previewRequested,
        resume: _resumePosition != null ? sessionState() : null,
      );
      return;
    }
    if (_resumePosition != null) {
      setPaused(!_resumePaused);
      return;
    }
    if (!loading && current.isNotEmpty) {
      setPaused(_bool(state['playing']));
    }
  }

  /// 对齐 Qt MusicPlayer::setPaused（MusicPlayer.cpp:538-546）。
  void setPaused(bool paused) {
    if (_remoteCommand('pause', <String, Object?>{'paused': paused})) {
      return;
    }
    if (_resumePosition != null) {
      _resumePaused = paused;
    }
    _host.mediaControl(paused ? 'pause' : 'resume');
  }

  /// 对齐 Qt MusicPlayer::seek（MusicPlayer.cpp:548-559）。
  void seek(double fraction) {
    if (_remoteCommand('seek', <String, Object?>{'value': fraction})) {
      return;
    }
    if (_resumePosition != null) {
      _resumePosition = _clamp(fraction, 0, 1) * _num(state['duration']);
      return;
    }
    if (_bool(state['seekable'])) {
      _host.mediaControl('seek', _clamp(fraction, 0, 1) * _num(state['duration']));
    }
  }

  /// 对齐 Qt MusicPlayer::volume（MusicPlayer.cpp:561-571）。
  void volume(double value) {
    if (_remoteCommand('volume', <String, Object?>{'value': value})) {
      return;
    }
    var target = value;
    if (!_features.applicationVolume) {
      target = 1.0;
    }
    target = _clamp(target, 0, 1);
    _host.mediaControl('volume', target);
    // Qt 用 QString::number(volume) 落盘（MusicPlayer.cpp:570），其默认 'g' 格式会把
    // 整数值写成 "1" 而不是 "1.0"；偏好串必须与 Qt 逐字节一致（Qt session/QSettings 兼容），
    // 因此这里用 _numberString 而不是 Dart 的 double.toString()。
    _host.setPreference('volume', _numberString(target));
  }

  /// 对齐 Qt MusicPlayer::next（MusicPlayer.cpp:573-587）。
  ///
  /// Qt 声明为 void next(int direction = 1, bool ended = false)，两个参数都可省略；
  /// 这里用可选位置参数还原同样的缺省值（next() / next(-1) / next(1, true) 均合法）。
  void next([int direction = 1, bool ended = false]) {
    if (_remoteCommand('next', <String, Object?>{'direction': direction, 'ended': ended})) {
      return;
    }
    if (queue.isEmpty) {
      return;
    }
    final selected = queue.navigate(direction, mode);
    if (selected < 0) {
      status = '队列已播放完';
      _emitChanged();
      return;
    }
    play(queue.at(selected), queueIndex: selected);
  }

  /// 对齐 Qt MusicPlayer::remove（MusicPlayer.cpp:589-594）。
  void remove(int index) {
    if (_remoteCommand('remove', <String, Object?>{'index': index})) {
      return;
    }
    queue.remove(index);
  }

  /// 对齐 Qt MusicPlayer::clearUpcoming（MusicPlayer.cpp:596-601）。
  void clearUpcoming() {
    if (_remoteCommand('clear', const <String, Object?>{})) {
      return;
    }
    queue.clearUpcoming(current);
  }

  /// 对齐 Qt MusicPlayer::stop（MusicPlayer.cpp:604-625）。
  void stop() {
    if (_remoteCommand('stop', const <String, Object?>{})) {
      return;
    }
    ++_generation;
    _resumePosition = null;
    _recoveryAttempts = 0;
    lyrics.clear();
    loading = false;
    failed = false;
    status = '';
    actualQuality = '';
    coverImage = '';
    current = <String, Object?>{};
    queue.clear();
    _host.mediaControl('stop');
    _host.mediaMetadata('', '', '', '');
    state['playing'] = false;
    state['position'] = 0.0;
    state['duration'] = 0.0;
    _emitChanged();
  }

  /// 对齐 Qt MusicPlayer::remoteCommand（MusicPlayer.cpp:628-641）：
  /// 服务可用时播放操作只走服务，绝不回退到第二个本地播放器。
  ///
  /// Qt 每次调用 m_host->playbackConnection()；由于 Host 的 remote 只在 Host 构造时
  /// 赋值一次（Qt/src/Host.cpp:45、Qt/src/Host.h:148），这里用构造期缓存的 _connection。
  bool _remoteCommand(String method, Map<String, Object?> arguments) {
    final connection = _connection;
    if (connection == null) {
      return false;
    }
    connection.call('player.' + method, arguments);
    applyPlaybackSnapshot();
    if (connection.error.isNotEmpty) {
      failed = true;
      status = connection.error;
      _emitChanged();
    }
    return true;
  }

  /// 对齐 Qt MusicPlayer::setMode（MusicPlayer.cpp:643-651）。
  void setMode(String value) {
    if (_remoteCommand('mode', <String, Object?>{'value': value})) {
      return;
    }
    if (modes.contains(value)) {
      mode = value;
      _emitChanged();
    }
  }

  /// 对齐 Qt MusicPlayer::setAlternative（MusicPlayer.cpp:653-660）。
  void setAlternative(bool enabled) {
    if (_remoteCommand('alternative', <String, Object?>{'enabled': enabled})) {
      return;
    }
    alternative = enabled;
    _host.setPreference('alternate-source', enabled ? 'on' : 'off');
    _emitChanged();
  }

  /// 对齐 Qt MusicPlayer::clearHistory（MusicPlayer.cpp:662-669）。
  void clearHistory() {
    if (_remoteCommand('clearHistory', const <String, Object?>{})) {
      return;
    }
    history = <Map<String, Object?>>[];
    _host.setPreference('play-history', '[]');
    _emitChanged();
  }

  /// 对齐 Qt MusicPlayer::clearCaches（MusicPlayer.cpp:672-684）。
  void clearCaches() {
    if (_remoteCommand('clearCaches', const <String, Object?>{})) {
      return;
    }
    lyrics.clearCache();
    clearHistory();
    localCovers = <String, Object?>{};
    _host.setPreference('local-cover-cache', '{}');
    // 当前歌词可能来自刚清掉的缓存，按同一首歌重新读取才能看到修正后的解析结果。
    if (current.isNotEmpty) {
      unawaited(lyrics.load(current, retry: true));
    }
  }

  /// 对齐 Qt MusicPlayer::playbackSnapshot（MusicPlayer.cpp:686-702）。
  ///
  /// Qt 返回 QJsonObject 值（写时复制），调用方改写返回值不会影响 MusicPlayer 内部状态；
  /// 这里对 current/state/history 做浅拷贝以还原该值语义，避免宿主/服务端意外改写聚合根。
  Map<String, Object?> playbackSnapshot() => <String, Object?>{
        'current': Map<String, Object?>.of(current),
        'queue': queue.toJson(),
        'history': List<Map<String, Object?>>.of(history),
        'index': queue.index,
        'mode': mode,
        'state': Map<String, Object?>.of(state),
        'loading': loading,
        'failed': failed,
        'trial': trial,
        'preview': previewRequested,
        'status': status,
        'quality': quality,
        'actualQuality': actualQuality,
        'alternative': alternative,
        'lyrics': lyrics.playbackSnapshot(),
      };

  /// 对齐 Qt MusicPlayer::applyPlaybackSnapshot（MusicPlayer.cpp:705-746）。
  void applyPlaybackSnapshot() {
    final connection = _connection;
    if (connection == null) {
      return;
    }
    final snapshot = connection.snapshot;
    current = _map(snapshot['current']);
    final index = snapshot['index'];
    queue.syncSnapshot(_tracks(snapshot['queue']), index is num ? index.toInt() : -1);
    history = _tracks(snapshot['history']);
    final storedMode = snapshot['mode'];
    mode = storedMode is String ? storedMode : 'all';
    state = _map(snapshot['state']);
    loading = _bool(snapshot['loading']);
    failed = _bool(snapshot['failed']);
    trial = _bool(snapshot['trial']);
    previewRequested = _bool(snapshot['preview']);
    status = _text(snapshot['status']);
    quality = _text(snapshot['quality']);
    actualQuality = _text(snapshot['actualQuality']);
    alternative = _bool(snapshot['alternative']);
    lyrics.applyPlaybackSnapshot(_map(snapshot['lyrics']));
    final cover = _text(current['cover']);
    if (_remoteCover != cover) {
      _remoteCover = cover;
      coverImage = '';
      if (cover.isNotEmpty) {
        _host.loadCover(cover).then((image) {
          if (_remoteCover == cover) {
            coverImage = image;
            _emitChanged();
          }
        });
      }
    }
    final serial = _int(snapshot['selectionSerial']);
    final selected = _receivedSnapshot && serial != _selectionSerial;
    _receivedSnapshot = true;
    _selectionSerial = serial;
    _emitChanged();
    if (selected) {
      _emitTrackSelected(_map(snapshot['selectedTrack']));
    }
  }

  /// 对齐 Qt MusicPlayer::sessionState（MusicPlayer.cpp:749-758）。
  Map<String, Object?> sessionState() {
    final live = _host.mediaState();
    final position = _resumePosition ??
        (live.containsKey('position') ? _num(live['position']) : _num(state['position']));
    final requested = _resumePosition != null
        ? !_resumePaused
        : loading ||
            (live.containsKey('requested') ? _bool(live['requested']) : _bool(state['playing']));
    // 同 playbackSnapshot：还原 QJsonObject 值语义，调用方不能通过返回值改聚合根。
    return <String, Object?>{
      'current': Map<String, Object?>.of(current),
      'queue': queue.toJson(),
      'index': queue.index,
      'mode': mode,
      'position': position,
      'requested': requested,
      'preview': previewRequested,
    };
  }

  /// 对齐 Qt MusicPlayer::restoreSessionState（MusicPlayer.cpp:760-780）。
  void restoreSessionState(Map<String, Object?> saved) {
    final rawPosition = saved['position'];
    final position = rawPosition is num ? rawPosition.toDouble() : -1.0;
    if (!position.isFinite || position < 0 || position > 1e12) {
      return;
    }
    final savedMode = _text(saved['mode']);
    mode = modes.contains(savedMode) ? savedMode : 'all';
    final track = _map(saved['current']);
    final savedQueue = _tracks(saved['queue']);
    final rawIndex = saved['index'];
    final index = rawIndex is num ? rawIndex.toInt() : -1;
    if (track.isEmpty) {
      queue.restore(savedQueue, index, _connection == null);
      _emitChanged();
      return;
    }
    final provider = track['provider'];
    final resolved = provider is String ? provider : _api.provider;
    if (track['kind'] != 'song' || resolved != _api.provider) {
      return;
    }
    // 先恢复队列再按身份选曲，损坏的旧索引不能使下一首跳到无关位置。
    queue.restore(savedQueue, index, _connection == null);
    play(track, preview: _bool(saved['preview']), resume: saved);
  }

  static LyricsApiPort Function(String provider) _defaultLyricsApiFactory(MusicApiPort api) {
    return (provider) =>
        provider == api.provider ? _MusicApiLyricsAdapter(api) : _UnwiredLyricsApi(provider);
  }

  static String _text(Object? value) => value is String ? value : '';

  static bool _bool(Object? value) => value is bool ? value : false;

  static double _num(Object? value) => value is num ? value.toDouble() : 0;

  /// 对齐 QJsonValue::toInt()/toInteger() 的取值域。
  ///
  /// Qt 的 toInt()/toInteger() 只在 QJsonValue 是数值时返回转换结果，字符串等其它类型
  /// 返回默认值；这里的调用点字段（track bitrate/sampleRate、audio bitDepth/br 的整数用法、
  /// state ended、snapshot selectionSerial、saved index）在协议里都是整数值，
  /// 因此 num -> int 的取值不会与 Qt 产生可观察差异。
  static int _int(Object? value) => value is num ? value.toInt() : 0;

  /// 对齐 Qt QString::number(double)（默认 'g'、precision 6）的文本形式。
  ///
  /// MusicPlayer.cpp:570 把音量偏好写成 QString::number(volume)，Qt 结果形如
  /// 1 -> "1"、0.7 -> "0.7"、0.35 -> "0.35"。Dart 的 double.toString() 对整数值会给出
  /// "1.0"，与 Qt 写入的偏好串不一致，会破坏"Qt session/QSettings/AppStorage 凭据兼容"，
  /// 故在此显式还原 Qt 的整数值无小数点的行为。
  static String _numberString(double value) {
    if (value == value.roundToDouble() && value.abs() < 1e15) {
      return value.toInt().toString();
    }
    return value.toString();
  }

  static double _clamp(double value, double low, double high) =>
      value < low ? low : (value > high ? high : value);

  static Map<String, Object?> _map(Object? value) =>
      value is Map ? Map<String, Object?>.from(value) : <String, Object?>{};

  static List<Map<String, Object?>> _tracks(Object? value) => <Map<String, Object?>>[
        if (value is List)
          for (final item in value)
            if (item is Map) Map<String, Object?>.from(item),
      ];

  static bool _deepEquals(Object? left, Object? right) {
    if (left is Map && right is Map) {
      if (left.length != right.length) {
        return false;
      }
      for (final key in left.keys) {
        if (!right.containsKey(key) || !_deepEquals(left[key], right[key])) {
          return false;
        }
      }
      return true;
    }
    if (left is List && right is List) {
      if (left.length != right.length) {
        return false;
      }
      for (var index = 0; index < left.length; index++) {
        if (!_deepEquals(left[index], right[index])) {
          return false;
        }
      }
      return true;
    }
    return left == right;
  }

  static Map<String, Object?> _decodeObject(String raw) {
    if (raw.isEmpty) {
      return <String, Object?>{};
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        return Map<String, Object?>.from(decoded);
      }
    } catch (_) {
      // 偏好被外部写坏时按空缓存处理，不影响播放。
    }
    return <String, Object?>{};
  }

  static List<Map<String, Object?>> _decodeHistory(String raw) {
    final result = <Map<String, Object?>>[];
    if (raw.isEmpty) {
      return result;
    }
    Object? decoded;
    try {
      decoded = jsonDecode(raw);
    } catch (_) {
      return result;
    }
    if (decoded is! List) {
      return result;
    }
    for (final value in decoded) {
      if (value is! Map) {
        continue;
      }
      final track = Map<String, Object?>.from(value);
      if (track['kind'] == 'song' && _identifier.hasMatch(_text(track['id']))) {
        result.add(track);
        if (result.length == historyLimit) {
          break;
        }
      }
    }
    return result;
  }

  static String _encodeCompact(Object? value) => jsonEncode(value);

  static bool _isLocalFile(String url) {
    final uri = Uri.tryParse(url);
    return uri != null && uri.scheme == 'file';
  }

  static String _localPath(String url) {
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'file') {
      return '';
    }
    try {
      return uri.toFilePath();
    } catch (_) {
      return '';
    }
  }

  static String _urlPath(String url) {
    final uri = Uri.tryParse(url);
    return uri == null ? '' : uri.path;
  }

  static String _fileName(String url) {
    final path = _urlPath(url);
    final slash = path.lastIndexOf('/');
    return slash >= 0 ? path.substring(slash + 1) : path;
  }

  static String _extension(String path) {
    final slash = path.lastIndexOf('/');
    final name = slash >= 0 ? path.substring(slash + 1) : path;
    final dot = name.lastIndexOf('.');
    return dot >= 0 ? name.substring(dot + 1).toLowerCase() : '';
  }

  static String _baseName(String path) {
    final slash = path.lastIndexOf('/');
    final name = slash >= 0 ? path.substring(slash + 1) : path;
    final dot = name.lastIndexOf('.');
    return (dot > 0 ? name.substring(0, dot) : name).toLowerCase();
  }
}

/// 把 [MusicPlayerHostPort] 适配成歌词领域需要的宿主端口。
class _PlayerLyricsHost implements LyricsHostPort {
  const _PlayerLyricsHost(this._host);

  final MusicPlayerHostPort _host;

  @override
  String preference(String key) => _host.preference(key);

  @override
  void setPreference(String key, String value) => _host.setPreference(key, value);

  @override
  Future<String> loadCover(String url) => _host.loadCover(url);

  @override
  Future<Map<String, Object?>> requestJson(String path, Map<String, Object?> params) =>
      _host.requestJson(path, params);

  @override
  void schedule(int delayMs, void Function() action) => _host.schedule(delayMs, action);
}

/// 用播放器自己的音乐接口驱动歌词请求，失败以异常交给歌词层。
class _MusicApiLyricsAdapter implements LyricsApiPort {
  const _MusicApiLyricsAdapter(this._api);

  final MusicApiPort _api;

  @override
  String get provider => _api.provider;

  @override
  Future<Object?> call(String method, List<Object?> args) async {
    final result = await _api.call(method, args);
    if (!result.ok) {
      throw MusicApiException(result.error);
    }
    return result.value;
  }
}

/// 宿主未接线时的歌词接口占位：调用即失败，不伪造任何歌词数据。
///
/// 生产宿主必须通过 MusicPlayer 的 lyricsApiFactory 完成四来源接线
/// （架构门上仍是 ARCH_BLOCKED，属于宿主接线缺口，不是本模块可补的像素证据）。
class _UnwiredLyricsApi implements LyricsApiPort {
  const _UnwiredLyricsApi(this.provider);

  @override
  final String provider;

  @override
  Future<Object?> call(String method, List<Object?> args) {
    throw StateError('歌词接口未接线：' + provider + '.' + method);
  }
}
