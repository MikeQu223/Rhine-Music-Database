/// 歌词控制器测试（**未执行**：本任务禁止 flutter test / dart test / dart analyze）。
///
/// RED/GREEN 状态：全部用例仅静态编写，未运行——不得据此宣称通过。
/// 证据源：Qt/src/LyricsController.h（84 行）、Qt/src/LyricsController.cpp（661 行）、
/// Qt/src/MusicApi.cpp（call/send 参数语义）。
///
/// 覆盖计划 Pass 条件「歌词偏移」与缓存不变量，逐条对应 Qt 源行号：
/// 1. trackKey 三种形态                    → LyricsController.cpp:78-84
/// 2. validDocument 逐项过滤                → :86-102
/// 3. activeLineIndex 偏移求和与 upper_bound → :117-131
/// 4. sameRecording siren 与非 siren 分支    → :104-115
/// 5. 构造全局偏移读取与 ±10000 夹取          → :55-65
/// 6. 构造缓存恢复：过滤非法 + 上限 12        → :66-75
/// 7. load 同曲保留位置/偏移，异曲回全局      → :242-254
/// 8. load 缓存命中不发请求                  → :264-277
/// 9. accept 缓存前置/去重/上限              → :470-486
/// 10. persist 240000 UTF-16 截断            → :492-499
/// 11. sync 仅在行号变化时 emit              → :501-509
/// 12. adjustOffset ±10000 夹取              → :511-518
/// 13. resetOffset 0 时不动                  → :520-531
/// 14. applyGlobalOffset 持久化与相等短路     → :533-544
/// 15. clear/clearCache 不 emit              → :133-158
/// 16. playbackSnapshot 往返 + 不重建 starts  → :639-661
/// 17. remoteCommand 转发并应用快照           → :629-637
/// 18. siren→netease 1500ms 节流             → :352-363
/// 19. siren 限流 60s + 重试墙钟             → :369-377、:456-458
/// 20. 封面 songs 详情 args=[[id]]           → :197-224（+ MusicDirectory.cpp:352）
///
/// 测试不触碰真实网络/文件系统/偏好：全部端口以内存替身实现。
library;

import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/domain/lyrics/lyrics_controller.dart';

/// 宿主端口替身：偏好、封面、桥请求、定时器全部内存化。
class FakeLyricsHost implements LyricsHostPort {
  FakeLyricsHost([Map<String, String>? initial]) {
    if (initial != null) {
      preferences.addAll(initial);
    }
  }

  final Map<String, String> preferences = <String, String>{};
  final List<Map<String, Object?>> writes = <Map<String, Object?>>[];
  final List<String> coverRequests = <String>[];
  final Map<String, String> coverImages = <String, String>{};
  final List<String> jsonPaths = <String>[];
  final List<Map<String, Object?>> jsonParameters = <Map<String, Object?>>[];
  final List<void Function()> timers = <void Function()>[];
  final List<int> timerDelays = <int>[];
  Map<String, Object?> jsonResponse = <String, Object?>{};
  Object? jsonFailure;

  @override
  String preference(String key) => preferences[key] ?? '';

  @override
  void setPreference(String key, String value) {
    preferences[key] = value;
    writes.add(<String, Object?>{'key': key, 'value': value});
  }

  @override
  Future<String> loadCover(String url) async {
    coverRequests.add(url);
    return coverImages[url] ?? '';
  }

  @override
  Future<Map<String, Object?>> requestJson(String path, Map<String, Object?> params) async {
    jsonPaths.add(path);
    jsonParameters.add(params);
    final failure = jsonFailure;
    if (failure != null) {
      throw failure;
    }
    return jsonResponse;
  }

  @override
  void schedule(int delayMs, void Function() action) {
    timerDelays.add(delayMs);
    timers.add(action);
  }

  /// 立即执行已排队的定时回调（Qt QTimer::singleShot 的替身）。
  void runTimers() {
    final pending = List<void Function()>.of(timers);
    timers.clear();
    for (final action in pending) {
      action();
    }
  }
}

/// 歌词接口替身：记录 method/args；handler 优先，其次 fail，最后空对象。
class FakeLyricsApi implements LyricsApiPort {
  FakeLyricsApi(this.provider);

  @override
  final String provider;

  final List<Map<String, Object?>> calls = <Map<String, Object?>>[];
  Future<Object?> Function(String method, List<Object?> args)? handler;
  bool fail = false;

  @override
  Future<Object?> call(String method, List<Object?> args) async {
    calls.add(<String, Object?>{'operation': method, 'arguments': args});
    final custom = handler;
    if (custom != null) {
      return custom(method, args);
    }
    if (fail) {
      throw StateError('offline');
    }
    return <String, Object?>{};
  }

  List<Map<String, Object?>> callsOf(String operation) => <Map<String, Object?>>[
        for (final entry in calls)
          if (entry['operation'] == operation) entry,
      ];
}

/// 播放连接替身：只记录命令，快照由测试直接设定。
class FakeLyricsRemote implements LyricsRemotePort {
  final List<Map<String, Object?>> commands = <Map<String, Object?>>[];
  Map<String, Object?> data = <String, Object?>{};

  @override
  void call(String method, Map<String, Object?> arguments) {
    commands.add(<String, Object?>{'method': method, 'arguments': arguments});
  }

  @override
  Map<String, Object?> get snapshot => data;
}

/// sidecar 读取替身：Qt loadLocal 里同步 QFile 读取的注入点。
class FakeLocalFiles implements LyricsLocalFilePort {
  final Map<String, List<int>> files = <String, List<int>>{};
  final List<String> reads = <String>[];

  @override
  Future<List<int>?> readLocalBytes(String path) async {
    reads.add(path);
    return files[path];
  }
}

/// 构造控制器：四个 provider 共用一个注册表，便于断言调用。
LyricsController buildLyrics(
  FakeLyricsHost host, {
  Map<String, FakeLyricsApi>? apis,
  FakeLyricsRemote? remote,
  FakeLocalFiles? files,
}) {
  final registry = apis ?? <String, FakeLyricsApi>{};
  return LyricsController(
    host,
    apiFactory: (String provider) => registry.putIfAbsent(provider, () => FakeLyricsApi(provider)),
    remote: remote,
    localFiles: files,
  );
}

/// 让所有已排队的微任务/未 await 的 Future 跑完。
Future<void> settle() async {
  for (var index = 0; index < 8; index++) {
    await Future<void>.delayed(Duration.zero);
  }
}

Map<String, Object?> song(
  String id, {
  String provider = 'netease',
  String title = '歌',
  String artist = '歌手',
  String album = '',
  double duration = 200000,
  String? cover,
  String? path,
  String? localLyrics,
  String? fingerprint,
}) =>
    <String, Object?>{
      'kind': 'song',
      'id': id,
      'provider': provider,
      'title': title,
      'artist': artist,
      'album': album,
      'duration': duration,
      if (cover != null) 'cover': cover,
      if (path != null) 'path': path,
      if (localLyrics != null) 'localLyrics': localLyrics,
      if (fingerprint != null) 'fingerprint': fingerprint,
    };

/// 合法歌词文档；行起始时间与文档偏移可调。
Map<String, Object?> lyricsDocument({
  List<double> starts = const <double>[1000, 2000],
  double offsetMs = 0,
  String timing = 'line',
  String source = 'netease',
  String plainText = '',
  int version = 1,
}) =>
    <String, Object?>{
      'version': version,
      'timing': timing,
      'offsetMs': offsetMs,
      'plainText': plainText,
      'source': source,
      'lines': <Object?>[
        for (var index = 0; index < starts.length; index++)
          <String, Object?>{'startMs': starts[index], 'text': 'L' + index.toString()},
      ],
    };

Map<String, Object?> cacheEntry(String key, Map<String, Object?> document) =>
    <String, Object?>{'key': key, 'document': document};

void main() {
  group('静态语义', () {
    test('trackKey：缺省 netease、本地追加 fingerprint、空曲目为空串', () {
      // Qt 证据：LyricsController.cpp:78-84。
      expect(LyricsController.trackKey(<String, Object?>{}), '');
      expect(LyricsController.trackKey(<String, Object?>{'id': '42'}), 'netease:42');
      expect(
        LyricsController.trackKey(<String, Object?>{'id': '42', 'provider': 'qq'}),
        'qq:42',
      );
      expect(
        LyricsController.trackKey(<String, Object?>{
          'id': '9',
          'provider': 'local',
          'fingerprint': 'abc',
        }),
        'local:9:abc',
      );
    });

    test('validDocument：版本/时序/行数/字段类型/有限数逐项过滤', () {
      // Qt 证据：LyricsController.cpp:86-102。
      expect(LyricsController.validDocument(lyricsDocument()), isTrue);
      // version 1.9 经 QJsonValue::toInt 截断为 1。
      expect(
        LyricsController.validDocument(lyricsDocument()..['version'] = 1.9),
        isTrue,
      );
      expect(LyricsController.validDocument(lyricsDocument(version: 2)), isFalse);
      expect(LyricsController.validDocument(lyricsDocument(timing: 'sentence')), isFalse);
      // 空行数组合法（只有 size>5000 才拒绝）。
      expect(
        LyricsController.validDocument(lyricsDocument()..['lines'] = <Object?>[]),
        isTrue,
      );
      expect(
        LyricsController.validDocument(lyricsDocument()..['lines'] = 'x'),
        isFalse,
      );
      expect(
        LyricsController.validDocument(
          lyricsDocument()
            ..['lines'] = List<Object?>.generate(
              5001,
              (int index) => <String, Object?>{'startMs': index.toDouble(), 'text': 'x'},
            ),
        ),
        isFalse,
      );
      expect(
        LyricsController.validDocument(lyricsDocument()..remove('plainText')),
        isFalse,
      );
      expect(
        LyricsController.validDocument(lyricsDocument()..['offsetMs'] = '0'),
        isFalse,
      );
      expect(
        LyricsController.validDocument(
          lyricsDocument()
            ..['lines'] = <Object?>[
              <String, Object?>{'startMs': double.nan, 'text': 'x'},
            ],
        ),
        isFalse,
      );
      expect(
        LyricsController.validDocument(
          lyricsDocument()
            ..['lines'] = <Object?>[
              <String, Object?>{'startMs': 1.0, 'text': 2},
            ],
        ),
        isFalse,
      );
    });

    test('activeLineIndex：位置+文档偏移+当前偏移，upper_bound-1', () {
      // Qt 证据：LyricsController.cpp:117-131。
      final document = lyricsDocument(
        starts: <double>[1000, 2000, 2000, 3000],
        offsetMs: 500,
      );
      expect(LyricsController.activeLineIndex(document, 0), -1);
      expect(LyricsController.activeLineIndex(document, 500), 0);
      expect(LyricsController.activeLineIndex(document, 1000), 0);
      // 重复起始时间：upper_bound 落在最后一个相等项之后。
      expect(LyricsController.activeLineIndex(document, 1500), 2);
      expect(LyricsController.activeLineIndex(document, 3000), 3);
      // 第三参数是当前曲目偏移，与文档偏移叠加。
      expect(LyricsController.activeLineIndex(document, 0, 1000), 0);
    });

    test('sameRecording：siren 只比标题与版本，其余要求歌手集合与时长', () {
      // Qt 证据：LyricsController.cpp:104-115。
      final siren = song('s', provider: 'siren', title: '晴天', duration: 0);
      expect(
        LyricsController.sameRecording(siren, song('c', title: '晴天', artist: '别人', duration: 0)),
        isTrue,
      );

      final track = song('a', title: '晴天', duration: 200000);
      expect(
        LyricsController.sameRecording(track, song('b', title: '晴天', duration: 201000)),
        isTrue,
      );
      expect(
        LyricsController.sameRecording(track, song('b', title: '晴天', duration: 202001)),
        isFalse,
      );
      expect(
        LyricsController.sameRecording(track, song('b', title: '晴天', duration: 0)),
        isFalse,
      );
      expect(
        LyricsController.sameRecording(track, song('b', title: '晴天', artist: '其他', duration: 200000)),
        isFalse,
      );
      // 版本关键词不同：live 版不能当作录音室版。
      expect(
        LyricsController.sameRecording(track, song('b', title: '晴天 (Live)', duration: 200000)),
        isFalse,
      );
      // 空歌手集合直接判否（Qt:112 !sourceArtists.isEmpty()）。
      final noArtists = <String, Object?>{'id': 'x', 'title': '晴天', 'duration': 200000.0};
      expect(
        LyricsController.sameRecording(noArtists, song('b', title: '晴天', duration: 200000)),
        isFalse,
      );
    });
  });

  group('构造与偏好', () {
    test('构造：全局偏移读取失败按 0，越界夹取 ±10000', () {
      // Qt 证据：LyricsController.cpp:55-65。
      final fallback = buildLyrics(
        FakeLyricsHost(<String, String>{'lyrics-global-offset-ms': 'abc'}),
      );
      expect(fallback.globalOffsetMs, 0);
      expect(fallback.offsetMs, 0);

      final high = buildLyrics(
        FakeLyricsHost(<String, String>{'lyrics-global-offset-ms': '25000'}),
      );
      expect(high.globalOffsetMs, 10000);
      expect(high.offsetMs, 10000);

      final low = buildLyrics(
        FakeLyricsHost(<String, String>{'lyrics-global-offset-ms': '-25000'}),
      );
      expect(low.globalOffsetMs, -10000);
      expect(low.offsetMs, -10000);
    });

    test('构造：缓存只保留合法文档且最多 12 条', () async {
      // Qt 证据：LyricsController.cpp:66-75（逐条 validDocument + CACHE_LIMIT 12）。
      final entries = <Map<String, Object?>>[
        for (var index = 0; index < 13; index++)
          cacheEntry('netease:' + index.toString(), lyricsDocument()),
        cacheEntry('netease:bad', <String, Object?>{'version': 1}),
      ];
      final host = FakeLyricsHost(<String, String>{'lyrics-cache': jsonEncode(entries)});
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(host, apis: apis);

      // 第 12 条（netease:11）仍在缓存内：命中不发请求。
      await controller.load(song('11'));
      expect(controller.status, 'ready');
      expect(apis, isEmpty);

      // 第 13 条（netease:12）被 CACHE_LIMIT 截断：走网络分支。
      await controller.load(song('12'));
      expect(apis['netease']?.callsOf('lyrics').length, 1);

      // 非法文档（netease:bad）未入缓存：同样走网络分支。
      await controller.load(song('bad'));
      expect(apis['netease']?.callsOf('lyrics').length, 2);
    });
  });

  group('读取与缓存', () {
    test('load：同曲保留播放位置与偏移，异曲回全局偏移', () async {
      // Qt 证据：LyricsController.cpp:242-254。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-global-offset-ms': '500',
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
          cacheEntry('netease:b', lyricsDocument()),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      controller.sync(3000);
      controller.adjustOffset(100);
      expect(controller.positionMs, 3000);
      expect(controller.offsetMs, 600);

      await controller.load(song('a'));
      expect(controller.positionMs, 3000);
      expect(controller.offsetMs, 600);

      await controller.load(song('b'));
      expect(controller.positionMs, 0);
      expect(controller.offsetMs, 500);
    });

    test('load：缓存命中直接 accept，不发任何网络请求', () async {
      // Qt 证据：LyricsController.cpp:264-277。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument(starts: <double>[1000, 2000])),
        ]),
      });
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(host, apis: apis);
      await controller.load(song('a'));
      expect(apis, isEmpty);
      expect(controller.status, 'ready');
      expect(controller.message, '');
      expect(controller.document['trackKey'], 'netease:a');
      controller.sync(2500);
      expect(controller.index, 1);
    });

    test('accept：缓存前置插入、按 key 去重、上限 12 条', () async {
      // Qt 证据：LyricsController.cpp:470-486。
      final dedupeHost = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
          cacheEntry('netease:a', lyricsDocument(starts: <double>[1, 2])),
        ]),
      });
      final dedupe = buildLyrics(dedupeHost);
      await dedupe.load(song('a'));
      final deduped = (jsonDecode(dedupeHost.preferences['lyrics-cache']!) as List)
          .cast<Map<String, Object?>>();
      expect(deduped.length, 1);
      expect(deduped.first['key'], 'netease:a');

      final capHost = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
          for (var index = 0; index < 11; index++)
            cacheEntry('netease:x' + index.toString(), lyricsDocument()),
        ]),
      });
      final cap = buildLyrics(capHost);
      await cap.load(song('a'));
      final capped = (jsonDecode(capHost.preferences['lyrics-cache']!) as List)
          .cast<Map<String, Object?>>();
      expect(capped.length, LyricsController.cacheLimit);
      expect(capped.first['key'], 'netease:a');
      expect(capped.last['key'], 'netease:x10');
    });

    test('persist：序列化 UTF-16 长度 ≥240000 时从尾部丢缓存', () async {
      // Qt 证据：LyricsController.cpp:492-499（QString::size 为 UTF-16 单元）。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument(plainText: 'x' * 300000)),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      final stored = host.preferences['lyrics-cache']!;
      expect(stored.length < 240000, isTrue);
      expect(stored, '[]');
    });
  });

  group('同步与偏移', () {
    test('sync：位置+文档偏移+当前偏移决定行号，变化才 emit', () async {
      // Qt 证据：LyricsController.cpp:501-509。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry(
            'netease:a',
            lyricsDocument(starts: <double>[1000, 2000], offsetMs: 500),
          ),
        ]),
      });
      final controller = buildLyrics(host);
      var emits = 0;
      controller.addListener(() => emits++);
      await controller.load(song('a'));
      expect(emits, 1); // accept 自身 emit 一次
      expect(controller.index, -1); // 0+500 < 1000

      controller.sync(400); // 900 → -1，未变化
      expect(emits, 1);
      controller.sync(600); // 1100 → 0
      expect(emits, 2);
      controller.sync(1600); // 2100 → 1
      expect(emits, 3);
      controller.sync(1700); // 2200 → 1，未变化
      expect(emits, 3);
    });

    test('adjustOffset：夹取 ±10000 并重新同步', () async {
      // Qt 证据：LyricsController.cpp:511-518。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument(starts: <double>[0])),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      controller.adjustOffset(999999);
      expect(controller.offsetMs, 10000);
      controller.adjustOffset(-999999);
      expect(controller.offsetMs, -10000);
    });

    test('resetOffset：已是 0 时不动也不 emit', () async {
      // Qt 证据：LyricsController.cpp:520-531。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      var emits = 0;
      controller.addListener(() => emits++);
      controller.resetOffset();
      expect(emits, 0);
      expect(controller.offsetMs, 0);

      controller.adjustOffset(250);
      expect(controller.offsetMs, 250);
      emits = 0;
      controller.resetOffset();
      expect(controller.offsetMs, 0);
      expect(emits, 1);
    });

    test('applyGlobalOffset：写入 lyrics-global-offset-ms 并 emit，相等时短路', () async {
      // Qt 证据：LyricsController.cpp:533-544。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      controller.adjustOffset(1500);
      var emits = 0;
      controller.addListener(() => emits++);
      controller.applyGlobalOffset();
      expect(controller.globalOffsetMs, 1500);
      expect(host.preferences['lyrics-global-offset-ms'], '1500');
      expect(emits, 1);

      controller.applyGlobalOffset();
      expect(emits, 1);
    });
  });

  group('生命周期与快照', () {
    test('clear/clearCache：清空状态与缓存，均不 emit', () async {
      // Qt 证据：LyricsController.cpp:133-158。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument()),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      var emits = 0;
      controller.addListener(() => emits++);

      controller.clear();
      expect(emits, 0);
      expect(controller.status, 'idle');
      expect(controller.document, isEmpty);
      expect(controller.currentKey, '');
      expect(controller.index, -1);
      expect(controller.offsetMs, controller.globalOffsetMs);
      expect(controller.positionMs, 0);

      controller.clearCache();
      expect(emits, 0);
      expect(host.preferences['lyrics-cache'], '[]');
    });

    test('playbackSnapshot/applyPlaybackSnapshot：字段往返且不重建 starts', () async {
      // Qt 证据：LyricsController.cpp:639-661。
      final host = FakeLyricsHost(<String, String>{
        'lyrics-cache': jsonEncode(<Map<String, Object?>>[
          cacheEntry('netease:a', lyricsDocument(starts: <double>[1000, 2000])),
        ]),
      });
      final controller = buildLyrics(host);
      await controller.load(song('a'));
      controller.sync(2500);
      final snapshot = controller.playbackSnapshot();
      expect(snapshot.keys.toSet(), <String>{
        'document',
        'status',
        'message',
        'key',
        'index',
        'offsetMs',
        'positionMs',
        'globalOffsetMs',
        'localSource',
      });
      expect(snapshot['key'], 'netease:a');
      expect(snapshot['status'], 'ready');
      expect(snapshot['index'], 1);

      final other = buildLyrics(FakeLyricsHost());
      other.applyPlaybackSnapshot(snapshot);
      expect(other.currentKey, 'netease:a');
      expect(other.status, 'ready');
      expect(other.index, 1);
      expect(other.document['trackKey'], 'netease:a');
      // 快照不重建 m_starts（Qt:651-661 原样覆盖文档），因此本端 sync 无行可用。
      other.sync(2500);
      expect(other.index, -1);
    });

    test('remoteCommand：有连接时转发 lyrics.* 并应用快照', () async {
      // Qt 证据：LyricsController.cpp:629-637。
      final remote = FakeLyricsRemote()
        ..data = <String, Object?>{
          'lyrics': <String, Object?>{
            'document': lyricsDocument(),
            'status': 'ready',
            'message': '',
            'key': 'netease:a',
            'index': 0,
            'offsetMs': 120.0,
            'positionMs': 800.0,
            'globalOffsetMs': 0.0,
            'localSource': 'auto',
          },
        };
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(FakeLyricsHost(), apis: apis, remote: remote);
      await controller.load(song('a'));
      expect(apis, isEmpty); // 有连接时不在本地读取
      expect(remote.commands.length, 1);
      expect(remote.commands.first['method'], 'lyrics.load');
      final arguments = remote.commands.first['arguments'] as Map<String, Object?>;
      expect(arguments['retry'], isFalse);
      expect(controller.currentKey, 'netease:a');
      expect(controller.offsetMs, 120);
      expect(controller.positionMs, 800);

      controller.adjustOffset(30);
      expect(remote.commands.last['method'], 'lyrics.offset');
      final offsetArguments = remote.commands.last['arguments'] as Map<String, Object?>;
      expect(offsetArguments['value'], 30.0);
    });
  });

  group('来源补缺与封面', () {
    test('search：siren→netease 两次请求间隔不足 1500ms 时经 schedule 排队', () async {
      // Qt 证据：LyricsController.cpp:352-363。
      final host = FakeLyricsHost();
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(host, apis: apis);
      apis['netease'] = FakeLyricsApi('netease')
        ..handler = (String method, List<Object?> args) async {
          if (method == 'search') {
            return <String, Object?>{
              'items': <Object?>[
                <String, Object?>{
                  'id': 'c1',
                  'title': '歌',
                  'artist': '歌手',
                  'duration': 200000.0,
                },
              ],
            };
          }
          return lyricsDocument(starts: <double>[1000]);
        };

      // 给足封面，避免“缺封面 → 补封面 → 再次 search”的支线干扰节流断言。
      await controller.load(song('a', provider: 'siren', cover: 'https://cdn/a.jpg'));
      expect(controller.status, 'ready');
      expect(apis['netease']!.callsOf('search').length, 1);
      expect(host.timers, isEmpty);

      final second = controller.load(song('b', provider: 'siren', cover: 'https://cdn/b.jpg'));
      await settle();
      // 仍在等定时器：没有第二次 search。
      expect(apis['netease']!.callsOf('search').length, 1);
      expect(host.timerDelays, isNotEmpty);
      expect(host.timerDelays.last, greaterThan(0));
      expect(host.timerDelays.last, lessThanOrEqualTo(1500));

      host.runTimers();
      await second;
      expect(apis['netease']!.callsOf('search').length, 2);
    });

    test('search：siren 网易云失败后限流 60s，重试墙钟内二次读取直接 empty', () async {
      // Qt 证据：LyricsController.cpp:369-377（失败置 60s 限流）、:456-458（重试墙钟）。
      final host = FakeLyricsHost();
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(host, apis: apis);
      final api = FakeLyricsApi('netease')..fail = true;
      apis['netease'] = api;

      await controller.load(song('a', provider: 'siren'));
      expect(controller.status, 'error');
      expect(controller.message, '暂无歌词（网易云暂时限流）');
      expect(api.callsOf('search').length, 1);

      await controller.load(song('a', provider: 'siren'));
      expect(controller.status, 'empty');
      expect(controller.message, '暂无歌词');
      expect(api.callsOf('search').length, 1); // 重试墙钟内不再请求
    });

    test('封面：候选缺 cover 时用 songs 详情（args=[[id]]）并回调 coverMatched', () async {
      // Qt 证据：LyricsController.cpp:197-224；songs 首参是 id 数组
      // （MusicDirectory.cpp:352、MusicLibrary.cpp:704）。
      final host = FakeLyricsHost();
      final apis = <String, FakeLyricsApi>{};
      final controller = buildLyrics(host, apis: apis);
      final local = song(
        'l1',
        provider: 'local',
        title: '歌',
        artist: '歌手',
        duration: 200000,
        path: '/music/a.mp3',
        fingerprint: 'fp',
      );
      controller.applyPlaybackSnapshot(<String, Object?>{
        'key': LyricsController.trackKey(local),
      });
      host.coverImages['https://cdn/cover.jpg'] = 'image';
      apis['netease'] = FakeLyricsApi('netease')
        ..handler = (String method, List<Object?> args) async {
          if (method == 'search') {
            return <String, Object?>{
              'items': <Object?>[
                <String, Object?>{
                  'id': 'c1',
                  'title': '歌',
                  'artist': '歌手',
                  'duration': 200000.0,
                },
              ],
            };
          }
          if (method == 'songs') {
            return <Object?>[
              <String, Object?>{
                'id': 'c1',
                'title': '歌',
                'artist': '歌手',
                'duration': 200000.0,
                'cover': 'https://cdn/cover.jpg',
              },
            ];
          }
          return <String, Object?>{};
        };

      final matched = <String>[];
      controller.addCoverMatchedListener(
        (String key, String url) => matched.add(key + '|' + url),
      );
      await controller.matchCover(local);
      await settle();

      final songs = apis['netease']!.callsOf('songs');
      expect(songs, isNotEmpty);
      final arguments = songs.first['arguments'] as List<Object?>;
      expect(arguments.length, 1);
      expect(arguments.first, <Object?>['c1']);
      expect(matched, <String>['local:l1:fp|https://cdn/cover.jpg']);
    });
  });
}
