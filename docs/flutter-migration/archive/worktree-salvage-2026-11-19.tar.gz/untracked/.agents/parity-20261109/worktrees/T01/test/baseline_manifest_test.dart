// T01 基线出处 manifest 断言。
//
// 状态：T01-F01（atom T01-F01-M15）编写、T01-C18 增补精确冻结与身份链交叉断言，
// **均未执行**（RED/GREEN 皆未运行）。本轮禁令不允许
// 'flutter test' / 'dart analyze' / 任何构建，因此本文件只固化断言，
// 不得被报告为“通过”。获准执行时的命令：
//   flutter test test/baseline_manifest_test.dart
//
// 字段契约来源：docs/flutter-migration/00-baseline.md §12。
// 本测试只读 fixture；不生成路径、快照或像素结论。

import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

const String _manifestPath = 'test/fixtures/baseline_manifest.json';

final RegExp _hex12 = RegExp(r'^[0-9a-f]{12}$');
final RegExp _hex16 = RegExp(r'^[0-9a-f]{16}$');
final RegExp _hex40 = RegExp(r'^[0-9a-f]{40}$');
final RegExp _hex64 = RegExp(r'^[0-9a-f]{64}$');
final RegExp _sha256ColonUpper = RegExp(r'^([0-9A-F]{2}:){31}[0-9A-F]{2}$');
final RegExp _sha1ColonUpper = RegExp(r'^([0-9A-F]{2}:){19}[0-9A-F]{2}$');

Map<String, dynamic> _map(Map<String, dynamic> parent, String key) {
  final Object? value = parent[key];
  expect(value, isA<Map>(), reason: '$key 必须是 JSON 对象');
  return (value! as Map).cast<String, dynamic>();
}

List<dynamic> _list(Map<String, dynamic> parent, String key) {
  final Object? value = parent[key];
  expect(value, isA<List>(), reason: '$key 必须是 JSON 数组');
  return value! as List<dynamic>;
}

int _int(Map<String, dynamic> parent, String key) {
  final Object? value = parent[key];
  expect(value, isA<int>(), reason: '$key 必须是整数');
  return value! as int;
}

void _nonEmpty(Map<String, dynamic> parent, String key, {String label = ''}) {
  final String where = label.isEmpty ? key : '$label.$key';
  final Object? value = parent[key];
  expect(value, isA<String>(), reason: '$where 必须是字符串');
  expect((value! as String).trim(), isNotEmpty, reason: '$where 不得为空');
}

void _matches(Object? value, RegExp pattern, String label) {
  expect(value, isA<String>(), reason: '$label 必须是字符串');
  expect(pattern.hasMatch(value! as String), isTrue,
      reason: '$label 格式不符：$value');
}

Map<String, dynamic> _loadManifest() {
  final File file = File(_manifestPath);
  expect(file.existsSync(), isTrue, reason: 'fixture 缺失：$_manifestPath');
  final Object? decoded = jsonDecode(file.readAsStringSync());
  expect(decoded, isA<Map>(), reason: 'fixture 顶层必须是 JSON 对象');
  return (decoded! as Map).cast<String, dynamic>();
}

void main() {
  final Map<String, dynamic> manifest = _loadManifest();

  group('§12.1 顶层键', () {
    test('schemaVersion / task / generatedAt', () {
      expect(manifest['schemaVersion'], 1);
      expect(manifest['task'], 'T01');
      _nonEmpty(manifest, 'generatedAt');
    });

    test('冻结坐标 repo / worktree / branch', () {
      _nonEmpty(manifest, 'repo');
      _nonEmpty(manifest, 'worktree');
      expect(manifest['branch'], 'flutter/p0-t01-baseline');
    });

    test('baselineCommit 与历史基线', () {
      _matches(manifest['baselineCommit'], _hex40, 'baselineCommit');
      expect(manifest['baselineCommit'], '8ed3067b0812eb2612f7841ec127a6e8ca93231b');
      expect(manifest['planHistoricalBaseline'], '89493eb3c3d2c1e6c050891718134ac7670e4d6c');
      _matches(manifest['worktreeHeadAtAuthoring'], _hex40, 'worktreeHeadAtAuthoring');
    });

    test('顶层键集合恰为契约的 25 个键', () {
      // 新增/删除顶层键必须同步修改 docs §12.1 与本断言，否则此处变红。
      expect(
        manifest.keys.toSet(),
        unorderedEquals(<String>{
          'schemaVersion', 'task', 'generatedAt',
          'repo', 'worktree', 'branch',
          'baselineCommit', 'planHistoricalBaseline',
          'apk', 'certificate', 'qtSource', 'buildIdentity', 'nativeChain',
          'manifest', 'device', 'installation', 'screenshots', 'gaps',
          'pixelBaseline', 'testExecution',
          'generatedBy', 'baselineCommitSource', 'worktreeHeadAtAuthoring',
          'worktreeHeadAtAuthoringNote', 'provenanceNotes',
        }),
      );
    });
  });

  group('§12.1 apk 与 §12.2 哈希/版本断言', () {
    test('必填字段非空且哈希为 64 位小写十六进制', () {
      final apk = _map(manifest, 'apk');
      _nonEmpty(apk, 'path', label: 'apk');
      expect(apk['path'] as String, endsWith('.apk'));
      _nonEmpty(apk, 'mtime', label: 'apk');
      _nonEmpty(apk, 'sha256', label: 'apk');
      _matches(apk['sha256'], _hex64, 'apk.sha256');
      // 精确冻结：只验格式时任何 64 位十六进制都会通过，钉不住基线产物。
      expect(apk['sha256'],
          'bd58d95a5edee4c66a9704a108fb335163dc4274239b5f32b2a0c4cb221b5a1e');
      expect(_int(apk, 'sizeBytes'), 73776456);
      expect(apk['abi'], 'arm64-v8a');
      expect(apk['topLevelApkCount'], 1);
      expect(apk['package'], 'rhine.music.database');
      _nonEmpty(apk, 'versionName', label: 'apk');
    });

    test('versionCode >= 1，targetSdk >= minSdk', () {
      final apk = _map(manifest, 'apk');
      expect(_int(apk, 'versionCode'), greaterThanOrEqualTo(1));
      final int minSdk = _int(apk, 'minSdk');
      final int targetSdk = _int(apk, 'targetSdk');
      expect(targetSdk, greaterThanOrEqualTo(minSdk));
    });
  });

  group('§12.1 certificate', () {
    test('证书全值非空且格式成立', () {
      final cert = _map(manifest, 'certificate');
      _matches(cert['sha256'], _sha256ColonUpper, 'certificate.sha256');
      _matches(cert['sha256Compact'], _hex64, 'certificate.sha256Compact');
      _matches(cert['sha1'], _sha1ColonUpper, 'certificate.sha1');
      // 两种写法必须指向同一张证书。
      expect(
        (cert['sha256']! as String).replaceAll(':', '').toLowerCase(),
        cert['sha256Compact'],
      );
      for (final String key in <String>[
        'owner',
        'issuer',
        'serialNumber',
        'validFrom',
        'validTo',
        'signatureAlgorithm',
        'publicKey',
        'source',
      ]) {
        _nonEmpty(cert, key, label: 'certificate');
      }
      expect(_list(cert, 'signatureEntries'), hasLength(3));
    });
  });

  group('§12.1 qtSource', () {
    test('Qt 源码同一性坐标', () {
      final qt = _map(manifest, 'qtSource');
      _matches(qt['candidateCommit'], _hex40, 'qtSource.candidateCommit');
      _nonEmpty(qt, 'candidateCommitTitle', label: 'qtSource');
      _nonEmpty(qt, 'candidateCommitTime', label: 'qtSource');
      _matches(qt['qtTreeCandidate'], _hex40, 'qtSource.qtTreeCandidate');
      _matches(qt['qtTreeBaseline'], _hex40, 'qtSource.qtTreeBaseline');
      expect(qt['qtTreeCandidate'], qt['qtTreeBaseline']);
      expect(qt['diffStatLines'], 0);
      expect(qt['isAncestorOfBaseline'], isTrue);
    });
  });

  group('§12.1 buildIdentity 与 §12.2 commitSha', () {
    test('commitSha 为 12 位十六进制，偏移为正整数', () {
      final id = _map(manifest, 'buildIdentity');
      _nonEmpty(id, 'headerPath', label: 'buildIdentity');
      expect(_int(id, 'headerBytes'), greaterThan(0));
      _matches(id['commitSha'], _hex12, 'buildIdentity.commitSha');
      _nonEmpty(id, 'commitTitle', label: 'buildIdentity');
      final offsets = _map(id, 'stringsInPayload');
      for (final String key in <String>[
        'utf8ShaOffset',
        'utf16ShaOffset',
        'utf16TitleOffset',
      ]) {
        expect(_int(offsets, key), greaterThan(0),
            reason: 'buildIdentity.stringsInPayload.$key 必须为正');
      }
    });
  });

  group('§12.1 nativeChain 与 §12.2 同值断言', () {
    test('三段 stage 齐全且哈希格式成立', () {
      final List<Map<String, dynamic>> chain = _list(manifest, 'nativeChain')
          .map((dynamic e) => (e! as Map).cast<String, dynamic>())
          .toList();
      expect(chain, hasLength(3));
      expect(
        chain.map((Map<String, dynamic> e) => e['stage']).toList(),
        <String>['linked-unstripped', 'stripped-intermediate', 'apk-entry'],
      );
      for (final Map<String, dynamic> stage in chain) {
        _nonEmpty(stage, 'path', label: 'nativeChain[${stage['stage']}]');
        expect(_int(stage, 'sizeBytes'), greaterThan(0));
        _matches(stage['sha256'], _hex64, 'nativeChain.sha256');
      }
      final Map<String, dynamic> stripped = chain
          .firstWhere((Map<String, dynamic> e) => e['stage'] == 'stripped-intermediate');
      final Map<String, dynamic> entry =
          chain.firstWhere((Map<String, dynamic> e) => e['stage'] == 'apk-entry');
      final Map<String, dynamic> unstripped =
          chain.firstWhere((Map<String, dynamic> e) => e['stage'] == 'linked-unstripped');
      expect(entry['sha256'], stripped['sha256']);
      expect(entry['sizeBytes'], stripped['sizeBytes']);
      expect(unstripped['sizeBytes'] as int,
          greaterThan(stripped['sizeBytes'] as int));
    });
  });

  group('§12.1 manifest 与 §12.2 四项精确匹配', () {
    test('sensorLandscape / false / false / 0x00030000', () {
      final mf = _map(manifest, 'manifest');
      _nonEmpty(mf, 'sourcePath', label: 'manifest');
      _nonEmpty(mf, 'mergedPath', label: 'manifest');
      expect(mf['screenOrientation'], 'sensorLandscape');
      expect(mf['allowBackup'], isFalse);
      expect(mf['resizeableActivity'], isFalse);
      expect(mf['glesVersion'], '0x00030000');
      expect(mf['glesRequired'], isTrue);
    });
  });

  group('§12.1 device', () {
    test('设备坐标非空且 serial 冻结', () {
      final device = _map(manifest, 'device');
      expect(device['serial'], '526f6b6d');
      expect(device['abi'], 'arm64-v8a');
      expect(_int(device, 'density'), greaterThan(0));
      expect(_int(device, 'apiLevel'), greaterThan(0));
      for (final String key in <String>[
        'model',
        'androidVersion',
        'physicalResolution',
        'fingerprint',
      ]) {
        _nonEmpty(device, key, label: 'device');
      }
    });
  });

  group('§12.1 installation 与 §12.2 安装事实', () {
    test('安装前不存在、未卸载、未清数据、增量安装成功', () {
      final install = _map(manifest, 'installation');
      expect(install['preinstallPackageAbsent'], isTrue);
      expect(install['uninstallPerformed'], isFalse);
      expect(install['clearDataPerformed'], isFalse);
      expect(install['incremental'], isTrue);
      expect(install['success'], isTrue);
      expect(_int(install, 'durationMs'), greaterThan(0));
      _nonEmpty(install, 'command', label: 'installation');
      expect(install['command'] as String, contains('adb'));
      _nonEmpty(install, 'firstInstallTime', label: 'installation');
      _nonEmpty(install, 'lastUpdateTime', label: 'installation');
      _nonEmpty(install, 'packagePathAfterInstall', label: 'installation');
    });
  });

  group('§12.1 screenshots 与 §12.2 12 图索引', () {
    test('恰好 12 项，bytes > 0，prefix 为 16 位十六进制', () {
      final shots = _map(manifest, 'screenshots');
      expect(shots['indexAvailable'], isTrue);
      final List<dynamic> items = _list(shots, 'items');
      expect(items, hasLength(12));
      for (final dynamic raw in items) {
        final Map<String, dynamic> item = (raw! as Map).cast<String, dynamic>();
        expect(_int(item, 'id'), greaterThan(0));
        _nonEmpty(item, 'file', label: 'screenshots.items');
        _nonEmpty(item, 'capturedAt', label: 'screenshots.items');
        expect(_int(item, 'bytes'), greaterThan(0));
        _matches(item['sha256Prefix16'], _hex16, 'screenshots.items.sha256Prefix16');
      }
    });

    test('像素实体不可用：entitiesAvailable == false 且无完整哈希', () {
      final shots = _map(manifest, 'screenshots');
      expect(shots['entitiesAvailable'], isFalse);
      expect(shots['fullHashAvailable'], isFalse);
      _nonEmpty(shots, 'originalDirectory', label: 'screenshots');
      _nonEmpty(shots, 'entityStatus', label: 'screenshots');
      expect(_map(manifest, 'pixelBaseline')['status'],
          'unavailable_recapture_required');
    });
  });

  group('§12.1 gaps 与 §12.2 唯一 closed', () {
    test('G1 为 closed/artifact-level，closed 数量恰为 1', () {
      final gaps = _map(manifest, 'gaps');
      const List<String> ids = <String>[
        'G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8',
      ];
      for (final String id in ids) {
        expect(gaps.containsKey(id), isTrue, reason: '缺少 $id');
        _nonEmpty(_map(gaps, id), 'status', label: 'gaps.$id');
      }
      final Map<String, dynamic> g1 = _map(gaps, 'G1');
      expect(g1['status'], 'closed');
      expect(g1['scope'], 'artifact-level');
      final List<String> closed = ids
          .where((String id) => _map(gaps, id)['status'] == 'closed')
          .toList();
      expect(closed, <String>['G1'],
          reason: '本 fixture 只允许 G1 为 closed；改状态必须显式改 fixture 并让测试失败');
    });
  });

  group('§12.2 身份链交叉校验', () {
    test('commitSha 是 candidateCommit 前缀，且出现在 APK 路径中', () {
      final Map<String, dynamic> qt = _map(manifest, 'qtSource');
      final Map<String, dynamic> build = _map(manifest, 'buildIdentity');
      final Map<String, dynamic> apk = _map(manifest, 'apk');
      final String candidate = qt['candidateCommit']! as String;
      final String short = build['commitSha']! as String;
      _matches(short, _hex12, 'buildIdentity.commitSha');
      expect(candidate.startsWith(short), isTrue,
          reason: 'buildIdentity.commitSha 必须是 qtSource.candidateCommit 的前缀');
      expect(apk['path'], contains(short),
          reason: 'APK 文件名必须带候选 commit 短 SHA');
      expect(build['commitTitle'], qt['candidateCommitTitle'],
          reason: '两处 commit 标题必须一致');
    });

    test('安装命令指向同一 APK 与同一设备', () {
      final Map<String, dynamic> apk = _map(manifest, 'apk');
      final Map<String, dynamic> install = _map(manifest, 'installation');
      final Map<String, dynamic> device = _map(manifest, 'device');
      final String command = install['command']! as String;
      expect(command, contains(apk['path']! as String));
      expect(command, contains(device['serial']! as String));
    });
  });

  group('§12.1 testExecution', () {
    test('本 fixture 不声称任何执行/通过', () {
      final exec = _map(manifest, 'testExecution');
      expect(exec['performed'], isFalse);
      _nonEmpty(exec, 'reason', label: 'testExecution');
    });
  });
}
