package rhine.music.database.parity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * RETENTION-FIX-223：宿主 Activity 销毁后，旧场景视图必须真正从死宿主的 View 树里摘掉，
 * 迟到/陈旧的 posted create 必须按"请求位 + 世代 + 挂载状态"三重门禁放弃。
 *
 * <p>证据（HEAP-219，PID 13337，APK SHA16d1e3b86...）：6 次 Back/重开之后，被销毁的 Activity
 * 仍被 JNI_GLOBAL 强引用，持有者是 {@code RhineQtView.mContext} 与 {@code QtWindow.mContext}。
 * 也就是说 Java 侧的静态字段已经清干净，钉住者仍在 native 侧，而 native 侧的 QtWindow /
 * 根窗口是**挂在旧 QtView 上**的：只要旧 RhineQtView 还留在死宿主的 ViewGroup 里，
 * {@code QtView.onDetachedFromWindow → destroyWindow → deleteWindow} 就永远不会被调用。
 *
 * <p>这不是一个能用纯函数覆盖的决策（顺序与门禁都在既有 Android 回调里），因此本文件是
 * **源码合同 fixture**：它解析 {@code RhineQtViews.java} / {@code RhineQtView.java} 的方法体
 * （先去注释，避免注释里的字样造成假通过），断言
 * <ol>
 *   <li>销毁回调里"排释放请求"严格早于"把视图从父容器摘掉"（顺序反了就等于先拆父窗口、
 *       再用旧世代号做一次空转，或者干脆什么都不拆）；</li>
 *   <li>摘除只作用于 {@code getContext() == activity} 的同一个已销毁宿主，新宿主的视图永不被摘；</li>
 *   <li>{@code releaseSceneForHostDestroy} 先清请求位再做任何早退（没有活跃世代也必须幂等）；</li>
 *   <li>延迟 create 的 Runnable 在 {@code createEmbeddedScene} 之前同时检查
 *       {@code sceneRequested}、{@code sceneGeneration == generation}、{@code isAttachedToWindow()}；</li>
 *   <li>陈旧 Runnable 只清"仍然等于自己那一代"的本地状态，绝不抹掉新一代的请求位/世代号；</li>
 *   <li>native 声明与 Kotlin 侧吃到的 public API 保持不变（JNI 注册名与签名不能漂）。</li>
 * </ol>
 *
 * <p><b>边界：源码合同证明的是"代码形状对了"，不证明运行时 GC。</b>根到 native 的 owner
 * 映射仍未运行时确认，必须由新的 HPROF 复核（见 reports/RETENTION-FIX-223.json）。
 *
 * <p>不依赖 android.* 运行时，也不需要 Robolectric：只读文件 + JUnit 4。
 */
public class QtSceneHostRetirementContractTest {

    private static final Pattern IDENTITY_GATE =
            Pattern.compile("getContext\\(\\)\\s*==\\s*activity");

    /** 世代门禁的两种合法写法（!= 早退 或 == 内联）。断言锚在语义上，不锚在一种拼写上。 */
    private static final Pattern GENERATION_GUARD = Pattern.compile(
            "sceneGeneration\\s*(?:!=|==)\\s*generation|generation\\s*(?:!=|==)\\s*sceneGeneration");

    private static String viewsSource;
    private static String viewSource;
    private static String qtViewSource;
    private static String delegateSource;

    @BeforeClass
    public static void loadProductionSources() throws IOException {
        viewsSource = stripComments(readSource("RhineQtViews.java"));
        viewSource = stripComments(readSource("RhineQtView.java"));
        qtViewSource = stripComments(readSource("QtView.java"));
        delegateSource = stripComments(readSource("QtEmbeddedDelegate.java"));
        assertTrue("RhineQtViews.java did not load", viewsSource.length() > 5000);
        assertTrue("RhineQtView.java did not load", viewSource.length() > 2000);
        assertTrue("QtView.java did not load", qtViewSource.length() > 5000);
        assertTrue("QtEmbeddedDelegate.java did not load", delegateSource.length() > 3000);
    }

    // ------------------------------------------------------------------
    // 1) 顺序：先排释放，再摘父容器
    // ------------------------------------------------------------------

    @Test
    public void releaseIsQueuedBeforeRetiredViewIsDetachedFromDeadHost() {
        String body = requireBody(viewsSource, "private static View releaseSceneViews", "releaseSceneViews");

        // 提取控制（非空肯定性）：方法体必须真的是这个方法的体，而不是空串/半截。
        assertTrue("fixture control: releaseSceneViews body looks truncated (" + body.length() + " chars)",
                body.contains("collectQtViews") && body.contains("unregisterAppStateListener"));

        int release = body.indexOf("releaseSceneForHostDestroy");
        assertTrue("destroyed-host path must queue releaseSceneForHostDestroy()", release >= 0);

        int remove = body.indexOf("removeView(");
        assertTrue("destroyed-host path must remove the retired view from its parent: without removeView( the "
                + "old RhineQtView stays in the dead Activity's ViewGroup, so QtView.onDetachedFromWindow -> "
                + "destroyWindow -> deleteWindow never runs and the native QtWindow keeps mContext (HEAP-219)",
                remove >= 0);

        assertTrue("releaseSceneForHostDestroy() must be queued BEFORE the parent removal (release@" + release
                + ", removeView@" + remove + "): the native scene generation has to be retired first, otherwise "
                + "the detach path deletes the parent window for a scene that is still the current one",
                release < remove);
    }

    // ------------------------------------------------------------------
    // 2) 身份门禁：只摘同一个已销毁宿主的视图
    // ------------------------------------------------------------------

    @Test
    public void parentRemovalIsGatedOnTheDestroyedActivityIdentity() {
        String body = requireBody(viewsSource, "private static View releaseSceneViews", "releaseSceneViews");
        int remove = body.indexOf("removeView(");
        assertTrue("no removeView( to gate", remove >= 0);

        boolean guarded = false;
        for (IfBlock block : ifBlocks(body)) {
            if (block.start < remove && remove < block.end && IDENTITY_GATE.matcher(block.condition).find()) {
                guarded = true;
                break;
            }
        }
        assertTrue("removeView( must sit inside an if-block whose condition is getContext() == activity: "
                + "an unconditional removal over every collected view could detach a live view that already "
                + "belongs to the new host", guarded);

        assertTrue("the removal must use the view's own parent (getParent())", body.contains("getParent()"));
        assertTrue("the removal must be typed against ViewGroup before calling removeView",
                body.contains("instanceof ViewGroup"));
    }

    @Test
    public void identityGateRejectsANewerHostView() {
        // 语义控制：同一个门禁表达式在"新宿主"上必须为假，旧宿主的视图上才为真。
        Object destroyedHost = new Object();
        Object newHost = new Object();
        assertTrue(identityGateMatches(destroyedHost, destroyedHost));
        assertFalse(identityGateMatches(destroyedHost, newHost));
        assertFalse("unknown/null context must not pass the gate", identityGateMatches(destroyedHost, null));
    }

    // ------------------------------------------------------------------
    // 3) releaseSceneForHostDestroy：先清请求位，再考虑早退
    // ------------------------------------------------------------------

    @Test
    public void releaseWithoutActiveGenerationStillClearsRequestState() {
        String body = requireBody(viewSource, "public void releaseSceneForHostDestroy", "releaseSceneForHostDestroy");

        assertTrue("fixture control: releaseSceneForHostDestroy body looks truncated",
                body.contains("retireScene()"));

        int clear = body.indexOf("sceneRequested = false");
        assertTrue("releaseSceneForHostDestroy must clear sceneRequested: a destroyed host must not leave a view "
                + "that still claims 'scene requested'", clear >= 0);

        int firstReturn = body.indexOf("return");
        assertTrue("releaseSceneForHostDestroy must not early-return on !sceneRequested before clearing the request "
                + "flag (return@" + firstReturn + ", clear@" + clear + "): that leaves a stale view with a non-zero "
                + "generation which later re-sends destroyEmbeddedScene for a generation it never created",
                firstReturn < 0 || clear < firstReturn);
    }

    // ------------------------------------------------------------------
    // 4/5) 延迟 create 的三重门禁与"只清自己那一代"
    // ------------------------------------------------------------------

    @Test
    public void stalePostedCreateIsGuardedBeforeCreatingTheScene() {
        String runnable = postedCreateRunnableBody();

        int create = runnable.indexOf("createEmbeddedScene(");
        assertTrue("posted runnable must still call createEmbeddedScene(", create >= 0);

        List<String> missing = missingCreateGuards(runnable);

        assertTrue("posted zero-size create must check request flag + generation + attachment before "
                + "createEmbeddedScene, missing: " + missing, missing.isEmpty());
    }

    @Test
    public void stalePostedCreateOnlyClearsItsOwnGeneration() {
        String runnable = postedCreateRunnableBody();

        List<Integer> unguarded = unguardedRequestClears(runnable);
        assertTrue("every sceneRequested = false inside the posted runnable must be generation-scoped "
                + "(unguarded at offsets " + unguarded + "): a stale runnable that clears the flag blind wipes a "
                + "newer generation's request, and the next zero-size layout frame then creates a scene for a host "
                + "that already asked to be retired", unguarded.isEmpty());

        assertTrue("the not-attached branch of the current generation must retire its own generation number "
                + "(otherwise a later createEmbeddedScene would reuse a retired generation)",
                runnable.contains("sceneGeneration = 0"));

        assertTrue("the stale path must not send destroyEmbeddedScene( itself (retirement belongs to "
                + "releaseSceneForHostDestroy/onDetachedFromWindow)", runnable.indexOf("destroyEmbeddedScene") < 0);
    }

    // ------------------------------------------------------------------
    // 6) 不变量：native 声明与 public API 不被顺手改掉
    // ------------------------------------------------------------------

    @Test
    public void delayedQtWindowAttachmentCannotCrossViewRetirement() {
        String addWindow = requireBody(qtViewSource,
                "void addQtWindow(QtWindow window, long viewReference, long parentWindowRef,\n                     long attachmentGeneration)",
                "QtView.addQtWindow(token-aware)");
        String runnable = blockAfter(addWindow, "runOnMainThread(() ->");
        assertNotNull("could not extract addQtWindow main-thread callback", runnable);

        int attachGate = runnable.indexOf("canAttachQtWindow(parentWindowRef, attachmentGeneration)");
        int assignWindow = runnable.indexOf("m_window = window");
        int addChild = runnable.indexOf("addView(m_window");
        assertTrue("posted QtWindow callback must check attachment before assigning/adding it",
                attachGate >= 0 && attachGate < assignWindow && attachGate < addChild);
    }

    @Test
    public void detachInvalidatesQueuedQtWindowAttachmentBeforeDestroyingParent() {
        String attached = requireBody(qtViewSource, "protected void onAttachedToWindow", "QtView.onAttachedToWindow");
        String detached = requireBody(qtViewSource, "protected void onDetachedFromWindow", "QtView.onDetachedFromWindow");
        assertTrue("onAttachedToWindow must advance and publish its attachment generation",
                attached.contains("m_attachmentGeneration++")
                        && attached.contains("m_isAttached = true"));
        int invalidate = detached.indexOf("m_attachmentGeneration++");
        int markDetached = detached.indexOf("m_isAttached = false");
        int destroy = detached.indexOf("destroyWindow()");
        assertTrue("onDetachedFromWindow must invalidate posted attachments before destroying the parent",
                invalidate >= 0 && markDetached >= 0 && invalidate < destroy && markDetached < destroy);
        assertTrue("detach must leave the adopted parent reference available to destroyWindow()",
                detached.indexOf("m_parentWindowReference = 0") < 0 || destroy < detached.indexOf("m_parentWindowReference = 0"));
    }

    @Test
    public void createWindowMarshalsViewStateReadsToTheMainThread() {
        String createWindow = requireBody(viewSource,
                "protected void createWindow(final long parentWindowRef, final long attachmentToken)",
                "RhineQtView.createWindow(token-aware)");
        int dispatch = createWindow.indexOf("runOnMainThread(");
        assertTrue("Qt-thread createWindow must dispatch to the main thread before reading View state",
                dispatch >= 0 && createWindow.indexOf("getWidth()") < 0 && createWindow.indexOf("getHeight()") < 0);
        String mainThreadBody = requireBody(viewSource, "private void createWindowOnMainThread",
                "RhineQtView.createWindowOnMainThread");
        assertTrue("main-thread create path must validate attachment generation",
                mainThreadBody.contains("isCurrentAttachment(attachmentToken)"));
    }

    @Test
    public void delegateCapturesAttachmentGenerationBeforeQueuingRootCreation() {
        String addView = requireBody(delegateSource, "public void addView(QtView view)", "QtEmbeddedDelegate.addView");
        int token = addView.indexOf("view.attachmentGeneration()");
        int enqueue = addView.indexOf("QtNative.runAction(");
        assertTrue("delegate must capture the Android attachment generation before entering the Qt queue",
                token >= 0 && enqueue > token);

        String createRoot = requireBody(delegateSource, "private void createRootWindow(QtView view",
                "QtEmbeddedDelegate.createRootWindow");
        assertTrue("queued root creation must reject an obsolete attachment before requesting JNI",
                createRoot.contains("isCurrentAttachmentGeneration(attachmentGeneration)"));
        assertTrue("root-window request must carry the captured attachment token",
                createRoot.contains("requestRootWindowForAttachment(attachmentGeneration)"));
    }

    @Test
    public void delegateViewMembershipIsSynchronizedAcrossAndroidAndQtQueues() {
        String addView = requireBody(delegateSource, "public void addView(QtView view)", "QtEmbeddedDelegate.addView");
        String removeView = blockAfter(delegateSource, "public void removeView(QtView view)");
        assertNotNull("could not extract QtEmbeddedDelegate.removeView", removeView);
        String createRoot = requireBody(delegateSource, "private void createRootWindow(QtView view",
                "QtEmbeddedDelegate.createRootWindow");
        assertTrue("addView must protect HashSet membership", addView.contains("synchronized (m_views)"));
        assertTrue("removeView must protect HashSet membership", removeView.contains("synchronized (m_views)"));
        assertTrue("queued root callback must protect HashSet membership", createRoot.contains("synchronized (m_views)"));
        assertTrue("activity destruction must synchronize HashSet.clear with Qt queue lookups",
                delegateSource.matches("(?s).*synchronized \\(m_views\\) \\{\\s*m_views\\.clear\\(\\);.*"));
    }

    @Test
    public void rootWindowTokenCrossesNativeQueueAndRejectedRootIsDeletedByCreator() throws IOException {
        String nativePatch = readProjectSource("scripts/qt-android-patches.cjs");
        assertTrue("Qt patch recipe must declare a separate token-aware JNI entrypoint",
                nativePatch.contains("createRootWindowForAttachment"));
        assertTrue("Qt queued root lambda must capture attachmentGeneration",
                nativePatch.contains("[rootView, x, y, width, height, attachmentGeneration]"));
        assertTrue("native root callback must hand ownership through createWindowForAttachment",
                nativePatch.contains("createWindowForAttachment"));
        assertTrue("unaccepted root QWindow must be deleteLater()'d by the creating Qt queue",
                nativePatch.contains("if (!accepted)\n                parentWindow->deleteLater();"));
    }

    @Test
    public void sceneChildAttachmentCarriesBothTokensIntoTheUiGate() throws IOException {
        String host = readProjectSource("Qt/src/EmbeddedSceneHost.cpp");
        String create = requireBody(host, "void createSceneView(", "EmbeddedSceneHost.createSceneView");
        int validate = create.indexOf("isCurrentAttachmentGeneration");
        int parentCheck = create.indexOf("if (!parentWindow)");
        int staleEpochCheck = create.indexOf("sceneEpochToken <= RhineEmbedded::sceneEpoch().current()");
        int destroyExisting = create.indexOf("destroySceneView();");
        int adopt = create.indexOf("sceneEpoch().adopt");
        assertTrue("Qt queue must reject a null parent before destroying or adopting a scene",
                parentCheck >= 0 && destroyExisting > parentCheck && adopt > parentCheck);
        assertTrue("Qt queue must reject stale attachment and non-new scene generations before replacement",
                validate >= 0 && staleEpochCheck >= 0 && destroyExisting > validate
                        && destroyExisting > staleEpochCheck && adopt > staleEpochCheck);
        assertTrue("addQtWindow JNI descriptor must include attachmentGeneration",
                create.contains("(Lorg/qtproject/qt/android/QtWindow;JJJ)V"));
        assertTrue("addQtWindow JNI call must pass the root generation",
                create.matches("(?s).*parentWindowReference,\\s*attachmentGeneration\\).*"));
        String jniSignature = host.substring(
                host.indexOf("Java_org_qtproject_qt_android_RhineQtView_createEmbeddedScene("),
                host.indexOf('{', host.indexOf("Java_org_qtproject_qt_android_RhineQtView_createEmbeddedScene(")));
        assertTrue("JNI bridge signature must receive the attachment token",
                jniSignature.contains("jlong attachmentGeneration"));
        String jniCreate = requireBody(host,
                "Java_org_qtproject_qt_android_RhineQtView_createEmbeddedScene(",
                "EmbeddedSceneHost.createEmbeddedScene JNI");
        assertTrue("queued scene lambda must capture the attachment token",
                jniCreate.contains("[javaView, parentWindowReference, width, height, attachmentGeneration, sceneGeneration]"));
        assertTrue("queued scene dispatch must forward attachmentGeneration to createSceneView",
                jniCreate.matches("(?s).*createSceneView\\(javaView,\\s*parentWindowReference,\\s*width,\\s*height,\\s*attachmentGeneration,\\s*static_cast<quint64>\\(sceneGeneration\\)\\).*"));

        String addWindow = requireBody(qtViewSource,
                "void addQtWindow(QtWindow window, long viewReference, long parentWindowRef,\n                     long attachmentGeneration)",
                "QtView.addQtWindow(token-aware)");
        String callback = blockAfter(addWindow, "runOnMainThread(() ->");
        assertNotNull("could not extract QtView main-thread child attachment", callback);
        int gate = callback.indexOf("canAttachQtWindow(parentWindowRef, attachmentGeneration)");
        int assign = callback.indexOf("m_window = window");
        int add = callback.indexOf("addView(m_window");
        assertTrue("posted child callback must verify the same live parent generation before mutation",
                gate >= 0 && assign > gate && add > gate);
    }

    @Test
    public void legacyQtWindowCallbackDoesNotDeleteTheParentWindow() {
        String legacy = requireBody(qtViewSource,
                "void addQtWindow(QtWindow window, long viewReference, long parentWindowRef)",
                "QtView.addQtWindow(stock signature)");
        assertFalse("legacy child callback must not delete its already-owned parent on rejection",
                legacy.contains("deleteWindow(parentWindowRef)"));
    }

    @Test
    public void legacyCreateWindowClaimsOrRetiresItsNewParent() {
        String legacyCreate = requireBody(viewSource,
                "protected void createWindow(final long parentWindowRef)",
                "RhineQtView.createWindow(stock signature)");
        int generation = legacyCreate.indexOf("final long attachmentToken = attachmentGeneration()");
        int claim = legacyCreate.indexOf("trackParentWindowForAttachment(parentWindowRef, attachmentToken)");
        int rejectDelete = legacyCreate.indexOf("deleteWindow(parentWindowRef)");
        int sceneCreate = legacyCreate.indexOf("createWindow(parentWindowRef, attachmentToken)");
        assertTrue("stock callback must capture and claim the same attachment before dispatching scene creation",
                generation >= 0 && claim > generation && sceneCreate > claim);
        assertTrue("claim failure must retire the newly supplied, unaccepted parent before returning",
                rejectDelete > claim && legacyCreate.indexOf("return", rejectDelete) > rejectDelete
                        && sceneCreate > legacyCreate.indexOf("return", rejectDelete));
    }

    @Test
    public void nativeDeclarationsAndPublicApiArePreserved() {
        assertTrue("RhineQtView must stay a QtView subclass in org.qtproject.qt.android",
                viewSource.contains("public class RhineQtView extends QtView"));

        String sceneCreate = oneLine(viewSource, "private native void createEmbeddedScene");
        assertTrue("JNI signature of createEmbeddedScene changed: " + sceneCreate,
                sceneCreate.contains("long parentWindowRef")
                        && sceneCreate.contains("int width")
                        && sceneCreate.contains("int height")
                        && sceneCreate.contains("long attachmentGeneration")
                         && sceneCreate.contains("long sceneGeneration"));
        String sceneDestroy = oneLine(viewSource, "private native void destroyEmbeddedScene");
        assertTrue("JNI signature of destroyEmbeddedScene changed: " + sceneDestroy,
                sceneDestroy.contains("long sceneGeneration"));

        assertTrue("releaseSceneForHostDestroy must stay public (called from RhineQtViews)",
                viewSource.contains("public void releaseSceneForHostDestroy()"));

        assertTrue("nativePushSceneState declaration lost",
                viewsSource.contains("private static native boolean nativePushSceneState("));
        assertTrue("nativePushScenePointer declaration lost",
                viewsSource.contains("private static native void nativePushScenePointer("));
        assertTrue("nativePushSceneWheel declaration lost",
                viewsSource.contains("private static native void nativePushSceneWheel("));
        assertTrue("SceneActionSink is consumed by Kotlin; keep it public",
                viewsSource.contains("public interface SceneActionSink"));
    }

    // ------------------------------------------------------------------
    // 非空肯定性控制：fixture 必须对"修复前/写反"的源码报错
    // ------------------------------------------------------------------

    @Test
    public void fixtureIsSensitiveToThePreFixShapes() {
        String preFixViews = "private static View releaseSceneViews(Activity activity) {\n"
                + "    for (View view : views) {\n"
                + "        if (view instanceof RhineQtView) { ((RhineQtView) view).releaseSceneForHostDestroy(); }\n"
                + "    }\n"
                + "    return first;\n"
                + "}\n";
        assertFalse("pre-fix releaseSceneViews has no parent removal and must be rejected",
                releaseQueuedBeforeRemoval(preFixViews));
        assertFalse("pre-fix releaseSceneViews has no identity-gated removal and must be rejected",
                removalIsIdentityGuarded(preFixViews));

        String reversed = "private static View releaseSceneViews(Activity activity) {\n"
                + "    if (view.getContext() == activity) { ((ViewGroup) view.getParent()).removeView(view); }\n"
                + "    ((RhineQtView) view).releaseSceneForHostDestroy();\n"
                + "    return first;\n"
                + "}\n";
        assertFalse("removal-before-release order must be rejected", releaseQueuedBeforeRemoval(reversed));
        assertTrue("the reversed sample still has an identity-gated removal", removalIsIdentityGuarded(reversed));

        String ungated = "private static View releaseSceneViews(Activity activity) {\n"
                + "    ((RhineQtView) view).releaseSceneForHostDestroy();\n"
                + "    ((ViewGroup) view.getParent()).removeView(view);\n"
                + "    return first;\n"
                + "}\n";
        assertFalse("unconditional removal must be rejected", removalIsIdentityGuarded(ungated));

        String preFixRelease = "public void releaseSceneForHostDestroy() {\n"
                + "    if (!sceneRequested) { return; }\n"
                + "    sceneRequested = false;\n"
                + "    retireScene();\n"
                + "}\n";
        assertFalse("pre-fix early-return-before-clear must be rejected",
                clearsRequestBeforeAnyReturn(preFixRelease));

        String preFixRunnable = "public void run() {\n"
                + "    if (!isAttachedToWindow()) { sceneRequested = false; return; }\n"
                + "    createEmbeddedScene(parentWindowRef, getWidth(), getHeight(), generation);\n"
                + "}\n";
        assertTrue("pre-fix runnable lacks the generation guard",
                missingCreateGuards(preFixRunnable).contains("sceneGeneration guard"));
        assertFalse("pre-fix runnable clears the request flag without a generation check",
                unguardedRequestClears(preFixRunnable).isEmpty());

        String noRequestGuardRunnable = "public void run() {\n"
                + "    if (!isAttachedToWindow()) { return; }\n"
                + "    createEmbeddedScene(parentWindowRef, getWidth(), getHeight(), generation);\n"
                + "}\n";
        assertTrue("a runnable with no request check at all must be rejected",
                missingCreateGuards(noRequestGuardRunnable).contains("sceneRequested"));

        // 非空控制：已交付形状（dominant guard + 自己的世代才清）必须被判为合格，
        // 否则"放宽到语义"就变成了"永远通过"。
        String shippedShapeRunnable = "public void run() {\n"
                + "    if (!sceneRequested || sceneGeneration != generation) { return; }\n"
                + "    if (!isAttachedToWindow()) { sceneRequested = false; sceneGeneration = 0; return; }\n"
                + "    createEmbeddedScene(parentWindowRef, getWidth(), getHeight(), generation);\n"
                + "}\n";
        assertTrue("shipped runnable shape must pass the guard checks",
                missingCreateGuards(shippedShapeRunnable).isEmpty());
        assertTrue("shipped runnable shape must pass the generation-scoped clear check",
                unguardedRequestClears(shippedShapeRunnable).isEmpty());

        String inlineShapeRunnable = "public void run() {\n"
                + "    if (!sceneRequested || sceneGeneration != generation || !isAttachedToWindow()) {\n"
                + "        if (sceneGeneration == generation) { sceneRequested = false; sceneGeneration = 0; }\n"
                + "        return;\n"
                + "    }\n"
                + "    createEmbeddedScene(parentWindowRef, getWidth(), getHeight(), generation);\n"
                + "}\n";
        assertTrue("inline-guard runnable must pass the guard checks", missingCreateGuards(inlineShapeRunnable).isEmpty());
        assertTrue("inline-guard runnable must pass the generation-scoped clear check",
                unguardedRequestClears(inlineShapeRunnable).isEmpty());
    }

    @Test
    public void commentStrippingPreventsVacuouslySatisfiedAsserts() {
        String commented = "void f() {\n  // ((ViewGroup) view.getParent()).removeView(view);\n"
                + "  /* sceneGeneration != generation; isAttachedToWindow */\n"
                + "  releaseSceneForHostDestroy();\n}\n";
        String stripped = stripComments(commented);
        assertEquals("line/block comments must not carry contract tokens", -1, stripped.indexOf("removeView("));
        assertEquals(-1, stripped.indexOf("sceneGeneration != generation"));
        assertTrue(stripped.contains("releaseSceneForHostDestroy()"));
        assertFalse(releaseQueuedBeforeRemoval(stripped));
    }

    // ------------------------------------------------------------------
    // 纯算法部分（可被上面的控制用例单独驱动）
    // ------------------------------------------------------------------

    static boolean releaseQueuedBeforeRemoval(String body) {
        int release = body.indexOf("releaseSceneForHostDestroy");
        int remove = body.indexOf("removeView(");
        return release >= 0 && remove >= 0 && release < remove;
    }

    static boolean removalIsIdentityGuarded(String body) {
        int remove = body.indexOf("removeView(");
        if (remove < 0) {
            return false;
        }
        for (IfBlock block : ifBlocks(body)) {
            if (block.start < remove && remove < block.end && IDENTITY_GATE.matcher(block.condition).find()) {
                return true;
            }
        }
        return false;
    }

    static boolean clearsRequestBeforeAnyReturn(String body) {
        int clear = body.indexOf("sceneRequested = false");
        if (clear < 0) {
            return false;
        }
        int ret = body.indexOf("return");
        return ret < 0 || clear < ret;
    }

    static List<String> missingCreateGuards(String runnable) {
        List<String> missing = new ArrayList<>();
        int create = runnable.indexOf("createEmbeddedScene(");
        if (create < 0) {
            missing.add("createEmbeddedScene(");
            return missing;
        }
        requireBefore(runnable, "sceneRequested", create, missing);
        if (!precedes(runnable, GENERATION_GUARD, create)) {
            missing.add("sceneGeneration guard");
        }
        if (!precedes(runnable, Pattern.compile("isCurrentAttachment\\s*\\(\\s*attachmentToken\\s*\\)"), create)
                && !precedes(runnable, Pattern.compile("isAttachedToWindow\\s*\\(\\s*\\)"), create)) {
            missing.add("current attachment guard");
        }
        return missing;
    }

    /**
     * {@code sceneRequested = false} 的每一次出现都必须是"世代作用域内"的，两种合法形状：
     * (a) 外层 if 条件里带 sceneGeneration（内联写法）；
     * (b) 同一方法体内更早处有一个带 sceneGeneration 的守门 if，且它内部 return（dominant guard），
     *     于是走到这条清除语句时世代必然仍等于自己那一代。
     * 修复前的形状（只有 isAttachedToWindow 一条 if）两种都不满足，因此返回非空。
     */
    static List<Integer> unguardedRequestClears(String body) {
        List<Integer> unguarded = new ArrayList<>();
        List<IfBlock> blocks = ifBlocks(body);
        int from = 0;
        int at;
        while ((at = body.indexOf("sceneRequested = false", from)) >= 0) {
            if (!isGenerationScoped(body, blocks, at)) {
                unguarded.add(at);
            }
            from = at + 1;
        }
        return unguarded;
    }

    private static boolean isGenerationScoped(String body, List<IfBlock> blocks, int clear) {
        for (IfBlock block : blocks) {
            if (block.start < clear && clear < block.end && GENERATION_GUARD.matcher(block.condition).find()) {
                return true;
            }
        }
        for (IfBlock block : blocks) {
            if (block.end < clear
                    && GENERATION_GUARD.matcher(block.condition).find()
                    && indexOfKeyword(body.substring(block.start, block.end), "return", 0) >= 0) {
                return true;
            }
        }
        return false;
    }

    private static boolean precedes(String haystack, Pattern token, int limit) {
        java.util.regex.Matcher matcher = token.matcher(haystack);
        return matcher.find() && matcher.start() < limit;
    }

    private static void requireBefore(String haystack, String token, int limit, List<String> missing) {
        int at = haystack.indexOf(token);
        if (at < 0 || at >= limit) {
            missing.add(token);
        }
    }

    /** 纯语义控制：与源码里的 {@code getContext() == activity} 同义。 */
    private static boolean identityGateMatches(Object destroyedActivity, Object viewContext) {
        // 源码门禁是引用相等（==），null context 永不相等。
        return viewContext != null && viewContext == destroyedActivity;
    }

    private static final class IfBlock {
        final String condition;
        final int start;
        final int end;

        IfBlock(String condition, int start, int end) {
            this.condition = condition;
            this.start = start;
            this.end = end;
        }
    }

    private static List<IfBlock> ifBlocks(String source) {
        List<IfBlock> blocks = new ArrayList<>();
        int from = 0;
        int at;
        while ((at = indexOfKeyword(source, "if", from)) >= 0) {
            int open = source.indexOf('(', at);
            if (open < 0) {
                break;
            }
            int close = matching(source, open, '(', ')');
            if (close < 0) {
                break;
            }
            int brace = source.indexOf('{', close);
            if (brace >= 0) {
                int end = matching(source, brace, '{', '}');
                if (end > 0) {
                    blocks.add(new IfBlock(source.substring(open + 1, close), brace, end));
                }
            }
            from = at + 2;
        }
        return blocks;
    }

    private static int indexOfKeyword(String source, String keyword, int from) {
        int at = source.indexOf(keyword, from);
        while (at >= 0) {
            boolean leftOk = at == 0 || !Character.isJavaIdentifierPart(source.charAt(at - 1));
            int after = at + keyword.length();
            boolean rightOk = after >= source.length() || !Character.isJavaIdentifierPart(source.charAt(after));
            if (leftOk && rightOk) {
                return at;
            }
            at = source.indexOf(keyword, at + 1);
        }
        return -1;
    }

    /** 从 {@code marker} 之后的第一个 '{' 开始，取括号内文本（不含外层括号）。 */
    private static String blockAfter(String source, String marker) {
        int at = source.indexOf(marker);
        if (at < 0) {
            return null;
        }
        int brace = source.indexOf('{', at + marker.length());
        if (brace < 0) {
            return null;
        }
        int end = matching(source, brace, '{', '}');
        if (end < 0) {
            return null;
        }
        return source.substring(brace + 1, end);
    }

    private static String postedCreateRunnableBody() {
        String createWindow = requireBody(viewSource,
                "private void createWindowOnMainThread", "RhineQtView.createWindowOnMainThread");
        assertTrue("fixture control: createWindow must still post a zero-size create runnable",
                createWindow.contains("post(() ->"));
        String runMethod = blockAfter(createWindow, "post(() ->");
        assertNotNull("could not extract the posted Runnable body", runMethod);
        assertTrue("fixture control: extracted run() body looks truncated", runMethod.contains("createEmbeddedScene("));
        return runMethod;
    }

    private static String requireBody(String source, String signature, String label) {
        String body = blockAfter(source, signature);
        assertNotNull("could not locate " + label + " (" + signature + ")", body);
        assertTrue(label + " body looks truncated", body.trim().length() > 40);
        return body;
    }

    private static String oneLine(String source, String marker) {
        int at = source.indexOf(marker);
        assertTrue("declaration lost: " + marker, at >= 0);
        int end = source.indexOf(';', at);
        return source.substring(at, end < 0 ? source.length() : end).replaceAll("\\s+", " ");
    }

    private static int matching(String source, int open, char openChar, char closeChar) {
        int depth = 0;
        for (int i = open; i < source.length(); i++) {
            char c = source.charAt(i);
            if (c == '"' || c == '\'') {
                i = skipLiteral(source, i);
                continue;
            }
            if (c == openChar) {
                depth++;
            } else if (c == closeChar) {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static int skipLiteral(String source, int quoteAt) {
        char quote = source.charAt(quoteAt);
        int i = quoteAt + 1;
        while (i < source.length()) {
            char c = source.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == quote) {
                return i;
            }
            i++;
        }
        return source.length() - 1;
    }

    /** 去掉 // 与 /* *&#47; 注释（保留字符串字面量），让注释里的字样不能"证明"合同成立。 */
    static String stripComments(String source) {
        StringBuilder out = new StringBuilder(source.length());
        int i = 0;
        int n = source.length();
        while (i < n) {
            char c = source.charAt(i);
            if (c == '/' && i + 1 < n && source.charAt(i + 1) == '/') {
                while (i < n && source.charAt(i) != '\n') {
                    i++;
                }
            } else if (c == '/' && i + 1 < n && source.charAt(i + 1) == '*') {
                i += 2;
                while (i + 1 < n && !(source.charAt(i) == '*' && source.charAt(i + 1) == '/')) {
                    i++;
                }
                i = Math.min(n, i + 2);
            } else if (c == '"' || c == '\'') {
                int end = skipLiteral(source, i);
                out.append(source, i, Math.min(n, end + 1));
                i = end + 1;
            } else {
                out.append(c);
                i++;
            }
        }
        return out.toString();
    }

    private static String readSource(String fileName) throws IOException {
        File found = locate(fileName);
        return new String(Files.readAllBytes(found.toPath()), StandardCharsets.UTF_8);
    }

    private static String readProjectSource(String relativePath) throws IOException {
        File dir = new File(System.getProperty("user.dir", ".")).getAbsoluteFile();
        for (int depth = 0; depth < 8 && dir != null; depth++) {
            File candidate = new File(dir, relativePath);
            if (candidate.isFile()) {
                return new String(Files.readAllBytes(candidate.toPath()), StandardCharsets.UTF_8);
            }
            dir = dir.getParentFile();
        }
        throw new IllegalStateException("cannot locate project source " + relativePath
                + " from " + System.getProperty("user.dir"));
    }

    /**
     * 从 {@code user.dir} 向上找 {@code .../org/qtproject/qt/android/<file>}，因此无论从
     * 仓库根、{@code android/} 还是 {@code android/app/} 运行都能定位；找不到就直接失败，
     * 不允许"定位不到就跳过"式的假通过。
     *
     * <p>{@code -Drhine.retention.sourceDir=<dir>} 可把 fixture 指到另一份源码根（例如从
     * {@code git show 47f699c:...} 导出的修复前快照）——这就是 RED 的可复现跑法；正常 GREEN
     * 不传该属性，直接测当前工作树。
     */
    private static File locate(String fileName) {
        String override = System.getProperty("rhine.retention.sourceDir", "");
        if (!override.isEmpty()) {
            File[] overridden = new File[] {
                new File(override, "android/app/src/main/java/org/qtproject/qt/android/" + fileName),
                new File(override, "android/app/javapatch/src/org/qtproject/qt/android/" + fileName),
                new File(override, "app/src/main/java/org/qtproject/qt/android/" + fileName),
                new File(override, "app/javapatch/src/org/qtproject/qt/android/" + fileName),
                new File(override, "src/main/java/org/qtproject/qt/android/" + fileName),
                new File(override, fileName),
            };
            for (File candidate : overridden) {
                if (candidate.isFile()) {
                    return candidate;
                }
            }
            throw new IllegalStateException(
                    "rhine.retention.sourceDir=" + override + " does not contain " + fileName);
        }
        File dir = new File(System.getProperty("user.dir", ".")).getAbsoluteFile();
        for (int depth = 0; depth < 8 && dir != null; depth++) {
            File[] candidates = new File[] {
                new File(dir, "android/app/src/main/java/org/qtproject/qt/android/" + fileName),
                new File(dir, "android/app/javapatch/src/org/qtproject/qt/android/" + fileName),
                new File(dir, "app/src/main/java/org/qtproject/qt/android/" + fileName),
                new File(dir, "app/javapatch/src/org/qtproject/qt/android/" + fileName),
                new File(dir, "src/main/java/org/qtproject/qt/android/" + fileName),
            };
            for (File candidate : candidates) {
                if (candidate.isFile()) {
                    return candidate;
                }
            }
            dir = dir.getParentFile();
        }
        throw new IllegalStateException("cannot locate " + fileName + " from " + System.getProperty("user.dir"));
    }
}
