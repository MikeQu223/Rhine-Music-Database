# 最终验收与声明（T54 / QA-FINAL）——阶段门台账

> **本文是"当前阶段"的验收门台账，不是全项目最终总审。** 它记录截至 §0.2 取证时刻，
> 每个门"有没有证据、证据到哪一层、缺什么"。任何一门未闭合时，本文不许出现"1:1 完成"、
> "视觉已对齐"、"可发布"一类结论。
>
> **本轮没有执行任何构建、测试、analyze、adb、设备操作或 Qt 编译。** 所有 device 轴判定为
> `NOT_RUN` / `DEVICE_BLOCKED`，不由 code/staticreview 推理得出（硬规则 R1）。

---

## 0. 坐标与取证口径

### 0.1 本文件坐标

| 项 | 值 |
|---|---|
| 文件 | `docs/flutter-migration/acceptance/final.md` |
| 所属任务 | T54 最终验收与声明（计划 L734-741） |
| 写入 worktree | `.agents/parity-20261109/worktrees/T54` |
| 分支 | `flutter/p4-t54-acceptance-gates` |
| 基线 | `8ed3067b0812eb2612f7841ec127a6e8ca93231b` |
| 集成目标 | 仓库根 `feat/flutter` |
| 提交标题（计划 L740） | `docs: record final parity acceptance` |
| 本文覆盖范围 | 只写本文件；不写任何源码/契约/测试 |

### 0.2 取证时刻与复现命令

本文件的全部 git 事实取自 **2026-11-10 04:20–04:52 (+08:00)** 的快照。并行任务仍在写盘，
因此本快照是**点时刻**事实：不得用"某文件不在清单里"去判定别的任务失败，也不得在快照
之后继续引用本文的行数/字节数。

复现命令（只读，不需要构建）：

~~~bash
B=8ed3067b0812eb2612f7841ec127a6e8ca93231b
git log --oneline --no-decorate 8ed3067b0812eb2612f7841ec127a6e8ca93231b..HEAD
git rev-parse HEAD
# 每棵任务树（过滤外部 TraeCN 的 Gradle 缓存，它不是本迁移产物）
for t in .agents/parity-20261109/worktrees/*/; do
  git -C "TREE" log --oneline --no-decorate 8ed3067b0812eb2612f7841ec127a6e8ca93231b..HEAD
  git -C "TREE" status --porcelain -uall | grep -v 'Qt/android/.gradle'
done
~~~

### 0.3 计划内坐标（行号=2026-11-09 版计划，已在 §0.2 快照核对）

| 引用 | 内容 |
|---|---|
| 计划 L17-24 | 证据等级 **E0–E3** 四级定义（E0 真机实证 / E1 直读源码 / E2 可复核产物 / **E3 推断·设计候选·未逐行核对 → 只能作线索，不得作验收依据**）；L26 追加「任何未落 fixture 的 E3 不得进入页面验收」 |
| 计划 L28-32 | 三条纪律（不自造阈值、不冒充证据、不用文档替代验收） |
| 计划 L72-82 | 设备 serial `526f6b6d`、OPD2511、Android 16/API 36、density 315、2880×1800；APK SHA256 `bd58d95a5edee4c66a9704a108fb335163dc4274239b5f32b2a0c4cb221b5a1e`；Qt 证书 `39396cd06f2b7980302bad220ed071e09286540be4d224a2f9b047ca65205bdf`；旧 Flutter 证书 `7c514fe8cf95411117b6a4d1cba78768c1cda1d665c42f4828398d8587239dd4`；`allowBackup=false` |
| 计划 L84-99 | 12 张真机截图的覆盖与"不能证明" |
| 计划 L103-114 | G1-G8 证据缺口；L114 明示"是证据缺口不是用户审批门" |
| 计划 L116-125 | 逻辑/物理/舞台换算（DPR 1.96875、stageScale 0.846561、stageWidth 1728） |
| 计划 L329-349 | 页面级矩阵，含"动作"列 |
| 计划 L353 | 16 个弹层级（+桌面歌词） |
| 计划 L357 | 动作命名空间字面量 |
| 计划 L359-365 | 竖屏是新增设计，不是 1:1 |
| 计划 L367-376 | 旋转连续性 6 组 |
| 计划 L746 | 单 writer 热点：`lib/app/router.dart`、`lib/bridge/engine_transport.dart`、`lib/hud/render/hud_painter.dart`、`lib/hud/pages/archive_page.dart` |
| 计划 L758-765 | 六门：功能/画面/协议/状态/稳定/发布 |
| 计划 L767-769 | 拟议辅助指标（未冻结，不得写入验收） |
| 计划 L792-800 | 六条不能宣称 |

### 0.4 本版对旧稿（T54-V8）与旧审（T54-V8-R1, verdict=FAIL）的闭合

| 旧审 mustFix | 本版处置 | 位置 |
|---|---|---|
| MF1 §2.1"356 commits/超出基线 0"失真 | 改为 baseline..HEAD **恰 6 个** commit，逐个列真实 SHA 与源 commit | §2.1 |
| MF2 T24 行把已提交文件写成未跟踪、漏 3 文件 | 拆成"已集成 `a30aa86`"与"未集成 `a1dfd48`/`6f031ea`"两行，逐文件列全 | §2.2 |
| MF3 T15 行把已提交 vendor/three 写成未跟踪、漏 index.html | 同一文件拆成"已提交 vendor 5 文件"与"未提交 index.html/renderer.js 等 4 文件" | §2.3 |
| MF4"无草稿"清单错列 T32/T39/T43/T50/T51，漏 SHARED | 重测为 **36 棵**树有草稿，逐树逐文件列出；另列 3 棵仅提交、5 棵空树，36+3+5=44 | §2.2 §2.3 |
| MF5 由 MF4 连锁的 code 轴结论失真 | code 轴改为按树逐文件判定，不再给"整体无草稿"结论 | §1.1 §2.3 |
| MF6 reports 文件数不实 | 改为带时间戳的实测值与"随并行任务增长，不作证据"说明 | §2.4 |
| MF7 行号引用不实（T26-S04-notes） | 逐条重核为 `:178` / `:186-188` / `:329`；并纠正旧审误引的 `T26-V3.json:279` → `:222` | §3.6、§6 第 6 行 |
| MF8 缺"动作"轴 | 新增独立**动作门**（§3.3），页面矩阵恢复"动作"列（§5） | §3.3 §5 |
| mayFix 协议门 staticreview 自相矛盾 | 协议门只记 `NOT_RUN`，草稿存在不代表契约成立 | §3.5 |
| mayFix 3D 查看器 code 描述 | 按 T41 草稿 `lib/scene/scene_math.dart` 实况重写，不写"已实现" | §5 |
| mayFix T26/T31 漏文件 | 逐文件补全（T26 3 提交 6 文件 + 1 草稿；T31 7 提交 9 文件 + 2 草稿） | §2.2 §2.3 |
| mayFix T43 省略号路径 | 全部改为精确路径 | §2.3 §8 |
| mayFix T52-V8:35 引用不当 | 改引 `reports/T52-V8.json:37`（unexecutedVerification）与 `:39`（notes） | §7 |

---

## 1. 判定语法与硬规则

### 1.1 四轴（每项证据必须四轴齐说，缺一轴即不算通过）

| 轴 | 含义 | 取证方式 |
|---|---|---|
| `code` | 产物是否存在、在哪棵树、是否被 git 跟踪 | 计划路径 + `git status`/`git log` |
| `staticreview` | 是否有独立只读审查报告且 verdict 明确 | `reports/*.json` 的 `verdict` 字段 |
| `integrated` | 是否在 `feat/flutter` 上、baseline 之后可达 | `git log B..HEAD` + `git rev-parse <commit>:<path>` |
| `device` | 真机/设备侧行为 | 只能在授权设备会话中取证；本轮全为 `NOT_RUN` |

### 1.2 状态词（全文只用这些词，不造同义词）

| 词 | 定义 |
|---|---|
| `PASS` | 该门要求的**全部**证据齐备且可复核 |
| `CODE_ONLY` | 有源码/文档产物，无测试执行、无审查、无集成 |
| `REVIEWED` | 有独立审查报告且 verdict 通过，但未集成 |
| `INTEGRATED` | 已在集成分支 baseline 之后可达 |
| `NOT_INTEGRATED` | 有提交但不在集成分支上 |
| `NOT_RUN` | 需要执行才能取证的项，本轮未执行 |
| `UNPROVEN` | 应当有证据但本轮没有，且不是"未执行"能开脱 |
| `WAIT` | 依赖上游裁决/审定，尚未开始 |
| `FAIL` | 已取证且不满足要求 |
| `DEVICE_BLOCKED` | 需要真机而当前无可用设备证据 |
| `ARCH_BLOCKED` | 需要架构裁决而裁决未出 |

### 1.3 硬规则

- **R1** device 轴不得由 code/staticreview 推出。没有真机帧就是 `NOT_RUN`/`DEVICE_BLOCKED`。
- **R2** `staticreview` 只认报告文件里的 `verdict` 字段 + 报告路径，不认转述、不认"看起来没问题"。
- **R3** `integrated` 只认集成分支上可达的 commit SHA。worktree 里的 commit 一律 `NOT_INTEGRATED`。
- **R4** 未被 git 跟踪的草稿一律 `code=CODE_ONLY`，哪怕内容完整、行数很大。
- **R5** 本轮未执行的 build/test/analyze/adb，永久记为 `NOT_RUN`，不得补写"预期通过"。
- **R6** 引用行号必须在取证时刻核对；行号漂移即视为证据失效，须重核后才可引用。
- **R7** 文件存在 ≠ 功能可用。跨树引用缺失（例：T12 的 `Qt/porting/CMakeLists.txt` 注册了
  `TextureHost.h/.cpp`，而这两文件在 T12 树内不存在，实体是 T14 的 `HybridTextureHost.*`）
  必须显式记为"不可构建"，不得因为"CMake 写了"就算接入。
- **R8** 一份 `PASS` 审查只覆盖它审过的那几个文件，不覆盖整张任务卡。集成一处 ≠ 任务完成。

---

## 2. 快照

### 2.1 集成分支 `feat/flutter`：baseline..HEAD 恰 6 个 commit

HEAD = `f51f59d18ae363c208955d7ac57f0e47b4cf2861`，越基线提交数 **6**（旧稿写"0"作废）。

| # | 集成 SHA | 标题 | 源 worktree commit | 落地文件（行数/字节） | 独立审查 | blob 复核 |
|---|---|---|---|---|---|---|
| 1 | `8f99813afe17b06781d631eb38f68611086a00db` | feat(domain): port qt login session state machine | T24 `a30aa864e1cfb088b31ba1d7718d86546dca128d` | `lib/domain/account/login_session.dart` +823；`test/domain/login_state_test.dart` +462 | `reports/T24-S01-review.json` verdict=PASS mustFix=[] | 逐文件 SAME |
| 2 | `9aec0470666634432b4b6ae32e82bdad98e07032` | chore(config): register real assets and integration_test | SHARED `7f3439e2e2a4523e8de4f81884f051fc7ba166a7` | `pubspec.yaml` +15 | `reports/SHARED-V4-S5-REVIEW.json` verdict=PASS mandatoryFixes=[] | SAME |
| 3 | `c643b555496d4bffcb6aa332a0d5621b135d2806` | docs: freeze settings sections and platform capabilities | T06 `c2a6d536d2cc3ae0d8ee774c2919f835767388ab` | `docs/flutter-migration/contracts/settings-platform.md` +366 | `reports/T06-V2-R-C01-r2.json` verdict=PASS status=COMPLETE | SAME |
| 4 | `4996275eb8a1f35b46c179268a754cc5fbd1ee81` | feat(hud): add Qt label text fitter | T31 `8b0c8fa486f04c2859709b77b18a6aacfa64acba` | `lib/hud/text/text_fitter.dart` +152 | `reports/T31-R-A3-recheck.json` verdict=PASS mustFix=[] | SAME |
| 5 | `e7ef1e48f006824db495afd6d0f04cd45bb0b020` | test: freeze settings sections fixture and contract assertions | T06 `eb053a7461302af281ee42dae7d7d67314ca3e21` | `test/fixtures/settings_sections.json` +932 / 25713 B sha256 `95eb9d81…`；`test/settings_sections_test.dart` +454 / 19751 B sha256 `5a769db1…` | `reports/T06-V2-R-F01b.json` verdict=PASS status=FINISHED | SAME |
| 6 | `f51f59d18ae363c208955d7ac57f0e47b4cf2861` | feat(hud): 新增 Qt 对齐的播放条 HUD 命令构建器与测试 | T39 `f9f18cba37870c462cb7c5fdb6b3892eda78afbc` | `lib/hud/player/player_bar.dart` 578 L / 20481 B sha256 `829b83e4…`；`test/hud/t39/player_bar_test.dart` 1037 L / 44031 B sha256 `e6056f10…` | `reports/T39-W1-REVIEW.json` verdict=PASS mandatoryFixes=[] | SAME |

集成台账与 hold 记录：`reports/INTEGRATE-M11.json`；集成审查 `reports/INTEGRATE-M11-R5.json`
（该文件 `:5` 的 `parentAgent` 是编排者 root `2b9274fb-ca00-4776-b98d-d1ca68fda127`，
真正出 verdict 的是 depth2 审查 leaf `dfa6ed93-eeb3-4fe2-b077-94c0c5c81437`，见
`reports/INTEGRATE-M11.json:204`；对 `eb053a7`/`f9f18cb` verdict=PASS mustFixOpen=[]）**明确要求**：不得因这两个 commit 就把 T06/T39 记为 done —— T06 的 Dart 测试
未运行，T39 只是 6 文件卡里的 2 文件切片（golden、modal/lyrics 均未做）。

**这 6 个 commit 的性质**：3 个契约/配置产物 + 2 个 HUD 文本/播放条切片 + 1 个登录状态机。
**没有一个页面、没有一个弹层、没有一条端到端链路被集成。** 因此 `integrated` 轴在
"整应用可运行"这个粒度上仍然是 0。

### 2.2 44 棵树 = 42 任务树 + SHARED + REUSE

**越基线有提交的 12 棵，共 23 个 commit，其中只有 6 个被集成（§2.1）。**

| 树 | 越基线 commit | HEAD | 已集成 | 未集成 |
|---|---|---|---|---|
| SHARED | 1 | `7f3439e` | `7f3439e` ✅ | — |
| T01 | 1 | `c6d0861` | — | `c6d0861` docs: freeze artifact baseline provenance（`docs/flutter-migration/00-baseline.md`、`docs/flutter-migration/evidence/device-2026-11-09.md`） |
| T02 | 1 | `1ee6eb8` | — | `1ee6eb8` docs(layout): freeze stage metrics and player input bounds（`docs/flutter-migration/contracts/layout.md`） |
| T06 | 2 | `eb053a7` | `c2a6d53`、`eb053a7` ✅ | — |
| T07 | 1 | `b3f4850` | — | `b3f4850` docs(storage): freeze Qt session and credential compatibility（`docs/flutter-migration/contracts/storage.md`） |
| T12 | 1 | `f72a5ed` | — | `f72a5ed` build: 注册 Qt 离屏纹理宿主 TextureHost 源文件（`Qt/CMakeLists.txt`、`Qt/porting/CMakeLists.txt`）→ **见 R7：注册的文件不在这棵树里** |
| T15 | 1 | `cd322fb` | — | `cd322fb` chore(web): vendor three.js 0.160.0（`web/rhine_replica/vendor/three/` 5 文件）→ 集成台账标 `HOLD_ARCH_BRANCH_ISOLATION` |
| T24 | 3 | `6f031ea` | `a30aa86` ✅ | `a1dfd48` feat(domain): port qt sms login and captcha flow；`6f031ea` feat(domain): port qt credential storage and per source logout（`credential_store.dart`、`credential_store_atomic_test.dart`、`credential_test.dart`） |
| T26 | 3 | `fb7242a` | — | `c556c7e` 路径与原子 IO（**OPEN mustFix：app_storage offline + tautology**）；`d921113` 面板偏好白名单（**parent unmet**）；`fb7242a` 播放会话恢复（**HOLD_LOGIC_FIX**）。文件：`app_storage.dart`、`playback_store.dart`、`preference_store.dart` + 3 测试 |
| T31 | 7 | `14e733d` | `8b0c8fa` ✅ | `180312b` boot lettering art run、`11b3f18` fallback predicate、`f5acc0c` glyph text run（**HOLD_COMPLEX_FALLBACK_FIX**）、`b785730` label fitting tests、`39738fc` glyph font resources、`14e733d` rolling label reel。文件：`art_run.dart`、`fallback_shaper.dart`、`glyph_font.dart`、`glyph_run.dart`、`rolling_label.dart` + 3 测试 |
| T39 | 1 | `f9f18cb` | `f9f18cb` ✅ | —（仅卡内 2/6 文件） |
| T53 | 1 | `10775d5` | — | `10775d5` docs(release): preserve signing and migration release gates（`docs/flutter-migration/release.md`、`tool/release/verify_signing.sh`） |

**仅提交、无脏文件**：T06、T12、T53（T07 现已有草稿，见 §2.3）。
**空树（无提交、无草稿，除外部 Gradle 缓存）**：T35、T36、T38、T42、REUSE。

### 2.3 未提交草稿台账：36 棵树（旧稿"无草稿"清单作废）

统计口径：`git status --porcelain -uall`，**过滤 `Qt/android/.gradle`**（外部 TraeCN 扩展活动，
44 棵树里都有该缓存，绝不 stage/delete，也绝不当成迁移产物）。

| 树 | 未提交内容 | 规模（§0.2 快照值；此后并行写盘继续增长，见 §2.4） |
|---|---|---|
| SHARED | `lib/domain/models/{api_result,media_snapshot,music_item,provider_id}.dart` + `test/domain/{api_result,media_snapshot,music_item,provider_id}_test.dart` | 8 文件 |
| T01 | M `docs/flutter-migration/00-baseline.md`；`test/baseline_manifest_test.dart`；`test/fixtures/baseline_manifest.json` | 12204 B / 8638 B |
| T02 | `test/fixtures/stage_metrics.json`、`test/stage_metrics_test.dart` | 2 文件 |
| T03 | `docs/flutter-migration/contracts/hud-protocol.md`、`test/fixtures/hud_commands_17.json`、`test/fixtures/hud_hits.json`、`test/hud_protocol_test.dart` | 4 文件 |
| T04 | `docs/flutter-migration/contracts/text-color.md`、`test/fixtures/glyph_metrics.json`、`test/text_metrics_test.dart` | 3 文件 |
| T05 | `docs/flutter-migration/contracts/domain.md`、`test/fixtures/login_matrix.json`、`test/login_matrix_test.dart` | 3 文件 |
| T07 | `test/fixtures/session_view.json`、`test/session_schema_test.dart` | 2 文件 |
| T10 | `docs/flutter-migration/01-slice.md`、`test/fixtures/slice_cases.json` | 2 文件 |
| T11 | `android/app/src/main/kotlin/rhine/music/database/porting/QtPlatformViewHost.kt`、`integration_test/slice_platformview_test.dart`、`lib/platform/qt_platform_view.dart` | 3 文件 |
| T13 | `lib/spike/dart_hud/{glyph_loader,hud_painter}.dart` + 2 测试 | 4 文件 |
| T14 | `Qt/porting/HybridTextureHost.{cpp,h}`（7438/8163 B）、`integration_test/slice_hybrid_test.dart`、`lib/spike/hybrid/hybrid_host.dart` | 4 文件 |
| T15 | `web/rhine_replica/index.html`、`web/rhine_replica/renderer.js`、`integration_test/slice_webview_test.dart`、`test/spike/webview/renderer_contract_test.dart` | 4 文件（vendor 5 文件已提交，见 §2.2） |
| T16 | `docs/flutter-migration/02-adjudication.md`、`docs/flutter-migration/adr/0001-host-architecture.md` | 2 文件 |
| T20 | `lib/app/lifecycle.dart`、`test/app/lifecycle_test.dart` | 2 文件 |
| T21 | `lib/bridge/{engine_transport,node_runtime}.dart`、2 测试、`integration_test/bridge_lifecycle_test.dart` | 5 文件 |
| T22 | `lib/domain/library/{directory_stack,music_library}.dart`、`test/domain/library_test.dart` | 3 文件 |
| T23 | `lib/domain/lyrics/lyrics_controller.dart`、`lib/domain/player/{music_player,playback_queue}.dart`、2 测试 | 5 文件 |
| T24 | M `lib/domain/account/login_session.dart`、M `test/domain/login_state_test.dart`、`lib/domain/account/account_manager.dart`、`test/domain/account_manager_test.dart` | 4 文件（即 `a1dfd48`/`6f031ea` 之后的增量） |
| T25 | `lib/platform/media_session.dart`、`test/media_session_test.dart` | 2 文件 |
| T26 | `lib/data/storage/session_store.dart`、`test/storage/{corruption,session_restore,session_view}_test.dart` | 4 文件 |
| T27 | `lib/app/consent_gate.dart`、`lib/diagnostics/diagnostics_service.dart`、`lib/platform/update_service.dart`、`test/app/consent_gate_test.dart`、`test/platform/diagnostics_test.dart`、`reports/T27-C14-W01{,-R}.json`、`reports/T27-C18-A{1,2,3}.json` | 10 文件 |
| T30 | `lib/hud/protocol/hud_command.dart` 743 L、`hud_frame.dart` 358 L、`hud_hit.dart` 220 L、`test/hud/hud_frame_test.dart` | 4 文件 |
| T31 | M `lib/hud/text/fallback_shaper.dart`、M `lib/hud/text/glyph_run.dart`、`test/hud/fallback_shaper_test.dart`、`test/hud/glyph_run_test.dart` | 4 文件 |
| T32 | `lib/hud/input/{hit_layer 173L,key_router 290L,pointer_router 175L,wheel_router 562L}.dart`、`test/hud/hit_layer_test.dart` | 5 文件 |
| T33 | `lib/hud/pages/{archive_page 380L,chrome 226L,directory_empty 141L}.dart`、`lib/hud/widgets/track_ruler.dart`、4 测试 | 8 文件 |
| T34 | `lib/hud/pages/song_detail.dart`、`lib/hud/widgets/action_row.dart`、2 测试 | 4 文件 |
| T37 | `lib/hud/widgets/settings_row.dart`、`test/hud/t37/settings_row_test.dart` | 2 文件 |
| T39 | `lib/hud/modals/{lyrics_panel,queue_modal}.dart`、2 测试 | 4 文件 |
| T40 | 6 弹层：`confirm_modal 489L`、`detail_sort_modal 446L`、`disc_warning_modal 623L`、`lyrics_offset_modal 511L`、`lyrics_source_modal 482L`、`playlist_picker 606L` + 4 测试 | 10 文件 |
| T41 | `lib/scene/scene_math.dart`、`test/scene/projection_test.dart` | 2 文件 |
| T43 | `lib/ui/layout/portrait_bands.dart` 744 L、`lib/ui/layout/portrait_stage.dart` 156 L、`test/fixtures/portrait_bands.json` 334 L、`test/ui/portrait_stage_test.dart` 691 L | 4 文件 |
| T44 | `lib/app/rotation_continuity.dart` | 1 文件 |
| T50 | `tool/parity/compare.py` | 1 文件 |
| T51 | `docs/flutter-migration/acceptance/portrait.md`、`test/fixtures/parity_cases/portrait_login.json` | 2 文件 |
| T52 | `docs/flutter-migration/03-performance.md`、`tool/perf/README.md`、`tool/perf/collect_frame_times.dart` | 3 文件 |
| T54 | `docs/flutter-migration/acceptance/final.md`（本文件提交前） | 1 文件 |

计数自洽：**36 有草稿 + 3 仅提交 + 5 空 = 44**。

**这些草稿全部 `code=CODE_ONLY`（R4）**：没有一行被集成，没有一份带独立审查报告，
没有一条测试被执行。行数大不代表可用——T30 的协议三文件 1321 行、T40 的六弹层 3157 行
都还是未跟踪状态。

### 2.4 环境异常与不可信证据

| 项 | 事实 | 影响 |
|---|---|---|
| 外部 Gradle 缓存 | `Qt/android/.gradle/` 在 44 棵树内均为未跟踪（TraeCN 扩展在跑） | 绝不 stage/delete；不得当迁移产物，也不得作为"构建过"的证据 |
| 12 张 Qt 基准 PNG | `/tmp/rhine-qt-baseline-2026-11-09/` 于 2026-11-10 00:01 消失，实体丢失，仅剩计划 L84-99 的索引 | 画面门唯一基准物证缺失 → `DEVICE_BLOCKED`（§3.2、§8 C1） |
| reports 目录 | 并行任务持续写入，计数对口径与时刻高度敏感：04:42:39 对 `reports/` 直接计数得 308（含本任务 2 个），而按 birth time 截止同一时刻为 269（05:20 前后约 309） | 本行不给单一数字；任何计数都**不作验收证据**，只按文件名精确引用 |
| 旧稿基线 | 旧稿写"超出基线 0 commit / 无草稿"，与实测冲突 | 旧稿 §2 整体作废，本版 §2 取代 |

### 2.5 与旧稿的关系

旧稿 263 行 / 23504 B，未跟踪、未提交。本版保留其正确骨架（状态词表、G1-G8、六门结构、
发布检查、性能拟议阈值、补采清单、禁止宣称、维护协议），替换其全部 git 事实与 code 轴结论，
并新增动作门与"动作"列。**旧稿内容不得再被引用**；如需历史差异见 §0.4。

---

## 3. 门

### 3.1 总表

T54 卡（计划 L736）要求"功能/画面/动作/状态/性能/签名"六门；计划 L758-765 要求
"功能/画面/协议/状态/稳定/发布"六门。两套并集去重后为下表**九门**。

| # | 门 | 判定 | 已取证（code/staticreview/integrated） | 缺口与阻断 |
|---|---|---|---|---|
| 1 | 功能门 | `NOT_RUN` | 5 处 atom 已 `INTEGRATED`（§2.1）；契约文档 2 份已集成 | 全部 Dart 测试未执行；无页面/弹层/端到端链路集成 |
| 2 | 画面门 | `DEVICE_BLOCKED` | 12 张图仅存索引（计划 L84-99） | 基准 PNG 实体丢失；横屏逐 ROI 未做；竖屏 golden 未生成 |
| 3 | 动作门 | `NOT_RUN` | 动作命名空间字面量仅计划 L357 有清单 | 无动作级测试；T32/T33/T34/T39/T40 均草稿；T05 未冻结 |
| 4 | 状态门 | `NOT_RUN` | T20/T44 草稿存在 | 旋转 6 组连续性无一条取证；QR 墙钟/generation 无设备证据 |
| 5 | 协议门 | `NOT_RUN` | T30 三文件草稿 1321 L | 17 op / hits 六字段 / frame 同代 / 不去重 —— 全部只是草稿，无测试 |
| 6 | 稳定门 | `NOT_RUN` | — | 30 min 切片未跑（禁执行） |
| 7 | 性能门 | `NOT_RUN` | T52 采集脚本 + README + 03-performance.md 草稿 | 阈值仍"拟议待冻结"（计划 L767-769） |
| 8 | 签名门 | `UNPROVEN` | `docs/flutter-migration/release.md` + `tool/release/verify_signing.sh` 已提交未集成 | keystore/别名/口令保管未核对；脚本未执行 |
| 9 | 发布门 | `NOT_RUN` | — | 升级/回滚演练未做；`allowBackup=false` 语义未验 |

**九门 0 PASS。** 因此计划 L792-800 的六条"不能宣称"全部生效（§9）。

### 3.2 画面门：为什么是 DEVICE_BLOCKED 而不是 NOT_RUN

画面门要求"横屏已取证页逐 ROI 人工通过"（计划 L761）。当前连"已取证页"都只剩文件名：
12 张 PNG 的实体在 `/tmp/rhine-qt-baseline-2026-11-09/` 被清空。索引能证明"当时拍过什么、
不能证明什么"（计划 L88-99），不能拿来逐 ROI 比对。补采是唯一出路（§8 C1），
在补采完成前，画面门不接受任何 SSIM/ΔE 分数替代（计划 L769 禁大 mask）。

### 3.3 动作门：本版新增

计划 L329 的矩阵有"动作"列，T54 卡 L736 要求"动作"门，旧稿缺此轴（MF8）。

- **命名空间**：计划 L357 列出 60+ 字面量（`open`/`back`/`close-modal`/`archive:tab-mode`/
  `column-prev|next`/`player:remove:<i>`/`music:qr|preview|cover-front|…`/`viewer:reset|clear|frosted|close`/
  `quality:set:<id>`/`msaa:<v>`/`aa-mode:<v>`/`render-scale:<v>`/`confirm:yes`…）。
  冻结责任在 T05（`docs/flutter-migration/contracts/domain.md` + `test/fixtures/login_matrix.json`，
  均草稿）。**未冻结 = 动作门无判据。**
- **分发实现**：T32 输入路由（`hit_layer`/`key_router`/`pointer_router`/`wheel_router`）、
  T33 页面动作（`archive_page`/`chrome`）、T34 详情动作（`action_row`）、T39/T40 弹层动作，
  全部未跟踪、未集成、未执行测试。
- **时序**：commands/hits/frame 三代次同发（计划 L762）属协议门与动作门交叉项，见 §3.5。
- 判定 `NOT_RUN`；不得因为"字符串出现在源码里"就算动作已实现。

### 3.4 状态门要点

计划 L367-376 的六组连续性（lane/目录栈/游标；输入文本/selection/composing/focus；QR 墙钟/
generation/cancel 屏障；队列/当前曲/位置/模式/歌词；3D 相机/时钟/boot/detail/viewer；
modal 名/关闭进度/modalOffset）。当前唯一相关产物是 T20 `lib/app/lifecycle.dart` 与
T44 `lib/app/rotation_continuity.dart`，皆草稿、皆无测试执行、皆未集成。**六组 0 组取证。**

### 3.5 协议门要点（不重复旧稿的自相矛盾）

旧稿在同一门里既写"staticreview 已过"又写"未执行"，属自相矛盾（mayFix）。本版口径：

- 契约**文档**存在（T03 `contracts/hud-protocol.md` 草稿）≠ 契约被冻结；
- 契约 **fixture** 存在（T03 `hud_commands_17.json`/`hud_hits.json` 草稿）≠ 17 op 参数与
  hits 六字段已被验证；
- 实现**草稿**存在（T30 `hud_command.dart` 743 L / `hud_frame.dart` 358 L / `hud_hit.dart` 220 L）≠ 协议成立。

三项都没有独立审查报告、都没有集成、都未执行测试 → 协议门 `NOT_RUN`。

### 3.6 门与语句的映射（哪一句话被哪一门禁掉）

| 想写的话 | 被哪门禁掉 | 依据 |
|---|---|---|
| "1:1 完成" | 全部九门 | 计划 L794 |
| "视觉已对齐" | 画面门 | 计划 L795；PNG 实体丢失 |
| "搜索正确" | 功能门 + 画面门 | 计划 L797；12 图只有空态（L90、L97） |
| "恢复已证" | 状态门 | 计划 L796；无 process-death 对照 |
| "竖屏 1:1" | 画面门 + 状态门 | 计划 L798；竖屏本就是新增设计（L359-365） |
| "可升级发布" | 签名门 + 发布门 | 计划 L799；T53 未集成、未核对 |

---

## 4. G1-G8 证据缺口现状

| # | 缺口（计划 L105-112） | 现状 | 判定 |
|---|---|---|---|
| G1 | APK 哈希未证明与当前 Qt 源码同 commit | T01 `00-baseline.md` §1 结论第 5/6 条 + §1.1 表：G1 记 `CLOSED`(artifact-level)；像素基准 `UNAVAILABLE_RECAPTURE_REQUIRED`。出处比对的两份产物（`test/baseline_manifest_test.dart` 12204 B、`test/fixtures/baseline_manifest.json` 8638 B）**仍未跟踪**，T01 提交 `c6d0861` 只含两份 docs | 出处级部分闭合 / 像素级未闭合 |
| G2 | 业务页仅 12 张局部横屏 | 计划 L99 已列未覆盖项（我的音乐/发现/登录后/播放中/Tab Mode/设置后续/弹层/错误态/竖屏）；T50 `tool/parity/compare.py` 草稿、T51 `portrait.md` 草稿均无对照结果 | 未闭合 |
| G3 | Qt 无竖屏规范 | Qt 两个 Activity 均 sensorLandscape（计划 L361）；T02 `layout.md`（`1ee6eb8`）冻结舞台换算但未集成；T43 `portrait_bands`/`portrait_stage` 草稿；T51 `portrait.md` 草稿 | `WAIT`（设计草案在，未审定） |
| G4 | 设置七区逐项可见性/平台开关未全量 | `contracts/settings-platform.md`（`c643b55`）+ `test/fixtures/settings_sections.json` + `test/settings_sections_test.dart`（`e7ef1e4`）已集成，审查 PASS；**测试未运行**；T37 `settings_row.dart` 草稿 | 契约级 `INTEGRATED` / 实现级 `NOT_RUN` |
| G5 | 存储逐键 schema、损坏回退未全量 | T07 `contracts/storage.md`（`b3f4850`）未集成；T26 三提交未集成，其中 `c556c7e` 有 **OPEN mustFix**（app_storage offline + tautology）、`fb7242a` 有 **HOLD_LOGIC_FIX**、`d921113` **parent unmet** | 未闭合（且带未闭合必修） |
| G6 | 登录后个人音乐/发现无真机画面 | T36、T38 均为**空树**（无提交、无草稿） | 未取证 |
| G7 | Android 内嵌 Node 的 Flutter 生命周期未验证 | T21 `engine_transport.dart`/`node_runtime.dart`/`integration_test/bridge_lifecycle_test.dart` 草稿 | 未验证 |
| G8 | 签名材料可用性未核对 | T53 `release.md` + `verify_signing.sh`（`10775d5`）未集成；脚本未执行 | 未取证 |

---

## 5. 页面矩阵（含"动作"列）

"动作"列逐字取自计划 L331-349；"Flutter 侧现状"只写本轮实测存在的产物，
不写"已实现"（R7）。

| 页面 | 关键状态 | 动作（计划 L329 列） | Flutter 侧现状 | 状态 |
|---|---|---|---|---|
| Consent 隐私门槛 | 首次/已同意/退出/重入 | 同意、退出 | T27 `lib/app/consent_gate.dart` + 测试草稿 | `CODE_ONLY` |
| Boot | 启动动画/跳过/35 s 切 detail | ENTER SYSTEM、skip | T31 `art_run.dart`（`180312b`，未集成） | `NOT_INTEGRATED` |
| Archive/首页 | 五 lane、目录栈、选中、滚动、Tab Mode、mask | open、column-prev/next、tab-mode、返回上一级、播放全部 | T33 `archive_page.dart` 380 L + `chrome.dart` + `track_ruler.dart` 草稿（`archive_page.dart` 是计划 L746 热点） | `CODE_ONLY` |
| 目录空态 | 空目录/返回 | 返回上一级 | T33 `directory_empty.dart` 141 L 草稿 | `CODE_ONLY` |
| 歌曲详情 | 加载/正常/无同专辑/有同专辑/播放态 | 播放、喜欢、加入歌单/队列、下一首、歌手作品、tabs、排序 | T34 `song_detail.dart` + `action_row.dart` 草稿 | `CODE_ONLY` |
| 歌单/专辑/歌手详情 | artist tabs、当前行、收藏态、排序 | 播放全部、排序、收藏、打开曲目 | 无对应产物 | `WAIT` |
| 3D 查看器 | opening/closing/reset/清晰/磨砂 | 拖拽、重置、关闭、查看封面 | T41 `lib/scene/scene_math.dart` + `test/scene/projection_test.dart` 草稿（仅投影数学，不含查看器动画/材质） | `CODE_ONLY` |
| 搜索 | 空/输入/结果/无结果/错误/分组/四标签 | 输入、清除、切标签、点结果、翻页 | 无页面产物；T05 `login_matrix.json` 草稿含搜索矩阵 | `WAIT` |
| 个人库/收藏 | 未登录/已登录/空/加载 | 登录、创建歌单、刷新、打开 | 无产物（T36 空树） | `WAIT` |
| 登录面板 | qr/phone/wechat、preparing/waiting/confirming/complete/failed | 生成/重生成、扫码、发短信、提交、取消 | T24 `login_session.dart` 已集成（`8f99813`）+ `account_manager.dart` 草稿；SMS/凭据两提交未集成 | 状态机 `INTEGRATED` / 面板 `WAIT` |
| 设置 | 七区、展开项、滚动、保存失败、缓存提示 | 开关、选择、编辑、恢复默认、清除缓存、检查更新 | T37 `settings_row.dart` 草稿；七区契约 + fixture 已集成 | 契约 `INTEGRATED` / UI `CODE_ONLY` |
| 发现 | 首屏/分页/错误/分类 | 滚动、打开卡片 | 无产物（T38 空树） | `WAIT` |
| 播放栏 | 无播放/加载/播放/暂停/seek/音量/歌词 | prev/toggle/next/seek/volume/词/队列 | T39 `player_bar.dart` 578 L **已集成**（`f51f59d`，1037 L 测试未运行） | `INTEGRATED` / 测试 `NOT_RUN` |
| 播放队列 | 空/单曲/多曲/当前项/拖动 | 播放、删除、清空、拖序、模式 | T39 `queue_modal.dart` 草稿；T23 `playback_queue.dart` 草稿 | `CODE_ONLY` |
| 歌词 | 无歌词/加载/偏移/来源/跟随 | 调偏移、切来源、重试、重置 | T23 `lyrics_controller.dart` 草稿；T39 `lyrics_panel.dart` 草稿；T40 `lyrics_offset_modal.dart` 511 L、`lyrics_source_modal.dart` 482 L 草稿 | `CODE_ONLY` |
| 更新 | 检查/无更新/有更新/下载/安装/失败 | 检查、下载、安装 | T27 `lib/platform/update_service.dart` 草稿 | `CODE_ONLY` |
| 诊断/性能面板 | 开/关/指标 | 开关、采样 | T27 `lib/diagnostics/diagnostics_service.dart` 草稿 | `CODE_ONLY` |
| Tab Mode | 开/关/列布局 | 进入/退出、选列 | T33 `chrome.dart`/`archive_page.dart` 草稿（未见独立 Tab Mode 语义产物） | `CODE_ONLY` |
| 桌面歌词 | 仅桌面 | 样式、位置 | 计划 L349：矩阵保留、Android 不实施 | 不适用 |

**横屏 19 页：0 页视觉取证，0 页动作取证；1 页（播放栏）code 集成但测试未跑。**
**竖屏：全部为新增设计，无 Qt 像素基准（计划 L359-365），T43/T51 仅草稿 → `WAIT`。**

---

## 6. 发布检查

T54 卡 L738 要求 7 项。逐项给"取证路径 + 现状"，不得以文档替代软件验收（L739 Fail 定义）。

| # | 项 | 应有证据 | 现状 | 判定 |
|---|---|---|---|---|
| 1 | Consent | 首次/已同意/退出后重入三态真机 + 持久化 | 计划 L88 只有 01/02 两张图（且实体丢失）；T27 `consent_gate.dart` 草稿 | `DEVICE_BLOCKED` |
| 2 | 更新 | 检查/无更新/有更新/下载/安装/失败 | 计划 L346 自述"E0 未覆盖"；T27 `update_service.dart` 草稿 | `NOT_RUN` |
| 3 | 诊断 | 面板开关 + 指标采样 | T27 `diagnostics_service.dart` 草稿；计划 L347 只有 E1 | `CODE_ONLY` |
| 4 | 媒体会话 | 通知栏/锁屏/耳机键/切歌 | T25 `lib/platform/media_session.dart` + 测试草稿 | `CODE_ONLY` |
| 5 | 返回键 | 5 个弹层 + Archive 层次 + 系统手势一致 | T32 `key_router.dart` 290 L 草稿；T44 `rotation_continuity.dart` 草稿 | `CODE_ONLY` |
| 6 | 存储 | 逐键 schema + 损坏回退 + 迁移不丢键 | T07 `storage.md` 未集成；T26 三提交未集成且带 OPEN mustFix/HOLD；`reports/T26-S04-notes.json:178`、`:186-188`、`:329` 明确把 QSettings 绝对路径/文件名/INI 转义与 `byte_level_compatibility` 记为 `DEVICE_BLOCKED`；`reports/T26-V3.json:222`（`evidenceRules[2]`）规定 DEVICE_BLOCKED 项不得计入 PASS | `DEVICE_BLOCKED` |
| 7 | 账号迁移 | 六登录路径 + 六 phase + 凭据兼容 | T24 状态机已集成；SMS（`a1dfd48`）与凭据/分源登出（`6f031ea`）未集成；`reports/T24-S01-review.json` PASS 只覆盖 `login_session.dart` 与 `login_state_test.dart` | `NOT_INTEGRATED` |
| — | 签名 | Qt 证书沿用 `39396cd0…05bdf`；旧 Flutter 证书 `7c514fe8…239dd4` 不覆盖；`applicationId=rhine.music.database`；versionCode 单调 | 计划 L728-732 是要求；`10775d5` 只落文档 + 校验脚本，脚本未执行，keystore/别名/口令未核对 | `UNPROVEN` |

---

## 7. 性能与稳定性

- **阈值状态：全部"拟议待冻结"**（计划 L767-769）。SSIM≥0.97、ΔE≤3、像素容差、帧时间比例
  都不得当作承诺；不得自造 60 fps / 16.6 ms / jank 1% / +10%。
- **Qt 侧特性**：按需绘制，静止低 fps 属正常（计划 L769），不得据此判 Flutter"更快"。
- **本轮产物**：T52 `tool/perf/collect_frame_times.dart`、`tool/perf/README.md`、
  `docs/flutter-migration/03-performance.md` 均为未跟踪草稿；
  `reports/T52-V8.json:37`（`unexecutedVerification`）与 `:39`（notes：
  "No device/architecture acceptance claimed"）已自述未执行、未声明设备/架构验收。
- **判定**：性能门 `NOT_RUN`；稳定门 `NOT_RUN`。30 min 切片、首帧、内存、启动均为空。

---

## 8. 补采与闭合任务（未取证页/项逐条）

| # | 任务 | 触发条件 | 产出 |
|---|---|---|---|
| C1 | 重采 12 张 Qt 横屏基准 PNG（同设备 `526f6b6d`、同 APK `bd58d95a…b5a1e`） | 需设备授权 | 恢复计划 L84-99 的实体物证 |
| C2 | 逐 ROI 横屏对照（T50） | C1 完成 + `tool/parity/compare.py` 定稿 | `docs/flutter-migration/acceptance/landscape.md` |
| C3 | 竖屏 golden 生成与清单（T51/T43） | T43 审定（计划 L365 要求未审定不得铺开） | `test/golden/portrait/full_suite_1080x2400.png` + `portrait.md` |
| C4 | 未覆盖页补采：我的音乐、发现、登录后、播放中、Tab Mode、设置第 6 项之后、弹层展开/关闭、错误/加载态 | 需登录账号 + 设备授权 | 计划 L99 清单逐项销账 |
| C5 | process-death 冷启动恢复对照 | 需设备 | 状态门"恢复已证"前提 |
| C6 | 搜索命中/排序/中文 IME 实输 | 需设备 + 输入法 | 计划 L90、L97 的"不能证明"项 |
| C7 | Node 内嵌生命周期 spike 实跑（T21） | 需设备 | G7 闭合 |
| C8 | 签名材料只读核对（keystore/别名/口令保管）+ `verify_signing.sh` 实跑 | 需人工授权读密钥材料 | G8 闭合 |
| C9 | 升级/回滚演练（保留账号/收藏/device/session，不卸载/清数据） | 需设备 + 签名可用 | 发布门 |
| C10 | 30 min 稳定切片 + 帧时间采集（T52） | 需设备 | 稳定门 + 性能门 |
| C11 | T39 剩余 4 文件（golden、modal/lyrics 对齐） | 页面任务落地后 | 补齐 `T39-W1` 的 2/6 切片 |
| C12 | T31 剩余 6 提交复核（`f5acc0c` 的 HOLD_COMPLEX_FALLBACK_FIX 必须先解） | hold 解除 | 文本链路完整 |
| C13 | T24 `a1dfd48`(SMS) / `6f031ea`(凭据) 集成 | 独立审查 | 六登录路径完整 |
| C14 | T12 Qt `TextureHost` 命名/归属修正（R7：注册 `TextureHost.h/.cpp`，实体是 T14 的 `HybridTextureHost.*`） | 架构裁决（T16） | Qt 侧可构建性 |

> C1-C10 属设备/发布侧，本轮全部未执行；C11-C14 属集成侧，需对应 owner 先解 hold。

---

## 9. 不能宣称的结论

计划 L792-800 六条，原文生效：

1. 未跑完 T54：不能称"1:1 完成"。
2. 未取真机帧：不能称"视觉已对齐"。
3. 未做 process-death 对照：不能称"恢复已证"。
4. 未做搜索命中：不能称"搜索正确"。
5. 未审定竖屏：不能称"竖屏 1:1"。
6. 未过签名/数据门：不能称"可升级发布"。

本台账追加四条（由 §2-§3 事实直接推出）：

7. 九门 0 PASS 时，不得用"大部分源码已写"论证"接近完成"——36 棵树 0 行集成（§2.3）。
8. 不得把集成台账里的 6 个 commit 当作"功能已迁移"：它们是契约/配置 + 3 个切片（§2.1）。
9. 不得把 `staticreview=PASS` 升级成 `device=PASS`（R1、R2）。
10. 不得引用本文件的旧版本（T54-V8 稿）的 §2 事实；旧稿已作废（§2.5）。

---

## 10. 维护协议

- **本文只记录证据状态，不制造证据。** 任何门要升级为 `PASS`，必须先在本文补
  `code/staticreview/integrated/device` 四轴证据并写明取证时刻与命令；缺一轴即回到原状态。
- **更新触发**：新 commit 进 `feat/flutter`；任一 hold 解除；任一真机采集完成；计划行号变动。
  更新时必须刷新 §0.2 快照时间与全部受影响行号（R6）。
- **谁写**：T54 owner 单 writer。其他人只读；发现错误走 control/report 通道，不直接改本文。
- **禁止**：用本文的表格代替软件验收（计划 L739 的 Fail 定义）；用"文档已写"关闭门；
  用 SSIM/ΔE 单指标放行（计划 L769）；把外部 Gradle 缓存或未跟踪草稿计入证据。
- **提交**：单标题 `docs: record final parity acceptance`，只加本文一个路径，不写正文、不署名。
