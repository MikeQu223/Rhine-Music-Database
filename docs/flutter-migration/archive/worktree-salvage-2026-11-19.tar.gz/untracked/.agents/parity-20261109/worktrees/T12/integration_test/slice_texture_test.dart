// T12 切片同脚本测试：Qt6 离屏纹理 → Flutter Texture 合成。
//
// port-local 说明：通道 rhine.music.database/porting/qt_texture 是本次迁移新增，
// 不是 Qt 既有远端协议字段，不得在任何对外文档里冒充 Qt 协议。
//
// 未执行记录（红线，不伪装）：
// 1) integration_test 的 dev_dependency 不在本卡可写域（pubspec.yaml 属共享文件），
//    当前没有独立依赖解析 ⇒ 本文件不可执行：ARCH_BLOCKED。
// 2) 首帧/尺寸/时间戳/旋转/后端的真实像素与性能证据必须真机取得：
//    flutter test integration_test/slice_texture_test.dart -d 526f6b6d ⇒ DEVICE_BLOCKED，
//    本轮 NOT_EXECUTED。
// 3) 输入转发/IME/a11y/媒体会话的「同一脚本」属于 T10 的 slice_runner（本树未合入），
//    这里只做能力矩阵断言与证据注释，不宣称跑通。
//
// 默认运行：只断言通道契约与 Dart 侧状态机；native 缺失时打印 ARCH_BLOCKED 原因，绝不伪造帧。
// --dart-define=RHINE_QT_TEXTURE_STRICT=true 时，native 缺失即失败（真机门用）。

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'package:rhine_music_database/platform/qt_texture.dart';

const bool _strict = bool.fromEnvironment('RHINE_QT_TEXTURE_STRICT');

/// 证据矩阵：每条断言都要能指回 Qt / Flutter 源码事实，禁止无源断言。
const Map<String, String> kEvidence = <String, String>{
  'firstFrame':
      'Qt/src/render/SceneLayerHost.cpp: polishItems→beginFrame→sync→render→endFrame 之后才有可发布帧；'
          'Flutter 侧 SurfaceTexture 必须至少收到一次 eglSwapBuffers 才有像素',
  'size': 'Qt/src/render/SceneLayerHost.cpp: resize 重建 QRhiTextureRenderTarget，尺寸随 surface 变化',
  'timestamp':
      'Qt/src/render/SceneLayerHost.cpp: 每帧 endFrame 后发布；时间戳取 CLOCK_MONOTONIC，非常量',
  'rotation':
      'Qt/src/AndroidWindow.cpp: kSensorLandscape=6 横屏锁定；旋转必须由宿主按键位重建目标与 UV',
  'ime': 'QQuickRenderControl 离屏窗口永不激活 ⇒ 没有 QInputMethod 焦点；IME 只能由宿主窗口提供（ARCH_BLOCKED）',
  'a11y': 'Qt/src/AndroidWindow.cpp: installUpdateHandler 关闭无障碍桥以避免 ANR ⇒ 离屏切片不提供 a11y',
  'mediaSession':
      'Qt/src/AndroidMediaSession.cpp: 媒体会话由 Qt 侧 QJniObject 调用 RhineMediaService，不经纹理桥',
};

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  final QtTextureController controller = QtTextureController();

  testWidgets('probe 契约：状态落在枚举内，协议版本只在 ready 时才要求一致',
      (WidgetTester tester) async {
    final QtTextureProbe probe = await controller.probe();

    expect(
      QtTextureState.values.contains(probe.state),
      isTrue,
      reason: 'probe 必须返回契约枚举内的状态，实际=${probe.state} / raw=${probe.rawStatus}',
    );
    if (probe.state == QtTextureState.ready) {
      expect(probe.protocolVersion, qtTextureProtocolVersion,
          reason: 'ready 时协议版本必须一致');
      expect(probe.isProtocolCompatible, isTrue);
    } else {
      // 宿主管道缺失时 Dart 侧填 0（未知），不得冒充 1。
      expect(probe.protocolVersion, anyOf(0, qtTextureProtocolVersion),
          reason: '非 ready 时版本只能是 0（未知）或与契约一致');
    }
    debugPrint('[T12] probe state=${probe.state.name} backend=${probe.backend.name} '
        'protocolVersion=${probe.protocolVersion} reason=${probe.reason}');
  });

  testWidgets('同脚本：create → 多帧 → resize → rotation → 输入 → status → dispose',
      (WidgetTester tester) async {
    final QtTextureProbe probe = await controller.probe();
    if (probe.state != QtTextureState.ready) {
      debugPrint('[T12][ARCH_BLOCKED] 纹理宿主不可用：${probe.state.name} / ${probe.reason}');
      if (_strict) {
        fail('RHINE_QT_TEXTURE_STRICT 要求纹理宿主可用，实际 ${probe.state.name}');
      }
      return;
    }

    const int width = 1080;
    const int height = 2400;
    const double dpr = 2.75;

    QtTextureFrame frame = await controller.create(
      width: width,
      height: height,
      dpr: dpr,
    );
    expect(frame.textureId, greaterThan(0), reason: 'Flutter Texture 需要真实 textureId');
    expect(frame.width, width);
    expect(frame.height, height);
    expect(frame.rendered, isFalse, reason: 'create 不产帧，rendered 必须是 false（不是占位）');

    // 首帧/帧序/时间戳：连续渲染必须单调递增，且至少真出过一次首帧。
    int lastSequence = -1;
    int lastTimestamp = -1;
    bool sawFirstFrame = false;
    for (int i = 0; i < 8; i++) {
      frame = await controller.render(frame.textureId);
      expect(frame.rendered, isTrue, reason: '第 $i 帧没有产出，切片不可继续');
      expect(frame.sequence, greaterThan(lastSequence), reason: 'frameSequence 必须严格递增');
      expect(frame.publishTimestampNanos, greaterThan(lastTimestamp),
          reason: '发布时间戳必须严格递增（CLOCK_MONOTONIC 每次 swap 后取值）');
      expect(frame.width, width);
      expect(frame.height, height);
      sawFirstFrame = sawFirstFrame || frame.firstFrame;
      lastSequence = frame.sequence;
      lastTimestamp = frame.publishTimestampNanos;
    }
    expect(sawFirstFrame, isTrue, reason: '至少一帧必须真的 swap 成功并标记 firstFrame');

    // 尺寸变化：目标重建后尺寸跟随（横竖互换，验证不是静态首帧）。
    final ({int width, int height}) resized = await controller.resize(
      frame.textureId,
      width: height,
      height: width,
      dpr: dpr,
    );
    expect(resized.width, height);
    expect(resized.height, width);

    // 旋转：0..3 四分之一圈必须原样回显，且旋转后仍要能出帧（防「旋转黑屏仍继续」）。
    for (final int quarterTurns in <int>[1, 2, 3, 0]) {
      expect(await controller.setRotation(frame.textureId, quarterTurns), quarterTurns);
      final QtTextureFrame rotated = await controller.render(frame.textureId);
      expect(rotated.rendered, isTrue, reason: '旋转 $quarterTurns 后黑屏 = 计划里的 Fail 条件');
      expect(rotated.rotationQuarterTurns, quarterTurns);
    }

    final QtTextureInfo info = await controller.status(frame.textureId);
    expect(info.state, QtTextureState.ready);
    expect(info.sequence, greaterThan(0));
    expect(info.firstFrameRendered, isTrue);
    expect(info.lastError, isEmpty, reason: '正常路径不该有 lastError');

    // 输入转发：离屏窗口必须能收到合成指针/按键（QCoreApplication::sendEvent）。
    expect(
      await controller.sendPointer(frame.textureId,
          x: 12.0, y: 34.0, phase: QtPointerPhase.down, buttons: 1),
      isTrue,
      reason: '证据: ${kEvidence['firstFrame']}',
    );
    expect(
      await controller.sendPointer(frame.textureId,
          x: 12.0, y: 34.0, phase: QtPointerPhase.up, buttons: 0),
      isTrue,
    );
    expect(
      await controller.sendKey(frame.textureId, key: 4 /* KEYCODE_BACK */, down: true),
      isTrue,
    );

    expect(await controller.dispose(frame.textureId), isTrue);
    final QtTextureInfo afterDispose = await controller.status(frame.textureId);
    expect(afterDispose.state, QtTextureState.released,
        reason: 'dispose 后 native 必须报 released，而不是留着 ready');
  }, timeout: const Timeout(Duration(minutes: 5)));

  testWidgets('能力矩阵：IME/a11y/媒体会话在离屏切片里显式为不支持', (WidgetTester tester) async {
    for (final String key in <String>['ime', 'a11y', 'mediaSession']) {
      expect(kEvidence[key], isNotNull, reason: '$key 必须有 Qt 源证据');
    }
    debugPrint('[T12] IME: ${kEvidence['ime']}');
    debugPrint('[T12] a11y: ${kEvidence['a11y']}');
    debugPrint('[T12] mediaSession: ${kEvidence['mediaSession']}');
  });

  testWidgets('QtTextureSurface 无 textureId/info 时只显示诊断占位，不伪造像素',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: Center(
          child: QtTextureSurface(
            width: 360,
            height: 640,
            dpr: 1.0,
            reason: 'ARCH_BLOCKED: 宿主未接线',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    expect(find.byType(Texture), findsNothing, reason: '没有 textureId 时不得渲染 Texture');
    expect(find.text('Qt texture 未就绪'), findsOneWidget);
    expect(find.textContaining('ARCH_BLOCKED: 宿主未接线'), findsOneWidget);
  });
}
