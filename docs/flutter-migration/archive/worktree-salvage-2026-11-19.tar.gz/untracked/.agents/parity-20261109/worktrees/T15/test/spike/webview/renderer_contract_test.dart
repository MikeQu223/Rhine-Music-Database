// T15-S01-M12 - source contract test for the local WebView HUD replica (plan candidate E).
//
// Qt is the specification; this file only re-derives it. Every expectation names the Qt line
// that publishes the value and reads the replica source that must reproduce it, so a reviewer
// can check the pair without running anything.
//
// Contract sources:
//   Qt/src/Glyphs.cpp:35-49      calibrated colours Gamma 1.8 -> sRGB, alpha a.size() > 3 ? a[3] : 1
//   Qt/src/Glyphs.cpp:530-564    text: baseline y + size * 1.044, scale(size/1000, -size/1000),
//                                cursor += advance * size + tracking
//   Qt/src/Glyphs.cpp:565-588    art: no baseline shift, positive y scale, width * size + tracking,
//                                count < 0 draws the whole string
//   Qt/src/Glyphs.cpp:637-825    the 17 operations, one if/else chain with no else arm
//   Qt/src/Glyphs.cpp:676-678    clip is Qt::IntersectClip
//   Qt/src/Glyphs.cpp:738-760    path: dash / max(penWidth, 1e-4), Qt::FlatCap, Qt::MiterJoin
//   Qt/src/Glyphs.cpp:761-774    arc: centre (n1, n2), radius n3, -start / -sweep, Qt::RoundCap
//   Qt/src/Glyphs.cpp:775-805    right-mask: 17 smoothstep stops over start..start+span
//   Qt/src/Glyphs.cpp:806-812    gradient: (979.2, 518.4) radius 1100, 8192 square, 3 stops
//   Qt/src/NativeHud.cpp:102-109 hits: {x, y, width, height, action, label}
//   Qt/src/PlayerBar.cpp:46-53   only the PlayerBar hit adds fixed: true
//   docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:497-510  the slice card
//
// This file has NOT been executed: flutter/dart execution is forbidden in this phase, so the
// atom report records it as RED-not-executed instead of claiming a green run.

import "dart:convert";
import "dart:io";

import "package:flutter_test/flutter_test.dart";

/// The if/else chain order of Qt/src/Glyphs.cpp:644-825, which the replica reproduces branch
/// for branch. It is an order in the dispatch, not an order inside a published stream.
const List<String> kOpOrder = <String>[
  "save",
  "restore",
  "alpha",
  "translate",
  "scale",
  "rotate",
  "clip",
  "fill",
  "ellipse",
  "text",
  "art",
  "fill-path",
  "path",
  "arc",
  "right-mask",
  "gradient",
  "image",
];

/// Identifiers of the in-page conformance checks. A missing id is a failure in the page, so the
/// renderer source must define every one of them.
const List<String> kConformanceIds = <String>[
  "alpha-multiplicative",
  "clip-intersect",
  "path-dash-normalized",
  "arc-angle-mapping",
  "right-mask-stops",
  "gradient-spec",
  "color-calibration",
  "glyph-baseline",
  "unknown-op-ignored",
  "hits-contract",
  "stage-math",
  "no-dedupe",
];

/// The inbound surface the host is allowed to call; anything else would be an invented rail.
const List<String> kRailEntries = <String>[
  "resize:",
  "publish:",
  "state:",
  "conformance:",
  "loadAssets:",
  "attachAsset:",
  "attachImage:",
  "hello:",
];

Directory repositoryRoot() {
  var directory = Directory.current;
  for (var depth = 0; depth < 12; depth += 1) {
    final hasPubspec = File("${directory.path}/pubspec.yaml").existsSync();
    final hasReplica = Directory("${directory.path}/web/rhine_replica").existsSync();
    if (hasPubspec && hasReplica) {
      return directory;
    }
    final parent = directory.parent;
    if (parent.path == directory.path) {
      break;
    }
    directory = parent;
  }
  return Directory.current;
}

String readRequired(Directory root, String relative) {
  final file = File("${root.path}/$relative");
  expect(file.existsSync(), isTrue, reason: "$relative must exist in the tree");
  return file.readAsStringSync();
}

List<String> dispatchedOps(String source) {
  final pattern = RegExp(r'op === "([a-z][a-z-]*)"');
  return pattern.allMatches(source).map((match) => match.group(1)!).toList();
}

void expectContains(String source, String needle, String why) {
  expect(source.contains(needle), isTrue, reason: "missing $needle: $why");
}

void main() {
  final root = repositoryRoot();
  final renderer = readRequired(root, "web/rhine_replica/renderer.js");
  final page = readRequired(root, "web/rhine_replica/index.html");

  group("17 operations from Qt/src/Glyphs.cpp:637-825", () {
    test("the dispatch order is the Qt if/else order, one branch per operation", () {
      final ops = dispatchedOps(renderer);
      expect(ops, equals(kOpOrder));
      expect(ops.toSet(), hasLength(kOpOrder.length), reason: "no operation may stand in for another");
    });

    test("an unknown operation is counted as unknown and never reaches the ops map", () {
      // Regression for the must-fix in reports/T15-V3-S01-REVIEW2.json: the counter used to run
      // before the dispatch, so stats.ops["not-an-op"] became 1 and the page's own
      // "unknown-op-ignored" check could never pass.
      final guardAt = renderer.indexOf("if (handled) {");
      final countAt = renderer.indexOf("stats.ops[op] = (stats.ops[op] || 0) + 1;");
      expect(guardAt, greaterThanOrEqualTo(0));
      expect(countAt, greaterThan(guardAt), reason: "the ops counter must sit behind the matched-branch guard");
      expect(renderer.substring(guardAt, countAt).contains("stats.ops["), isFalse,
          reason: "nothing between the guard and the counter may record an operation");
      expect(RegExp(r"handled = false;\s*stats\.unknown \+= 1;").hasMatch(renderer), isTrue,
          reason: "the final else arm must mark the command unhandled and count it as unknown");
    });

    test("every operation keeps the argument positions Qt reads", () {
      // Qt reads a[0] as the operation and a[i] as numbers through n(i); the replica must not
      // shift a payload into a different slot.
      expectContains(renderer, 'ctx.fillStyle = colorToCss(a[1]) || "rgba(0,0,0,1)";',
          "fill keeps its colour at a[1] and its rectangle at a[2..5] (Glyphs.cpp:691)");
      expectContains(renderer, "drawText(ctx, assets, stats, a[1], numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), a[5], numberAt(a, 6), colorToCss(a[7])",
          "text keeps value a[1], x a[2], y a[3], size a[4], weight a[5], tracking a[6], colour a[7] (Glyphs.cpp:715)");
      expectContains(renderer, "drawArt(ctx, assets, stats, a[1], numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), letters, numberAt(a, 6), colorToCss(a[7])",
          "art keeps key a[1], x a[2], y a[3], size a[4], count a[5], tracking a[6], colour a[7] (Glyphs.cpp:727)");
      expectContains(renderer, 'ctx.fillStyle = colorToCss(a[2]) || "rgba(0,0,0,1)";',
          "fill-path keeps its path at a[1] and colour at a[2] (Glyphs.cpp:737)");
      expectContains(renderer, "var penWidth = numberAt(a, 2);",
          "path keeps path a[1], pen width a[2], colour a[3], dash a[4], offset a[5] (Glyphs.cpp:740-756)");
      expectContains(renderer, 'ctx.strokeStyle = colorToCss(a[7]) || "rgba(0,0,0,1)";',
          "arc keeps centre a[1], a[2], radius a[3], start a[4], sweep a[5], pen a[6], colour a[7] (Glyphs.cpp:763-772)");
      // Must-fix M12-F1: the page publishes bitmaps into assets.images (index.html:332,341,347)
      // and never into assets.image, so the singular lookup was dead code that counted a miss
      // for every image operation.
      expectContains(renderer, "var bag = assets.images || {};",
          "image reads the same bag the page writes (index.html:332,341,347)");
      expectContains(renderer, "var img = bag[String(a[1])] || null;",
          "image keeps key a[1] (Glyphs.cpp:821); the rectangle stays at a[2..5] below");
      expect(renderer.contains("assets.image ?"), isFalse,
          reason: "the dead singular lookup expression must be gone, not merely shadowed");
      expect(renderer.contains("assets.image(String("), isFalse,
          reason: "no caller may still reach for the singular bag");
    });
  });

  group("published constants", () {
    test("stage height, baseline, pen epsilon and mask steps are the Qt values", () {
      expectContains(renderer, "var STAGE_HEIGHT = 1080;", "1080 tall logical stage");
      expectContains(renderer, "var DEFAULT_ASCENT = 1.044;", "Glyphs.cpp:536,547,558 use size * 1.044");
      expectContains(renderer, "var PEN_EPSILON = 0.0001;", "Glyphs.cpp:752,756 qMax(penWidth, .0001)");
      expectContains(renderer, "var MASK_STEPS = 16;", "Glyphs.cpp:797 constexpr int MaskSteps = 16");
      expectContains(renderer, "return { width: STAGE_HEIGHT * (width / height), height: STAGE_HEIGHT, scale: height / STAGE_HEIGHT };",
          "stageScale = height / 1080 (plan 4.3)");
    });

    test("calibrated colours use Gamma 1.8 lifted to sRGB, plain colours pass through", () {
      expectContains(renderer, "var linear = Math.pow(value, 1.8);", "Glyphs.cpp:43 pow(value, 1.8)");
      expectContains(renderer, "return linear <= 0.0031308 ? 12.92 * linear : 1.055 * Math.pow(linear, 1 / 2.4) - 0.055;",
          "Glyphs.cpp:44 sRGB transfer function");
      expectContains(renderer, 'value.length > 4 && String(value[4]).indexOf("calibrated") === 0',
          "Glyphs.cpp:38 marks calibration on the fifth entry");
      expectContains(renderer, "var a = value.length > 3 ? Number(value[3]) : 1;",
          "Glyphs.cpp:48 alpha is a.size() > 3 ? a[3].toDouble() : 1, so a null alpha is 0");
    });

    test("glyph text uses the published baseline and advance", () {
      expectContains(renderer, "ctx.translate(cursor, y + size * ascent);", "Glyphs.cpp:547,558 baseline shift");
      expectContains(renderer, "ctx.scale(scale, -scale);", "Glyphs.cpp:548,559 flips y for a glyph outline");
      expectContains(renderer, "cursor += Number(entry.advance) * size + tracking;", "Glyphs.cpp:562 advance * size + tracking");
      expectContains(renderer, "ctx.fill(new Path2D(entry.path));", "the published glyph path is drawn, not a substitute");
      expectContains(renderer, 'var units = font && font.data && font.data.units ? Number(font.data.units) : 1000;',
          "scale = size / units, 1000 in the shipped font");
      // Must-fix M12-F2: a space is published as {advance: 0.286, path: ""}. Requiring a
      // non-empty path dropped it and skipped its advance, so "Hello World" rendered as
      // "HelloWorld". The lookup must survive on the advance and the fill must be conditional.
      expect(renderer.contains("if (entry && entry.path) {"), isFalse,
          reason: "the lookup may no longer require a non-empty outline");
      expectContains(renderer, "var advance = Number(entry.advance);",
          "the lookup keeps an entry whose advance is finite even when path is empty");
      expectContains(renderer, "if (entry.path) {",
          "an empty outline is skipped for the fill while the advance below still runs");
      final fillAt = renderer.indexOf("ctx.fill(new Path2D(entry.path));");
      final advanceAt = renderer.indexOf("cursor += Number(entry.advance) * size + tracking;");
      final guardAt = renderer.indexOf("if (entry.path) {");
      expect(guardAt, greaterThanOrEqualTo(0));
      expect(fillAt, greaterThan(guardAt), reason: "the fill sits inside the empty-outline guard");
      expect(advanceAt, greaterThan(fillAt), reason: "the advance runs for every glyph, including a space");
    });

    test("lettering art has no baseline shift, a positive y scale and width advance", () {
      expectContains(renderer, "ctx.translate(cursor, y);", "Glyphs.cpp:582 translates to the art origin, no 1.044");
      expectContains(renderer, "ctx.scale(scale, scale);", "Glyphs.cpp:583 keeps y down for lettering");
      expectContains(renderer, "cursor += Number(letter.width) * size + tracking;", "Glyphs.cpp:586 advance * size + tracking");
      expectContains(renderer, "var scale = size / 1000;", "Glyphs.cpp:573,583 size / 1000");
    });

    test("a dash is normalised like QPen and composed back to stage pixels before canvas", () {
      expectContains(renderer, "var divisor = Math.max(Number(penWidth) || 0, PEN_EPSILON);", "Glyphs.cpp:752");
      expectContains(renderer, "return Number(offset || 0) / Math.max(Number(penWidth) || 0, PEN_EPSILON);", "Glyphs.cpp:756");
      // Must-fix M12-F2/dash: QPen stores the dash in pen widths and multiplies back when it
      // paints, so canvas (which takes stage pixels) must receive the composed value. Feeding
      // the divided value straight to setLineDash painted a 6/4 dash as 3/2 on a 2px pen.
      expectContains(renderer, "function dashStages(penWidth, dashArray) {",
          "the stage-pixel dash is its own explicit step, not a silent reuse of the divided value");
      expectContains(renderer, "return value * pen;",
          "QPen unit * pen width restores the published stage length (Glyphs.cpp:751-756)");
      expectContains(renderer, "function penWidthStage(penWidth) {",
          "the painted width is derived once, from QPen semantics, for both the stroke and the dash");
      expectContains(renderer, "var pen = penWidthStage(penWidth);",
          "the dash multiplies back by the painted width, not by the 1e-4 divisor");
      expectContains(renderer, "if (!isFinite(width) || width <= 0) {",
          "a zero width pen is a 1px cosmetic pen (qpen.cpp:489-490), not a 1e-4 wide pen");
      expectContains(renderer, "function cosmeticStrokeWidth() {",
          "Qt draws a zero width pen one device pixel wide whatever the transform (qpen.cpp:651-654)");
      expectContains(renderer, "var scale = Number(state.stage.scale) * Number(state.devicePixelRatio || 1);",
          "one device pixel has to be converted into this page's scaled user space");
      expectContains(renderer, "function strokeWidthStage(penWidth) {",
          "the stroke width and the dash multiplier are separate decisions");
      expectContains(renderer, "ctx.lineWidth = strokeWidthStage(penWidth);",
          "canvas ignores lineWidth 0 and its lineWidth is user space, so neither 0 nor a bare 1 is right");
      expectContains(renderer, "function dashOffsetStage(penWidth, offset) {",
          "the offset is composed the same way (Glyphs.cpp:756)");
      expectContains(renderer, "var dash = dashStages(penWidth, a[4]);",
          "the path branch hands the composed dash to canvas");
      expectContains(renderer, "ctx.lineDashOffset = dashOffsetStage(penWidth, a[5]);",
          "the path branch hands the composed offset to canvas");
      expect(renderer.contains("ctx.setLineDash(dashPattern("), isFalse,
          reason: "the raw divided value must never reach setLineDash");
      expectContains(renderer, 'ctx.lineCap = "butt";', "Glyphs.cpp:748 Qt::FlatCap");
      expectContains(renderer, 'ctx.lineJoin = "miter";', "Glyphs.cpp:748 Qt::MiterJoin");
      expectContains(renderer, 'ctx.setLineDash([]);', "a path without dashes clears a previous pattern");
    });

    test("clip intersects and alpha multiplies", () {
      expectContains(renderer, "ctx.clip();", "canvas clip is always an intersection, like Qt::IntersectClip");
      expectContains(renderer, "ctx.globalAlpha = ctx.globalAlpha * numberAt(a, 1);", "Glyphs.cpp:659 multiplies opacity");
    });

    test("arc maps Qt's negated angles onto the canvas direction", () {
      expectContains(renderer, "var angles = arcAngles(numberAt(a, 4), numberAt(a, 5));", "Glyphs.cpp:770-771");
      expectContains(renderer, "anticlockwise: sweep < 0", "a negative Qt sweep becomes an anticlockwise canvas arc");
      expectContains(renderer, "ctx.ellipse(numberAt(a, 1), numberAt(a, 2), radius, radius, 0, angles.start, angles.end, angles.anticlockwise);",
          "Qt builds QRectF(n1 - n3, n2 - n3, 2n3, 2n3) at Glyphs.cpp:763");
      expectContains(renderer, 'ctx.lineCap = "round";', "Glyphs.cpp:772 Qt::RoundCap");
    });

    test("right-mask uses 17 smoothstep stops and fills start..right", () {
      expectContains(renderer, "var eased = progress * progress * (3 - 2 * progress);", "Glyphs.cpp:800 smoothstep");
      expectContains(renderer, "for (var step = 0; step <= MASK_STEPS; step += 1) {", "Glyphs.cpp:798 step <= MaskSteps gives 17 stops");
      expectContains(renderer, "a: baseChannels.a * eased", "Glyphs.cpp:802 scales only the alpha");
      expectContains(renderer, "var gradient = ctx.createLinearGradient(start, 0, start + span, 0);", "Glyphs.cpp:796");
      expectContains(renderer, "ctx.fillRect(start, 0, right - start, height);", "Glyphs.cpp:805 fills start..n(4), height n(5)");
      expectContains(renderer, "stops.length === 17", "the conformance check proves the stop count");
    });

    test("gradient is the fixed Qt radial", () {
      expectContains(renderer, "cx: 979.2,", "Glyphs.cpp:807 QPointF(979.2, 518.4)");
      expectContains(renderer, "cy: 518.4,", "Glyphs.cpp:807");
      expectContains(renderer, "radius: 1100,", "Glyphs.cpp:807");
      expectContains(renderer, "{ x: -4096, y: -4096, width: 8192, height: 8192 },", "Glyphs.cpp:812");
      expectContains(renderer, "{ offset: 0.76, rgb: [23, 33, 37] },", "Glyphs.cpp:810 dark stop");
      expectContains(renderer, "{ offset: 1, rgb: [17, 24, 27] },", "Glyphs.cpp:811 dark stop");
      expectContains(renderer, "{ offset: 0, rgb: [231, 231, 225] },", "Glyphs.cpp:809 light stop");
      expectContains(renderer, "{ offset: 0.76, rgb: [227, 225, 220] },", "Glyphs.cpp:810 light stop");
      expectContains(renderer, "{ offset: 1, rgb: [228, 223, 219] },", "Glyphs.cpp:811 light stop");
    });
  });

  group("hits keep the published six fields", () {
    test("hitsAt reads the published keys and never widens or reorders them", () {
      expectContains(renderer, "var hx = Number(hit.x);", "NativeHud.cpp:103");
      expectContains(renderer, "var hy = Number(hit.y);", "NativeHud.cpp:104");
      expectContains(renderer, "var hw = Number(hit.width);", "NativeHud.cpp:105");
      expectContains(renderer, "var hh = Number(hit.height);", "NativeHud.cpp:106");
      expectContains(renderer, "found.push(hit);", "the published object is returned unchanged");
      expect(renderer.contains(".sort("), isFalse, reason: "hits are never reordered");
      expect(renderer.contains("hit.fixed ="), isFalse, reason: "fixed belongs to PlayerBar.cpp:46-53, not to the HUD");
      expect(renderer.contains('hit.action ='), isFalse, reason: "action is published, never rewritten");
      expect(renderer.contains('hit.label ='), isFalse, reason: "label is published, never rewritten");
    });
  });

  group("page rail and security shape", () {
    test("the page cannot load anything remote or take focus", () {
      expect(page.contains("http://"), isFalse, reason: "the slice is same-origin only");
      expect(page.contains("https://"), isFalse, reason: "the slice is same-origin only");
      expectContains(page, "default-src 'none'", "CSP denies by default");
      expectContains(page, "script-src 'self'", "only local scripts");
      expectContains(page, "object-src 'none'", "no plugin surface");
      expectContains(page, "base-uri 'none'", "no injected base");
      expectContains(page, "pointer-events: none;", "every pointer event belongs to Flutter");
      expect(page.contains("<input"), isFalse, reason: "the page never owns focus or IME");
      expect(page.contains("<textarea"), isFalse, reason: "the page never owns focus or IME");
      expect(page.contains("contenteditable"), isFalse, reason: "the page never owns focus or IME");
    });

    test("the rail exposes only the published entry points", () {
      expectContains(page, "window.__rhineRail = {", "one inbound surface");
      for (final entry in kRailEntries) {
        expectContains(page, entry, "the host talks to the page through this name");
      }
      expectContains(page, "window.__rhineReady = true;", "the host can wait for readiness");
    });

    test("one generation is published as a triple and a failed draw is rejected", () {
      expectContains(page, "Array.isArray(frame.commands)", "commands is part of the triple");
      expectContains(page, "Array.isArray(frame.hits)", "hits is part of the triple");
      expectContains(page, "frame.frame === null", "frame is part of the triple");
      expectContains(page, "'incomplete-generation-triple'", "a partial triple is rejected whole");
      expectContains(page, "'render-failed'", "a frame that throws is not counted as published");
      expectContains(page, "if (!renderHud()) {", "the draw result gates the publish");
      expectContains(page, "clearHud();", "a half drawn frame is cleared");
    });

    test("an absent scene module is reported instead of silently skipped", () {
      expectContains(page, "'./three_scene.js'", "the scene module is the next atom of this slice");
      expectContains(page, "reason = 'scene-module-absent'", "its absence is a published state");
      expectContains(page, "three: { present: false, glbLoaded: false, loadedKeys: [], renderClock: 0, webgl2: false, lastError: null }",
          "the initial scene state is explicit");
    });

    test("the local three.js build the page imports exists", () {
      expectContains(page, '"./vendor/three/build/three.module.js"', "the import map points at the vendored build");
      final vendor = File("${root.path}/web/rhine_replica/vendor/three/build/three.module.js");
      expect(vendor.existsSync(), isTrue, reason: "the vendored three build must be in the tree");
      expect(vendor.lengthSync(), greaterThan(1000000), reason: "a truncated vendor file would fail at runtime");
      final loader = File("${root.path}/web/rhine_replica/vendor/three/examples/jsm/loaders/GLTFLoader.js");
      expect(loader.existsSync(), isTrue, reason: "the GLB loader is vendored next to it");
    });

    test("the renderer never fetches and never evals", () {
      expect(renderer.contains("fetch("), isFalse, reason: "the page injects values; the renderer draws");
      expect(renderer.contains("XMLHttpRequest"), isFalse, reason: "no network from the renderer");
      expect(renderer.contains("new Function"), isFalse, reason: "no dynamic code");
      expect(renderer.contains("eval("), isFalse, reason: "no dynamic code");
    });
  });

  group("same-source assets", () {
    test("the glyph asset carries units 1000, ascent 1044 and advance/path entries", () {
      final file = File("${root.path}/Assets/fonts/misans-glyphs.json");
      expect(file.existsSync(), isTrue, reason: "Qt/src/Glyphs.cpp:75 loads Assets/fonts/misans-glyphs.json");
      final source = file.readAsStringSync();
      for (final weight in <String>["light", "regular", "demibold", "bold"]) {
        expect(source.contains('"$weight":{"units":1000'), isTrue, reason: "weight $weight is a published font");
      }
      final head = source.substring(0, 4096);
      expect(head.contains('"ascent":1044'), isTrue, reason: "baseline factor 1.044 = 1044 / 1000");
      expect(head.contains('"advance":'), isTrue, reason: "each glyph publishes its advance");
      expect(head.contains('"path":"'), isTrue, reason: "each glyph publishes its outline");
    });

    test("the lettering asset publishes width and path per letter", () {
      final file = File("${root.path}/Resources/boot-lettering-art.json");
      expect(file.existsSync(), isTrue, reason: "Qt/src/Glyphs.cpp:83 loads Resources/boot-lettering-art.json");
      final art = jsonDecode(file.readAsStringSync()) as Map<String, dynamic>;
      final brand = art["brand"] as Map<String, dynamic>?;
      expect(brand, isNotNull, reason: "the brand key is used by the slice fixture");
      final letters = brand!["letters"] as List<dynamic>;
      expect(letters, isNotEmpty);
      final first = letters.first as Map<String, dynamic>;
      expect(first["width"], isA<num>(), reason: "width is the art advance (Glyphs.cpp:87)");
      expect(first["path"], isA<String>(), reason: "path is the lettering outline");
    });

    test("every conformance id the slice asserts exists in the renderer", () {
      for (final id in kConformanceIds) {
        expectContains(renderer, '"$id"', "the page must answer this check");
      }
    });
  });
}
