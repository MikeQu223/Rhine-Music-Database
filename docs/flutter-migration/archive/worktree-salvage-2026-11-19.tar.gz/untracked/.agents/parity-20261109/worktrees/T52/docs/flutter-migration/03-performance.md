# Flutter 迁移性能与稳定性基线（T52）

> 状态：**UNMEASURED / 未测量**。本文件是**基线方案文档**，不是测量报告。
> 没有真机样本：没有帧时间、没有首帧、没有内存、没有启动、没有 30 min 稳定性数据；
> 没有同设备同场景 Qt 对比；没有任何阈值被冻结。所有指标行的状态列一律 `UNMEASURED`，
> 证据列一律「无（本轮禁止设备采集与执行）」。
> 本文件不含 `60 fps` / `16.6 ms` / `jank 1%` / `+10%` 之类的承诺（这些字样只出现在计划原文
> 照抄与「不许写」的纪律条目里）；本文件也不宣称任何指标已通过、达标或已对齐。

- 计划卡：T52 性能与稳定性基线（`docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md:718-724`）
- 本文件原子：T52-C18-A2（输出 `docs/flutter-migration/03-performance.md`）
- 分支 / 基线：`flutter/p4-t52-performance-tool` / `8ed3067b0812eb2612f7841ec127a6e8ca93231b`（本树 HEAD）
- 工作树：`.agents/parity-20261109/worktrees/T52`
- 同卡产物（只读引用，别树不改）：见 §1
- 设备门：`DEVICE_BLOCKED`（未解除）；宿主接线：`ARCH_BLOCKED`（未解除）——见 §7

## 0. 本文件是什么，不是什么

| 是 | 不是 |
| --- | --- |
| 把 T52 卡的**采集口径、报告契约、未测项目、证据纪律、门状态**固化成可复核文本 | 不是测量结果；不含任何实测数字 |
| 说明「未来怎样采、采到什么形状、哪些字段必须带、哪些结论仍然不能下」 | 不是阈值判定器，不给通过/失败 |
| 与 `tool/perf/README.md`、`tool/perf/collect_frame_times.dart` **逐字对齐**的消费说明 | 不是 CI 性能门，不设性能预算 |
| 记录本轮 E0 = 0 与全部未执行验证 | 不是「性能已对齐」的证明，也不是发布放行 |

## 1. 计划锚点（行号已在本树逐行核对）

计划文件：`docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md`（共 869 行）。

| 计划行 | 原文要点 | 对本文件的含义 |
| --- | --- | --- |
| `:718` | `#### T52 性能与稳定性基线` | T52 卡标题行 |
| `:719` | `Owner: PERF · Deps: T50、T51 · Files: Create tool/perf/collect_frame_times.dart、tool/perf/README.md、docs/flutter-migration/03-performance.md` | 本文件是本卡 Files 段的第三项（末项） |
| `:720` | `[ ] 采集帧时间分布、首帧、内存、启动、30 min 稳定性；同设备同场景对比 Qt。` | 五项采集目标 + 对比前提；**当前全部未做**（§3、§8） |
| `:721` | `[ ] 指标标"拟议待冻结"；不写固定 60fps/16.6ms/jank 1%/+10%。` | 阈值纪律（§6） |
| `:722` | `[ ] 静止低 fps 正常；不以删功能换分数。` | 解释性纪律（§6） |
| `:723` | `Pass: 数据可复核、差异有解释。Fail: 自造阈值当承诺。` | Pass/Fail 判定（§9） |
| `:724` | `Commit: docs: record performance baseline and stability` | 提交标题（由父提交，本原子无 Git 权限） |
| `:767-769` | §9.2 拟议辅助指标（待基线冻结）：`SSIM≥0.97、ΔE≤3、像素容差、性能比例均为拟议，必须用 Qt 同设备同场景基线冻结后才可写入验收`；并明确 `原 Qt 按需绘制，静止低 fps 正常，不得自造 60fps/16.6ms/jank 1%/+10% 承诺` | 所有性能比例的冻结前提；本文件不冻结任何比例 |
| `:792-799` | §9.4 不能宣称的结论：`未跑完 T54：不能称"1:1 完成"`、`未取真机帧：不能称"视觉已对齐"` 等六条 | 本卡受同一禁令约束：不宣称任何性能结论 |

**行号边界澄清。** 任务描述写的 `plan:718-726` 里，`:725` 是空行，`:726` 是 **T53** 卡的标题
（`#### T53 签名、数据升级与回滚`）。T52 卡的实体范围是 `:718-724`；引用时不得把 T53 的内容算进 T52 卡。

**本卡三份产物。**

| 产物 | 写者 | 状态 | 行数 / bytes | sha256（本树快照，消费方须自行重算） |
| --- | --- | --- | --- | --- |
| `tool/perf/collect_frame_times.dart` | T52-C18-A1（接管 T52-S01-M12 草稿） | 已编写，**未执行** | 949 / 33036 | `22db286c7a2e9379b48a9cfd78dae39ea18f5d7068c782c128c8523bc43fe3ea` |
| `tool/perf/README.md` | T52-C18-A1（接管 T52-S01-M12 草稿） | 已编写，**未执行**（A1 仍在原地修订，见脚注） | 372 / 23511 | `618636fec63d98491eac7b56efcdf04b279527d4bb3412691ed89239c48b8697` |
| `docs/flutter-migration/03-performance.md` | T52-C18-A2（本原子） | 本文件 | 见本原子 report | 见本原子 report |

> 脚注：表中行数 / bytes / sha256 是 2026-11-10 07:35 CST 读到的 T52-C18-A1 **待提交版本**（A1 尚未提交，本文件不引用任何 commit 标识）。A1 若继续修订这两个文件，行号、bytes 与 sha256 都会变动：消费方须以磁盘上重算的 `sha256sum` / `wc -lc` 为准，并优先按**章节名与字段名**定位，而不是只依赖行号。本文件正文对这两个 A1 文件的引用，行号均按该 06:45 快照核对。

「已编写，未执行」的含义（`tool/perf/README.md` 状态横幅 :3-6、§9 未执行验证记录 :347-358）：`dart analyze` / `dart run` /
`flutter …` / Gradle / adb 全部未运行，仓库里没有任何真实样本，也没有任何报告产物。

## 2. 证据纪律

等级沿用姊妹文档（`worktrees/T16/docs/flutter-migration/02-adjudication.md:11-16`）：

| 等级 | 含义 | 在本文件中的可用性 |
| --- | --- | --- |
| E0 | 真机安装 / 启动 / 采集 / 截图实证 | **唯一**可填指标行的等级。**本轮 E0 采集数 = 0** |
| E1 | 直读源码行 | 只作契约与口径依据，不能作性能证据 |
| E2 | APK / 证书 / 哈希 / 版本 | 只作发布门依据，与性能无关 |
| E3 | 推断 / 设计候选 / 未逐行核对 | 只作线索，不写入任何指标行 |

硬规则：

1. 没采过的指标不得填数值，只能标 `UNMEASURED`（本文件全部指标行如此）。
2. 不得用源码常量、工具 README 的描述或设计推断替代真机样本。
3. 不得把「口径已定义」写成「指标已测量」——本文件每张表都区分这两件事。
4. 指标必须绑定到一段脚本化场景（`tool/perf/README.md` §3.1 字段表 `scene.id` + `scene.description` 行 :88），孤立的 fps 数字无意义。

## 3. 指标清单（全部 UNMEASURED）

状态列统一为 `UNMEASURED`；证据列统一为「无（本轮禁止设备采集与执行）」。
「拟议状态」列说明该指标的阈值/口径是否冻结：**全部「拟议待冻结」**。

| 指标 | 卡内要求 | 采集口径（来源） | 现状状态 | 证据 | 拟议状态 |
| --- | --- | --- | --- | --- | --- |
| 帧时间分布（四相位百分位） | plan:720 | `tool/perf/README.md` §4 输出表 :154；`collect_frame_times.dart` 的 `distribution` :615-623（`buildMs` :619 / `rasterMs` :620 / `totalSpanMs` :621 / `vsyncOverheadMs` :622） | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |
| 首帧（first frame） | plan:720 | **当前无口径**：collector 只聚合 `frame` 记录，没有 first-frame 字段（`collect_frame_times.dart` 的 `distribution` :615-623 只聚合四相位，未定义首帧字段） | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |
| 内存（PSS / Java heap / native） | plan:720 | **Flutter 侧无口径**；Qt 侧仅有 `RHINE_MEMORY_PROBE`（`tools/perf/README.md:93`、`:108`） | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |
| 启动（cold / warm start） | plan:720 | **当前无口径**：collector 不产出启动指标 | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |
| 30 min 稳定性 | plan:720；稳定门见 `:764` | **当前无采集方案**：`:764` 的稳定门只写「切片 30 min 无崩溃/ANR/OOM；性能数据可复核」 | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |
| 同设备同场景 Qt 对比 | plan:720 | `tool/perf/README.md` §8 :323-345；`collect_frame_times.dart` 的 `_unavailableComparison` :736-757、`_compare` :758-837；前提是 Qt 侧同 schema 导出器 | `UNMEASURED` | 无（本轮禁止设备采集与执行） | 拟议待冻结 |

**诚实边界。** 上方「当前无口径」的三行（首帧、内存、启动）与「无采集方案」的一行（30 min）
不满足 `:720` 的采集要求：`tool/perf` 工具链目前**只覆盖帧时间分布**这一项。其余四项在
`tool/perf/README.md` 与 `collect_frame_times.dart` 中都没有对应字段，本轮不得假装它们「采过」或「口径已定」。

## 4. 采集与报告口径（与 tool/perf 逐字对齐）

### 4.1 输入：`rhine.frame-timings.samples/1`（JSONL）

- 一行一条 JSON；空行与 `#` 开头行忽略（`tool/perf/README.md` §3.1 :55；`collect_frame_times.dart` 解析循环 :297）。
- **必须有且只有一条 `meta`**，另有每条 `FrameTiming` 一条 `frame`（`tool/perf/README.md` §3.1 记录形状 :57-90、§3.2 :94-114）。
- `frame` 必需五个相位时间戳：`vsyncStartUs` / `buildStartUs` / `buildFinishUs` /
  `rasterStartUs` / `rasterFinishUs`；`rasterFinishWallUs`（墙钟）与 `appState` 可选但强烈建议
  （`tool/perf/README.md` §3.2 字段表 :105-114；`collect_frame_times.dart` 相位解析缺键记 `missing_or_non_integer_phase_timestamp` :355）。单位统一为微秒。
- 派生量由工具计算：`buildUs = buildFinishUs - buildStartUs`、
  `rasterUs = rasterFinishUs - rasterStartUs`、`totalSpanUs = rasterFinishUs - vsyncStartUs`、
  `vsyncOverheadUs = buildStartUs - vsyncStartUs`（`tool/perf/README.md` §3.2 :116-123；
  `collect_frame_times.dart` 的 `_Frame` getter :214-217，非负校验 :223-226）。
- 任一派生量为负 → 该行记固定 reason `non_monotonic_phase_span` 并剔除
  （`tool/perf/README.md` §3.2 :125-140；`collect_frame_times.dart` :369）。invalid 的 reason 是固定键：
  `json_parse_error` / `record_is_not_a_json_object` / `duplicate_meta_record` /
  `unknown_record_type` / `missing_or_non_integer_phase_timestamp` / `non_monotonic_phase_span`。
- `meta.schema` 存在且不等于 `rhine.frame-timings.samples/1` → exit 3 拒绝
  （`tool/perf/README.md` §3.1 :92；`collect_frame_times.dart` :385-388）。

### 4.2 窗口与热身裁剪（全有全无）

- `meta.captureWindow.startWallUs` 与 `endWallUs` **都给**才用 meta，缺一个就两端一起丢弃、
  改用帧墙钟的 min/max（`tool/perf/README.md` §3.1 :89、§4.2 :216；`collect_frame_times.dart` 的 `windowFromMeta` :422-423、`windowSource` :481）。
- `warmupUs`：`--warmup-ms*1000` 优先，其次 `meta.warmupUs`，否则 0（不裁剪）；负值直接报错
  （`collect_frame_times.dart` :405-412）。
- 裁剪顺序固定为 **热身 → 状态 → 缺失**（`tool/perf/README.md` §4.2 :214-249；`collect_frame_times.dart` :443-465）：
  1. `warmupUs > 0` 且帧无墙钟 / cutoff 不可得 → `droppedWarmupUnknownWall`；帧墙钟 < cutoff → `droppedWarmup`；
  2. `appState` 存在且 ≠ `active` → `droppedInactiveAppState`；
  3. `appState` 缺失且给了 `--active-only` → `droppedMissingAppState`。
- 唯一非确定字段是 `generatedAtUtc`（`tool/perf/README.md` §4.1 :250；`collect_frame_times.dart` :561），因此同输入可复现。
- Qt 侧热身的位置：`tools/perf/bench2.sh:38`（`sleep "${WARMUP:-5}"`）在**所有交互动作之前**，是启动后的
  墙钟前置段。若采集在脚本启动时就已开始，必须设 `warmupUs=5000000` 对齐（`tool/perf/README.md` §2 :38-45，:41 即 `warmupUs = 5000000`）。

### 4.3 统计口径（可手工复核）

- 单位：内部微秒，输出毫秒 3 位小数；`distribution.unit = "ms"`，`sourceUnit` 标微秒
  （`tool/perf/README.md` §4.1 :180-182；`collect_frame_times.dart` 的 `distribution.sourceUnit` :616）。
- 百分位：**线性插值**，`rank = (n-1)*q`，在升序数组上取相邻两名插值；`p50=q0.50`、`p90=q0.90`、
  `p95=q0.95`、`p99=q0.99`（`tool/perf/README.md` §4.1 :183-184；`collect_frame_times.dart` 的 `_percentile` :880-893）。
- 标准差：**总体**（除以 n），不是样本标准差（`tool/perf/README.md` §4.1 :185；`collect_frame_times.dart` :865，报告内说明字段 :618）。
- 边界 `n == 1`：百分位与 min/max 都等于该帧，`stdDev = 0`（`tool/perf/README.md` §4.1 :204）。
- `null` 表示该量不可计算，**不是 0**（`tool/perf/README.md` §4.1 :200-201）。

### 4.4 速率字段与 spanBasis 语义

- `rate.spanBasis` 三取值：`kept_frame_wall_span`（优先：保留帧自身墙钟跨度
  `max(rasterFinishWallUs) - min(rasterFinishWallUs)`）/ `capture_window`（样本无墙钟或跨度非正时退化）/
  `unavailable`（两者都不可得，速率字段为 null）（`tool/perf/README.md` §4.1 :186-189；
  `collect_frame_times.dart` 的 `rateBasis` :518-520）。
- 分子与分母同源：`spanBasis = kept_frame_wall_span` 时 `framesInRate` 只数**带墙钟**的保留帧
  （`tool/perf/README.md` §4.1 :196-199；`collect_frame_times.dart` 的 `rateFrames` :524）。
- `engineFramesPerSecond = framesInRate * 1e6 / span`（`collect_frame_times.dart` :529-530）。
- `busyRatio = Σ totalSpanUs / span`，可 >1（相邻帧跨度重叠），**只作负载描述**；静止时很低是正常的，
  不代表掉帧（`tool/perf/README.md` §4.1 :192；`collect_frame_times.dart` 的 `busyRatio` :531-533）。
- `spanBasis = capture_window` 时，被热身裁掉的帧仍占窗口时间，`engineFramesPerSecond` 与 `busyRatio`
  **都会**被系统性低估（`tool/perf/README.md` §4.1 :202-203）。

### 4.5 输出：`rhine.frame-timings.report/1`

报告是一份 JSON，字段顺序固定（`tool/perf/README.md` §4 :142-159；`collect_frame_times.dart` 的 `_buildReport` :403-661）：

| 区块 | 关键字段 |
| --- | --- |
| `tool` | `path` / `revision` / `atom` / `plan` / `planSection` |
| `input` | `path` / `bytes` / `linesRead` / `encoding` / `samplesSchema`（**不含哈希**） |
| `scene` | `id` / `description` / `source`（`meta` / `cli_label_override` / `missing`） |
| `measurement` | `status` / `thresholds` / `deviceGate` / `productionWiring` / `captureMode` |
| `window` | `source` / `startWallUs` / `endWallUs` / `spanMs` / `warmupUs` / `warmupTrimApplied` |
| `counts` | `framesKept` / `dropped*` / `appStateCounts` / `invalid` / `metaRecordsUsed`（恒为 1） |
| `distribution` | `buildMs` / `rasterMs` / `totalSpanMs` / `vsyncOverheadMs`（各 count/min/p50/p90/p95/p99/max/mean/stdDev/sum） |
| `rate` | `engineFramesPerSecond` / `busyRatio` / `spanUs` / `spanMs` / `spanBasis` / `framesInRate` / `note` |
| `provenance` | `complete` / `gaps` / `recorder` / `device` / `app` / `scene` / `activeOnlyFilter` / `appStateCounts` |
| `comparison` | `available` / `path` / `baselineSchema` / `metric` / `deltaMs` / `ratio` / `verdict` / `reason` |
| `nonClaims` | 字符串数组（报告自带「不能宣称什么」） |
| `capture` | 原始 `meta` 原样回显 |

`provenance.gaps` 的固定文案（缺证据就逐条列出，`complete` 转 false；`collect_frame_times.dart` 的 `_provenance` :663-733）：
`recorder block missing…` / `recorder.api missing` / `recorder.flutterVersion missing` /
`recorder.buildMode is not "debug"` / `device block missing: same-device Qt comparison impossible` /
`app block missing: build identity unknown` / `scene missing: distribution is not tied to a scripted scenario` /
`captureWindow missing in meta: window derived from frame wall clocks` /
`warmupUs missing or zero: warm-up frames are included` /
`some samples carry no appState: active-app filtering is partial`。

### 4.6 measurement 硬约定（未测状态就在这里）

```json
{
  "status": "NO_VALID_SAMPLES | SAMPLED_UNFROZEN",
  "thresholds": { "frozen": false, "evaluated": false,
                  "provenance": "…plan §9.2…", "reuseForbidden": ["…48 MiB…"] },
  "deviceGate": "DEVICE_BLOCKED",
  "productionWiring": "NOT_WIRED",
  "captureMode": "debug-only; non-active-app samples excluded"
}
```

（`collect_frame_times.dart` 的 `measurement` :571-587；`tool/perf/README.md` :161-176。）

- `frozen` / `evaluated` **永远是 `false`**：没有阈值可判，也没有 Qt 基线。
- `SAMPLED_UNFROZEN` 只表示「有样本可读」，**不等于达标**；无有效样本时是 `NO_VALID_SAMPLES`。
- `deviceGate: DEVICE_BLOCKED`：真机采集与像素/性能验收未做，工具不替它开门，只能由真机采集解除。
- `productionWiring: NOT_WIRED`：采集不接应用启动路径（`tool/perf/README.md` §5 :252-256；`collect_frame_times.dart` :585）。
- `thresholds.reuseForbidden` 明写：协议/内存上限（如 48 MiB Node 堆）是**契约边界**，不是帧时间阈值；
  `60 fps / 16.6 ms / jank<1% / +10%` 式承诺在同设备 Qt 基线冻结前禁止。

### 4.7 comparison.verdict 恒为 NOT_EVALUATED

无论可比与否，`comparison` 形状固定，`verdict` **恒为 `NOT_EVALUATED`**
（`tool/perf/README.md` §8 :328-342；`collect_frame_times.dart` 的 `_unavailableComparison` :736-757、`_compare` :758-837，`verdict` 见 :749 与 :830）：

- 无可比基线（`--baseline` 未给 / 不存在 / 非 JSON / schema 不符 / 缺 `p50Ms`+`p95Ms`）→
  `available:false`、`deltaMs` 与 `ratio` 为 `null`，并附 `reason`。
- 可比时 → 额外产出描述性 `deltaMs.p50/p95` 与 `ratio.p50/p95`，并附 `equivalence: UNVERIFIED`；
  `reason` 写 `plan §9.2: no frozen performance threshold; deltas are descriptive`。
- 未给基线时还附 `qtAdapter: NOT_IMPLEMENTED: tools/perf (Qt harness) prints 内容帧/s and FG diag lines;
  it does not export rhine.frame-timings.report/1 yet`（`collect_frame_times.dart` :763-765）。

### 4.8 等价性未验证：Qt 内容帧/s ≠ Flutter engineFramesPerSecond

- Qt 口径（唯一参照）：**内容帧/s = `节拍诊断` 的 `render/s`（`Engine::m_renderFrames`）**，即画面内容
  真正更新的次数；`fg=off` 时 Vulkan 的 presented ≈ 内容帧 × 1.86，拿 presented 当帧率是错的
  （`tools/perf/README.md:13-23`；`tool/perf/README.md` §2 :29-31、§7 硬约束表 :317）。
- Flutter 的 `FrameTiming` 是**引擎帧**，与 Qt 的「内容帧」是否一一对应**没有验证过**
  （`tool/perf/README.md` §2 :48-51）。因此速率字段命名 `engineFramesPerSecond`，并在 `rate.note` 与
  `comparison.equivalence` 标 `UNVERIFIED`（`collect_frame_times.dart` 的 `rate.note` :632-640、`equivalence` :833-835）。
- 结论纪律：**不能把两个 fps 数字直接相减当「对齐」**。同设备同场景时，比的应该是**同一段动作脚本下的
  帧间隔分布**（`tool/perf/README.md` §2 :50-51），且 `ratio` 不是 parity（`collect_frame_times.dart` :833-835）。

### 4.9 报告自带的 nonClaims

`collect_frame_times.dart` 的 `nonClaims` :651-658 固定五条：

1. 本报告不含任何阈值判定，不能读出「p95 通过/不通过」。
2. 48 MiB 等协议或内存上限不是帧时间阈值，本报告未复用为性能门。
3. 非 active app 的样本不参与结论；采集仅限调试构建与显式开关。
4. 静止低 fps 是正常现象；帧率必须连同场景动作脚本一起读。
5. 未与 Qt 同设备同场景基线对照前，不得声称性能对齐。

## 5. Qt 对齐口径（同设备同场景是硬前提）

未来对比必须复用 `tools/perf/bench2.sh` 的**同一段动作脚本**（`tools/perf/README.md:53-55`）：

| 步骤 | 脚本位置（本树已核对） |
| --- | --- |
| 杀旧进程 | `tools/perf/bench2.sh:21` |
| 注入固定起始 session | `tools/perf/bench2.sh:24` |
| 启动（带 `RHINE_FG_DIAG` / `RHINE_PACE_DIAG` / `RHINE_KEY_PROBE`） | `tools/perf/bench2.sh:27-34` |
| 等首条 `节拍诊断` | `tools/perf/bench2.sh:37` |
| 热身 5 s（`WARMUP` 默认 5） | `tools/perf/bench2.sh:38`；默认值见 `tools/perf/README.md:63` |
| 聚焦窗口 | `tools/perf/bench2.sh:40-46` |
| `ESC` 关设置弹窗 → `→` 切「收藏专辑」→ `F11` 全屏 | `tools/perf/bench2.sh:48-51` |
| 按住 `↓` 20 s | `tools/perf/bench2.sh:53-55` |
| 截图 | `tools/perf/bench2.sh:57` |
| 杀进程 | `tools/perf/bench2.sh:59` |

- 场景是「收藏专辑」（COLLECTION 04，98 条），不是 COLLECTION 03：后者在账号校验失败时为空，
  长按 ↓ 没有可选项、测不出负载（`tools/perf/README.md:67-69`；`bench2.sh:48-49`）。
- 只有 5 个设置键生效：`aa-mode` / `render-scale` / `supersample` / `fg` / `vsync`
  （本文件在本树核对所得：`Qt/src/render/RenderConfiguration.h:76-80`；`tools/perf/README.md:70-72` 记录同一组键。
  引用源码行号的消费方须自行复核——本文件只采用自己核对过的行号）；`msaa` / `aa-scale` 是残留存储值，
  `quality=hires` 是音质不是画质（`tools/perf/README.md:72`）。

- 关键探针输出形状：`RHINE_PACE_DIAG=1` → `节拍诊断: tick/s=… sceneUpd/s=… hudUpd/s=… render/s=… 间隔均=…ms step均=…ms`；
  `RHINE_FG_DIAG=1` → `FG diag: presented … rendered … skipped … gapP50 …`（`tools/perf/README.md:102-103`）。
- **同设备同场景的前提**（`tool/perf/README.md` §8 :343-344）：同一台 Android 设备、同一场景脚本、Qt 与 Flutter
  都跑满同一段动作；桌面 `tools/perf/`（niri/grim/uinput）那套**不等价于** Android 真机。设备身份须与 T01
  台账的同一台设备一致（`worktrees/T01/docs/flutter-migration/00-baseline.md:51`：serial `526f6b6d`，OPD2511，
  Android 16/API 36）。
- Qt 侧目前**没有** `rhine.frame-timings.report/1` 导出器：`tools/perf/` 输出的是 `节拍诊断` 文本行与
  `FG diag` 行（`tools/perf/README.md:98-108`），不是本 schema；报告的 `comparison.qtAdapter` 如实写
  `NOT_IMPLEMENTED`（`tool/perf/README.md` §8 :325-327；`collect_frame_times.dart` :763-765）。

> 行号稳定性注：本节与上表的 `Qt/src/render/RenderConfiguration.h:76-80` 以基线 `8ed3067b0812eb2612f7841ec127a6e8ca93231b` 实测为准；迁移期间 Qt 源不改，若后续 rebase 导致行号漂移须重新核对（`tools/perf/README.md:70` 写的 `:61-65` 与本次实测不符，本文件不沿用该值）。

## 6. 阈值纪律

1. **不写** `60 fps` / `16.6 ms` / `jank 1%` / `+10%`（plan:721、§9.2 `:769`；`tool/perf/README.md` §1 表 :13、
   §7 硬约束表 :315；`collect_frame_times.dart` 头部约束 :14-18、`reuseForbidden` :577-582）。
2. **不把协议/内存上限当性能阈值**：48 MiB Node 堆等是契约边界，报告 `thresholds.reuseForbidden` 明写
   （`tool/perf/README.md` §1 表 :15、§7 硬约束表 :316；`collect_frame_times.dart` :577-582）。
3. **不做 CI 性能门**：本工具不产出通过/失败，连阈值参数都不接受（`tool/perf/README.md` §1 表 :12、
   §7 硬约束表 :315；`collect_frame_times.dart` 头部约束 :14、用法说明 :100）。
4. **「静止低 fps 正常；不以删功能换分数」**（plan:722 原文）——解释：
   - 原 Qt 是**按需绘制**，静止时帧率低是正常现象，不得据此判 jank（`plan:769`；`tool/perf/README.md` §2 :46、
     §7 硬约束表 :318；`collect_frame_times.dart` 的 `nonClaims` :655）。
   - 「不以删功能换分数」意为：**不得**为了抬高任何帧率/分位数字而删减页面、动作、状态或领域语义；
     数字必须连同场景动作脚本一起读（`collect_frame_times.dart` 的 `nonClaims` :655）。
5. 一切性能比例在 Qt 同设备同场景基线冻结前都是**拟议辅助指标**，不得写入验收（plan:767-769）。

## 7. 门状态

| 门 | 状态 | 依据 |
| --- | --- | --- |
| 宿主接线（PRODUCTION WIRING） | `ARCH_BLOCKED`（**未解除**） | T16 五候选同 slice **真实裁决未测**：`worktrees/T16/docs/flutter-migration/02-adjudication.md:6`（未裁决 PENDING_DEVICE_EVIDENCE）、`:59-71`（矩阵每格 UNMEASURED，已跑候选 0/5，赢家 UNASSIGNED）、`:100`（PRODUCTION WIRING → ARCH_BLOCKED）、`:121`（不得用源码推断代替实测） |
| 性能 / 像素设备门（MEASUREMENT） | `DEVICE_BLOCKED`（**未解除**） | `02-adjudication.md:101`（MEASUREMENT → DEVICE_BLOCKED，范围含 T50-T54）、`:119`（无设备授权窗口）；本卡采集侧：`tool/perf/README.md` §7 硬约束表 :321、§8 :345（`deviceGate = DEVICE_BLOCKED`，只能由真机采集解除）、`collect_frame_times.dart` :584 |
| 阈值 / 拟议指标冻结 | `UNFROZEN`（未冻结） | plan §9.2 `:767-769`；`measurement.thresholds.frozen = false`、`evaluated = false`（`collect_frame_times.dart` :573-574） |
| 生产埋点 | `NOT_WIRED`（未接线） | `collect_frame_times.dart` :585；`tool/perf/README.md` §5 :252-256 |

**依赖链。** 计划 `:748` 明确「契约未冻结不实现；切片未裁决不写页面；T43 未审定不铺竖屏；T53 未过不发布」。
本卡（T52）的采集结果（未来）将进入 T54 的稳定门（`plan:764`：`切片 30 min 无崩溃/ANR/OOM；性能数据可复核`），
但 T16 裁决未出、设备窗口未开之前，本卡不产出任何可复核数据，也不替任何门开门。

## 8. 卡内三条 checkbox 的当前状态与解冻前置

| 计划行 | 卡内条目 | 当前状态 |
| --- | --- | --- |
| `:720` | 采集帧时间分布、首帧、内存、启动、30 min 稳定性；同设备同场景对比 Qt | **未做（UNMEASURED）**；工具链目前只覆盖「帧时间分布」，其余四项无口径（§3） |
| `:721` | 指标标「拟议待冻结」；不写固定 60fps/16.6ms/jank 1%/+10% | **口径已固化、指标未测量**：文件与工具已写「拟议待冻结」，且未写任何固定阈值（§6） |
| `:722` | 静止低 fps 正常；不以删功能换分数 | **口径已固化**（§6 第 4 条），无数据可测 |

**未来解冻所需前置（全部 pending）：**

1. **同设备**：与 T01 台账同一台 Android 真机（`worktrees/T01/docs/flutter-migration/00-baseline.md:51`；
   serial `526f6b6d`，OPD2511，Android 16/API 36），且 `meta.device` 必填。
2. **同场景脚本**：复用 `tools/perf/bench2.sh` 的动作序列（§5），热身 `warmupUs=5000000` 对齐 `bench2.sh:38`。
3. **Qt 基线 report/1 导出器**：当前 `NOT_IMPLEMENTED`（`tool/perf/README.md` §8 :325-327）。必须先由 Qt 侧把
   `节拍诊断` / `FG diag` 文本折算成同 schema，否则 `--baseline` 永远 `available:false`。实现该导出器
   **不在本原子写域内**（§11）。
4. **授权设备采集**：真机采集、设备操作、截图补采需另行授权（`plan:790`：`命令只作未来模板；设备操作、
   账号登录、截图补采需另行授权`）。
5. **生产接线**：`NOT_WIRED`；采集仅限调试构建 + 显式开关，不得进 `main()` 或任何生产 `initState`
   （`tool/perf/README.md` §5 :252-256、§7 硬约束表 :320）。

## 9. Pass / Fail 原文与逐条判定

计划 `:723` 原文：

> Pass: 数据可复核、差异有解释。Fail: 自造阈值当承诺。

| 条目 | 原文 | 判定 | 依据 |
| --- | --- | --- | --- |
| Pass | 数据可复核、差异有解释 | **未达成**（不是失败） | 无数据：本轮 E0 采集数 = 0，没有任何 `rhine.frame-timings.report/1` 产物。可复核的**路径**已冻结（§4 的输入契约、窗口/热身裁剪、线性插值百分位、`spanBasis` 语义、`comparison` 固定形状），但「数据可复核」指的是**数据**，尚无数据即未达成 |
| Fail | 自造阈值当承诺 | **未违反**（不构成 Fail） | 本文件与整条工具链均未写任何阈值：自证字段见 `measurement.thresholds.frozen = false` / `evaluated = false` / `reuseForbidden[]`（`collect_frame_times.dart` :572-583）与 `nonClaims[]`（:651-658），纪律见 §6 |

**判定纪律。** 本轮不产生「通过」也不产生「失败」：Pass 的缺失原因是**没有测量**（而不是测量不合格），
Fail 的触发条件是**自造阈值**（本轮未发生）。任何把本文件读成「性能验收已通过」或「性能验收失败」的用法都是错的。

## 10. 未执行验证记录

| 项 | 状态 |
| --- | --- |
| `dart analyze tool/perf/collect_frame_times.dart` | 未执行（本轮禁止） |
| `dart run tool/perf/…`（stdout / `--out` / `--baseline`） | 未执行（本轮禁止） |
| `flutter test` / `flutter build` / `gradle` / `adb` | 未执行（本轮禁止） |
| 真机设备采集（帧时间 / 首帧 / 内存 / 启动 / 30 min） | 未做（无授权、无真机会话） |
| Qt 基线 `rhine.frame-timings.report/1` 导出器 | 未实现（`NOT_IMPLEMENTED`） |
| 单元测试 | 未新增、未执行（本轮不执行任何测试） |
| 本文件的验证方式 | 仅经**独立只读审查**（读文档、源码与工具 README），无运行时证据 |

因此：本文件与 `tool/perf/` 的正确性只有**静态复核**；任何「跑通了 / p95 是多少 / 帧率多少」的说法都必须是
未来某次被授权的真机会话的产物（`tool/perf/README.md` §9 :357）。

## 11. 边界

- 本原子（T52-C18-A2）只写本文件 `docs/flutter-migration/03-performance.md`，并为 `docs/flutter-migration/`
  建目录；不写其他任何文件。
- `tool/perf/collect_frame_times.dart`、`tool/perf/README.md` 是 A1（T52-C18-A1，接管 T52-S01-M12 草稿）的写域，本原子**只读引用**，未改一行。
- `tools/perf/`（Qt 侧，复数 `tools`）保持只读（`tool/perf/README.md` §10 :371-372）。
- 不改计划文件、契约、`lib/`、`android/`；不复制其它 worktree 的私有夹具（`T01` / `T16` 只读引用其公开结构、行号与产物摘要）。
- 不宣称设备 PASS，不宣布任何门解除，不写「已验证 / 达标 / 1:1 完成」。
- 本原子无 Git 写权限；提交由父（T52-C18 lead）完成，提交标题取自 `plan:724`。

## 12. 未来补采清单（全部 pending）

| # | 谁（授权前提） | 采什么 | 产出 schema / 文件 | 状态 |
| --- | --- | --- | --- | --- |
| 1 | 获授权的采集会话（设备窗口） | Flutter 调试构建 + 显式开关下的 `FrameTiming`（`meta` + `frame`）落成 JSONL | `rhine.frame-timings.samples/1` → `dart run tool/perf/collect_frame_times.dart` → `rhine.frame-timings.report/1` | pending |
| 2 | Qt 侧实现者（写域不在本卡） | `节拍诊断` `render/s` + `FG diag` 折算为同 schema | `rhine.frame-timings.report/1`（Qt 基线报告） | pending（当前 `NOT_IMPLEMENTED`） |
| 3 | 获授权采集会话 | 首帧时延 | 口径与 schema **待定义**（现无字段） | pending |
| 4 | 获授权采集会话 | 内存（PSS / Java heap / native） | Flutter 侧口径**待定义**；可参照 Qt `RHINE_MEMORY_PROBE`（`tools/perf/README.md:108`） | pending |
| 5 | 获授权采集会话 | 冷启动 / 热启动 | 口径与 schema **待定义** | pending |
| 6 | 获授权采集会话 | 30 min 连续稳定性（崩溃 / ANR / OOM + 性能分布） | 口径**待定义**；稳定门见 `plan:764` | pending |
| 7 | 获授权采集会话 | 同设备同场景 Qt × Flutter 对比 | `dart run … --baseline <qt-report.json>`；即便可比，`comparison.verdict` 仍为 `NOT_EVALUATED`，只产出描述性 `deltaMs`/`ratio` | pending |
| 8 | Lead / 用户 | 冻结拟议辅助指标（若决定冻结） | 写入验收的阈值口径（须先有 #1 + #2 + #7） | pending |

**补采的前置冻结项（不得跳过）：** `provenance.complete` 必须为 true 才能减少 `gaps`；`meta` 必须带
`recorder`（`api` / `buildMode:"debug"` / `flutterVersion`）、`device`、`app`、`scene.id` + `scene.description`、
`captureWindow`、`warmupUs`（`collect_frame_times.dart` 的 `provenance` 判定 :663-733）。

---

**一句话纪律。** 本文件固化的是「怎么采、采到什么形状、哪些字段必须带、哪些结论仍然不能下」；它不提供任何数字、
任何阈值、任何通过结论——性能门仍由 `DEVICE_BLOCKED` 与未裁决的 T16 挡在门外。
