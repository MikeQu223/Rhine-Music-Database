/**
 * Rhine replica HUD command renderer.
 *
 * This file is the browser side of the local WebView replica slice (plan candidate E).
 * It consumes exactly the values Qt publishes and invents no protocol:
 *
 *   Qt/src/NativeHud.h:74-76     commands, hits and frame are the published HUD values
 *   Qt/src/Glyphs.cpp:637-825    the 17 operations, dispatched on a[0]
 *   Qt/src/Glyphs.cpp:35-49      calibrated colours are Gamma 1.8 -> sRGB
 *   Qt/src/Glyphs.cpp:530-564    text: baseline y + size * 1.044, advance * size + tracking
 *   Qt/src/Glyphs.cpp:530-564    a space is published with an empty path and a real advance
 *   Qt/src/Glyphs.cpp:749-756    a QPen dash length is in pen widths, so the painted value is the
 *                               published stage value, never the divided one
 *   third_party/qt/qtbase/src/gui/painting/qpen.cpp:102-103, 487-490
 *                               "a dash of length 5 in width 10 is 50 pixels long" and a zero
 *                               width pen is a cosmetic pen one pixel wide
 *   Qt/src/Glyphs.cpp:565-588    lettering art: no baseline shift, positive y scale
 *   Qt/src/NativeHud.cpp:102-109 hits carry {x, y, width, height, action, label}
 *   Qt/src/PlayerBar.cpp:46-53   only the PlayerBar hit adds fixed: true
 *
 * Loaded as a classic script so the page also works from an opaque origin. Nothing here
 * fetches anything: the host injects the published values and the glyph data.
 */
(function (global) {
  "use strict";

  /** Qt renders HUD commands in a logical stage whose height is fixed (plan 4.3). */
  var STAGE_HEIGHT = 1080;
  /** Fallback baseline factor; the real one comes from the glyph JSON ascent / units. */
  var DEFAULT_ASCENT = 1.044;
  /** Qt/src/Glyphs.cpp:752,756 divide dash lengths by max(penWidth, 1e-4). */
  var PEN_EPSILON = 0.0001;
  /** Qt/src/Glyphs.cpp:797 right-mask smoothstep step count. */
  var MASK_STEPS = 16;

  function round6(value) {
    return Math.round(value * 1000000) / 1000000;
  }

  /** Qt/src/Glyphs.cpp:35-49: one linear channel lifted to sRGB. */
  function calibrateChannel(value) {
    var linear = Math.pow(value, 1.8);
    return linear <= 0.0031308 ? 12.92 * linear : 1.055 * Math.pow(linear, 1 / 2.4) - 0.055;
  }

  /** A colour is calibrated when its fifth entry starts with "calibrated" (Glyphs.cpp:36-38). */
  function isCalibrated(value) {
    return Array.isArray(value) && value.length > 4 && String(value[4]).indexOf("calibrated") === 0;
  }

  /** Normalises a published colour array into 0..1 channels. Missing alpha is 1 (Glyphs.cpp:44). */
  function colorChannels(value) {
    if (!Array.isArray(value) || value.length < 3) {
      return null;
    }
    var r = Number(value[0]);
    var g = Number(value[1]);
    var b = Number(value[2]);
    // Qt/src/Glyphs.cpp:48 is a.size() > 3 ? a[3].toDouble() : 1, so a published null is 0,
    // not "missing"; only a three element colour gets the implicit 1.
    var a = value.length > 3 ? Number(value[3]) : 1;
    if (isCalibrated(value)) {
      r = calibrateChannel(r);
      g = calibrateChannel(g);
      b = calibrateChannel(b);
    }
    return { r: r, g: g, b: b, a: a };
  }

  /** Qt rasterises into 8 bit channels, so the CSS form rounds the same way. */
  function channelsToCss(channels) {
    if (!channels) {
      return null;
    }
    var r = Math.max(0, Math.min(255, Math.round(channels.r * 255)));
    var g = Math.max(0, Math.min(255, Math.round(channels.g * 255)));
    var b = Math.max(0, Math.min(255, Math.round(channels.b * 255)));
    var a = Math.max(0, Math.min(1, channels.a));
    return "rgba(" + r + "," + g + "," + b + "," + round6(a) + ")";
  }

  function colorToCss(value) {
    return channelsToCss(colorChannels(value));
  }

  /** Done at the end of a frame, not asserted, so reported counters are never fabricated. */
  function ensureStats(stats) {
    var target = stats || {};
    if (!target.ops) {
      target.ops = {};
    }
    if (typeof target.unknown !== "number") {
      target.unknown = 0;
    }
    if (typeof target.missingGlyphs !== "number") {
      target.missingGlyphs = 0;
    }
    if (typeof target.layoutFallbacks !== "number") {
      target.layoutFallbacks = 0;
    }
    if (typeof target.missingImages !== "number") {
      target.missingImages = 0;
    }
    if (typeof target.missingArt !== "number") {
      target.missingArt = 0;
    }
    if (!target.glyphMisses) {
      target.glyphMisses = [];
    }
    return target;
  }

  /** Qt/src/Glyphs.cpp:65-90 keys glyphs by font family name, weights are these four. */
  var WEIGHTS = ["light", "regular", "demibold", "bold"];
  var SYMBOL_FONT = "symbols";

  function resolveFont(glyphs, weight) {
    if (!glyphs) {
      return null;
    }
    var key = String(weight || "regular");
    if (glyphs[key]) {
      return { name: key, data: glyphs[key] };
    }
    if (glyphs.regular) {
      return { name: "regular", data: glyphs.regular };
    }
    return null;
  }

  /**
   * Qt/src/Glyphs.cpp:539-562 draws one glyph at a time: an outline is filled and then every
   * glyph advances by advance * size + tracking. A space is published with path "" and a real
   * advance (misans-glyphs.json: " " -> advance 0.286, path ""), so a lookup that required a
   * non-empty path dropped it, skipped its advance and collapsed "Hello World" into
   * "HelloWorld". The entry therefore survives on its advance alone.
   */
  function lookupGlyph(font, glyph) {
    if (!font || !font.data || !font.data.glyphs) {
      return null;
    }
    var entry = font.data.glyphs[glyph];
    if (!entry) {
      return null;
    }
    var advance = Number(entry.advance);
    if (!isFinite(advance)) {
      return null;
    }
    return entry;
  }

  function symbolGlyph(glyphs, glyph) {
    var font = glyphs && glyphs[SYMBOL_FONT];
    if (!font || !font.glyphs) {
      return null;
    }
    var entry = font.glyphs[glyph];
    return entry && entry.path ? entry : null;
  }

  /**
   * Qt falls back to QTextLayout only for a missing glyph, a combining sequence, a complex
   * script or RTL (Glyphs.cpp:109-120). This replica must say so instead of drawing a
   * plausible wrong shape, so every fallback is counted and reported.
   */
  function needsLayoutSupport(glyph) {
    if (glyph.length > 1) {
      return true;
    }
    return /[\u0300-\u036f\u0590-\u05ff\u0600-\u06ff\u0900-\u097f\u0e00-\u0e7f\u200d\ufe0f]/u.test(glyph);
  }

  /**
   * Qt/src/Glyphs.cpp:749-756 stores the dash lengths and the offset as QPen values divided by
   * qMax(penWidth, .0001). A QPen dash length is expressed in pen widths and QPainter multiplies
   * it back when it paints (third_party/qt/qtbase/src/gui/painting/qpen.cpp:102-103, 487-488:
   * "a dash of length 5 in width 10 is 50 pixels long"), so what reaches the raster is exactly
   * the published stage value. Canvas setLineDash takes stage pixels, so that product has to be
   * restored before the value is handed over. Dividing without multiplying back is the defect
   * this pair exists to prevent: a [6, 4] dash on a 2px pen painted 3/2 stage px instead of 6/4.
   *
   * A zero width pen is a cosmetic pen one pixel wide (qpen.cpp:489-490), not a 1e-4 wide pen:
   * the divisor stays 1e-4 so the published pattern is enormous and therefore solid, exactly as
   * Qt paints it, while the width that multiplies back is 1. Multiplying by 1e-4 instead would
   * turn that solid line into a 6px dash.
   *
   * penWidthStage / dashStages / dashOffsetStage are the only place the QPen rule is applied, and
   * dashPattern stays the verbatim Qt normalisation so it can be proved against the source.
   */
  function clampPen(penWidth) {
    return Math.max(Number(penWidth) || 0, PEN_EPSILON);
  }

  /** The width QPen multiplies its dash pattern by: qstroker.cpp:1086 dashes[i] = pattern *
   *  m_stroke_width, and m_stroke_width is 1 for a zero width pen (qpaintengineex.cpp:380/407). */
  function penWidthStage(penWidth) {
    var width = Number(penWidth);
    if (!isFinite(width) || width <= 0) {
      return 1;
    }
    return width;
  }

  /**
   * Qt paints a zero width pen as a cosmetic pen: "the pen width is always drawn one pixel wide,
   * independent of the transformation on the painter" (qpen.cpp:651-654, and isCosmetic() is true
   * whenever width == 0, qpen.cpp:797; the cosmetic stroker is set to width 1 at
   * qpaintengineex.cpp:407). Canvas has no cosmetic line: lineWidth is measured in the current
   * user space, which here is the stage scaled by stageScale * devicePixelRatio
   * (index.html:114-120 applyHudTransform), so one painted device pixel is 1 / (scale * dpr)
   * stage units. Before a resize() the scale is 0, so the guard falls back to one stage pixel
   * rather than dividing by zero.
   */
  function cosmeticStrokeWidth() {
    var scale = Number(state.stage.scale) * Number(state.devicePixelRatio || 1);
    if (!isFinite(scale) || scale <= 0) {
      return 1;
    }
    return 1 / scale;
  }

  /** The stage-space stroke width for the path op: the pen width, or the cosmetic one device px. */
  function strokeWidthStage(penWidth) {
    var width = Number(penWidth);
    if (!isFinite(width) || width <= 0) {
      return cosmeticStrokeWidth();
    }
    return width;
  }

  function dashPattern(penWidth, dashArray) {
    var divisor = Math.max(Number(penWidth) || 0, PEN_EPSILON);
    if (!Array.isArray(dashArray) || dashArray.length === 0) {
      return [];
    }
    return dashArray.map(function (value) {
      return Number(value) / divisor;
    });
  }

  /** The stage-pixel dash a QPen would paint: QPen unit * painted pen width (qpen.cpp:487-490). */
  function dashStages(penWidth, dashArray) {
    var pen = penWidthStage(penWidth);
    return dashPattern(penWidth, dashArray).map(function (value) {
      return value * pen;
    });
  }

  function dashOffset(penWidth, offset) {
    return Number(offset || 0) / Math.max(Number(penWidth) || 0, PEN_EPSILON);
  }

  /** Same composition for the offset: QPen measures it in pen widths too (qpen.cpp:487-490). */
  function dashOffsetStage(penWidth, offset) {
    return dashOffset(penWidth, offset) * penWidthStage(penWidth);
  }

  /**
   * Qt/src/Glyphs.cpp:770-771 calls arcMoveTo/arcTo with -start and -sweep in degrees and
   * measures angles counterclockwise in a y-down system, while canvas measures them
   * clockwise. Mapping both to the same point on the circle gives:
   *   canvas start angle  = start radians
   *   canvas sweep        = sweep radians
   *   anticlockwise       = sweep < 0
   */
  function arcAngles(startRadians, sweepRadians) {
    var start = Number(startRadians) || 0;
    var sweep = Number(sweepRadians) || 0;
    return { start: start, end: start + sweep, anticlockwise: sweep < 0, sweep: sweep };
  }

  /** The Qt end point of an arc, used to prove the mapping above against the source. */
  function qtArcEndpoint(cx, cy, radius, startRadians, sweepRadians) {
    var theta = -Number(startRadians || 0) - Number(sweepRadians || 0);
    return { x: cx + radius * Math.cos(theta), y: cy - radius * Math.sin(theta) };
  }

  function canvasArcEndpoint(cx, cy, radius, angles) {
    return { x: cx + radius * Math.cos(angles.end), y: cy + radius * Math.sin(angles.end) };
  }

  /**
   * Qt/src/Glyphs.cpp:796-804: 17 stops (step 0..16), eased with p*p*(3-2*p) and the base
   * colour alpha scaled by that easing.
   */
  function maskStops(start, span, baseChannels) {
    var stops = [];
    for (var step = 0; step <= MASK_STEPS; step += 1) {
      var progress = step / MASK_STEPS;
      var eased = progress * progress * (3 - 2 * progress);
      stops.push({
        offset: progress,
        progress: progress,
        eased: eased,
        css: baseChannels
          ? channelsToCss({ r: baseChannels.r, g: baseChannels.g, b: baseChannels.b, a: baseChannels.a * eased })
          : null,
      });
    }
    return stops;
  }

  /** Qt/src/Glyphs.cpp:806-812: fixed centre, fixed radius, three stops per theme. */
  function gradientSpec(dark) {
    return {
      cx: 979.2,
      cy: 518.4,
      radius: 1100,
      rect: { x: -4096, y: -4096, width: 8192, height: 8192 },
      stops: dark
        ? [
            { offset: 0, rgb: [32, 42, 47] },
            { offset: 0.76, rgb: [23, 33, 37] },
            { offset: 1, rgb: [17, 24, 27] },
          ]
        : [
            { offset: 0, rgb: [231, 231, 225] },
            { offset: 0.76, rgb: [227, 225, 220] },
            { offset: 1, rgb: [228, 223, 219] },
          ],
    };
  }

  /** Logical size to stage size. stageScale = height / 1080 (plan 4.3). */
  function stageFor(logicalWidth, logicalHeight) {
    var height = Number(logicalHeight) || 0;
    var width = Number(logicalWidth) || 0;
    if (!(height > 0) || !(width > 0)) {
      return { width: 0, height: STAGE_HEIGHT, scale: 0 };
    }
    return { width: STAGE_HEIGHT * (width / height), height: STAGE_HEIGHT, scale: height / STAGE_HEIGHT };
  }

  /**
   * Hit testing over the published table. Published order is preserved: this function never
   * sorts, never dedupes and never publishes a widened rectangle. Which hit wins is a host
   * decision (Qt decides it in the Engine and NativeHudInput, not in the HUD painter).
   */
  function hitsAt(hits, x, y, padding) {
    var pad = Number(padding) || 0;
    var found = [];
    if (!Array.isArray(hits)) {
      return found;
    }
    for (var i = 0; i < hits.length; i += 1) {
      var hit = hits[i];
      if (!hit) {
        continue;
      }
      var hx = Number(hit.x);
      var hy = Number(hit.y);
      var hw = Number(hit.width);
      var hh = Number(hit.height);
      if (x >= hx - pad && x <= hx + hw + pad && y >= hy - pad && y <= hy + hh + pad) {
        found.push(hit);
      }
    }
    return found;
  }

  function numberAt(a, index) {
    var value = a[index];
    if (value === undefined || value === null) {
      return 0;
    }
    return Number(value);
  }

  function drawText(ctx, assets, stats, value, x, y, size, weight, tracking, css) {
    var font = resolveFont(assets.glyphs, weight);
    var units = font && font.data && font.data.units ? Number(font.data.units) : 1000;
    var scale = size / units;
    var ascent = font && font.data && font.data.ascent ? Number(font.data.ascent) / units : DEFAULT_ASCENT;
    var cursor = x;
    var glyphs = Array.from(String(value));
    for (var i = 0; i < glyphs.length; i += 1) {
      var glyph = glyphs[i];
      var entry = lookupGlyph(font, glyph);
      if (!entry && needsLayoutSupport(glyph)) {
        stats.layoutFallbacks += 1;
      }
      if (!entry) {
        entry = symbolGlyph(assets.glyphs, glyph);
      }
      if (!entry) {
        stats.missingGlyphs += 1;
        if (stats.glyphMisses.length < 64) {
          stats.glyphMisses.push(glyph);
        }
        continue;
      }
      if (entry.path) {
        ctx.save();
        ctx.translate(cursor, y + size * ascent);
        ctx.scale(scale, -scale);
        ctx.fillStyle = css;
        ctx.fill(new Path2D(entry.path));
        ctx.restore();
      }
      cursor += Number(entry.advance) * size + tracking;
    }
    return cursor;
  }

  function drawArt(ctx, assets, stats, key, x, y, size, count, tracking, css) {
    var letters = assets.lettering ? assets.lettering[String(key)] : null;
    if (!letters) {
      stats.missingArt += 1;
      return;
    }
    var total = count < 0 ? letters.length : Math.min(count, letters.length);
    var scale = size / 1000;
    var cursor = x;
    for (var i = 0; i < total; i += 1) {
      var letter = letters[i];
      if (!letter || !letter.path) {
        continue;
      }
      ctx.save();
      ctx.translate(cursor, y);
      ctx.scale(scale, scale);
      ctx.fillStyle = css;
      ctx.fill(new Path2D(letter.path));
      ctx.restore();
      cursor += Number(letter.width) * size + tracking;
    }
  }

  /**
   * Runs one published command stream. Every branch mirrors the Qt branch with the same
   * name; an unknown operation is silently skipped exactly as the Qt if/else chain does.
   */
  function renderCommands(ctx, commands, options) {
    var opts = options || {};
    var assets = opts.assets || {};
    var stats = ensureStats(opts.stats);
    var list = Array.isArray(commands) ? commands : [];
    for (var i = 0; i < list.length; i += 1) {
      var a = list[i];
      if (!Array.isArray(a) || a.length === 0) {
        stats.unknown += 1;
        continue;
      }
      var op = String(a[0]);
      // Counted only after a branch matched: Qt/src/Glyphs.cpp:637-825 is an if/else chain with
      // no else arm, and an unknown operation paints nothing, so it is not evidence of a draw.
      var handled = true;
      if (op === "save") {
        ctx.save();
      } else if (op === "restore") {
        ctx.restore();
      } else if (op === "alpha") {
        ctx.globalAlpha = ctx.globalAlpha * numberAt(a, 1);
      } else if (op === "translate") {
        ctx.translate(numberAt(a, 1), numberAt(a, 2));
      } else if (op === "scale") {
        ctx.scale(numberAt(a, 1), numberAt(a, 2));
      } else if (op === "rotate") {
        ctx.rotate(numberAt(a, 1));
      } else if (op === "clip") {
        ctx.beginPath();
        ctx.rect(numberAt(a, 1), numberAt(a, 2), numberAt(a, 3), numberAt(a, 4));
        ctx.clip();
      } else if (op === "fill") {
        ctx.fillStyle = colorToCss(a[1]) || "rgba(0,0,0,1)";
        ctx.fillRect(numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), numberAt(a, 5));
      } else if (op === "ellipse") {
        var ew = numberAt(a, 4);
        var eh = numberAt(a, 5);
        if (Math.abs(ew) > 0 && Math.abs(eh) > 0) {
          ctx.beginPath();
          ctx.ellipse(numberAt(a, 2) + ew / 2, numberAt(a, 3) + eh / 2, Math.abs(ew) / 2, Math.abs(eh) / 2, 0, 0, Math.PI * 2);
          ctx.fillStyle = colorToCss(a[1]) || "rgba(0,0,0,1)";
          ctx.fill();
        }
      } else if (op === "text") {
        drawText(ctx, assets, stats, a[1], numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), a[5], numberAt(a, 6), colorToCss(a[7]) || "rgba(0,0,0,1)");
      } else if (op === "art") {
        // Qt/src/Glyphs.cpp:718 is a[5].toInt(-1): only a JSON number becomes a count, and any
        // other type means "the whole string" instead of a NaN loop that draws nothing.
        var rawCount = a[5];
        var letters = typeof rawCount === "number" && isFinite(rawCount) ? Math.trunc(rawCount) : -1;
        drawArt(ctx, assets, stats, a[1], numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), letters, numberAt(a, 6), colorToCss(a[7]) || "rgba(0,0,0,1)");
      } else if (op === "fill-path") {
        ctx.fillStyle = colorToCss(a[2]) || "rgba(0,0,0,1)";
        ctx.fill(new Path2D(String(a[1])));
      } else if (op === "path") {
        var penWidth = numberAt(a, 2);
        ctx.strokeStyle = colorToCss(a[3]) || "rgba(0,0,0,1)";
        // Canvas ignores lineWidth 0 and keeps the previous width, and its lineWidth is user
        // space, so a zero width pen cannot be left as 0 nor written as a bare 1: the cosmetic
        // pen is one painted device pixel (see cosmeticStrokeWidth).
        ctx.lineWidth = strokeWidthStage(penWidth);
        ctx.lineCap = "butt";
        ctx.lineJoin = "miter";
        // Canvas takes stage pixels, QPen takes pen widths: hand over the composed value.
        var dash = dashStages(penWidth, a[4]);
        if (dash.length > 0) {
          ctx.setLineDash(dash);
          ctx.lineDashOffset = dashOffsetStage(penWidth, a[5]);
        } else {
          ctx.setLineDash([]);
          ctx.lineDashOffset = 0;
        }
        ctx.stroke(new Path2D(String(a[1])));
      } else if (op === "arc") {
        var radius = numberAt(a, 3);
        if (radius > 0) {
          var angles = arcAngles(numberAt(a, 4), numberAt(a, 5));
          ctx.beginPath();
          ctx.ellipse(numberAt(a, 1), numberAt(a, 2), radius, radius, 0, angles.start, angles.end, angles.anticlockwise);
          ctx.strokeStyle = colorToCss(a[7]) || "rgba(0,0,0,1)";
          ctx.lineWidth = numberAt(a, 6);
          ctx.lineCap = "round";
          ctx.lineJoin = "bevel";
          ctx.setLineDash([]);
          ctx.stroke();
        }
      } else if (op === "right-mask") {
        var base = colorChannels(a[1]);
        var start = numberAt(a, 2);
        var span = numberAt(a, 3);
        var right = numberAt(a, 4);
        var height = numberAt(a, 5);
        if (base && right > start) {
          var gradient = ctx.createLinearGradient(start, 0, start + span, 0);
          var stops = maskStops(start, span, base);
          for (var s = 0; s < stops.length; s += 1) {
            if (stops[s].css) {
              gradient.addColorStop(stops[s].offset, stops[s].css);
            }
          }
          ctx.fillStyle = gradient;
          ctx.fillRect(start, 0, right - start, height);
        }
      } else if (op === "gradient") {
        var spec = gradientSpec(a.length > 1 && a[1] === true);
        var radial = ctx.createRadialGradient(spec.cx, spec.cy, 0, spec.cx, spec.cy, spec.radius);
        for (var g = 0; g < spec.stops.length; g += 1) {
          radial.addColorStop(spec.stops[g].offset, "rgb(" + spec.stops[g].rgb.join(",") + ")");
        }
        ctx.fillStyle = radial;
        ctx.fillRect(spec.rect.x, spec.rect.y, spec.rect.width, spec.rect.height);
      } else if (op === "image") {
        // Qt/src/Glyphs.cpp:813-824 resolves a[1] through image(key). The page publishes its
        // bitmaps into assets.images (index.html:332, 341, 347); the singular assets.image this
        // line used to read was never written anywhere, so every image op counted as a miss.
        var bag = assets.images || {};
        var img = bag[String(a[1])] || null;
        if (img) {
          ctx.drawImage(img, numberAt(a, 2), numberAt(a, 3), numberAt(a, 4), numberAt(a, 5));
        } else {
          stats.missingImages += 1;
        }
      } else {
        handled = false;
        stats.unknown += 1;
      }
      if (handled) {
        stats.ops[op] = (stats.ops[op] || 0) + 1;
      }
    }
    return stats;
  }

  /** A minimal conforming surface used by the conformance checks that need a real context. */
  function createSurface(width, height) {
    var canvas = global.document ? global.document.createElement("canvas") : null;
    if (!canvas) {
      return null;
    }
    canvas.width = width;
    canvas.height = height;
    return canvas;
  }

  function recorder() {
    var calls = [];
    var state = { globalAlpha: 1, fillStyle: null, strokeStyle: null, lineWidth: 0, lineCap: null, lineJoin: null, lineDashOffset: 0, dash: [] };
    function record(name) {
      return function () {
        calls.push({ name: name, args: Array.prototype.slice.call(arguments) });
      };
    }
    return {
      calls: calls,
      get globalAlpha() {
        return state.globalAlpha;
      },
      set globalAlpha(value) {
        state.globalAlpha = value;
      },
      set fillStyle(value) {
        state.fillStyle = value;
      },
      set strokeStyle(value) {
        state.strokeStyle = value;
      },
      set lineWidth(value) {
        state.lineWidth = value;
      },
      set lineCap(value) {
        state.lineCap = value;
      },
      set lineJoin(value) {
        state.lineJoin = value;
      },
      set lineDashOffset(value) {
        state.lineDashOffset = value;
      },
      get lineDashOffset() {
        return state.lineDashOffset;
      },
      save: record("save"),
      restore: record("restore"),
      translate: record("translate"),
      scale: record("scale"),
      rotate: record("rotate"),
      beginPath: record("beginPath"),
      rect: record("rect"),
      clip: record("clip"),
      fillRect: record("fillRect"),
      fill: record("fill"),
      stroke: record("stroke"),
      setLineDash: function (value) {
        state.dash = value;
        calls.push({ name: "setLineDash", args: [value] });
      },
      createLinearGradient: function () {
        return { addColorStop: function () {} };
      },
      createRadialGradient: function () {
        return { addColorStop: function () {} };
      },
      state: state,
    };
  }

  function check(id, ok, expected, actual, note) {
    return { id: id, ok: !!ok, expected: expected, actual: actual, note: note || null };
  }

  function closeTo(a, b, tolerance) {
    return Math.abs(a - b) <= tolerance;
  }

  /**
   * Offline conformance. Each id is also asserted by the Dart slice test, so a page that
   * cannot prove a contract fails the slice instead of looking green.
   */
  function runConformance(options) {
    var opts = options || {};
    var assets = opts.assets || {};
    var results = {};
    function add(entry) {
      results[entry.id] = entry;
    }

    var rec = recorder();
    renderCommands(rec, [["alpha", 0.5], ["alpha", 0.5]], { assets: assets });
    add(check("alpha-multiplicative", closeTo(rec.globalAlpha, 0.25, 1e-12), 0.25, rec.globalAlpha,
      "Qt/src/Glyphs.cpp:658-659 multiplies the current opacity, it never assigns."));

    var clipCanvas = createSurface(20, 20);
    var clipCtx = clipCanvas ? clipCanvas.getContext("2d") : null;
    if (!clipCtx) {
      add(check("clip-intersect", false, "two intersecting clips keep their intersection", "no 2d context", "canvas unavailable"));
    } else {
      clipCtx.fillStyle = "rgb(255,255,255)";
      clipCtx.fillRect(0, 0, 20, 20);
      clipCtx.fillStyle = "rgb(0,0,0)";
      clipCtx.save();
      clipCtx.beginPath();
      clipCtx.rect(0, 0, 10, 10);
      clipCtx.clip();
      clipCtx.beginPath();
      clipCtx.rect(5, 5, 10, 10);
      clipCtx.clip();
      clipCtx.fillRect(0, 0, 20, 20);
      clipCtx.restore();
      var inside = clipCtx.getImageData(7, 7, 1, 1).data[0];
      var outside = clipCtx.getImageData(2, 2, 1, 1).data[0];
      add(check("clip-intersect", inside < 8 && outside > 247, "inside dark, outside untouched", "inside=" + inside + " outside=" + outside,
        "Qt/src/Glyphs.cpp:676-678 uses Qt::IntersectClip."));
    }

    var normal = dashPattern(2, [6, 4]);
    var degenerate = dashPattern(0, [6, 4]);
    var normalStage = dashStages(2, [6, 4]);
    var degenerateStage = dashStages(0, [6, 4]);
    var offsetStage = dashOffsetStage(2, 5);
    add(check("path-dash-normalized",
      closeTo(normal[0], 3, 1e-12) && closeTo(normal[1], 2, 1e-12) && closeTo(degenerate[0], 60000, 1e-6) &&
        closeTo(normalStage[0], 6, 1e-12) && closeTo(normalStage[1], 4, 1e-12) &&
        closeTo(degenerateStage[0], 60000, 1e-6) && closeTo(offsetStage, 5, 1e-12) &&
        penWidthStage(0) === 1 && penWidthStage(-3) === 1 && penWidthStage(2) === 2 &&
        strokeWidthStage(2) === 2 && strokeWidthStage(-3) === cosmeticStrokeWidth() &&
        isFinite(strokeWidthStage(0)) && strokeWidthStage(0) > 0,
      "[3,2] and [60000,40000]", JSON.stringify(normal) + " / " + JSON.stringify(degenerate) +
        " / stage " + JSON.stringify(normalStage) + " / " + JSON.stringify(degenerateStage) + " / offset " + offsetStage +
        " / painted width 0->" + penWidthStage(0) + " 2->" + penWidthStage(2) +
        " / stroke 0->" + strokeWidthStage(0) + " 2->" + strokeWidthStage(2),
      "Qt/src/Glyphs.cpp:749-756 divides by max(penWidth, 1e-4) and QPen measures the pattern in " +
        "pen widths (qpen.cpp:487-488), so the painted stage dash is the published [6,4], not " +
        "[3,2]; a zero width pen is a 1px cosmetic pen (qpen.cpp:489-490), so its enormous " +
        "pattern stays a solid line instead of collapsing to 6 stage px. That same pen is " +
        "cosmetic and paints one device pixel whatever the transform (qpen.cpp:651-654, :797), " +
        "which in this page's user space is 1/(stageScale*dpr) stage units."));

    var angles = arcAngles(0, Math.PI / 2);
    var qtPoint = qtArcEndpoint(100, 100, 50, 0, Math.PI / 2);
    var canvasPoint = canvasArcEndpoint(100, 100, 50, angles);
    var negative = arcAngles(0, -Math.PI / 2);
    add(check("arc-angle-mapping",
      closeTo(qtPoint.x, canvasPoint.x, 1e-9) && closeTo(qtPoint.y, canvasPoint.y, 1e-9) && negative.anticlockwise === true,
      "the canvas end point equals the Qt arcTo end point and a negative sweep is anticlockwise",
      JSON.stringify(canvasPoint) + " vs " + JSON.stringify(qtPoint),
      "Qt/src/Glyphs.cpp:770-771 negates start and sweep; canvas measures the other way."));

    var stops = maskStops(1240, 160, { r: 0.9, g: 0.9, b: 0.88, a: 1 });
    var halfStop = stops[8];
    add(check("right-mask-stops",
      stops.length === 17 && closeTo(stops[0].eased, 0, 1e-12) && closeTo(stops[16].eased, 1, 1e-12) && closeTo(halfStop.eased, 0.5, 1e-12),
      "17 stops, eased 0..1 with p*p*(3-2p)", "count=" + stops.length + " mid=" + halfStop.eased,
      "Qt/src/Glyphs.cpp:797-803."));

    var dark = gradientSpec(true);
    var light = gradientSpec(false);
    add(check("gradient-spec",
      closeTo(dark.cx, 979.2, 1e-9) && closeTo(dark.cy, 518.4, 1e-9) && dark.radius === 1100 && dark.stops.length === 3 &&
        dark.stops[0].rgb.join(",") === "32,42,47" && dark.stops[1].rgb.join(",") === "23,33,37" && dark.stops[2].rgb.join(",") === "17,24,27" &&
        light.stops[0].rgb.join(",") === "231,231,225" && light.stops[1].rgb.join(",") === "227,225,220" && light.stops[2].rgb.join(",") === "228,223,219",
      "centre 979.2/518.4, radius 1100, three stops per theme", JSON.stringify(dark.stops) + " / " + JSON.stringify(light.stops),
      "Qt/src/Glyphs.cpp:806-812."));

    var calibrated = calibrateChannel(0.92);
    var calibratedDark = calibrateChannel(0.08);
    var plain = colorToCss([0.5, 0.25, 0.125, 1]);
    add(check("color-calibration",
      closeTo(calibrated, 0.936042, 1e-5) && closeTo(calibratedDark, 0.103697, 1e-5) && plain === "rgba(128,64,32,1)",
      "0.92 -> 0.936042, 0.08 -> 0.103697, unmarked colours pass through",
      calibrated + " / " + calibratedDark + " / " + plain,
      "Qt/src/Glyphs.cpp:35-49, Gamma 1.8 to sRGB."));

    var font = resolveFont(assets.glyphs, "demibold");
    if (!font) {
      add(check("glyph-baseline", false, "glyph data with ascent 1044 and units 1000", "glyph data unavailable",
        "the page must report a missing glyph source instead of drawing a plausible substitute"));
    } else {
      var ascent = Number(font.data.ascent) / Number(font.data.units);
      var advance = null;
      var probe = font.data.glyphs ? Object.keys(font.data.glyphs)[0] : null;
      if (probe) {
        advance = Number(font.data.glyphs[probe].advance);
      }
      var space = font.data.glyphs ? font.data.glyphs[" "] : null;
      var spaceKept = !!space && space.path === "" && lookupGlyph(font, " ") === space;
      var spaceAdvance = space ? Number(space.advance) : 0;
      add(check("glyph-baseline",
        Number(font.data.units) === 1000 && closeTo(ascent, 1.044, 1e-9) && advance !== null && advance > 0 &&
          spaceKept && spaceAdvance > 0,
        "units 1000, ascent/units 1.044", "units=" + font.data.units + " ascent=" + ascent +
          " sampleAdvance=" + advance + " spaceKept=" + spaceKept + " spaceAdvance=" + spaceAdvance,
        "Qt/src/Glyphs.cpp:536,539 and the glyph JSON contract; a space has path \"\" and must " +
          "still advance by advance * size + tracking (Glyphs.cpp:562)."));
    }

    var unknownStats = renderCommands(recorder(), [["not-an-op", 1, 2]], { assets: assets });
    add(check("unknown-op-ignored", unknownStats.unknown === 1 && !unknownStats.ops["not-an-op"],
      "one unknown operation counted and skipped", JSON.stringify(unknownStats.unknown),
      "Qt/src/Glyphs.cpp:637-825 has no else branch, so unknown operations are ignored."));

    var hits = [
      { x: 700, y: 300, width: 328, height: 328, action: "open-detail", label: "17" },
      { x: 96, y: 1000, width: 1728, height: 80, action: "player-toggle", label: "play", fixed: true },
    ];
    var found = hitsAt(hits, 704, 304, 0);
    var padded = hitsAt(hits, 90, 1004, 16);
    add(check("hits-contract",
      found.length === 1 && found[0].action === "open-detail" && padded.length === 1 && padded[0].fixed === true &&
        Object.prototype.hasOwnProperty.call(found[0], "fixed") === false,
      "published order kept, padding widens the test only, fixed stays where Qt put it",
      JSON.stringify(found) + " / " + JSON.stringify(padded),
      "Qt/src/NativeHud.cpp:102-109, Qt/src/PlayerBar.cpp:46-53."));

    var landscape = stageFor(1462.857, 914.286);
    var small = stageFor(1280, 720);
    add(check("stage-math",
      closeTo(landscape.scale, 0.846561, 1e-6) && closeTo(landscape.width, 1728, 0.01) &&
        closeTo(small.scale, 0.666667, 1e-6) && closeTo(small.width, 1920, 1e-9),
      "height / 1080 and 1080 * aspect", JSON.stringify(landscape) + " / " + JSON.stringify(small),
      "plan 4.3 stageScale; the host compares the same numbers."));

    var duplicate = [["fill", [0, 0, 0, 1], 0, 0, 10, 10], ["fill", [0, 0, 0, 1], 0, 0, 10, 10]];
    var duplicateStats = renderCommands(recorder(), duplicate, { assets: assets });
    add(check("no-dedupe", duplicateStats.ops.fill === 2, "two identical fills are both drawn", duplicateStats.ops.fill,
      "commands, hits and frame must be published verbatim, without deduplication."));

    return results;
  }

  global.RhineReplica = {
    stageHeight: STAGE_HEIGHT,
    defaultAscent: DEFAULT_ASCENT,
    maskSteps: MASK_STEPS,
    weights: WEIGHTS.slice(),
    renderCommands: renderCommands,
    stageFor: stageFor,
    hitsAt: hitsAt,
    colorChannels: colorChannels,
    colorToCss: colorToCss,
    isCalibrated: isCalibrated,
    calibrateChannel: calibrateChannel,
    clampPen: clampPen,
    penWidthStage: penWidthStage,
    strokeWidthStage: strokeWidthStage,
    cosmeticStrokeWidth: cosmeticStrokeWidth,
    dashPattern: dashPattern,
    dashStages: dashStages,
    dashOffset: dashOffset,
    dashOffsetStage: dashOffsetStage,
    arcAngles: arcAngles,
    qtArcEndpoint: qtArcEndpoint,
    canvasArcEndpoint: canvasArcEndpoint,
    maskStops: maskStops,
    gradientSpec: gradientSpec,
    resolveFont: resolveFont,
    lookupGlyph: lookupGlyph,
    needsLayoutSupport: needsLayoutSupport,
    createRecorder: recorder,
    runConformance: runConformance,
  };
})(typeof window !== "undefined" ? window : this);
