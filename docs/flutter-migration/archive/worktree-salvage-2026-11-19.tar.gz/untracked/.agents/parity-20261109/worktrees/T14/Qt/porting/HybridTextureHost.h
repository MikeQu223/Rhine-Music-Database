#pragma once

#include <QJsonObject>
#include <QObject>
#include <QSize>
#include <QStringList>
#include <QtGlobal>

// =============================================================================
// HybridTextureHost —— 候选 D「混合切片」的 Qt 侧 3D 纹理宿主（单向交付）
//
// 目标（plan 行489-495，docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md）：
//   HUD 由 Dart 自绘；3D 由 Qt 供给为「一张纹理」；必须证明坐标同源、双栈同步、旋转、
//   退出条件、可回退点。plan 行493 的 Fail 条件：两套状态双写同一帧必须显式失败。
//   本类用结构性单向对抗该 Fail 模式 —— 只读 Qt 场景帧，没有任何写回 HUD/state 的入口。
//
// 职责边界：
//   * 本类不做真实 GL 初始化/上传/合成：真实离屏合成由 Android 侧 SurfaceTexture 承接，
//     该部分属 T12 树（Qt/porting/TextureHost.*，本树不存在且尚未冻结），此处只留交接注释；
//     不 #include 任何本树不存在的 T12 头，只用 Qt 自带头。
//   * 无网络、无子进程、无文件系统副作用；不做任何计时/帧调度/节流。
//
// 线程契约：本类**仅**在 GUI 线程使用（与 Qt/src/NativeScene、Qt/src/NativeHud 同一线程）。
//   内部无锁、无原子、无跨线程投递 —— 全部成员只在 GUI 线程读写，任一方法都不得跨线程调用。
//   与 Dart 侧 HybridTexturePort 语义一一对应，但跨语言边界只传值（QSize / QJsonObject / double）。
//
// 层序（plan 行180 / §4.1）：3D → HUD → modal 遮罩 → hits 透明层 → chrome → 性能面板。
//   HUD 绝不烘焙进 3D 纹理：本类交付的纹理里只有 3D，Dart 在自己的层上绘 HUD。
//
// Stage（plan §4.1 行178；权威 Qt 源 Qt/qml/Overlay.qml:22-23，逐字）：
//   stageScale  = logicalHeight > 0 ? logicalHeight / 1080 : 1
//   stageWidth  = logicalWidth / stageScale
//   stageHeight = logicalHeight / stageScale
//   旋转/尺寸变化只重算 stage，绝不重建引擎状态。
//   机制依据：Qt/src/NativeScene.cpp:217-224 的 resize 只写 m_width/m_height、
//   重算投影（perspective(fov, w/h, 5, 300)）与 viewer 尺寸，不重建 Engine 与资源。
//
//   层级必须分清：NativeScene.cpp:219-220 的 std::max(1.0, ·) 属「引擎 resize」层
//   （保护投影除零与零尺寸视口），**不是 stage 公式的一部分**，不得用来推导 stageScale。
//   Overlay.qml:22 对 height <= 0 只回落 scale = 1；若先 max(1.0, h) 再除以 1080，
//   height = 0 会得到 1/1080（≈0.000926）而 Qt 给 1，两栈立刻不同源。故本类原样保存
//   逻辑尺寸，把 >0 分支留给公式本身。
//   纹理像素尺寸 = qRound(logicalWidth * dpr)（高同理）。**不**用 stageWidth * stageScale 的乘除链：
//   浮点上 (w / s) * s 不保证逐位回到 w，注释与代码必须一致。
//   其中 >= 1 px 的夹取、以及非有限值的落 1，是**本宿主的像素分配下限（QSize 不接受 0/负像素、
//   0 尺寸纹理在 GL 侧非法、qRound(NaN) 属未定义转换）**，不是 Qt 的声明，也不回写 stage 几何记录
//   —— 见 HybridTextureHost.cpp 的 kMinimumTexturePixels / pixelExtent()。
//
// 帧：3D 与 HUD 共享同一 render frame。Qt 源事实 Qt/src/NativeSceneFrame.cpp:87-119 的
//   31 个基础字面键，按该 emit 的写入顺序：
//     pendingAnimations, pointerCursor, aoProjection, reference, near(=5), far(=300),
//     viewer(=false), viewerReady(=false), viewerState(={}), mode, selected,
//     culledCards, shadowCards, returningCards, returningPartNodes, globalSubdued,
//     returningMusicKeys, returningAgeMax, time, draws, view, projection, eye,
//     background, fogColor, fogNear, fogFar, detail, boot, focus, aperture
//   同一 emit 随后追加 actorTemplate / appearanceRevision / actors（:164-166）与 stats（:195），
//   故**写入点**（emitFrame 结束时）的顶层键总数是 35。
//
//   键数边界（T14-C18-CONTRACT frameKeysAdjudication.threeLayerMechanism_v3，
//   supersedes frozenRuling / frozenRuling_v2；三层不可混用）：
//     ① 写入点 = 35：emitFrame 结束时 31 字面键 + actorTemplate/appearanceRevision/actors + stats。
//     ② NativeScene::sample 返回帧（引擎消费前）= 33：NativeCards::expand 成功收尾覆写
//        frame["draws"] 并 frame.remove("actorTemplate") / frame.remove("actors")
//        （Qt/src/NativeCards.cpp:236-237 Darwin、:303-304 非 Darwin）；expand 在包长/模板
//        校验失败时提前 return（:160-162 / :253-255），两键不删 ⇒ 该路径仍为 35。
//     ③ 引擎/渲染消费点 >= 36：Engine.cpp:1143 取 scene.frame 后于 :1248 每帧无条件写 discAngle，
//        :1196-1199 条件写 jitter，:1203-1204 条件写 temporalReset；RhiScene.cpp:3883-3885 再写
//        opticalLightEnabled / geometryRevision ⇒ 至少 36 键，expand 失败路径至少 38 键。
//   33 只是「sample 成功返回路径」的交付集，**不是**契约冻结的固定键数：消费者禁止断言固定键数
//   或键序。字段清单最终由 T03 从 RhiScene/Engine 边界冻结（plan:212）；本文件只做源镜像，
//   差异已上报 T10/T16，不得自行修改契约，也不得把任何总数表述为已冻结事实。
//   QJsonObject 序列化按键排序，故上面的「顺序」只是源文件写入顺序的镜像，不是线上字节顺序，
//   只有成员集合是事实。
//
//   **Qt 侧没有任何 generation 键**：generation/envelope 是本地适配层概念，不是 Qt wire
//   事实 —— 见 frameEnvelope()。
//
// 发布：commands/hits/frame 必须在同一 state generation 发布；generation 只能当一致性
//   检查，绝不允许对合法相同的命令去重（plan 行159 / §4.3 行213）。本类只推进 3D 帧的
//   generation；Dart 侧 HUD 命令流不经过本类。宿主已附着时，消费侧要求
//   texture.generation == envelope.generation，不等即双写/错帧 Fail（plan 行495）。
//
// 3D 真实性（plan §4.5 行226）：真实 GLB/材质/相机/BVH 拾取/灯光/雾/动画时间/纹理准入
//   必须保留；禁止静态图、预渲染视频或把文字烤进 3D。本类只搬运真实场景帧，不合成假画面。
//
// 隐藏 2D/3D 契约（plan §4.5 行227）：投影偏移 0.16/0.20、离屏扩张 18%、near 5 / far 300、
//   竖屏 aspect<1.05 分支、viewer 34° FOV / 0.3..120 裁剪 —— 均属 3D 内容，本类不改写，
//   也不在 C++ 侧重算（坐标同源由 Qt 场景帧自身保证）。
//
// 颜色/命令/命中契约（plan §4.2-§4.4、Qt/src/NativeHud.cpp:102-109、
//   Qt/src/PlayerBar.cpp:46-53）属 Dart HUD 侧，本类不复制、不解释、不改写。
// =============================================================================

class HybridTextureHost : public QObject {
    Q_OBJECT
public:
    explicit HybridTextureHost(QObject *parent = nullptr);
    ~HybridTextureHost() override;

    // 单一 generation 帧键：只在 produceFrame 成功时 +1，单调不减；release() 不回退，
    // 也不因重复的相同状态而去重（plan 行159）。
    quint64 generation() const;

    // 设定可用表面（逻辑像素 + 设备像素比）。按冻结 stage 公式重算 stageScale/stageWidth/
    // stageHeight 与纹理像素尺寸、发出 surfaceChanged；不重建任何引擎状态
    // （NativeScene.cpp:217-224 只做尺寸与投影）。
    // 附着条件只看「是否调用过 setSurface」，与输入是否有限无关：几何记录一律按源公式镜像原始
    // 输入（非有限值也照录，与 Dart 侧 stage 逐值同源）；非有限/<=0 只在像素分配时落到 1 px
    // 卫生下限（见 cpp 的 pixelExtent），不伪造有限几何。
    // 与上一状态逐位相同也照样发信号：本类不去重合法相同的状态。
    // logicalHeight <= 0（含 NaN 比较为 false 的情形）时 stageScale 取 1（Overlay.qml:22 的 :1 回落）。
    void setSurface(double logicalWidth, double logicalHeight, double devicePixelRatio);

    QSize textureSize() const;   // 纹理像素尺寸；未附着时为无效 QSize()
    // 最近一次 setSurface 算出的 stage 几何（stage 单位）。存活/可合成以 isAttached() 为准：
    // release() 后这些数值作为几何记录保留（可回退点），不随拆卸清零。
    double stageScale() const;   // logicalHeight > 0 ? logicalHeight / 1080 : 1
    double stageWidth() const;   // logicalWidth / stageScale
    double stageHeight() const;  // logicalHeight / stageScale（退化尺寸下为 0）
    bool isAttached() const;

    // 表面旋转（弧度）：精确保存、不归一化、不舍入（硬门要求投影容差 1e-9、旋转不重建引擎）。
    // 允许在 setSurface/附着之前调用（Dart 侧可能在首帧前就给定姿态）。该旋转在下一次成功
    // produceFrame 时被标记为「已完成」；退出/拆卸时未完成的旋转回正为 0 —— 回正在 teardown()
    // 的「未附着早退」之前执行，因此「先 rotate 再 release」不会留下永久 pending。
    void rotate(double radians);
    double rotation() const;

    // 一次 3D 帧 → generation 自增 1 并返回。校验附着、校验帧非空；任一不满足则返回当前
    // generation 且不推进（qWarning）。只读 sceneFrame，绝不向 HUD 写任何东西。
    quint64 produceFrame(const QJsonObject &sceneFrame);

    // 本地适配 envelope：{generation, frame, commands, hits, state}。
    // commands/hits 恒为空 QJsonArray、state 恒为空 QJsonObject —— 本类永不写 HUD 数据。
    // generation 在 JSON 侧**以 double 承载**（JSON number 无 64 位整数）：消费侧只做相等
    // 比较，严禁算术 —— 超过 2^53 后 double 不再逐位精确；自增只发生在 C++ 的 quint64 计数器上。
    // generation 是本适配层新增的概念，Qt wire（NativeSceneFrame.cpp:87-119,164-166,195）
    // 无此键；envelope 大小/超时/entityKey 等数值均为拟议，由 T10/T16 冻结（plan 行147）。
    QJsonObject frameEnvelope() const;

    // 退出/拆卸：幂等。回正未完成旋转、清附着、发 released()；重复调用无副作用、不再发信号。
    // 计数语义：teardownCount 只在「确实从已附着变为未附着」时 +1；rotate() 在附着前产生的
    // pending 旋转仍会在 release() 里回正，但那时不发 released()、不计数。
    // 可回退点：本类只释放「纹理句柄」侧的存活标记，既不销毁 Qt 场景对象也不停其渲染，
    // 因此 Dart 侧停止合成后 Qt 通道仍可回退使用（plan 行492「记录可回退点」）。
    void release();

    // Qt wire 帧键的写入顺序镜像（权威 Qt/src/NativeSceneFrame.cpp:87-119，共 31 项，不得增删）。
    // 仅供一致性/诊断检查；绝不用于比对去重合法的相同命令。
    static QStringList qtWireFrameKeyOrder();

    // 实际执行过的拆卸次数（release() 或析构导致）。用于验证 exit 幂等：两次 release 仍为 1。
    quint64 teardownCount() const;

signals:
    void frameProduced(quint64 generation, QSize textureSize);
    void surfaceChanged(double stageScale);
    void released();

private:
    // 幂等内部拆卸（不发信号）：析构与 release() 共用。
    void teardown();

    quint64 m_generation = 0;          // 单一 generation 帧键
    double m_logicalWidth = 0.0;       // 最近一次 setSurface 的逻辑宽（原样保存，不夹取）
    double m_logicalHeight = 0.0;      // 最近一次 setSurface 的逻辑高（原样保存，不夹取）
    double m_devicePixelRatio = 1.0;   // 最近一次 setSurface 的设备像素比
    double m_stageScale = 1.0;         // 冻结公式；未 setSurface 前为 1.0（不可合成，见 isAttached）
    double m_stageWidth = 0.0;         // stageWidth = m_logicalWidth / m_stageScale
    double m_stageHeight = 0.0;        // stageHeight = m_logicalHeight / m_stageScale
    double m_rotation = 0.0;           // 表面旋转（弧度，原样保存）
    bool m_rotationPending = false;    // 旋转尚未被任何成功帧承接 ⇒ 退出时回正
    bool m_attached = false;           // 是否存在可用表面
    QSize m_textureSize;               // 纹理像素尺寸
    QJsonObject m_lastFrame;           // 最近一次成功产出的 Qt 场景帧（只读副本）
    quint64 m_teardownCount = 0;       // 拆卸执行次数
};
