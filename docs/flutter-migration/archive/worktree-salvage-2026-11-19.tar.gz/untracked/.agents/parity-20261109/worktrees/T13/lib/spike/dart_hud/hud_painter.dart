// Dart painter for the 17 flat HUD commands, mirroring
// Qt/src/Glyphs.cpp:637-825 (Glyphs::renderCommands).
//
// Contract notes pinned by the source tests:
//   * commands stay a flat array, a[0] is the op name, and the stream is
//     consumed in order with no sorting and no de-duplication;
//   * alpha multiplies the running painter opacity instead of replacing it;
//   * clip intersects with the current clip;
//   * unknown ops are ignored and the remaining commands still run;
//   * path dash values are divided by pen width and Qt multiplies them back,
//     so the stage-space dash lengths are the raw command values;
//   * arc negates start and sweep twice between Qt and a y-down canvas, so the
//     Flutter sweep keeps the raw radians;
//   * right-mask builds 17 smoothstep stops, gradient is a fixed radial around
//     (979.2, 518.4) with radius 1100.
//
// Deliberately not ported: the Android RHINE_HUD_CULL pre-filter and the
// Android/Darwin text-run caches are platform optimisations that must not
// change semantics, so they stay out of the contract.
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'glyph_loader.dart';

/// Resolves the image command payload; NativeHud::image() drops empty keys
/// before the command is emitted (Qt/src/NativeHud.cpp:130-134).
typedef HudImageResolver = ui.Image? Function(String key);

/// One entry of the hits array: exactly the six keys NativeHud::hit() writes
/// (Qt/src/NativeHud.cpp:102-109) plus the optional fixed flag that only
/// PlayerBar adds (Qt/src/PlayerBar.cpp:46-53).
class HudHit {
  const HudHit({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.action,
    required this.label,
    this.fixed = false,
  });

  factory HudHit.fromJson(Map<String, dynamic> json) {
    for (final String key in _requiredKeys) {
      if (!json.containsKey(key)) {
        throw FormatException(
          'HUD hit is missing the mandatory field ' + key,
          json.toString(),
        );
      }
    }
    final String action = json['action'] as String;
    final Object? label = json['label'];
    final Object? fixed = json['fixed'];
    return HudHit(
      x: _toDouble(json['x']),
      y: _toDouble(json['y']),
      width: _toDouble(json['width']),
      height: _toDouble(json['height']),
      action: action,
      label: label is String ? label : action,
      fixed: fixed == true,
    );
  }

  /// Parses the hits array of one HUD frame, preserving producer order.
  static List<HudHit> listFromJson(Object? value) {
    if (value is! List) {
      return const <HudHit>[];
    }
    return <HudHit>[
      for (final Object? entry in value)
        if (entry is Map) HudHit.fromJson(entry.cast<String, dynamic>()),
    ];
  }

  static const List<String> _requiredKeys = <String>[
    'x',
    'y',
    'width',
    'height',
    'action',
    'label',
  ];

  final double x;
  final double y;
  final double width;
  final double height;
  final String action;
  final String label;
  final bool fixed;

  ui.Rect get rect => ui.Rect.fromLTWH(x, y, width, height);

  /// Topmost-first hit test over one frame.
  ///
  /// Later hits are painted on top, so the reverse scan matches what the stage
  /// shows. modalOffset is the vertical shift a modal applies to stage content
  /// (NativeHud state key at Qt/src/NativeHud.cpp:205); fixed hits, which only
  /// PlayerBar produces, keep their stage position.
  static HudHit? hitTest(
    List<HudHit> hits,
    ui.Offset point, {
    double modalOffset = 0,
  }) {
    for (int i = hits.length - 1; i >= 0; i -= 1) {
      final HudHit hit = hits[i];
      final ui.Rect rect =
          hit.fixed ? hit.rect : hit.rect.translate(0, modalOffset);
      if (rect.contains(point)) {
        return hit;
      }
    }
    return null;
  }
}

/// Per-frame diagnostics; never used on its own to claim a pass.
class HudPaintStats {
  const HudPaintStats({
    this.commands = 0,
    this.unknownOps = 0,
    this.missingImages = 0,
  });

  final int commands;
  final int unknownOps;
  final int missingImages;
}

/// Executes one HUD command stream.
class HudPainter {
  HudPainter({required this.atlas, this.imageResolver, this.trace});

  /// Pi as spelled in the Qt command handlers.
  static const double pi = 3.14159265358979323846;

  /// Fixed radial gradient geometry (Qt/src/Glyphs.cpp:807-811).
  static const ui.Offset radialCenter = ui.Offset(979.2, 518.4);
  static const double radialRadius = 1100;
  static const List<double> radialStops = <double>[0, 0.76, 1];

  final GlyphAtlas atlas;
  final HudImageResolver? imageResolver;

  /// Optional op trace for source-level tests; entries are op@opacity with the
  /// opacity in effect when the command starts.
  final List<String>? trace;

  double _opacity = 1;
  final List<double> _opacityStack = <double>[];

  double get opacity => _opacity;

  /// Runs a whole frame. Qt builds a fresh painter per frame, so opacity state
  /// starts at 1 for every call.
  HudPaintStats paintAll(ui.Canvas canvas, List<Object?> commands) {
    _opacity = 1;
    _opacityStack.clear();
    int unknown = 0;
    int missing = 0;
    for (final Object? entry in commands) {
      if (entry is! List) {
        unknown += 1;
        _record('invalid');
        continue;
      }
      final List<Object?> command = entry;
      final String op =
          command.isNotEmpty && command[0] is String ? command[0] as String : '';
      _record(op);
      switch (op) {
        case 'save':
          _opacityStack.add(_opacity);
          canvas.save();
          break;
        case 'restore':
          if (_opacityStack.isNotEmpty) {
            _opacity = _opacityStack.removeLast();
          }
          canvas.restore();
          break;
        case 'alpha':
          _opacity *= _number(command, 1);
          break;
        case 'translate':
          canvas.translate(_number(command, 1), _number(command, 2));
          break;
        case 'scale':
          canvas.scale(_number(command, 1), _number(command, 2));
          break;
        case 'rotate':
          canvas.rotate(_number(command, 1));
          break;
        case 'clip':
          canvas.clipRect(_rect(command, 1));
          break;
        case 'fill':
          canvas.drawRect(_rect(command, 2), _fillPaint(_at(command, 1)));
          break;
        case 'ellipse':
          canvas.drawOval(_rect(command, 2), _fillPaint(_at(command, 1)));
          break;
        case 'text':
          atlas.drawText(
            canvas,
            _string(command, 1),
            _number(command, 2),
            _number(command, 3),
            _number(command, 4),
            _string(command, 5, fallback: 'regular'),
            resolveColor(_at(command, 7)),
            tracking: _number(command, 6),
          );
          break;
        case 'art':
          atlas.drawArt(
            canvas,
            _string(command, 1),
            _number(command, 2),
            _number(command, 3),
            _number(command, 4),
            resolveColor(_at(command, 7)),
            count: _int(command, 5, -1),
            tracking: _number(command, 6),
          );
          break;
        case 'fill-path':
          canvas.drawPath(
            atlas.pathFor(_string(command, 1)),
            _fillPaint(_at(command, 2)),
          );
          break;
        case 'path':
          _drawStroke(
            canvas,
            atlas.pathFor(_string(command, 1)),
            _number(command, 2),
            _at(command, 3),
            _at(command, 4),
            _at(command, 5),
          );
          break;
        case 'arc':
          canvas.drawArc(
            arcRect(_number(command, 1), _number(command, 2), _number(command, 3)),
            arcStartRadians(_number(command, 4)),
            arcSweepRadians(_number(command, 5)),
            false,
            ui.Paint()
              ..style = ui.PaintingStyle.stroke
              ..isAntiAlias = true
              ..strokeCap = ui.StrokeCap.round
              ..strokeWidth = _number(command, 6)
              ..color = _apply(_color(_at(command, 7))),
          );
          break;
        case 'right-mask':
          _drawRightMask(
            canvas,
            _color(_at(command, 1)),
            _number(command, 2),
            _number(command, 3),
            _number(command, 4),
            _number(command, 5),
          );
          break;
        case 'gradient':
          final bool dark = command.length > 1 && command[1] == true;
          canvas.drawRect(
            const ui.Rect.fromLTWH(-4096, -4096, 8192, 8192),
            ui.Paint()
              ..style = ui.PaintingStyle.fill
              ..isAntiAlias = true
              ..shader = ui.Gradient.radial(
                radialCenter,
                radialRadius,
                radialColors(dark),
                radialStops,
              ),
          );
          break;
        case 'image':
          final ui.Image? image =
              imageResolver == null ? null : imageResolver!(_string(command, 1));
          if (image == null) {
            missing += 1;
          } else {
            canvas.drawImageRect(
              image,
              ui.Rect.fromLTWH(
                0,
                0,
                image.width.toDouble(),
                image.height.toDouble(),
              ),
              _rect(command, 2),
              ui.Paint()
                ..isAntiAlias = true
                ..filterQuality = ui.FilterQuality.medium,
            );
          }
          break;
        default:
          unknown += 1;
          break;
      }
    }
    return HudPaintStats(
      commands: commands.length,
      unknownOps: unknown,
      missingImages: missing,
    );
  }

  /// Mirrors the calibrated colour rule used by every command payload.
  static ui.Color resolveColor(Object? value) => GlyphAtlas.colorFromJson(value);

  /// Dash lengths in stage space.
  ///
  /// Qt divides each value by max(penWidth, 0.0001) when calling
  /// setDashPattern and the pen multiplies by pen width again while stroking
  /// (Qt/src/Glyphs.cpp:748-757), so the two factors cancel and the raw values
  /// are the pattern that reaches the rasteriser.
  static List<double> dashPattern(List<dynamic> dash, {required double penWidth}) {
    final double scale = math.max(penWidth, 0.0001);
    return <double>[
      for (final dynamic value in dash) (_toDouble(value) / scale) * scale,
    ];
  }

  /// Same cancellation as [dashPattern] for the dash phase.
  static double dashOffset(Object? value, {required double penWidth}) {
    final double scale = math.max(penWidth, 0.0001);
    return (_toDouble(value) / scale) * scale;
  }

  /// Qt builds the arc box as (x-r, y-r, 2r, 2r) around the pen origin
  /// (Qt/src/Glyphs.cpp:763).
  static ui.Rect arcRect(double x, double y, double radius) =>
      ui.Rect.fromLTWH(x - radius, y - radius, radius * 2, radius * 2);

  /// Qt rotates by -a[4] * 180 / pi; a y-down canvas measures angles clockwise,
  /// so the Flutter arc starts at the raw radian value
  /// (Qt/src/Glyphs.cpp:770-771).
  static double arcStartRadians(double value) => value;

  /// Counterpart of [arcStartRadians] for the sweep.
  static double arcSweepRadians(double value) => value;

  /// Qt fills QRectF(start, 0, right - start, height)
  /// (Qt/src/Glyphs.cpp:805).
  static ui.Rect rightMaskRect(double start, double right, double height) =>
      ui.Rect.fromLTWH(start, 0, right - start, height);

  /// 17 evenly spaced stop offsets (MaskSteps = 16, loop inclusive).
  static List<double> rightMaskStops({int steps = 16}) => <double>[
        for (int step = 0; step <= steps; step += 1) step / steps,
      ];

  /// Smoothstep alpha ramp: p*p*(3-2p) applied to the base alpha.
  static List<ui.Color> rightMaskColors(ui.Color base, {int steps = 16}) {
    final List<ui.Color> colors = <ui.Color>[];
    for (int step = 0; step <= steps; step += 1) {
      final double progress = step / steps;
      final double eased = progress * progress * (3 - 2 * progress);
      colors.add(base.withValues(alpha: base.a * eased));
    }
    return colors;
  }

  /// Plain sRGB stops from the Qt integer colours
  /// (Qt/src/Glyphs.cpp:809-811).
  static List<ui.Color> radialColors(bool dark) => dark
      ? const <ui.Color>[
          ui.Color(0xFF202A2F),
          ui.Color(0xFF172125),
          ui.Color(0xFF11181B),
        ]
      : const <ui.Color>[
          ui.Color(0xFFE7E7E1),
          ui.Color(0xFFE3E1DC),
          ui.Color(0xFFE4DFDB),
        ];

  void _drawStroke(
    ui.Canvas canvas,
    ui.Path path,
    double penWidth,
    Object? colorValue,
    Object? dashValue,
    Object? dashOffsetValue,
  ) {
    final ui.Paint paint = ui.Paint()
      ..style = ui.PaintingStyle.stroke
      ..isAntiAlias = true
      ..strokeWidth = penWidth
      ..strokeCap = ui.StrokeCap.butt
      ..strokeJoin = ui.StrokeJoin.miter
      ..strokeMiterLimit = 2
      ..color = _apply(_color(colorValue));
    final List<dynamic> dash = dashValue is List ? dashValue : const <dynamic>[];
    if (dash.isEmpty) {
      canvas.drawPath(path, paint);
      return;
    }
    _drawDashed(
      canvas,
      path,
      paint,
      dashPattern(dash, penWidth: penWidth),
      dashOffset(dashOffsetValue, penWidth: penWidth),
    );
  }

  void _drawDashed(
    ui.Canvas canvas,
    ui.Path path,
    ui.Paint paint,
    List<double> pattern,
    double offset,
  ) {
    for (final ui.PathMetric metric in path.computeMetrics()) {
      double distance = -offset;
      bool visible = true;
      int index = 0;
      while (distance < metric.length) {
        final double length = pattern[index % pattern.length];
        if (length <= 0) {
          break;
        }
        final double start = math.max(distance, 0);
        final double end = math.min(distance + length, metric.length);
        if (visible && end > start) {
          canvas.drawPath(metric.extractPath(start, end), paint);
        }
        distance += length;
        visible = !visible;
        index += 1;
      }
    }
  }

  void _drawRightMask(
    ui.Canvas canvas,
    ui.Color base,
    double start,
    double span,
    double right,
    double height,
  ) {
    canvas.drawRect(
      rightMaskRect(start, right, height),
      ui.Paint()
        ..style = ui.PaintingStyle.fill
        ..isAntiAlias = true
        ..shader = ui.Gradient.linear(
          ui.Offset(start, 0),
          ui.Offset(start + span, 0),
          rightMaskColors(base),
          rightMaskStops(),
        ),
    );
  }

  ui.Paint _fillPaint(Object? colorValue) => ui.Paint()
    ..style = ui.PaintingStyle.fill
    ..isAntiAlias = true
    ..color = _apply(_color(colorValue));

  ui.Color _color(Object? value) =>
      value == null ? const ui.Color(0xFF000000) : resolveColor(value);

  /// QPainter opacity multiplies into every primitive alpha.
  ui.Color _apply(ui.Color color) =>
      _opacity == 1 ? color : color.withValues(alpha: color.a * _opacity);

  void _record(String op) {
    final List<String>? sink = trace;
    if (sink == null) {
      return;
    }
    sink.add(op + '@' + _opacity.toStringAsFixed(3));
  }

  static Object? _at(List<Object?> command, int index) =>
      index < command.length ? command[index] : null;

  static ui.Rect _rect(List<Object?> command, int index) => ui.Rect.fromLTWH(
        _number(command, index),
        _number(command, index + 1),
        _number(command, index + 2),
        _number(command, index + 3),
      );

  static String _string(List<Object?> command, int index,
      {String fallback = ''}) {
    final Object? value = _at(command, index);
    return value is String ? value : fallback;
  }

  static int _int(List<Object?> command, int index, int fallback) {
    final Object? value = _at(command, index);
    return value is num ? value.toInt() : fallback;
  }

  static double _number(List<Object?> command, int index) =>
      _toDouble(_at(command, index));

  static double _toDouble(dynamic value) {
    if (value is num) {
      return value.toDouble();
    }
    if (value is String) {
      return double.tryParse(value) ?? 0;
    }
    return 0;
  }
}
