/// Qt 移植源：Qt/src/LyricsController.h（84 行）、Qt/src/LyricsController.cpp（661 行）。
///
/// 歌词唯一状态源：缓存（最多 12 条）、每曲偏移、来源选择、时间轴同步、
/// 播放快照往返与封面补全。语义逐条对齐 Qt，注释标注出处函数与行号。
/// 纯 Dart 领域层，不依赖 Flutter，也不在 UI 内解析歌词：
/// 面板内播放与详情页播放读同一个 [LyricsController] 实例的状态，界面只订阅
/// [addListener]/[addCoverMatchedListener] 增量刷新（Qt 只有一处 m_document）。
///
/// Qt ↔ Dart 逐函数映射（左为 Qt 文件:行，右为本文件符号）：
/// - LyricsController.cpp:55-76   构造：全局偏移 + 缓存恢复      → 构造 / _restoreCache
/// - LyricsController.cpp:78-84   trackKey                      → [trackKey]
/// - LyricsController.cpp:86-102  validDocument                  → [validDocument]
/// - LyricsController.cpp:104-115 sameRecording                  → [sameRecording]
/// - LyricsController.cpp:117-131 activeLineIndex                → [activeLineIndex]
/// - LyricsController.cpp:133-146 clear                          → [clear]
/// - LyricsController.cpp:148-158 clearCache                     → [clearCache]
/// - LyricsController.cpp:160-169 api()/valid()                  → _apiFor / _valid
/// - LyricsController.cpp:171-182 matchCover                     → [matchCover]
/// - LyricsController.cpp:184-195 tryCover                       → _tryCover
/// - LyricsController.cpp:197-224 loadCandidateCover             → _loadCandidateCover
/// - LyricsController.cpp:226-240 selectLocalSource              → [selectLocalSource]
/// - LyricsController.cpp:242-319 load                           → [load]
/// - LyricsController.cpp:321-344 supplement                     → _supplement
/// - LyricsController.cpp:346-405 search                         → _search
/// - LyricsController.cpp:407-445 fetchCandidate                 → _fetchCandidate
/// - LyricsController.cpp:447-468 finish                         → _finish
/// - LyricsController.cpp:470-490 accept                         → _accept
/// - LyricsController.cpp:492-499 persist                        → _persist
/// - LyricsController.cpp:501-509 sync                           → [sync]
/// - LyricsController.cpp:511-518 adjustOffset                   → [adjustOffset]
/// - LyricsController.cpp:520-531 resetOffset                    → [resetOffset]
/// - LyricsController.cpp:533-544 applyGlobalOffset              → [applyGlobalOffset]
/// - LyricsController.cpp:546-627 loadLocal                      → _loadLocal
/// - LyricsController.cpp:629-637 remoteCommand                  → _remoteCommand
/// - LyricsController.cpp:639-649 playbackSnapshot               → [playbackSnapshot]
/// - LyricsController.cpp:651-661 applyPlaybackSnapshot          → [applyPlaybackSnapshot]
///
/// 持久化边界（Qt 源证据，逐条可查）：
/// - 偏好键 `lyrics-cache`：只存 {"key","document"} 数组，上限 12 条
///   （LyricsController.cpp:66-75 读、:480-486 组、:492-499 写）。
/// - 偏好键 `lyrics-global-offset-ms`：只存**全局**偏移
///   （LyricsController.cpp:61 读、:542 写；QString::number 语义见 :542）。
/// - **每曲 offsetMs 不入偏好**：缓存条目里没有 offset 字段（:480-485），
///   Qt 只在切歌时把它重置为全局偏移（:250 clear 后 :252 回填）并随
///   playbackSnapshot 往返（:645/:657）。session 状态也不含歌词
///   （MusicPlayer::sessionState 见 MusicPlayer.cpp:700 附近；只有
///   playbackSnapshot 带 {"lyrics", lyrics.playbackSnapshot()}，MusicPlayer.cpp:701）。
/// - 两个偏好键都在 Host 允许名单里（Host.cpp:1050）：写后必须能读回。
library;

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

/// 主机能力端口，对齐 Qt Host：偏好读写、封面加载、本地桥 JSON 请求与定时器。
/// Qt 证据：Qt/src/LyricsController.cpp:61/66/189/605/356（preference、loadCover、
/// requestJson、QTimer::singleShot 的唯一注入点）。
abstract class LyricsHostPort {
  /// 读取偏好；缺失返回空串（Qt Host::preference）。
  String preference(String key);

  /// 写入偏好（Qt Host::setPreference）。
  void setPreference(String key, String value);

  /// 加载封面图（Qt Host::loadCover）；失败返回空串。
  Future<String> loadCover(String url);

  /// 本地桥 JSON 请求（Qt Host::requestJson）；失败以抛异常表达（Qt 侧为 error 串）。
  Future<Map<String, Object?>> requestJson(String path, Map<String, Object?> params);

  /// 定时回调，对齐 Qt QTimer::singleShot（网易云歌词 1500ms 间隔）。
  void schedule(int delayMs, void Function() action);
}

/// 可选的本地歌词 sidecar 读取能力，对齐 Qt loadLocal 中的 QFile 读取。
///
/// Qt 在控制器内同步读 *.lrc/*.LRC；纯 Dart 领域层不 import dart:io，
/// 因此把字节读取下沉为可选端口：主机未实现时按“无 sidecar”降级（内嵌歌词仍可解析），
/// 不改变 [LyricsHostPort] 的冻结签名。
abstract class LyricsLocalFilePort {
  /// 读取绝对路径文件全部字节；不存在或不可读返回 null。
  Future<List<int>?> readLocalBytes(String path);
}

/// 歌词 API 端口，对齐 Qt MusicApi::call：失败抛异常，成功返回 result.value。
abstract class LyricsApiPort {
  /// 来源名（netease/qq/kugou/siren），对齐 Qt MusicApi::provider。
  String get provider;

  /// 调用 API；参数列表即 Qt QJsonArray 语义。
  Future<Object?> call(String method, List<Object?> args);
}

/// 播放侧远程命令端口，对齐 Qt Host::playbackConnection()。
/// Qt 证据：Qt/src/LyricsController.cpp:629-637 remoteCommand。
abstract class LyricsRemotePort {
  /// 发送命令（方法名带 lyrics. 前缀）。
  void call(String method, Map<String, Object?> arguments);

  /// 读取完整播放快照；snapshot["lyrics"] 为歌词子快照。
  Map<String, Object?> get snapshot;
}

/// 歌词控制器：状态、缓存与同步的唯一来源。
///
/// Qt 的 load → supplement → search → fetchCandidate → finish 回调链在 Dart 里
/// 用 await 串成同一个 Future；emit 时序与 Qt 完全一致，界面应按 emit 增量刷新，
/// 不要用 Future 完成当作首帧信号。
class LyricsController {
  LyricsController(
    this._host, {
    LyricsApiPort Function(String provider)? apiFactory,
    LyricsRemotePort? remote,
    LyricsLocalFilePort? localFiles,
  })  : _apiFactory = apiFactory,
        _remote = remote,
        _localFiles = localFiles {
    // Qt 证据：Qt/src/LyricsController.cpp:60-65（有限数才夹取 -10000..10000）。
    final saved = _parseOffset(_host.preference('lyrics-global-offset-ms'));
    if (saved != null && saved.isFinite) {
      _globalOffsetMs = saved.clamp(-10000.0, 10000.0).toDouble();
    }
    offsetMs = _globalOffsetMs;
    // Qt 证据：Qt/src/LyricsController.cpp:66-75（最多 12 条，逐条 validDocument 过滤）。
    _restoreCache();
  }

  /// Qt 证据：Qt/src/LyricsController.cpp:13 PROVIDERS。
  static const List<String> providers = <String>['netease', 'qq', 'kugou', 'siren'];

  /// Qt 证据：Qt/src/LyricsController.cpp:14 CACHE_LIMIT。
  static const int cacheLimit = 12;

  /// 当前曲目的本地歌词来源，对齐 Qt localSource（构造默认 auto）。
  String localSource = 'auto';

  /// idle/loading/ready/plain/empty/error，对齐 Qt status。
  String status = 'idle';

  /// 对齐 Qt message。
  String message = '';

  /// 对齐 Qt currentKey（trackKey）。
  String currentKey = '';

  /// 当前高亮行，-1 表示无。
  int index = -1;

  /// 当前曲目偏移（毫秒），对齐 Qt offsetMs。
  double offsetMs = 0;

  /// 播放位置（毫秒），对齐 Qt positionMs。
  double positionMs = 0;

  /// 当前歌词文档，字段与 Qt document() 一致。
  Map<String, Object?> document = <String, Object?>{};

  /// 全局偏移（毫秒），对齐 Qt globalOffsetMs()。
  double get globalOffsetMs => _globalOffsetMs;

  final LyricsHostPort _host;
  final LyricsApiPort Function(String provider)? _apiFactory;
  final LyricsRemotePort? _remote;

  /// 可选 sidecar 读取端口（Qt loadLocal 里同步 QFile 读取的注入点）。
  /// 主机自身实现 [LyricsLocalFilePort] 时也可直接生效，见 _loadLocal。
  final LyricsLocalFilePort? _localFiles;

  /// 对齐 Qt m_apis[4]：按 provider 惰性创建并缓存（构造期创建无对外语义差别）。
  final Map<String, LyricsApiPort> _apis = <String, LyricsApiPort>{};

  /// 对齐 Qt m_generation：clear/load 递增，旧异步回调据此丢弃。
  int _generation = 0;

  /// 对齐 Qt m_globalOffsetMs。
  double _globalOffsetMs = 0;

  /// 对齐 Qt m_neteaseLyricsBlockedUntil。
  int _neteaseLyricsBlockedUntil = 0;

  /// 对齐 Qt m_lastNeteaseLyricRequest。
  int _lastNeteaseLyricRequest = 0;

  /// 对齐 Qt m_lyricsRetryAfter（墙钟毫秒）。
  final Map<String, int> _lyricsRetryAfter = <String, int>{};

  /// 对齐 Qt m_starts：行起始时间，供 sync 二分。
  final List<double> _starts = <double>[];

  /// 对齐 Qt m_cache：前置插入、尾部淘汰。
  List<Map<String, Object?>> _cache = <Map<String, Object?>>[];

  /// 对齐 Qt m_localSources（本地曲目 id → 来源，上限 200）。
  final Map<String, String> _localSources = <String, String>{};

  final List<void Function()> _listeners = <void Function()>[];
  final List<void Function(String key, String url)> _coverListeners =
      <void Function(String key, String url)>[];

  /// 订阅 changed（Qt LyricsController::changed）。
  void addListener(void Function() listener) => _listeners.add(listener);

  /// 取消订阅。
  void removeListener(void Function() listener) => _listeners.remove(listener);

  /// 订阅 coverMatched（Qt LyricsController::coverMatched）。
  void addCoverMatchedListener(void Function(String key, String url) listener) =>
      _coverListeners.add(listener);

  void _emit() {
    for (final listener in List<void Function()>.of(_listeners)) {
      listener();
    }
  }

  void _emitCover(String key, String url) {
    for (final listener in List<void Function(String, String)>.of(_coverListeners)) {
      listener(key, url);
    }
  }

  // ---------------------------------------------------------------------------
  // 静态语义
  // ---------------------------------------------------------------------------

  /// 歌曲身份：provider:id，本地曲目再追加 fingerprint。
  /// Qt 证据：Qt/src/LyricsController.cpp:78-84 trackKey。
  static String trackKey(Map<String, Object?> track) {
    if (track.isEmpty) {
      return '';
    }
    final key = _providerName(track) + ':' + _text(track['id']);
    return _text(track['provider']) == 'local'
        ? key + ':' + _text(track['fingerprint'])
        : key;
  }

  /// 文档合法性：版本 1、timing 三值之一、lines ≤5000、plainText 字符串、
  /// offsetMs 有限数、逐行 startMs 有限数 + text 字符串。
  /// Qt 证据：Qt/src/LyricsController.cpp:86-102 validDocument。
  static bool validDocument(Map<String, Object?> document) {
    if (_integer(document['version'], 0) != 1) {
      return false;
    }
    final timing = _text(document['timing']);
    if (timing != 'line' && timing != 'word' && timing != 'none') {
      return false;
    }
    final lines = document['lines'];
    if (lines is! List || lines.length > 5000) {
      return false;
    }
    if (document['plainText'] is! String) {
      return false;
    }
    final offset = document['offsetMs'];
    if (offset is! num || !offset.toDouble().isFinite) {
      return false;
    }
    for (final value in lines) {
      if (value is! Map) {
        return false;
      }
      final line = _object(value);
      final start = line['startMs'];
      if (start is! num || !start.toDouble().isFinite || line['text'] is! String) {
        return false;
      }
    }
    return true;
  }

  /// 同一录音：标题归一化相等 + 歌手集合相等 + 版本关键词相同 + 时长差 ≤2000ms；
  /// siren 只比标题与版本。空歌手集合在非 siren 下直接判否。
  /// Qt 证据：Qt/src/LyricsController.cpp:104-115 sameRecording。
  static bool sameRecording(Map<String, Object?> track, Map<String, Object?> candidate) {
    final sourceArtists = _artists(track);
    final sameTitle =
        _comparable(_text(track['title'])) == _comparable(_text(candidate['title']));
    final sameVersion = _recordingVersion(track) == _recordingVersion(candidate);
    if (_text(track['provider']) == 'siren') {
      // Qt 注释：检查标题与版本一致即可。
      return sameTitle && sameVersion;
    }
    final trackDuration = _number(track['duration']);
    final candidateDuration = _number(candidate['duration']);
    return sameTitle &&
        sourceArtists.isNotEmpty &&
        _sameList(sourceArtists, _artists(candidate)) &&
        sameVersion &&
        trackDuration > 0 &&
        candidateDuration > 0 &&
        (trackDuration - candidateDuration).abs() <= 2000;
  }

  /// 当前行：position = positionMs + document.offsetMs + offsetMs，upper_bound-1。
  /// Qt 证据：Qt/src/LyricsController.cpp:117-131 activeLineIndex。
  static int activeLineIndex(
    Map<String, Object?> document,
    double positionMs, [
    double offsetMs = 0,
  ]) {
    final lines = _lines(document);
    final position = positionMs + _number(document['offsetMs']) + offsetMs;
    var lower = 0;
    var upper = lines.length;
    while (lower < upper) {
      final middle = (lower + upper) ~/ 2;
      if (_number(_object(lines[middle])['startMs']) <= position) {
        lower = middle + 1;
      } else {
        upper = middle;
      }
    }
    return lower - 1;
  }

  // ---------------------------------------------------------------------------
  // 生命周期
  // ---------------------------------------------------------------------------

  /// 清空当前文档并递增代号；不 emit（对齐 Qt）。
  /// Qt 证据：Qt/src/LyricsController.cpp:133-146 clear。
  void clear() {
    if (_remoteCommand('clear')) {
      return;
    }
    ++_generation;
    currentKey = '';
    document = <String, Object?>{};
    _starts.clear();
    status = 'idle';
    message = '';
    index = -1;
    offsetMs = _globalOffsetMs;
    positionMs = 0;
  }

  /// 清空缓存、重试墙钟与网易云限流；不 emit（对齐 Qt）。
  /// Qt 证据：Qt/src/LyricsController.cpp:148-158 clearCache。
  void clearCache() {
    if (_remoteCommand('clearCache')) {
      return;
    }
    _cache = <Map<String, Object?>>[];
    _lyricsRetryAfter.clear();
    _neteaseLyricsBlockedUntil = 0;
    _lastNeteaseLyricRequest = 0;
    _persist();
  }

  // ---------------------------------------------------------------------------
  // 读取
  // ---------------------------------------------------------------------------

  /// 切歌先清空显示，再按身份读精确歌词；同曲保留位置与偏移。
  /// Qt 证据：Qt/src/LyricsController.cpp:242-319 load。
  Future<void> load(Map<String, Object?> track, {bool retry = false}) async {
    if (_remoteCommand('load', <String, Object?>{'track': _cloneObject(track), 'retry': retry})) {
      return;
    }
    final key = trackKey(track);
    final sameTrack = key == currentKey;
    final position = sameTrack ? positionMs : 0.0;
    final offset = sameTrack ? offsetMs : _globalOffsetMs;
    clear();
    offsetMs = offset;
    currentKey = key;
    positionMs = position;
    if (_text(track['provider']) == 'local') {
      // Qt m_localSources.value(id).toString("auto")：非字符串回落 auto。
      final stored = _localSources[_text(track['id'])];
      localSource = stored is String ? stored : 'auto';
      final pending = _Load(generation: _generation, track: _cloneObject(track))
        ..needsCover = _text(track['cover']).isEmpty;
      await _loadLocal(track, pending);
      return;
    }
    if (!retry) {
      for (final entry in _cache) {
        if (_text(entry['key']) != currentKey) {
          continue;
        }
        final cached = _object(entry['document']);
        // 塞壬歌词来自网易云；旧版本缓存过的官网歌词直接忽略。
        if (_text(track['provider']) == 'siren' && _text(cached['source']) == 'siren') {
          continue;
        }
        _accept(cached, track);
        return;
      }
    }
    if (_text(track['provider']) == 'siren') {
      if ((_lyricsRetryAfter[currentKey] ?? 0) > _now()) {
        status = 'empty';
        message = '暂无歌词';
        _emit();
        return;
      }
      status = 'loading';
      message = '正在从网易云读取歌词…';
      _emit();
      final pending = _Load(generation: _generation, track: _cloneObject(track))
        ..needsCover = _text(track['cover']).isEmpty
        ..lyricSource = 'netease';
      await _supplement(pending);
      return;
    }
    status = 'loading';
    message = '正在读取歌词…';
    _emit();
    final pending = _Load(generation: _generation, track: _cloneObject(track))
      ..needsCover = _text(track['cover']).isEmpty;
    final api = _apiFor(_providerName(track));
    Object? result;
    var ok = true;
    if (api == null) {
      // 无 API 端口等价 Qt 该 provider 请求失败，不抛给调用方。
      ok = false;
    } else {
      try {
        result = await api.call('lyrics', <Object?>[_cloneObject(track)]);
      } catch (_) {
        ok = false;
      }
    }
    if (!_valid(pending)) {
      return;
    }
    pending.networkFailed = !ok;
    final loaded = _object(result);
    if (ok && validDocument(loaded)) {
      pending.native = loaded;
      if (_lines(loaded).isNotEmpty) {
        _accept(loaded, pending.track);
        return;
      }
    }
    await _supplement(pending);
  }

  /// 本地曲目封面补全：身份一致才补，避免把别曲封面套上来。
  /// Qt 证据：Qt/src/LyricsController.cpp:171-182 matchCover。
  Future<void> matchCover(Map<String, Object?> track) async {
    if (_text(track['provider']) != 'local' || trackKey(track) != currentKey) {
      return;
    }
    final pending = _Load(generation: _generation, track: _cloneObject(track))
      ..needsLyrics = false
      ..needsCover = true;
    await _supplement(pending);
  }

  /// 本地歌曲歌词来源选择，写入 m_localSources 后强制重读。
  /// Qt 证据：Qt/src/LyricsController.cpp:226-240 selectLocalSource。
  Future<void> selectLocalSource(Map<String, Object?> track, String source) async {
    if (_remoteCommand('source', <String, Object?>{
      'track': _cloneObject(track),
      'source': source,
    })) {
      return;
    }
    // Qt 证据：Qt/src/LyricsController.cpp:232 —— 白名单是
    // {auto, local, netease, qq, kugou}，**不含 siren**；而 PROVIDERS
    // （:13）与 loadLocal 的“已选来源”分支（:548）都含 siren。
    // 这是 Qt 的既成行为，不补齐、不“修正”。
    if (_text(track['provider']) != 'local' ||
        _text(track['id']).isEmpty ||
        !const <String>{'auto', 'local', 'netease', 'qq', 'kugou'}.contains(source)) {
      return;
    }
    final id = _text(track['id']);
    // 超过 200 条且是新曲目时整体清空，避免无界增长。
    if (_localSources.length >= 200 && !_localSources.containsKey(id)) {
      _localSources.clear();
    }
    _localSources[id] = source;
    await load(track, retry: true);
  }

  // ---------------------------------------------------------------------------
  // 同步与偏移
  // ---------------------------------------------------------------------------

  /// 按播放位置推进高亮行；变化才 emit。
  /// Qt 证据：Qt/src/LyricsController.cpp:501-509 sync。
  void sync(double position) {
    positionMs = position;
    final time = position + _number(document['offsetMs']) + offsetMs;
    final next = _upperBound(_starts, time) - 1;
    if (next != index) {
      index = next;
      _emit();
    }
  }

  /// 当前曲目偏移加减，夹取 ±10000 后重新同步。
  /// Qt 证据：Qt/src/LyricsController.cpp:511-518 adjustOffset。
  void adjustOffset(double deltaMs) {
    if (_remoteCommand('offset', <String, Object?>{'value': deltaMs})) {
      return;
    }
    offsetMs = (offsetMs + deltaMs).clamp(-10000.0, 10000.0).toDouble();
    sync(positionMs);
    _emit();
  }

  /// 当前曲目偏移归零；本来就是 0 时不动也不 emit。
  /// Qt 证据：Qt/src/LyricsController.cpp:520-531 resetOffset。
  void resetOffset() {
    if (_remoteCommand('reset')) {
      return;
    }
    if (offsetMs == 0) {
      return;
    }
    offsetMs = 0;
    sync(positionMs);
    _emit();
  }

  /// 把当前偏移提升为全局偏移并持久化。
  /// Qt 证据：Qt/src/LyricsController.cpp:533-544 applyGlobalOffset。
  void applyGlobalOffset() {
    if (_remoteCommand('global')) {
      return;
    }
    if (offsetMs == _globalOffsetMs) {
      return;
    }
    _globalOffsetMs = offsetMs;
    _host.setPreference('lyrics-global-offset-ms', _qtNumber(_globalOffsetMs));
    _emit();
  }

  // ---------------------------------------------------------------------------
  // 快照
  // ---------------------------------------------------------------------------

  /// 字段名与 Qt 完全一致：document/status/message/key/index/offsetMs/
  /// positionMs/globalOffsetMs/localSource。
  /// Qt 证据：Qt/src/LyricsController.cpp:639-649 playbackSnapshot。
  Map<String, Object?> playbackSnapshot() {
    return <String, Object?>{
      'document': _cloneValue(document),
      'status': status,
      'message': message,
      'key': currentKey,
      'index': index,
      'offsetMs': offsetMs,
      'positionMs': positionMs,
      'globalOffsetMs': _globalOffsetMs,
      'localSource': localSource,
    };
  }

  /// 应用播放侧快照（远程命令后同步本地状态）；不 emit、不重建 m_starts。
  /// Qt 证据：Qt/src/LyricsController.cpp:651-661 applyPlaybackSnapshot ——
  /// Qt 原样覆盖 document 却不重建 m_starts，也不 emit；这里同样**故意**不
  /// 重建 _starts（快照来自持有同一文档的对端，starts 由对端 accept 时建好）。
  /// 若要“顺手修正”，会与 Qt 的可观测状态（index 已由快照给出）分叉。
  void applyPlaybackSnapshot(Map<String, Object?> snapshot) {
    document = _cloneObject(snapshot['document']);
    status = _stringOr(snapshot['status'], 'idle');
    message = _text(snapshot['message']);
    currentKey = _text(snapshot['key']);
    index = _integer(snapshot['index'], -1);
    offsetMs = _number(snapshot['offsetMs']);
    positionMs = _number(snapshot['positionMs']);
    _globalOffsetMs = _number(snapshot['globalOffsetMs']);
    localSource = _stringOr(snapshot['localSource'], 'auto');
  }

  // ---------------------------------------------------------------------------
  // 内部：缓存与持久化
  // ---------------------------------------------------------------------------

  void _restoreCache() {
    final raw = _host.preference('lyrics-cache');
    if (raw.isEmpty) {
      return;
    }
    Object? decoded;
    try {
      decoded = jsonDecode(raw);
    } catch (_) {
      return;
    }
    if (decoded is! List) {
      return;
    }
    for (final value in decoded) {
      if (value is! Map) {
        continue;
      }
      final entry = _object(value);
      final key = entry['key'];
      if (key is! String) {
        continue;
      }
      final cached = _object(entry['document']);
      if (!validDocument(cached)) {
        continue;
      }
      _cache.add(<String, Object?>{'key': key, 'document': cached});
      if (_cache.length == cacheLimit) {
        break;
      }
    }
  }

  /// 紧凑序列化写入偏好；UTF-16 长度 ≥240000 时从尾部丢缓存（QString::size 语义）。
  /// Qt 证据：Qt/src/LyricsController.cpp:492-499 persist。
  void _persist() {
    var serialized = jsonEncode(_cache);
    while (serialized.length >= 240000 && _cache.isNotEmpty) {
      _cache.removeLast();
      serialized = jsonEncode(_cache);
    }
    _host.setPreference('lyrics-cache', serialized);
  }

  // ---------------------------------------------------------------------------
  // 内部：读取链
  // ---------------------------------------------------------------------------

  /// 主来源读不到时按 provider 顺序补缺。
  /// Qt 证据：Qt/src/LyricsController.cpp:321-344 supplement。
  Future<void> _supplement(_Load pending) async {
    final source = _providerName(pending.track);
    if (source == 'siren' &&
        pending.lyricSource == 'netease' &&
        _neteaseLyricsBlockedUntil > _now()) {
      pending.networkFailed = true;
      _finish(pending);
      return;
    }
    while (pending.provider < providers.length &&
        (providers[pending.provider] == source ||
            (providers[pending.provider] == 'siren' && source != 'siren') ||
            (pending.lyricSource.isNotEmpty &&
                providers[pending.provider] != pending.lyricSource))) {
      pending.provider++;
    }
    if (pending.provider >= providers.length) {
      _finish(pending);
      return;
    }
    pending.queries = <String>[
      _text(pending.track['title']) + ' ' + _text(pending.track['artist']),
      _text(pending.track['title']),
    ];
    // QStringList::removeDuplicates：保留首次出现。
    final unique = <String>[];
    for (final query in pending.queries) {
      if (!unique.contains(query)) {
        unique.add(query);
      }
    }
    pending.queries = unique;
    pending.query = 0;
    await _search(pending);
  }

  /// 每条 query 取前 2 个 sameRecording 候选；siren→netease 先等 1500ms。
  /// Qt 证据：Qt/src/LyricsController.cpp:346-405 search。
  Future<void> _search(_Load pending) async {
    if (pending.query >= pending.queries.length) {
      pending.provider++;
      await _supplement(pending);
      return;
    }
    final siren = _text(pending.track['provider']) == 'siren';
    if (siren && providers[pending.provider] == 'netease') {
      final now = _now();
      final wait = 1500 - (now - _lastNeteaseLyricRequest);
      if (wait > 0) {
        await _wait(wait);
        if (!_valid(pending)) {
          return;
        }
        await _search(pending);
        return;
      }
      _lastNeteaseLyricRequest = now;
    }
    final provider = providers[pending.provider];
    final api = _apiFor(provider);
    Object? result;
    var ok = true;
    if (api == null) {
      ok = false;
    } else {
      try {
        result = await api.call('search', <Object?>[
          pending.queries[pending.query],
          'song',
          0,
        ]);
      } catch (_) {
        ok = false;
      }
    }
    if (!_valid(pending)) {
      return;
    }
    if (!ok) {
      pending.networkFailed = true;
      if (siren && provider == 'netease') {
        _neteaseLyricsBlockedUntil = _now() + 60000;
      }
      pending.provider++;
      await _supplement(pending);
      return;
    }
    final items = _objectList(_object(result)['items']);
    final candidates = <Map<String, Object?>>[];
    for (final item in items) {
      if (sameRecording(pending.track, item)) {
        candidates.add(item);
        if (candidates.length == 2) {
          break;
        }
      }
    }
    pending.candidates = candidates;
    // Qt 证据：Qt/src/LyricsController.cpp:388-392 —— 封面补全是**发出即走**：
    // 循环内不等待、循环后也不复查 needsCover，控制流立刻落到下面的
    // “needsLyrics/needsCover 都满足才提前返回” 判定。若此处 await，
    // 快速返回的封面实现会在判定前把 needsCover 置 false，从而提前 return
    // 并整段跳过歌词抓取（Qt 不会这样），因此必须 unawaited。
    if (pending.needsCover) {
      for (final item in candidates) {
        unawaited(_loadCandidateCover(pending, item, provider));
      }
    }
    if (!pending.needsLyrics && !pending.needsCover) {
      return;
    }
    if (!pending.needsLyrics) {
      pending.query++;
      await _search(pending);
      return;
    }
    pending.candidate = 0;
    await _fetchCandidate(pending);
  }

  /// 逐候选取歌词；成功后记录 sourceTrackId 并回头补封面。
  /// Qt 证据：Qt/src/LyricsController.cpp:407-445 fetchCandidate。
  Future<void> _fetchCandidate(_Load pending) async {
    if (pending.candidate >= pending.candidates.length) {
      pending.query++;
      await _search(pending);
      return;
    }
    final candidate = pending.candidates[pending.candidate];
    final provider = providers[pending.provider];
    final api = _apiFor(provider);
    Object? result;
    var ok = true;
    if (api == null) {
      ok = false;
    } else {
      try {
        result = await api.call('lyrics', <Object?>[_cloneObject(candidate)]);
      } catch (_) {
        ok = false;
      }
    }
    if (!_valid(pending)) {
      return;
    }
    if (!ok) {
      pending.networkFailed = true;
      if (_text(pending.track['provider']) == 'siren' && provider == 'netease') {
        _neteaseLyricsBlockedUntil = _now() + 60000;
      }
      pending.provider++;
      await _supplement(pending);
      return;
    }
    final loaded = _object(result);
    if (validDocument(loaded) && _lines(loaded).isNotEmpty) {
      loaded['sourceTrackId'] = candidate['id'];
      _accept(loaded, pending.track);
      pending.needsLyrics = false;
      // 找到歌词后仍补齐缺失封面，避免首个平台缺封面时过早结束。
      if (pending.needsCover) {
        pending.lyricSource = '';
        pending.provider = 0;
        await _supplement(pending);
      }
      return;
    }
    pending.candidate++;
    await _fetchCandidate(pending);
  }

  /// 取不到词时的收尾：native plainText 回退、状态/文案、siren 重试墙钟。
  /// Qt 证据：Qt/src/LyricsController.cpp:447-468 finish。
  void _finish(_Load pending) {
    if (!pending.needsLyrics) {
      return;
    }
    if (_text(pending.native['plainText']).isNotEmpty) {
      _accept(pending.native, pending.track);
      return;
    }
    status = pending.networkFailed ? 'error' : 'empty';
    if (_text(pending.track['provider']) == 'siren') {
      final delay = pending.networkFailed ? 60000 : 600000;
      _lyricsRetryAfter[trackKey(pending.track)] = _now() + delay;
    }
    if (pending.networkFailed) {
      message = _text(pending.track['provider']) == 'siren'
          ? '暂无歌词（网易云暂时限流）'
          : '歌词暂不可用，点击重试';
    } else {
      message = '暂无歌词 / 纯音乐';
    }
    _emit();
  }

  /// 接受文档：写 trackKey、重建 starts、算 index、前置插入缓存并持久化。
  /// Qt 证据：Qt/src/LyricsController.cpp:470-490 accept。
  void _accept(Map<String, Object?> value, Map<String, Object?> track) {
    final accepted = _cloneObject(value);
    accepted['trackKey'] = trackKey(track);
    document = accepted;
    _starts.clear();
    for (final line in _lines(accepted)) {
      _starts.add(_number(_object(line)['startMs']));
    }
    status = _starts.isEmpty ? 'plain' : 'ready';
    message = _starts.isEmpty ? '此歌词没有时间信息' : '';
    index = activeLineIndex(accepted, positionMs, offsetMs);
    // Qt 证据：Qt/src/LyricsController.cpp:480-486 —— 缓存条目只有
    // {"key","document"} 两个字段，**不含 offsetMs**；每曲偏移只活在内存里
    // （切歌时按 :250/:252 重置为全局偏移），跨进程只经 playbackSnapshot 往返。
    final cache = <Map<String, Object?>>[
      <String, Object?>{'key': currentKey, 'document': accepted},
    ];
    for (final entry in _cache) {
      if (_text(entry['key']) != currentKey && cache.length < cacheLimit) {
        cache.add(entry);
      }
    }
    _cache = cache;
    _lyricsRetryAfter.remove(currentKey);
    _persist();
    _emit();
  }

  /// 本地歌词：选源 → sidecar/内嵌 → 桥解析。
  /// Qt 证据：Qt/src/LyricsController.cpp:546-627 loadLocal。
  Future<void> _loadLocal(Map<String, Object?> track, _Load pending) async {
    if (providers.contains(localSource)) {
      pending.lyricSource = localSource;
      status = 'loading';
      message = '正在从所选来源匹配歌词…';
      _emit();
      await _supplement(pending);
      return;
    }
    final content = _text(track['localLyrics']);
    var sidecarBytes = const <int>[];
    // 端口来源优先级：显式注入 > 主机自身实现；都没有则按“无 sidecar”降级
    // （Qt 里等价于两个后缀都 open 失败）。
    final files = _localFiles ??
        (_host is LyricsLocalFilePort ? _host as LyricsLocalFilePort : null);
    if (files != null) {
      final base = _lyricsSidecarBase(_text(track['path']));
      if (base.isNotEmpty) {
        for (final suffix in const <String>['.lrc', '.LRC']) {
          List<int>? bytes;
          try {
            bytes = await files.readLocalBytes(base + suffix);
          } catch (_) {
            bytes = null;
          }
          if (!_valid(pending)) {
            return;
          }
          // Qt：open 成功且 size ≤ 1000000 才读取；空白内容不算 sidecar。
          if (bytes == null || bytes.length > 1000000 || _isBlankBytes(bytes)) {
            continue;
          }
          sidecarBytes = List<int>.of(bytes);
          break;
        }
      }
    }
    if (sidecarBytes.isEmpty && content.trim().isEmpty) {
      if (localSource == 'local') {
        pending.needsLyrics = false;
        status = 'empty';
        message = '没有本地歌词文件或内嵌歌词，可选择其他来源';
        _emit();
        if (pending.needsCover) {
          await _supplement(pending);
        }
        return;
      }
      status = 'loading';
      message = '本地缺少歌词，正在匹配…';
      _emit();
      for (final entry in _cache) {
        final cached = _object(entry['document']);
        if (_text(entry['key']) == currentKey &&
            _text(cached['source']) != 'local' &&
            validDocument(cached)) {
          _accept(cached, track);
          pending.needsLyrics = false;
          break;
        }
      }
      if (pending.needsLyrics || pending.needsCover) {
        await _supplement(pending);
      }
      return;
    }
    status = 'loading';
    _emit();
    // 原始字节交给桥统一识别编码；内嵌歌词已由标签库转成 Unicode，作为回退保留。
    final parameters = <String, Object?>{'content': content};
    if (sidecarBytes.isNotEmpty) {
      parameters['contentBase64'] = base64Encode(sidecarBytes);
    }
    var response = <String, Object?>{};
    var error = '';
    try {
      response = await _host.requestJson('/local/lyrics', parameters);
    } catch (failure) {
      error = failure.toString();
    }
    if (!_valid(pending)) {
      return;
    }
    final body = _object(response['body']);
    final loaded = _object(body['document']);
    if (error.isEmpty &&
        validDocument(loaded) &&
        (_lines(loaded).isNotEmpty || _text(loaded['plainText']).isNotEmpty)) {
      _accept(loaded, pending.track);
      pending.needsLyrics = false;
    }
    if (pending.needsLyrics && localSource == 'local') {
      pending.needsLyrics = false;
      status = 'empty';
      message = '本地歌词无法读取，可选择其他来源';
      _emit();
    }
    if (pending.needsLyrics || pending.needsCover) {
      await _supplement(pending);
    }
  }

  // ---------------------------------------------------------------------------
  // 内部：封面
  // ---------------------------------------------------------------------------

  /// 已有封面直接补；缺封面时复用同平台歌曲详情，且仍按录音信息核对。
  /// Qt 证据：Qt/src/LyricsController.cpp:197-224 loadCandidateCover。
  Future<void> _loadCandidateCover(
    _Load pending,
    Map<String, Object?> candidate,
    String provider,
  ) async {
    final cover = _text(candidate['cover']);
    if (cover.isNotEmpty) {
      _tryCover(pending, cover);
      return;
    }
    final key = 'detail:' + provider + ':' + _text(candidate['id']);
    if (pending.coverRequests.contains(key)) {
      return;
    }
    pending.coverRequests.add(key);
    LyricsApiPort? api;
    try {
      api = _apiFor(provider);
    } catch (_) {
      // 该 Future 是发出即走（Qt:388-392）：任何失败都只能内部吞掉，
      // 不允许变成未处理异步异常中断调用方。
      return;
    }
    if (api == null) {
      return;
    }
    Object? result;
    try {
      // Qt 证据：Qt/src/LyricsController.cpp:210-211 —— 参数是
      // {QJsonValue(QJsonArray{candidate["id"]})}，即 args = [[id]]（"songs"
      // 端点首参是 id 数组；对照 MusicDirectory.cpp:352 与 MusicLibrary.cpp:704
      // 的 {QJsonValue(ids)}）。不能写成 [id]。
      result = await api.call('songs', <Object?>[
        <Object?>[candidate['id']],
      ]);
    } catch (_) {
      return;
    }
    if (!_valid(pending) || !pending.needsCover) {
      return;
    }
    for (final value in _objectList(result)) {
      if (sameRecording(pending.track, value)) {
        _tryCover(pending, _text(value['cover']));
      }
    }
  }

  /// 封面加载一次一 URL；成功后发 coverMatched（key 用 pending 曲目身份）。
  /// Qt 证据：Qt/src/LyricsController.cpp:184-195 tryCover。
  void _tryCover(_Load pending, String url) {
    if (!pending.needsCover || url.isEmpty || pending.coverRequests.contains(url)) {
      return;
    }
    pending.coverRequests.add(url);
    unawaited(_host.loadCover(url).then(
      (image) {
        if (_valid(pending) && pending.needsCover && image.isNotEmpty) {
          pending.needsCover = false;
          _emitCover(trackKey(pending.track), url);
        }
      },
      onError: (Object _) {},
    ));
  }

  // ---------------------------------------------------------------------------
  // 内部：远程命令与端口
  // ---------------------------------------------------------------------------

  /// 有播放连接时转发命令并按 snapshot["lyrics"] 应用；返回 true 表示已接管。
  /// Qt 证据：Qt/src/LyricsController.cpp:629-637 remoteCommand。
  bool _remoteCommand(String method, [Map<String, Object?>? arguments]) {
    final remote = _remote;
    if (remote == null) {
      return false;
    }
    remote.call('lyrics.' + method, arguments ?? <String, Object?>{});
    applyPlaybackSnapshot(_object(remote.snapshot['lyrics']));
    return true;
  }

  /// Qt api(provider)：未知来源回落到 netease 实例。
  LyricsApiPort? _apiFor(String provider) {
    final factory = _apiFactory;
    if (factory == null) {
      return null;
    }
    final name = providers.contains(provider) ? provider : providers.first;
    final cached = _apis[name];
    if (cached != null) {
      return cached;
    }
    final created = factory(name);
    _apis[name] = created;
    return created;
  }

  /// Qt MusicApi::Valid：代号一致才允许推进（Qt 另有 QPointer 存活检查，
  /// Dart 侧对象由监听者保活，故以代号为主要判据）。
  bool _valid(_Load pending) => pending.generation == _generation;

  Future<void> _wait(int delayMs) {
    final completer = Completer<void>();
    _host.schedule(delayMs, () {
      if (!completer.isCompleted) {
        completer.complete();
      }
    });
    return completer.future;
  }

  static int _now() => DateTime.now().millisecondsSinceEpoch;
}

/// 单次读取任务的共享状态，对齐 Qt LyricsController::Load。
class _Load {
  _Load({required this.generation, required this.track});

  final int generation;
  final Map<String, Object?> track;
  Map<String, Object?> native = <String, Object?>{};
  bool networkFailed = false;
  int provider = 0;
  List<String> queries = <String>[];
  int query = 0;
  List<Map<String, Object?>> candidates = <Map<String, Object?>>[];
  int candidate = 0;
  bool needsLyrics = true;
  bool needsCover = false;
  String lyricSource = '';
  final List<String> coverRequests = <String>[];
}

// -----------------------------------------------------------------------------
// 归一化与类型工具（Qt 匿名命名空间同名逻辑）
// -----------------------------------------------------------------------------

/// Qt QRegularExpression("[\\s\\p{P}\\p{S}]", UseUnicodePropertiesOption)：
/// 去掉空白、标点与符号。Dart RegExp 的 unicode 模式提供同名属性类。
final RegExp _stripped = RegExp(r'[\s\p{P}\p{S}]', unicode: true);

const List<String> _versionKeywords = <String>[
  'live',
  'remix',
  'demo',
  'acoustic',
  'instrumental',
  '伴奏',
  '翻唱',
  '现场',
  '重录',
];

/// Qt comparable：NFKC → 小写 → 去掉空白/标点/符号。
/// Qt 证据：Qt/src/LyricsController.cpp:16-20。
///
/// Qt 用 QString::NormalizationForm_KC（完整 NFKC 表）；纯 Dart 无归一化表，
/// 这里实现**影响曲名/歌手匹配的兼容分解子集**，覆盖范围见
/// [_nfkcCompatibility]。未覆盖的输入（半角片假名及其浊点组合、CJK 兼容
/// 表意文字等）保留原样——这是本移植唯一无法用无表实现对齐的偏差，已在
/// 文件头“已知偏差”登记，且不改变任何控制流/字段/阈值。
String _comparable(String value) {
  return _compatibilityFold(value).toLowerCase().replaceAll(_stripped, '');
}

String _compatibilityFold(String value) {
  final buffer = StringBuffer();
  for (final rune in value.runes) {
    final folded = _nfkcCompatibility(rune);
    if (folded != null) {
      buffer.write(folded);
    } else {
      buffer.writeCharCode(rune);
    }
  }
  return buffer.toString();
}

const List<String> _romanUpper = <String>[
  'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', //
  'L', 'C', 'D', 'M',
];
const List<String> _romanLower = <String>[
  'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x', 'xi', 'xii', //
  'l', 'c', 'd', 'm',
];

/// NFKC 兼容分解子集（单码位 → 展开串）；返回 null 表示无兼容分解。
///
/// 覆盖：全角 ASCII（U+FF01..FF5E）、表意空格（U+3000）、全角货币
/// （U+FFE0..FFE6）、罗马数字（U+2160..U+217F）、带圈/带括号数字
/// （U+2460..U+24EA）、带括号字母（U+249C..U+24B5）、连字（U+FB00..FB06）、
/// 上标/下标数字与符号（U+00B2/B3/B9、U+2070..207E、U+2080..208E）。
String? _nfkcCompatibility(int rune) {
  if (rune >= 0xFF01 && rune <= 0xFF5E) {
    return String.fromCharCode(rune - 0xFEE0);
  }
  if (rune == 0x3000) {
    return ' ';
  }
  if (rune >= 0xFFE0 && rune <= 0xFFE6) {
    const mapped = <int, int>{
      0xFFE0: 0x00A2,
      0xFFE1: 0x00A3,
      0xFFE2: 0x00AC,
      0xFFE3: 0x02C9,
      0xFFE4: 0x00A6,
      0xFFE5: 0x00A5,
      0xFFE6: 0x20A9,
    };
    return String.fromCharCode(mapped[rune]!);
  }
  if (rune >= 0x2160 && rune <= 0x216F) {
    return _romanUpper[rune - 0x2160];
  }
  if (rune >= 0x2170 && rune <= 0x217F) {
    return _romanLower[rune - 0x2170];
  }
  if (rune >= 0x2460 && rune <= 0x2473) {
    return (rune - 0x2460 + 1).toString();
  }
  if (rune >= 0x2474 && rune <= 0x2487) {
    return (rune - 0x2474 + 1).toString();
  }
  if (rune >= 0x2488 && rune <= 0x249B) {
    return (rune - 0x2488 + 1).toString();
  }
  if (rune == 0x24EA) {
    return '0';
  }
  if (rune >= 0x249C && rune <= 0x24B5) {
    return '(' + String.fromCharCode(0x61 + rune - 0x249C) + ')';
  }
  if (rune >= 0x24B6 && rune <= 0x24CF) {
    return String.fromCharCode(0x41 + rune - 0x24B6);
  }
  if (rune >= 0x24D0 && rune <= 0x24E9) {
    return String.fromCharCode(0x61 + rune - 0x24D0);
  }
  if (rune >= 0xFB00 && rune <= 0xFB06) {
    const ligatures = <String>['ff', 'fi', 'fl', 'ffi', 'ffl', 'st', 'st'];
    return ligatures[rune - 0xFB00];
  }
  if (rune == 0x00B2) {
    return '2';
  }
  if (rune == 0x00B3) {
    return '3';
  }
  if (rune == 0x00B9) {
    return '1';
  }
  if (rune >= 0x2070 && rune <= 0x207E) {
    const superscripts = <String>[
      '0', 'i', null, null, '4', '5', '6', '7', '8', '9', '+', '\u2212', '=', '(', ')', //
    ];
    return superscripts[rune - 0x2070];
  }
  if (rune == 0x207F) {
    return 'n';
  }
  if (rune >= 0x2080 && rune <= 0x208E) {
    const subscripts = <String>[
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '\u2212', '=', '(', ')', //
    ];
    return subscripts[rune - 0x2080];
  }
  return null;
}

/// Qt artists：优先 artists[].name，空则按 \s*/\s* 切 artist；归一化后排序。
List<String> _artists(Map<String, Object?> track) {
  var values = <String>[];
  final raw = track['artists'];
  if (raw is List) {
    for (final artist in raw) {
      // Qt artist.toObject()["name"].toString()：非对象按空名参与，保持集合非空语义。
      values.add(artist is Map ? _text(artist['name']) : '');
    }
  }
  if (values.isEmpty) {
    values = _text(track['artist']).split(RegExp(r'\s*/\s*'));
  }
  final normalized = <String>[];
  for (final value in values) {
    final text = _comparable(value);
    if (text.isNotEmpty) {
      normalized.add(text);
    }
  }
  normalized.sort();
  return normalized;
}

/// Qt recordingVersion：标题+专辑小写后按关键词表收集、排序、/ 连接。
String _recordingVersion(Map<String, Object?> track) {
  final text = (_text(track['title']) + ' ' + _text(track['album'])).toLowerCase();
  final versions = <String>[];
  for (final keyword in _versionKeywords) {
    if (text.contains(keyword)) {
      versions.add(keyword);
    }
  }
  versions.sort();
  return versions.join('/');
}

String _text(Object? value) => value is String ? value : '';

String _stringOr(Object? value, String fallback) => value is String ? value : fallback;

double _number(Object? value) => value is num ? value.toDouble() : 0.0;

int _integer(Object? value, int fallback) => value is num ? value.toInt() : fallback;

/// Qt track["provider"].toString("netease")：非字符串回落 netease。
String _providerName(Map<String, Object?> track) {
  final provider = track['provider'];
  return provider is String ? provider : 'netease';
}

Map<String, Object?> _object(Object? value) {
  if (value is! Map) {
    return <String, Object?>{};
  }
  final result = <String, Object?>{};
  value.forEach((Object? key, Object? item) {
    if (key is String) {
      result[key] = item;
    }
  });
  return result;
}

List<Object?> _lines(Map<String, Object?> document) {
  final raw = document['lines'];
  return raw is List ? raw : const <Object?>[];
}

List<Map<String, Object?>> _objectList(Object? value) {
  if (value is! List) {
    return <Map<String, Object?>>[];
  }
  return <Map<String, Object?>>[for (final item in value) _object(item)];
}

Object? _cloneValue(Object? value) {
  if (value is Map) {
    return _cloneObject(value);
  }
  if (value is List) {
    return <Object?>[for (final item in value) _cloneValue(item)];
  }
  return value;
}

Map<String, Object?> _cloneObject(Object? value) {
  final source = _object(value);
  final result = <String, Object?>{};
  source.forEach((String key, Object? item) {
    result[key] = _cloneValue(item);
  });
  return result;
}

bool _sameList(List<String> left, List<String> right) {
  if (left.length != right.length) {
    return false;
  }
  for (var row = 0; row < left.length; row++) {
    if (left[row] != right[row]) {
      return false;
    }
  }
  return true;
}

int _upperBound(List<double> values, double value) {
  var lower = 0;
  var upper = values.length;
  while (lower < upper) {
    final middle = (lower + upper) ~/ 2;
    if (values[middle] <= value) {
      lower = middle + 1;
    } else {
      upper = middle;
    }
  }
  return lower;
}

/// Qt QString::toDouble：空串/非法返回 null（调用方按 ok=false 处理）。
double? _parseOffset(String raw) {
  final text = raw.trim();
  if (text.isEmpty) {
    return null;
  }
  return double.tryParse(text);
}

/// Qt QByteArray::trimmed().isEmpty()：只含 ASCII 空白视为空白。
bool _isBlankBytes(List<int> bytes) {
  for (final byte in bytes) {
    if (byte != 0x20 &&
        byte != 0x09 &&
        byte != 0x0A &&
        byte != 0x0B &&
        byte != 0x0C &&
        byte != 0x0D) {
      return false;
    }
  }
  return true;
}

/// Qt QFileInfo::absolutePath() + '/' + completeBaseName()。
String _lyricsSidecarBase(String path) {
  if (path.isEmpty) {
    return '';
  }
  final slash = path.lastIndexOf('/');
  final directory = slash >= 0 ? path.substring(0, slash) : '';
  final name = slash >= 0 ? path.substring(slash + 1) : path;
  if (name.isEmpty) {
    return '';
  }
  final dot = name.lastIndexOf('.');
  final base = dot > 0 ? name.substring(0, dot) : name;
  return directory.isEmpty ? base : directory + '/' + base;
}

/// QString::number(double)：'g' 6 位有效数字，指数形式补足两位。
String _qtNumber(double value) {
  if (value == 0) {
    return '0';
  }
  if (value.isNaN) {
    return 'nan';
  }
  if (value.isInfinite) {
    return value.isNegative ? '-inf' : 'inf';
  }
  final negative = value < 0;
  final magnitude = value.abs();
  var exponent = (math.log(magnitude) / math.ln10).floor();
  var scaled = magnitude / math.pow(10.0, exponent.toDouble()).toDouble();
  while (scaled >= 10) {
    scaled /= 10;
    exponent++;
  }
  while (scaled < 1) {
    scaled *= 10;
    exponent--;
  }
  String body;
  if (exponent < -4 || exponent >= 6) {
    final mantissa = _trimZeros(scaled.toStringAsFixed(5));
    final sign = exponent < 0 ? '-' : '+';
    body = mantissa + 'e' + sign + exponent.abs().toString().padLeft(2, '0');
  } else {
    body = _trimZeros(magnitude.toStringAsFixed(5 - exponent));
  }
  return negative ? '-' + body : body;
}

String _trimZeros(String value) {
  if (!value.contains('.')) {
    return value;
  }
  var result = value;
  while (result.endsWith('0')) {
    result = result.substring(0, result.length - 1);
  }
  if (result.endsWith('.')) {
    result = result.substring(0, result.length - 1);
  }
  return result;
}
