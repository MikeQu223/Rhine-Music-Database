#include "TextureHost.h"

#include <QCoreApplication>
#include <QDebug>
#include <QHash>
#include <QGuiApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QMutex>
#include <QMutexLocker>
#include <QOpenGLContext>
#include <QOpenGLExtraFunctions>
#include <QPointingDevice>
#include <QQuickGraphicsDevice>
#include <QQuickItem>
#include <QQuickRenderControl>
#include <QQuickRenderTarget>
#include <QQuickWindow>
#include <QSurfaceFormat>
#include <QtGui/qopenglcontext_platform.h>
#include <QQmlComponent>
#include <QQmlEngine>

#include <rhi/qrhi.h>

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <jni.h>

#include <atomic>
#include <chrono>

/*
 * 后端选择与退出条件（写在这里而不是散在报告里，审阅时一眼可见）：
 *
 * 1. 本宿主走 OpenGL/EGL。QQuickRenderControl 渲染到离屏 QRhiTexture，然后在同一个
 *    EGL 上下文里把该纹理 blit 到 SurfaceTexture 的生产端窗口再 eglSwapBuffers。
 *    选它是因为 QRhi 的 GLES2 后端接受外部 QOpenGLContext（QQuickGraphicsDevice::
 *    fromOpenGLContext），而 EGL 窗口表面的创建/交换是公开的 EGL API，不需要 Qt 私有头。
 * 2. Vulkan 不实现。理由：QQuickGraphicsDevice::fromDeviceObjects 只能导入
 *    VkPhysicalDevice/VkDevice/queueFamilyIndex/queueIndex，QRhi 不暴露"渲染到外部
 *    VkSurface 并 present"的入口；要给 Flutter 合成就只能走 VK_ANDROID_external_memory
 *    /AHardwareBuffer 导出再 fromVulkanImage，那条路径既要求 GL/VK 共享 external memory
 *    扩展，又要求 Flutter 侧 accept 该格式，属于设备相关能力，本切片没有证据支持。
 *    退出条件因此是：若宿主强制要求 Vulkan（例如宿主自身 GL 上下文不可共享），本宿主
 *    直接报 archBlocked，不静默回退到静态首帧。
 * 3. 若 QRhi 实际选出的后端不是 OpenGLES2（例如宿主把它配置成 Vulkan），start() 报
 *    archBlocked 并带出真实 backend 名，不做像素伪装。
 */

namespace {

// 内置探针场景：没有接真实 HUD 像素的意图，只提供"有动画"的可验证内容。
// 动画是必要的：静态首帧会让"每帧都在真正重绘"这条断言失去意义（计划里的 Fail 条件
// 明确写了"只有静态首帧"要判失败）。
const char *const kProbeQml = R"QML(
import QtQuick

Item {
    id: probe
    width: 360
    height: 640

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#ff1b2b3a" }
            GradientStop { position: 1.0; color: "#ff0d1620" }
        }
    }

    Rectangle {
        id: spinner
        width: Math.min(probe.width, probe.height) * 0.28
        height: width
        radius: width * 0.18
        color: "#ff35c6a4"
        anchors.centerIn: parent

        NumberAnimation on rotation {
            from: 0
            to: 360
            duration: 2000
            loops: Animation.Infinite
            running: true
        }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 24
        color: "#ffe7e7e1"
        font.pixelSize: 18
        text: "qt texture probe"
    }
}
)QML";

/// 采样矩阵：把 RHI 纹理的 uv 按四分之一圈旋转后送给 blit 着色器。
/// 列主序，与 glUniformMatrix3fv(transpose = GL_FALSE) 一致。
const float kUvMatrices[4][9] = {
    {1.f, 0.f, 0.f, 0.f, 1.f, 0.f, 0.f, 0.f, 1.f},
    {0.f, -1.f, 0.f, 1.f, 0.f, 0.f, 0.f, 1.f, 1.f},
    {-1.f, 0.f, 0.f, 0.f, -1.f, 0.f, 1.f, 1.f, 1.f},
    {0.f, 1.f, 0.f, -1.f, 0.f, 0.f, 1.f, 0.f, 1.f},
};

const char *const kBlitVertexShader = R"GLSL(#version 300 es
in vec2 a_position;
in vec2 a_uv;
uniform mat3 u_uvMatrix;
out vec2 v_uv;
void main() {
    v_uv = (u_uvMatrix * vec3(a_uv, 1.0)).xy;
    gl_Position = vec4(a_position, 0.0, 1.0);
}
)GLSL";

const char *const kBlitFragmentShader = R"GLSL(#version 300 es
precision mediump float;
uniform sampler2D u_texture;
in vec2 v_uv;
out vec4 fragColor;
void main() {
    fragColor = texture(u_texture, v_uv);
}
)GLSL";

} // namespace

TextureHost::TextureHost(QQmlEngine *engine, QObject *parent)
    : QObject(parent), m_engine(engine) {
    if (!m_engine) {
        m_engine = new QQmlEngine(this);
        m_ownsEngine = true;
    }
}

TextureHost::~TextureHost() {
    release();
    if (m_rootItem) {
        delete m_rootItem;
        m_rootItem = nullptr;
    }
    delete m_window;
    m_window = nullptr;
    delete m_control;
    m_control = nullptr;
    // m_engine 若由本类创建，parent 是 this，随 QObject 析构一起回收。
}

QByteArray TextureHost::Report::toJson() const {
    // 只输出冻结契约里的 10 个键。surfaceAttached 留在结构体里给 C++ 侧判断用，
    // 不进 JSON，避免 Dart 侧的严格解析看到契约外字段。
    QJsonObject obj;
    obj.insert(QStringLiteral("rendered"), rendered);
    obj.insert(QStringLiteral("frameSequence"), static_cast<double>(frameSequence));
    obj.insert(QStringLiteral("firstFrameRendered"), firstFrameRendered);
    obj.insert(QStringLiteral("width"), width);
    obj.insert(QStringLiteral("height"), height);
    obj.insert(QStringLiteral("rotationQuarterTurns"), rotationQuarterTurns);
    obj.insert(QStringLiteral("publishTimestampNanos"),
               static_cast<double>(publishTimestampNanos));
    obj.insert(QStringLiteral("status"), status);
    obj.insert(QStringLiteral("lastError"), lastError);
    obj.insert(QStringLiteral("backend"), backend);
    return QJsonDocument(obj).toJson(QJsonDocument::Compact);
}

quint64 TextureHost::monotonicNanos() const {
    const auto now = std::chrono::steady_clock::now().time_since_epoch();
    return static_cast<quint64>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(now).count());
}

void TextureHost::fail(const QString &status, const QString &message) {
    m_phase = Phase::Failed;
    m_status = status;
    if (!message.isEmpty()) {
        m_lastStatusError = message;
        qWarning() << "TextureHost:" << status << message;
    }
    if (m_backend.isEmpty()) {
        m_backend = QStringLiteral("none");
    }
}

TextureHost::Report TextureHost::report() const {
    Report r;
    r.status = m_status;
    r.backend = m_backend;
    r.lastError = m_lastStatusError;
    r.rendered = false;
    r.frameSequence = m_frameSequence;
    r.firstFrameRendered = m_firstFrame;
    r.width = m_width;
    r.height = m_height;
    r.rotationQuarterTurns = m_rotation;
    r.publishTimestampNanos = m_publishTimestampNanos;
    r.surfaceAttached = m_eglSurface != nullptr;
    return r;
}

bool TextureHost::isStarted() const {
    return m_phase == Phase::Ready && m_eglSurface != nullptr;
}

void TextureHost::setRootUrl(const QUrl &url) {
    m_rootUrl = url;
}

bool TextureHost::loadScene() {
    if (!m_window) {
        fail(QStringLiteral("failed"), QStringLiteral("window 尚未创建"));
        return false;
    }

    QQmlComponent component(m_engine);
    if (m_rootUrl.isEmpty()) {
        component.setData(QByteArray(kProbeQml), QUrl(QStringLiteral("file:builtin-probe.qml")));
    } else {
        component.loadUrl(m_rootUrl);
    }

    if (component.isError()) {
        fail(QStringLiteral("failed"),
             QStringLiteral("QML 载入失败：%1").arg(component.errorString()));
        return false;
    }

    QObject *object = component.create();
    if (!object) {
        fail(QStringLiteral("failed"),
             QStringLiteral("QML 实例化失败：%1").arg(component.errorString()));
        return false;
    }

    auto *item = qobject_cast<QQuickItem *>(object);
    if (!item) {
        fail(QStringLiteral("failed"), QStringLiteral("QML 根对象不是 QQuickItem"));
        delete object;
        return false;
    }

    if (m_rootItem) {
        delete m_rootItem;
    }
    m_rootItem = item;
    m_rootItem->setParentItem(m_window->contentItem());
    const qreal dpr = m_dpr > 0.0 ? m_dpr : 1.0;
    m_rootItem->setSize(QSizeF(m_width / dpr, m_height / dpr));
    return true;
}

bool TextureHost::rebuildTarget(int width, int height) {
    if (!m_rhi) {
        fail(QStringLiteral("failed"), QStringLiteral("QRhi 尚未就绪"));
        return false;
    }
    if (width <= 0 || height <= 0) {
        fail(QStringLiteral("failed"),
             QStringLiteral("非法尺寸 %1x%2").arg(width).arg(height));
        return false;
    }

    // 纹理目标不可原地 resize：尺寸变化必须销毁重建（与 SceneLayerHost 的 resize 一致）。
    if (m_renderTarget) {
        delete m_renderTarget;
        m_renderTarget = nullptr;
    }
    if (m_renderPass) {
        delete m_renderPass;
        m_renderPass = nullptr;
    }
    if (m_texture) {
        delete m_texture;
        m_texture = nullptr;
    }

    m_texture = m_rhi->newTexture(QRhiTexture::RGBA8, QSize(width, height), 1,
                                  QRhiTexture::RenderTarget | QRhiTexture::UsedAsTransferSource);
    if (!m_texture || !m_texture->create()) {
        fail(QStringLiteral("failed"),
             QStringLiteral("离屏纹理创建失败：%1").arg(m_rhi->backendName()));
        return false;
    }

    QRhiColorAttachment colorAttachment(m_texture);
    QRhiTextureRenderTargetDescription description(colorAttachment);
    m_renderPass = m_rhi->newCompatibleRenderPassDescriptor();
    m_renderTarget = m_rhi->newTextureRenderTarget(description, QRhiTextureRenderTarget::PreserveColorContents);
    if (!m_renderPass || !m_renderTarget) {
        fail(QStringLiteral("failed"), QStringLiteral("渲染目标分配失败"));
        return false;
    }
    m_renderTarget->setRenderPassDescriptor(m_renderPass);
    if (!m_renderTarget->create()) {
        fail(QStringLiteral("failed"), QStringLiteral("渲染目标创建失败"));
        return false;
    }

    QQuickRenderTarget quickTarget = QQuickRenderTarget::fromRhiRenderTarget(m_renderTarget);
    if (quickTarget.isNull()) {
        fail(QStringLiteral("failed"), QStringLiteral("QQuickRenderTarget 构造失败"));
        return false;
    }
    const qreal dpr = m_dpr > 0.0 ? m_dpr : 1.0;
    quickTarget.setDevicePixelRatio(dpr);
    m_window->setRenderTarget(quickTarget);

    m_width = width;
    m_height = height;
    m_window->setGeometry(0, 0, qRound(width / dpr), qRound(height / dpr));
    m_window->contentItem()->setSize(QSizeF(width / dpr, height / dpr));
    if (m_rootItem) {
        m_rootItem->setSize(QSizeF(width / dpr, height / dpr));
    }
    return true;
}

bool TextureHost::initGraphics(ANativeWindow *window) {
    if (!QGuiApplication::instance()) {
        // Flutter 进程里没有 QGuiApplication 就不可能建 QQuickWindow。这条是最常见的
        // 架构性失败，单独给出 archBlocked（而不是 failed），让 Dart 侧能区分"接线缺口"
        // 与"运行时错误"。
        fail(QStringLiteral("archBlocked"),
             QStringLiteral("当前进程没有 QGuiApplication 实例，Qt Quick 无法渲染"));
        return false;
    }

    QSurfaceFormat format;
    format.setRenderableType(QSurfaceFormat::OpenGLES);
    format.setVersion(3, 0);
    format.setProfile(QSurfaceFormat::NoProfile);
    format.setDepthBufferSize(0);
    format.setStencilBufferSize(0);
    format.setSamples(0);
    format.setSwapBehavior(QSurfaceFormat::NoSwap);

    m_glContext = new QOpenGLContext(this);
    m_glContext->setFormat(format);
    if (!m_glContext->create()) {
        fail(QStringLiteral("failed"), QStringLiteral("QOpenGLContext 创建失败"));
        return false;
    }

    auto *egl = m_glContext->nativeInterface<QNativeInterface::QEGLContext>();
    if (!egl) {
        fail(QStringLiteral("archBlocked"),
             QStringLiteral("Qt 平台插件不是 EGL（拿不到 QEGLContext），无法绑定 Surface"));
        return false;
    }

    EGLDisplay display = egl->display();
    EGLConfig config = egl->config();
    EGLContext context = egl->nativeContext();
    if (display == EGL_NO_DISPLAY || config == nullptr || context == EGL_NO_CONTEXT) {
        fail(QStringLiteral("failed"), QStringLiteral("QEGLContext 暴露的 EGL 句柄无效"));
        return false;
    }

    const EGLint surfaceAttributes[] = {
        EGL_RENDER_BUFFER, EGL_BACK_BUFFER,
        EGL_NONE,
    };
    EGLSurface surface = eglCreateWindowSurface(display, config, window, surfaceAttributes);
    if (surface == EGL_NO_SURFACE) {
        fail(QStringLiteral("failed"),
             QStringLiteral("eglCreateWindowSurface 失败，EGL error=0x%1")
                 .arg(static_cast<int>(eglGetError()), 0, 16));
        return false;
    }

    m_eglDisplay = display;
    m_eglConfig = config;
    m_eglContext = context;
    m_eglSurface = surface;
    m_nativeWindow = window;
    return true;
}

bool TextureHost::makeBlitCurrent() {
    if (!m_eglDisplay || !m_eglSurface || !m_eglContext) {
        return false;
    }
    const EGLBoolean ok = eglMakeCurrent(static_cast<EGLDisplay>(m_eglDisplay),
                                        static_cast<EGLSurface>(m_eglSurface),
                                        static_cast<EGLSurface>(m_eglSurface),
                                        static_cast<EGLContext>(m_eglContext));
    if (ok != EGL_TRUE) {
        fail(QStringLiteral("failed"),
             QStringLiteral("eglMakeCurrent(窗口表面) 失败，EGL error=0x%1")
                 .arg(static_cast<int>(eglGetError()), 0, 16));
        return false;
    }
    return true;
}

void TextureHost::doneBlitCurrent() {
    if (!m_eglDisplay) {
        return;
    }
    // 交还当前上下文。Qt/QRhi 下一帧会用自己的 fallback surface 重新 makeCurrent。
    eglMakeCurrent(static_cast<EGLDisplay>(m_eglDisplay), EGL_NO_SURFACE, EGL_NO_SURFACE,
                   EGL_NO_CONTEXT);
}

bool TextureHost::initBlitPipeline() {
    auto *f = m_glContext ? m_glContext->extraFunctions() : nullptr;
    if (!f) {
        fail(QStringLiteral("failed"), QStringLiteral("拿不到 QOpenGLExtraFunctions"));
        return false;
    }

    auto compile = [f](GLenum type, const char *source) -> GLuint {
        const GLuint shader = f->glCreateShader(type);
        f->glShaderSource(shader, 1, &source, nullptr);
        f->glCompileShader(shader);
        GLint status = GL_FALSE;
        f->glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
        if (status != GL_TRUE) {
            GLint logLength = 0;
            f->glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
            QByteArray log(qMax(1, static_cast<int>(logLength)), '\0');
            f->glGetShaderInfoLog(shader, log.size(), nullptr, log.data());
            qWarning() << "TextureHost: blit shader 编译失败" << log;
            f->glDeleteShader(shader);
            return 0;
        }
        return shader;
    };

    const GLuint vertexShader = compile(GL_VERTEX_SHADER, kBlitVertexShader);
    const GLuint fragmentShader = compile(GL_FRAGMENT_SHADER, kBlitFragmentShader);
    if (vertexShader == 0 || fragmentShader == 0) {
        if (vertexShader) {
            f->glDeleteShader(vertexShader);
        }
        if (fragmentShader) {
            f->glDeleteShader(fragmentShader);
        }
        fail(QStringLiteral("failed"), QStringLiteral("blit 着色器编译失败"));
        return false;
    }

    m_blitProgram = f->glCreateProgram();
    f->glAttachShader(m_blitProgram, vertexShader);
    f->glAttachShader(m_blitProgram, fragmentShader);
    f->glBindAttribLocation(m_blitProgram, 0, "a_position");
    f->glBindAttribLocation(m_blitProgram, 1, "a_uv");
    f->glLinkProgram(m_blitProgram);
    f->glDeleteShader(vertexShader);
    f->glDeleteShader(fragmentShader);

    GLint linked = GL_FALSE;
    f->glGetProgramiv(m_blitProgram, GL_LINK_STATUS, &linked);
    if (linked != GL_TRUE) {
        GLint logLength = 0;
        f->glGetProgramiv(m_blitProgram, GL_INFO_LOG_LENGTH, &logLength);
        QByteArray log(qMax(1, static_cast<int>(logLength)), '\0');
        f->glGetProgramInfoLog(m_blitProgram, log.size(), nullptr, log.data());
        fail(QStringLiteral("failed"),
             QStringLiteral("blit 程序链接失败：%1").arg(QString::fromUtf8(log)));
        return false;
    }

    m_blitUvMatrixLocation = f->glGetUniformLocation(m_blitProgram, "u_uvMatrix");
    m_blitTextureLocation = f->glGetUniformLocation(m_blitProgram, "u_texture");

    // 全屏 quad：三角形条带 4 顶点，(位置 x,y) + (uv u,v)。
    // uv 的 y 取反：RHI 的纹理原点在左上，而 GL 的默认帧缓冲原点在左下。
    const float vertices[] = {
        -1.f, -1.f, 0.f, 1.f,
         1.f, -1.f, 1.f, 1.f,
        -1.f,  1.f, 0.f, 0.f,
         1.f,  1.f, 1.f, 0.f,
    };

    f->glGenVertexArrays(1, &m_blitVao);
    f->glGenBuffers(1, &m_blitVbo);
    f->glBindVertexArray(m_blitVao);
    f->glBindBuffer(GL_ARRAY_BUFFER, m_blitVbo);
    f->glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    f->glEnableVertexAttribArray(0);
    f->glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), nullptr);
    f->glEnableVertexAttribArray(1);
    f->glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float),
                             reinterpret_cast<const void *>(2 * sizeof(float)));
    f->glBindVertexArray(0);
    f->glBindBuffer(GL_ARRAY_BUFFER, 0);

    if (m_blitProgram == 0) {
        fail(QStringLiteral("failed"), QStringLiteral("blit 程序创建失败"));
        return false;
    }
    return true;
}

void TextureHost::destroyBlitPipeline() {
    auto *f = m_glContext ? m_glContext->extraFunctions() : nullptr;
    if (f) {
        if (m_blitVbo) {
            f->glDeleteBuffers(1, &m_blitVbo);
            m_blitVbo = 0;
        }
        if (m_blitVao) {
            f->glDeleteVertexArrays(1, &m_blitVao);
            m_blitVao = 0;
        }
        if (m_blitProgram) {
            f->glDeleteProgram(m_blitProgram);
            m_blitProgram = 0;
        }
    }
    m_blitUvMatrixLocation = -1;
    m_blitTextureLocation = -1;
}

bool TextureHost::start(ANativeWindow *window, int width, int height, qreal devicePixelRatio) {
    if (!window) {
        fail(QStringLiteral("failed"), QStringLiteral("Surface 为空，拿不到 ANativeWindow"));
        return false;
    }
    if (m_phase == Phase::Ready) {
        release();
    }

    m_nativeWindow = window;
    m_width = width > 0 ? width : 1080;
    m_height = height > 0 ? height : 1920;
    m_dpr = devicePixelRatio > 0.0 ? devicePixelRatio : 1.0;
    m_frameSequence = 0;
    m_firstFrame = false;
    m_publishTimestampNanos = 0;
    m_lastStatusError.clear();
    m_status = QStringLiteral("ready");
    m_backend = QStringLiteral("none");

    if (!initGraphics(window)) {
        return false;
    }

    m_control = new QQuickRenderControl(this);
    m_window = new QQuickWindow(m_control);
    m_window->setColor(Qt::transparent);
    m_window->setFlags(Qt::Window | Qt::FramelessWindowHint);
    m_window->setGraphicsDevice(QQuickGraphicsDevice::fromOpenGLContext(m_glContext));
    m_window->setGeometry(0, 0, m_width, m_height);

    if (!m_control->initialize()) {
        fail(QStringLiteral("failed"), QStringLiteral("QQuickRenderControl::initialize 失败"));
        return false;
    }

    m_rhi = m_control->rhi();
    if (!m_rhi) {
        fail(QStringLiteral("failed"), QStringLiteral("QQuickRenderControl 未给出 QRhi"));
        return false;
    }
    if (m_rhi->backend() != QRhi::OpenGLES2) {
        // 计划要求记录"不可共享时的退出条件"：这里就是。宿主如果只接受 Vulkan，
        // 本宿主不静默降级，直接报 archBlocked 并带出实际后端名。
        fail(QStringLiteral("archBlocked"),
             QStringLiteral("QRhi 后端为 %1，本宿主仅支持 OpenGLES2 共享上下文")
                 .arg(QString::fromUtf8(m_rhi->backendName())));
        return false;
    }
    m_backend = QStringLiteral("opengl");

    if (!rebuildTarget(m_width, m_height)) {
        return false;
    }
    if (!loadScene()) {
        return false;
    }

    // blit 资源需要当前上下文；窗口表面此时已建好。
    if (!makeBlitCurrent()) {
        return false;
    }
    const bool pipelineReady = initBlitPipeline();
    doneBlitCurrent();
    if (!pipelineReady) {
        return false;
    }

    m_phase = Phase::Ready;
    m_status = QStringLiteral("ready");
    return true;
}

void TextureHost::resize(int width, int height, qreal devicePixelRatio) {
    if (m_phase != Phase::Ready) {
        return;
    }
    if (width <= 0 || height <= 0) {
        return;
    }
    m_dpr = devicePixelRatio > 0.0 ? devicePixelRatio : m_dpr;
    if (!rebuildTarget(width, height)) {
        return;
    }
    // 尺寸变了，GL 侧的拷贝纹理必须跟着重建（在 publishTexture 里按尺寸懒建）。
    m_width = width;
    m_height = height;
}

bool TextureHost::setRotation(int quarterTurns) {
    if (quarterTurns < 0) {
        quarterTurns = ((quarterTurns % 4) + 4) % 4;
    }
    m_rotation = quarterTurns % 4;
    return m_phase == Phase::Ready;
}

bool TextureHost::publishTexture() {
    auto *f = m_glContext ? m_glContext->extraFunctions() : nullptr;
    if (!f || !m_texture || m_blitProgram == 0) {
        return false;
    }

    const QSize pixelSize = m_texture->pixelSize();
    if (pixelSize.isEmpty()) {
        return false;
    }

    // 1. 用 RHI 纹理的 GL 名字自建 FBO 作读源，把像素拷进我们自己的纹理。
    //    不直接采样 RHI 纹理，是为了不和 RHI 的 DSA/采样状态纠缠（RHI 不保证
    //    帧末保留其纹理的采样参数）。
    const QRhiTexture::NativeTexture native = m_texture->nativeTexture();
    const GLuint sourceTexture = static_cast<GLuint>(native.object);
    if (sourceTexture == 0) {
        fail(QStringLiteral("failed"), QStringLiteral("RHI 纹理没有可用的 GL 名字"));
        return false;
    }

    if (m_copyTexture == 0 || m_copySize != pixelSize) {
        if (m_copyTexture != 0) {
            f->glDeleteTextures(1, &m_copyTexture);
            m_copyTexture = 0;
        }
        f->glGenTextures(1, &m_copyTexture);
        f->glBindTexture(GL_TEXTURE_2D, m_copyTexture);
        f->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        f->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        f->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        f->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        f->glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8, pixelSize.width(), pixelSize.height());
        f->glBindTexture(GL_TEXTURE_2D, 0);
        m_copySize = pixelSize;
    }

    if (m_copyFbo == 0) {
        f->glGenFramebuffers(1, &m_copyFbo);
    }

    f->glBindFramebuffer(GL_FRAMEBUFFER, m_copyFbo);
    f->glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, sourceTexture, 0);
    const GLenum fboStatus = f->glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (fboStatus != GL_FRAMEBUFFER_COMPLETE) {
        f->glBindFramebuffer(GL_FRAMEBUFFER, 0);
        fail(QStringLiteral("failed"),
             QStringLiteral("RHI 纹理挂到 FBO 后不完整，status=0x%1")
                 .arg(static_cast<uint>(fboStatus), 0, 16));
        return false;
    }

    f->glBindTexture(GL_TEXTURE_2D, m_copyTexture);
    f->glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, pixelSize.width(), pixelSize.height());
    f->glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // 2. 画到窗口表面（默认帧缓冲）。
    f->glBindFramebuffer(GL_FRAMEBUFFER, 0);
    f->glViewport(0, 0, m_width, m_height);
    f->glDisable(GL_BLEND);
    f->glDisable(GL_DEPTH_TEST);
    f->glDisable(GL_CULL_FACE);
    f->glClearColor(0.f, 0.f, 0.f, 1.f);
    f->glClear(GL_COLOR_BUFFER_BIT);

    f->glUseProgram(m_blitProgram);
    f->glActiveTexture(GL_TEXTURE0);
    f->glBindTexture(GL_TEXTURE_2D, m_copyTexture);
    if (m_blitTextureLocation >= 0) {
        f->glUniform1i(m_blitTextureLocation, 0);
    }
    if (m_blitUvMatrixLocation >= 0) {
        f->glUniformMatrix3fv(m_blitUvMatrixLocation, 1, GL_FALSE, kUvMatrices[m_rotation % 4]);
    }
    f->glBindVertexArray(m_blitVao);
    f->glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    f->glBindVertexArray(0);
    f->glUseProgram(0);

    const quint64 publishNanos = monotonicNanos();

    // 3. 时间戳 + present。Android 上 SurfaceTexture 的时间戳来自 eglPresentationTimeANDROID；
    //    不支持该扩展时退回"发布时刻的单调钟"，并在契约里说明这是宿主侧时钟。
    auto presentationTime = reinterpret_cast<PFNEGLPRESENTATIONTIMEANDROIDPROC>(
        eglGetProcAddress("eglPresentationTimeANDROID"));
    if (presentationTime) {
        presentationTime(static_cast<EGLDisplay>(m_eglDisplay),
                         static_cast<EGLSurface>(m_eglSurface),
                         static_cast<khronos_stime_nanoseconds_t>(publishNanos));
    }

    if (eglSwapBuffers(static_cast<EGLDisplay>(m_eglDisplay),
                       static_cast<EGLSurface>(m_eglSurface)) != EGL_TRUE) {
        fail(QStringLiteral("failed"),
             QStringLiteral("eglSwapBuffers 失败，EGL error=0x%1")
                 .arg(static_cast<int>(eglGetError()), 0, 16));
        return false;
    }

    if (!m_firstFrame) {
        m_firstFrame = true;
    }
    m_publishTimestampNanos = publishNanos;
    return true;
}

TextureHost::Report TextureHost::renderFrame(qint64 frameTimeNanos) {
    Q_UNUSED(frameTimeNanos);
    Report snapshot = report();
    if (m_phase != Phase::Ready) {
        return snapshot;
    }

    // Qt 侧的渲染序列与 SceneLayerHost 保持一致：polish → beginFrame → sync → render → endFrame。
    m_control->polishItems();
    m_control->beginFrame();
    if (!m_control->commandBuffer()) {
        fail(QStringLiteral("failed"),
             QStringLiteral("beginFrame 后没有 commandBuffer，RHI 未就绪"));
        return report();
    }
    const bool synced = m_control->sync();
    m_control->render();
    m_control->endFrame();

    if (!synced) {
        fail(QStringLiteral("failed"), QStringLiteral("QQuickRenderControl::sync 失败"));
        return report();
    }

    if (!makeBlitCurrent()) {
        return report();
    }
    const bool published = publishTexture();
    doneBlitCurrent();

    if (!published) {
        return report();
    }

    ++m_frameSequence;
    snapshot = report();
    snapshot.rendered = true;
    snapshot.frameSequence = m_frameSequence;
    snapshot.publishTimestampNanos = m_publishTimestampNanos;
    return snapshot;
}

void TextureHost::destroyGraphics() {
    if (!m_glContext) {
        return;
    }
    if (makeBlitCurrent()) {
        destroyBlitPipeline();
        if (m_copyTexture != 0) {
            auto *f = m_glContext->extraFunctions();
            if (f) {
                f->glDeleteTextures(1, &m_copyTexture);
                f->glDeleteFramebuffers(1, &m_copyFbo);
            }
            m_copyTexture = 0;
            m_copyFbo = 0;
            m_copySize = QSize();
        }
        doneBlitCurrent();
    }

    if (m_rhi) {
        m_rhi->finish();
    }
    delete m_renderTarget;
    m_renderTarget = nullptr;
    delete m_renderPass;
    m_renderPass = nullptr;
    delete m_texture;
    m_texture = nullptr;

    if (m_control) {
        m_control->invalidate();
    }

    if (m_eglDisplay && m_eglSurface) {
        eglDestroySurface(static_cast<EGLDisplay>(m_eglDisplay),
                          static_cast<EGLSurface>(m_eglSurface));
    }
    m_eglSurface = nullptr;
    m_eglConfig = nullptr;
    m_eglContext = nullptr;
    m_eglDisplay = nullptr;

    if (m_glContext) {
        m_glContext->doneCurrent();
        delete m_glContext;
        m_glContext = nullptr;
    }
    m_nativeWindow = nullptr;
    m_rhi = nullptr;
}

void TextureHost::release() {
    if (m_phase == Phase::Released) {
        return;
    }
    if (m_phase == Phase::Ready || m_phase == Phase::Failed) {
        destroyGraphics();
    }
    // 根 item 挂在 window 的 contentItem 下，窗口析构会连带删掉；先显式删并置空，
    // 避免析构函数里二次 delete。
    delete m_rootItem;
    m_rootItem = nullptr;
    delete m_window;
    m_window = nullptr;
    delete m_control;
    m_control = nullptr;
    m_phase = Phase::Released;
    m_status = QStringLiteral("released");
    m_backend = QStringLiteral("none");
}

bool TextureHost::sendPointer(qreal x, qreal y, int phase, int buttons) {
    if (m_phase != Phase::Ready || !m_window) {
        return false;
    }
    QEvent::Type type = QEvent::MouseMove;
    if (phase == 0) {
        type = QEvent::MouseButtonPress;
    } else if (phase == 2) {
        type = QEvent::MouseButtonRelease;
    }

    Qt::MouseButtons qtButtons = Qt::NoButton;
    if (buttons & 0x00000001) { // AMOTION_EVENT_BUTTON_PRIMARY
        qtButtons |= Qt::LeftButton;
    }
    if (buttons & 0x00000002) { // AMOTION_EVENT_BUTTON_SECONDARY
        qtButtons |= Qt::RightButton;
    }
    if (buttons & 0x00000004) { // AMOTION_EVENT_BUTTON_TERTIARY
        qtButtons |= Qt::MiddleButton;
    }

    Qt::MouseButton button = Qt::LeftButton;
    if (type == QEvent::MouseMove && qtButtons == Qt::NoButton) {
        button = Qt::NoButton;
    } else if (!(qtButtons & Qt::LeftButton)) {
        button = qtButtons & Qt::RightButton ? Qt::RightButton : Qt::LeftButton;
    }

    const QPointF local(x, y);
    QMouseEvent event(type, local, m_window->mapToGlobal(local.toPoint()), button, qtButtons,
                      Qt::NoModifier, QPointingDevice::primaryPointingDevice());
    QCoreApplication::sendEvent(m_window, &event);
    return event.isAccepted();
}

bool TextureHost::sendKey(int key, bool down, bool repeat) {
    if (m_phase != Phase::Ready || !m_window) {
        return false;
    }

    // 只映射离屏宿主真正需要的几个 Android keyCode；其余交给宿主适配层（T16 接线）。
    // 映射不到就返回 false，不做"随便按一个键"的假装成功。
    Qt::Key qtKey = Qt::Key_unknown;
    switch (key) {
    case 4: // KEYCODE_BACK
        qtKey = Qt::Key_Back;
        break;
    case 3: // KEYCODE_HOME
        qtKey = Qt::Key_Home;
        break;
    case 24: // KEYCODE_VOLUME_UP
        qtKey = Qt::Key_VolumeUp;
        break;
    case 25: // KEYCODE_VOLUME_DOWN
        qtKey = Qt::Key_VolumeDown;
        break;
    case 26: // KEYCODE_POWER
        qtKey = Qt::Key_PowerOff;
        break;
    case 82: // KEYCODE_MENU
        qtKey = Qt::Key_Menu;
        break;
    default:
        break;
    }

    if (qtKey == Qt::Key_unknown) {
        m_lastStatusError = QStringLiteral("未映射的 Android keyCode=%1").arg(key);
        return false;
    }

    QKeyEvent event(down ? QEvent::KeyPress : QEvent::KeyRelease, qtKey, Qt::NoModifier,
                    QString(), repeat);
    QCoreApplication::sendEvent(m_window, &event);
    return event.isAccepted();
}

// ---------------------------------------------------------------------------
// JNI 入口：供 rhine.music.database.porting.TextureBridge 的 companion 方法调用。
// 句柄表用进程内 QMutex 保护；所有调用都假设在 Kotlin 的单一 HandlerThread 上。
// ---------------------------------------------------------------------------

namespace {

struct Entry {
    TextureHost *host = nullptr;
    ANativeWindow *window = nullptr;
};

struct Registry {
    QMutex mutex;
    QHash<jlong, Entry> entries;
    std::atomic<jlong> nextHandle{1};
};

Registry &registry() {
    static Registry r;
    return r;
}

TextureHost *lookupHost(jlong handle) {
    QMutexLocker locker(&registry().mutex);
    const auto it = registry().entries.constFind(handle);
    if (it == registry().entries.constEnd()) {
        return nullptr;
    }
    return it->host;
}

jstring toJString(JNIEnv *env, const QString &text) {
    // 不直接 NewStringUTF：错误消息里有中文，Java 侧期望的是 UTF-16。
    const QByteArray utf16(reinterpret_cast<const char *>(text.utf16()),
                           text.size() * 2);
    return env->NewString(reinterpret_cast<const jchar *>(utf16.constData()), text.size());
}

QString jsonString(const QByteArray &json) {
    return QString::fromUtf8(json);
}

QString staticProbeJson() {
    const bool guiReady = QGuiApplication::instance() != nullptr;
    QJsonObject obj;
    obj.insert(QStringLiteral("status"),
               guiReady ? QStringLiteral("ready") : QStringLiteral("archBlocked"));
    obj.insert(QStringLiteral("backend"),
               guiReady ? QStringLiteral("opengl") : QStringLiteral("none"));
    obj.insert(QStringLiteral("protocolVersion"), 1);
    obj.insert(QStringLiteral("reason"),
               guiReady ? QStringLiteral("native host 可用；create() 决定实际 GL 能力")
                        : QStringLiteral("进程内没有 QGuiApplication，Qt Quick 无法渲染"));
    return jsonString(QJsonDocument(obj).toJson(QJsonDocument::Compact));
}

} // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeProbe(JNIEnv *env, jclass) {
    return toJString(env, staticProbeJson());
}

JNIEXPORT jlong JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeCreate(JNIEnv *env, jclass, jobject surface,
                                                             jint width, jint height, jfloat dpr) {
    if (!surface) {
        return 0;
    }
    ANativeWindow *window = ANativeWindow_fromSurface(env, surface);
    if (!window) {
        return 0;
    }

    auto *host = new TextureHost(nullptr);
    host->start(window, width, height, static_cast<qreal>(dpr));

    const jlong handle = registry().nextHandle.fetch_add(1);
    {
        QMutexLocker locker(&registry().mutex);
        Entry entry;
        entry.host = host;
        entry.window = window;
        registry().entries.insert(handle, entry);
    }
    return handle;
}

JNIEXPORT void JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeResize(JNIEnv *, jclass, jlong handle,
                                                             jint width, jint height, jfloat dpr) {
    if (auto *host = lookupHost(handle)) {
        host->resize(width, height, static_cast<qreal>(dpr));
    }
}

JNIEXPORT jboolean JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeSetRotation(JNIEnv *, jclass, jlong handle,
                                                                  jint quarterTurns) {
    if (auto *host = lookupHost(handle)) {
        return host->setRotation(quarterTurns) ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeRender(JNIEnv *env, jclass, jlong handle,
                                                             jlong frameTimeNanos) {
    auto *host = lookupHost(handle);
    if (!host) {
        return env->NewStringUTF("{\"rendered\":false,\"status\":\"failed\","
                                 "\"lastError\":\"handle 不存在\",\"backend\":\"none\"}");
    }
    const TextureHost::Report report = host->renderFrame(static_cast<qint64>(frameTimeNanos));
    return toJString(env, jsonString(report.toJson()));
}

JNIEXPORT jstring JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeStatus(JNIEnv *env, jclass, jlong handle) {
    auto *host = lookupHost(handle);
    if (!host) {
        return env->NewStringUTF("{\"rendered\":false,\"status\":\"failed\","
                                 "\"lastError\":\"handle 不存在\",\"backend\":\"none\"}");
    }
    const TextureHost::Report report = host->report();
    return toJString(env, jsonString(report.toJson()));
}

JNIEXPORT jboolean JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeSendPointer(JNIEnv *, jclass, jlong handle,
                                                                  jfloat x, jfloat y, jint phase,
                                                                  jint buttons) {
    if (auto *host = lookupHost(handle)) {
        return host->sendPointer(x, y, phase, buttons) ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeSendKey(JNIEnv *, jclass, jlong handle,
                                                              jint key, jboolean down,
                                                              jboolean repeat) {
    if (auto *host = lookupHost(handle)) {
        return host->sendKey(key, down == JNI_TRUE, repeat == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_rhine_music_database_porting_TextureBridge_nativeDestroy(JNIEnv *, jclass, jlong handle) {
    Entry entry;
    {
        QMutexLocker locker(&registry().mutex);
        const auto it = registry().entries.find(handle);
        if (it == registry().entries.end()) {
            return;
        }
        entry = it.value();
        registry().entries.erase(it);
    }
    if (entry.host) {
        entry.host->release();
        delete entry.host;
    }
    if (entry.window) {
        ANativeWindow_release(entry.window);
    }
}

} // extern "C"
