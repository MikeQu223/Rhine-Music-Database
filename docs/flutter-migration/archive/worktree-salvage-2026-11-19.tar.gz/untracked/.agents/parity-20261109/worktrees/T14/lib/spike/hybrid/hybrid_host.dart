// T14 候选 D「混合切片」——Dart 侧宿主：HUD 由 Dart 自绘，3D 由 Qt 供给为一张纹理。
//
// 契约来源（不可改；plan = docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md）：
// * 层序（plan:180）：3D → HUD → modal 遮罩 → hits 透明层 → chrome → 性能面板；HUD 绝不烘焙进 3D 纹理。
// * stage（plan:178）：stageScale = heightLogical/1080；stageWidth = widthLogical/stageScale；
//   旋转/尺寸变化只重算 stage，绝不重建引擎状态。
// * frame（NativeSceneFrame.cpp:87-119 的 31 个字面键；:164-166、:195 追加 actorTemplate/
//   appearanceRevision/actors/stats ⇒ 写入 35）；成功 expand 后 NativeCards.cpp:236-237（非 Darwin
//   同构 :303-304）主动 remove actorTemplate/actors ⇒ 交付 33；校验失败提前返回（:160-162 / :253-255）
//   尚未 remove ⇒ 该帧交付 35。**交付键数路径依赖、不是常量**：消费者禁止假定固定键数，未知键原样透传。
//   QJsonObject 序列化按键排序，只有成员集合是协议事实。
// * commands（plan:185-205、Glyphs.cpp:637-825）：Qt 原样 flat array，a[0]=op，17 个 op：
//   save|restore|alpha|translate|scale|rotate|clip|fill|ellipse|text|art|fill-path|path|arc|
//   right-mask|gradient|image；没有 z、没有 frameId、不是 {id,opcode,args,seq}；本文件原样透传。
// * hits（NativeHud.cpp:102-109；PlayerBar.cpp:46-53）：必需 {x,y,width,height,action,label}，
//   只有 PlayerBar 的 hit 额外带 fixed:true；同一次 draw pass 产出、按源顺序消费、矩形为 stage 坐标。
// * 发布（plan:213）：commands/hits/frame 同一状态代次发布；generation 只做一致性校验，不得去重；
//   measure/hit/IME 共用同一套 layout geometry（本文件对三者只暴露一个 stage）。
// * 颜色（Glyphs.cpp:35-49、NativeHud.cpp:10-15）：RGBA 数组 + 可选第 5 项 calibrated 前缀，Gamma 1.8 → sRGB。
// * Fail 条件（plan:489-495）：两套状态双写同一帧必须显式失败——见 HybridHost.doubleWriteDetected。
//
// **本地适配概念，不是 Qt wire 事实**：envelope（generation/frame/commands/hits/state）与 generation
// 都是候选 D 新引入的本地包装（plan:147 要求标注为拟议）；Qt 侧没有 generation 键，NativeHud.h:74-76
// 只公开 commands/hits/frame。
//
// 自包含：只依赖 dart:math；不 import lib/hud/protocol/*（T30 树）或 lib/hud/text/*（T31 树）——
// 两棵树在本 worktree 不存在；接入点一律走下面的可注入 port（由 T30/T31/T12 实现后注入）。
import 'dart:math' as math;

/// 本地适配 envelope 的成员名，顺序即语义顺序。
///
/// **不是 Qt wire 事实**：Qt 只 emit 顶层 frame（NativeSceneFrame.cpp:56-213）并公开
/// commands/hits/frame（NativeHud.h:74-76）。envelope 存在的唯一理由是 plan:213
/// 「commands/hits/frame 必须同一状态代次发布」——绑在一个 generation 下才能整体丢弃错帧快照。
const List<String> kHybridEnvelopeFields = <String>[
  'generation', 'frame', 'commands', 'hits', 'state',
];

/// `NativeScene::emitFrame` 按 emit 顺序写出的 31 个字面键（NativeSceneFrame.cpp:87-119）。
///
/// 顺序不是协议事实（QJsonObject 序列化按键排序），集合成员才是；值语义见 plan:212（Flutter 只读）。
const List<String> kQtLiteralFrameKeys = <String>[
  'pendingAnimations', 'pointerCursor', 'aoProjection', 'reference',
  'near', 'far', 'viewer', 'viewerReady',
  'viewerState', 'mode', 'selected', 'culledCards',
  'shadowCards', 'returningCards', 'returningPartNodes', 'globalSubdued',
  'returningMusicKeys', 'returningAgeMax', 'time', 'draws',
  'view', 'projection', 'eye', 'background',
  'fogColor', 'fogNear', 'fogFar', 'detail',
  'boot', 'focus', 'aperture',
];

/// `emitFrame` 在 31 个字面键之后继续追加的键（NativeSceneFrame.cpp:164-166、:195）；
/// culledCards/shadowCards 在 :162-163 被覆写，键本身已在字面键表里。
const List<String> kQtFrameKeysAddedAfterLiterals = <String>[
  'actorTemplate', 'appearanceRevision', 'actors', 'stats',
];

/// 交付顶层键的**源镜像子集** = 31 字面键 + `appearanceRevision` + `stats`；常量本身保留。
///
/// 命名裁决（T14-C18-CONTRACT frameKeysAdjudication.**threeLayerMechanism_v3**，逐条服从；
/// 它 supersedes 旧 frozenRuling 与 frozenRuling_v2——更早口径把 33 说成「漏计」，正是 A2 推翻、
/// Lead 独立复核的错误归因）：
/// * **写入点是 35 个顶层键**：31 个字面键在 NativeSceneFrame.cpp:87-119（其中 culledCards/
///   shadowCards 在 :162-163 被覆写，键已在 31 内），随后 :164 actorTemplate、:165 appearanceRevision、
///   :166 actors，最后 :195 stats。
/// * **交付集是路径依赖的，不是常量**：成功 expand 路径在 NativeCards.cpp:236-237（非 Darwin 同构
///   :303-304）主动 `frame.remove("actorTemplate")` + `frame.remove("actors")` ⇒ 交付 **33** 键；
///   而 NativeCards.cpp:160-162（非 Darwin :253-255）在 parts 为空或字节校验失败时提前 return，
///   尚未执行 remove ⇒ 该帧仍交付 **35** 键。
/// * 因此本表只能表述为「**成功 expand 路径的交付集**」：绝不得写成「共享契约冻结」「固定 33」
///   或「固定 35」。消费者禁止假定固定键数，未知键必须原样透传（plan:212：字段清单由 T03 从
///   RhiScene/Engine 冻结，本节不枚举）；本文件只做源镜像，差异已上报 T10/T16，不得自行改契约。
///
/// 用展开表达式是为了保证与 [kQtLiteralFrameKeys] 永远一致；本表刻意不含
/// actorTemplate/actors，正是替「成功路径把它们 remove 掉」留痕：不要在本地补齐去冒充 35，
/// 也不要删表去冒充「键数无所谓」。
const List<String> kQtDeliveredFrameKeys = <String>[
  ...kQtLiteralFrameKeys,
  'appearanceRevision',
  'stats',
];

/// 本地适配 envelope 的协议错误（缺成员 / 类型错 / 非 String 键）；属新设计（plan:147）。
class HybridProtocolException implements Exception {
  /// 人类可读的失败原因，含出错的成员名与实际类型。
  const HybridProtocolException(this.message);

  /// 失败原因文本。
  final String message;

  @override
  String toString() => 'HybridProtocolException: $message';
}

/// 一次发布的状态代次快照：frame / commands / hits / state 四件套必须同时存在（plan:213）。
///
/// **全有或全无**：commands/hits/state 即使为空也必须出现，因为一次 draw pass 同时产出三者；
/// 任一成员缺失或类型错都由 [decode] 抛 [HybridProtocolException]，绝不半份套用。
class HybridFrameEnvelope {
  /// 直接构造（调用方已自行校验时用）；协议校验走 [decode]。
  const HybridFrameEnvelope({
    required this.generation,
    required this.frame,
    required this.commands,
    required this.hits,
    required this.state,
  });

  /// 本地适配代次号（**不是 Qt wire 键**）；用于一致性校验与整体丢弃。
  final int generation;

  /// 3D 与 HUD 共享的一份渲染帧（plan:212），只读。
  final Map<String, Object?> frame;

  /// Qt 原样 flat command 数组，a[0]=op（plan:185-205）。
  final List<Object?> commands;

  /// hit 原始项数组，顺序即绘制顺序（plan:211）。
  final List<Object?> hits;

  /// 本地适配状态袋（**不是 Qt wire 键**）；供 measure/hit/IME 共用几何时读取。
  final Map<String, Object?> state;

  /// 严格解码，全有或全无：缺任一成员、成员类型不对或 map 含非 String 键即抛
  /// [HybridProtocolException]。`generation` 必须是 `int`（JSON 整数）；`num` 但非 `int`
  /// （如 `1.0`）按类型错拒绝。
  static HybridFrameEnvelope decode(Map<String, Object?> raw) {
    if (!raw.containsKey('generation')) {
      throw const HybridProtocolException('missing generation');
    }
    final Object? generation = raw['generation'];
    if (generation is! int) {
      throw HybridProtocolException(
        'generation must be int, got ${_describe(generation)}',
      );
    }
    return HybridFrameEnvelope(
      generation: generation,
      frame: _requireMap(raw, 'frame'),
      commands: _requireList(raw, 'commands'),
      hits: _requireList(raw, 'hits'),
      state: _requireMap(raw, 'state'),
    );
  }

  /// [decode] 的宽松版本：协议错返回 null，不抛。
  static HybridFrameEnvelope? tryDecode(Map<String, Object?> raw) {
    try {
      return decode(raw);
    } on HybridProtocolException {
      return null;
    }
  }

  @override
  String toString() =>
      'HybridFrameEnvelope(generation: $generation, commands: ${commands.length}, '
      'hits: ${hits.length}, frameKeys: ${frame.length}, stateKeys: ${state.length})';
}

/// 代次闸门：**非更新的快照整体丢弃，绝不合并**（plan:213：新 generation 只能做一致性校验）。
class HybridFrameGate {
  /// 最近一次真正套用的代次；null 表示尚未套用任何代次。
  int? appliedGeneration;

  /// 是否应套用：仅当代次严格大于已套用代次（或尚无已套用代次）时为 true。
  bool shouldApply(int generation) {
    final int? applied = appliedGeneration;
    return applied == null || generation > applied;
  }

  /// 记账一次套用；调用方必须先通过 [shouldApply]。
  void markApplied(int generation) {
    appliedGeneration = generation;
  }
}

/// stage 几何：stage 坐标（1080 高归一化）与逻辑坐标之间的唯一换算（plan:178）。
///
/// 横屏 `scale = heightLogical/1080`、`width = widthLogical/scale`、`height = heightLogical/scale`；
/// 竖屏（plan:179）把 LayoutBuilder + 安全区 + IME 算出的同一 geometry 喂进 [fromLogicalSize]，
/// 不按设备类型分支、不另起竖屏公式。measure/hit/IME 必须共用同一个 stage 实例（plan:213）。
class HybridStage {
  /// 以已算好的三个值直接构造（供反序列化/测试）；常规路径用 [fromLogicalSize]。
  const HybridStage({
    required this.scale,
    required this.width,
    required this.height,
  });

  /// 逻辑像素 → stage 像素的换算因子（= heightLogical/1080）。
  final double scale;

  /// stage 宽度 = widthLogical/scale。
  final double width;

  /// stage 高度 = heightLogical/scale。
  final double height;

  /// 由逻辑尺寸推导 stage，逐字对齐 Qt/qml/Overlay.qml:22-23：
  /// `stageScale: height > 0 ? height / 1080 : 1`、`stageWidth: width / stageScale`。
  ///
  /// **不对输入做前置夹取**。Qt 的 `std::max(1.0, width/height)` 在
  /// Qt/src/NativeScene.cpp:219-220，属**引擎 resize** 层（只改 m_width/m_height、
  /// 重算 perspective 与 viewer 尺寸），与 stage 公式层（Overlay.qml:22-23）是两层。
  /// 把引擎夹取混进 stage 会让 `height <= 0` 得到 `scale = 1/1080 ≈ 0.000926`，
  /// 而 Qt 的 Overlay 给 1——这正是本卡 must-fix 指出的错源。
  ///
  /// 退化输入按源公式直译（不额外消毒）：`(0, 0)` ⇒ `scale 1.0 / width 0.0 /
  /// height 0.0`；NaN 高度同样走 `> 0` 的 false 分支得 `scale 1.0`，此时 **height 字段为 NaN**
/// （`width` 只在 logicalWidth 自身为 NaN 时才为 NaN）。
  factory HybridStage.fromLogicalSize(double logicalWidth, double logicalHeight) {
    final double scale =
        logicalHeight > 0 ? logicalHeight / _kStageReferenceHeight : 1.0;
    return HybridStage(
      scale: scale,
      width: logicalWidth / scale,
      height: logicalHeight / scale,
    );
  }

  /// 3D 引擎侧的 HUD 宽度（stage 宽度），即 plan:178 的 stageWidth。
  static double engineHudWidth(double logicalWidth, double logicalHeight) =>
      HybridStage.fromLogicalSize(logicalWidth, logicalHeight).width;

  @override
  String toString() => 'HybridStage(scale: $scale, width: $width, height: $height)';
}

/// stage 归一化参考高度（plan:178：`stageScale = heightLogical/1080`）。
const double _kStageReferenceHeight = 1080.0;

/// 首个 [HybridHost.resizeLogical] 之前的占位逻辑边长（正方形 ⇒ scale 1、stage 1080×1080）；
/// 真实几何必须由 layout 喂入。
const double _kPlaceholderLogicalSize = 1080.0;

/// Android 触摸层外扩量（stage 像素）——**只是 Android 侧的数值**，不是通用常量。
///
/// Qt 源事实是平台门控的三元式：Qt/qml/Overlay.qml:38
/// `touchHitPadding: android ? 16 : 0`，随后 :40-43 的 `hitArea()` 逐值外扩
/// （`x-pad, y-pad, w+2*pad, h+2*pad`）。所以平台门在**消费侧**：桌面/iOS 必须按 0 处理，
/// 只有 Android 触摸命中层取本常量。
///
/// **只在消费侧使用**：外扩绝不写回源矩形、不改变源顺序、不改 hit 的 wire 形态
/// （plan:211 明确禁止把触摸层扩张写回源矩形）。
const double kHybridTouchPadding = 16.0;

/// 一条命中矩形：{x,y,width,height,action,label}（NativeHud.cpp:102-109），
/// 仅 PlayerBar 额外带 `fixed:true`（PlayerBar.cpp:46-53）。
class HybridHit {
  /// 构造一条命中；`fixed` 缺省 false，只有 PlayerBar 的 hit 传 true。
  const HybridHit({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.action,
    required this.label,
    this.fixed = false,
  });

  /// stage 坐标矩形左上角 x。
  final double x;

  /// stage 坐标矩形左上角 y。
  final double y;

  /// stage 坐标矩形宽。
  final double width;

  /// stage 坐标矩形高。
  final double height;

  /// 派发动作名。
  final String action;

  /// 展示用 label；源缺失/为 null/非字符串时回落为 [action]（NativeHud.cpp:108
  /// `label.isNull() ? action : label`），显式空串原样保留。
  final String label;

  /// 是否带 PlayerBar 的 `fixed:true`（modalOffset 只推非 fixed hits，plan:180）。
  final bool fixed;

  /// 按源顺序解码 hits：几何不可用（缺 x/y/width/height、非 num、NaN/±Infinity）或 `action`
  /// 缺失/非字符串 ⇒ **整项丢弃**；`label` 缺失/null/非字符串 ⇒ 回落 [action]，显式 `""` 保留；
  /// `fixed` 仅字面 `true` 置位。不重排、不去重、不 clamp、不外扩（外扩只属消费侧）。
  static List<HybridHit> decode(List<Object?> raw) {
    final List<HybridHit> result = <HybridHit>[];
    for (final Object? item in raw) {
      if (item is! Map) continue;
      final double? x = _finiteDouble(item['x']);
      final double? y = _finiteDouble(item['y']);
      final double? width = _finiteDouble(item['width']);
      final double? height = _finiteDouble(item['height']);
      if (x == null || y == null || width == null || height == null) continue;
      final Object? action = item['action'];
      if (action is! String) continue;
      final Object? label = item['label'];
      result.add(
        HybridHit(
          x: x,
          y: y,
          width: width,
          height: height,
          action: action,
          label: label is String ? label : action,
          fixed: item['fixed'] == true,
        ),
      );
    }
    return result;
  }

  /// 回到 wire 形态：键顺序恒为 x,y,width,height,action,label，`fixed` 仅 true 时输出
  /// （NativeHud.cpp:103-108 的键集 + PlayerBar.cpp:47-53 的 fixed）。
  Map<String, Object?> toJson() {
    final Map<String, Object?> json = <String, Object?>{
      'x': x,
      'y': y,
      'width': width,
      'height': height,
      'action': action,
      'label': label,
    };
    if (fixed) json['fixed'] = true;
    return json;
  }

  @override
  String toString() =>
      'HybridHit($x, $y, $width, $height, $action, $label${fixed ? ", fixed" : ""})';
}

/// 原 calibrated 颜色使用的 Gamma（Glyphs.cpp:43 `std::pow(value, 1.8)`；
/// NativeHud.cpp:10-15 的 calibratedWhite/calibratedRGB 标记）。
const double kHybridCalibratedGamma = 1.8;

/// 线性 → sRGB 编码（Glyphs.cpp:44）：
/// `linear <= 0.0031308 ? 12.92*linear : 1.055*pow(linear, 1/2.4) - 0.055`。
double hybridSrgbEncode(double linear) {
  if (linear <= 0.0031308) return 12.92 * linear;
  return 1.055 * math.pow(linear, 1 / 2.4).toDouble() - 0.055;
}

/// 单个 calibrated 通道：先幂回线性，再做 sRGB 编码。
double hybridCalibratedChannel(double value) =>
    hybridSrgbEncode(math.pow(value, kHybridCalibratedGamma).toDouble());

/// RGBA 颜色（通道 0..1）；解码逐条对齐 Qt `color()`（Glyphs.cpp:35-49）。
class HybridColor {
  /// 直接构造。
  const HybridColor({
    required this.r,
    required this.g,
    required this.b,
    required this.a,
  });

  /// 红通道。
  final double r;

  /// 绿通道。
  final double g;

  /// 蓝通道。
  final double b;

  /// alpha 通道。
  final double a;

  /// 解码命令里的颜色项（Glyphs.cpp:35-49）：非数组 ⇒ 不透明黑 `(0,0,0,1)`；前三个通道非数字
  /// ⇒ `0.0`；第 4 元素缺失 ⇒ `1.0`、存在但非数字 ⇒ `0.0`（与 Qt 退化行为一致：NativeHud.cpp:10-15
  /// 的数组恒为长度 4，Glyphs.cpp:48 直接取 `a[3].toDouble()`）；第 5 项为 `calibrated` 前缀字符串时
  /// **只对 rgb** 做 Gamma 1.8 → sRGB（alpha 不参与，Glyphs.cpp:39-47 的 `channel` 只作用于下标 0..2）。
  static HybridColor decode(Object? raw) {
    if (raw is! List) {
      return const HybridColor(r: 0, g: 0, b: 0, a: 1);
    }
    final List<Object?> values = List<Object?>.from(raw);
    final bool calibrated = values.length > 4 &&
        values[4] is String &&
        (values[4] as String).startsWith('calibrated');
    double channel(int index) {
      final double value = index < values.length ? _rawDouble(values[index]) : 0.0;
      return calibrated ? hybridCalibratedChannel(value) : value;
    }

    return HybridColor(
      r: channel(0),
      g: channel(1),
      b: channel(2),
      a: values.length > 3 ? _rawDouble(values[3]) : 1.0,
    );
  }

  /// 回到 wire 形态的 RGBA 数组（不含 calibrated 标记；标记只在源头写入）。
  List<double> toJson() => <double>[r, g, b, a];

  @override
  String toString() => 'HybridColor($r, $g, $b, $a)';
}

/// 交给 Qt 纹理侧的几何快照：逻辑尺寸 + stage 尺寸 + 缩放 + 设备像素比。
///
/// 本地适配概念（不是 Qt wire 事实）；宿主 attach 时一次性交给 [HybridTexturePort]。
class HybridSurfaceGeometry {
  /// 直接构造。
  const HybridSurfaceGeometry({
    required this.logicalWidth,
    required this.logicalHeight,
    required this.stageWidth,
    required this.stageHeight,
    required this.scale,
    required this.devicePixelRatio,
  });

  /// 逻辑（Flutter 逻辑像素）宽度。
  final double logicalWidth;

  /// 逻辑高度。
  final double logicalHeight;

  /// stage 宽度（= widthLogical/scale）。
  final double stageWidth;

  /// stage 高度（= heightLogical/scale）。
  final double stageHeight;

  /// 逻辑 → stage 换算因子。
  final double scale;

  /// 设备像素比；只影响纹理分配，绝不参与 stage 换算。
  final double devicePixelRatio;

  @override
  String toString() => 'HybridSurfaceGeometry($logicalWidth x $logicalHeight, '
      'stage ${stageWidth}x$stageHeight, scale $scale, dpr $devicePixelRatio)';
}

/// Qt 3D 纹理侧（将来由 Qt/porting/HybridTextureHost.h/.cpp 与 T12 的 TextureHost 实现并注入）。
///
/// **绝不反向写入 Dart HUD 状态**：该 port 只接收几何/旋转/生命周期动作，Dart 侧 commands/hits/stage
/// 恒由本文件的宿主持有。`generation` 由**端口实现方内部自行维护**，宿主只读（无 setter、
/// 也没有任何反向推进入口）——若宿主能推进 Qt 代次，「两套状态双写同一帧」就再也测不出来，
/// 会掩盖 plan:489-495 的错帧 Fail 条件。
abstract interface class HybridTexturePort {
  /// Qt 侧当前可用的纹理代次；宿主用它和 envelope 的 generation 比对以发现双写。
  ///
  /// 只读：代次由端口实现方（T12 的 HybridTextureHost）在产出新帧时**内部**维护；
  /// 本 port 不提供 `advance`/`setGeneration` 一类入口，宿主永远无法自证一致。
  int get generation;

  /// 附着纹理并接收首次几何（宿主构造时调用）。
  void attach(HybridSurfaceGeometry geometry);

  /// 逻辑尺寸变化：只重分配/重设视口，**不得重建引擎状态**（NativeScene.cpp:217-224）。
  void resize(double logicalWidth, double logicalHeight);

  /// 旋转纹理呈现（弧度）；不改 stage 尺寸。
  void rotate(double radians);

  /// 解除附着（宿主回退到纯 Dart HUD 时调用），之后不得再收到 resize/rotate。
  void detach();
}

/// Dart HUD 命令绘制器（将来由 T31 glyph 引擎实现并注入；该树不在本 worktree）。
///
/// 契约：命令按源顺序逐条消费，不得排序、不得去重、不得改写参数（plan:213），坐标系恒为 [HybridStage]。
abstract interface class HybridHudCommandPainter {
  /// 绘制一帧命令；`commands` 就是 envelope 里那一份，顺序即 Qt 产出顺序。
  void paint(List<Object?> commands, HybridStage stage);
}

/// 宿主时钟（可注入，测试用假时钟）。3D 与 HUD 共享同一 render frame（plan:212），
/// 该时钟给出该帧的宿主时间戳。
abstract interface class HybridSceneClock {
  /// 当前时间（秒，单调）。
  double nowSeconds();
}

/// 一次 [HybridHost.apply] 的结果。
class HybridApplyResult {
  /// 直接构造。
  const HybridApplyResult({
    required this.applied,
    required this.generation,
    required this.reason,
    required this.commandCount,
    required this.hitCount,
    required this.hudPainted,
  });

  /// 是否整份套用（false = 整体丢弃，什么都没有改）。
  final bool applied;

  /// 本次 envelope 的代次（即使被丢弃也如实记录）。
  final int generation;

  /// 理由：成功 `applied`，丢弃 `stale-generation: ...`，错帧 `double-write: ...`。
  final String reason;

  /// 透传给 HUD 绘制器的命令条数（丢弃时为 0）。
  final int commandCount;

  /// 解码出的可用 hit 条数（丢弃时为 0）。
  final int hitCount;

  /// 是否真的调用了 HUD 绘制器。
  final bool hudPainted;

  @override
  String toString() =>
      'HybridApplyResult(applied: $applied, generation: $generation, '
      'commands: $commandCount, hits: $hitCount, hudPainted: $hudPainted, '
      'reason: $reason)';
}

/// 候选 D 的 Dart 侧宿主：HUD 由 Dart 绘（[HybridHudCommandPainter]），3D 由 Qt 供给为一张纹理
/// （[HybridTexturePort]）。
///
/// 职责边界（plan:489-495）：坐标同源（3D 与 HUD 共用同一个 [stage]，plan:178/plan:213）；
/// 双栈同步（[apply] 要求 `texture.generation == envelope.generation`，不等即「两套状态双写同一帧」
/// 的 Fail 条件）；旋转（[rotateTo] 只转 stage/texture，绝不重建引擎状态，NativeScene.cpp:165-198）；
/// 退出条件（[rollbackToDartOnly] 是可回退点：解除 Qt 纹理，仅保留 Dart HUD）。
class HybridHost {
  /// 构造宿主。构造即 [HybridTexturePort.attach]（候选 D 的前提是 Qt 3D 纹理已就位），
  /// 因此 [attached] 初始为 true；首个 [resizeLogical] 之前 stage 是占位几何（逻辑 1080×1080 ⇒
  /// scale 1），真实宿主应在构造后立刻按 layout 调 [resizeLogical]。
  ///
  /// [devicePixelRatio] 只进 [HybridSurfaceGeometry]，不参与 stage 换算；非正值按 1.0 处理。
  HybridHost({
    required HybridTexturePort texture,
    required HybridHudCommandPainter hud,
    HybridSceneClock? clock,
    double devicePixelRatio = 1.0,
  })  : _texture = texture,
        _hud = hud,
        _clock = clock,
        _devicePixelRatio = devicePixelRatio > 0 ? devicePixelRatio : 1.0,
        _stage = HybridStage.fromLogicalSize(
          _kPlaceholderLogicalSize,
          _kPlaceholderLogicalSize,
        ),
        _attached = true {
    _texture.attach(_geometry());
  }

  final HybridTexturePort _texture;
  final HybridHudCommandPainter _hud;
  final HybridSceneClock? _clock;
  final double _devicePixelRatio;

  /// 代次闸门：非更新的快照整体丢弃（plan:213）。
  final HybridFrameGate gate = HybridFrameGate();

  HybridStage _stage;

  /// layout 送入的**原始**逻辑尺寸（不夹取、不反推）；[HybridSurfaceGeometry] 只从这里取值。
  ///
  /// 反向用 `_stage.width * _stage.scale` 回推会引入浮点往返漂移
  /// （`(w/s)*s != w` 在多次 resize 后可观测），而这些原值还要喂给 Qt 引擎 resize 与
  /// 3D/HUD 的同一套 geometry，所以原样保存。
  double _logicalWidth = _kPlaceholderLogicalSize;
  double _logicalHeight = _kPlaceholderLogicalSize;
  bool _attached;
  bool _doubleWriteDetected = false;
  double _rotationRadians = 0;
  List<HybridHit> _hits = const <HybridHit>[];
  Map<String, Object?>? _frame;
  Map<String, Object?>? _state;
  double? _lastFrameTime;

  /// 当前 stage；3D、HUD、hits、measure、IME 全部共用这一个实例（plan:213）。
  HybridStage get stage => _stage;

  /// 是否已检测到「两套状态双写同一帧」（plan:489-495 的 Fail 条件）。**粘性**：置位后不自动清除，
  /// 作为 Fail 证据保留；回退后请改用 [attached] 判断运行模式。
  bool get doubleWriteDetected => _doubleWriteDetected;

  /// Qt 纹理是否仍附着（[rollbackToDartOnly] 之后为 false，即纯 Dart HUD 模式）。
  bool get attached => _attached;

  /// 最近一次 [rotateTo] 传入的弧度（未旋转为 0）。
  double get rotationRadians => _rotationRadians;

  /// 最近一次成功 apply 解出的 hits，按源顺序（消费侧用，外扩见 [kHybridTouchPadding]）。
  List<HybridHit> get hits => _hits;

  /// 最近一次成功 apply 的 frame（只读；首次成功 apply 前为 null）。
  Map<String, Object?>? get frame => _frame;

  /// 最近一次成功 apply 的 state（本地适配袋；首次成功 apply 前为 null）。
  Map<String, Object?>? get state => _state;

  /// 最近一次成功 apply 的宿主时钟读数（秒）；未注入 clock 或尚未成功 apply 时为 null。
  double? get lastFrameTimeSeconds => _lastFrameTime;

  /// 逻辑尺寸变化：只重算 stage 并调 [HybridTexturePort.resize]，**绝不重建引擎状态**
  /// （plan:178；Qt/src/NativeScene.cpp:217-224 那里也只更新 m_width/m_height、重算投影与
  /// viewer 尺寸）。已回退（detached）时不触碰 Qt 侧。
  void resizeLogical(double logicalWidth, double logicalHeight) {
    _logicalWidth = logicalWidth;
    _logicalHeight = logicalHeight;
    _stage = HybridStage.fromLogicalSize(logicalWidth, logicalHeight);
    if (_attached) {
      _texture.resize(logicalWidth, logicalHeight);
    }
  }

  /// 把旋转推进到 [radians]（弧度）：只转 stage/texture 的呈现变换，尺寸与引擎状态都不动。
  ///
  /// Qt 同源语义见 NativeScene.cpp:165-198（`setMode`）：离开 detail 时 `m_targetRotation = 0`
  /// 且要求尚未完成的旋转回正——所以弧度是**目标值**而不是增量，宿主如实记录供退出判断使用。
  void rotateTo(double radians) {
    _rotationRadians = radians;
    if (_attached) {
      _texture.rotate(radians);
    }
  }

  /// 可回退点：解除 Qt 纹理，仅保留 Dart HUD（plan:489-495「可回退点」）。同时把旋转回正
  /// （[rotationRadians] 归 0），因为纯 HUD 模式不存在被旋转的 3D 层。之后 [apply] 走 HUD-only
  /// 路径：不再做 texture.generation 比对（已无 Qt 帧可双写）。
  void rollbackToDartOnly() {
    if (_attached) {
      _texture.detach();
      _attached = false;
    }
    _rotationRadians = 0;
  }

  /// 套用一份 envelope 快照，顺序与语义：
  /// 1. [HybridFrameEnvelope.decode]（全有或全无）。协议错**不吞**：原样抛
  ///    [HybridProtocolException]，绝不套用半份快照、也不静默降级。
  /// 2. 代次闸门：非更新代**整份丢弃**，`applied=false`、reason 说明、不绘制（plan:213）。
  /// 3. 双写检测：附着状态下要求 `texture.generation == envelope.generation`；不等即
  ///    「两套状态双写/错帧」⇒ [doubleWriteDetected] = true、`applied=false`、reason 明确、
  ///    **不绘制**，且不推进闸门（plan:489-495 Fail 条件）。
  /// 4. 通过后**先落状态、再绘制**：hits 按源顺序解码后与 frame/state/帧时间戳一起落到字段上，
  ///    并立刻 [HybridFrameGate.markApplied]；**最后**才把 commands 交给 HUD 绘制器。顺序理由：
  ///    painter 抛异常时同一代次已记账，不会被二次套用、也不会被二次绘制；异常**不吞**（不 try/catch），
  ///    原样抛给调用方——半套呈现必须显式失败（plan:495 的错帧 Fail 要求）。
  /// 5. commands **逐条**原样透传：元素对象同一（不拷贝、不重建、不改写）、同序、不去重（plan:213）。
///    外层容器在 [HybridFrameEnvelope.decode] 里做防御性浅拷贝——契约 `adjudications.a3CommandsIdentity`
///    已裁决「不为此改 A1 入口或删防御拷贝」，所以 `identical(外层 List)` **不可达且不要求**；
///    可断言的是逐条 `identical(painted[i], source[i])` 与 `identical(host.stage, painter.lastStage)`。
  HybridApplyResult apply(Map<String, Object?> envelopeRaw) {
    final HybridFrameEnvelope envelope = HybridFrameEnvelope.decode(envelopeRaw);
    if (!gate.shouldApply(envelope.generation)) {
      return HybridApplyResult(
        applied: false,
        generation: envelope.generation,
        reason: 'stale-generation: incoming=${envelope.generation} '
            'applied=${gate.appliedGeneration}',
        commandCount: 0,
        hitCount: 0,
        hudPainted: false,
      );
    }
    if (_attached && _texture.generation != envelope.generation) {
      _doubleWriteDetected = true;
      return HybridApplyResult(
        applied: false,
        generation: envelope.generation,
        reason: 'double-write: texture.generation=${_texture.generation} '
            '!= envelope.generation=${envelope.generation}',
        commandCount: 0,
        hitCount: 0,
        hudPainted: false,
      );
    }

    final List<HybridHit> decodedHits = HybridHit.decode(envelope.hits);
    // 执行顺序是语义的一部分，禁止重排：
    // 1) 先落 state/hits/frame/帧时间戳，并立刻推进闸门；
    // 2) 最后才绘制。
    // 理由：若先 paint 后记账，painter 抛异常会留下「已画但未记账」的半套状态，重试同代会重绘，
    // HUD 侧即出现两套状态交替写入的错帧——正是 plan:489-495 要显式失败的形状。
    _hits = decodedHits;
    _frame = envelope.frame;
    _state = envelope.state;
    _lastFrameTime = _clock?.nowSeconds();
    gate.markApplied(envelope.generation);
    // 不 try/catch：绘制失败必须冒泡，绝不静默吞掉半套呈现。
    _hud.paint(envelope.commands, _stage);
    return HybridApplyResult(
      applied: true,
      generation: envelope.generation,
      reason: 'applied',
      commandCount: envelope.commands.length,
      hitCount: decodedHits.length,
      hudPainted: true,
    );
  }

  /// 当前 stage/逻辑尺寸/dpr 的快照，交给 Qt 纹理侧。
  ///
  /// 逻辑尺寸取 [_logicalWidth]/[_logicalHeight] 的**输入原值**；绝不用
  /// `_stage.width * _stage.scale` 反推——stage 公式本身是一次除法，乘回去会漂移，
  /// 而 Qt 侧（HybridTextureHost::setSurface）和 3D 引擎 resize 都按原值算。
  HybridSurfaceGeometry _geometry() => HybridSurfaceGeometry(
        logicalWidth: _logicalWidth,
        logicalHeight: _logicalHeight,
        stageWidth: _stage.width,
        stageHeight: _stage.height,
        scale: _stage.scale,
        devicePixelRatio: _devicePixelRatio,
      );

  @override
  String toString() =>
      'HybridHost(attached: $_attached, generation: ${gate.appliedGeneration}, '
      'doubleWrite: $_doubleWriteDetected, $_stage)';
}

/// 取一个有限 double；非 num / NaN / ±Infinity 返回 null（调用方据此丢弃该项）。
double? _finiteDouble(Object? value) {
  if (value is! num) return null;
  final double result = value.toDouble();
  return result.isFinite ? result : null;
}

/// Qt `QJsonValue::toDouble()` 的退化行为：非数字 ⇒ 0.0（Glyphs.cpp:40-48）。
double _rawDouble(Object? value) => value is num ? value.toDouble() : 0.0;

/// 取必需 map 成员；缺失/类型错/含非 String 键时抛 [HybridProtocolException]。
Map<String, Object?> _requireMap(Map<String, Object?> raw, String key) {
  if (!raw.containsKey(key)) {
    throw HybridProtocolException('missing $key (envelope 成员即使为空也必须存在)');
  }
  final Object? value = raw[key];
  if (value is! Map) {
    throw HybridProtocolException('$key must be a Map, got ${_describe(value)}');
  }
  final Map<String, Object?> result = <String, Object?>{};
  for (final MapEntry<Object?, Object?> entry in value.entries) {
    final Object? entryKey = entry.key;
    if (entryKey is! String) {
      throw HybridProtocolException('$key has non-String key ${_describe(entryKey)}');
    }
    result[entryKey] = entry.value;
  }
  return result;
}

/// 取必需 list 成员；缺失/类型错时抛 [HybridProtocolException]。
///
/// 返回**防御性浅拷贝**（元素对象不复制，只重建外层容器）：契约 `adjudications.a3CommandsIdentity`
/// 明确「不为此改 A1 入口或删防御拷贝」，故 `identical(外层 List)` 不可达且不要求；宿主与测试只能
/// 断言逐条 `identical(painted[i], source[i])` 与 `identical(host.stage, painter.lastStage)`。
List<Object?> _requireList(Map<String, Object?> raw, String key) {
  if (!raw.containsKey(key)) {
    throw HybridProtocolException('missing $key (envelope 成员即使为空也必须存在)');
  }
  final Object? value = raw[key];
  if (value is! List) {
    throw HybridProtocolException('$key must be a List, got ${_describe(value)}');
  }
  return List<Object?>.from(value);
}

/// 出错时的类型说明（null 显式标出，避免 "instance of Null" 噪声）。
String _describe(Object? value) => value == null ? 'null' : '${value.runtimeType}';
