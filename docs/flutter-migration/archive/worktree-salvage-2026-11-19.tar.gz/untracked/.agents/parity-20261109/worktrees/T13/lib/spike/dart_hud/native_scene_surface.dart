// Dart port of the native Qt 3D scene surface (NativeScene) for the T13 HUD/3D
// slice.
//
// SCOPE — what is real here and what is not
// -----------------------------------------
// REAL, in this file, no GPU needed:
//   * GLB container decode (magic "glTF", version 2, JSON/BIN chunks) over an
//     injectable byte source, so the shipped Assets/models/*.glb bytes are
//     parsed rather than treated as a bitmap or a pre-baked backdrop;
//   * glTF accessor decode to real triangle data, converted into the same
//     per-mesh BVH the Qt picking class builds, and a raycast that returns the
//     hit distance with the same two-sided/one-sided rule;
//   * the double-precision scene math (column-major matrix, perspective,
//     look-at, multiply, Gauss-Jordan inverse, point/direction transform,
//     frustum planes) that the camera, the culling pass and the picker share;
//   * the camera bootstrap values, the fog law, the two clip-space projection
//     offsets and the slot/cell coordinate mapping;
//   * the frame key table of NativeScene::emitFrame plus the derived scalars
//     (detail, background, fogColor) with the exact curves Qt uses.
//
// NOT here, and deliberately not faked: rasterisation. Qt draws the cards
// through QRhi on a GLES/Vulkan/Metal context that it owns
// (Qt/qml/Scene3D.qml:17-21 RhiScene -> Engine::rhine). Flutter can only show
// those pixels through an external texture, so the whole rasteriser is behind
// [NativeSceneBackend]; this tree ships [UnavailableNativeSceneBackend] only,
// and every entry point that would need a texture fails loudly with
// ARCH_BLOCKED and the exact host files that are missing. There is no static
// background, no placeholder texture id and no silently blank widget: a caller
// that reaches a rasterising path gets a [NativeBackendUnavailable] exception
// carrying [NativeSceneHostWiring.blockage].
//
// SOURCE MAP, Qt tree at baseline 8ed3067b0812eb2612f7841ec127a6e8ca93231b
// (all line numbers verified by reading the files, not inferred):
//   Qt/src/SceneMath.h:22-34        Matrix contract (column-major doubles)
//   Qt/src/SceneMath.cpp:37-63      Matrix::compose (quaternion from half angles)
//   Qt/src/SceneMath.cpp:64-78      Matrix::perspective
//   Qt/src/SceneMath.cpp:79-95      Matrix::camera (look-at)
//   Qt/src/SceneMath.cpp:96-108     Matrix::operator*
//   Qt/src/SceneMath.cpp:110-157    Matrix::inverse (partial pivoting)
//   Qt/src/SceneMath.cpp:158-164    Matrix::point (perspective divide)
//   Qt/src/SceneMath.cpp:165-171    Matrix::direction (normalised 3x3)
//   Qt/src/SceneMath.cpp:184-217    Frustum planes + intersects/intersectsSphere
//   Qt/src/SceneMotion.cpp:9-11     clamp(v, 0, 1)
//   Qt/src/SceneMotion.cpp:42-45    smooth = smootherstep 6v^5-15v^4+10v^3
//   Qt/src/SceneMotion.cpp:46-49    ease   = smoothstep   v^2*(3-2v)
//   Qt/src/SceneMotion.cpp:120-122  Cell::key() = "lane:row"
//   Qt/src/SceneAppearance.h:15-16  boundsCenter {0,1.85,0}, boundsRadius 3.3
//   Qt/src/SceneAppearance.cpp:17-32 color() sRGB->linear, blend()
//   Qt/src/NativeScene.h:123-132    eye/aim/fov/fog defaults, near 5 far 300
//   Qt/src/NativeScene.h:49-55      FrameTimings fields
//   Qt/src/NativeScene.cpp:11-16    wrap(), nearest()
//   Qt/src/NativeScene.cpp:31-43    slots.json -> per-lane column lists
//   Qt/src/NativeScene.cpp:49-52    view/projection/aoProjection bootstrap
//   Qt/src/NativeScene.cpp:63-78    fileLocation/fileAt/cellPosition
//   Qt/src/NativeScene.cpp:217-224  resize(): aoProjection <- old projection
//   Qt/src/NativeSceneCamera.cpp:96-97   fog near/far law
//   Qt/src/NativeSceneCamera.cpp:100-106 archive clip-space offset + ao sync
//   Qt/src/NativeSceneFrame.cpp:62      floor matrix compose({0,-4.63,0}, {-pi/2,0,0})
//   Qt/src/NativeSceneFrame.cpp:87-119  frame key table
//   Qt/src/NativeSceneFrame.cpp:116     detail = smooth((m_detail-0.25)/0.55)
//   Qt/src/NativeSceneFrame.cpp:123     lightView = camera({-6,14,-5},{}).inverse()
//   Qt/src/NativeSceneFrame.cpp:126-141 per-actor culling, 16.1/15.1 thresholds
//   Qt/src/NativeSceneInput.cpp:36-97   pick(): ray build + per-card test
//   Qt/src/NativeSceneInput.cpp:109-111 intersectsCard bounds
//   Qt/src/NativePicking.cpp:26-62      Box slab test
//   Qt/src/NativePicking.cpp:75-105     BVH build (leaf <= 8)
//   Qt/src/NativePicking.cpp:148-178    triangle(): side 1/2 ray rules
//   Qt/src/NativePicking.cpp:231-249    raycast(): nearest finite t -> point
//   Qt/src/DiscGeometry.h:5-13          card shell extent [-2.5,2.5] x [0,3.7]
//   Assets/models/archive-assembly.glb  3343744 B, glTF 2.0, 22 nodes/meshes
//   Assets/models/archive-cassette.glb  3565116 B, glTF 2.0, 17 nodes/meshes
//   Assets/android-3d/scene-fixture.json  frame ground truth used by the checks
//
// KNOWN BLOCKERS (reported verbatim, not worked around)
// ----------------------------------------------------
// ARCH_BLOCKED     No GLES/EGL host, no FlutterTexture/SurfaceProducer
//                  registration, no JNI bridge, no Android C++ target: see
//                  NativeSceneHostWiring. Rendering cannot run in this tree.
// BLK-PUBSPEC-ASSETS  pubspec.yaml in this tree declares no "assets:" section
//                  (the only occurrence is the commented example at
//                  pubspec.yaml:61), so AssetBundle cannot resolve
//                  Assets/models/*.glb even though both files are tracked by
//                  git. A host must add "Assets/models/" to pubspec.yaml; the
//                  pubspec is outside this file's write domain, so
//                  [GlbAssetSource] reports the missing key instead of
//                  pretending the bytes arrived.
// DEVICE_BLOCKED   Pixel/performance comparison is not executed per the
//                  task prohibition, so nothing here claims a device pass.
import 'dart:convert';
import 'dart:io' show File;
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/services.dart' show AssetBundle, ByteData;

// ===========================================================================
// Section 1 — failures and small numeric helpers
// ===========================================================================

/// Base for every failure this file raises instead of guessing.
///
/// The port never substitutes a plausible value for a missing one: a caller
/// either gets a decoded value or one of these, so a device gate can fail on a
/// named cause.
sealed class NativeSceneFailure implements Exception {
  const NativeSceneFailure(this.message, [this.detail]);

  /// Short, stable English description of what is missing or malformed.
  final String message;

  /// Optional machine-readable context (offsets, asset keys, host paths).
  final String? detail;

  @override
  String toString() => detail == null
      ? runtimeType.toString() + ': ' + message
      : runtimeType.toString() + ': ' + message + ' (' + detail! + ')';
}

/// The GLB container itself is malformed: bad magic, wrong version, a chunk
/// that overruns the file, or a JSON chunk that does not decode.
final class GlbFailure extends NativeSceneFailure {
  const GlbFailure(super.message, [super.detail]);
}

/// A glTF document is structurally valid but references data this port does not
/// decode (unknown accessor type, missing bufferView, out-of-range index).
final class GltfFailure extends NativeSceneFailure {
  const GltfFailure(super.message, [super.detail]);
}

/// The scene asset a caller asked for cannot be reached from this tree.
final class SceneAssetFailure extends NativeSceneFailure {
  const SceneAssetFailure(super.message, [super.detail]);
}

/// A rasterising call was made against a backend that has no host wiring.
///
/// [requirements] is the complete, ordered list of host-side work that would
/// make the call legal; [blockage] carries the ARCH_BLOCKED report.
final class NativeBackendUnavailable extends NativeSceneFailure {
  const NativeBackendUnavailable({
    required String message,
    required this.blockage,
    String? detail,
  }) : super(message, detail);

  final NativeBackendBlockage blockage;

  /// Convenience view of the blockage's host requirements.
  List<NativeSceneHostRequirement> get requirements => blockage.requirements;
}

/// Mirrors Qt/src/SceneMotion.cpp:9-11 clamp(value, 0, 1).
double sceneClamp01(double value) =>
    value < 0 ? 0 : (value > 1 ? 1 : value);

/// Mirrors Qt/src/SceneMotion.cpp:42-45: clamp, then smootherstep.
///
/// v * v * v * (10 + v * (-15 + 6 * v)), i.e. 6v^5 - 15v^4 + 10v^3 with the
/// explicit Horner form Qt uses so the floating-point result is identical.
double sceneSmooth(double value) {
  final double v = sceneClamp01(value);
  return v * v * v * (10 + v * (-15 + 6 * v));
}

/// Mirrors Qt/src/SceneMotion.cpp:46-49: clamp, then smoothstep v^2*(3-2v).
double sceneEase(double value) {
  final double v = sceneClamp01(value);
  return v * v * (3 - 2 * v);
}

/// Mirrors Qt/src/NativeScene.cpp:11-13 wrap(value, count).
///
/// Qt returns 0 for a non-positive count, and uses the sign-corrected modulo
/// (value % count + count) % count. Dart's % already returns a non-negative
/// result for a positive divisor, so the correction is a no-op here; it is kept
/// in the expression so the two implementations stay visibly the same.
int sceneWrap(int value, int count) {
  if (count <= 0) {
    return 0;
  }
  return (value % count + count) % count;
}

/// Mirrors Qt/src/NativeScene.cpp:14-16 nearest(value, center, period).
int sceneNearest(int value, int center, int period) {
  if (period == 0) {
    return value;
  }
  final double offset = center - value + period / 2.0;
  final int steps = (offset / period).floor();
  return value + steps * period;
}

// ===========================================================================
// Section 2 — GLB container (real glTF 2.0 binary)
// ===========================================================================

/// One chunk of a GLB container.
///
/// The header is length:uint32, type:uint32 followed by length bytes (payloads
/// are 4-byte aligned by construction because the spec pads the JSON chunk with
/// 0x20 and the BIN chunk with 0x00).
class GlbChunk {
  const GlbChunk({
    required this.type,
    required this.data,
    required this.offset,
  });

  /// Raw four-character chunk type as a little-endian uint32.
  final int type;

  /// Chunk payload, exactly length bytes.
  final Uint8List data;

  /// Byte offset of the chunk header from the start of the file.
  final int offset;

  int get length => data.length;

  bool get isJson => type == GlbContainer.jsonChunkType;
  bool get isBinary => type == GlbContainer.binaryChunkType;

  /// Four-character code, e.g. "JSON" or "BIN\0".
  String get typeName => String.fromCharCodes(<int>[
        type & 0xFF,
        (type >> 8) & 0xFF,
        (type >> 16) & 0xFF,
        (type >> 24) & 0xFF,
      ]);
}

/// A decoded GLB container: the glTF JSON plus the optional binary buffer.
///
/// Verified against the two shipped assets, both of which are glTF 2.0 with one
/// JSON chunk and one BIN chunk:
///   Assets/models/archive-assembly.glb  length 3343744, JSON 22768, BIN 3320948
///   Assets/models/archive-cassette.glb  length 3565116, JSON 18252, BIN 3546836
class GlbContainer {
  const GlbContainer._({
    required this.version,
    required this.declaredLength,
    required this.byteLength,
    required this.json,
    required this.binary,
    required this.chunks,
  });

  /// "glTF" as a little-endian uint32 (bytes 67 6C 54 46).
  static const int magic = 0x46546C67;

  /// "JSON" as a little-endian uint32 (bytes 4A 53 4F 4E).
  static const int jsonChunkType = 0x4E4F534A;

  /// "BIN\0" as a little-endian uint32 (bytes 42 49 4E 00).
  static const int binaryChunkType = 0x004E4942;

  /// The only container version this port accepts.
  static const int supportedVersion = 2;

  /// Smallest possible container: 12-byte header plus one chunk header.
  static const int minimumLength = 20;

  final int version;
  final int declaredLength;
  final int byteLength;
  final Map<String, dynamic> json;
  final Uint8List? binary;
  final List<GlbChunk> chunks;

  /// Parses a whole GLB file.
  ///
  /// Rejects, in order: a short header, a wrong magic, a version other than 2, a
  /// declared length that does not match the buffer, a first chunk that is not
  /// JSON, a chunk that overruns the declared length, trailing bytes after the
  /// last chunk, a second JSON chunk, and a JSON payload that is not an object.
  /// Every rejection names the byte offset so a truncated asset read is obvious
  /// at the call site instead of surfacing later as empty geometry.
  factory GlbContainer.parse(Uint8List bytes) {
    if (bytes.length < minimumLength) {
      throw GlbFailure(
        'GLB shorter than the 20-byte minimum container',
        'byteLength ' + bytes.length.toString(),
      );
    }
    final ByteData data = ByteData.sublistView(bytes);
    final int magicValue = data.getUint32(0, Endian.little);
    if (magicValue != magic) {
      throw GlbFailure(
        'GLB magic is not "glTF"',
        '0x' + magicValue.toRadixString(16).padLeft(8, '0'),
      );
    }
    final int versionValue = data.getUint32(4, Endian.little);
    if (versionValue != supportedVersion) {
      throw GlbFailure(
        'unsupported GLB version',
        'version ' +
            versionValue.toString() +
            ', expected ' +
            supportedVersion.toString(),
      );
    }
    final int declared = data.getUint32(8, Endian.little);
    if (declared != bytes.length) {
      throw GlbFailure(
        'GLB declared length does not match the buffer',
        'declared ' +
            declared.toString() +
            ', actual ' +
            bytes.length.toString(),
      );
    }
    final List<GlbChunk> chunks = <GlbChunk>[];
    Uint8List? binary;
    Map<String, dynamic>? document;
    int offset = 12;
    while (offset + 8 <= declared) {
      final int length = data.getUint32(offset, Endian.little);
      final int type = data.getUint32(offset + 4, Endian.little);
      final int start = offset + 8;
      final int end = start + length;
      if (end > declared) {
        throw GlbFailure(
          'GLB chunk overruns the declared length',
          'chunk at ' +
              offset.toString() +
              ' claims ' +
              length.toString() +
              ' bytes, only ' +
              (declared - start).toString() +
              ' remain',
        );
      }
      final Uint8List payload = Uint8List.sublistView(bytes, start, end);
      final GlbChunk chunk =
          GlbChunk(type: type, data: payload, offset: offset);
      chunks.add(chunk);
      if (chunk.isJson) {
        if (document != null) {
          throw GlbFailure('GLB has more than one JSON chunk',
              'second JSON chunk at ' + offset.toString());
        }
        if (chunks.length != 1) {
          throw GlbFailure('GLB JSON chunk is not the first chunk',
              'first chunk type "' + chunks.first.typeName + '"');
        }
        document = _decodeJsonChunk(payload, offset);
      } else if (chunk.isBinary) {
        if (binary != null) {
          throw GlbFailure('GLB has more than one BIN chunk',
              'second BIN chunk at ' + offset.toString());
        }
        binary = payload;
      }
      offset = end;
    }
    if (document == null) {
      throw const GlbFailure('GLB has no JSON chunk');
    }
    if (offset != declared) {
      throw GlbFailure(
        'GLB has trailing bytes after the last chunk',
        'stopped at ' + offset.toString() + ' of ' + declared.toString(),
      );
    }
    return GlbContainer._(
      version: versionValue,
      declaredLength: declared,
      byteLength: bytes.length,
      json: document,
      binary: binary,
      chunks: chunks,
    );
  }

  static Map<String, dynamic> _decodeJsonChunk(Uint8List payload, int offset) {
    // The spec pads the JSON chunk with 0x20; UTF-8 decoding accepts it and
    // jsonDecode skips leading/trailing whitespace.
    final String text;
    try {
      text = utf8.decode(payload, allowMalformed: false);
    } on FormatException catch (error) {
      throw GlbFailure('GLB JSON chunk is not valid UTF-8',
          'chunk at ' + offset.toString() + ': ' + error.message);
    }
    final Object? decoded;
    try {
      decoded = jsonDecode(text);
    } on FormatException catch (error) {
      throw GlbFailure('GLB JSON chunk does not parse',
          'chunk at ' + offset.toString() + ': ' + error.message);
    }
    if (decoded is! Map) {
      throw GlbFailure('GLB JSON chunk is not an object',
          'chunk at ' + offset.toString());
    }
    return decoded.cast<String, dynamic>();
  }

  /// Convenience wrapper for a ByteData produced by an AssetBundle.
  static GlbContainer fromByteData(ByteData data) => GlbContainer.parse(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      );

  /// asset.version from the glTF document ("2.0" for the shipped assets).
  String get assetVersion => _string(json['asset'], 'version');

  /// asset.generator from the glTF document.
  String get generator => _string(json['asset'], 'generator');

  /// extensionsUsed, in document order.
  List<String> get extensionsUsed => <String>[
        for (final Object? value in _list(json['extensionsUsed']))
          if (value is String) value,
      ];

  static String _string(Object? owner, String key) {
    if (owner is Map) {
      final Object? value = owner[key];
      if (value is String) {
        return value;
      }
    }
    return '';
  }

  static List<Object?> _list(Object? value) =>
      value is List ? value.cast<Object?>() : const <Object?>[];
}

/// Where the GLB bytes come from.
///
/// The point of the abstraction is that the decoder above is testable and
/// host-agnostic: the same [GlbContainer.parse] runs over an AssetBundle payload
/// on device, a file read in a desktop harness, or a literal buffer in a unit
/// test. A source reports "not reachable" by throwing [SceneAssetFailure]; it
/// never returns an empty buffer, because an empty buffer would decode as a
/// malformed container and hide the real cause.
sealed class GlbByteSource {
  const GlbByteSource();

  /// Human-readable identification used in diagnostics.
  String get label;

  /// Reads the whole container, or throws [SceneAssetFailure].
  Future<Uint8List> read();

  /// Parses the container in one step.
  Future<GlbContainer> load() async => GlbContainer.parse(await read());
}

/// Bytes already in memory.
final class GlbMemorySource extends GlbByteSource {
  const GlbMemorySource(this.bytes, {this.label = 'memory'});

  final Uint8List bytes;

  @override
  final String label;

  @override
  Future<Uint8List> read() async {
    if (bytes.isEmpty) {
      throw const SceneAssetFailure(
          'in-memory GLB source is empty', 'GlbMemorySource');
    }
    return bytes;
  }
}

/// A file on the local filesystem.
///
/// This is the honest source for a desktop harness and for an app-private copy
/// the host has already materialised (for example a file unpacked from the APK).
/// A raw "assets/..." key is NOT a filesystem path: use [GlbAssetSource] for
/// that. dart:io is imported for this source only, so the file is aimed at
/// Android/desktop targets, matching the Qt application this port mirrors.
final class GlbFileSource extends GlbByteSource {
  const GlbFileSource(this.path);

  final String path;

  @override
  String get label => 'file:' + path;

  @override
  Future<Uint8List> read() async {
    final File file = File(path);
    if (!await file.exists()) {
      throw SceneAssetFailure('GLB file does not exist', path);
    }
    final Uint8List bytes = await file.readAsBytes();
    if (bytes.isEmpty) {
      throw SceneAssetFailure('GLB file is empty', path);
    }
    return bytes;
  }
}

/// A Flutter asset.
///
/// The key must be reachable through an assets: declaration in pubspec.yaml.
/// This tree declares none (the only occurrence is the commented example at
/// pubspec.yaml:61), so loading Assets/models/*.glb here fails with
/// BLK-PUBSPEC-ASSETS spelled out, which is the correct outcome: the file is
/// tracked by git and present on disk, but not shipped to the Dart VM.
final class GlbAssetSource extends GlbByteSource {
  const GlbAssetSource(this.bundle, this.key);

  final AssetBundle bundle;
  final String key;

  @override
  String get label => 'asset:' + key;

  @override
  Future<Uint8List> read() async {
    if (key.isEmpty) {
      throw const SceneAssetFailure('GLB asset key is empty');
    }
    final ByteData data;
    try {
      data = await bundle.load(key);
    } on Object catch (error) {
      throw SceneAssetFailure(
        'GLB asset is not reachable through this AssetBundle '
        '(BLK-PUBSPEC-ASSETS: pubspec.yaml declares no assets: section, '
        'see pubspec.yaml:61)',
        key + ' -> ' + error.toString(),
      );
    }
    final Uint8List bytes =
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    if (bytes.isEmpty) {
      throw SceneAssetFailure('GLB asset is empty', key);
    }
    return bytes;
  }
}

/// A caller-supplied reader, for a host that owns its own I/O layer.
final class GlbFunctionSource extends GlbByteSource {
  const GlbFunctionSource(this.reader, {this.label = 'callback'});

  final Future<Uint8List?> Function(String key) reader;

  @override
  final String label;

  @override
  Future<Uint8List> read() async {
    final Uint8List? bytes = await reader(label);
    if (bytes == null || bytes.isEmpty) {
      throw SceneAssetFailure('GLB reader returned no bytes', label);
    }
    return bytes;
  }
}

// ===========================================================================
// Section 3 — glTF document model and accessor decoding
// ===========================================================================

/// glTF componentType codes used by the accessor decoder
/// (glTF 2.0 spec, accessor.componentType).
class GltfComponentType {
  const GltfComponentType._();

  static const int byte = 5120;
  static const int unsignedByte = 5121;
  static const int short = 5122;
  static const int unsignedShort = 5123;
  static const int unsignedInt = 5125;
  static const int float = 5126;

  /// Size in bytes of one component, or 0 when the code is unknown.
  static int sizeOf(int componentType) {
    switch (componentType) {
      case byte:
      case unsignedByte:
        return 1;
      case short:
      case unsignedShort:
        return 2;
      case unsignedInt:
      case float:
        return 4;
      default:
        return 0;
    }
  }
}

/// Number of components an accessor type string carries, or 0 when unknown.
int gltfTypeComponents(String type) {
  switch (type) {
    case 'SCALAR':
      return 1;
    case 'VEC2':
      return 2;
    case 'VEC3':
      return 3;
    case 'VEC4':
    case 'MAT2':
      return 4;
    case 'MAT3':
      return 9;
    case 'MAT4':
      return 16;
    default:
      return 0;
  }
}

/// One bufferViews[] entry.
class GltfBufferView {
  const GltfBufferView({
    required this.index,
    required this.buffer,
    required this.byteOffset,
    required this.byteLength,
    required this.byteStride,
  });

  final int index;
  final int buffer;
  final int byteOffset;
  final int byteLength;

  /// Zero when the view is tightly packed.
  final int byteStride;
}

/// One accessors[] entry.
class GltfAccessor {
  const GltfAccessor({
    required this.index,
    required this.componentType,
    required this.type,
    required this.count,
    required this.bufferView,
    required this.byteOffset,
    required this.min,
    required this.max,
  });

  final int index;
  final int componentType;
  final String type;
  final int count;

  /// -1 for an accessor with no bufferView (all-zero data per the spec).
  final int bufferView;
  final int byteOffset;

  /// Declared bounds, empty when the asset omits them.
  final List<double> min;
  final List<double> max;

  int get components => gltfTypeComponents(type);

  bool get isFloat32 => componentType == GltfComponentType.float;

  bool get isIndex =>
      componentType == GltfComponentType.unsignedByte ||
      componentType == GltfComponentType.unsignedShort ||
      componentType == GltfComponentType.unsignedInt;
}

/// One meshes[].primitives[] entry, resolved to accessor indices.
class GltfPrimitive {
  const GltfPrimitive({
    required this.position,
    required this.normal,
    required this.texCoord,
    required this.indices,
    required this.material,
  });

  /// Accessor index of POSITION, or -1 when absent.
  final int position;

  /// Accessor index of NORMAL, or -1 when absent.
  final int normal;

  /// Accessor index of TEXCOORD_0, or -1 when absent.
  final int texCoord;

  /// Accessor index of the index buffer, or -1 for a non-indexed primitive.
  final int indices;

  /// materials[] index, or -1 when the primitive declares no material.
  final int material;
}

/// One meshes[] entry.
class GltfMesh {
  const GltfMesh({
    required this.index,
    required this.name,
    required this.primitives,
  });

  final int index;
  final String name;
  final List<GltfPrimitive> primitives;
}

/// One nodes[] entry.
class GltfNode {
  const GltfNode({
    required this.index,
    required this.name,
    required this.mesh,
    required this.assemblyPart,
    required this.children,
  });

  final int index;
  final String name;

  /// -1 when the node only groups other nodes.
  final int mesh;

  /// extras.assemblyPart.
  ///
  /// archive-assembly.glb uses it to group the cover, carrier, substrate,
  /// optical-core, optical-lenses and fasteners; archive-cassette.glb sets no
  /// extras at all, so this is empty there.
  final String assemblyPart;
  final List<int> children;
}

/// A parsed glTF scene: the document model plus the binary buffer.
///
/// Only what this port needs is modelled (nodes, meshes, primitives, material
/// names, accessors, bufferViews, root nodes). Everything else stays in [raw]
/// untouched so a reviewer can diff it against the file byte for byte.
class GltfScene {
  GltfScene._({
    required this.container,
    required this.raw,
    required this.nodes,
    required this.meshes,
    required this.materials,
    required this.accessors,
    required this.bufferViews,
    required this.rootNodes,
    required this.sceneName,
  });

  /// Decodes the glTF document of [container].
  factory GltfScene.fromContainer(GlbContainer container) {
    final Map<String, dynamic> raw = container.json;

    final List<GltfAccessor> accessors = <GltfAccessor>[];
    final List<Object?> accessorJson = _listOf(raw['accessors']);
    for (int index = 0; index < accessorJson.length; index += 1) {
      final Map<String, dynamic> entry = _mapOf(accessorJson[index]);
      accessors.add(
        GltfAccessor(
          index: index,
          componentType: _intOf(entry['componentType'], 0),
          type: entry['type'] is String ? entry['type'] as String : '',
          count: _intOf(entry['count'], 0),
          bufferView: _intOf(entry['bufferView'], -1),
          byteOffset: _intOf(entry['byteOffset'], 0),
          min: _doublesOf(entry['min']),
          max: _doublesOf(entry['max']),
        ),
      );
    }

    final List<GltfBufferView> bufferViews = <GltfBufferView>[];
    final List<Object?> viewJson = _listOf(raw['bufferViews']);
    for (int index = 0; index < viewJson.length; index += 1) {
      final Map<String, dynamic> entry = _mapOf(viewJson[index]);
      bufferViews.add(
        GltfBufferView(
          index: index,
          buffer: _intOf(entry['buffer'], 0),
          byteOffset: _intOf(entry['byteOffset'], 0),
          byteLength: _intOf(entry['byteLength'], 0),
          byteStride: _intOf(entry['byteStride'], 0),
        ),
      );
    }

    final List<GltfMesh> meshes = <GltfMesh>[];
    final List<Object?> meshJson = _listOf(raw['meshes']);
    for (int index = 0; index < meshJson.length; index += 1) {
      final Map<String, dynamic> entry = _mapOf(meshJson[index]);
      final List<GltfPrimitive> primitives = <GltfPrimitive>[];
      for (final Object? primitive in _listOf(entry['primitives'])) {
        final Map<String, dynamic> value = _mapOf(primitive);
        final Map<String, dynamic> attributes = _mapOf(value['attributes']);
        primitives.add(
          GltfPrimitive(
            position: _intOf(attributes['POSITION'], -1),
            normal: _intOf(attributes['NORMAL'], -1),
            texCoord: _intOf(attributes['TEXCOORD_0'], -1),
            indices: _intOf(value['indices'], -1),
            material: _intOf(value['material'], -1),
          ),
        );
      }
      meshes.add(
        GltfMesh(
          index: index,
          name: entry['name'] is String ? entry['name'] as String : '',
          primitives: primitives,
        ),
      );
    }

    final List<GltfNode> nodes = <GltfNode>[];
    final List<Object?> nodeJson = _listOf(raw['nodes']);
    for (int index = 0; index < nodeJson.length; index += 1) {
      final Map<String, dynamic> entry = _mapOf(nodeJson[index]);
      final Map<String, dynamic> extras = _mapOf(entry['extras']);
      nodes.add(
        GltfNode(
          index: index,
          name: entry['name'] is String ? entry['name'] as String : '',
          mesh: _intOf(entry['mesh'], -1),
          assemblyPart: extras['assemblyPart'] is String
              ? extras['assemblyPart'] as String
              : '',
          children: <int>[
            for (final Object? child in _listOf(entry['children']))
              if (child is num) child.toInt(),
          ],
        ),
      );
    }

    final List<String> materials = <String>[];
    for (final Object? material in _listOf(raw['materials'])) {
      final Map<String, dynamic> value = _mapOf(material);
      materials.add(value['name'] is String ? value['name'] as String : '');
    }

    final List<Object?> scenes = _listOf(raw['scenes']);
    final int sceneIndex = _intOf(raw['scene'], 0);
    final Map<String, dynamic> scene =
        sceneIndex >= 0 && sceneIndex < scenes.length
            ? _mapOf(scenes[sceneIndex])
            : <String, dynamic>{};

    return GltfScene._(
      container: container,
      raw: raw,
      nodes: nodes,
      meshes: meshes,
      materials: materials,
      accessors: accessors,
      bufferViews: bufferViews,
      rootNodes: <int>[
        for (final Object? node in _listOf(scene['nodes']))
          if (node is num) node.toInt(),
      ],
      sceneName: scene['name'] is String ? scene['name'] as String : '',
    );
  }

  final GlbContainer container;
  final Map<String, dynamic> raw;
  final List<GltfNode> nodes;
  final List<GltfMesh> meshes;
  final List<String> materials;
  final List<GltfAccessor> accessors;
  final List<GltfBufferView> bufferViews;
  final List<int> rootNodes;

  /// scenes[scene].name; "Rhine_Archive_Asset" and "Rhine_Assembly_Asset.012"
  /// for the two shipped assets.
  final String sceneName;

  bool get hasBinary => container.binary != null;

  /// Bytes of buffers[0], i.e. the GLB BIN chunk.
  ///
  /// Both shipped assets declare exactly one buffer with no uri
  /// (archive-assembly.glb: {"byteLength": 3320948}), which is the GLB BIN chunk
  /// by definition.
  Uint8List requireBinary() {
    final Uint8List? binary = container.binary;
    if (binary == null) {
      throw GltfFailure('glTF document has no BIN chunk', sceneName);
    }
    return binary;
  }

  /// Reads a float accessor as tightly packed double values.
  ///
  /// Follows the glTF layout rules the Qt offline step assumed: the element base
  /// is bufferView.byteOffset + accessor.byteOffset, the element stride is
  /// bufferView.byteStride when present and tightly packed otherwise, and a
  /// 32-bit float component is widened to double (which is exact), matching
  /// Qt/src/NativePicking.cpp:117-121 where Qt memcpys floats into a double[3].
  Float64List readFloatAccessor(int index) {
    final GltfAccessor accessor = _accessor(index);
    if (!accessor.isFloat32) {
      throw GltfFailure(
        'accessor is not 32-bit float',
        'accessor ' + index.toString(),
      );
    }
    final int components = accessor.components;
    if (components == 0) {
      throw GltfFailure(
        'accessor type is not decodable',
        'accessor ' + index.toString() + ' type ' + accessor.type,
      );
    }
    final Float64List result = Float64List(accessor.count * components);
    if (accessor.bufferView < 0) {
      return result;
    }
    final Uint8List binary = requireBinary();
    final GltfBufferView view = _bufferView(accessor.bufferView);
    final int elementSize = 4 * components;
    final int stride = view.byteStride > 0 ? view.byteStride : elementSize;
    final int base = view.byteOffset + accessor.byteOffset;
    final int lastEnd =
        accessor.count == 0 ? base : base + (accessor.count - 1) * stride + elementSize;
    if (base < 0 || lastEnd > binary.length) {
      throw GltfFailure(
        'accessor reads past the BIN chunk',
        'accessor ' +
            index.toString() +
            ' base ' +
            base.toString() +
            ' stride ' +
            stride.toString() +
            ' count ' +
            accessor.count.toString() +
            ' bin ' +
            binary.length.toString(),
      );
    }
    final ByteData data = ByteData.sublistView(binary);
    int target = 0;
    for (int element = 0; element < accessor.count; element += 1) {
      int cursor = base + element * stride;
      for (int component = 0; component < components; component += 1) {
        result[target] = data.getFloat32(cursor, Endian.little);
        cursor += 4;
        target += 1;
      }
    }
    return result;
  }

  /// Reads an index accessor as unsigned 32-bit values.
  ///
  /// 5121/5123/5125 are all widened to uint32 so the BVH builder sees one
  /// representation, the same way Qt/src/NativePicking.cpp:123-127 widens its
  /// stored indices.
  Uint32List readIndexAccessor(int index) {
    final GltfAccessor accessor = _accessor(index);
    if (!accessor.isIndex) {
      throw GltfFailure(
        'accessor is not an unsigned index type',
        'accessor ' + index.toString(),
      );
    }
    if (accessor.components != 1) {
      throw GltfFailure(
        'index accessor is not SCALAR',
        'accessor ' + index.toString(),
      );
    }
    final Uint32List result = Uint32List(accessor.count);
    if (accessor.bufferView < 0) {
      return result;
    }
    final Uint8List binary = requireBinary();
    final GltfBufferView view = _bufferView(accessor.bufferView);
    final int size = GltfComponentType.sizeOf(accessor.componentType);
    final int stride = view.byteStride > 0 ? view.byteStride : size;
    final int base = view.byteOffset + accessor.byteOffset;
    final int lastEnd =
        accessor.count == 0 ? base : base + (accessor.count - 1) * stride + size;
    if (base < 0 || lastEnd > binary.length) {
      throw GltfFailure(
        'index accessor reads past the BIN chunk',
        'accessor ' + index.toString(),
      );
    }
    final ByteData data = ByteData.sublistView(binary);
    for (int element = 0; element < accessor.count; element += 1) {
      final int at = base + element * stride;
      switch (accessor.componentType) {
        case GltfComponentType.unsignedByte:
          result[element] = data.getUint8(at);
          break;
        case GltfComponentType.unsignedShort:
          result[element] = data.getUint16(at, Endian.little);
          break;
        default:
          result[element] = data.getUint32(at, Endian.little);
          break;
      }
    }
    return result;
  }

  /// Declared bounds of an accessor, as (min, max) component arrays.
  ///
  /// These are the numbers the asset declares, not a recomputation, so a caller
  /// can assert that the GLB agrees with the card shell Qt hardcodes
  /// (Qt/src/DiscGeometry.h:5: x in [-2.5, 2.5], y in [0, 3.7]) without paying for
  /// a full vertex scan.
  (List<double>, List<double>) declaredBounds(int accessorIndex) {
    final GltfAccessor accessor = _accessor(accessorIndex);
    return (accessor.min, accessor.max);
  }

  /// Nodes whose extras.assemblyPart equals [part] and that carry a mesh.
  List<GltfNode> nodesForPart(String part) => <GltfNode>[
        for (final GltfNode node in nodes)
          if (node.assemblyPart == part && node.mesh >= 0) node,
      ];

  GltfAccessor _accessor(int index) {
    if (index < 0 || index >= accessors.length) {
      throw GltfFailure(
        'accessor index out of range',
        'index ' + index.toString() + ' of ' + accessors.length.toString(),
      );
    }
    return accessors[index];
  }

  GltfBufferView _bufferView(int index) {
    if (index < 0 || index >= bufferViews.length) {
      throw GltfFailure(
        'bufferView index out of range',
        'index ' + index.toString() + ' of ' + bufferViews.length.toString(),
      );
    }
    return bufferViews[index];
  }

  static List<Object?> _listOf(Object? value) =>
      value is List ? value.cast<Object?>() : const <Object?>[];

  static Map<String, dynamic> _mapOf(Object? value) =>
      value is Map ? value.cast<String, dynamic>() : <String, dynamic>{};

  static int _intOf(Object? value, int fallback) =>
      value is num ? value.toInt() : fallback;

  static List<double> _doublesOf(Object? value) {
    if (value is! List) {
      return const <double>[];
    }
    return <double>[
      for (final Object? entry in value)
        if (entry is num) entry.toDouble(),
    ];
  }
}

// ===========================================================================
// Section 4 — scene math (SceneVector / SceneMatrix / SceneFrustum)
// ===========================================================================

/// Mirrors Qt/src/SceneMath.h:7-20 SceneMath::Vector.
///
/// Immutable because the Dart call sites never alias a vector the way the C++
/// setters do; the arithmetic and the normalized() zero-length rule are the same.
class SceneVector {
  const SceneVector(this.x, this.y, this.z);

  static const SceneVector zero = SceneVector(0, 0, 0);

  /// Qt/src/SceneMath.cpp:85, the fixed up axis of the look-at basis.
  static const SceneVector up = SceneVector(0, 1, 0);

  final double x;
  final double y;
  final double z;

  SceneVector operator +(SceneVector other) =>
      SceneVector(x + other.x, y + other.y, z + other.z);

  SceneVector operator -(SceneVector other) =>
      SceneVector(x - other.x, y - other.y, z - other.z);

  SceneVector operator *(double scale) =>
      SceneVector(x * scale, y * scale, z * scale);

  double dot(SceneVector other) => x * other.x + y * other.y + z * other.z;

  /// Qt/src/SceneMath.cpp:20-22.
  SceneVector cross(SceneVector other) => SceneVector(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x,
      );

  /// Qt/src/SceneMath.cpp:23-25.
  double get length => math.sqrt(x * x + y * y + z * z);

  /// Qt/src/SceneMath.cpp:26-29: a zero-length vector comes back unchanged
  /// (the factor becomes 1 rather than NaN).
  SceneVector normalized() {
    final double size = length;
    return this * (size == 0 ? 1 : 1 / size);
  }

  /// Qt/src/SceneMath.cpp:30-32.
  SceneVector lerp(SceneVector other, double amount) => SceneVector(
        x + (other.x - x) * amount,
        y + (other.y - y) * amount,
        z + (other.z - z) * amount,
      );

  bool get isFinite => x.isFinite && y.isFinite && z.isFinite;

  /// Qt returns QJsonArray{x, y, z} (Qt/src/SceneMath.cpp:33-35).
  List<double> toJson() => <double>[x, y, z];

  @override
  bool operator ==(Object other) =>
      other is SceneVector && other.x == x && other.y == y && other.z == z;

  @override
  int get hashCode => Object.hash(x, y, z);

  @override
  String toString() => 'SceneVector(' +
      x.toStringAsFixed(6) +
      ', ' +
      y.toStringAsFixed(6) +
      ', ' +
      z.toStringAsFixed(6) +
      ')';
}

/// Mirrors Qt/src/SceneMath.h:22-34 / SceneMath.cpp:37-183 SceneMath::Matrix.
///
/// Storage is column-major with 16 doubles, exactly like the C++ struct, and every
/// operation keeps double precision; the float32 narrowing happens only when a
/// backend uploads the matrix (Qt/src/SceneMath.cpp:179-183 bytes()), which is
/// [uploadBytes] here.
class SceneMatrix {
  SceneMatrix._(this.values);

  /// A copy of an existing 16-element column-major array.
  factory SceneMatrix.fromValues(List<double> values) {
    if (values.length != 16) {
      throw ArgumentError.value(
        values.length,
        'values',
        'a 4x4 matrix needs exactly 16 doubles',
      );
    }
    return SceneMatrix._(Float64List.fromList(values));
  }

  /// Qt's default member initialiser, Qt/src/SceneMath.h:24.
  factory SceneMatrix.identity() => SceneMatrix._(
        Float64List.fromList(
          const <double>[
            1, 0, 0, 0, //
            0, 1, 0, 0, //
            0, 0, 1, 0, //
            0, 0, 0, 1, //
          ],
        ),
      );

  /// Qt returns an all-zero matrix for a singular input
  /// (Qt/src/SceneMath.cpp:126-130), so a caller can detect the failure through
  /// [isZero].
  factory SceneMatrix.zeros() => SceneMatrix._(Float64List(16));

  /// Column-major values; index is column * 4 + row.
  final Float64List values;

  double get m00 => values[0];
  double get m11 => values[5];
  double get m22 => values[10];
  double get m33 => values[15];

  /// Clip-space x offset, Qt's values[8]
  /// (Qt/src/NativeSceneCamera.cpp:102).
  double get clipX => values[8];

  /// Clip-space y offset, Qt's values[9]
  /// (Qt/src/NativeSceneCamera.cpp:103).
  double get clipY => values[9];

  bool get isZero {
    for (int index = 0; index < 16; index += 1) {
      if (values[index] != 0) {
        return false;
      }
    }
    return true;
  }

  bool get isFinite {
    for (int index = 0; index < 16; index += 1) {
      if (!values[index].isFinite) {
        return false;
      }
    }
    return true;
  }

  /// Qt/src/SceneMath.cpp:37-63 compose(position, rotation, scale).
  ///
  /// Rotation is an XYZ Euler triple in radians, converted to a quaternion by the
  /// half-angle products Qt spells out, then to a row-major rotation scaled per
  /// axis and dropped into the column-major slots.
  factory SceneMatrix.compose(
    SceneVector position,
    SceneVector rotation, [
    SceneVector scale = const SceneVector(1, 1, 1),
  ]) {
    final double c1 = math.cos(rotation.x / 2);
    final double c2 = math.cos(rotation.y / 2);
    final double c3 = math.cos(rotation.z / 2);
    final double s1 = math.sin(rotation.x / 2);
    final double s2 = math.sin(rotation.y / 2);
    final double s3 = math.sin(rotation.z / 2);
    final double x = s1 * c2 * c3 + c1 * s2 * s3;
    final double y = c1 * s2 * c3 - s1 * c2 * s3;
    final double z = c1 * c2 * s3 + s1 * s2 * c3;
    final double w = c1 * c2 * c3 - s1 * s2 * s3;
    final double x2 = x + x;
    final double y2 = y + y;
    final double z2 = z + z;
    final double xx = x * x2;
    final double xy = x * y2;
    final double xz = x * z2;
    final double yy = y * y2;
    final double yz = y * z2;
    final double zz = z * z2;
    final double wx = w * x2;
    final double wy = w * y2;
    final double wz = w * z2;
    return SceneMatrix._(
      Float64List.fromList(<double>[
        (1 - (yy + zz)) * scale.x,
        (xy + wz) * scale.x,
        (xz - wy) * scale.x,
        0,
        (xy - wz) * scale.y,
        (1 - (xx + zz)) * scale.y,
        (yz + wx) * scale.y,
        0,
        (xz + wy) * scale.z,
        (yz - wx) * scale.z,
        (1 - (xx + yy)) * scale.z,
        0,
        position.x,
        position.y,
        position.z,
        1,
      ]),
    );
  }

  /// Qt/src/SceneMath.cpp:64-78 perspective(fovDegrees, aspect, near, far).
  ///
  /// Vertical field of view, symmetric frustum, right-handed depth mapped to
  /// [-1, 1]: c = -(far + near) / (far - near), d = -2 * far * near / (far - near).
  factory SceneMatrix.perspective(
    double fovDegrees,
    double aspect,
    double near,
    double far,
  ) {
    final double top = near * math.tan(math.pi / 180 * 0.5 * fovDegrees);
    final double height = 2 * top;
    final double width = aspect * height;
    final double left = -0.5 * width;
    final double right = left + width;
    final double bottom = top - height;
    final double x = 2 * near / (right - left);
    final double y = 2 * near / (top - bottom);
    final double a = (right + left) / (right - left);
    final double b = (top + bottom) / (top - bottom);
    final double c = -(far + near) / (far - near);
    final double d = -2 * far * near / (far - near);
    return SceneMatrix._(
      Float64List.fromList(<double>[
        x, 0, 0, 0, //
        0, y, 0, 0, //
        a, b, c, -1, //
        0, 0, d, 0, //
      ]),
    );
  }

  /// Qt/src/SceneMath.cpp:79-95 camera(position, target).
  ///
  /// The look-at basis is stored as an affine transform whose translation column is
  /// the eye, so camera(...).inverse() is the view matrix and
  /// camera(...).point(world) lands in camera space. The degenerate cases are Qt's:
  /// a zero position - target becomes +Z, and a zero cross product nudges z by
  /// 0.0001 before retrying.
  factory SceneMatrix.camera(SceneVector position, SceneVector target) {
    SceneVector z = position - target;
    if (z.length == 0) {
      z = SceneVector(z.x, z.y, 1);
    }
    z = z.normalized();
    SceneVector x = SceneVector.up.cross(z);
    if (x.length == 0) {
      z = SceneVector(z.x, z.y, z.z + 0.0001).normalized();
      x = SceneVector.up.cross(z);
    }
    x = x.normalized();
    final SceneVector y = z.cross(x);
    return SceneMatrix._(
      Float64List.fromList(<double>[
        x.x, x.y, x.z, 0, //
        y.x, y.y, y.z, 0, //
        z.x, z.y, z.z, 0, //
        position.x, position.y, position.z, 1, //
      ]),
    );
  }

  /// Qt/src/SceneMath.cpp:96-108 operator*: this * other, i.e. the standard
  /// column-major product with the right operand applied first.
  SceneMatrix multiply(SceneMatrix other) {
    final Float64List result = Float64List(16);
    for (int column = 0; column < 4; column += 1) {
      for (int row = 0; row < 4; row += 1) {
        double value = 0;
        for (int k = 0; k < 4; k += 1) {
          value += values[k * 4 + row] * other.values[column * 4 + k];
        }
        result[column * 4 + row] = value;
      }
    }
    return SceneMatrix._(result);
  }

  SceneMatrix operator *(SceneMatrix other) => multiply(other);

  /// Qt/src/SceneMath.cpp:110-157 inverse().
  ///
  /// Gauss-Jordan elimination on a row-major copy with partial pivoting. A singular
  /// matrix returns [SceneMatrix.zeros] rather than an invalid matrix, so callers
  /// must check [isZero], exactly as the Qt comment asks.
  SceneMatrix inverse() {
    final List<Float64List> rows =
        List<Float64List>.generate(4, (int _) => Float64List(8));
    for (int row = 0; row < 4; row += 1) {
      for (int column = 0; column < 4; column += 1) {
        rows[row][column] = values[column * 4 + row];
      }
      rows[row][row + 4] = 1;
    }
    for (int column = 0; column < 4; column += 1) {
      int pivot = column;
      for (int row = column + 1; row < 4; row += 1) {
        if (rows[row][column].abs() > rows[pivot][column].abs()) {
          pivot = row;
        }
      }
      if (rows[pivot][column] == 0) {
        return SceneMatrix.zeros();
      }
      if (pivot != column) {
        final Float64List swap = rows[pivot];
        rows[pivot] = rows[column];
        rows[column] = swap;
      }
      final double divisor = rows[column][column];
      for (int index = 0; index < 8; index += 1) {
        rows[column][index] /= divisor;
      }
      for (int row = 0; row < 4; row += 1) {
        if (row == column) {
          continue;
        }
        final double factor = rows[row][column];
        for (int index = 0; index < 8; index += 1) {
          rows[row][index] -= factor * rows[column][index];
        }
      }
    }
    final Float64List result = Float64List(16);
    for (int row = 0; row < 4; row += 1) {
      for (int column = 0; column < 4; column += 1) {
        result[column * 4 + row] = rows[row][column + 4];
      }
    }
    return SceneMatrix._(result);
  }

  /// Qt/src/SceneMath.cpp:158-164 point(): transform then divide by w.
  ///
  /// A zero w yields an infinite result rather than an exception, matching the C++
  /// division; callers that cannot tolerate it check [SceneVector.isFinite].
  SceneVector point(SceneVector point) {
    final double w = 1 /
        (values[3] * point.x +
            values[7] * point.y +
            values[11] * point.z +
            values[15]);
    return SceneVector(
      (values[0] * point.x +
              values[4] * point.y +
              values[8] * point.z +
              values[12]) *
          w,
      (values[1] * point.x +
              values[5] * point.y +
              values[9] * point.z +
              values[13]) *
          w,
      (values[2] * point.x +
              values[6] * point.y +
              values[10] * point.z +
              values[14]) *
          w,
    );
  }

  /// Qt/src/SceneMath.cpp:165-171 direction(): rotate by the upper 3x3 and
  /// normalise.
  ///
  /// Qt normalises after the transform, including when the matrix has a non-uniform
  /// scale, so this port does the same.
  SceneVector direction(SceneVector vector) => SceneVector(
        values[0] * vector.x + values[4] * vector.y + values[8] * vector.z,
        values[1] * vector.x + values[5] * vector.y + values[9] * vector.z,
        values[2] * vector.x + values[6] * vector.y + values[10] * vector.z,
      ).normalized();

  /// A copy with the clip-space translation Qt writes directly
  /// (Qt/src/NativeSceneCamera.cpp:102-103: values[8] += dx, values[9] += dy).
  SceneMatrix withClipOffset(double dx, double dy) {
    final Float64List copy = Float64List.fromList(values);
    copy[8] += dx;
    copy[9] += dy;
    return SceneMatrix._(copy);
  }

  /// A copy with the diagonal scale Qt applies for the wider culling frustum
  /// (Qt/src/NativeSceneCamera.cpp:116-117: values[0] /= 1.18, values[5] /= 1.18).
  SceneMatrix withLinearScale(double x, double y) {
    final Float64List copy = Float64List.fromList(values);
    copy[0] *= x;
    copy[5] *= y;
    return SceneMatrix._(copy);
  }

  /// Qt/src/SceneMath.cpp:172-178.
  List<double> toJson() => <double>[
        for (int index = 0; index < 16; index += 1) values[index],
      ];

  /// Qt/src/SceneMath.cpp:179-183: double -> float32, for GPU submission only.
  Float32List uploadBytes() {
    final Float32List result = Float32List(16);
    for (int index = 0; index < 16; index += 1) {
      result[index] = values[index];
    }
    return result;
  }

  @override
  String toString() => 'SceneMatrix(' + toJson().join(', ') + ')';
}

/// Mirrors Qt/src/SceneMath.cpp:184-217 SceneMath::Frustum.
///
/// Six planes extracted from a projection-view matrix, each normalised, with the
/// sign convention plane = row3 + sign * row(axis), where even indices are the
/// "min" plane (sign -1) and odd indices the "max" plane (sign +1).
class SceneFrustum {
  SceneFrustum(SceneMatrix matrix) : _planes = _extract(matrix.values);

  final List<Float64List> _planes;

  /// Fixed plane count: left/right, bottom/top, near/far.
  static const int planeCount = 6;

  static List<Float64List> _extract(Float64List m) {
    final List<Float64List> planes = <Float64List>[];
    for (int index = 0; index < planeCount; index += 1) {
      final int component = index ~/ 2;
      final double sign = index % 2 == 0 ? -1 : 1;
      final Float64List plane = Float64List(4);
      for (int column = 0; column < 4; column += 1) {
        plane[column] = m[column * 4 + 3] + sign * m[column * 4 + component];
      }
      final double length = math.sqrt(
        plane[0] * plane[0] + plane[1] * plane[1] + plane[2] * plane[2],
      );
      for (int index = 0; index < 4; index += 1) {
        plane[index] /= length;
      }
      planes.add(plane);
    }
    return planes;
  }

  /// Qt/src/SceneMath.cpp:199-209: a box is outside as soon as one plane has its
  /// positive vertex behind it.
  bool intersects(SceneVector minimum, SceneVector maximum) {
    for (final Float64List plane in _planes) {
      final double x = plane[0] > 0 ? maximum.x : minimum.x;
      final double y = plane[1] > 0 ? maximum.y : minimum.y;
      final double z = plane[2] > 0 ? maximum.z : minimum.z;
      if (plane[0] * x + plane[1] * y + plane[2] * z + plane[3] < 0) {
        return false;
      }
    }
    return true;
  }

  /// Qt/src/SceneMath.cpp:210-217.
  bool intersectsSphere(SceneVector center, double radius) {
    for (final Float64List plane in _planes) {
      if (plane[0] * center.x +
              plane[1] * center.y +
              plane[2] * center.z +
              plane[3] <
          -radius) {
        return false;
      }
    }
    return true;
  }

  /// Normals and offsets, for a reviewer diffing against the C++ planes.
  List<List<double>> get planes => <List<double>>[
        for (final Float64List plane in _planes)
          <double>[plane[0], plane[1], plane[2], plane[3]],
      ];
}

// ===========================================================================
// Section 5 — slots, cells and world coordinates
// ===========================================================================

/// Mirrors Qt/src/SceneMotion.h:22-27 / SceneMotion.cpp:120-122 Cell.
class SceneCell {
  const SceneCell(this.lane, this.row);

  /// Qt's default actor cell, {2, 12} (Qt/src/NativeScene.h:85).
  static const SceneCell initial = SceneCell(2, 12);

  final int lane;
  final int row;

  /// Qt concatenates lane + ":" + row (Qt/src/SceneMotion.cpp:120-122); kept
  /// identical so a hover-lift map keyed by [key] matches the Qt hash key format.
  String get key => lane.toString() + ':' + row.toString();

  SceneCell shifted(int laneDelta, int rowDelta) =>
      SceneCell(lane + laneDelta, row + rowDelta);

  @override
  bool operator ==(Object other) =>
      other is SceneCell && other.lane == lane && other.row == row;

  @override
  int get hashCode => Object.hash(lane, row);

  @override
  String toString() => 'SceneCell(' + key + ')';
}

/// Mirrors the slot table NativeScene builds from slots.json
/// (Qt/src/NativeScene.cpp:31-43).
///
/// The Qt constructor walks the five lanes, appends every record index whose
/// category equals columns[lane], and remembers the first index per lane as that
/// column's memory (the card a lane returns to). The shipped
/// Assets/android-3d/slots.json has 5 columns, 5 categories and 40 records, and
/// Resources/slots.json has the same shape, so both load here.
class SceneSlotTable {
  SceneSlotTable._(
    this.columns,
    this.categories,
    this.records,
    this._laneRecords,
  );

  /// The five lane names, in column order (the shipped file lists 搜索结果,
  /// 喜欢的歌曲, 我的歌单, 收藏歌单, 收藏专辑).
  final List<String> columns;

  /// The declared category list; kept for parity and diagnostics.
  final List<String> categories;

  /// Record ids in document order.
  final List<String> records;

  final List<List<int>> _laneRecords;

  /// Lane count Qt walks: std::min(5, columns.size()) (NativeScene.cpp:34).
  static const int laneCount = 5;

  /// First row of a lane; fileLocation offsets from it (NativeScene.cpp:67).
  static const int rowOrigin = 12;

  /// Lane spacing along x and row spacing along z (NativeScene.cpp:77).
  static const double laneSpacing = 5.2;
  static const double rowSpacing = 0.62;

  /// Height of the card plane (NativeScene.cpp:77).
  static const double cardHeight = -4.6;

  /// The row the camera aim is expressed against, (row - 15.5) * 0.62
  /// (NativeScene.cpp:77).
  static const double rowCenter = 15.5;

  /// Lane 2 is the centre column, hence (lane - 2) * 5.2.
  static const int laneCenter = 2;

  /// Parses slots.json.
  factory SceneSlotTable.fromJson(Map<String, dynamic> json) {
    final List<String> columns = <String>[
      for (final Object? column in _listOf(json['columns']))
        if (column is String) column,
    ];
    final List<String> categories = <String>[
      for (final Object? category in _listOf(json['categories']))
        if (category is String) category,
    ];
    final List<Object?> recordJson = _listOf(json['records']);
    final List<String> records = <String>[];
    final List<String> recordCategories = <String>[];
    for (final Object? entry in recordJson) {
      final Map<String, dynamic> record = _mapOf(entry);
      records.add(record['id'] is String ? record['id'] as String : '');
      recordCategories.add(
        record['category'] is String ? record['category'] as String : '',
      );
    }
    final List<List<int>> laneRecords = <List<int>>[];
    for (int lane = 0; lane < math.min(laneCount, columns.length); lane += 1) {
      final List<int> laneList = <int>[];
      for (int index = 0; index < recordCategories.length; index += 1) {
        if (recordCategories[index] == columns[lane]) {
          laneList.add(index);
        }
      }
      laneRecords.add(laneList);
    }
    while (laneRecords.length < laneCount) {
      laneRecords.add(<int>[]);
    }
    return SceneSlotTable._(columns, categories, records, laneRecords);
  }

  /// Record indices of one lane, in document order.
  List<int> laneRecords(int lane) => _laneRecords[sceneWrap(lane, laneCount)];

  /// Qt/src/NativeScene.cpp:44-47: the scene is not ready when the actor template
  /// is empty or lane 0 is empty. This table covers the lane half; the template
  /// half belongs to the appearance/cards port.
  String? get failure => _laneRecords[0].isEmpty || columns.isEmpty
      ? 'Missing native scene assets: lane 0 of slots.json is empty'
      : null;

  /// Qt/src/NativeScene.cpp:63-71 fileLocation(index).
  ///
  /// The lane is the one whose column list contains [index]; the row is
  /// 12 + position in that lane. An unknown index falls back to {2, 12}.
  SceneCell fileLocation(int index) {
    for (int lane = 0; lane < laneCount; lane += 1) {
      final int row = _laneRecords[lane].indexOf(index);
      if (row >= 0) {
        return SceneCell(lane, rowOrigin + row);
      }
    }
    return SceneCell.initial;
  }

  /// Qt/src/NativeScene.cpp:72-75 fileAt(cell): both axes wrap, so the plane is
  /// toroidal and the camera can keep sliding without a seam.
  int fileAt(SceneCell cell) {
    final List<int> files = _laneRecords[sceneWrap(cell.lane, laneCount)];
    if (files.isEmpty) {
      return 0;
    }
    return files[sceneWrap(cell.row - rowOrigin, files.length)];
  }

  /// Qt/src/NativeScene.cpp:76-78 cellPosition(cell):
  /// {(lane - 2) * 5.2, -4.6, (row - 15.5) * 0.62}.
  ///
  /// This is the untracked world position. The live scene subtracts the
  /// column-camera and adds the rail and the entrance offset when it composes an
  /// actor (Qt/src/NativeSceneUpdate.cpp:224-225), which [trackedPosition] does.
  static SceneVector cellPosition(SceneCell cell) => SceneVector(
        (cell.lane - laneCenter) * laneSpacing,
        cardHeight,
        (cell.row - rowCenter) * rowSpacing,
      );

  /// The live actor position Qt composes per frame
  /// (Qt/src/NativeSceneUpdate.cpp:224-225):
  /// {chosen.x - trackX, selectedBase + lift + hoverLift, chosen.z + entryZ + rail}.
  static SceneVector trackedPosition({
    required SceneCell cell,
    required double trackX,
    required double baseY,
    required double lift,
    required double hoverLift,
    required double entryZ,
    required double rail,
  }) {
    final SceneVector chosen = cellPosition(cell);
    return SceneVector(
      chosen.x - trackX,
      baseY + lift + hoverLift,
      chosen.z + entryZ + rail,
    );
  }

  static List<Object?> _listOf(Object? value) =>
      value is List ? value.cast<Object?>() : const <Object?>[];

  static Map<String, dynamic> _mapOf(Object? value) =>
      value is Map ? value.cast<String, dynamic>() : <String, dynamic>{};
}

// ===========================================================================
// Section 6 — BVH picking (Qt/src/NativePicking.cpp)
// ===========================================================================

/// Qt/src/NativePicking.cpp:26-62 Box, the slab test the BVH uses.
///
/// The C++ struct starts inverted and grows through include(); the Dart value type
/// is always a real interval, so an empty box is an interval nothing can enter and
/// [isEmpty] reports the inverted case the C++ sentinels stand for.
class ScenePickingBox {
  const ScenePickingBox(this.low, this.high);

  factory ScenePickingBox.empty() => const ScenePickingBox(
        SceneVector(double.infinity, double.infinity, double.infinity),
        SceneVector(
          double.negativeInfinity,
          double.negativeInfinity,
          double.negativeInfinity,
        ),
      );

  final SceneVector low;
  final SceneVector high;

  bool get isEmpty => low.x > high.x || low.y > high.y || low.z > high.z;

  /// Qt/src/NativePicking.cpp:29-34.
  ScenePickingBox include(SceneVector point) => ScenePickingBox(
        SceneVector(
          math.min(low.x, point.x),
          math.min(low.y, point.y),
          math.min(low.z, point.z),
        ),
        SceneVector(
          math.max(high.x, point.x),
          math.max(high.y, point.y),
          math.max(high.z, point.z),
        ),
      );

  /// Qt/src/NativePicking.cpp:35-38.
  ScenePickingBox includeBox(ScenePickingBox other) =>
      include(other.low).include(other.high);

  /// Qt/src/NativePicking.cpp:39-61 Box::intersects(origin, direction, best).
  ///
  /// near starts at 0 so geometry behind the ray origin is rejected, and far starts
  /// at the running best hit so the traversal prunes. A zero component must already
  /// lie inside the slab, which is what keeps an axis-aligned ray from producing an
  /// infinity that would poison the interval.
  bool intersects(SceneVector origin, SceneVector direction, double best) {
    double near = 0;
    double far = best;
    for (int axis = 0; axis < 3; axis += 1) {
      final double start = component(origin, axis);
      final double step = component(direction, axis);
      final double lowAxis = component(low, axis);
      final double highAxis = component(high, axis);
      if (step == 0) {
        if (start < lowAxis || start > highAxis) {
          return false;
        }
        continue;
      }
      double first = (lowAxis - start) / step;
      double last = (highAxis - start) / step;
      if (first > last) {
        final double swap = first;
        first = last;
        last = swap;
      }
      near = math.max(near, first);
      far = math.min(far, last);
      if (near > far) {
        return false;
      }
    }
    return true;
  }

  /// Axis accessor shared by the slab test and the builder.
  static double component(SceneVector value, int axis) =>
      axis == 0 ? value.x : axis == 1 ? value.y : value.z;

  @override
  String toString() =>
      'ScenePickingBox(' + low.toString() + ' .. ' + high.toString() + ')';
}

/// Qt/src/NativePicking.cpp:63-69 Node.
///
/// Mutable because build() reserves a node, fills its bounds, then writes the child
/// indices after the two recursive calls return.
class SceneBvhNode {
  SceneBvhNode({
    required this.box,
    this.left = -1,
    this.right = -1,
    this.first = 0,
    this.count = 0,
  });

  ScenePickingBox box;
  int left;
  int right;
  int first;
  int count;

  bool get isLeaf => count != 0;
}

/// One pickable card mesh, mirroring Qt/src/NativePicking.cpp:70-193 Mesh.
///
/// Qt loads its parts from archive-cassette.json plus a 32-byte-stride vertex blob
/// and a uint32 index blob built offline. This port builds the identical structure
/// from a real GLB primitive, so the shipped assets are the picking geometry rather
/// than a pre-baked side channel.
class ScenePickingMesh {
  ScenePickingMesh._(this.positions, this.indices, this.nodes, this.triangles);

  /// A mesh that failed validation, so raycast() misses the way Qt does when load()
  /// bailed out (Qt/src/NativePicking.cpp:111-115 and 135-139 leave nodes empty).
  factory ScenePickingMesh.empty() => ScenePickingMesh._(
        Float64List(0),
        Uint32List(0),
        <SceneBvhNode>[],
        <int>[],
      );

  /// Builds a mesh from one primitive of a decoded GLB.
  ///
  /// [meshIndex] indexes [GltfScene.meshes]. Every shipped mesh has exactly one
  /// primitive carrying POSITION/NORMAL/TEXCOORD_0 plus indices, so a primitive
  /// count other than one is reported rather than silently half-loaded.
  factory ScenePickingMesh.fromGltf(GltfScene scene, int meshIndex) {
    if (meshIndex < 0 || meshIndex >= scene.meshes.length) {
      throw GltfFailure(
        'mesh index out of range',
        'mesh ' + meshIndex.toString() + ' of ' + scene.meshes.length.toString(),
      );
    }
    final GltfMesh mesh = scene.meshes[meshIndex];
    if (mesh.primitives.length != 1) {
      throw GltfFailure(
        'mesh does not have exactly one primitive',
        'mesh ' +
            meshIndex.toString() +
            ' primitiveCount ' +
            mesh.primitives.length.toString(),
      );
    }
    final GltfPrimitive primitive = mesh.primitives.first;
    if (primitive.position < 0 || primitive.indices < 0) {
      throw GltfFailure(
        'primitive is missing POSITION or indices',
        'mesh ' + meshIndex.toString(),
      );
    }
    final Float64List positions = scene.readFloatAccessor(primitive.position);
    final Uint32List raw = scene.readIndexAccessor(primitive.indices);
    final int vertexCount = positions.length ~/ 3;
    final Uint32List indices = Uint32List(raw.length);
    for (int index = 0; index < raw.length; index += 1) {
      final int value = raw[index];
      if (value >= vertexCount) {
        return ScenePickingMesh.empty();
      }
      indices[index] = value;
    }
    final int count = indices.length ~/ 3;
    final List<int> triangles = List<int>.generate(count, (int index) => index);
    final ScenePickingMesh result = ScenePickingMesh._(
      positions,
      indices,
      <SceneBvhNode>[],
      triangles,
    );
    if (count > 0) {
      final List<ScenePickingBox> boxes = <ScenePickingBox>[];
      for (int triangle = 0; triangle < count; triangle += 1) {
        ScenePickingBox box = ScenePickingBox.empty();
        for (int vertex = 0; vertex < 3; vertex += 1) {
          final int position = indices[triangle * 3 + vertex];
          box = box.include(
            SceneVector(
              positions[position * 3],
              positions[position * 3 + 1],
              positions[position * 3 + 2],
            ),
          );
        }
        boxes.add(box);
      }
      result._build(boxes, 0, count);
    }
    return result;
  }

  /// Three doubles per vertex in the primitive local space, exactly the values GLB
  /// POSITION carries.
  final Float64List positions;

  /// Triangle indices into [positions].
  final Uint32List indices;

  final List<SceneBvhNode> nodes;

  /// The triangle permutation build() maintains; entry i is the original triangle
  /// index stored at leaf slot i (Qt triangles, Qt/src/NativePicking.cpp:73).
  final List<int> triangles;

  bool get isEmpty => nodes.isEmpty;

  int get triangleCount => indices.length ~/ 3;

  /// Qt/src/NativePicking.cpp:75-105 build().
  ///
  /// Reserve the node, accumulate the bounds of the triangle range, stop as a leaf at
  /// 8 triangles or fewer, otherwise split at the median of the longest axis. Qt uses
  /// nth_element, which only guarantees the median lands at middle; sorting the range
  /// by the same low + high centroid key puts that same triangle there and leaves the
  /// two halves partitioned the same way, so traversal prunes against the same boxes.
  int _build(List<ScenePickingBox> boxes, int first, int count) {
    final int index = nodes.length;
    nodes.add(SceneBvhNode(box: ScenePickingBox.empty()));
    ScenePickingBox box = ScenePickingBox.empty();
    for (int i = first; i < first + count; i += 1) {
      box = box.includeBox(boxes[triangles[i]]);
    }
    nodes[index].box = box;
    if (count <= 8) {
      nodes[index].first = first;
      nodes[index].count = count;
      return index;
    }
    int axis = 0;
    for (int candidate = 1; candidate < 3; candidate += 1) {
      final double candidateSpan =
          ScenePickingBox.component(box.high, candidate) -
              ScenePickingBox.component(box.low, candidate);
      final double axisSpan = ScenePickingBox.component(box.high, axis) -
          ScenePickingBox.component(box.low, axis);
      if (candidateSpan > axisSpan) {
        axis = candidate;
      }
    }
    final int middle = first + count ~/ 2;
    final List<int> slice = triangles.sublist(first, first + count);
    slice.sort((int left, int right) {
      final double leftSum = ScenePickingBox.component(boxes[left].low, axis) +
          ScenePickingBox.component(boxes[left].high, axis);
      final double rightSum = ScenePickingBox.component(boxes[right].low, axis) +
          ScenePickingBox.component(boxes[right].high, axis);
      return leftSum.compareTo(rightSum);
    });
    triangles.setRange(first, first + count, slice);
    final int left = _build(boxes, first, middle - first);
    final int right = _build(boxes, middle, first + count - middle);
    nodes[index].left = left;
    nodes[index].right = right;
    return index;
  }

  SceneVector _position(int vertex) => SceneVector(
        positions[vertex * 3],
        positions[vertex * 3 + 1],
        positions[vertex * 3 + 2],
      );

  /// Qt/src/NativePicking.cpp:148-178 triangle().
  ///
  /// Moller-Trumbore with Qt's side rule: side 1 flips the winding, side 2 accepts
  /// both facings, anything else culls back faces. A hit behind the origin is rejected
  /// through the numerator sign and a parallel ray returns infinity.
  ///
  /// [triangle] is an original triangle index, which is what visit() passes.
  double intersectTriangle(
    int triangle,
    SceneVector origin,
    SceneVector direction,
    int side,
  ) {
    SceneVector first = _position(indices[triangle * 3]);
    final SceneVector second = _position(indices[triangle * 3 + 1]);
    SceneVector third = _position(indices[triangle * 3 + 2]);
    if (side == 1) {
      final SceneVector swap = first;
      first = third;
      third = swap;
    }
    final SceneVector edge1 = second - first;
    final SceneVector edge2 = third - first;
    final SceneVector normal = edge1.cross(edge2);
    double denominator = direction.dot(normal);
    double sign = 1;
    if (denominator > 0) {
      if (side != 2) {
        return double.infinity;
      }
    } else if (denominator < 0) {
      sign = -1;
      denominator = -denominator;
    } else {
      return double.infinity;
    }
    final SceneVector difference = origin - first;
    final double firstWeight = sign * direction.dot(difference.cross(edge2));
    final double secondWeight = sign * direction.dot(edge1.cross(difference));
    if (firstWeight < 0 ||
        secondWeight < 0 ||
        firstWeight + secondWeight > denominator) {
      return double.infinity;
    }
    final double numerator = -sign * difference.dot(normal);
    return numerator < 0 ? double.infinity : numerator / denominator;
  }

  /// Qt/src/NativePicking.cpp:179-192 visit().
  ///
  /// [best] is a single-element list because Dart has no reference parameters.
  void _visit(
    int index,
    SceneVector origin,
    SceneVector direction,
    int side,
    List<double> best,
  ) {
    final SceneBvhNode node = nodes[index];
    if (!node.box.intersects(origin, direction, best[0])) {
      return;
    }
    if (node.isLeaf) {
      for (int i = node.first; i < node.first + node.count; i += 1) {
        best[0] = math.min(
          best[0],
          intersectTriangle(triangles[i], origin, direction, side),
        );
      }
      return;
    }
    if (node.left >= 0) {
      _visit(node.left, origin, direction, side, best);
    }
    if (node.right >= 0) {
      _visit(node.right, origin, direction, side, best);
    }
  }

  /// Qt/src/NativePicking.cpp:231-249 raycast().
  ///
  /// Returns the hit point in the mesh local space, or null for a miss. NativeScene
  /// passes side 2 (Qt/src/NativeSceneInput.cpp:77), which accepts both facings.
  SceneVector? raycast(SceneVector origin, SceneVector direction, int side) {
    if (nodes.isEmpty || !origin.isFinite || !direction.isFinite) {
      return null;
    }
    final List<double> best = <double>[double.infinity];
    _visit(0, origin, direction, side, best);
    if (!best[0].isFinite) {
      return null;
    }
    return origin + direction * best[0];
  }
}

// ===========================================================================
// Section 7 — card picking, drag projection, plane navigation, culling
// ===========================================================================

/// One card the picker may test.
///
/// NativeScene::pick builds these from the drawn instances plus the live actor and
/// every returning actor (Qt/src/NativeSceneInput.cpp:89-95). Drawn cards test only
/// picking mesh 0; the actor and the returning cards test every mesh, which is what
/// the allMeshes flag records.
class SceneCardInstance {
  const SceneCardInstance({
    required this.cell,
    required this.matrix,
    this.allMeshes = false,
  });

  final SceneCell cell;

  /// The card world transform, scale included where the actor carries one.
  final SceneMatrix matrix;

  final bool allMeshes;

  /// The conservative card shell Qt hardcodes
  /// (Qt/src/NativeSceneInput.cpp:49-50, reused against the frustum at
  /// Qt/src/NativeSceneCamera.cpp:110): x in [-2.8, 2.8], y in [-0.3, 4.1],
  /// z in [-1.2, 1.2].
  static const SceneVector shellMinimum = SceneVector(-2.8, -0.3, -1.2);
  static const SceneVector shellMaximum = SceneVector(2.8, 4.1, 1.2);
}

/// Mirrors NativeScene::pick (Qt/src/NativeSceneInput.cpp:36-97).
///
/// The ray is built by unprojecting the pointer at NDC z = 0.5 rather than at the
/// near plane, and every card is tested in its own local space: the shell slab first,
/// then the BVH. A hit only counts between 5 and 300 units from the eye, the same
/// window the projection uses.
class NativeScenePicker {
  const NativeScenePicker(this.meshes);

  /// Picking meshes by appearance index; index 0 is the one drawn cards test.
  final List<ScenePickingMesh> meshes;

  /// [x] and [y] are logical pixels from the top left, the coordinates Qt receives.
  ///
  /// Returns null when the pointer misses every card, which is what an empty
  /// std::optional means to the QML layer.
  SceneCell? pick({
    required double x,
    required double y,
    required double width,
    required double height,
    required SceneMatrix projection,
    required SceneMatrix view,
    required SceneVector eye,
    required List<SceneCardInstance> drawn,
    required List<SceneCardInstance> extra,
  }) {
    final SceneMatrix inverse = (projection * view).inverse();
    if (inverse.isZero) {
      // Qt would divide by a zero w and carry infinities through the slab test, which
      // fails every axis and yields no hit; returning null states that outcome.
      return null;
    }
    final SceneVector direction = (inverse.point(
              SceneVector(x / width * 2 - 1, -y / height * 2 + 1, 0.5),
            ) -
            eye)
        .normalized();
    double nearest = 1e100;
    SceneCell? result;
    for (final SceneCardInstance instance in drawn) {
      final SceneCell? hit = _probe(instance, eye, direction, nearest);
      if (hit != null) {
        nearest = _lastDistance;
        result = hit;
      }
    }
    for (final SceneCardInstance instance in extra) {
      final SceneCell? hit = _probe(instance, eye, direction, nearest);
      if (hit != null) {
        nearest = _lastDistance;
        result = hit;
      }
    }
    return result;
  }

  /// Distance of the hit the most recent [probe] accepted.
  ///
  /// A field rather than a tuple because Qt threads nearest by reference through the
  /// card lambda; this keeps the accept rule in one place, next to the 5..300 window.
  double _lastDistance = 0;

  /// One card, Qt/src/NativeSceneInput.cpp:42-88.
  ///
  /// The card is tested in its own local space: the shell slab first, which rejects
  /// anything the ray cannot reach, then every picking mesh the caller allows. The hit
  /// is transformed back to world space and accepted only inside the 5..300 distance
  /// window and nearer than the running best.
  SceneCell? _probe(
    SceneCardInstance instance,
    SceneVector eye,
    SceneVector direction,
    double nearest,
  ) {
    final SceneMatrix inverse = instance.matrix.inverse();
    if (inverse.isZero) {
      return null;
    }
    final SceneVector origin = inverse.point(eye);
    final SceneVector localDirection = inverse.direction(direction);
    double low = -1e100;
    double high = 1e100;
    for (int axis = 0; axis < 3; axis += 1) {
      final double start = ScenePickingBox.component(origin, axis);
      final double step = ScenePickingBox.component(localDirection, axis);
      final double minimum = ScenePickingBox.component(
        SceneCardInstance.shellMinimum,
        axis,
      );
      final double maximum = ScenePickingBox.component(
        SceneCardInstance.shellMaximum,
        axis,
      );
      if (step == 0) {
        if (start < minimum || start > maximum) {
          return null;
        }
        continue;
      }
      double first = (minimum - start) / step;
      double last = (maximum - start) / step;
      if (first > last) {
        final double swap = first;
        first = last;
        last = swap;
      }
      low = math.max(low, first);
      high = math.min(high, last);
    }
    if (low > high || high < 0 || low > nearest) {
      return null;
    }
    double best = 1e100;
    SceneCell? result;
    for (int index = 0; index < meshes.length; index += 1) {
      if (!instance.allMeshes && index != 0) {
        continue;
      }
      final SceneVector? hit = meshes[index].raycast(origin, localDirection, 2);
      if (hit == null) {
        continue;
      }
      final SceneVector point = instance.matrix.point(hit);
      final double distance = (point - eye).length;
      if (distance >= 5 && distance <= 300 && distance < best) {
        best = distance;
        result = instance.cell;
      }
    }
    if (result == null) {
      return null;
    }
    _lastDistance = best;
    return result;
  }
}

/// Mirrors NativeScene::dragProjection (Qt/src/NativeSceneInput.cpp:24-33).
///
/// Projects the card centre plus and minus half a lane step and half a row step into
/// screen space, so a pointer delta can be turned into lane and row motion. The pair
/// order and the sign of the y term follow Qt: x is scaled by width / 2 with no flip,
/// y by -height / 2.
class SceneDragProjection {
  const SceneDragProjection({
    required this.laneX,
    required this.laneY,
    required this.rowX,
    required this.rowY,
  });

  factory SceneDragProjection.measure({
    required SceneVector actorPosition,
    required SceneVector actorRotation,
    required SceneMatrix projection,
    required SceneMatrix view,
    required double width,
    required double height,
  }) {
    final SceneVector center =
        SceneMatrix.compose(actorPosition, actorRotation)
            .point(const SceneVector(0, 1.85, 0));
    final SceneMatrix combined = projection * view;
    List<double> project(SceneVector motion) {
      final SceneVector from = combined.point(center + motion * -0.5);
      final SceneVector to = combined.point(center + motion * 0.5);
      return <double>[
        (to.x - from.x) * width / 2,
        -(to.y - from.y) * height / 2,
      ];
    }

    final List<double> lane = project(const SceneVector(-5.2, 0, 0));
    final List<double> row = project(const SceneVector(0, 0, -0.62));
    return SceneDragProjection(
      laneX: lane[0],
      laneY: lane[1],
      rowX: row[0],
      rowY: row[1],
    );
  }

  /// Screen delta of one lane step, and of one row step, in logical pixels.
  final double laneX;
  final double laneY;
  final double rowX;
  final double rowY;
}

/// Mirrors NativeScene::navigatePlane (Qt/src/NativeSceneInput.cpp:99-115).
///
/// The plane is walked in whole cells: at most 64 steps, each one rounded with
/// floor(v + 0.5) from the start cell toward the goal, and the start cell itself is
/// skipped because Qt only selects when the step differs from the current cell. The
/// returned list is every cell Qt would select, in order, excluding the start cell.
List<SceneCell> sceneNavigationPath(SceneCell from, SceneCell goal) {
  if (goal == from) {
    return const <SceneCell>[];
  }
  final int steps = math.min(
    64,
    math.max((goal.lane - from.lane).abs(), (goal.row - from.row).abs()),
  );
  final List<SceneCell> path = <SceneCell>[];
  for (int index = 1; index <= steps; index += 1) {
    final int lane = (from.lane +
            (goal.lane - from.lane) * index / steps +
            0.5)
        .floor();
    final int row = (from.row + (goal.row - from.row) * index / steps + 0.5)
        .floor();
    final SceneCell cell = SceneCell(lane, row);
    if (cell == from) {
      continue;
    }
    if (path.isNotEmpty && path.last == cell) {
      continue;
    }
    path.add(cell);
  }
  return path;
}

/// Mirrors NativeScene::visibleCells (Qt/src/NativeSceneCamera.cpp:113-172).
///
/// A wider, far-shifted copy of the live projection is inverted to recover the eight
/// corners of the view volume. Corners outside the card height band are dropped and
/// the twelve edges are clipped against y = -6.5 and y = 6.5, so a camera looking
/// along the card plane still yields a bounded footprint. Lanes and rows within two
/// cells of that footprint are then tested against the frustum with the full card
/// shell, which is why the result may contain cells that end up culled per instance.
List<SceneCell> sceneVisibleCells({
  required double fov,
  required double width,
  required double height,
  required double fogFar,
  required SceneMatrix view,
  required double clipX,
  required double clipY,
  required double trackX,
  required double trackZ,
}) {
  final double far = math.min(300, math.max(6, fogFar + 8));
  SceneMatrix candidate = SceneMatrix.perspective(fov, width / height, 5, far);
  candidate = candidate.withLinearScale(1 / 1.18, 1 / 1.18);
  final Float64List withClip = Float64List.fromList(candidate.values);
  withClip[8] = clipX;
  withClip[9] = clipY;
  candidate = SceneMatrix.fromValues(withClip);
  final SceneMatrix matrix = candidate * view;
  final SceneFrustum frustum = SceneFrustum(matrix);
  final SceneMatrix inverse = matrix.inverse();
  if (inverse.isZero) {
    return const <SceneCell>[];
  }
  final List<SceneVector> vertices = <SceneVector>[];
  for (int index = 0; index < 8; index += 1) {
    vertices.add(
      inverse.point(
        SceneVector(
          index & 1 == 1 ? 1 : -1,
          index & 2 == 2 ? 1 : -1,
          index & 4 == 4 ? 1 : -1,
        ),
      ),
    );
  }
  double minimumX = 1e100;
  double minimumY = 1e100;
  double minimumZ = 1e100;
  double maximumX = -1e100;
  double maximumY = -1e100;
  double maximumZ = -1e100;
  void include(SceneVector point) {
    minimumX = math.min(minimumX, point.x);
    minimumY = math.min(minimumY, point.y);
    minimumZ = math.min(minimumZ, point.z);
    maximumX = math.max(maximumX, point.x);
    maximumY = math.max(maximumY, point.y);
    maximumZ = math.max(maximumZ, point.z);
  }

  for (final SceneVector vertex in vertices) {
    if (vertex.y >= -6.5 && vertex.y <= 6.5) {
      include(vertex);
    }
  }
  const List<List<int>> edges = <List<int>>[
    <int>[0, 1],
    <int>[0, 2],
    <int>[0, 4],
    <int>[1, 3],
    <int>[1, 5],
    <int>[2, 3],
    <int>[2, 6],
    <int>[3, 7],
    <int>[4, 5],
    <int>[4, 6],
    <int>[5, 7],
    <int>[6, 7],
  ];
  for (final List<int> edge in edges) {
    final SceneVector start = vertices[edge[0]];
    final SceneVector end = vertices[edge[1]];
    final double dy = end.y - start.y;
    if (dy.abs() < 1e-9) {
      continue;
    }
    for (final double plane in const <double>[-6.5, 6.5]) {
      final double amount = (plane - start.y) / dy;
      if (amount >= 0 && amount <= 1) {
        include(start.lerp(end, amount));
      }
    }
  }
  if (maximumX < minimumX) {
    return const <SceneCell>[];
  }
  final int minLane =
      ((minimumX - 2.8 + trackX) / 5.2 + 2).floor() - 1;
  final int maxLane =
      ((maximumX + 2.8 + trackX) / 5.2 + 2).ceil() + 1;
  final int minRow =
      ((minimumZ - 0.6 - trackZ) / 0.62 + 15.5).floor() - 2;
  final int maxRow =
      ((maximumZ + 0.6 - trackZ) / 0.62 + 15.5).ceil() + 2;
  final List<SceneCell> result = <SceneCell>[];
  for (int lane = minLane; lane <= maxLane; lane += 1) {
    for (int row = minRow; row <= maxRow; row += 1) {
      final double x = (lane - 2) * 5.2 - trackX;
      final double z = (row - 15.5) * 0.62 + trackZ;
      if (frustum.intersects(
        SceneVector(x - 2.8, -6.5, z - 1.2),
        SceneVector(x + 2.8, 6.5, z + 1.2),
      )) {
        result.add(SceneCell(lane, row));
      }
    }
  }
  return result;
}

// ===========================================================================
// Section 8 — the native backend port (ARCH_BLOCKED, reported not hidden)
// ===========================================================================

/// Mirrors Qt/src/SceneTypes.h:8-17 SceneDrawData.
///
/// One instanced draw: count matrices of 16 floats, count theme floats, and count
/// stable instance ids. Qt keeps these in QByteArrays handed straight to the GPU, so
/// the Flutter port keeps the same float32 layout and the same id list; the ids exist
/// because the motion-vector pass pairs matrices to instances by cell, not by draw
/// order (Qt/src/NativeSceneUpdate.cpp:17-19, 271).
class SceneDrawData {
  const SceneDrawData({
    required this.matrices,
    required this.themes,
    required this.ids,
  });

  /// count * 16 floats, column-major, the float32 form of the composed matrices
  /// (Qt/src/SceneMath.cpp:179-183).
  final Float32List matrices;

  /// count floats, the per-instance theme blend.
  final Float32List themes;

  /// count stable ids, one per matrix; empty when the draw carries no identity.
  final List<int> ids;

  int get count => ids.isNotEmpty
      ? ids.length
      : (themes.isNotEmpty ? themes.length : matrices.length ~/ 16);

  bool get isEmpty => count == 0;
}

/// Mirrors NativeScene::FrameTimings (Qt/src/NativeScene.h:49-54).
///
/// Qt fills these only while profiling is on, so every field defaults to zero and a
/// zero total means "not measured" rather than "instant".
class SceneFrameTimings {
  const SceneFrameTimings({
    this.simulateMs = 0,
    this.metadataMs = 0,
    this.buffersMs = 0,
    this.engineMs = 0,
  });

  final double simulateMs;
  final double metadataMs;
  final double buffersMs;
  final double engineMs;

  double get totalMs => simulateMs + metadataMs + buffersMs + engineMs;

  Map<String, double> toJson() => <String, double>{
        'simulateMs': simulateMs,
        'metadataMs': metadataMs,
        'buffersMs': buffersMs,
        'engineMs': engineMs,
      };
}

/// One host-side file or symbol the native rasteriser needs.
///
/// Every entry is a claim a reviewer can check in this tree: the path either exists
/// and lacks the symbol, or does not exist at all.
class NativeHostRequirement {
  const NativeHostRequirement({
    required this.path,
    required this.symbol,
    required this.purpose,
    required this.present,
  });

  /// Repository-relative path.
  final String path;

  /// The symbol, class or block the path must gain.
  final String symbol;

  /// Why the port needs it.
  final String purpose;

  /// Whether the path exists in this tree at baseline.
  final bool present;

  @override
  String toString() =>
      path + ' (' + (present ? 'exists, missing ' : 'absent, needs ') + symbol + ')';
}

/// The ARCH_BLOCKED report: what the native path needs and why it is not here.
class NativeBackendBlockage {
  const NativeBackendBlockage({
    required this.code,
    required this.summary,
    required this.requirements,
  });

  /// The gate name every writer in this card reports.
  static const String archBlocked = 'ARCH_BLOCKED';

  final String code;
  final String summary;
  final List<NativeHostRequirement> requirements;

  /// A multi-line rendering suitable for a report or a log line.
  String describe() {
    final StringBuffer buffer = StringBuffer()
      ..write(code)
      ..write(': ')
      ..writeln(summary);
    for (final NativeHostRequirement requirement in requirements) {
      buffer.writeln('  - ' + requirement.toString() + ': ' + requirement.purpose);
    }
    return buffer.toString().trimRight();
  }
}

/// The exact host work that ARCH_BLOCKED stands for.
///
/// Verified in this tree at baseline 8ed3067b0812eb2612f7841ec127a6e8ca93231b:
///   * android/app/build.gradle.kts exists and mentions the NDK only through
///     ndkVersion = flutter.ndkVersion (line 10); it has no externalNativeBuild
///     block, so no C++ target is compiled;
///   * android/app/src/main/cpp does not exist at all (find android -type f lists
///     no .cc/.cpp/.h/CMakeLists.txt);
///   * android/app/src/main/kotlin/rhine/music/database/MainActivity.kt is five
///     lines and simply extends FlutterActivity, so no texture is registered;
///   * pubspec.yaml has no assets: section (line 61 is the commented example), so
///     AssetBundle cannot read Assets/models/*.glb;
///   * there is no Dart texture bridge; Scene3D.qml's RhiScene (Qt/qml/Scene3D.qml
///     :17-21) has no Flutter equivalent in the tree.
class NativeSceneHostWiring {
  const NativeSceneHostWiring._();

  /// The blockage reported by [UnavailableNativeSceneBackend] and by every frame
  /// diagnostic that needs a rasteriser.
  static const NativeBackendBlockage blockage = NativeBackendBlockage(
    code: NativeBackendBlockage.archBlocked,
    summary:
        'native GLES/FlutterTexture backend is not in this tree: the Qt scene poses '
        'and picks, but no host code can rasterise the GLB cards',
    requirements: <NativeHostRequirement>[
      NativeHostRequirement(
        path: 'android/app/src/main/kotlin/rhine/music/database/MainActivity.kt',
        symbol: 'TextureRegistry entry registration in configureFlutterEngine',
        purpose:
            'Qt creates the QRhi swapchain itself; Flutter needs an Android surface '
            'texture whose id is handed to Dart so a Texture widget can display it',
        present: true,
      ),
      NativeHostRequirement(
        path: 'android/app/src/main/cpp/',
        symbol: 'CMakeLists.txt plus the GLES renderer sources',
        purpose:
            'no C++ directory exists, so nothing compiles the scene renderer, the '
            'shader set, or the GLB buffer upload',
        present: false,
      ),
      NativeHostRequirement(
        path: 'android/app/build.gradle.kts',
        symbol: 'externalNativeBuild { cmake { path } }',
        purpose:
            'the module currently builds no native code, so the renderer would not '
            'be packaged even if the sources existed',
        present: true,
      ),
      NativeHostRequirement(
        path: 'pubspec.yaml',
        symbol: 'flutter: assets: - Assets/models/ (and Assets/android-3d/)',
        purpose:
            'without the asset declaration GlbAssetSource cannot reach the two GLB '
            'files through AssetBundle, even though git tracks them',
        present: true,
      ),
      NativeHostRequirement(
        path: 'lib/spike/dart_hud/native_texture_bridge.dart',
        symbol: 'Texture widget fed by the registered texture id',
        purpose:
            'the Dart side must own the MethodChannel handshake and the widget that '
            'shows the external texture under the HUD layer',
        present: false,
      ),
    ],
  );
}

/// Everything a backend needs to start.
class NativeSceneBackendConfig {
  const NativeSceneBackendConfig({
    required this.width,
    required this.height,
    required this.devicePixelRatio,
    this.assetRoot = 'Assets/android-3d',
    this.reduced = false,
  });

  /// Logical surface size in pixels; the projection aspect comes from here
  /// (Qt/src/NativeScene.cpp:51).
  final int width;
  final int height;

  /// Physical pixel factor for the texture allocation.
  final double devicePixelRatio;

  /// Directory the scene fixtures live in, mirroring the root NativeScene receives
  /// (Qt/src/NativeScene.cpp:28-30).
  final String assetRoot;

  /// Reduced-motion flag Qt forwards to the viewer and the springs
  /// (Qt/src/NativeScene.cpp:203-216).
  final bool reduced;

  NativeSceneBackendConfig copyWith({
    int? width,
    int? height,
    double? devicePixelRatio,
    bool? reduced,
  }) =>
      NativeSceneBackendConfig(
        width: width ?? this.width,
        height: height ?? this.height,
        devicePixelRatio: devicePixelRatio ?? this.devicePixelRatio,
        assetRoot: assetRoot,
        reduced: reduced ?? this.reduced,
      );
}

/// One frame of renderer input, assembled from the frame the surface produced plus
/// the live matrices and the decoded models.
class NativeSceneRenderRequest {
  const NativeSceneRenderRequest({
    required this.time,
    required this.width,
    required this.height,
    required this.devicePixelRatio,
    required this.view,
    required this.projection,
    required this.aoProjection,
    required this.eye,
    required this.aim,
    required this.background,
    required this.fogColor,
    required this.fogNear,
    required this.fogFar,
    required this.detail,
    required this.focus,
    required this.aperture,
    required this.floorMatrix,
    required this.cards,
    required this.models,
    required this.frame,
  });

  /// The scene clock, the same value the frame carries as "time"
  /// (Qt/src/NativeSceneFrame.cpp:105).
  final double time;

  final int width;
  final int height;
  final double devicePixelRatio;

  final SceneMatrix view;
  final SceneMatrix projection;
  final SceneMatrix aoProjection;
  final SceneVector eye;
  final SceneVector aim;

  /// Linear-light colours, three components each
  /// (Qt/src/SceneAppearance.cpp:17-32).
  final List<double> background;
  final List<double> fogColor;
  final double fogNear;
  final double fogFar;

  /// The eased detail scalar the HUD keys off
  /// (Qt/src/NativeSceneFrame.cpp:116).
  final double detail;
  final double focus;
  final double aperture;

  /// The floor transform, compose({0, -4.63, 0}, {-pi/2, 0, 0})
  /// (Qt/src/NativeSceneFrame.cpp:62).
  final SceneMatrix floorMatrix;

  /// The instanced card draw, i.e. drawBuffers[10].
  final SceneDrawData cards;

  /// The decoded models so the renderer draws the shipped geometry; a backend that
  /// silently substitutes a placeholder would defeat the point of this port.
  final List<NativeSceneSurfaceModel> models;

  /// The frame the surface emitted, for keys the renderer may forward to the HUD.
  final Map<String, Object?> frame;
}

/// The injectable native rasteriser port.
///
/// Qt owns its GL context inside the same process, so NativeScene can draw inline.
/// Flutter cannot: the pixels must come back as an external texture. That is the one
/// capability this interface abstracts, and this tree ships only the honest
/// unavailable implementation.
///
/// Implementations must:
///   * report [isAvailable] truthfully and expose [blockage] when it is false;
///   * never return a texture id before a real context exists;
///   * upload the matrices and themes exactly as composed, without re-quantising the
///     double-precision scene math beyond the float32 narrowing Qt itself performs
///     (Qt/src/SceneMath.cpp:179-183);
///   * match [ScenePickingMesh] when they implement [raycast], because the Dart BVH
///     is the reference the fixture rays were captured against.
abstract interface class NativeSceneBackend {
  /// Stable name for diagnostics.
  String get label;

  /// True only when a real GL context exists and [render] can draw.
  bool get isAvailable;

  /// The blockage when [isAvailable] is false, otherwise null.
  NativeBackendBlockage? get blockage;

  /// The external texture id once the context exists, or null while it does not.
  int? get textureId;

  /// Creates the context and uploads the models.
  Future<void> init(NativeSceneBackendConfig config);

  /// Handles a surface or orientation change.
  void resize(NativeSceneBackendConfig config);

  /// Uploads one instanced draw (drawBuffers[10]).
  void uploadDrawBuffers(int id, SceneDrawData data);

  /// Draws one frame. Returns false when nothing was drawn, so a caller never
  /// mistakes a stale texture for a new one.
  bool render(NativeSceneRenderRequest request);

  /// Native raycast, mirroring NativePicking::raycast
  /// (Qt/src/NativePicking.cpp:231-249): returns the hit point in the mesh local
  /// space, or null. The Dart [ScenePickingMesh] is the reference implementation.
  SceneVector? raycast({
    required int mesh,
    required SceneVector origin,
    required SceneVector direction,
    required int side,
  });

  /// The last frame's timings (Qt/src/NativeScene.h:49-54).
  SceneFrameTimings get frameTimings;

  /// Releases the context and the texture. Idempotent.
  void dispose();
}

/// The backend this tree can actually run: none.
///
/// Every rasterising entry point throws [NativeBackendUnavailable] carrying
/// [NativeSceneHostWiring.blockage], so ARCH_BLOCKED surfaces at the first call
/// instead of as a blank rectangle that a screenshot could mistake for a working 3D
/// layer. The inspection members ([label], [isAvailable], [blockage], [textureId])
/// answer normally, because callers legitimately ask them before deciding what to do.
class UnavailableNativeSceneBackend implements NativeSceneBackend {
  const UnavailableNativeSceneBackend();

  /// Why this backend cannot draw, with the concrete host gaps.
  NativeBackendBlockage get blockage => NativeSceneHostWiring.blockage;

  NativeBackendUnavailable _refuse(String operation) => NativeBackendUnavailable(
        message: 'native GLES/FlutterTexture backend is unavailable: ' +
            operation +
            ' cannot run',
        blockage: NativeSceneHostWiring.blockage,
        detail: 'missing host wiring: ' +
            NativeSceneHostWiring.blockage.requirements.length.toString() +
            ' requirement(s), first is ' +
            NativeSceneHostWiring.blockage.requirements.first.toString(),
      );

  @override
  String get label => 'unavailable';

  @override
  bool get isAvailable => false;

  /// Null rather than a throwing getter: a widget may legitimately ask for a texture
  /// id while deciding whether to show a placeholder, and null is the true answer.
  @override
  int? get textureId => null;

  @override
  Future<void> init(NativeSceneBackendConfig config) async {
    throw _refuse('init');
  }

  @override
  void resize(NativeSceneBackendConfig config) {
    throw _refuse('resize');
  }

  @override
  void uploadDrawBuffers(int id, SceneDrawData data) {
    throw _refuse('uploadDrawBuffers(' + id.toString() + ')');
  }

  @override
  bool render(NativeSceneRenderRequest request) {
    throw _refuse('render');
  }

  @override
  SceneVector? raycast({
    required int mesh,
    required SceneVector origin,
    required SceneVector direction,
    required int side,
  }) {
    throw _refuse('raycast');
  }

  @override
  SceneFrameTimings get frameTimings => const SceneFrameTimings();

  @override
  void dispose() {
    // Nothing was ever created, so releasing is a no-op and stays idempotent.
  }
}

// ===========================================================================
// Section 9 — appearance colours, models, and the frame key table
// ===========================================================================

/// Qt/src/SceneAppearance.cpp:17-24, the sRGB to linear conversion every scene
/// colour goes through.
///
/// Qt builds a QColor from the hex string and maps each 0..255 channel:
/// c < 0.04045 ? c * 0.0773993808 : pow(c * 0.9478672986 + 0.0521327014, 2.4).
double sceneSrgbToLinear(double component) => component < 0.04045
    ? component * 0.0773993808
    : math.pow(component * 0.9478672986 + 0.0521327014, 2.4).toDouble();

/// Qt/src/SceneAppearance.cpp:17-24 SceneAppearance::color(hex).
///
/// Accepts #rgb, #rrggbb and #aarrggbb the way QColor does and returns the three
/// linear-light channels. An unparsable string is reported rather than defaulted,
/// because a wrong colour would silently change the whole scene.
List<double> sceneColorFromHex(String hex) {
  final String digits = hex.startsWith('#') ? hex.substring(1) : hex;
  String expand(int start, int length) => length == 1
      ? digits[start] + digits[start]
      : digits.substring(start, start + length);
  if (digits.length == 3) {
    return <double>[
      for (int index = 0; index < 3; index += 1)
        sceneSrgbToLinear(int.parse(expand(index, 1), radix: 16) / 255),
    ];
  }
  if (digits.length == 6 || digits.length == 8) {
    // QColor parses the 8-digit form as AARRGGBB, so the colour channels start at 2.
    final int offset = digits.length == 8 ? 2 : 0;
    return <double>[
      for (int channel = 0; channel < 3; channel += 1)
        sceneSrgbToLinear(
          int.parse(
                digits.substring(offset + channel * 2, offset + channel * 2 + 2),
                radix: 16,
              ) /
              255,
        ),
    ];
  }
  throw ArgumentError.value(
    hex,
    'hex',
    'expected a #rgb, #rrggbb or #aarrggbb colour',
  );
}

/// Qt/src/SceneAppearance.cpp:25-32 SceneAppearance::blend(from, to, amount).
///
/// A straight per-channel lerp in linear space, over the three colour channels.
List<double> sceneBlend(List<double> from, List<double> to, double amount) =>
    <double>[
      for (int index = 0; index < 3; index += 1)
        from[index] + (to[index] - from[index]) * amount,
    ];

/// The scene palette and the two blends the frame carries.
///
/// Qt/src/NativeSceneFrame.cpp:110-113 blends a light and a dark hex with the theme
/// scalar every frame, producing the background and fogColor keys. The parsed
/// colours are cached because the parse is the only part that is not a multiply.
class SceneAppearance {
  const SceneAppearance._();

  /// The light page colour Qt/src/NativeSceneFrame.cpp:110 uses.
  static const String lightBackground = '#eae5e1';

  /// The dark page colour Qt/src/NativeSceneFrame.cpp:111 uses.
  static const String darkBackground = '#11181b';

  /// The dark fog colour Qt/src/NativeSceneFrame.cpp:113 uses.
  static const String darkFog = '#263136';

  static final List<double> _light = sceneColorFromHex(lightBackground);
  static final List<double> _dark = sceneColorFromHex(darkBackground);
  static final List<double> _fog = sceneColorFromHex(darkFog);

  /// The cached linear-light form of a palette entry, by its hex string.
  static List<double> linear(String hex) {
    if (hex == lightBackground) {
      return _light;
    }
    if (hex == darkBackground) {
      return _dark;
    }
    if (hex == darkFog) {
      return _fog;
    }
    return sceneColorFromHex(hex);
  }

  /// Qt/src/NativeSceneFrame.cpp:110-111: blend(color(#eae5e1), color(#11181b),
  /// theme).
  static List<double> background(double theme) =>
      sceneBlend(_light, _dark, theme);

  /// Qt/src/NativeSceneFrame.cpp:112-113: blend(color(#eae5e1), color(#263136),
  /// theme).
  static List<double> fogColor(double theme) => sceneBlend(_light, _fog, theme);

  /// The culling sphere Qt takes from the appearance record
  /// (Qt/src/SceneAppearance.h:15-16).
  static const SceneVector boundsCenter = SceneVector(0, 1.85, 0);
  static const double boundsRadius = 3.3;
}

/// The facts the two shipped GLB files declare, so a check can prove the loaded
/// document is the real asset rather than a placeholder.
///
/// Every number below was read out of the files with a GLB parser at baseline
/// 8ed3067: chunk sizes, scene names, and the node, mesh, material and accessor
/// counts.
class NativeSceneModels {
  const NativeSceneModels._();

  /// The loose cassette the archive floor shows.
  static const String cassettePath = 'Assets/models/archive-cassette.glb';
  static const int cassetteBytes = 3565116;
  static const int cassetteJsonBytes = 18252;
  static const int cassetteBinaryBytes = 3546836;
  static const String cassetteSceneName = 'Rhine_Archive_Asset';
  static const int cassetteNodes = 17;
  static const int cassetteMeshes = 17;
  static const int cassetteMaterials = 17;
  static const int cassetteAccessors = 65;

  /// The card assembly the detail viewer explodes.
  static const String assemblyPath = 'Assets/models/archive-assembly.glb';
  static const int assemblyBytes = 3343744;
  static const int assemblyJsonBytes = 22768;
  static const int assemblyBinaryBytes = 3320948;
  static const String assemblySceneName = 'Rhine_Assembly_Asset.012';
  static const int assemblyNodes = 22;
  static const int assemblyMeshes = 22;
  static const int assemblyMaterials = 16;
  static const int assemblyAccessors = 81;

  /// The card shell the assembly cover and Qt DiscGeometry agree on
  /// (Qt/src/DiscGeometry.h:5, and accessor 0 of archive-assembly.glb whose declared
  /// bounds are x in [-2.5, 2.5], y in [0, 3.7]).
  static const SceneVector shellMinimum = SceneVector(-2.5, 0, 0);
  static const SceneVector shellMaximum = SceneVector(2.5, 3.7, 0.62);

  /// The extensions both shipped files declare.
  static const List<String> extensionsUsed = <String>[
    'KHR_materials_transmission',
    'KHR_materials_ior',
  ];
}

/// One decoded GLB plus the picking meshes built from it.
class NativeSceneSurfaceModel {
  const NativeSceneSurfaceModel({
    required this.name,
    required this.container,
    required this.scene,
    required this.meshes,
  });

  /// Decodes a GLB already in memory.
  factory NativeSceneSurfaceModel.fromBytes(String name, Uint8List bytes) {
    final GlbContainer container = GlbContainer.parse(bytes);
    return NativeSceneSurfaceModel.fromContainer(name, container);
  }

  /// Decodes an already parsed container.
  factory NativeSceneSurfaceModel.fromContainer(
    String name,
    GlbContainer container,
  ) {
    final GltfScene scene = GltfScene.fromContainer(container);
    return NativeSceneSurfaceModel(
      name: name,
      container: container,
      scene: scene,
      // A mesh that cannot become a picking mesh degrades to an empty one rather than
      // failing the load: picking then misses that mesh exactly as Qt does when
      // load() bails out (Qt/src/NativePicking.cpp:135-139), while the rest of the
      // document stays usable.
      meshes: List<ScenePickingMesh>.unmodifiable(<ScenePickingMesh>[
        for (int index = 0; index < scene.meshes.length; index += 1)
          _pickingMeshOrEmpty(scene, index),
      ]),
    );
  }

  /// Decodes through an injectable byte source, which is how the same model loads
  /// from an AssetBundle on device, from a file in a harness, or from memory in a
  /// test.
  static Future<NativeSceneSurfaceModel> load(
    String name,
    GlbByteSource source,
  ) async {
    final GlbContainer container = await source.load();
    return NativeSceneSurfaceModel.fromContainer(name, container);
  }

  static ScenePickingMesh _pickingMeshOrEmpty(GltfScene scene, int index) {
    try {
      return ScenePickingMesh.fromGltf(scene, index);
    } on NativeSceneFailure {
      return ScenePickingMesh.empty();
    }
  }

  /// Diagnostic name, normally the asset path.
  final String name;

  final GlbContainer container;
  final GltfScene scene;

  /// One picking mesh per glTF mesh in document order, which is the index space
  /// SceneAppearance::pickingMeshes uses.
  final List<ScenePickingMesh> meshes;

  int get nodeCount => scene.nodes.length;
  int get meshCount => scene.meshes.length;
  int get materialCount => scene.materials.length;
  int get accessorCount => scene.accessors.length;
  int get binaryBytes => container.binary?.length ?? 0;

  bool get isUsable =>
      container.version == GlbContainer.supportedVersion &&
      binaryBytes > 0 &&
      nodeCount > 0;

  /// Triangles across every mesh, the honest measure of how much geometry loaded.
  int get triangleCount {
    int total = 0;
    for (final ScenePickingMesh mesh in meshes) {
      total += mesh.triangleCount;
    }
    return total;
  }

  /// Bounds of the cover parts, or null when the file marks no cover node.
  ///
  /// archive-assembly.glb tags its cover meshes with extras.assemblyPart equal to
  /// cover; the union of their POSITION min and max is the shell this port claims.
  (SceneVector, SceneVector)? coverBounds() {
    double minX = double.infinity;
    double minY = double.infinity;
    double minZ = double.infinity;
    double maxX = double.negativeInfinity;
    double maxY = double.negativeInfinity;
    double maxZ = double.negativeInfinity;
    bool found = false;
    for (final GltfNode node in scene.nodesForPart('cover')) {
      // A node may name a mesh that is absent from a trimmed document; skipping it
      // keeps the union honest instead of throwing on a range error.
      if (node.mesh < 0 || node.mesh >= scene.meshes.length) {
        continue;
      }
      for (final GltfPrimitive primitive in scene.meshes[node.mesh].primitives) {
        if (primitive.position < 0) {
          continue;
        }
        final (List<double> low, List<double> high) =
            scene.declaredBounds(primitive.position);
        if (low.length < 3 || high.length < 3) {
          continue;
        }
        found = true;
        minX = math.min(minX, low[0]);
        minY = math.min(minY, low[1]);
        minZ = math.min(minZ, low[2]);
        maxX = math.max(maxX, high[0]);
        maxY = math.max(maxY, high[1]);
        maxZ = math.max(maxZ, high[2]);
      }
    }
    if (!found) {
      return null;
    }
    return (SceneVector(minX, minY, minZ), SceneVector(maxX, maxY, maxZ));
  }

  /// One line describing what was decoded, for a report or a log.
  String describe() =>
      name +
      ': ' +
      container.byteLength.toString() +
      ' B, glTF ' +
      container.assetVersion +
      ', ' +
      nodeCount.toString() +
      ' nodes, ' +
      meshCount.toString() +
      ' meshes, ' +
      materialCount.toString() +
      ' materials, ' +
      accessorCount.toString() +
      ' accessors, ' +
      binaryBytes.toString() +
      ' B binary, ' +
      triangleCount.toString() +
      ' pick triangles';
}

/// The frame key table of NativeScene::emitFrame
/// (Qt/src/NativeSceneFrame.cpp:87-119) plus the keys it appends.
///
/// The literal is written in this exact order and the appended keys follow, which is
/// why the emitted map has 35 keys. The Android capture in
/// Assets/android-3d/scene-fixture.json has 33: it drops returningAgeMax,
/// actorTemplate, appearanceRevision and actors, and adds discAngle (written by
/// Qt/src/Engine.cpp:1248, outside the scene) and originalActorBlend (an
/// Android-port-only key with no producer anywhere in Qt/src, recorded here rather
/// than invented).
class NativeSceneFrame {
  const NativeSceneFrame._();

  /// The 31 keys the initialiser list writes, in source order.
  static const List<String> keys = <String>[
    'pendingAnimations',
    'pointerCursor',
    'aoProjection',
    'reference',
    'near',
    'far',
    'viewer',
    'viewerReady',
    'viewerState',
    'mode',
    'selected',
    'culledCards',
    'shadowCards',
    'returningCards',
    'returningPartNodes',
    'globalSubdued',
    'returningMusicKeys',
    'returningAgeMax',
    'time',
    'draws',
    'view',
    'projection',
    'eye',
    'background',
    'fogColor',
    'fogNear',
    'fogFar',
    'detail',
    'boot',
    'focus',
    'aperture',
  ];

  /// The four keys emitFrame adds after the literal
  /// (Qt/src/NativeSceneFrame.cpp:162-166 and 195).
  static const List<String> appendedKeys = <String>[
    'actorTemplate',
    'appearanceRevision',
    'actors',
    'stats',
  ];

  /// The two capture-only keys, each with the reason it is outside emitFrame.
  static const List<String> captureOnlyKeys = <String>[
    'discAngle',
    'originalActorBlend',
  ];

  /// The near plane the frame reports, a literal 5
  /// (Qt/src/NativeSceneFrame.cpp:91).
  static const double near = 5;

  /// The far plane the frame reports, a literal 300
  /// (Qt/src/NativeSceneFrame.cpp:92).
  static const double far = 300;

  /// The initial fog range from the member defaults
  /// (Qt/src/NativeScene.h:131-132); updateCamera replaces both once a frame runs.
  static const double initialFogNear = 22;
  static const double initialFogFar = 47;

  /// Qt/src/NativeSceneFrame.cpp:116: smooth((m_detail - 0.25) / 0.55).
  static double detailScalar(double mDetail) =>
      sceneSmooth((mDetail - 0.25) / 0.55);

  /// Builds the frame in emitFrame order.
  ///
  /// The derived keys cannot be passed in: detail is always [detailScalar] of the raw
  /// scalar and background and fogColor are always the theme blends, so a caller
  /// cannot desynchronise the HUD mask from the camera with a hand-written detail
  /// value.
  static Map<String, Object?> build({
    required SceneMatrix view,
    required SceneMatrix projection,
    required SceneMatrix aoProjection,
    required SceneVector eye,
    double time = 0,
    String mode = 'boot',
    int selected = 0,
    double theme = 0,
    double detailRaw = 0,
    double fogNear = initialFogNear,
    double fogFar = initialFogFar,
    double focus = 0,
    double aperture = 0,
    bool pendingAnimations = false,
    String pointerCursor = 'default',
    bool reference = false,
    int culledCards = 0,
    int shadowCards = 0,
    int returningCards = 0,
    int returningPartNodes = 0,
    double globalSubdued = 0,
    double returningAgeMax = 0,
    List<String> returningMusicKeys = const <String>[],
    List<Object?> draws = const <Object?>[],
    List<Object?> actors = const <Object?>[],
    Object? actorTemplate,
    double appearanceRevision = 0,
    Object? boot,
    Object? stats,
    bool viewer = false,
    bool viewerReady = false,
    Map<String, Object?> viewerState = const <String, Object?>{},
  }) =>
      <String, Object?>{
        'pendingAnimations': pendingAnimations,
        'pointerCursor': pointerCursor,
        'aoProjection': aoProjection.toJson(),
        'reference': reference,
        'near': near,
        'far': far,
        'viewer': viewer,
        'viewerReady': viewerReady,
        'viewerState': viewerState,
        'mode': mode,
        'selected': selected,
        'culledCards': culledCards,
        'shadowCards': shadowCards,
        'returningCards': returningCards,
        'returningPartNodes': returningPartNodes,
        'globalSubdued': globalSubdued,
        'returningMusicKeys': returningMusicKeys,
        'returningAgeMax': returningAgeMax,
        'time': time,
        'draws': draws,
        'view': view.toJson(),
        'projection': projection.toJson(),
        'eye': eye.toJson(),
        'background': SceneAppearance.background(theme),
        'fogColor': SceneAppearance.fogColor(theme),
        'fogNear': fogNear,
        'fogFar': fogFar,
        'detail': detailScalar(detailRaw),
        'boot': boot,
        'focus': focus,
        'aperture': aperture,
        'actorTemplate': actorTemplate,
        'appearanceRevision': appearanceRevision,
        'actors': actors,
        'stats': stats,
      };

  /// The statistics object Qt builds at Qt/src/NativeSceneFrame.cpp:195-213.
  ///
  /// Every field is passed in rather than defaulted: a key present but zero means
  /// something different from a key that was never computed, and the counters depend
  /// on the visible-cell pass that the surface runs.
  static Map<String, Object?> stats({
    required bool loaded,
    required double fieldOfView,
    required SceneVector cameraPosition,
    required SceneVector modelPosition,
    required SceneCell selectedCell,
    required int selectedSlot,
    required int archiveCount,
    required int archiveCandidates,
    required int returningFiles,
    required double clearance,
    required SceneCell coordinateOrigin,
    required bool holdingArchive,
    List<Map<String, Object?>> pulses = const <Map<String, Object?>>[],
  }) =>
      <String, Object?>{
        'loaded': loaded,
        'fieldOfView': fieldOfView,
        'modelPosition': <double>[
          sceneFrameRound(modelPosition.x),
          sceneFrameRound(modelPosition.y),
          sceneFrameRound(modelPosition.z),
        ],
        'cameraPosition': <double>[
          sceneFrameRound(cameraPosition.x),
          sceneFrameRound(cameraPosition.y),
          sceneFrameRound(cameraPosition.z),
        ],
        'selectedCell': <String, int>{
          'lane': selectedCell.lane,
          'row': selectedCell.row,
        },
        'selectedSlot': selectedSlot,
        'archiveCount': archiveCount,
        'archiveCandidates': archiveCandidates,
        'returningFiles': returningFiles,
        'clearance': clearance,
        'coordinateOrigin': <String, int>{
          'lane': coordinateOrigin.lane,
          'row': coordinateOrigin.row,
        },
        'holdingArchive': holdingArchive,
        'pulses': pulses,
      };

  /// Qt/src/NativeSceneFrame.cpp:178-181: floor(v * 10000 + 0.5) / 10000.
  static double sceneFrameRound(double value) =>
      (value * 10000 + 0.5).floorToDouble() / 10000;
}

// ===========================================================================
// Section 10 — camera, culling, and the surface that ties the port together
// ===========================================================================

/// The camera the scene opens with and the matrices derived from it.
///
/// Qt keeps this state on NativeScene: the eye, aim and fov members are seeded from
/// Qt/src/NativeScene.h:123-128 and Qt/src/NativeScene.cpp:49-52 builds the three
/// matrices from them, while Qt/src/NativeSceneCamera.cpp:13-107 replaces all of it
/// every update. This port keeps the same split: the constructors here produce exactly
/// what NativeScene.cpp:49-52 produces, and [NativeSceneCameraState] carries what
/// updateCamera would have converged to.
class NativeSceneCamera {
  const NativeSceneCamera._();

  /// The eye the scene starts at (Qt/src/NativeScene.cpp:49).
  static const SceneVector defaultEye = SceneVector(-62.26, 35.98, 43.28);

  /// The aim the scene starts at (Qt/src/NativeScene.cpp:49).
  static const SceneVector defaultAim = SceneVector(-0.5, 1.1, 0.4);

  /// The initial field of view (Qt/src/NativeScene.h:128 and
  /// Qt/src/NativeScene.cpp:51). updateCamera converges to about 2.999 degrees on a
  /// 16:9 surface, which is why the shipped fixture reports 2.999269163161202 rather
  /// than 6.15; this value is only the seed.
  static const double fieldOfView = 6.15;

  /// The field of view the archive overlay projection uses
  /// (Qt/src/NativeScene.cpp:52).
  static const double aoFieldOfView = 34;

  /// The near and far planes both projections use
  /// (Qt/src/NativeScene.cpp:51-52).
  static const double nearPlane = 5;
  static const double farPlane = 300;

  /// The clip-space nudges the archive overlay applies so the mask and the label edges
  /// stay aligned (Qt/src/NativeSceneCamera.cpp:104-105).
  static const double archiveOffsetX = 0.16;
  static const double archiveOffsetY = 0.20;

  /// Aspect from the logical surface size, clamped the way resize() clamps
  /// (Qt/src/NativeScene.cpp:217-224 uses max(1.0, ...) per axis).
  static double aspect(double width, double height) =>
      math.max(1, width) / math.max(1, height);

  /// Qt/src/NativeSceneCamera.cpp:98: perspective(m_fov, aspect, 5, 300).
  static SceneMatrix projection({
    required double fov,
    required double width,
    required double height,
  }) =>
      SceneMatrix.perspective(fov, aspect(width, height), nearPlane, farPlane);

  /// Qt/src/NativeScene.cpp:52: perspective(34, w / h, 5, 300), before the archive
  /// offset is applied.
  static SceneMatrix overlayProjection({
    required double width,
    required double height,
  }) =>
      SceneMatrix.perspective(
        aoFieldOfView,
        aspect(width, height),
        nearPlane,
        farPlane,
      );

  /// Qt/src/NativeSceneCamera.cpp:104-105: the archive overlay is the main projection
  /// with values[8] and values[9] nudged, not a separately built matrix.
  ///
  /// [detailProgress] is smooth((m_detail - 0.25) / 0.55); the offset scales with
  /// 1 - detailProgress and is zero while booting or under the cinematic camera
  /// (Qt/src/NativeSceneCamera.cpp:100-105).
  static SceneMatrix archiveOverlay({
    required SceneMatrix projection,
    required double detailProgress,
    required bool offsetApplies,
  }) {
    if (!offsetApplies) {
      return projection;
    }
    final double offset = 1 - detailProgress;
    return projection.withClipOffset(
      archiveOffsetX * offset,
      archiveOffsetY * offset,
    );
  }

  /// Qt/src/NativeScene.cpp:50: camera(eye, aim).inverse().
  static SceneMatrix view(SceneVector eye, SceneVector aim) =>
      SceneMatrix.camera(eye, aim).inverse();

  /// Qt/src/NativeSceneCamera.cpp:94-97: the fog range follows the rendered distance,
  /// so it slides with the camera instead of sitting at a fixed depth.
  ///
  /// renderedDistance = (eye - aim).length; fogNear = distance +
  /// lerp(5 - 4 * theme, -1, detail); fogFar = distance + lerp(25 - 9 * theme, 12,
  /// detail).
  static (double, double) fog({
    required SceneVector eye,
    required SceneVector aim,
    required double theme,
    required double detail,
  }) {
    final double distance = (eye - aim).length;
    return (
      distance + (5 - 4 * theme) + (-1 - (5 - 4 * theme)) * detail,
      distance + (25 - 9 * theme) + (12 - (25 - 9 * theme)) * detail,
    );
  }
}

/// One actor's per-instance state, the 20 doubles Qt appends to actorBytes
/// (Qt/src/NativeSceneFrame.cpp:139-148).
///
/// The matrix is 16 column-major doubles, then quality, clarity, theme and a reserved
/// zero. Qt copies the doubles straight out of a double array, so the byte order is the
/// host order; [toBytes] reproduces that with a Float64List because this port has no
/// other way to hand a backend the same buffer.
class SceneActorState {
  const SceneActorState({
    required this.matrix,
    required this.quality,
    required this.clarity,
    required this.theme,
  });

  /// Doubles per actor: 16 matrix + 4 scalars.
  static const int stride = 20;

  final SceneMatrix matrix;
  final double quality;
  final double clarity;
  final double theme;

  /// The 20 doubles in Qt order.
  List<double> toDoubles() => <double>[
        ...matrix.values,
        quality,
        clarity,
        theme,
        0,
      ];

  /// The same 20 values as bytes, matching the memcpy of the double array.
  Float64List toBytes() => Float64List.fromList(toDoubles());

  /// The JSON record emitFrame appends per actor
  /// (Qt/src/NativeSceneFrame.cpp:154-160).
  ///
  /// Qt writes a null musicKey when the string is empty rather than an empty string,
  /// so the key survives a round trip through the diagnostic capture.
  Map<String, Object?> toJson({
    required int id,
    required String musicKey,
    required bool selected,
    required bool shadowOnly,
  }) =>
      <String, Object?>{
        'id': id,
        'musicKey': musicKey.isEmpty ? null : musicKey,
        'selected': selected,
        'shadowOnly': shadowOnly,
      };
}

/// Why a card is or is not drawn, mirroring the two counters and the shadow flag of
/// NativeScene::emitFrame (Qt/src/NativeSceneFrame.cpp:120-151).
class SceneCardVisibility {
  const SceneCardVisibility._({
    required this.visible,
    required this.shadowOnly,
  });

  /// Drawn normally.
  static const SceneCardVisibility drawn =
      SceneCardVisibility._(visible: true, shadowOnly: false);

  /// Outside the camera frustum but inside the light frustum: the card still casts
  /// its shadow, which is the case Qt counts in shadowCards.
  static const SceneCardVisibility shadow =
      SceneCardVisibility._(visible: true, shadowOnly: true);

  /// Dropped entirely, the case Qt counts in culledCards.
  static const SceneCardVisibility culled =
      SceneCardVisibility._(visible: false, shadowOnly: false);

  final bool visible;
  final bool shadowOnly;
}

/// The two-stage cull of NativeScene::emitFrame
/// (Qt/src/NativeSceneFrame.cpp:120-138).
///
/// A card is tested against the camera frustum first. A card that fails is still kept
/// when the light frustum, built from camera({-6, 14, -5}, origin).inverse(), puts it
/// within the shadow box, because the shadow is what the floor needs. Only a card
/// outside both is culled. The selected actor and the returning cards skip the test
/// because Qt only culls when the actor is not selected.
class SceneCardCulling {
  const SceneCardCulling._();

  /// The light the shadow box is built from
  /// (Qt/src/NativeSceneFrame.cpp:123).
  static const SceneVector lightEye = SceneVector(-6, 14, -5);

  /// The light aims at the origin, which is the empty target Qt passes.
  static const SceneVector lightAim = SceneVector(0, 0, 0);

  /// Half extents of the shadow box in light space
  /// (Qt/src/NativeSceneFrame.cpp:134). Both are widened by the culling radius.
  static const double shadowExtentX = 16.1;
  static const double shadowExtentY = 15.1;

  /// Qt inflates the appearance radius by 0.1 before every test
  /// (Qt/src/NativeSceneFrame.cpp:128-129), so a 3.3 radius card culls as 3.4.
  static const double radiusPadding = 0.1;

  /// The measured radius of one card (Qt/src/SceneAppearance.h:16).
  static const double boundsRadius = 3.3;

  /// Classifies one card.
  ///
  /// [cameraFrustum] is built from projection * view and [lightView] from
  /// camera(lightEye, lightAim).inverse(); both are passed in because Qt rebuilds them
  /// once per frame rather than per card.
  static SceneCardVisibility classify({
    required SceneMatrix cardMatrix,
    required SceneFrustum cameraFrustum,
    required SceneMatrix lightView,
    required bool selected,
    required bool cullingEnabled,
    SceneVector boundsCenter = SceneAppearance.boundsCenter,
  }) {
    if (selected || !cullingEnabled) {
      return SceneCardVisibility.drawn;
    }
    final double radius = boundsRadius + radiusPadding;
    final SceneVector center = cardMatrix.point(boundsCenter);
    if (cameraFrustum.intersectsSphere(center, radius)) {
      return SceneCardVisibility.drawn;
    }
    final SceneVector light = lightView.point(center);
    if (light.x.abs() > shadowExtentX + radius ||
        light.y.abs() > shadowExtentY + radius) {
      return SceneCardVisibility.culled;
    }
    return SceneCardVisibility.shadow;
  }
}

/// The camera state the surface reports and the HUD masks against.
///
/// A plain mutable record of exactly the members updateCamera writes
/// (Qt/src/NativeSceneCamera.cpp:89-107), kept separate from the surface so the
/// reactive shell can rebuild on it without owning the renderer.
class NativeSceneCameraState {
  NativeSceneCameraState({
    this.eye = NativeSceneCamera.defaultEye,
    this.aim = NativeSceneCamera.defaultAim,
    this.fov = NativeSceneCamera.fieldOfView,
    this.fogNear = NativeSceneFrame.initialFogNear,
    this.fogFar = NativeSceneFrame.initialFogFar,
    this.detail = 0,
    this.focus = 0,
    this.aperture = 0,
  });

  SceneVector eye;
  SceneVector aim;
  double fov;
  double fogNear;
  double fogFar;
  double detail;
  double focus;
  double aperture;

  /// The frame's detail key, the eased scalar rather than the raw one
  /// (Qt/src/NativeSceneFrame.cpp:116).
  double get detailProgress => NativeSceneFrame.detailScalar(detail);
}

/// The 3D slice: camera state, picking, culling and the frame, with rasterisation
/// delegated to an injected [NativeSceneBackend].
///
/// The surface is deliberately the same shape as Qt NativeScene: it owns no pixels.
/// Qt could draw inline because it owns a GL context; here the pixels must come back
/// as an external texture, so [backend] is the only rasterising path and this tree can
/// only supply [UnavailableNativeSceneBackend]. Everything the surface does itself,
/// the camera matrices, the picking, the culling, the frame map, is real and is what a
/// device build would upload.
///
/// ARCH_BLOCKED, recorded here because a reader of this file must not mistake the
/// port for a working 3D layer:
///   * there is no FlutterTexture bridge: lib/ has no dart:ffi texture registration and
///     android/app/src/main/kotlin/rhine/music/database/MainActivity.kt is 5 lines with
///     no TextureRegistry call;
///   * there is no native rasteriser: android/app/src/main/cpp does not exist and
///     android/app/build.gradle.kts has no externalNativeBuild block;
///   * GLB decoding to GPU meshes needs that native side, so this file decodes the real
///     GLB containers in Dart for verification and hands the decoded document to the
///     backend rather than pretending to draw;
///   * pubspec.yaml has no assets section, so the shipped GLB files are not reachable
///     through an AssetBundle in this tree (BLK-PUBSPEC-ASSETS).
class NativeSceneSurface {
  NativeSceneSurface({
    required this.backend,
    required this.slots,
    required this.models,
    required this.width,
    required this.height,
    this.reduced = false,
    String mode = 'boot',
    int selected = 0,
    double theme = 0,
    bool cullingEnabled = true,
    NativeSceneCameraState? camera,
  })  : mode = mode,
        selected = selected,
        theme = theme,
        cullingEnabled = cullingEnabled,
        camera = camera ?? NativeSceneCameraState(),
        _failure = null;

  /// The backend that cannot draw, for a caller that wants the surface's shape without
  /// a rasteriser.
  factory NativeSceneSurface.unavailable({
    required SceneSlotTable slots,
    required List<NativeSceneSurfaceModel> models,
    required int width,
    required int height,
    bool reduced = false,
  }) =>
      NativeSceneSurface(
        backend: const UnavailableNativeSceneBackend(),
        slots: slots,
        models: models,
        width: width,
        height: height,
        reduced: reduced,
      );

  /// Rasterises the slice. Never available in this tree; see the class document.
  final NativeSceneBackend backend;

  /// The slot plane the cards are laid out on, from slots.json.
  final SceneSlotTable slots;

  /// The decoded GLB documents, cassette first because picking mesh 0 is the mesh a
  /// drawn card tests (Qt/src/NativeSceneInput.cpp:73).
  final List<NativeSceneSurfaceModel> models;

  final NativeSceneCameraState camera;
  final bool reduced;

  int width;
  int height;
  String mode;
  int selected;
  double theme;

  /// Whether the emitFrame cull runs, the m_drawCulling flag of
  /// Qt/src/NativeSceneFrame.cpp:126.
  final bool cullingEnabled;

  String? _failure;

  /// Timings of the last frame the backend actually drew; null until then.
  SceneFrameTimings? lastTimings;

  /// Non-null when the surface cannot produce a frame, which in this tree is always
  /// the missing native host (Qt/src/NativeScene.cpp:44-47 sets the same member when
  /// its assets are missing).
  String? get failure => _failure ?? slots.failure;

  /// True when a frame can be described, not when it can be drawn.
  bool get ready => failure == null;

  /// The picking meshes, taken from the first model because SceneAppearance exposes
  /// one list for the whole plane.
  List<ScenePickingMesh> get pickingMeshes =>
      models.isEmpty ? const <ScenePickingMesh>[] : models.first.meshes;

  SceneMatrix get view => NativeSceneCamera.view(camera.eye, camera.aim);

  SceneMatrix get projection => NativeSceneCamera.projection(
        fov: camera.fov,
        width: width.toDouble(),
        height: height.toDouble(),
      );

  /// Qt/src/NativeSceneCamera.cpp:104-107: the overlay is the main projection with the
  /// archive offset, and the offset is zero while booting.
  SceneMatrix get overlayProjection => NativeSceneCamera.archiveOverlay(
        projection: projection,
        detailProgress: camera.detailProgress,
        offsetApplies: mode != 'boot',
      );

  /// The floor transform, compose({0, -4.63, 0}, {-pi/2, 0, 0})
  /// (Qt/src/NativeSceneFrame.cpp:62).
  static SceneMatrix floorMatrix() => SceneMatrix.compose(
        const SceneVector(0, -4.63, 0),
        const SceneVector(-math.pi / 2, 0, 0),
      );

  /// Creates the backend and uploads the models.
  ///
  /// Propagates [NativeBackendUnavailable] rather than swallowing it: a caller that
  /// ignored [NativeSceneBackend.isAvailable] should see the blockage, not a silent
  /// null texture that a screenshot could mistake for a working layer.
  Future<void> load() async {
    await backend.init(
      NativeSceneBackendConfig(
        width: width,
        height: height,
        devicePixelRatio: 1,
        reduced: reduced,
      ),
    );
  }

  /// Qt/src/NativeScene.cpp:217-224: reallocate the matrices for a new surface size,
  /// then hand the size to the renderer.
  void resize(int nextWidth, int nextHeight) {
    width = math.max(1, nextWidth);
    height = math.max(1, nextHeight);
    if (backend.isAvailable) {
      backend.resize(
        NativeSceneBackendConfig(
          width: width,
          height: height,
          devicePixelRatio: 1,
          reduced: reduced,
        ),
      );
    }
  }

  /// Qt/src/NativeScene.cpp:76-78 mapped through the slot table's cellPosition.
  SceneVector cellPosition(SceneCell cell) => SceneSlotTable.cellPosition(cell);

  /// The camera the frame would use, after the fog range is derived from the aim.
  void updateFog() {
    final (double near, double far) = NativeSceneCamera.fog(
      eye: camera.eye,
      aim: camera.aim,
      theme: theme,
      detail: camera.detail,
    );
    camera.fogNear = near;
    camera.fogFar = far;
  }

  /// Picks a card, mirroring NativeScene::pick
  /// (Qt/src/NativeSceneInput.cpp:36-97).
  ///
  /// [cards] are the instances the caller considers drawn, in draw order; every one is
  /// tested with allMeshes false, because Qt only tests mesh 0 for drawn cards. Pass
  /// the live actor and the returning cards through [extra] so they test every mesh.
  SceneCell? pick({
    required double x,
    required double y,
    required List<SceneCardInstance> cards,
    List<SceneCardInstance> extra = const <SceneCardInstance>[],
  }) =>
      NativeScenePicker(pickingMeshes).pick(
        x: x,
        y: y,
        width: width.toDouble(),
        height: height.toDouble(),
        projection: projection,
        view: view,
        eye: camera.eye,
        drawn: cards,
        extra: extra,
      );

  /// The visible cells of NativeSceneCamera.cpp:113-172.
  List<SceneCell> visibleCells({double trackX = 0, double trackZ = 0}) =>
      sceneVisibleCells(
        fov: camera.fov,
        width: width.toDouble(),
        height: height.toDouble(),
        fogFar: camera.fogFar,
        view: view,
        clipX: overlayProjection.clipX,
        clipY: overlayProjection.clipY,
        trackX: trackX,
        trackZ: trackZ,
      );

  /// Builds the frame this surface would hand the HUD.
  ///
  /// The key table, the derived detail scalar and the theme blends all come from
  /// [NativeSceneFrame], so this method only supplies the live values. The draws list
  /// carries one entry per instanced draw plus the floor, matching the order
  /// emitFrame appends them in (Qt/src/NativeSceneFrame.cpp:64-78: floor first, then
  /// every appearance instance).
  Map<String, Object?> emitFrame({
    required double time,
    required List<Map<String, Object?>> draws,
    required List<Map<String, Object?>> actorJson,
    int culledCards = 0,
    int shadowCards = 0,
    int returningCards = 0,
    int returningPartNodes = 0,
    double globalSubdued = 0,
    List<String> returningMusicKeys = const <String>[],
    double returningAgeMax = 0,
    bool pendingAnimations = false,
    String pointerCursor = 'default',
    bool reference = false,
    bool viewer = false,
    bool viewerReady = false,
    Map<String, Object?> viewerState = const <String, Object?>{},
    Object? actorTemplate,
    double appearanceRevision = 0,
    Object? boot,
    Object? stats,
  }) {
    updateFog();
    return NativeSceneFrame.build(
      view: view,
      projection: projection,
      aoProjection: overlayProjection,
      eye: camera.eye,
      time: time,
      mode: mode,
      selected: selected,
      theme: theme,
      detailRaw: camera.detail,
      fogNear: camera.fogNear,
      fogFar: camera.fogFar,
      focus: camera.focus,
      aperture: camera.aperture,
      pendingAnimations: pendingAnimations,
      pointerCursor: pointerCursor,
      reference: reference,
      culledCards: culledCards,
      shadowCards: shadowCards,
      returningCards: returningCards,
      returningPartNodes: returningPartNodes,
      globalSubdued: globalSubdued,
      returningMusicKeys: returningMusicKeys,
      returningAgeMax: returningAgeMax,
      draws: draws,
      actors: actorJson,
      actorTemplate: actorTemplate,
      appearanceRevision: appearanceRevision,
      boot: boot,
      stats: stats,
      viewer: viewer,
      viewerReady: viewerReady,
      viewerState: viewerState,
    );
  }

  /// Draws one frame through the backend.
  ///
  /// Returns false when the backend drew nothing, so a stale texture can never be
  /// presented as a new frame. Throws [NativeBackendUnavailable] in this tree.
  bool render(Map<String, Object?> frame, {required SceneDrawData cards}) {
    // No isAvailable branch: an unavailable backend throws from render() with the
    // blockage attached, which is louder than a silent false and cannot be mistaken
    // for a drawn frame.
    final bool drew = backend.render(
      NativeSceneRenderRequest(
        time: frame['time'] is double ? frame['time']! as double : 0,
        width: width,
        height: height,
        devicePixelRatio: 1,
        view: view,
        projection: projection,
        aoProjection: overlayProjection,
        eye: camera.eye,
        aim: camera.aim,
        background: SceneAppearance.background(theme),
        fogColor: SceneAppearance.fogColor(theme),
        fogNear: camera.fogNear,
        fogFar: camera.fogFar,
        detail: camera.detailProgress,
        focus: camera.focus,
        aperture: camera.aperture,
        floorMatrix: floorMatrix(),
        cards: cards,
        models: models,
        frame: frame,
      ),
    );
    if (drew) {
      // Only read the timings after a draw, because a zero total means not measured
      // (Qt/src/NativeScene.h:49-54) and a backend that never drew has nothing to
      // report.
      lastTimings = backend.frameTimings;
    }
    return drew;
  }

  /// Releases the backend. Safe to call twice.
  void dispose() => backend.dispose();
}

// ===========================================================================
// Section 11 — self checks
// ===========================================================================

/// In-file checks that need no test file, no Flutter binding and no device.
///
/// The writer is not allowed to create or run tests for this atom, so the checks live
/// here as pure functions a later atom can call from its own test. Every one returns a
/// list of problems, empty meaning the check passed; nothing is asserted with expect
/// and nothing touches an AssetBundle, so importing this file costs a caller nothing.
class NativeSceneSelfCheck {
  const NativeSceneSelfCheck._();

  /// The overlay projection the shipped capture recorded
  /// (Assets/android-3d/scene-fixture.json:3-6), 16 values in Qt order.
  static const List<double> fixtureAoProjection = <double>[
    1.8398545978973289,
    0,
    0,
    0,
    0,
    3.2708526184841404,
    0,
    0,
    0.16,
    0.2,
    -1.0338983050847457,
    -1,
    0,
    0,
    -10.169491525423728,
    0,
  ];

  /// The fog and background colour at theme 0, from the same capture
  /// (Assets/android-3d/scene-fixture.json:8-10).
  static const List<double> fixtureBackground = <double>[
    0.8227857543924378,
    0.7835377915215659,
    0.7529422167708612,
  ];

  /// The four pointer rays and the cells they hit, from the same capture
  /// (Assets/android-3d/scene-fixture.json:846-851).
  ///
  /// The capture does not record the surface size the rays were taken at, so these are
  /// kept as data for a check that runs against a known surface rather than asserted
  /// here.
  static const List<(double, double, int, int)> fixtureRays =
      <(double, double, int, int)>[
    (26.400000000000006, 288, 3, -1),
    (546.4, 608, 2, 14),
    (946.4, 808, 2, 19),
    (1546.4, 1008, 2, 26),
  ];

  /// Runs every check, including the two that need the real GLB bytes.
  ///
  /// [cassetteBytes] and [assemblyBytes] are the raw file contents when the caller has
  /// them; a null list skips the document check with a reported skip so a skipped check
  /// can never look like a pass.
  static List<String> runAll({
    Uint8List? cassetteBytes,
    Uint8List? assemblyBytes,
  }) =>
      <String>[
        ...checkMotionCurves(),
        ...checkCameraMath(),
        ...checkPalette(),
        ...checkSlotPlane(),
        ...checkFrameKeys(),
        ...checkCulling(),
        ...checkMeshRaycast(),
        ...checkModels(cassetteBytes: cassetteBytes, assemblyBytes: assemblyBytes),
      ];

  /// The two easing curves, against the closed forms they claim
  /// (Qt/src/SceneMotion.cpp:42-49).
  static List<String> checkMotionCurves() {
    final List<String> problems = <String>[];
    // smootherstep: 6v^5 - 15v^4 + 10v^3. The endpoints and the midpoint are exact.
    if (sceneSmooth(0) != 0 || sceneSmooth(1) != 1) {
      problems.add('smooth does not map 0 and 1 to 0 and 1');
    }
    if (sceneSmooth(0.5) != 0.5) {
      problems.add('smooth(0.5) != 0.5, so the curve is not symmetric');
    }
    if (sceneSmooth(-1) != 0 || sceneSmooth(2) != 1) {
      problems.add('smooth does not clamp outside [0, 1]');
    }
    const double fifth = 0.25;
    final double expected =
        6 * math.pow(fifth, 5) - 15 * math.pow(fifth, 4) + 10 * math.pow(fifth, 3);
    final double actual = sceneSmooth(fifth);
    if ((actual - expected).abs() > 1e-15) {
      problems
          .add('smooth(0.25) is ' + actual.toString() + ', 6v^5-15v^4+10v^3 is ' +
              expected.toString());
    }
    // smoothstep: v^2(3 - 2v).
    if (sceneEase(0) != 0 || sceneEase(1) != 1) {
      problems.add('ease does not map 0 and 1 to 0 and 1');
    }
    if (sceneEase(0.25) != 0.15625) {
      problems.add('ease(0.25) != 0.15625, so the curve is not v^2(3-2v)');
    }
    if (sceneEase(-1) != 0 || sceneEase(2) != 1) {
      problems.add('ease does not clamp outside [0, 1]');
    }
    return problems;
  }

  /// The camera matrices against the shipped capture.
  ///
  /// The capture was taken at 16:9 with the archive offset applied, so the overlay
  /// projection recomputed here must match it bit for bit; that also pins
  /// perspective() and the offset direction.
  static List<String> checkCameraMath() {
    final List<String> problems = <String>[];
    final SceneMatrix overlay = NativeSceneCamera.overlayProjection(
      width: 1920,
      height: 1080,
    ).withClipOffset(
      NativeSceneCamera.archiveOffsetX,
      NativeSceneCamera.archiveOffsetY,
    );
    const double tolerance = 1e-12;
    for (int index = 0; index < 16; index += 1) {
      if ((overlay.values[index] - fixtureAoProjection[index]).abs() > tolerance) {
        problems.add(
          'overlay projection value ' +
              index.toString() +
              ' is ' +
              overlay.values[index].toString() +
              ', capture has ' +
              fixtureAoProjection[index].toString(),
        );
      }
    }
    if (NativeSceneCamera.projection(fov: 6.15, width: 1920, height: 1080).isZero) {
      problems.add('projection returned the singular matrix');
    }
    final SceneMatrix view = NativeSceneCamera.view(
      NativeSceneCamera.defaultEye,
      NativeSceneCamera.defaultAim,
    );
    if (view.isZero) {
      problems.add('view returned the singular matrix');
    }
    // camera(eye, aim).inverse().point(eye) must land on the origin, and the aim must
    // land on -z: that is what the inverse of a look-at means.
    final SceneVector eyeInView = view.point(NativeSceneCamera.defaultEye);
    if (eyeInView.length > 1e-9) {
      problems.add(
        'eye does not map to the view origin: ' + eyeInView.length.toString(),
      );
    }
    final SceneVector aimInView = view.point(NativeSceneCamera.defaultAim);
    if ((aimInView.x).abs() > 1e-9 || (aimInView.y).abs() > 1e-9) {
      problems.add('aim does not sit on the view axis');
    }
    if (aimInView.z >= 0) {
      problems.add('aim is not in front of the camera: z ' + aimInView.z.toString());
    }
    // The view must be orthonormal, or the frustum normals are wrong.
    for (int column = 0; column < 3; column += 1) {
      final SceneVector axis = SceneVector(
        view.values[column * 4],
        view.values[column * 4 + 1],
        view.values[column * 4 + 2],
      );
      if ((axis.length - 1).abs() > 1e-9) {
        problems.add('view axis ' + column.toString() + ' is not unit length');
      }
    }
    return problems;
  }

  /// The theme blends, which must reproduce the capture at theme 0
  /// (Qt/src/NativeSceneFrame.cpp:110-113).
  static List<String> checkPalette() {
    final List<String> problems = <String>[];
    final List<double> background = SceneAppearance.background(0);
    const double tolerance = 1e-12;
    for (int channel = 0; channel < 3; channel += 1) {
      if ((background[channel] - fixtureBackground[channel]).abs() > tolerance) {
        problems.add(
          'background channel ' +
              channel.toString() +
              ' is ' +
              background[channel].toString() +
              ', capture has ' +
              fixtureBackground[channel].toString(),
        );
      }
    }
    final List<double> dark = SceneAppearance.background(1);
    for (int channel = 0; channel < 3; channel += 1) {
      if (dark[channel] != SceneAppearance.linear(SceneAppearance.darkBackground)[channel]) {
        problems.add('background at theme 1 is not the dark colour');
        break;
      }
    }
    final List<double> fog = SceneAppearance.fogColor(0);
    if (fog[0] != background[0]) {
      problems.add('fog at theme 0 is not the light colour, so the fog blend is wrong');
    }
    if (sceneColorFromHex('#eae5e1').length != 3) {
      problems.add('colour parse did not return three channels');
    }
    return problems;
  }

  /// The slot plane: cellPosition and the two wraps of fileAt
  /// (Qt/src/NativeScene.cpp:63-78).
  static List<String> checkSlotPlane() {
    final List<String> problems = <String>[];
    final SceneVector centre = SceneSlotTable.cellPosition(const SceneCell(2, 15));
    // lane 2 and row 15.5 are both the centres of their axis, so the only offset left
    // is the card height.
    if (centre.x != 0) {
      problems.add('cellPosition x at lane 2 is ' + centre.x.toString());
    }
    if (centre.y != SceneSlotTable.cardHeight) {
      problems.add('cellPosition y is ' + centre.y.toString());
    }
    if ((centre.z + 0).abs() > 1e-12) {
      problems.add('cellPosition z at row 15.5 is ' + centre.z.toString());
    }
    final SceneVector oneLane = SceneSlotTable.cellPosition(const SceneCell(3, 15));
    if ((oneLane.x - SceneSlotTable.laneSpacing).abs() > 1e-12) {
      problems.add('one lane step is ' + oneLane.x.toString());
    }
    final SceneVector oneRow = SceneSlotTable.cellPosition(const SceneCell(2, 16));
    if ((oneRow.z - SceneSlotTable.rowSpacing).abs() > 1e-12) {
      problems.add('one row step is ' + oneRow.z.toString());
    }
    // The plane wraps on both axes at fileAt time, never in the cell itself
    // (Qt/src/NativeScene.cpp:11-13).
    if (sceneWrap(-1, 5) != 4) {
      problems.add('sceneWrap(-1, 5) is ' + sceneWrap(-1, 5).toString());
    }
    if (sceneWrap(3, 0) != 0) {
      problems.add('sceneWrap with a non-positive period is not 0');
    }
    return problems;
  }

  /// The frame key table and its derived values
  /// (Qt/src/NativeSceneFrame.cpp:87-119).
  static List<String> checkFrameKeys() {
    final List<String> problems = <String>[];
    if (NativeSceneFrame.keys.length != 31) {
      problems.add(
        'frame literal key count is ' + NativeSceneFrame.keys.length.toString(),
      );
    }
    final Map<String, Object?> frame = NativeSceneFrame.build(
      view: NativeSceneCamera.view(
        NativeSceneCamera.defaultEye,
        NativeSceneCamera.defaultAim,
      ),
      projection: NativeSceneCamera.projection(
        fov: 6.15,
        width: 1920,
        height: 1080,
      ),
      aoProjection: NativeSceneCamera.overlayProjection(
        width: 1920,
        height: 1080,
      ),
      eye: NativeSceneCamera.defaultEye,
    );
    final List<String> emitted = frame.keys.toList(growable: false);
    if (emitted.length != NativeSceneFrame.keys.length + 4) {
      problems.add('emitted key count is ' + emitted.length.toString());
    }
    for (int index = 0; index < NativeSceneFrame.keys.length; index += 1) {
      if (emitted[index] != NativeSceneFrame.keys[index]) {
        problems.add(
          'frame key ' +
              index.toString() +
              ' is ' +
              emitted[index] +
              ', source order has ' +
              NativeSceneFrame.keys[index],
        );
      }
    }
    if (frame['near'] != 5) {
      problems.add('frame near is not the literal 5');
    }
    if (frame['far'] != 300) {
      problems.add('frame far is not the literal 300');
    }
    if (NativeSceneFrame.detailScalar(0) != 0) {
      problems.add('detail at 0 is not clamped to 0');
    }
    if (NativeSceneFrame.detailScalar(0.8) != 1) {
      problems.add('detail at 0.8 is not the top of the ramp');
    }
    if (NativeSceneFrame.detailScalar(0.525) != 0.5) {
      problems.add(
        'detail at 0.525 is ' +
            NativeSceneFrame.detailScalar(0.525).toString() +
            ', the ramp midpoint should be 0.5',
      );
    }
    return problems;
  }

  /// The two-stage cull and the light frustum
  /// (Qt/src/NativeSceneFrame.cpp:120-138).
  static List<String> checkCulling() {
    final List<String> problems = <String>[];
    final SceneMatrix projection = NativeSceneCamera.projection(
      fov: 6.15,
      width: 1920,
      height: 1080,
    );
    final SceneMatrix view = NativeSceneCamera.view(
      NativeSceneCamera.defaultEye,
      NativeSceneCamera.defaultAim,
    );
    final SceneFrustum frustum = SceneFrustum(projection * view);
    final SceneMatrix lightView =
        SceneMatrix.camera(SceneCardCulling.lightEye, SceneCardCulling.lightAim)
            .inverse();
    // A card at the aim is in front of the camera and must be drawn.
    final SceneCardVisibility near = SceneCardCulling.classify(
      cardMatrix: SceneMatrix.compose(
        NativeSceneCamera.defaultAim,
        const SceneVector(0, 0, 0),
      ),
      cameraFrustum: frustum,
      lightView: lightView,
      selected: false,
      cullingEnabled: true,
    );
    if (!near.visible || near.shadowOnly) {
      problems.add('the card under the aim is not drawn normally');
    }
    // A card far behind the camera with no light-space presence must be culled.
    final SceneCardVisibility far = SceneCardCulling.classify(
      cardMatrix: SceneMatrix.compose(
        const SceneVector(0, 0, 900),
        const SceneVector(0, 0, 0),
      ),
      cameraFrustum: frustum,
      lightView: lightView,
      selected: false,
      cullingEnabled: true,
    );
    if (far.visible) {
      problems.add('a card behind the camera is not culled');
    }
    // The selected card always survives, which is the selected flag Qt passes as true
    // for the live actor (Qt/src/NativeSceneFrame.cpp:126).
    final SceneCardVisibility pinned = SceneCardCulling.classify(
      cardMatrix: SceneMatrix.compose(
        const SceneVector(0, 0, 900),
        const SceneVector(0, 0, 0),
      ),
      cameraFrustum: frustum,
      lightView: lightView,
      selected: true,
      cullingEnabled: true,
    );
    if (!pinned.visible) {
      problems.add('the selected card is culled');
    }
    // With culling off nothing is culled, the m_drawCulling escape hatch.
    final SceneCardVisibility disabled = SceneCardCulling.classify(
      cardMatrix: SceneMatrix.compose(
        const SceneVector(0, 0, 900),
        const SceneVector(0, 0, 0),
      ),
      cameraFrustum: frustum,
      lightView: lightView,
      selected: false,
      cullingEnabled: false,
    );
    if (!disabled.visible) {
      problems.add('culling disabled still drops a card');
    }
    return problems;
  }

  /// The BVH and the triangle test on a hand-built quad
  /// (Qt/src/NativePicking.cpp:148-192 and 231-249).
  static List<String> checkMeshRaycast() {
    final List<String> problems = <String>[];
    final ScenePickingMesh mesh = quadMesh();
    if (mesh.isEmpty) {
      problems.add('the quad mesh built no BVH');
      return problems;
    }
    if (mesh.triangleCount != 2) {
      problems.add('the quad mesh has ' + mesh.triangleCount.toString() + ' triangles');
    }
    // Straight down -z at the quad centre: side 2 accepts both facings, so the hit is
    // the plane at z = 0 and the returned point is the ray origin plus 1.
    final SceneVector? centre = mesh.raycast(
      const SceneVector(0, 0, 1),
      const SceneVector(0, 0, -1),
      2,
    );
    if (centre == null) {
      problems.add('a ray through the quad hit nothing');
    } else {
      if ((centre.x).abs() > 1e-12 ||
          (centre.y).abs() > 1e-12 ||
          (centre.z).abs() > 1e-12) {
        problems.add('the quad hit is not the quad centre: ' + centre.toJson().toString());
      }
    }
    // Outside the quad in x: must miss, which is what proves the barycentric test runs
    // rather than the box alone.
    if (mesh.raycast(
          const SceneVector(3, 0, 1),
          const SceneVector(0, 0, -1),
          2,
        ) !=
        null) {
      problems.add('a ray outside the quad still hit');
    }
    // One-sided cull: a back-face ray misses with side 0 and hits with side 2.
    final SceneVector? backFace = mesh.raycast(
      const SceneVector(0, 0, -1),
      const SceneVector(0, 0, 1),
      0,
    );
    final SceneVector? bothFaces = mesh.raycast(
      const SceneVector(0, 0, -1),
      const SceneVector(0, 0, 1),
      2,
    );
    if (backFace != null) {
      problems.add('a back-facing ray hit a front-face-only mesh');
    }
    if (bothFaces == null) {
      problems.add('side 2 did not accept a back-facing hit');
    }
    // A non-finite input is a miss, the guard raycast() shares with Qt.
    if (mesh.raycast(
          const SceneVector(double.nan, 0, 1),
          const SceneVector(0, 0, -1),
          2,
        ) !=
        null) {
      problems.add('a non-finite ray hit something');
    }
    return problems;
  }

  /// A two-triangle quad in the z = 0 plane spanning [-1, 1] on both axes, built
  /// straight into the BVH.
  ///
  /// It exists so the picking check needs no GLB bytes, no asset bundle and no device.
  static ScenePickingMesh quadMesh() {
    final Float64List positions = Float64List.fromList(<double>[
      -1, -1, 0,
      1, -1, 0,
      1, 1, 0,
      -1, 1, 0,
    ]);
    final Uint32List indices = Uint32List.fromList(<int>[0, 1, 2, 0, 2, 3]);
    final int count = indices.length ~/ 3;
    final ScenePickingMesh mesh = ScenePickingMesh._(
      positions,
      indices,
      <SceneBvhNode>[],
      List<int>.generate(count, (int index) => index),
    );
    final List<ScenePickingBox> boxes = <ScenePickingBox>[];
    for (int triangle = 0; triangle < count; triangle += 1) {
      ScenePickingBox box = ScenePickingBox.empty();
      for (int vertex = 0; vertex < 3; vertex += 1) {
        final int position = indices[triangle * 3 + vertex];
        box = box.include(
          SceneVector(
            positions[position * 3],
            positions[position * 3 + 1],
            positions[position * 3 + 2],
          ),
        );
      }
      boxes.add(box);
    }
    mesh._build(boxes, 0, count);
    return mesh;
  }

  /// The two shipped GLB files, when their bytes are available.
  ///
  /// Checks the container header, the chunk layout, the declared scene name and the
  /// object counts recorded in [NativeSceneModels], then builds every picking mesh so a
  /// malformed buffer view surfaces here rather than on a device.
  static List<String> checkModels({
    Uint8List? cassetteBytes,
    Uint8List? assemblyBytes,
  }) {
    final List<String> problems = <String>[];
    void checkOne(
      Uint8List? bytes,
      String name,
      int byteCount,
      int jsonBytes,
      int binaryBytes,
      String sceneName,
      int nodes,
      int meshes,
      int materials,
      int accessors,
    ) {
      if (bytes == null) {
        problems.add(name + ': skipped, no bytes supplied');
        return;
      }
      if (bytes.length != byteCount) {
        problems.add(
          name +
              ': ' +
              bytes.length.toString() +
              ' B, recorded ' +
              byteCount.toString(),
        );
      }
      final GlbContainer container;
      final NativeSceneSurfaceModel model;
      try {
        container = GlbContainer.parse(bytes);
        model = NativeSceneSurfaceModel.fromContainer(name, container);
      } on NativeSceneFailure catch (error) {
        problems.add(name + ': ' + error.message + ' (' + error.detail + ')');
        return;
      }
      if (container.version != 2) {
        problems.add(name + ': glTF version is ' + container.version.toString());
      }
      if (container.byteLength != bytes.length) {
        problems.add(name + ': header length disagrees with the file size');
      }
      final int jsonChunkBytes = container.chunks
          .firstWhere((GlbChunk chunk) => chunk.isJson)
          .length;
      if (jsonChunkBytes != jsonBytes) {
        problems.add(
          name + ': JSON chunk is ' + jsonChunkBytes.toString() + ' B',
        );
      }
      if ((container.binary?.length ?? 0) != binaryBytes) {
        problems.add(
          name +
              ': BIN chunk is ' +
              (container.binary?.length ?? 0).toString() +
              ' B',
        );
      }
      if (model.scene.nodes.length != nodes) {
        problems.add(
          name + ': ' + model.scene.nodes.length.toString() + ' nodes, recorded ' +
              nodes.toString(),
        );
      }
      if (model.scene.meshes.length != meshes) {
        problems.add(
          name + ': ' + model.scene.meshes.length.toString() + ' meshes, recorded ' +
              meshes.toString(),
        );
      }
      if (model.scene.materials.length != materials) {
        problems.add(
          name + ': ' + model.scene.materials.length.toString() +
              ' materials, recorded ' + materials.toString(),
        );
      }
      if (model.scene.accessors.length != accessors) {
        problems.add(
          name + ': ' + model.scene.accessors.length.toString() +
              ' accessors, recorded ' + accessors.toString(),
        );
      }
      final String? declared = model.scene.sceneName;
      if (declared != null && declared != sceneName) {
        problems.add(name + ': scene is ' + declared + ', recorded ' + sceneName);
      }
      if (model.triangleCount <= 0) {
        problems.add(name + ': no picking triangles decoded');
      }
      if (model.scene.meshes.isNotEmpty && model.meshes.first.isEmpty) {
        problems.add(name + ': mesh 0 built no BVH, so picking would always miss');
      }
    }

    checkOne(
      cassetteBytes,
      NativeSceneModels.cassettePath,
      NativeSceneModels.cassetteBytes,
      NativeSceneModels.cassetteJsonBytes,
      NativeSceneModels.cassetteBinaryBytes,
      NativeSceneModels.cassetteSceneName,
      NativeSceneModels.cassetteNodes,
      NativeSceneModels.cassetteMeshes,
      NativeSceneModels.cassetteMaterials,
      NativeSceneModels.cassetteAccessors,
    );
    checkOne(
      assemblyBytes,
      NativeSceneModels.assemblyPath,
      NativeSceneModels.assemblyBytes,
      NativeSceneModels.assemblyJsonBytes,
      NativeSceneModels.assemblyBinaryBytes,
      NativeSceneModels.assemblySceneName,
      NativeSceneModels.assemblyNodes,
      NativeSceneModels.assemblyMeshes,
      NativeSceneModels.assemblyMaterials,
      NativeSceneModels.assemblyAccessors,
    );
    return problems;
  }
}
