/// Unit tests for the architecture-neutral bootstrap (atom T20-C18-S02).
///
/// Every port is faked here: no engine, no network, no file system and no
/// binding is touched, which is why these cases can run as plain unit tests.
library;

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/app/bootstrap.dart';

/// Fake host. Counts each call, records what the bootstrap asked for and can be
/// told to throw from any port.
class _FakeShellPorts implements ShellPorts {
  _FakeShellPorts({
    this.matrix,
    this.failAttach = false,
    this.failInitialize = false,
    this.failCapabilities = false,
    this.failReport = false,
    this.failFallback = false,
  });

  /// Matrix handed to [capabilities]; null makes the probe throw.
  ShellCapabilities? matrix;
  bool failAttach;
  bool failInitialize;
  bool failCapabilities;
  bool failReport;
  bool failFallback;

  int attachCalls = 0;
  int initializeCalls = 0;
  int capabilitiesCalls = 0;
  final List<String> calls = <String>[];
  final List<ShellFailure> reported = <ShellFailure>[];
  final List<ShellFallbackReason> fallbacks = <ShellFallbackReason>[];

  @override
  void attachEngine() {
    attachCalls += 1;
    calls.add('attachEngine');
    if (failAttach) {
      throw StateError('engine refused to start');
    }
  }

  @override
  void initializeShell() {
    initializeCalls += 1;
    calls.add('initializeShell');
    if (failInitialize) {
      throw StateError('initialization aborted');
    }
  }

  @override
  void reportFailure(ShellFailure failure) {
    calls.add('reportFailure');
    reported.add(failure);
    if (failReport) {
      throw StateError('reporter is broken');
    }
  }

  @override
  void showFallback(ShellFallbackReason reason) {
    calls.add('showFallback:' + reason.name);
    fallbacks.add(reason);
    if (failFallback) {
      throw StateError('fallback entry is broken');
    }
  }

  @override
  ShellCapabilities capabilities() {
    capabilitiesCalls += 1;
    calls.add('capabilities');
    if (failCapabilities) {
      throw StateError('capability probe failed');
    }
    final ShellCapabilities? value = matrix;
    if (value == null) {
      throw StateError('no matrix supplied');
    }
    return value;
  }
}

ShellCapabilities _capabilities({String? fallbackEntry = 'settings-graphics'}) {
  return ShellCapabilities(
    backend: 'vulkan',
    vsync: true,
    supersample: false,
    renderScale: 1.0,
    antialiasing: true,
    frameGeneration: false,
    frameGenerationPresentLayer: false,
    frameGenerationInterpolation: false,
    notes: <String>['此构建未编入 Vulkan 帧生成'],
    fallbackEntry: fallbackEntry,
  );
}

void main() {
  group('startup sequence', () {
    test('start enters consentPending without calling any port', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      expect(bootstrap.snapshot.phase, ShellPhase.idle);
      bootstrap.start();

      expect(bootstrap.snapshot.phase, ShellPhase.consentPending);
      expect(ports.calls, isEmpty);
      expect(bootstrap.snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
      ]);
    });

    test('grantConsent attaches once, initializes once and reaches ready', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      expect(ports.calls, <String>[
        'capabilities',
        'attachEngine',
        'initializeShell',
      ]);
      expect(ports.attachCalls, 1);
      expect(ports.initializeCalls, 1);
      expect(ports.capabilitiesCalls, 1);
      expect(ports.reported, isEmpty);
      expect(ports.fallbacks, isEmpty);

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.ready);
      expect(snapshot.isReady, isTrue);
      expect(snapshot.isFailed, isFalse);
      expect(snapshot.failure, isNull);
      expect(snapshot.fallback, isNull);
      expect(snapshot.engineAttached, isTrue);
      expect(snapshot.retryCount, 0);
      expect(snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
        ShellPhase.initializing,
        ShellPhase.ready,
      ]);
    });

    test('declineConsent never reaches the engine', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.declineConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.consentDeclined);
      expect(snapshot.engineAttached, isFalse);
      expect(snapshot.failure, isNull);
      expect(snapshot.capabilities, isNull);
      expect(ports.attachCalls, 0);
      expect(ports.initializeCalls, 0);
      expect(ports.capabilitiesCalls, 0);
      expect(ports.reported, isEmpty);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.consentDeclined,
      ]);
      expect(snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.consentDeclined,
      ]);
    });

    test('a throwing fallback entry cannot turn a decline into a start', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failFallback: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.declineConsent();

      expect(bootstrap.snapshot.phase, ShellPhase.consentDeclined);
      expect(ports.attachCalls, 0);
      expect(ports.initializeCalls, 0);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.consentDeclined,
      ]);
    });
  });

  group('failure boundary', () {
    test('attachEngine throw fails the shell with engineMissing', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failAttach: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.failed);
      expect(snapshot.isFailed, isTrue);
      expect(snapshot.engineAttached, isFalse);
      expect(snapshot.retryCount, 0);
      expect(snapshot.fallback, ShellFallbackReason.engineMissing);
      expect(snapshot.failure, isNotNull);
      expect(snapshot.failure!.phase, ShellPhase.attaching);
      expect(snapshot.failure!.message, contains('engine refused to start'));
      expect(snapshot.failure!.cause, isA<StateError>());
      expect(snapshot.failure!.stackTrace, isNotNull);
      expect(ports.reported.length, 1);
      expect(ports.reported.single.phase, ShellPhase.attaching);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.engineMissing,
      ]);
      expect(ports.initializeCalls, 0);
      expect(snapshot.completedPhases, <ShellPhase>[ShellPhase.consentPending]);
    });

    test('initializeShell throw fails the shell with initializationFailed', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failInitialize: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.failed);
      expect(snapshot.fallback, ShellFallbackReason.initializationFailed);
      expect(snapshot.failure!.phase, ShellPhase.initializing);
      expect(snapshot.engineAttached, isTrue);
      expect(ports.attachCalls, 1);
      expect(ports.reported.length, 1);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.initializationFailed,
      ]);
      expect(snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
      ]);
    });

    test('a throwing reporter is called once and cannot erase the failure', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failAttach: true,
        failReport: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(ports.reported.length, 1);
      expect(snapshot.phase, ShellPhase.failed);
      expect(snapshot.failure, isNotNull);
      expect(snapshot.fallback, ShellFallbackReason.engineMissing);
    });

    test('a throwing fallback entry keeps the recorded failure', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failAttach: true,
        failFallback: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.failed);
      expect(snapshot.failure!.phase, ShellPhase.attaching);
      expect(snapshot.failure!.message, contains('engine refused to start'));
      expect(snapshot.fallback, ShellFallbackReason.engineMissing);
      expect(ports.reported.length, 1);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.engineMissing,
      ]);
    });

    test('a throwing capability probe fails the attach step', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failCapabilities: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(snapshot.phase, ShellPhase.failed);
      expect(snapshot.fallback, ShellFallbackReason.engineMissing);
      expect(snapshot.capabilities, isNull);
      expect(bootstrap.keepFallbackEntry, isTrue);
      expect(ports.capabilitiesCalls, 1);
      expect(ports.attachCalls, 0);
      expect(ports.reported.single.phase, ShellPhase.attaching);
    });
  });

  group('retry', () {
    test('retry after an attach failure re-enters only attaching', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failAttach: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      expect(bootstrap.snapshot.phase, ShellPhase.failed);

      ports.failAttach = false;
      bootstrap.retry();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(ports.attachCalls, 2);
      expect(ports.capabilitiesCalls, 1);
      expect(ports.initializeCalls, 1);
      expect(snapshot.phase, ShellPhase.ready);
      expect(snapshot.retryCount, 1);
      expect(snapshot.failure, isNull);
      expect(snapshot.fallback, isNull);
      expect(snapshot.engineAttached, isTrue);
      expect(snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
        ShellPhase.initializing,
        ShellPhase.ready,
      ]);
    });

    test('retry after an initialize failure never re-attaches the engine', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failInitialize: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      expect(bootstrap.snapshot.phase, ShellPhase.failed);

      ports.failInitialize = false;
      bootstrap.retry();

      final ShellSnapshot snapshot = bootstrap.snapshot;
      expect(ports.attachCalls, 1);
      expect(ports.capabilitiesCalls, 1);
      expect(ports.initializeCalls, 2);
      expect(snapshot.phase, ShellPhase.ready);
      expect(snapshot.retryCount, 1);
      expect(snapshot.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
        ShellPhase.initializing,
        ShellPhase.ready,
      ]);
    });

    test('a repeated failure keeps incrementing retryCount', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failInitialize: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      bootstrap.retry();
      expect(bootstrap.snapshot.retryCount, 1);
      expect(bootstrap.snapshot.phase, ShellPhase.failed);

      bootstrap.retry();
      expect(bootstrap.snapshot.retryCount, 2);
      expect(bootstrap.snapshot.phase, ShellPhase.failed);
      expect(ports.attachCalls, 1);
      expect(ports.initializeCalls, 3);
      expect(ports.reported.length, 3);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.initializationFailed,
        ShellFallbackReason.initializationFailed,
        ShellFallbackReason.initializationFailed,
      ]);
    });

    test('retry outside the failed phase throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      expect(bootstrap.retry, throwsStateError);

      bootstrap.start();
      expect(bootstrap.retry, throwsStateError);

      bootstrap.grantConsent();
      expect(bootstrap.snapshot.phase, ShellPhase.ready);
      expect(bootstrap.retry, throwsStateError);
      expect(ports.attachCalls, 1);
      expect(ports.initializeCalls, 1);
    });
  });

  group('illegal transitions', () {
    test('grantConsent before start throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      expect(bootstrap.grantConsent, throwsStateError);
      expect(ports.attachCalls, 0);
      expect(bootstrap.snapshot.phase, ShellPhase.idle);
    });

    test('declineConsent before start throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      expect(bootstrap.declineConsent, throwsStateError);
      expect(ports.fallbacks, isEmpty);
      expect(bootstrap.snapshot.phase, ShellPhase.idle);
    });

    test('start twice and start after ready throw StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      expect(bootstrap.start, throwsStateError);

      bootstrap.grantConsent();
      expect(bootstrap.start, throwsStateError);
      expect(ports.attachCalls, 1);
    });

    test('a second grantConsent after ready throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      expect(bootstrap.grantConsent, throwsStateError);
      expect(ports.attachCalls, 1);
      expect(ports.initializeCalls, 1);
    });

    test('declineConsent after the grant throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      expect(bootstrap.declineConsent, throwsStateError);
      expect(bootstrap.snapshot.phase, ShellPhase.ready);
    });

    test('noteServiceExited before the engine is attached throws StateError', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      expect(
        () => bootstrap.noteServiceExited(message: '音乐服务已退出，请重试'),
        throwsStateError,
      );

      bootstrap.start();
      expect(
        () => bootstrap.noteServiceExited(message: '音乐服务已退出，请重试'),
        throwsStateError,
      );
      expect(ports.reported, isEmpty);
    });
  });

  group('capability matrix', () {
    test('the constructor matrix wins and the port is never probed', () {
      final ShellCapabilities injected = _capabilities();
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(
        ports,
        initialCapabilities: injected,
      );

      bootstrap.start();
      bootstrap.grantConsent();

      expect(ports.capabilitiesCalls, 0);
      expect(ports.calls, <String>['attachEngine', 'initializeShell']);
      expect(bootstrap.snapshot.capabilities, same(injected));
      expect(bootstrap.keepFallbackEntry, isFalse);
    });

    test('the matrix comes from the port when none is injected', () {
      final ShellCapabilities fromPort = _capabilities();
      final _FakeShellPorts ports = _FakeShellPorts(matrix: fromPort);
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      expect(bootstrap.snapshot.capabilities, isNull);

      bootstrap.grantConsent();
      expect(ports.capabilitiesCalls, 1);
      expect(bootstrap.snapshot.capabilities, same(fromPort));
    });

    test('a matrix without a fallback entry keeps the fallback entry', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(fallbackEntry: null),
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      expect(bootstrap.snapshot.phase, ShellPhase.ready);
      expect(bootstrap.snapshot.capabilities, isNotNull);
      expect(bootstrap.snapshot.capabilities!.fallbackEntry, isNull);
      expect(bootstrap.keepFallbackEntry, isTrue);
    });

    test('frame generation is usable only when all three flags hold', () {
      final ShellCapabilities off = _capabilities();
      expect(off.frameGenerationUsable, isFalse);

      final ShellCapabilities on = ShellCapabilities(
        backend: 'vulkan',
        vsync: true,
        supersample: true,
        renderScale: 1.25,
        antialiasing: true,
        frameGeneration: true,
        frameGenerationPresentLayer: true,
        frameGenerationInterpolation: true,
        notes: <String>[],
        fallbackEntry: 'settings-graphics',
      );
      expect(on.frameGenerationUsable, isTrue);
      expect(on.renderScale, 1.25);
    });

    test('matrices with the same injected values compare equal', () {
      final ShellCapabilities first = _capabilities();
      final ShellCapabilities second = _capabilities();

      expect(first, second);
      expect(first.hashCode, second.hashCode);
      expect(first == _capabilities(fallbackEntry: null), isFalse);
      expect(first.toString(), contains('vulkan'));
      expect(first.toString(), contains('settings-graphics'));
    });
  });

  group('service exit', () {
    test('a service exit after ready fails the shell and retry re-attaches', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();
      bootstrap.noteServiceExited(message: '音乐服务已退出，请重试');

      final ShellSnapshot failed = bootstrap.snapshot;
      expect(failed.phase, ShellPhase.failed);
      expect(failed.failure!.phase, ShellPhase.attaching);
      expect(failed.failure!.message, '音乐服务已退出，请重试');
      expect(failed.fallback, ShellFallbackReason.serviceExited);
      expect(failed.engineAttached, isTrue);
      // History keeps the phases that really finished; phase carries the
      // verdict, so a lost service does not erase the earlier ready.
      expect(failed.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
        ShellPhase.initializing,
        ShellPhase.ready,
      ]);
      expect(ports.reported.length, 1);
      expect(ports.fallbacks, <ShellFallbackReason>[
        ShellFallbackReason.serviceExited,
      ]);

      bootstrap.retry();

      final ShellSnapshot ready = bootstrap.snapshot;
      expect(ports.attachCalls, 2);
      expect(ports.initializeCalls, 1);
      expect(ready.phase, ShellPhase.ready);
      expect(ready.retryCount, 1);
      expect(ready.completedPhases, <ShellPhase>[
        ShellPhase.consentPending,
        ShellPhase.attaching,
        ShellPhase.initializing,
        ShellPhase.ready,
      ]);
    });
  });

  group('snapshot', () {
    test('the snapshot lists are unmodifiable', () {
      final _FakeShellPorts ports = _FakeShellPorts(matrix: _capabilities());
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      expect(
        () => bootstrap.snapshot.completedPhases.add(ShellPhase.idle),
        throwsA(isA<UnsupportedError>()),
      );
      expect(
        () => bootstrap.snapshot.capabilities!.notes.add('injected later'),
        throwsA(isA<UnsupportedError>()),
      );
    });

    test('copyWith clears nullable fields only when asked to', () {
      final _FakeShellPorts ports = _FakeShellPorts(
        matrix: _capabilities(),
        failInitialize: true,
      );
      final ShellBootstrap bootstrap = ShellBootstrap(ports);

      bootstrap.start();
      bootstrap.grantConsent();

      final ShellSnapshot failed = bootstrap.snapshot;
      expect(failed.failure, isNotNull);
      expect(failed.fallback, isNotNull);
      expect(failed.capabilities, isNotNull);

      final ShellSnapshot kept = failed.copyWith(retryCount: 7);
      expect(kept.retryCount, 7);
      expect(kept.failure, same(failed.failure));
      expect(kept.fallback, same(failed.fallback));
      expect(kept.capabilities, same(failed.capabilities));
      expect(kept.phase, ShellPhase.failed);
      expect(kept.completedPhases, failed.completedPhases);

      final ShellSnapshot cleared = failed.copyWith(
        failure: null,
        fallback: null,
        capabilities: null,
      );
      expect(cleared.failure, isNull);
      expect(cleared.fallback, isNull);
      expect(cleared.capabilities, isNull);
      expect(cleared.phase, ShellPhase.failed);
      expect(cleared.completedPhases, failed.completedPhases);
    });
  });
}
