/// Qt 封面查看器的纯状态机测试（不执行：本任务禁止 dart/flutter 测试运行）。
///
/// 断言全部来自 Qt/src/NativeViewer.cpp 与 SceneMath.cpp 的可读语义：
/// - 打开 0.38s / 关闭 0.22s / 复位 0.56s 三次缓出（:59, :120, :150-160）
/// - clarity 阻尼率 8、spread 阻尼率 5.5（:166-168）
/// - 半径夹 5..28、注视点夹 |target|<=5、phi 夹 (1e-6, pi-1e-6)（:139-232）
/// - frame 字段与竖屏 zoom = min(1.15, aspect/0.85)/(1+0.08*spread)（:258-300）
/// - 模板展开顺序与封面纸片锚点 (-1.36, 3.04, 0.255)（:276-300）
///
/// viewer 在 Qt 里不产出任何 2D 命令，因此这里也不断言 fill/text/hit。

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/pages/viewer_hud.dart';

List<ViewerMesh> _meshes() => <ViewerMesh>[
      const ViewerMesh(name: 'fastener-a', assemblyPart: 'fasteners'),
      const ViewerMesh(name: 'cover-a', assemblyPart: 'cover'),
    ];

Map<String, Object?> _template(String name, String part, {bool label = false}) => <String, Object?>{
      'name': name,
      'assemblyPart': part,
      'label': label,
      'side': label ? 0 : 1,
      'asset': label ? 'cassette-sheet' : 'assembly-sheet',
    };

List<Map<String, Object?>> _actorTemplate() => <Map<String, Object?>>[
      _template('fastener-a', 'fasteners'),
      _template('cover-a', 'cover'),
      _template('', 'cover', label: true),
      _template('unrelated', 'substrate'),
    ];

/// 打开并跑满 opening 窗口，返回可直接断言 open 态的实例。
ViewerHud _opened({double width = 1920, double height = 1080}) {
  final ViewerHud hud = ViewerHud(width: width, height: height, loadMeshes: _meshes);
  hud.open(0);
  hud.update(0.4, 0);
  return hud;
}

/// 以 50ms 步进推进到 until 秒（Qt update 内部把 seconds 夹到 <=0.05）。
void _advance(ViewerHud hud, double from, double until) {
  double time = from;
  while (time < until - 1e-9) {
    time = math.min(until, time + 0.05);
    hud.update(time, 0);
  }
}

void main() {
  group('SceneMath 基元（SceneMath.cpp:6-206）', () {
    test('Vector 基本运算与归一化', () {
      const ViewerVector a = ViewerVector(1, 2, 3);
      const ViewerVector b = ViewerVector(-1, 0.5, 2);
      expect(a.dot(b), 6.0);
      expect(a.cross(b).toList(), <double>[2.5, -5.0, 2.5]);
      expect(a.length, math.sqrt(14));
      expect(a.normalized.length, closeTo(1, 1e-12));
      expect(ViewerVector.zero.normalized.toList(), <double>[0, 0, 0]);
      expect(a.lerp(b, 0.5).toList(), <double>[0, 1.25, 2.5]);
      expect(a.toList(), <double>[1, 2, 3]);
    });

    test('Spherical 与 Vector 互逆（NativeViewer.cpp:27-38）', () {
      const ViewerVector eye = ViewerVector(7.2, 3.8, 12);
      final ViewerSpherical spherical = ViewerSpherical.fromVector(eye);
      expect(spherical.radius, eye.length);
      expect(spherical.phi, closeTo(math.acos(3.8 / eye.length), 1e-12));
      expect(spherical.theta, closeTo(math.atan2(7.2, 12), 1e-12));
      final ViewerVector back = spherical.toVector();
      expect(back.x, closeTo(eye.x, 1e-9));
      expect(back.y, closeTo(eye.y, 1e-9));
      expect(back.z, closeTo(eye.z, 1e-9));
      expect(ViewerSpherical.fromVector(ViewerVector.zero).radius, 0);
    });

    test('Spring::damp 与 Qt 公式逐项一致', () {
      final ViewerSpring spring = ViewerSpring(0, 0);
      const double target = 1;
      const double rate = 8;
      const double seconds = 0.05;
      final double delta = 0 - target;
      final double impulse = 0 + rate * delta;
      final double decay = math.exp(-rate * seconds);
      final double expectedValue = target + (delta + impulse * seconds) * decay;
      final double expectedVelocity = (0 - rate * impulse * seconds) * decay;
      spring.damp(target, rate, seconds);
      expect(spring.value, closeTo(expectedValue, 1e-12));
      expect(spring.velocity, closeTo(expectedVelocity, 1e-12));
    });

    test('compose 只平移时是单位矩阵加平移列（列主序）', () {
      final ViewerMatrix matrix = ViewerMatrix.compose(const ViewerVector(1, 2, 3), ViewerVector.zero);
      expect(matrix.toList(), <double>[
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        1, 2, 3, 1,
      ]);
    });

    test('perspective 的 16 值布局与 Qt 相同', () {
      final ViewerMatrix matrix = ViewerMatrix.perspective(34, 16 / 9, 0.3, 120);
      final double top = 0.3 * math.tan(math.pi / 180 * 0.5 * 34);
      final double height = 2 * top;
      final double width = (16 / 9) * height;
      final double left = -0.5 * width;
      final double right = left + width;
      final double bottom = top - height;
      expect(matrix.values[0], closeTo(2 * 0.3 / (right - left), 1e-12));
      expect(matrix.values[5], closeTo(2 * 0.3 / (top - bottom), 1e-12));
      expect(matrix.values[8], closeTo((right + left) / (right - left), 1e-12));
      expect(matrix.values[10], closeTo(-(120 + 0.3) / (120 - 0.3), 1e-12));
      expect(matrix.values[11], -1);
      expect(matrix.values[14], closeTo(-2 * 120 * 0.3 / (120 - 0.3), 1e-12));
    });

    test('camera 正交基与逆矩阵把 eye 映到原点、focus 映到 -z', () {
      const ViewerVector eye = ViewerVector(7.2, 3.8, 12);
      final ViewerMatrix camera = ViewerMatrix.camera(eye, ViewerVector.zero);
      final ViewerVector x = ViewerVector(camera.values[0], camera.values[1], camera.values[2]);
      final ViewerVector y = ViewerVector(camera.values[4], camera.values[5], camera.values[6]);
      final ViewerVector z = ViewerVector(camera.values[8], camera.values[9], camera.values[10]);
      expect(x.length, closeTo(1, 1e-12));
      expect(y.length, closeTo(1, 1e-12));
      expect(z.length, closeTo(1, 1e-12));
      expect(x.dot(y), closeTo(0, 1e-12));
      // Qt 的 look-at 把相机放在 +z 方向看向原点，focus 落在 -z。
      expect(camera.inverse().point(eye).toList()[0], closeTo(0, 1e-9));
      expect(camera.inverse().point(eye).toList()[1], closeTo(0, 1e-9));
      expect(camera.inverse().point(eye).toList()[2], closeTo(0, 1e-9));
      final ViewerVector focusInView = camera.inverse().point(ViewerVector.zero);
      expect(focusInView.z, closeTo(-eye.length, 1e-9));
    });

    test('奇异矩阵的逆是全零矩阵（SceneMath.cpp:126-131）', () {
      final ViewerMatrix singular = ViewerMatrix(List<double>.filled(16, 0));
      expect(singular.inverse().toList().every((double value) => value == 0), isTrue);
    });
  });

  group('打开 / 关闭时序（NativeViewer.cpp:52-160 / 250-262）', () {
    test('open：opening 0.38s 内 pending，之后 open（:59 / :262）', () {
      final ViewerHud hud = ViewerHud(loadMeshes: _meshes);
      hud.open(0);
      expect(hud.isOpen, isTrue);
      expect(hud.ready, isTrue);
      expect(hud.transition, 'opening');
      expect(hud.pendingUntil, 0.38);
      expect(hud.pending, isTrue);
      hud.update(0.37, 0);
      expect(hud.transition, 'opening');
      expect(hud.pending, isTrue);
      hud.update(0.38, 0);
      expect(hud.transition, 'open');
      expect(hud.pending, isFalse);
    });

    test('reduced 打开立即 open、pendingUntil 归零（:91-99）', () {
      final ViewerHud hud = ViewerHud(loadMeshes: _meshes);
      hud.reduced(true);
      hud.open(0);
      expect(hud.transition, 'open');
      expect(hud.pendingUntil, 0);
      expect(hud.pending, isFalse);
    });

    test('close：closing 0.22s 后释放 templates 并回到 closed（:120 / :253-260）', () {
      final ViewerHud hud = _opened();
      hud.action('close', 1.0);
      expect(hud.closing, isTrue);
      expect(hud.transition, 'closing');
      expect(hud.closeAt, closeTo(1.22, 1e-12));
      expect(hud.pending, isTrue);
      hud.update(1.21, 0);
      expect(hud.isOpen, isTrue);
      hud.update(1.22, 0);
      expect(hud.isOpen, isFalse);
      expect(hud.closing, isFalse);
      expect(hud.ready, isFalse);
      expect(hud.transition, 'closed');
      expect(hud.meshes, isEmpty);
    });

    test('reduced 关闭立刻生效（closeAt = time）', () {
      final ViewerHud hud = _opened();
      hud.reduced(true);
      hud.action('close', 2.0);
      expect(hud.closeAt, 2.0);
      hud.update(2.0, 0);
      expect(hud.isOpen, isFalse);
      expect(hud.transition, 'closed');
    });

    test('重新打开会重新装载模板（Qt 关闭时清空 meshes，:257-258 / :74-79）', () {
      int loads = 0;
      final ViewerHud hud = ViewerHud(loadMeshes: () {
        loads++;
        return _meshes();
      });
      hud.open(0);
      expect(loads, 1);
      hud.update(0.4, 0);
      hud.action('close', 1);
      hud.update(1.3, 0);
      hud.open(2);
      expect(loads, 2);
      expect(hud.ready, isTrue);
    });

    test('关闭后 frame 原样返回 base（:259-261）', () {
      final ViewerHud hud = ViewerHud(loadMeshes: _meshes);
      final Map<String, Object?> base = <String, Object?>{'seed': 1};
      expect(hud.frame(base, actorTemplate: _actorTemplate()), base);
    });
  });

  group('action 语义（NativeViewer.cpp:136-160）', () {
    test('未 ready 时 clear/frosted/explode 全部忽略，close 仍生效', () {
      final ViewerHud hud = ViewerHud();
      hud.open(0);
      expect(hud.ready, isFalse);
      hud.action('frosted', 0.1);
      expect(hud.targetClarity, 1);
      expect(hud.surface, 'clear');
      hud.action('explode', 0.1);
      expect(hud.targetSpread, 0);
      hud.action('close', 0.2);
      expect(hud.closing, isTrue);
    });

    test('clear/frosted 切 targetClarity 与 surface（:143-146）', () {
      final ViewerHud hud = _opened();
      hud.action('frosted', 1);
      expect(hud.targetClarity, 0);
      expect(hud.surface, 'frosted');
      hud.action('clear', 1.1);
      expect(hud.targetClarity, 1);
      expect(hud.surface, 'clear');
    });

    test('explode/assemble 切 targetSpread（:147-149）', () {
      final ViewerHud hud = _opened();
      hud.action('explode', 1);
      expect(hud.targetSpread, 1);
      hud.action('assemble', 1.1);
      expect(hud.targetSpread, 0);
    });

    test('reset 进入 0.56s 复位（:150-151 / :152-160）', () {
      final ViewerHud hud = _opened();
      hud.pointer('pointerdown', 100, 100);
      hud.pointer('pointermove', 200, 100);
      hud.action('reset', 1);
      expect(hud.resetting, isTrue);
    });

    test('关闭态 action 全部无效', () {
      final ViewerHud hud = ViewerHud(loadMeshes: _meshes);
      hud.action('close', 0);
      hud.action('explode', 0);
      expect(hud.isOpen, isFalse);
      expect(hud.targetSpread, 0);
    });
  });

  group('弹簧收敛（NativeViewer.cpp:166-176）', () {
    test('explode 收敛到 1 并精确贴拢', () {
      final ViewerHud hud = _opened();
      hud.action('explode', 1);
      _advance(hud, 0.4, 4.0);
      expect(hud.spread.value, 1);
      expect(hud.spread.velocity, 0);
      expect(hud.clarity.value, 1);
    });

    test('frosted 收敛到 0 并精确贴拢', () {
      final ViewerHud hud = _opened();
      hud.action('frosted', 1);
      _advance(hud, 0.4, 4.0);
      expect(hud.clarity.value, 0);
      expect(hud.clarity.velocity, 0);
    });

    test('单步阻尼应把差值缩小且不过冲（阻尼率 8）', () {
      final ViewerHud hud = _opened();
      hud.action('frosted', 1);
      final double before = (hud.clarity.value - hud.targetClarity).abs();
      hud.update(1.05, 0);
      final double after = (hud.clarity.value - hud.targetClarity).abs();
      expect(after, lessThan(before));
      expect(hud.clarity.value, greaterThanOrEqualTo(0));
    });

    test('reduced 时 update 直接贴到目标（:166-169）', () {
      final ViewerHud hud = _opened();
      hud.action('explode', 1);
      hud.reduced(true);
      hud.update(1.05, 0);
      expect(hud.spread.value, 1);
      expect(hud.clarity.value, 1);
    });
  });

  group('复位动画（NativeViewer.cpp:150-160 / 200-216）', () {
    test('复位在 0.56s 后结束并回到默认球面', () {
      final ViewerHud hud = _opened();
      hud.pointer('pointerdown', 100, 100);
      hud.pointer('pointermove', 300, 200);
      final double draggedTheta = hud.goal.theta;
      expect(draggedTheta, isNot(closeTo(math.atan2(7.2, 12), 1e-9)));
      hud.reset(true);
      expect(hud.resetting, isTrue);
      _advance(hud, 0.4, 1.2);
      expect(hud.resetting, isFalse);
      expect(hud.pose.radius, closeTo(viewerDefaultEye.length, 1e-6));
      expect(hud.pose.phi, closeTo(math.acos(3.8 / viewerDefaultEye.length), 1e-6));
      final double delta = hud.pose.theta - math.atan2(7.2, 12);
      expect(math.atan2(math.sin(delta), math.cos(delta)).abs(), lessThan(1e-6));
      expect(hud.focus.length, closeTo(0, 1e-9));
      expect(hud.eye.length, closeTo(viewerDefaultEye.length, 1e-6));
    });

    test('interrupt 把当前姿态作为新目标（:117-123）', () {
      final ViewerHud hud = _opened();
      // 先平移出非零 focus，再复位，才能验证 interrupt 把 focus 接回 target。
      hud.pointer('pan', 100, 0);
      _advance(hud, 0.4, 1.0);
      expect(hud.focus.length, greaterThan(0.5));
      hud.reset(true);
      hud.update(1.05, 0);
      final ViewerSpherical partial = hud.pose;
      final ViewerVector partialFocus = hud.focus;
      expect(partialFocus.length, greaterThan(0.3));
      hud.pointer('pointerdown', 10, 10);
      expect(hud.resetting, isFalse);
      expect(hud.goal.theta, closeTo(partial.theta, 1e-12));
      expect(hud.goal.radius, closeTo(partial.radius, 1e-12));
      expect(hud.target.x, closeTo(partialFocus.x, 1e-12));
      expect(hud.target.length, closeTo(partialFocus.length, 1e-12));
    });

    test('reduced 时复位立即生效（:104-112）', () {
      final ViewerHud hud = _opened();
      hud.pointer('pointerdown', 0, 0);
      hud.pointer('pointermove', 500, 300);
      hud.reduced(true);
      hud.reset(true);
      expect(hud.resetting, isFalse);
      expect(hud.pose.radius, closeTo(viewerDefaultEye.length, 1e-9));
    });
  });

  group('键盘（NativeViewer.cpp:162-200）', () {
    test('Escape 关闭；Home 复位', () {
      final ViewerHud hud = _opened();
      hud.key('Escape', 1);
      expect(hud.closing, isTrue);
      final ViewerHud other = _opened();
      other.pointer('pointerdown', 0, 0);
      other.pointer('pointermove', 250, 0);
      other.key('Home', 1);
      expect(other.resetting, isTrue);
    });

    test('未 ready 或 closing 时除 Escape 外全部忽略', () {
      final ViewerHud hud = ViewerHud();
      hud.open(0);
      hud.key('ArrowRight', 0.1);
      expect(hud.target.length, 0);
      expect(hud.goal.radius, viewerDefaultEye.length);
    });

    test('+/-/= 缩放并夹在 5..28（:186-190）', () {
      final ViewerHud hud = _opened();
      for (int i = 0; i < 40; i++) {
        hud.key('-', 1);
      }
      expect(hud.goal.radius, viewerMaxRadius);
      for (int i = 0; i < 80; i++) {
        hud.key('+', 1);
      }
      expect(hud.goal.radius, viewerMinRadius);
    });

    test('方向键按相机基移动注视点，并夹在 |target|<=5（:191-200）', () {
      final ViewerHud hud = _opened();
      final ViewerMatrix camera = ViewerMatrix.camera(hud.eye, hud.focus);
      final ViewerVector right = ViewerVector(camera.values[0], camera.values[1], camera.values[2]);
      hud.key('ArrowRight', 1);
      final double step = viewerDefaultEye.length * 0.025;
      expect(hud.target.dot(right), closeTo(step, 1e-9));
      for (int i = 0; i < 60; i++) {
        hud.key('ArrowRight', 1);
      }
      expect(hud.target.length, closeTo(viewerTargetLimit, 1e-9));
    });
  });

  group('指针（NativeViewer.cpp:202-247）', () {
    test('未 ready 时忽略所有指针事件', () {
      final ViewerHud hud = ViewerHud();
      hud.open(0);
      hud.pointer('pointerdown', 10, 10);
      expect(hud.dragging, isFalse);
      hud.pointer('wheel', 0, 0, -100);
      expect(hud.goal.radius, viewerDefaultEye.length);
    });

    test('拖动按 2*pi*0.65/height 改 theta/phi，phi 夹在 (0, pi)', () {
      final ViewerHud hud = _opened();
      final double theta0 = hud.goal.theta;
      final double phi0 = hud.goal.phi;
      hud.pointer('pointerdown', 100, 100);
      expect(hud.dragging, isTrue);
      hud.pointer('pointermove', 200, 140);
      final double unit = 2 * math.pi * 0.65 / 1080;
      expect(hud.goal.theta, closeTo(theta0 - 100 * unit, 1e-12));
      expect(hud.goal.phi, closeTo(phi0 - 40 * unit, 1e-12));
      hud.pointer('pointerup', 0, 0);
      expect(hud.dragging, isFalse);

      for (int i = 0; i < 200; i++) {
        hud.pointer('pointerdown', 0, 0);
        hud.pointer('pointermove', 0, 5000);
      }
      expect(hud.goal.phi, greaterThan(0));
      expect(hud.goal.phi, lessThan(math.pi));
    });

    test('滚轮负 delta 缩小半径（放大），正 delta 放大，均夹 5..28（:228-235）', () {
      final ViewerHud hud = _opened();
      final double start = hud.goal.radius;
      hud.pointer('wheel', 0, 0, -50);
      final double scale = math.pow(0.95, 0.7 * 50 * 0.01).toDouble();
      expect(hud.goal.radius, closeTo(start * scale, 1e-12));
      for (int i = 0; i < 200; i++) {
        hud.pointer('wheel', 0, 0, -50);
      }
      expect(hud.goal.radius, viewerMinRadius);
      for (int i = 0; i < 400; i++) {
        hud.pointer('wheel', 0, 0, 50);
      }
      expect(hud.goal.radius, viewerMaxRadius);
    });

    test('pan：手指右移把注视点沿 -right 移动，跟手 1:1（:236-247）', () {
      final ViewerHud hud = _opened();
      final ViewerMatrix camera = ViewerMatrix.camera(hud.eye, hud.focus);
      final ViewerVector right = ViewerVector(camera.values[0], camera.values[1], camera.values[2]);
      final ViewerVector up = ViewerVector(camera.values[4], camera.values[5], camera.values[6]);
      final double span = 2 * viewerDefaultEye.length * math.tan(34 * math.pi / 360);
      final double worldPerPixel = span / 1080;
      hud.pointer('pan', 100, 0);
      expect(hud.target.dot(right), closeTo(-100 * worldPerPixel, 1e-12));
      expect(hud.target.dot(up), closeTo(0, 1e-12));
      hud.pointer('pan', 0, 60);
      expect(hud.target.dot(up), closeTo(60 * worldPerPixel, 1e-12));
    });
  });

  group('coverFront（NativeViewer.cpp:125-134）', () {
    test('正面把相机放到 +|eye|，背面放到 -|eye|', () {
      final ViewerHud front = _opened();
      front.coverFront(true);
      final double distance = viewerDefaultEye.length;
      expect(front.pose.radius, closeTo(distance, 1e-12));
      expect(front.eye.z, closeTo(distance, 1e-9));
      expect(front.eye.x, closeTo(0, 1e-12));
      expect(front.focus.length, 0);

      final ViewerHud back = _opened();
      back.coverFront(false);
      expect(back.eye.z, closeTo(-distance, 1e-9));
      expect(back.pose.theta, closeTo(math.pi, 1e-12));
    });
  });

  group('frame 场景字段（NativeViewer.cpp:258-352）', () {
    test('打开后写入 viewer/near/far/view/eye/projection/fog', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      expect(out['viewer'], isTrue);
      expect(out['viewerReady'], isTrue);
      expect(out['near'], 0.3);
      expect(out['far'], 120.0);
      expect((out['view']! as List<double>).length, 16);
      expect(out['eye'], hud.eye.toList());
      expect((out['projection']! as List<double>).length, 16);
      expect(out['fogNear'], closeTo(hud.eye.length - 1, 1e-9));
      expect(out['fogFar'], closeTo(hud.eye.length + 12, 1e-9));
      expect(out['draws'], isEmpty);
    });

    test('横屏 aspect>=1.05 不做 zoom，projection[0]=2n/(r-l)（:264-272）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final List<double> projection = out['projection']! as List<double>;
      final double top = 0.3 * math.tan(34 * math.pi / 360);
      final double height = 2 * top;
      final double width = (1920 / 1080) * height;
      expect(projection[0], closeTo(0.6 / width, 1e-9));
      expect(projection[0], closeTo(1.83986, 1e-4));
      expect(projection[5], closeTo(0.6 / (top - (top - height)), 1e-9));
    });

    test('竖屏 aspect<1.05 按 min(1.15,aspect/0.85)/(1+0.08*spread) 放大（:266-271）', () {
      final ViewerHud hud = _opened(width: 1080, height: 1920);
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final List<double> projection = out['projection']! as List<double>;
      final double aspect = 1080 / 1920;
      final double top = 0.3 * math.tan(34 * math.pi / 360);
      final double width = aspect * 2 * top;
      final double zoom = math.min(1.15, aspect / 0.85) / (1 + 0.08 * hud.spread.value);
      expect(projection[0], closeTo(0.6 / width * zoom, 1e-9));
      expect(projection[5], closeTo(0.6 / (2 * top) * zoom, 1e-9));
      expect(projection[0], closeTo(3.8481, 5e-4));
    });

    test('view 是 camera(eye,focus) 的逆：把 eye 映到原点', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final ViewerMatrix view = ViewerMatrix(out['view']! as List<double>);
      final ViewerVector origin = view.point(hud.eye);
      expect(origin.x, closeTo(0, 1e-9));
      expect(origin.y, closeTo(0, 1e-9));
      expect(origin.z, closeTo(0, 1e-9));
    });

    test('actors 固定一条锚点 actor（:302-305）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final List<Object?> actors = out['actors']! as List<Object?>;
      expect(actors.length, 1);
      expect(actors.first, <String, Object?>{
        'id': 100000,
        'musicKey': null,
        'selected': true,
        'shadowOnly': false,
      });
    });

    test('模板展开顺序 = parts 深度序，封面纸片带 -1/mesh/side2/cassette（:276-300）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final List<Map<String, Object?>> parts = (out['actorTemplate']! as List<Object?>)
          .map((Object? value) => value! as Map<String, Object?>)
          .toList();
      expect(parts.length, 3);
      expect(parts[0]['name'], 'fastener-a');
      expect(parts[1]['name'], 'cover-a');
      expect(parts[2]['name'], '');
      expect(parts[0]['partIndex'], 0);
      expect(parts[1]['partIndex'], 1);
      expect(parts[2]['partIndex'], 2);
      expect(parts[0]['mesh'], 0);
      expect(parts[1]['mesh'], 1);
      expect(parts[2]['mesh'], -1);
      expect(parts[0]['asset'], 'assembly');
      expect(parts[2]['asset'], 'cassette');
      expect(parts[2]['side'], 2);
      expect(parts[1]['side'], 1);
      for (final Map<String, Object?> part in parts) {
        expect(part['castShadow'], isFalse);
      }
      expect((parts[2]['localMatrix']! as List<double>)[12], closeTo(-1.36, 1e-12));
      expect((parts[2]['localMatrix']! as List<double>)[13], closeTo(3.04, 1e-12));
      expect((parts[2]['localMatrix']! as List<double>)[14], closeTo(0.255, 1e-12));
    });

    test('spread=1 时各部件按 depth 沿 z 位移（含封面纸片 +1.85）', () {
      final ViewerHud hud = _opened();
      hud.action('explode', 1);
      _advance(hud, 0.4, 4.0);
      expect(hud.spread.value, 1);
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final List<Map<String, Object?>> parts = (out['actorTemplate']! as List<Object?>)
          .map((Object? value) => value! as Map<String, Object?>)
          .toList();
      expect((parts[0]['localMatrix']! as List<double>)[14], closeTo(2.75, 1e-12));
      expect((parts[1]['localMatrix']! as List<double>)[14], closeTo(1.85, 1e-12));
      expect((parts[2]['localMatrix']! as List<double>)[14], closeTo(0.255 + 1.85, 1e-12));
    });

    test('viewerState 的 transition/surface/exploded 与 stats（:337-351）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final Map<String, Object?> state = out['viewerState']! as Map<String, Object?>;
      expect(state['transition'], 'open');
      expect(state['surface'], 'clear');
      expect(state['exploded'], 'false');
      final Map<String, Object?> stats =
          jsonDecode(state['stats']! as String) as Map<String, Object?>;
      expect(stats.length, 13);
      expect(stats['ready'], true);
      expect((stats['distance']! as num).toDouble(), closeTo(hud.pose.radius, 1e-12));
      expect((stats['clarity']! as num).toDouble(), closeTo(hud.clarity.value, 1e-12));
      expect(stats['azimuth'], isA<num>());
      expect((stats['cameraPosition']! as List<Object?>).length, 3);

      hud.action('explode', 1);
      final Map<String, Object?> exploded = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      expect((exploded['viewerState']! as Map<String, Object?>)['exploded'], 'true');
    });

    test('frame 不修改传入 base（复制后写入）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> base = <String, Object?>{'seed': 1, 'nested': <String, Object?>{'x': 2}};
      final Map<String, Object?> out = hud.frame(base, actorTemplate: _actorTemplate());
      expect(base.keys.toList(), <String>['seed', 'nested']);
      expect(base.containsKey('viewer'), isFalse);
      expect(out['seed'], 1);
      expect(out['viewer'], isTrue);
    });

    test('竖屏 spread 收敛到 1 时 zoom 再除以 1.08（:269）', () {
      final ViewerHud hud = _opened(width: 1080, height: 1920);
      hud.action('explode', 1);
      _advance(hud, 0.4, 4.0);
      final List<double> projection = hud
          .frame(<String, Object?>{}, actorTemplate: _actorTemplate())['projection']! as List<double>;
      final double aspect = 1080 / 1920;
      final double top = 0.3 * math.tan(34 * math.pi / 360);
      final double zoom = math.min(1.15, aspect / 0.85) / (1 + 0.08 * 1);
      expect(projection[0], closeTo(0.6 / (aspect * 2 * top) * zoom, 1e-9));
    });
  });

  group('卡片状态与内存（NativeViewer.cpp:303-320）', () {
    test('cardState 20 槽：[0..15]=compose({0,-1.85,0})、[16]=1、[17]=clarity、[18]=theme、[19]=0', () {
      final ViewerHud hud = _opened();
      final List<double> state = hud.cardState();
      expect(state.length, 20);
      expect(state.sublist(0, 12), <double>[1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]);
      expect(state[12], 0);
      expect(state[13], -1.85);
      expect(state[14], 0);
      expect(state[15], 1);
      expect(state[16], 1);
      expect(state[17], hud.clarity.value);
      expect(state[18], hud.theme);
      expect(state[19], 0);
    });

    test('trimMemory 只在关闭时清模板（:303-307）', () {
      final ViewerHud hud = _opened();
      hud.trimMemory();
      expect(hud.meshes, isNotEmpty);
      hud.action('close', 1);
      hud.update(1.3, 0);
      hud.trimMemory();
      expect(hud.meshes, isEmpty);
    });

    test('没有宿主模板时不 ready，也不虚构任何 UI 数据', () {
      final ViewerHud hud = ViewerHud();
      hud.open(0);
      expect(hud.ready, isFalse);
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: const <Map<String, Object?>>[]);
      expect(out['viewer'], isTrue);
      expect(out['viewerReady'], isFalse);
      expect(out['actorTemplate'], isEmpty);
    });
  });

  group('隔离性（契约 2：viewer 不产 2D HUD 命令）', () {
    test('frame 结果只含场景键，从不出现 commands/hits/fixed', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> out = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      for (final String key in <String>['commands', 'hits', 'fixed', 'art', 'scene-draw']) {
        expect(out.containsKey(key), isFalse, reason: key);
      }
      expect(out.keys.toSet(), <String>{
        'viewer',
        'viewerReady',
        'near',
        'far',
        'view',
        'eye',
        'projection',
        'fogNear',
        'fogFar',
        'draws',
        'actorTemplate',
        'actors',
        'viewerState',
      });
    });

    test('同一状态重复取帧稳定（无隐藏可变状态）', () {
      final ViewerHud hud = _opened();
      final Map<String, Object?> first = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      final Map<String, Object?> second = hud.frame(<String, Object?>{}, actorTemplate: _actorTemplate());
      expect(first['view'], second['view']);
      expect(first['projection'], second['projection']);
      expect((first['viewerState']! as Map<String, Object?>)['stats'],
          (second['viewerState']! as Map<String, Object?>)['stats']);
    });
  });
}
