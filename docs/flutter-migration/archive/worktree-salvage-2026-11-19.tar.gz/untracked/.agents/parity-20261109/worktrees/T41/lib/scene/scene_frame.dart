/// Native scene frame envelope — the Dart port of the JSON object that
/// NativeScene::emitFrame builds in Qt/src/NativeSceneFrame.cpp:56-214,
/// together with the draw buffer contract from Qt/src/SceneTypes.h and the
/// scene colour blend from Qt/src/SceneAppearance.cpp:17-32.
///
/// The frame is a QJsonObject in Qt, so the key set, the sorted key order after
/// serialisation and the integral-double rendering are part of the wire contract
/// with the HUD. [SceneFrame.toJson] reproduces both: keys are emitted sorted and
/// integral doubles collapse to integers exactly like QJsonDocument does.
///
/// STATUS: written, deliberately NOT executed. flutter test / dart analyze /
/// formatter / code generation are prohibited in this worktree, so RED/GREEN are
/// both recorded as NOT RUN.
library;

import 'dart:collection';
import 'dart:math' as math;
import 'dart:typed_data';

import 'scene_math.dart';

// ---------------------------------------------------------------------------
// Scene palette — NativeSceneFrame.cpp:110-113.
// ---------------------------------------------------------------------------

/// Daylight paper colour used for the background and the fog ramp.
const String kScenePaperHex = '#eae5e1';

/// Night background colour (NativeSceneFrame.cpp:111).
const String kSceneNightHex = '#11181b';

/// Night fog colour (NativeSceneFrame.cpp:113) — a little bluer than the
/// background so the wall separates from the sky.
const String kSceneFogNightHex = '#263136';

/// SceneAppearance.cpp:17-24 — sRGB hex to three linear-light components.
///
/// Qt routes the hex through QColor and then applies the exact sRGB transfer
/// curve (0.0773993808 for the linear toe, 0.9478672986 / 0.0521327014 with a
/// 2.4 exponent above it). The calibrated 1.8 gamma is not used here: the
/// appearance layer already decoded the textures, this is the clear colour.
List<double> linearColor(String hex) {
  final int packed = _parseHex(hex);
  final int red = (packed >> 16) & 0xff;
  final int green = (packed >> 8) & 0xff;
  final int blue = packed & 0xff;
  return <double>[
    _linearChannel(red / 255.0),
    _linearChannel(green / 255.0),
    _linearChannel(blue / 255.0),
  ];
}

double _linearChannel(double component) => component < 0.04045
    ? component * 0.0773993808
    : math.pow(component * 0.9478672986 + 0.0521327014, 2.4).toDouble();

/// Accepts '#rrggbb', '#aarrggbb' and the three/four digit shorthand, mirroring
/// the forms the appearance table actually uses.
int _parseHex(String hex) {
  String text = hex.trim();
  if (text.startsWith('#')) {
    text = text.substring(1);
  }
  if (text.length == 3) {
    text = text.split('').map((String digit) => digit + digit).join();
  } else if (text.length == 4) {
    text = text.split('').map((String digit) => digit + digit).join();
  }
  if (text.length == 8) {
    text = text.substring(2); // drop the alpha pair: the clear colour is rgb only
  }
  if (text.length != 6) {
    throw FormatException('Scene colour must be #rrggbb or #aarrggbb', hex);
  }
  return int.parse(text, radix: 16);
}

/// SceneAppearance.cpp:25-32 — component-wise linear blend used for the
/// background and the fog colour while the theme crossfades.
List<double> blendLinear(List<double> from, List<double> to, double amount) =>
    <double>[
      from[0] + (to[0] - from[0]) * amount,
      from[1] + (to[1] - from[1]) * amount,
      from[2] + (to[2] - from[2]) * amount,
    ];

/// NativeSceneFrame.cpp:110-111 — blend(paper, night, theme).
List<double> sceneBackgroundColor(double theme) =>
    blendLinear(linearColor(kScenePaperHex), linearColor(kSceneNightHex), theme);

/// NativeSceneFrame.cpp:112-113 — blend(paper, fogNight, theme).
List<double> sceneFogColor(double theme) =>
    blendLinear(linearColor(kScenePaperHex), linearColor(kSceneFogNightHex), theme);

// ---------------------------------------------------------------------------
// Draw buffers — SceneTypes.h:1-21.
// ---------------------------------------------------------------------------

/// Qt SceneDrawData — the two GPU buffers a draw binds plus the fallback id list.
///
/// matrices/themes hold raw bytes because the native submit path never
/// round-trips through JSON (SceneTypes.h:3-7).
class SceneDrawData {
  SceneDrawData({Uint8List? matrices, Uint8List? themes, List<int>? ids})
      : matrices = matrices ?? Uint8List(0),
        themes = themes ?? Uint8List(0),
        ids = ids ?? <int>[];

  Uint8List matrices;
  Uint8List themes;
  List<int> ids;

  bool get isEmpty => matrices.isEmpty && themes.isEmpty && ids.isEmpty;
}

/// Qt SceneDrawBuffers — QHash<int, SceneDrawData>, keyed by draw id.
typedef SceneDrawBuffers = Map<int, SceneDrawData>;

/// SceneTypes.h:13-21 — the focus test the HUD uses to decide whether a card is
/// the one the viewer is showing.
///
/// detailMode is mode == "detail"; instanced draws are never focused, and a
/// non-instanced draw is focused when the viewer is open or when the draw is the
/// music-selected card.
bool isFocusedSceneCard(
  Map<String, Object?> draw, {
  required bool detailMode,
  required bool viewer,
}) {
  final bool instanced = draw['instanced'] == true;
  final bool musicSelected = draw['musicSelected'] == true;
  return detailMode && !instanced && (viewer || musicSelected);
}

// ---------------------------------------------------------------------------
// Actor state — NativeSceneFrame.cpp:142-148.
// ---------------------------------------------------------------------------

/// The 20 doubles per actor instance that the card shader consumes.
///
/// Layout (NativeSceneFrame.cpp:142-147): slots 0..15 hold the column-major model
/// matrix, slot 16 quality, 17 clarity, 18 theme and 19 is reserved zero.
class SceneActorState {
  const SceneActorState({
    required this.matrix,
    required this.quality,
    required this.clarity,
    required this.theme,
  });

  final Mat4 matrix;
  final double quality;
  final double clarity;
  final double theme;

  /// The native std::array<double, 20> copy, in host byte order.
  Float64List toState() {
    final Float64List state = Float64List(20);
    for (int index = 0; index < 16; ++index) {
      state[index] = matrix.values[index];
    }
    state[16] = quality;
    state[17] = clarity;
    state[18] = theme;
    state[19] = 0;
    return state;
  }
}

/// NativeSceneFrame.cpp:121-148 — appends every actor state back to back.
///
/// Qt appends the raw double[20] bytes (sizeof state == 160) in host order; the
/// Dart view uses the same host order so a native reader on the same device sees
/// identical bytes.
Uint8List packSceneActorStates(Iterable<SceneActorState> states) {
  final List<SceneActorState> list = states.toList(growable: false);
  final Float64List packed = Float64List(list.length * 20);
  int cursor = 0;
  for (final SceneActorState state in list) {
    final Float64List values = state.toState();
    for (int index = 0; index < 20; ++index) {
      packed[cursor++] = values[index];
    }
  }
  return packed.buffer.asUint8List(packed.offsetInBytes, packed.lengthInBytes);
}

// ---------------------------------------------------------------------------
// Stats projection — NativeSceneFrame.cpp:178-213.
// ---------------------------------------------------------------------------

/// NativeSceneFrame.cpp:179 — floor(value * 10000 + 0.5) / 10000.
double round4(double value) => (value * 10000 + 0.5).floorToDouble() / 10000;

/// NativeSceneFrame.cpp:190-194 — project a world point through
/// projection * view * compose(actor.position, actor.rotation) and map NDC to
/// pixels with floor((x + 1) * width / 2 + 0.5) and
/// floor((1 - y) * height / 2 + 0.5).
List<int> projectScenePoint(
  Mat4 projectionView,
  Vec3 point, {
  required double width,
  required double height,
}) {
  final Vec3 clip = projectionView.point(point);
  return <int>[
    ((clip.x + 1) * width / 2 + 0.5).floor(),
    ((1 - clip.y) * height / 2 + 0.5).floor(),
  ];
}

/// NativeSceneFrame.cpp:182 — {"lane": lane, "row": row}.
Map<String, Object?> sceneCellJson(SceneCell cell) =>
    <String, Object?>{'lane': cell.lane, 'row': cell.row};

/// NativeSceneFrame.cpp:195-213 — the stats block of the frame.
///
/// selectedSlot is fileLocation(selected).lane * 32 + row
/// (NativeSceneFrame.cpp:206), which is why the row there is the file row
/// (12 + index) rather than the card row.
Map<String, Object?> buildSceneStats({
  required Mat4 projection,
  required Mat4 view,
  required Vec3 actorPosition,
  required Vec3 actorRotation,
  required SceneCell actorCell,
  required SceneCell selectedCell,
  required int selectedSlot,
  required Vec3 eye,
  required double width,
  required double height,
  required double fieldOfView,
  required Map<String, Object?> decryption,
  required int archiveCount,
  required int archiveCandidates,
  required int returningFiles,
  required List<Map<String, Object?>> pulses,
  required double clearance,
  required SceneCell coordinateOrigin,
  required bool holdingArchive,
}) {
  final Mat4 projectionView = projection * view * Mat4.compose(actorPosition, actorRotation);
  List<int> project(Vec3 point) =>
      projectScenePoint(projectionView, point, width: width, height: height);
  return <String, Object?>{
    'loaded': true,
    'fieldOfView': fieldOfView,
    'decryption': decryption,
    'topLeft': project(const Vec3(-2.5, 3.7, 0)),
    'topRight': project(const Vec3(2.5, 3.7, 0)),
    'labelTopLeft': project(const Vec3(-1.855, 3.27, 0.255)),
    'labelBottomLeft': project(const Vec3(-1.855, 2.81, 0.255)),
    'modelPosition': <double>[
      round4(actorPosition.x),
      round4(actorPosition.y),
      round4(actorPosition.z),
    ],
    'cameraPosition': <double>[round4(eye.x), round4(eye.y), round4(eye.z)],
    'selectedCell': sceneCellJson(actorCell),
    'selectedSlot': selectedSlot,
    'archiveCount': archiveCount,
    'archiveCandidates': archiveCandidates,
    'returningFiles': returningFiles,
    'pulses': pulses,
    'clearance': clearance,
    'coordinateOrigin': sceneCellJson(coordinateOrigin),
    'holdingArchive': holdingArchive,
  };
}

/// NativeSceneFrame.cpp:50-51 — the frame counts as changed while the detail
/// fade is still converging. The engine uses this to keep the scene awake; if it
/// is dropped, the detail page stays transparent until an unrelated wake.
bool sceneDetailFading({required String mode, required double detail}) =>
    mode == 'detail' && detail < 0.99;

// ---------------------------------------------------------------------------
// Frame envelope — NativeSceneFrame.cpp:87-119.
// ---------------------------------------------------------------------------

/// A single emitted scene frame.
///
/// The wrapper exists instead of a bare map so the viewer overlay
/// (Qt/src/NativeViewer.cpp:276-355) can mutate the keys it owns while every
/// other consumer reads typed values. Keys are the Qt JSON keys verbatim; see
/// [toJson] for the wire form.
class SceneFrame {
  SceneFrame([Map<String, Object?>? fields])
      : fields = LinkedHashMap<String, Object?>.from(fields ?? const <String, Object?>{});

  /// NativeSceneFrame.cpp:87-119 — the base frame emitted before the viewer
  /// overlay and before the actor pass.
  ///
  /// actors / actorTemplate / stats are attached by the caller because they need
  /// the appearance table and the actor list; every key the base frame owns is
  /// filled here with the same literal Qt uses.
  factory SceneFrame.base({
    required String mode,
    required int selected,
    required Mat4 view,
    required Mat4 projection,
    required Mat4 aoProjection,
    required Vec3 eye,
    required double theme,
    required double fogNear,
    required double fogFar,
    required double detail,
    required double time,
    required Map<String, Object?> boot,
    required double focus,
    required double aperture,
    int pendingAnimations = 0,
    int pointerCursor = 0,
    bool reference = false,
    int culledCards = 0,
    int shadowCards = 0,
    int returningCards = 0,
    int returningPartNodes = 0,
    int globalSubdued = 0,
    List<String> returningMusicKeys = const <String>[],
    double returningAgeMax = 0,
    List<Map<String, Object?>> draws = const <Map<String, Object?>>[],
  }) {
    final SceneFrame frame = SceneFrame();
    frame.fields.addAll(<String, Object?>{
      'pendingAnimations': pendingAnimations,
      'pointerCursor': pointerCursor,
      'aoProjection': aoProjection.toJson(),
      'reference': reference,
      'near': kSceneNear,
      'far': kSceneFar,
      'viewer': false,
      'viewerReady': false,
      'viewerState': <String, Object?>{},
      'mode': mode,
      'selected': selected,
      'culledCards': culledCards,
      'shadowCards': shadowCards,
      'returningCards': returningCards,
      'returningPartNodes': returningPartNodes,
      'globalSubdued': globalSubdued,
      'returningMusicKeys': List<String>.from(returningMusicKeys),
      'returningAgeMax': returningAgeMax,
      'time': time,
      'draws': List<Map<String, Object?>>.from(draws),
      'view': view.toJson(),
      'projection': projection.toJson(),
      'eye': eye.toJson(),
      'background': sceneBackgroundColor(theme),
      'fogColor': sceneFogColor(theme),
      'fogNear': fogNear,
      'fogFar': fogFar,
      'detail': smoothStep5((detail - kArchiveDetailStart) / kArchiveDetailSpan),
      'boot': boot,
      'focus': focus,
      'aperture': aperture,
    });
    return frame;
  }

  /// Insertion order of the Qt literal; [toJson] sorts on the way out.
  final LinkedHashMap<String, Object?> fields;

  Object? operator [](String key) => fields[key];

  void operator []=(String key, Object? value) => fields[key] = value;

  bool has(String key) => fields.containsKey(key);

  /// Attaches the keys the actor pass owns (NativeSceneFrame.cpp:162-166).
  void attachActorPass({
    required int culledCards,
    required int shadowCards,
    required List<Map<String, Object?>> actorTemplate,
    required double appearanceRevision,
    required List<Map<String, Object?>> actors,
  }) {
    fields['culledCards'] = culledCards;
    fields['shadowCards'] = shadowCards;
    fields['actorTemplate'] = actorTemplate;
    fields['appearanceRevision'] = appearanceRevision;
    fields['actors'] = actors;
  }

  String get mode => fields['mode'] as String? ?? 'boot';

  bool get viewer => fields['viewer'] == true;

  set viewer(bool value) => fields['viewer'] = value;

  bool get viewerReady => fields['viewerReady'] == true;

  set viewerReady(bool value) => fields['viewerReady'] = value;

  Map<String, Object?> get viewerState =>
      (fields['viewerState'] as Map<Object?, Object?>? ?? const <Object?, Object?>{})
          .cast<String, Object?>();

  set viewerState(Map<String, Object?> value) => fields['viewerState'] = value;

  double get near => _asDouble(fields['near']);

  set near(double value) => fields['near'] = value;

  double get far => _asDouble(fields['far']);

  set far(double value) => fields['far'] = value;

  double get detail => _asDouble(fields['detail']);

  double get fogNear => _asDouble(fields['fogNear']);

  set fogNear(double value) => fields['fogNear'] = value;

  double get fogFar => _asDouble(fields['fogFar']);

  set fogFar(double value) => fields['fogFar'] = value;

  double get time => _asDouble(fields['time']);

  Map<String, Object?> get stats =>
      (fields['stats'] as Map<Object?, Object?>? ?? const <Object?, Object?>{})
          .cast<String, Object?>();

  set stats(Map<String, Object?> value) => fields['stats'] = value;

  /// NativeViewer.cpp:281-284 — the viewer pass overwrites the camera keys.
  void setCamera({required Mat4 view, required Mat4 projection, required Vec3 eye}) {
    fields['view'] = view.toJson();
    fields['projection'] = projection.toJson();
    fields['eye'] = eye.toJson();
  }

  List<double> get view => _asDoubles(fields['view']);

  List<double> get projection => _asDoubles(fields['projection']);

  List<double> get eye => _asDoubles(fields['eye']);

  List<Map<String, Object?>> get draws => _asMaps(fields['draws']);

  set draws(List<Map<String, Object?>> value) => fields['draws'] = value;

  List<Map<String, Object?>> get actors => _asMaps(fields['actors']);

  set actors(List<Map<String, Object?>> value) => fields['actors'] = value;

  List<Map<String, Object?>> get actorTemplate => _asMaps(fields['actorTemplate']);

  set actorTemplate(List<Map<String, Object?>> value) => fields['actorTemplate'] = value;

  /// True while the detail page is still fading in (NativeSceneFrame.cpp:50-51).
  bool get detailFading => sceneDetailFading(mode: mode, detail: detail);

  /// The wire form: keys sorted like QJsonObject and integral doubles rendered as
  /// integers like QJsonDocument.
  Map<String, Object?> toJson() {
    final List<String> keys = fields.keys.toList(growable: false)..sort();
    final Map<String, Object?> out = <String, Object?>{};
    for (final String key in keys) {
      out[key] = _wireValue(fields[key]);
    }
    return out;
  }

  /// Convenience for the native bridge: the frame encoded exactly once, with the
  /// same escaping QJsonDocument uses for control characters.
  String toJsonText() => _encodeWireMap(toJson());

  @override
  String toString() => 'SceneFrame(' + fields.length.toString() + ' keys, mode=' + mode + ')';
}

String _encodeWireMap(Map<String, Object?> value) {
  final StringBuffer buffer = StringBuffer('{');
  bool first = true;
  value.forEach((String key, Object? entry) {
    if (!first) {
      buffer.write(',');
    }
    first = false;
    buffer
      ..write(_encodeWireString(key))
      ..write(':')
      ..write(_encodeWireValue(entry));
  });
  buffer.write('}');
  return buffer.toString();
}

String _encodeWireValue(Object? value) {
  if (value == null) {
    return 'null';
  }
  if (value is String) {
    return _encodeWireString(value);
  }
  if (value is bool) {
    return value ? 'true' : 'false';
  }
  if (value is int) {
    return value.toString();
  }
  if (value is double) {
    if (!value.isFinite) {
      return 'null';
    }
    if (value == value.roundToDouble() && value.abs() < 1e15) {
      return value.toInt().toString();
    }
    return value.toString();
  }
  if (value is List<Object?>) {
    final StringBuffer buffer = StringBuffer('[');
    for (int index = 0; index < value.length; ++index) {
      if (index != 0) {
        buffer.write(',');
      }
      buffer.write(_encodeWireValue(value[index]));
    }
    buffer.write(']');
    return buffer.toString();
  }
  if (value is Map<Object?, Object?>) {
    return _encodeWireMap(value.cast<String, Object?>());
  }
  return _encodeWireString(value.toString());
}

String _encodeWireString(String value) {
  final StringBuffer buffer = StringBuffer('"');
  for (final int unit in value.codeUnits) {
    if (unit == 0x22) {
      buffer.write('\\"');
    } else if (unit == 0x5c) {
      buffer.write('\\\\');
    } else if (unit == 0x0a) {
      buffer.write('\\n');
    } else if (unit == 0x0d) {
      buffer.write('\\r');
    } else if (unit == 0x09) {
      buffer.write('\\t');
    } else if (unit < 0x20) {
      buffer.write('\\u00');
      buffer.write(unit.toRadixString(16).padLeft(2, '0'));
    } else {
      buffer.writeCharCode(unit);
    }
  }
  buffer.write('"');
  return buffer.toString();
}

double _asDouble(Object? value) => value is num ? value.toDouble() : 0;

List<double> _asDoubles(Object? value) {
  if (value is List<double>) {
    return value;
  }
  if (value is List<Object?>) {
    return value.map(_asDouble).toList(growable: false);
  }
  return const <double>[];
}

List<Map<String, Object?>> _asMaps(Object? value) {
  if (value is List<Map<String, Object?>>) {
    return value;
  }
  if (value is List<Object?>) {
    return value
        .whereType<Map<Object?, Object?>>()
        .map((Map<Object?, Object?> entry) => entry.cast<String, Object?>())
        .toList(growable: false);
  }
  return const <Map<String, Object?>>[];
}

/// QJsonValue renders an integral double without a fractional part; keep the same
/// shape so the frame JSON stays byte-comparable with Qt.
Object? _wireValue(Object? value) {
  if (value is List<Object?>) {
    return value.map(_wireValue).toList(growable: false);
  }
  if (value is Map<Object?, Object?>) {
    final List<String> keys =
        value.keys.map((Object? key) => key.toString()).toList(growable: false)..sort();
    final Map<String, Object?> out = <String, Object?>{};
    for (final String key in keys) {
      out[key] = _wireValue(value[key]);
    }
    return out;
  }
  if (value is double && value.isFinite && value == value.roundToDouble() && value.abs() < 1e15) {
    return value.toInt();
  }
  return value;
}
