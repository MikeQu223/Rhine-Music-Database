import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/detail_sort_modal.dart';

// ---------------------------------------------------------------------------
// Qt reference constants.
//
// Every literal in this section is copied from the Qt source, never from the
// Dart port, so the assertions below fail if the port drifts:
//   Qt/src/NativeHud.cpp:141-144           modalBounds("detail-sort")
//   Qt/src/NativeHud.cpp:160-166           containerLayout
//   Qt/src/NativeHudModal.cpp:122-141      the popover branch
//   Qt/src/NativeHud.cpp:10-15, 102-120    ink/fill/text/hit/button
//   Qt/src/NativeHudMusic.cpp:40-60        open guard + sort action
//   Qt/src/NativeHudController.cpp:913-925 Escape
//   Qt/src/UiMotion.h:24-42, UiMotion.cpp:7-22, 86-120  SurfaceMotion
// ---------------------------------------------------------------------------

/// NativeHud stage width (1920x1080 landscape stage).
const double _qtStageWidth = 1920;

/// NativeHud stage height, i.e. the outside catcher height
/// (Qt/src/NativeHudModal.cpp:128).
const double _qtStageHeight = 1080;

/// containerLayout: sidebar = clamp(width * 0.23 - 40, 250, 340)
/// (Qt/src/NativeHud.cpp:161-163). At 1920 this clamps to 340.
const double _qtSidebar = 340;

/// containerLayout: left = 40 (Qt/src/NativeHud.h:38).
const double _qtLayoutLeft = 40;

/// containerLayout: x = left + sidebar + 36 (Qt/src/NativeHud.cpp:164).
const double _qtLayoutX = _qtLayoutLeft + _qtSidebar + 36;

/// modalBounds x for detail-sort: layout.x + 195 (Qt/src/NativeHud.cpp:141).
const double _qtPanelX = _qtLayoutX + 195;

/// modalBounds y (Qt/src/NativeHud.cpp:141).
const double _qtPanelY = 391;

/// modalBounds width (Qt/src/NativeHud.cpp:141).
const double _qtPanelW = 240;

/// modalBounds height (Qt/src/NativeHud.cpp:141).
const double _qtPanelH = 184;

/// Row inset from the panel edge (Qt/src/NativeHudModal.cpp:135).
const double _qtRowInset = 8;

/// Row height (Qt/src/NativeHudModal.cpp:135).
const double _qtRowH = 42;

/// Row pitch: bounds.y() + 8 + index * 42 (Qt/src/NativeHudModal.cpp:135).
const double _qtRowPitch = 42;

/// Row width: bounds.width() - 16 (Qt/src/NativeHudModal.cpp:135).
const double _qtRowW = _qtPanelW - 16;

/// Row text size (Qt/src/NativeHudModal.cpp:136).
const double _qtRowTextSize = 14;

/// min(10, rowWidth / 8) at the Qt width (Qt/src/NativeHud.cpp:113).
const double _qtButtonInset = 10;

/// Text x inside a button: rect.x + inset (Qt/src/NativeHud.cpp:118).
const double _qtTextX = _qtPanelX + _qtRowInset + _qtButtonInset;

/// Text y inside row [index]: rect.y + (h - size) / 2 - 4 (NativeHud.cpp:118).
double _qtTextY(int index) =>
    _qtPanelY +
    _qtRowInset +
    index * _qtRowPitch +
    (_qtRowH - _qtRowTextSize) / 2 -
    4;

/// Panel fill, light (Qt/src/NativeHudModal.cpp:130).
const List<Object?> _qtLightPanelFill = <Object?>[0.929, 0.922, 0.894, 1];

/// Panel fill, dark: the detail-sort branch writes four components and no
/// colour space (Qt/src/NativeHudModal.cpp:130), unlike the other modals which
/// write "calibratedWhite" (Qt/src/NativeHudModal.cpp:146).
const List<Object?> _qtDarkPanelFill = <Object?>[0.15, 0.15, 0.15, 1];

/// Modal-control tint, light (Qt/src/NativeHud.cpp:116).
const List<Object?> _qtLightButtonTint = <Object?>[0.44, 0.49, 0.36, 0.1];

/// Modal-control tint, dark (Qt/src/NativeHud.cpp:116).
const List<Object?> _qtDarkButtonTint = <Object?>[0.55, 0.59, 0.46, 0.13];

/// ink(), light (Qt/src/NativeHud.cpp:13-14).
const List<Object?> _qtLightInk = <Object?>[0.08, 0.085, 0.075, 1, 'calibratedRGB'];

/// ink(), dark (Qt/src/NativeHud.cpp:11-12).
const List<Object?> _qtDarkInk = <Object?>[0.92, 0.92, 0.92, 1, 'calibratedWhite'];

/// Field order (Qt/src/NativeHudModal.cpp:131).
const List<String> _qtFields = <String>['none', 'title', 'album', 'artist'];

/// Label order (Qt/src/NativeHudModal.cpp:132).
const List<String> _qtLabels = <String>[
  '默认排序',
  '按歌曲名排序',
  '按专辑名排序',
  '按歌手名排序',
];

/// Selection prefix (Qt/src/NativeHudModal.cpp:134).
const String _qtCheck = '✓ ';

/// Action prefix (Qt/src/NativeHudModal.cpp:136).
const String _qtActionPrefix = 'music:sort:detail:';

/// The outside catcher action and label (Qt/src/NativeHudModal.cpp:128).
const String _qtCloseAction = 'close-modal';
const String _qtCatcherLabel = '关闭排序菜单';

/// Escape target while any modal is open (Qt/src/NativeHudController.cpp:919).
const String _qtEscapeAction = 'close-modal';

/// The cleanup Qt runs before applying the sort when the menu is already open
/// (Qt/src/NativeHudMusic.cpp:51-55).
const List<String> _qtCleanupWhenOpen = <String>[
  'modal.clear',
  'closing=false',
  'searchGeneration++',
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Deterministic stand-in for NativeHud glyph metrics.
///
/// width = text.length * perChar + tracking, recorded so tests can prove that
/// fit() measured through the injected hook instead of guessing.
class _Measure {
  _Measure(this.perChar);

  /// Width per character, in stage pixels.
  final double perChar;

  /// Every measurement request, in call order: [text, size, weight, tracking].
  final List<List<Object?>> calls = <List<Object?>>[];

  double call(String text, double size, String? weight, double tracking) {
    calls.add(<Object?>[text, size, weight, tracking]);
    return text.length * perChar + tracking;
  }
}

/// Identity-ish spy hook: shifts by a fixed delta and records the input rect.
class _RectSpy {
  _RectSpy(this.dx, this.dy);

  final double dx;
  final double dy;

  /// Every rect handed to the hook, in call order.
  final List<List<double>> inputs = <List<double>>[];

  List<double> call(double x, double y, double w, double h) {
    inputs.add(<double>[x, y, w, h]);
    return <double>[x + dx, y + dy, w, h];
  }
}

/// Always measures zero: no label ever truncates.
double _zeroMeasure(String text, double size, String? weight, double tracking) =>
    0.0;

/// Identity rect hook, i.e. the landscape stage.
List<double> _identityRect(double x, double y, double w, double h) =>
    <double>[x, y, w, h];

/// Builds the port with the injected state a test cares about.
DetailSortModal _modal({
  double width = _qtStageWidth,
  bool dark = false,
  bool reduced = false,
  bool closing = false,
  double opacity = 1.0,
  double offset = 0.0,
  String detailSort = 'none',
  DetailSortMeasureText measureText = _zeroMeasure,
  DetailSortRectHook rectHook = _identityRect,
}) =>
    DetailSortModal(
      width: width,
      dark: dark,
      reduced: reduced,
      closing: closing,
      opacity: opacity,
      offset: offset,
      detailSort: detailSort,
      measureText: measureText,
      rectHook: rectHook,
    );

/// The Qt label for row [index] under a selection: the selected row carries
/// the `✓ ` prefix (Qt/src/NativeHudModal.cpp:134).
String _labelFor(int index, int selected) =>
    (selected == index ? _qtCheck : '') + _qtLabels[index];

/// The Qt op stream for the light theme, no offset, no opacity ramp, the
/// constructor's selection (row 0 checked, since the port defaults to the Qt
/// `detailSort == "none"`), and a zero-width measurer (nothing truncates).
List<List<Object?>> _qtCommands({
  List<Object?> panelFill = _qtLightPanelFill,
  List<Object?> tint = _qtLightButtonTint,
  List<Object?> ink = _qtLightInk,
  double opacity = 1.0,
  double offset = 0.0,
  int selected = 0,
}) {
  final List<List<Object?>> commands = <List<Object?>>[
    <Object?>['save'],
    <Object?>['alpha', opacity],
    <Object?>['translate', 0.0, offset],
    <Object?>['fill', panelFill, _qtPanelX, _qtPanelY, _qtPanelW, _qtPanelH],
  ];
  for (int index = 0; index < _qtFields.length; index++) {
    final double rowY = _qtPanelY + _qtRowInset + index * _qtRowPitch;
    commands.add(<Object?>[
      'fill',
      tint,
      _qtPanelX + _qtRowInset,
      rowY,
      _qtRowW,
      _qtRowH,
    ]);
    commands.add(<Object?>[
      'text',
      _labelFor(index, selected),
      _qtTextX,
      _qtTextY(index),
      _qtRowTextSize,
      'regular',
      0.0,
      ink,
    ]);
  }
  commands.add(<Object?>['restore']);
  return commands;
}

/// The Qt hit table: the outside catcher first (Qt/src/NativeHudModal.cpp:128),
/// then the four rows (:135-136).
List<List<Object?>> _qtHits({
  double offset = 0.0,
  int selected = 0,
  List<String> fields = _qtFields,
  List<String> labels = _qtLabels,
  double panelX = _qtPanelX,
  double width = _qtStageWidth,
}) {
  final List<List<Object?>> hits = <List<Object?>>[
    <Object?>[0.0, -offset, width, _qtStageHeight, _qtCloseAction, _qtCatcherLabel],
  ];
  for (int index = 0; index < fields.length; index++) {
    hits.add(<Object?>[
      panelX + _qtRowInset,
      _qtPanelY + _qtRowInset + index * _qtRowPitch,
      _qtRowW,
      _qtRowH,
      _qtActionPrefix + fields[index],
      (selected == index ? _qtCheck : '') + labels[index],
    ]);
  }
  return hits;
}

void main() {
  // -------------------------------------------------------------------------
  // Frame shape
  // -------------------------------------------------------------------------
  group('frame shape', () {
    test('paints a popover: save, alpha, translate, panel, four rows, restore',
        () {
      final DetailSortModalFrame frame = _modal().build();

      expect(frame.commands.length, 13);
      expect(frame.commands.first, <Object?>['save']);
      expect(frame.commands.last, <Object?>['restore']);
      expect(
        frame.commands
            .where((List<Object?> op) => op.first == 'restore')
            .length,
        1,
      );
      expect(
        frame.commands.where((List<Object?> op) => op.first == 'fill').length,
        5,
        reason: 'one panel fill plus one tint fill per row',
      );
      expect(
        frame.commands.where((List<Object?> op) => op.first == 'text').length,
        4,
      );
    });

    test('installs no scrim: no full-stage fill exists', () {
      final DetailSortModalFrame frame = _modal().build();

      for (final List<Object?> op in frame.commands) {
        if (op.first == 'fill') {
          final bool fullStage = op[2] == 0.0 &&
              op[3] == 0.0 &&
              op[4] == _qtStageWidth &&
              op[5] == _qtStageHeight;
          expect(fullStage, isFalse,
              reason: 'the detail-sort popover has no scrim '
                  '(Qt/src/NativeHudModal.cpp:122-141)');
        }
      }
      expect(
        frame.commands.any((List<Object?> op) => op.first == 'clip'),
        isFalse,
      );
      expect(
        frame.commands.any((List<Object?> op) => op.first == 'scale'),
        isFalse,
      );
    });

    test('draws no generic header: no rule and no header-sized text', () {
      final DetailSortModalFrame frame = _modal().build();

      expect(
        frame.commands.any((List<Object?> op) => op.first == 'rule'),
        isFalse,
      );
      for (final List<Object?> op in frame.commands) {
        if (op.first == 'text') {
          expect(op[4], _qtRowTextSize);
          expect(op[2], _qtTextX);
        }
      }
    });

    test('every command is a flat array headed by its op name', () {
      final DetailSortModalFrame frame = _modal().build();

      for (final List<Object?> op in frame.commands) {
        expect(op, isNotEmpty);
        expect(op.first, isA<String>());
      }
      for (final List<Object?> hit in frame.hits) {
        expect(hit.length, 6);
        expect(hit[0], isA<double>());
        expect(hit[1], isA<double>());
        expect(hit[2], isA<double>());
        expect(hit[3], isA<double>());
        expect(hit[4], isA<String>());
        expect(hit[5], isA<String>());
      }
    });
  });

  // -------------------------------------------------------------------------
  // Command stream matches Qt
  // -------------------------------------------------------------------------
  group('command stream matches Qt', () {
    test('light theme, none selected, opacity 1, offset 0', () {
      final DetailSortModalFrame frame = _modal().build();

      expect(frame.commands, _qtCommands());
    });

    test('dark theme swaps the panel fill, the tint and the ink', () {
      final DetailSortModalFrame frame = _modal(dark: true).build();

      expect(
        frame.commands,
        _qtCommands(
          panelFill: _qtDarkPanelFill,
          tint: _qtDarkButtonTint,
          ink: _qtDarkInk,
        ),
      );
    });

    test('the injected opacity and offset are painted verbatim', () {
      final DetailSortModalFrame frame =
          _modal(opacity: 0.42, offset: 8).build();

      expect(frame.commands[1], <Object?>['alpha', 0.42]);
      expect(frame.commands[2], <Object?>['translate', 0.0, 8.0]);
      expect(frame.commands, _qtCommands(opacity: 0.42, offset: 8));
    });

    test('the panel fill is the detail-sort four-component dark literal', () {
      final DetailSortModalFrame frame = _modal(dark: true).build();
      final List<Object?> panelFill = frame.commands[3];

      expect(panelFill[0], 'fill');
      expect(panelFill[1], <Object?>[0.15, 0.15, 0.15, 1]);
      expect(panelFill[2], _qtPanelX);
      expect(panelFill[3], _qtPanelY);
      expect(panelFill[4], _qtPanelW);
      expect(panelFill[5], _qtPanelH);
    });

    test('row order is fields order, one tint fill and one text each', () {
      final DetailSortModalFrame frame = _modal().build();

      for (int index = 0; index < _qtFields.length; index++) {
        final List<Object?> fill = frame.commands[4 + index * 2];
        final List<Object?> text = frame.commands[5 + index * 2];
        expect(fill, <Object?>[
          'fill',
          _qtLightButtonTint,
          _qtPanelX + _qtRowInset,
          _qtPanelY + _qtRowInset + index * _qtRowPitch,
          _qtRowW,
          _qtRowH,
        ]);
        expect(text[0], 'text');
        expect(text[1], _labelFor(index, 0));
        expect(text[2], _qtTextX);
        expect(text[3], _qtTextY(index));
        expect(text[4], _qtRowTextSize);
        expect(text[5], 'regular');
        expect(text[6], 0.0);
        expect(text[7], _qtLightInk);
      }
    });
  });

  // -------------------------------------------------------------------------
  // Panel geometry
  // -------------------------------------------------------------------------
  group('panel geometry', () {
    test('containerLayout matches Qt at the design width', () {
      expect(DetailSortModal.containerLayout(_qtStageWidth), <double>[
        _qtLayoutLeft,
        _qtSidebar,
        _qtLayoutX,
        _qtStageWidth - _qtLayoutX - 40,
      ]);
    });

    test('containerLayout clamps the sidebar at small and large widths', () {
      // 400 * 0.23 - 40 = 52, clamped up to 250 (Qt/src/NativeHud.cpp:161-163).
      expect(DetailSortModal.containerLayout(400), <double>[40, 250, 326, 34]);
      // 2000 * 0.23 - 40 = 420, clamped down to 340.
      expect(DetailSortModal.containerLayout(2000), <double>[
        40,
        340,
        416,
        1544,
      ]);
    });

    test('popoverBounds is layout.x + 195, 391, 240, 184', () {
      expect(DetailSortModal.popoverBounds(_qtStageWidth), <double>[
        _qtPanelX,
        _qtPanelY,
        _qtPanelW,
        _qtPanelH,
      ]);
      expect(DetailSortModal.popoverBounds(400), <double>[521, 391, 240, 184]);
    });

    test('the constants mirror the Qt literals', () {
      expect(DetailSortModal.panelOffsetX, 195);
      expect(DetailSortModal.panelTop, 391);
      expect(DetailSortModal.panelWidth, 240);
      expect(DetailSortModal.panelHeight, 184);
      expect(DetailSortModal.rowHeight, 42);
      expect(DetailSortModal.rowInset, 8);
      expect(DetailSortModal.rowTextSize, 14);
      expect(DetailSortModal.containerLeft, 40);
      expect(DetailSortModal.sidebarMinimum, 250);
      expect(DetailSortModal.sidebarMaximum, 340);
      expect(DetailSortModal.sidebarGap, 36);
    });

    test('the painted panel rectangle is the modalBounds rectangle', () {
      final DetailSortModalFrame frame = _modal(width: 1000).build();
      final List<double> bounds = DetailSortModal.popoverBounds(1000);

      expect(bounds, <double>[521, 391, 240, 184]);
      expect(frame.commands[3], <Object?>[
        'fill',
        _qtLightPanelFill,
        bounds[0],
        bounds[1],
        bounds[2],
        bounds[3],
      ]);
    });
  });

  // -------------------------------------------------------------------------
  // Hit records
  // -------------------------------------------------------------------------
  group('hit records', () {
    test('the outside catcher is hit 0, before every panel hit', () {
      final DetailSortModalFrame frame = _modal().build();

      expect(frame.hits, _qtHits());
      expect(frame.hits.length, 5);
      expect(frame.hits[0], <Object?>[
        0.0,
        0.0,
        _qtStageWidth,
        _qtStageHeight,
        _qtCloseAction,
        _qtCatcherLabel,
      ]);
      for (int index = 1; index < frame.hits.length; index++) {
        expect(
          frame.hits[index][4],
          startsWith(_qtActionPrefix),
          reason: 'panel rows come after the catcher; Overlay.qml:186-215 gives '
              'later hits the higher z, so the catcher must be first',
        );
      }
    });

    test('the catcher cancels the translate, covering the stage 0..1080', () {
      final DetailSortModalFrame frame = _modal(offset: 8).build();

      expect(frame.commands[2], <Object?>['translate', 0.0, 8.0]);
      expect(frame.hits[0], <Object?>[
        0.0,
        -8.0,
        _qtStageWidth,
        _qtStageHeight,
        _qtCloseAction,
        _qtCatcherLabel,
      ]);
      expect(frame.hits[0][1] + 8.0, 0.0,
          reason: 'QML adds modalOffset back to non-fixed hits '
              '(Qt/qml/Overlay.qml:193)');
    });

    test('the catcher is the only full-stage hit', () {
      final DetailSortModalFrame frame = _modal().build();

      for (final List<Object?> hit in frame.hits.skip(1)) {
        expect(hit[2] == _qtStageWidth && hit[3] == _qtStageHeight, isFalse);
      }
    });

    test('rows carry the four sort fields with the Qt labels', () {
      final DetailSortModalFrame frame = _modal().build();

      expect(
        frame.hits.skip(1).map((List<Object?> hit) => hit[4]).toList(),
        <String>[
          'music:sort:detail:none',
          'music:sort:detail:title',
          'music:sort:detail:album',
          'music:sort:detail:artist',
        ],
      );
      expect(
        frame.hits.skip(1).map((List<Object?> hit) => hit[5]).toList(),
        <String>[
          _labelFor(0, 0),
          _labelFor(1, 0),
          _labelFor(2, 0),
          _labelFor(3, 0),
        ],
      );
    });

    test('row rects match the Qt row loop', () {
      final DetailSortModalFrame frame = _modal().build();

      for (int index = 0; index < _qtFields.length; index++) {
        expect(frame.hits[index + 1], <Object?>[
          _qtPanelX + _qtRowInset,
          _qtPanelY + _qtRowInset + index * _qtRowPitch,
          _qtRowW,
          _qtRowH,
          _qtActionPrefix + _qtFields[index],
          _labelFor(index, 0),
        ]);
      }
    });

    test('actionFor builds the Qt action string', () {
      expect(DetailSortModal.actionFor('none'), 'music:sort:detail:none');
      expect(DetailSortModal.actionFor('title'), 'music:sort:detail:title');
      expect(DetailSortModal.actionFor('album'), 'music:sort:detail:album');
      expect(DetailSortModal.actionFor('artist'), 'music:sort:detail:artist');
    });

    test('closeAction and catcherLabel are the Qt strings', () {
      expect(DetailSortModal.closeAction, _qtCloseAction);
      expect(DetailSortModal.catcherLabel, _qtCatcherLabel);
    });
  });

  // -------------------------------------------------------------------------
  // Labels and the selection prefix
  // -------------------------------------------------------------------------
  group('labels and selection prefix', () {
    test('an unknown detailSort value checks no row', () {
      final DetailSortModalFrame frame = _modal(detailSort: 'genre').build();

      expect(
        frame.hits.skip(1).map((List<Object?> hit) => hit[5]).toList(),
        _qtLabels,
      );
    });

    test('the check mark is U+2713 followed by a space', () {
      expect(_qtCheck.runes.toList(), <int>[0x2713, 0x20]);
    });

    test('only the selected row is prefixed', () {
      for (int selected = 0; selected < _qtFields.length; selected++) {
        final DetailSortModalFrame frame =
            _modal(detailSort: _qtFields[selected]).build();
        for (int row = 0; row < _qtFields.length; row++) {
          final String label = frame.hits[row + 1][5] as String;
          final String action = frame.hits[row + 1][4] as String;
          expect(action, _qtActionPrefix + _qtFields[row]);
          if (row == selected) {
            expect(label, _qtCheck + _qtLabels[row]);
          } else {
            expect(label, _qtLabels[row]);
            expect(label.startsWith(_qtCheck), isFalse);
          }
        }
      }
    });

    test('the checked row keeps its action and its geometry', () {
      final DetailSortModalFrame frame = _modal(detailSort: 'album').build();

      expect(frame.hits[3][5], '✓ 按专辑名排序');
      expect(frame.hits[3][4], 'music:sort:detail:album');
      expect(frame.hits[3][2], _qtRowW);
      expect(frame.hits[1][5], '默认排序');
      expect(frame.hits[1][4], 'music:sort:detail:none');
    });

    test('the check mark is painted into the text command too', () {
      final DetailSortModalFrame frame = _modal(detailSort: 'title').build();

      expect(frame.commands[5][1], '默认排序');
      expect(frame.commands[7][1], '✓ 按歌曲名排序');
      expect(frame.commands[9][1], '按专辑名排序');
      expect(frame.commands[11][1], '按歌手名排序');
    });
  });

  // -------------------------------------------------------------------------
  // fit
  // -------------------------------------------------------------------------
  group('fit', () {
    test('a fitting label is measured once and painted unchanged', () {
      final _Measure measure = _Measure(30);
      final DetailSortModalFrame frame =
          _modal(measureText: measure.call).build();

      // The port defaults to the Qt `detailSort == "none"` (NativeHud.h:83),
      // so row 0 is checked even in this "nothing injected" case
      // (Qt/src/NativeHudModal.cpp:134).
      expect(frame.commands[5][1], '✓ 默认排序');
      expect(measure.calls.length, 4);
      expect(
        measure.calls.first,
        <Object?>['✓ 默认排序', 14.0, 'regular', 0.0],
      );
    });

    test('an over-wide label is truncated through the injected measurer', () {
      // 80 px per character: '默认排序' = 320 > 224, '默认排' = 240 > 224,
      // '默认' = 160 <= 224, so the bisection lands on 2, backs off one
      // character and appends the ellipsis (Qt/src/NativeHud.cpp:48-76).
      final _Measure measure = _Measure(80);
      // `album` is a Qt-reachable selection (the sort action assigns the
      // field, Qt/src/NativeHudMusic.cpp:56) and leaves row 0 unchecked.
      final DetailSortModalFrame frame =
          _modal(detailSort: 'album', measureText: measure.call).build();

      expect(frame.commands[5][1], '默…');
      // Row 0 is painted first, so its three measurements come first; the
      // later rows measure their own labels afterwards.
      expect(measure.calls.take(3).toList(), <List<Object?>>[
        <Object?>['默认排序', 14.0, 'regular', 0.0],
        <Object?>['默认排', 14.0, 'regular', 0.0],
        <Object?>['默认', 14.0, 'regular', 0.0],
      ]);
    });

    test('a single character that does not fit degrades to the ellipsis', () {
      final _Measure measure = _Measure(300);
      final DetailSortModalFrame frame =
          _modal(measureText: measure.call).build();

      expect(frame.commands[5][1], '…');
    });

    test('fit measures at the row size, weight regular, tracking 0', () {
      final _Measure measure = _Measure(80);
      _modal(detailSort: 'album', measureText: measure.call).build();

      for (final List<Object?> call in measure.calls) {
        expect(call[1], _qtRowTextSize);
        expect(call[2], 'regular');
        expect(call[3], 0.0);
      }
      expect(measure.calls.first.first, '默认排序');
      // Row 0 (unchecked while album is selected) is measured as the whole
      // label and then as prefixes of it — never as anything else.
      for (final List<Object?> call in measure.calls.take(3)) {
        expect(_qtLabels[0].startsWith(call.first! as String), isTrue);
      }
    });

    test('the checked label is fitted with the check mark included', () {
      final _Measure measure = _Measure(80);
      final DetailSortModalFrame frame =
          _modal(detailSort: 'title', measureText: measure.call).build();

      expect(frame.commands[7][1], '✓…');
      expect(measure.calls.first.first, '✓ 按歌曲名排序');
    });
  });

  // -------------------------------------------------------------------------
  // Injected rect hook
  // -------------------------------------------------------------------------
  group('rect hook', () {
    test('every painted rect goes through the hook, in Qt order', () {
      final _RectSpy spy = _RectSpy(1, 2);
      final DetailSortModalFrame frame = _modal(rectHook: spy.call).build();

      final List<List<double>> expectedInputs = <List<double>>[
        <double>[0, 0, _qtStageWidth, _qtStageHeight],
        <double>[_qtPanelX, _qtPanelY, _qtPanelW, _qtPanelH],
      ];
      for (int index = 0; index < _qtFields.length; index++) {
        expectedInputs.add(<double>[
          _qtPanelX + _qtRowInset,
          _qtPanelY + _qtRowInset + index * _qtRowPitch,
          _qtRowW,
          _qtRowH,
        ]);
      }
      expect(spy.inputs, expectedInputs);

      expect(frame.hits[0], <Object?>[1.0, 2.0, _qtStageWidth, _qtStageHeight]);
      expect(frame.commands[3], <Object?>[
        'fill',
        _qtLightPanelFill,
        _qtPanelX + 1,
        _qtPanelY + 2,
        _qtPanelW,
        _qtPanelH,
      ]);
      expect(frame.hits[1], <Object?>[
        _qtPanelX + _qtRowInset + 1,
        _qtPanelY + _qtRowInset + 2,
        _qtRowW,
        _qtRowH,
        'music:sort:detail:none',
        '✓ 默认排序',
      ]);
    });

    test('the hook maps the catcher too, keeping the -offset compensation', () {
      final _RectSpy spy = _RectSpy(0, 0);
      final DetailSortModalFrame frame =
          _modal(offset: 8, rectHook: spy.call).build();

      expect(spy.inputs.first, <double>[0, -8, _qtStageWidth, _qtStageHeight]);
      expect(frame.hits[0][1], -8.0);
    });

    test('the identity hook returns the stage numbers verbatim', () {
      final DetailSortModalFrame frame = _modal().build();

      expect(frame.hits, _qtHits());
      expect(DetailSortModal.popoverBounds(_qtStageWidth), <double>[
        _qtPanelX,
        _qtPanelY,
        _qtPanelW,
        _qtPanelH,
      ]);
    });
  });

  // -------------------------------------------------------------------------
  // Action table
  // -------------------------------------------------------------------------
  group('action table', () {
    test('music:sort-menu opens the popover only on a detail playlist', () {
      expect(
        DetailSortModal.opensSortMenu(
          currentKind: 'playlist',
          frameMode: 'detail',
        ),
        isTrue,
      );
      expect(
        DetailSortModal.opensSortMenu(
          currentKind: 'playlist',
          frameMode: 'browse',
        ),
        isFalse,
      );
      expect(
        DetailSortModal.opensSortMenu(currentKind: 'album', frameMode: 'detail'),
        isFalse,
      );
      expect(
        DetailSortModal.opensSortMenu(currentKind: '', frameMode: ''),
        isFalse,
      );
      expect(DetailSortModal.playlistKind, 'playlist');
      expect(DetailSortModal.detailMode, 'detail');
      expect(DetailSortModal.popoverKind, 'detail-sort');
    });

    test('an accepted sort action carries the cleanup and four assignments', () {
      for (int index = 0; index < _qtFields.length; index++) {
        final DetailSortActionEffect? effect = DetailSortModal.sortActionEffect(
          field: _qtFields[index],
          mode: 'detail',
          frameMode: 'detail',
          currentKind: 'playlist',
          modal: 'detail-sort',
        );

        expect(effect, isNotNull);
        expect(effect!.field, _qtFields[index]);
        expect(effect.detailSort, _qtFields[index]);
        expect(effect.trackOffset, 0.0);
        expect(effect.setDirectorySort, isTrue);
        expect(effect.beginSort, isTrue);
        expect(effect.clearsModal, isTrue);
        expect(effect.cleanup, _qtCleanupWhenOpen);
      }
    });

    test('the cleanup clears the modal, the closing flag, the search generation',
        () {
      expect(DetailSortCleanup.whenOpen, <String>[
        'modal.clear',
        'closing=false',
        'searchGeneration++',
      ]);
      expect(DetailSortCleanup.whenClosed, isEmpty);
    });

    test('an already-closed menu applies the sort without clearing anything', () {
      final DetailSortActionEffect? effect = DetailSortModal.sortActionEffect(
        field: 'artist',
        mode: 'detail',
        frameMode: 'detail',
        currentKind: 'playlist',
        modal: '',
      );

      expect(effect, isNotNull);
      expect(effect!.clearsModal, isFalse);
      expect(effect.cleanup, isEmpty);
      expect(effect.detailSort, 'artist');
      expect(effect.setDirectorySort, isTrue);
      expect(effect.beginSort, isTrue);
    });

    test('an unknown or mis-cased field is rejected without effects', () {
      expect(
        DetailSortModal.sortActionEffect(
          field: 'genre',
          mode: 'detail',
          frameMode: 'detail',
          currentKind: 'playlist',
          modal: 'detail-sort',
        ),
        isNull,
      );
      expect(
        DetailSortModal.sortActionEffect(
          field: '',
          mode: 'detail',
          frameMode: 'detail',
          currentKind: 'playlist',
          modal: '',
        ),
        isNull,
      );
      expect(
        DetailSortModal.sortActionEffect(
          field: 'TITLE',
          mode: 'detail',
          frameMode: 'detail',
          currentKind: 'playlist',
          modal: '',
        ),
        isNull,
      );
    });

    test('a sort action outside the detail playlist frame is rejected', () {
      expect(
        DetailSortModal.sortActionEffect(
          field: 'title',
          mode: 'browse',
          frameMode: 'detail',
          currentKind: 'playlist',
          modal: '',
        ),
        isNull,
      );
      expect(
        DetailSortModal.sortActionEffect(
          field: 'title',
          mode: 'detail',
          frameMode: 'browse',
          currentKind: 'playlist',
          modal: '',
        ),
        isNull,
      );
      expect(
        DetailSortModal.sortActionEffect(
          field: 'title',
          mode: 'detail',
          frameMode: 'detail',
          currentKind: 'album',
          modal: '',
        ),
        isNull,
      );
      expect(
        DetailSortModal.sortActionEffect(
          field: 'title',
          mode: 'detail',
          frameMode: 'detail',
          currentKind: '',
          modal: '',
        ),
        isNull,
      );
    });

    test('the effect never rewrites the field it was given', () {
      final DetailSortActionEffect? effect = DetailSortModal.sortActionEffect(
        field: 'album',
        mode: 'detail',
        frameMode: 'detail',
        currentKind: 'playlist',
        modal: 'detail-sort',
      );

      expect(effect!.field, 'album');
      expect(effect.detailSort, effect.field);
    });
  });

  // -------------------------------------------------------------------------
  // Key table
  // -------------------------------------------------------------------------
  group('key table', () {
    test('Escape closes the menu', () {
      expect(DetailSortModal.keyActions['Escape'], _qtEscapeAction);
      expect(DetailSortModal.keyActions.length, 1);
    });

    test('no Tab focus order and no arrow scrolling is fabricated', () {
      expect(DetailSortModal.keyActions.containsKey('Tab'), isFalse);
      expect(DetailSortModal.keyActions.containsKey('ArrowDown'), isFalse);
      expect(DetailSortModal.keyActions.containsKey('ArrowUp'), isFalse);
      expect(DetailSortModal.keyActions.containsKey('Enter'), isFalse);
    });
  });

  // -------------------------------------------------------------------------
  // Motion
  // -------------------------------------------------------------------------
  group('motion', () {
    test('starts hidden with offset 12 and no transition', () {
      final DetailSortMotion motion = DetailSortMotion();

      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
    });

    test('set(true) targets full opacity at offset 0 over 0.3 s', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);

      expect(motion.duration, 0.3);
      expect(motion.entering, isTrue);
      expect(motion.targetOpacity, 1.0);
      expect(motion.targetOffset, 0.0);
      expect(motion.finished, isFalse);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
    });

    test('the entering curve matches the Qt bezier', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);

      motion.sample(0.15); // progress 0.5
      expect(motion.opacity, closeTo(0.96138255575218934, 1e-12));
      expect(motion.offset, closeTo(0.46340933097372883, 1e-12));

      motion.sample(0.3); // progress 1; the bezier lands within an ulp of 1
      expect(motion.opacity, closeTo(1.0, 1e-12));
      expect(motion.offset, closeTo(0.0, 1e-12));
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
    });

    test('a quarter of the entering curve lands on the Qt value', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);
      motion.sample(0.075); // progress 0.25

      expect(motion.opacity, closeTo(0.76486475245604313, 1e-12));
    });

    test('the launching sample is a hair short of the start offset', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);
      motion.sample(0.0); // bezier(0) is about 8.94e-8, not exactly 0

      expect(motion.offset, closeTo(11.999998927116426, 1e-9));
      expect(motion.opacity, closeTo(8.9406964498550705e-8, 1e-12));
    });

    test('set(false) targets hidden at offset 8 over 0.2 s', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);
      motion.sample(0.3);
      motion.set(false, 0.3);

      expect(motion.duration, 0.2);
      expect(motion.entering, isFalse);
      expect(motion.targetOpacity, 0.0);
      expect(motion.targetOffset, 8.0);
      expect(motion.finished, isFalse);

      motion.sample(0.4); // progress 0.5 on the leaving curve
      expect(motion.opacity, closeTo(0.67518541414424427, 1e-12));
      expect(motion.offset, closeTo(2.5985166868460459, 1e-12));

      motion.sample(0.5); // progress 1
      expect(motion.opacity, closeTo(2.6645352591003757e-15, 1e-12));
      expect(motion.offset, closeTo(7.9999999999999787, 1e-12));
      expect(motion.finished, isTrue);
    });

    test('reduced motion snaps instantly', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0, true);

      expect(motion.duration, 0.0);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      expect(motion.finished, isTrue);
    });

    test('a retarget samples the running transition, so it does not jump', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);
      motion.sample(0.15);
      final double sampled = motion.opacity;

      motion.set(false, 0.15);
      expect(motion.opacity, sampled);
      expect(motion.offset, closeTo(0.46340933097372883, 1e-12));
      expect(motion.duration, 0.2);
      expect(motion.targetOpacity, 0.0);
    });

    test('sampling past the end clamps instead of overshooting', () {
      final DetailSortMotion motion = DetailSortMotion();
      motion.set(true, 0);
      motion.sample(10.0);

      expect(motion.opacity, closeTo(1.0, 1e-12));
      expect(motion.offset, closeTo(0.0, 1e-12));
      expect(motion.finished, isTrue);
      motion.sample(20.0);
      expect(motion.opacity, closeTo(1.0, 1e-12));
      expect(motion.offset, closeTo(0.0, 1e-12));
    });
  });

  // -------------------------------------------------------------------------
  // Injected state
  // -------------------------------------------------------------------------
  group('injected state', () {
    test('closing does not alter the painted frame (NativeHud.cpp:262-266)', () {
      final DetailSortModalFrame open =
          _modal(closing: false, offset: 8).build();
      final DetailSortModalFrame closing =
          _modal(closing: true, offset: 8).build();

      expect(closing.commands, open.commands);
      expect(closing.hits, open.hits);
    });

    test('closing at a fully faded opacity still paints and registers hits', () {
      final DetailSortModalFrame frame =
          _modal(closing: true, opacity: 0.0, offset: 8).build();

      // The host clears the modal only when closing && motion.finished()
      // (Qt/src/NativeHud.cpp:262-266); until then modalDraw keeps painting
      // (Qt/src/NativeHud.cpp:306-308). opacity <= 0 is not that condition.
      expect(frame.commands, isNotEmpty);
      expect(frame.hits.length, 5);
      expect(frame.commands[1], <Object?>['alpha', 0.0]);
      expect(frame.hits[0], <Object?>[
        0.0,
        -8.0,
        _qtStageWidth,
        _qtStageHeight,
        _qtCloseAction,
        _qtCatcherLabel,
      ]);
    });

    test('reduced motion does not change the frame', () {
      final DetailSortModalFrame normal = _modal(reduced: false).build();
      final DetailSortModalFrame reduced = _modal(reduced: true).build();

      expect(reduced.commands, normal.commands);
      expect(reduced.hits, normal.hits);
    });

    test('width is injected everywhere it is needed', () {
      final DetailSortModalFrame frame =
          _modal(width: 1000, offset: 8).build();

      expect(frame.hits[0], <Object?>[
        0.0,
        -8.0,
        1000.0,
        _qtStageHeight,
        _qtCloseAction,
        _qtCatcherLabel,
      ]);
      expect(frame.commands[3][2], 521.0);
      expect(frame.hits[1][0], 529.0);
    });

    test('fields and labels are the Qt lists', () {
      expect(DetailSortModal.fields, _qtFields);
      expect(DetailSortModal.labels, _qtLabels);
    });

    test('build is pure: two calls over the same state agree', () {
      final DetailSortModal modal = _modal(detailSort: 'album', dark: true);
      final DetailSortModalFrame first = modal.build();
      final DetailSortModalFrame second = modal.build();

      expect(second.commands, first.commands);
      expect(second.hits, first.hits);
      expect(second.commands, isNot(same(first.commands)));
    });

    test('the default constructor state is the Qt idle state', () {
      const DetailSortModal modal = DetailSortModal(width: _qtStageWidth);

      expect(modal.dark, isFalse);
      expect(modal.reduced, isFalse);
      expect(modal.closing, isFalse);
      expect(modal.detailSort, 'none');
      expect(modal.offset, 0.0);
      expect(modal.opacity, 1.0);
    });
  });
}
