import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/hud/modals/disc_warning_modal.dart';

// Written, never executed in this atom. Intended command:
//   flutter test test/hud/t40/disc_warning_modal_test.dart
//
// Every literal below is copied from the Qt source, not from the Dart
// implementation under test:
//   geometry  Qt/src/NativeHud.cpp:140-159
//   drawing   Qt/src/NativeHudModal.cpp:80-257 (disc-rotation-warning branch is
//             the generic full-modal path, :163-209)
//   prims     Qt/src/NativeHud.cpp:10-15, :48-76, :102-120, :125-129
//   motion    Qt/src/UiMotion.h:24-42, Qt/src/UiMotion.cpp:86-120
//   actions   Qt/src/NativeHudController.cpp:711-723, :887-925

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

/// Deterministic stand-in for Glyphs::width (Qt/src/Glyphs.h:25). CJK units
/// cost one em, ASCII half an em: enough to exercise fit() with no font.
double _stageMeasure(
    String text, double size, String? weight, double tracking) {
  var width = 0.0;
  for (final unit in text.codeUnits) {
    width += unit >= 0x2E80 ? size : size * 0.5;
  }
  return width + tracking * text.length;
}

/// Stand-in for the portrait adapter: doubles every landscape rect.
List<double> _doubleRect(double x, double y, double width, double height) =>
    <double>[x * 2, y * 2, width * 2, height * 2];

List<double> _identityRect(double x, double y, double width, double height) =>
    <double>[x, y, width, height];

DiscWarningModalState _state({
  double width = 1920.0,
  bool dark = false,
  bool reduced = false,
  bool closing = false,
  bool search = false,
  double opacity = 1.0,
  double offset = 0.0,
  DiscWarningMeasureText? measureText,
  DiscWarningRectHook? rectHook,
}) {
  return DiscWarningModalState(
    width: width,
    dark: dark,
    reduced: reduced,
    closing: closing,
    search: search,
    opacity: opacity,
    offset: offset,
    measureText: measureText ?? _stageMeasure,
    rectHook: rectHook ?? _identityRect,
  );
}

DiscWarningModalFrame _frame([DiscWarningModalState? state]) =>
    DiscWarningModal(state ?? _state()).build();

List<List<Object?>> _fills(List<List<Object?>> commands) =>
    commands.where((command) => command[0] == 'fill').toList();

List<List<Object?>> _texts(List<List<Object?>> commands) =>
    commands.where((command) => command[0] == 'text').toList();

List<Object?> _fillOfHeight(List<List<Object?>> commands, double height) {
  for (final command in _fills(commands)) {
    if (command[5] == height) {
      return command;
    }
  }
  throw StateError('no fill with height ' + height.toString());
}

/// Qt/src/NativeHud.cpp:10-15 dark ink.
const List<Object?> _inkDark = <Object?>[
  0.92,
  0.92,
  0.92,
  1.0,
  'calibratedWhite',
];

/// Qt/src/NativeHud.cpp:10-15 light ink. _state() defaults dark = false
/// (:40), so a default frame draws this colour, not [_inkDark].
const List<Object?> _inkLight = <Object?>[
  0.08,
  0.085,
  0.075,
  1.0,
  'calibratedRGB',
];

// ---------------------------------------------------------------------------
void main() {
  // -------------------------------------------------------------------------
  group('command stream', () {
    test('19 ops, save first, restore last, alpha then scrim then translate',
        () {
      final commands = _frame().commands;
      expect(commands.length, 19);
      expect(commands.first, <Object?>['save']);
      expect(commands.last, <Object?>['restore']);
      expect(commands[1], <Object?>['alpha', 1.0]);
      expect(commands[2][0], 'fill'); // scrim, Qt/src/NativeHudModal.cpp:163
      expect(commands[3], <Object?>['translate', 0.0, 0.0]);
      // Qt/src/NativeHudModal.cpp:166 translates before the panel fill :171.
      final translateIndex = commands.indexWhere((command) =>
          command[0] == 'translate' && command[1] == 0.0 && command[2] == 0.0);
      expect(translateIndex, greaterThan(2));
      expect(commands.map((command) => command[0]).toList(), <String>[
        'save',
        'alpha',
        'fill',
        'translate',
        'fill',
        'text',
        'fill',
        'text',
        'text',
        'text',
        'text',
        'text',
        'text',
        'text',
        'fill',
        'text',
        'fill',
        'text',
        'restore',
      ]);
    });

    test('alpha carries the injected motion opacity (NativeHudModal.cpp:84)',
        () {
      final commands = _frame(_state(opacity: 0.25)).commands;
      expect(commands[1], <Object?>['alpha', 0.25]);
    });

    test('translate carries the injected motion offset (NativeHudModal.cpp:166)',
        () {
      final commands = _frame(_state(offset: 4.5)).commands;
      expect(commands[3], <Object?>['translate', 0.0, 4.5]);
    });

    test('opaque literals: 10 text ops and 5 fills', () {
      final commands = _frame().commands;
      expect(_texts(commands).length, 10);
      expect(_fills(commands).length, 5);
    });
  });

  // -------------------------------------------------------------------------
  group('scrim (Qt/src/NativeHudModal.cpp:163-165)', () {
    test('full stage 0,0,width,1080 painted before the translate', () {
      final commands = _frame().commands;
      final scrim = commands[2];
      expect(scrim[0], 'fill');
      expect(scrim[2], 0.0);
      expect(scrim[3], 0.0);
      expect(scrim[4], 1920.0);
      expect(scrim[5], 1080.0);
      final translateIndex = commands
          .indexWhere((command) => command[0] == 'translate');
      expect(commands.indexOf(scrim), lessThan(translateIndex));
      expect(translateIndex, 3);
    });

    test('light scrim 227,224,215 / 255 at alpha 0.45 (search false)', () {
      final scrim = _frame().commands[2];
      final color = scrim[1] as List<Object?>;
      expect(color.length, 4);
      expect((color[0] as double), closeTo(227 / 255, 1e-9));
      expect((color[1] as double), closeTo(224 / 255, 1e-9));
      expect((color[2] as double), closeTo(215 / 255, 1e-9));
      expect((color[3] as double), closeTo(0.45, 1e-9));
    });

    test('dark scrim 17,24,27 / 255 at alpha 0.6', () {
      final scrim = _frame(_state(dark: true)).commands[2];
      final color = scrim[1] as List<Object?>;
      expect(color.length, 4);
      expect((color[0] as double), closeTo(17 / 255, 1e-9));
      expect((color[1] as double), closeTo(24 / 255, 1e-9));
      expect((color[2] as double), closeTo(27 / 255, 1e-9));
      expect((color[3] as double), closeTo(0.6, 1e-9));
    });

    test('scrim width follows the injected stage width', () {
      final scrim = _frame(_state(width: 1200.0)).commands[2];
      expect(scrim[4], 1200.0);
      expect(scrim[5], 1080.0);
    });
  });

  // -------------------------------------------------------------------------
  group('panel geometry (Qt/src/NativeHud.cpp:140-159)', () {
    test('1920 stage: left 330, top 122, usable 1260, height 836', () {
      final panel = _fillOfHeight(_frame().commands, 836.0);
      expect(panel[2], 330.0);
      expect(panel[3], 122.0);
      expect(panel[4], 1260.0);
      expect(panel[5], 836.0);
      expect(DiscWarningModal.boundsFor(1920.0),
          <double>[330.0, 122.0, 1260.0, 836.0]);
    });

    test('width 1200: usable 1100 centred at left 50', () {
      final panel = _fillOfHeight(_frame(_state(width: 1200.0)).commands, 836.0);
      expect(panel[2], 50.0);
      expect(panel[3], 122.0);
      expect(panel[4], 1100.0);
      expect(DiscWarningModal.boundsFor(1200.0),
          <double>[50.0, 122.0, 1100.0, 836.0]);
    });

    test('width 800: usable 700 centred at left 50 (1260 cap not reached)', () {
      expect(DiscWarningModal.boundsFor(800.0),
          <double>[50.0, 122.0, 700.0, 836.0]);
    });

    test('panel fill precedes the first text and clears the base hits', () {
      final commands = _frame().commands;
      final panelIndex = commands.indexOf(_fillOfHeight(commands, 836.0));
      expect(panelIndex, lessThan(commands.indexWhere((c) => c[0] == 'text')));
    });

    test('light panel 0.929,0.922,0.894 has four components', () {
      final color = _fillOfHeight(_frame().commands, 836.0)[1] as List<Object?>;
      expect(color.length, 4);
      expect(color[0] as double, closeTo(0.929, 1e-9));
      expect(color[1] as double, closeTo(0.922, 1e-9));
      expect(color[2] as double, closeTo(0.894, 1e-9));
      expect(color[3] as double, closeTo(1.0, 1e-9));
    });

    test('dark panel 0.15,0.15,0.15 keeps calibratedWhite', () {
      final color = _fillOfHeight(_frame(_state(dark: true)).commands, 836.0)[1]
          as List<Object?>;
      expect(color.length, 5);
      expect(color[0] as double, closeTo(0.15, 1e-9));
      expect(color[3] as double, closeTo(1.0, 1e-9));
      expect(color[4], 'calibratedWhite');
    });

    test('rect hook maps every rect, landscape numbers unchanged', () {
      final frame = _frame(_state(rectHook: _doubleRect));
      final panel = _fillOfHeight(frame.commands, 1672.0);
      expect(panel[2], 660.0);
      expect(panel[3], 244.0);
      expect(panel[4], 2520.0);
      expect(panel[5], 1672.0);
      expect(frame.hits[0][0], 2740.0);
      expect(frame.hits[0][1], 280.0);
      expect(frame.hits[0][2], 334.0);
      expect(frame.hits[0][3], 108.0);
    });
  });

  // -------------------------------------------------------------------------
  group('header and body text (Qt/src/NativeHudModal.cpp:188-209)', () {
    test('category line is the composed MUSIC DIRECTORY string at 11px', () {
      final text = _texts(_frame().commands)[0];
      expect(text[1], 'RHINE LAB / MUSIC DATABASE / MUSIC DIRECTORY');
      expect(text[2], 383.0);
      expect(text[3], 159.0);
      expect(text[4], 11.0);
      expect(text[5], 'regular');
      expect(text[6], 0.0);
      // Default _state() is light, so the category uses light ink
      // (Qt/src/NativeHud.cpp:10-15); dark is covered by 'theme colour: dark
      // ink keeps calibratedWhite' below.
      expect(text[7], _inkLight);
    });

    test('title 38 demibold and subtitle 15 regular at x+53', () {
      final texts = _texts(_frame().commands);
      expect(texts[2][1], 'DISC ROTATION');
      expect(texts[2][2], 383.0);
      expect(texts[2][3], 213.0);
      expect(texts[2][4], 38.0);
      expect(texts[2][5], 'demibold');
      expect(texts[3][1], '开启前请确认资源与功耗风险');
      expect(texts[3][2], 383.0);
      expect(texts[3][3], 269.0);
      expect(texts[3][4], 15.0);
      expect(texts[3][5], 'regular');
    });

    test('body rows: 22 demibold lead plus three 16 regular lines', () {
      final texts = _texts(_frame().commands);
      expect(texts[4][1], '唱片旋转需要持续刷新画面。');
      expect(texts[4][2], 383.0);
      expect(texts[4][3], 372.0);
      expect(texts[4][4], 22.0);
      expect(texts[4][5], 'demibold');

      expect(texts[5][1], '开启后会增加 CPU / GPU 占用、耗电和发热，可能缩短电池续航。');
      expect(texts[5][3], 432.0);
      expect(texts[5][4], 16.0);

      expect(texts[6][1], '仅当前歌曲的详情页和歌词页旋转；资源库、暂停和后台均不旋转。');
      expect(texts[6][3], 474.0);
      expect(texts[6][4], 16.0);

      expect(texts[7][1], '该功能默认关闭，减少动态效果开启时也不会旋转。');
      expect(texts[7][3], 516.0);
      expect(texts[7][4], 16.0);
    });

    test('theme colour: dark ink keeps calibratedWhite', () {
      final text = _texts(_frame(_state(dark: true)).commands)[0];
      expect(text[7], <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite']);
    });

    test('light ink is calibratedRGB', () {
      final text = _texts(_frame().commands)[0];
      expect(text[7], _inkLight);
    });
  });

  // -------------------------------------------------------------------------
  group('hits (Qt/src/NativeHud.cpp:102-120)', () {
    test('exactly three hits in draw order, each exactly six fields', () {
      final hits = _frame().hits;
      expect(hits.length, 3);
      for (final hit in hits) {
        expect(hit.length, 6);
        expect(hit[0], isA<double>());
        expect(hit[1], isA<double>());
        expect(hit[2], isA<double>());
        expect(hit[3], isA<double>());
        expect(hit[4], isA<String>());
        expect(hit[5], isA<String>());
      }
    });

    test('header back button: 1370,140,167,54 close-modal', () {
      expect(_frame().hits[0],
          <Object?>[1370.0, 140.0, 167.0, 54.0, 'close-modal', '← 返回']);
    });

    test('enable button: 383,602,260,48 disc-rotation:enable', () {
      expect(_frame().hits[1], <Object?>[
        383.0,
        602.0,
        260.0,
        48.0,
        'disc-rotation:enable',
        '了解风险，仍然开启',
      ]);
    });

    test('cancel button: 670,602,180,48 disc-rotation:cancel', () {
      expect(_frame().hits[2], <Object?>[
        670.0,
        602.0,
        180.0,
        48.0,
        'disc-rotation:cancel',
        '保持关闭',
      ]);
    });

    test('hit label defaults to the action when null (NativeHud.cpp:108)', () {
      for (final hit in _frame().hits) {
        expect(hit[5], isNotNull);
        expect((hit[5] as String).isNotEmpty, isTrue);
      }
    });

    test('hits track the injected width', () {
      final hits = _frame(_state(width: 1200.0)).hits;
      expect(hits[0][0], 930.0); // 50 + 1100 - 220
      expect(hits[0][1], 140.0);
      expect(hits[1][0], 103.0); // 50 + 53
      expect(hits[1][1], 602.0);
      expect(hits[2][0], 390.0); // 50 + 340
    });

    test('hits are appended in the same order as their buttons are drawn', () {
      final frame = _frame();
      final actions = <String>[];
      for (final command in frame.commands) {
        if (command[0] == 'text' && command[4] == 20.0) {
          actions.add('close-modal');
        }
      }
      expect(actions.length, 1);
      expect(frame.hits.map((hit) => hit[4]).toList(), <String>[
        'close-modal',
        'disc-rotation:enable',
        'disc-rotation:cancel',
      ]);
    });
  });

  // -------------------------------------------------------------------------
  group('action table and close path (NativeHudController.cpp:711-925)', () {
    test('every emitted action is in the exposed table', () {
      expect(DiscWarningModal.actions, <String>[
        'close-modal',
        'disc-rotation:enable',
        'disc-rotation:cancel',
      ]);
      final emitted =
          _frame().hits.map((hit) => hit[4] as String).toSet().toList();
      expect(emitted.toSet(), DiscWarningModal.actions.toSet());
    });

    test('close path is close-modal only: no 取消 button, no scrim catcher', () {
      final frame = _frame();
      expect(DiscWarningModal.escapeAction, 'close-modal');
      // Qt has no 取消 label on this panel; closing is the header back button or
      // Escape (NativeHudController.cpp:913-922 -> closeModal() :132-143).
      for (final hit in frame.hits) {
        expect(hit[4], isNot('close'));
        expect(hit[5], isNot('取消'));
        expect(hit[5], isNot('Cancel'));
      }
      // The generic path installs no full-stage catcher (NativeHudModal.cpp:173
      // clears hits and only the detail-sort popover adds one at :128).
      for (final hit in frame.hits) {
        final coversStage = (hit[0] as double) <= 0.0 &&
            (hit[1] as double) <= 0.0 &&
            (hit[2] as double) >= 1920.0 &&
            (hit[3] as double) >= 1080.0;
        expect(coversStage, isFalse);
      }
    });

    test('Escape maps to close-modal; every other key is swallowed', () {
      expect(DiscWarningModal.keyActions, <String, String>{
        'Escape': 'close-modal',
      });
      expect(DiscWarningModal.actionForKey('Escape'), 'close-modal');
      // NativeHudController.cpp:923-925 returns for any key while a modal is
      // open, and the arrow branches :891-903 are settings/desktop-lyrics only.
      for (final key in <String>[
        'Tab',
        'Return',
        'Enter',
        'Space',
        'ArrowUp',
        'ArrowDown',
        'ArrowLeft',
        'ArrowRight',
        'Escape ',
        'esc',
        'a',
      ]) {
        expect(DiscWarningModal.actionForKey(key), isNull,
            reason: 'Qt swallows ' + key + ' while the warning modal is open');
      }
    });

    test('host replacement is out of scope of this frame: no settings command',
        () {
      // Both content actions REPLACE the modal with settings at host level
      // (NativeHudController.cpp:718-723). This frame only reports the action.
      final commands = _frame().commands;
      expect(commands.where((command) => command[0] == 'image'), isEmpty);
      expect(commands.where((command) => command[0] == 'art'), isEmpty);
      expect(commands.where((command) => command[0] == 'clip'), isEmpty);
    });
  });

  // -------------------------------------------------------------------------
  group('fit through the injected measurement (NativeHud.cpp:48-76)', () {
    test('normal labels are not truncated at 1920', () {
      final texts = _texts(_frame().commands);
      expect(texts[1][1], '← 返回'); // fits 147px at 20px with this measure
      expect(texts[8][1], '了解风险，仍然开启');
      expect(texts[9][1], '保持关闭');
    });

    test('text anchors are inset by min(10, width / 8) (NativeHud.cpp:112-120)',
        () {
      final texts = _texts(_frame().commands);
      expect(texts[1][2], 1380.0); // 1370 + 10
      expect(texts[1][3], 153.0); // 140 + (54 - 20) / 2 - 4
      expect(texts[8][2], 393.0); // 383 + 10
      expect(texts[8][3], 614.0); // 602 + (48 - 16) / 2 - 4
      expect(texts[9][2], 680.0); // 670 + 10
      expect(texts[9][3], 614.0);
    });

    test('button plates use the modal tint (NativeHud.cpp:115-116)', () {
      final tints = _fills(_frame().commands)
          .where((command) => command[5] == 48.0 || command[5] == 54.0)
          .toList();
      expect(tints.length, 3);
      expect(tints[0][1], <Object?>[0.44, 0.49, 0.36, 0.1]);
      expect(tints[1][1], <Object?>[0.44, 0.49, 0.36, 0.1]);
      expect(tints[2][1], <Object?>[0.44, 0.49, 0.36, 0.1]);
    });

    test('dark button tint 0.55,0.59,0.46,0.13', () {
      final tints = _fills(_frame(_state(dark: true)).commands)
          .where((command) => command[5] == 48.0 || command[5] == 54.0)
          .toList();
      expect(tints.first[1], <Object?>[0.55, 0.59, 0.46, 0.13]);
    });

    test('truncation calls the injected measure and appends the ellipsis', () {
      final calls = <String>[];
      double coarse(String text, double size, String? weight, double tracking) {
        calls.add(text +
            '|' +
            size.toString() +
            '|' +
            (weight ?? 'null') +
            '|' +
            tracking.toString());
        return text.length * 100.0;
      }

      final texts = _texts(_frame(_state(measureText: coarse)).commands);
      // Enable button: 240px available at 100px per unit keeps two units, then
      // Qt drops the last kept unit and appends U+2026 -> '了…'
      // (NativeHud.cpp:71-73).
      expect(texts[8][1], '了…');
      // Cancel button: only 160px available keeps a single unit, and dropping
      // that one leaves just the ellipsis -> '…'.
      expect(texts[9][1], '…');
      expect(calls, isNotEmpty);
      // First fit() in draw order is the header button (NativeHudModal.cpp:199).
      // The label is drawn demibold, but Qt calls fit() without a weight
      // (NativeHud.cpp:118), so the measurement sees "regular" (NativeHud.h:249).
      expect(calls.first, '← 返回|20.0|regular|0.0');
      expect(calls, contains('了解风险，仍然开启|16.0|regular|0.0'));
      expect(calls, contains('保持关闭|16.0|regular|0.0'));
    });

    test('fit() measures with Qt default regular even when drawn demibold', () {
      // MF-1 guard (Qt/src/NativeHud.cpp:118, NativeHud.h:249): button() never
      // forwards its own weight to fit(), so the header back button is measured
      // as "regular" although it is drawn demibold.
      final weights = <String>[];
      double weightSensitive(
          String text, double size, String? weight, double tracking) {
        weights.add(weight ?? 'null');
        // demibold is 10x wider: forwarding the drawn weight would push
        // '← 返回' past the 147px available width and collapse it to '…'.
        final factor = weight == 'demibold' ? 10.0 : 1.0;
        return _stageMeasure(text, size, weight, tracking) * factor;
      }

      final texts =
          _texts(_frame(_state(measureText: weightSensitive)).commands);
      expect(texts[1][1], '← 返回');
      expect(weights, isNotEmpty);
      expect(weights.every((weight) => weight == 'regular'), isTrue,
          reason: 'Qt fit() keeps its own default weight (NativeHud.h:249)');
    });

    test('the measure sees the full label before any truncation', () {
      final calls = <String>[];
      double exact(String text, double size, String? weight, double tracking) {
        calls.add(text);
        return _stageMeasure(text, size, weight, tracking);
      }

      _frame(_state(measureText: exact));
      expect(calls, contains('← 返回'));
      expect(calls, contains('了解风险，仍然开启'));
      expect(calls, contains('保持关闭'));
    });

    test('tracking stays zero for every text op', () {
      for (final text in _texts(_frame().commands)) {
        expect(text[6], 0.0);
      }
    });
  });

  // -------------------------------------------------------------------------
  group('motion (Qt/src/UiMotion.h:24-42, UiMotion.cpp:86-120)', () {
    test('initial state: opacity 0, offset 12, duration 0, finished', () {
      final motion = DiscWarningMotion();
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
    });

    test('set(true): 0.3s, target opacity 1, target offset 0, no snap', () {
      final motion = DiscWarningMotion()..set(true, 0.0);
      expect(motion.duration, closeTo(0.3, 1e-12));
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);
      expect(motion.finished, isFalse);
    });

    test('enter samples: 0 at start, past 0.9 at half, settled at 0.3', () {
      final motion = DiscWarningMotion()..set(true, 0.0);
      motion.sample(0.0);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 12.0);

      motion.sample(0.15);
      // Enter curve (0.22, 1, 0.36, 1) front-loads: linear would be 0.5.
      expect(motion.opacity, greaterThan(0.9));
      expect(motion.offset, lessThan(1.0));
      expect(motion.finished, isFalse);

      motion.sample(0.3);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);

      motion.sample(9.0);
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);
    });

    test('set(false): 0.2s, target opacity 0, target offset 8', () {
      final motion = DiscWarningMotion()
        ..set(true, 0.0)
        ..sample(0.3)
        ..set(false, 1.0);
      expect(motion.duration, closeTo(0.2, 1e-12));
      expect(motion.opacity, 1.0);
      expect(motion.offset, 0.0);

      motion.sample(2.0);
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
      expect(motion.duration, 0.0);
      expect(motion.finished, isTrue);
    });

    test('exit samples sit on the (0.4, 0, 1, 1) curve', () {
      final motion = DiscWarningMotion()
        ..set(true, 0.0)
        ..sample(0.3)
        ..set(false, 1.0);
      motion.sample(1.1); // progress 0.5
      // set(false, 1.0) samples the settled entry first (UiMotion.cpp:102), so
      // the transition starts from opacity 1 / offset 0. On the exit curve
      // (0.4, 0, 1, 1), bezier(0.5, 0.4, 0, 1, 1) = 0.32481458585575573, hence
      // opacity = 1 - amount and offset = 8 * amount.
      expect(motion.opacity, closeTo(0.6751854141442443, 1e-9));
      expect(motion.offset, closeTo(2.598516686846046, 1e-9));
    });

    test('reduced motion snaps: duration 0, opacity and offset instant', () {
      final enter = DiscWarningMotion()..set(true, 0.0, reduced: true);
      expect(enter.duration, 0.0);
      expect(enter.opacity, 1.0);
      expect(enter.offset, 0.0);
      expect(enter.finished, isTrue);

      final leave = DiscWarningMotion()..set(false, 0.0, reduced: true);
      expect(leave.duration, 0.0);
      expect(leave.opacity, 0.0);
      expect(leave.offset, 8.0);
      expect(leave.finished, isTrue);
    });

    test('a mid-flight set() continues from the sampled state', () {
      final motion = DiscWarningMotion()..set(true, 0.0);
      motion.sample(0.1);
      final opacity = motion.opacity;
      final offset = motion.offset;
      expect(opacity, greaterThan(0.0));
      expect(offset, lessThan(12.0));

      motion.set(false, 0.1);
      motion.sample(0.1); // progress 0
      expect(motion.opacity, closeTo(opacity, 1e-12));
      expect(motion.offset, closeTo(offset, 1e-12));
      expect(motion.duration, closeTo(0.2, 1e-12));

      motion.sample(0.3); // progress 1
      expect(motion.opacity, 0.0);
      expect(motion.offset, 8.0);
      expect(motion.finished, isTrue);
    });

    test('reversing mid-enter shortens the exit path, it does not jump', () {
      final motion = DiscWarningMotion()..set(true, 0.0);
      motion.sample(0.06);
      final before = motion.opacity;
      motion.set(false, 0.06);
      expect(motion.opacity, before);
      motion.sample(0.16);
      expect(motion.opacity, lessThan(before));
    });
  });

  // -------------------------------------------------------------------------
  group('purity', () {
    test('build() is repeatable and does not mutate the injected state', () {
      final state = _state(width: 1920.0);
      final first = DiscWarningModal(state).build();
      final second = DiscWarningModal(state).build();
      expect(first.commands.length, second.commands.length);
      expect(first.hits, second.hits);
      expect(state.width, 1920.0);
      expect(state.opacity, 1.0);
      expect(state.offset, 0.0);
    });

    test('closing flag does not alter the painted frame (NativeHud.cpp:262-266)',
        () {
      final open = _frame();
      final closing = _frame(_state(closing: true));
      expect(closing.commands.length, open.commands.length);
      expect(closing.hits, open.hits);
      for (var i = 0; i < open.commands.length; i++) {
        expect(closing.commands[i].toString(), open.commands[i].toString());
      }
    });

    test('search flag only changes the scrim alpha (NativeHudModal.cpp:162)',
        () {
      final normal = _frame().commands[2][1] as List<Object?>;
      final searching = _frame(_state(search: true)).commands[2][1]
          as List<Object?>;
      expect(normal[3], closeTo(0.45, 1e-9));
      expect(searching[3], closeTo(0.12, 1e-9));
      expect(searching[0], normal[0]);
      expect(searching[1], normal[1]);
      expect(searching[2], normal[2]);
    });
  });
}
