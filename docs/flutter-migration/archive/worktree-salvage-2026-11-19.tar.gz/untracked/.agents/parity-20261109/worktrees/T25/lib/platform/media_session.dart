/// 系统媒体控件（Android MediaSession + MediaStyle 通知 + 音频焦点）的 Flutter 侧端口契约。
///
/// 本文件只做两件事，且不持有播放器状态、不建立第二份队列：
/// 1. [MediaSessionPort]：把 Qt 侧 `AndroidMediaSession` 的三个驱动入口
///    （ensureStarted / update / stop）与动作回传流翻译成可注入的接口；
/// 2. 动作词表与意图映射：把系统回传的动作字符串翻译成播放器意图，
///    逐条对齐 `NativeApplication::mediaAction`。
///
/// 状态值类型唯一来源是 SHARED 的 `MediaSnapshot`
/// （`lib/domain/models/media_snapshot.dart`，由 SHARED-S4 唯一拥有）。
/// 本文件不声明 MediaSessionState 之类的平行值对象，也不缓存队列：
/// 端口只负责把宿主递进来的快照原样送到平台，把平台回传的动作原样翻译成意图。
///
/// 源码证据（Qt 侧）：
/// - `Qt/src/AndroidMediaSession.h:11-27`：setCommandCallback / ensureStarted / update / stop
///   四个入口，动作契约与 iOS MPRemoteCommandCenter 完全一致（resume/pause/toggle/next/prev）。
/// - `Qt/src/AndroidMediaSession.cpp:27-47`：start() 走 startForegroundService；
///   幂等由 Java 侧 instance != null 早退保证（RhineMediaService.java:64-70）；
///   POST_NOTIFICATIONS 只请求一次，sdk < 33 跳过，被拒不阻塞。
/// - `Qt/src/AndroidMediaSession.cpp:58-70`：update(playing, positionMs, durationMs, title,
///   artist, album, coverPath) 与 stop() 均为 fire-and-forget 静态调用。
/// - `Qt/src/PlatformAndroid.cpp:62-72`：platformMediaInfo —— title 为空或 duration <= 0
///   转待机（调 stop()，前台服务保持），否则先 ensureStarted() 再 update()。
/// - `Qt/src/NativeApplication.cpp:27,197-213`：kSeekActionPrefix = "rhine.media.SEEK:"；
///   resume/pause -> setPaused(action == "pause")；next/prev -> next(+1/-1)；
///   SEEK -> toDouble() 后仅当 duration > 0 才 seek(qBound(0, position/duration, 1))；
///   其余（含 "toggle"）一律 hud.action("player:" + action)。
/// - `Qt/android/src/rhine/music/database/RhineMediaService.java:37-41,125-148,178-204,248-254`：
///   onPlay="resume" / onPause="pause" / onSkipToNext="next" / onSkipToPrevious="prev" /
///   onSeekTo=ACTION_SEEK + ":" + Math.max(0, pos)；音频焦点 LOSS 与 LOSS_TRANSIENT 派 "pause"
///   （LOSS_TRANSIENT_CAN_DUCK 不派）；拔耳机 ACTION_AUDIO_BECOMING_NOISY 派 "pause"。
/// - `Qt/src/Host.cpp:952-961`：mediaMetadata 对 title/artist/album 各取 left(256)；
///   `Qt/src/Host.cpp:987-998`：mediaState 以 1000ms 节流上报。
///
/// INTEGRATION（跨树唯一耦合点，按 control 明令不阻塞本树落地）：
/// 本文件 import '../domain/models/media_snapshot.dart' 指向 SHARED-S4 的落盘路径。
/// 该类已于 2026-11-09 在 SHARED 工作树落盘（137 行，sha1 8ffd5a3c…），尚未引入本树，
/// 故整合前本树无法解析该 import，由 integrator 带入。
/// 端口只以类型方式引用 MediaSnapshot，不读取其任何字段，
/// 因此 SHARED-S4 的字段命名变化不会影响本文件。读取字段（standby 判定、256 截断、
/// 1000ms 节流）属于后续整合工作（非本卡）。
/// [MediaSessionPort.actions] 的订阅语义由实现方声明：Qt 侧只有一个 sink，
/// 后一次 setCommandCallback 覆盖前一次（AndroidMediaSession.cpp:50-52），
/// 故实现方宜采用「单订阅、后订阅者胜出」或广播，并在实现文档里写明；
/// 后续整合的接线以此为准。
library;

import 'dart:async';

import '../domain/models/media_snapshot.dart';

/// Java 侧 ACTION_SEEK 加冒号后的前缀（Qt/src/NativeApplication.cpp:27）。
///
/// 与 AndroidMediaSession.h:9-10 的动作词表并列：普通动作是定长单词，
/// 进度动作是「前缀 + 毫秒数」。两个生产者都送 long 毫秒
/// （RhineMediaService.java:147 的 Math.max(0, pos)、:195 的 getLongExtra），
/// 即 wire 上实际是整数；这里保留 double 是因为 C++ 侧用 QString::toDouble() 解析
/// （NativeApplication.cpp:205），端口要能原样承接该解析结果，含空串/非数字等退化输入。
const String mediaSessionSeekPrefix = 'rhine.media.SEEK:';

/// 系统媒体控件回传的单个动作。
///
/// 词表与 Java native 回调逐字一致（RhineMediaService.java:125-148,178-204），
/// 不做任何别名扩展：平台说过什么就是什么，未识别的一律进 [MediaSessionUnknown]。
sealed class MediaSessionAction {
  const MediaSessionAction();

  /// 解析 Java 侧 mediaAction(String) 送出的原始字符串。
  ///
  /// 与 NativeApplication::mediaAction 的前置判定同序：先比定长词，再看
  /// [mediaSessionSeekPrefix]。毫秒数用与 QString::toDouble() 相同的宽松语义：
  /// 空串、非数字、NaN、Infinity 一律得 0.0（QString::toDouble() 对无效输入给 0.0 且
  /// ok=false，NativeApplication.cpp:205 未检查 ok，故无效值实际落成 0.0）。
  ///
  /// 单位是毫秒，负值按原始 wire 保留：Java 在 RhineMediaService.java:147 已经
  /// Math.max(0, pos) 夹过一次，只有 onStartCommand 的 long extra 路径
  /// （:195）可能送来负数，最终仍由意图映射按 qBound(0, position/duration, 1)
  /// 收口（NativeApplication.cpp:208）。
  factory MediaSessionAction.parse(String wire) {
    switch (wire) {
      case 'resume':
        return const MediaSessionResume();
      case 'pause':
        return const MediaSessionPause();
      case 'toggle':
        return const MediaSessionToggle();
      case 'next':
        return const MediaSessionNext();
      case 'prev':
        return const MediaSessionPrevious();
    }
    if (wire.startsWith(mediaSessionSeekPrefix)) {
      return MediaSessionSeek(_wireMilliseconds(wire.substring(mediaSessionSeekPrefix.length)));
    }
    return MediaSessionUnknown(wire);
  }

  /// 回写平台时的原始字符串。对定长词、[MediaSessionUnknown]（保留调用方给的原串）
  /// 与规范数值互为逆运算；非规范数值（前导空白、1e3 这类写法）会被归一化，
  /// 不保证逐字还原。
  String get wire;
}

/// onPlay（RhineMediaService.java:125-127）。
final class MediaSessionResume extends MediaSessionAction {
  const MediaSessionResume();

  @override
  String get wire => 'resume';
}

/// onPause，同时也是音频焦点丢失与拔耳机时派发的动作
/// （RhineMediaService.java:130-132,155-162,248-254）。
final class MediaSessionPause extends MediaSessionAction {
  const MediaSessionPause();

  @override
  String get wire => 'pause';
}

/// Android 原生回调不会派发的 toggle 词表项：它列在 AndroidMediaSession.h:9-10 的
/// 共同动作契约里，但 Java 侧没有 toggle 分支（RhineMediaService.java:125-148,178-204）。
///
/// C++ 侧并未把它当未知动作处理——它落到
/// hud.action("player:toggle")（NativeApplication.cpp:210-212），
/// 最终走 MusicPlayer::toggle()（含失败重播与恢复态语义，
/// Qt/src/MusicPlayer.cpp:520-537），与 setPaused(!playing) 并不等价。
final class MediaSessionToggle extends MediaSessionAction {
  const MediaSessionToggle();

  @override
  String get wire => 'toggle';
}

/// onSkipToNext（RhineMediaService.java:135-137）。
final class MediaSessionNext extends MediaSessionAction {
  const MediaSessionNext();

  @override
  String get wire => 'next';
}

/// onSkipToPrevious（RhineMediaService.java:140-142）。
final class MediaSessionPrevious extends MediaSessionAction {
  const MediaSessionPrevious();

  @override
  String get wire => 'prev';
}

/// 进度跳转，单位毫秒（RhineMediaService.java:145-148）。
final class MediaSessionSeek extends MediaSessionAction {
  const MediaSessionSeek(this.positionMs);

  /// 平台报告的绝对毫秒位置。解析侧用 double 承接 QString::toDouble() 的结果
  /// （退化输入得 0.0），故此处为 double。
  final double positionMs;

  @override
  String get wire => mediaSessionSeekPrefix + _wireNumber(positionMs);
}

/// 未识别动作：原样保留，交由 HUD 的 player: 命名空间兜底
/// （NativeApplication.cpp:210-212）。
final class MediaSessionUnknown extends MediaSessionAction {
  const MediaSessionUnknown(this.raw);

  /// 平台送来的原始字符串，不做任何归一化。
  final String raw;

  @override
  String get wire => raw;
}

/// 播放器意图：NativeApplication::mediaAction 的四个出口
/// （Qt/src/NativeApplication.cpp:200-212）。
sealed class MediaPlaybackIntent {
  const MediaPlaybackIntent();
}

/// MusicPlayer::setPaused（NativeApplication.cpp:200-201）。
final class MediaSetPaused extends MediaPlaybackIntent {
  const MediaSetPaused(this.paused);

  final bool paused;
}

/// MusicPlayer::next(direction)（NativeApplication.cpp:202-203）：+1 下一曲，-1 上一曲。
final class MediaStepTrack extends MediaPlaybackIntent {
  const MediaStepTrack(this.direction);

  final int direction;
}

/// MusicPlayer::seek(fraction)（NativeApplication.cpp:204-209），fraction 属于 [0, 1]。
final class MediaSeekFraction extends MediaPlaybackIntent {
  const MediaSeekFraction(this.fraction);

  final double fraction;
}

/// hud.action("player:" + action)（NativeApplication.cpp:210-212）。
final class MediaHudAction extends MediaPlaybackIntent {
  const MediaHudAction(this.action);

  final String action;
}

/// 把平台动作翻译成播放器意图；返回 null 表示本次动作不产生任何播放器调用。
///
/// 逐条对齐 NativeApplication::mediaAction（Qt/src/NativeApplication.cpp:197-213）：
/// - resume/pause -> [MediaSetPaused]（false/true），无「已在播放就跳过」的短路：
///   C++ 侧无条件调 setPaused，去重归播放器/音频层。
/// - next/prev -> [MediaStepTrack](+1/-1)。
/// - seek -> 仅当 [durationMs] > 0 才产出 [MediaSeekFraction]，
///   且分数按 qBound(0, position/duration, 1) 夹取（:207-208）；
///   否则返回 null（C++ 侧同样什么都不做）。
/// - toggle 与一切未识别动作 -> [MediaHudAction]('player:' + wire)。
///
/// 注意：本函数只产出意图，不触碰任何播放器状态——端口是单向同步，
/// 不存在「回声」把状态再写回端口的路径。
MediaPlaybackIntent? mediaPlaybackIntent(MediaSessionAction action, {required num durationMs}) {
  switch (action) {
    case MediaSessionResume():
      return const MediaSetPaused(false);
    case MediaSessionPause():
      return const MediaSetPaused(true);
    case MediaSessionNext():
      return const MediaStepTrack(1);
    case MediaSessionPrevious():
      return const MediaStepTrack(-1);
    case MediaSessionSeek(:final positionMs):
      final duration = durationMs.toDouble();
      if (!(duration > 0)) {
        // 与 C++ 的 if (duration > 0) 完全同构：0、负数、NaN 全部不跳转。
        return null;
      }
      final fraction = positionMs / duration;
      // 显式 toDouble：即使 clamp 的静态类型推断退化，也保证贴合 MediaSeekFraction.fraction。
      return MediaSeekFraction(fraction.clamp(0.0, 1.0).toDouble());
    case MediaSessionToggle():
      return const MediaHudAction('player:toggle');
    case MediaSessionUnknown(:final raw):
      return MediaHudAction('player:' + raw);
  }
}

/// 把 [MediaPlaybackIntent] 分发给可注入的播放器方法。
///
/// 四个回调就是 NativeApplication::mediaAction 实际调用的四个出口
/// （NativeApplication.cpp:201,203,208,211），由宿主注入真实播放器；
/// 测试注入记录器即可断言「意图 -> 调用」的对应关系，且不需要构造播放器。
/// 这里刻意不持有队列或播放状态：端口只翻译，不做第二写者。
class MediaPlaybackDispatcher {
  const MediaPlaybackDispatcher({
    required this.setPaused,
    required this.stepTrack,
    required this.seekFraction,
    required this.hudAction,
  });

  /// MusicPlayer::setPaused(paused)。
  final void Function(bool paused) setPaused;

  /// MusicPlayer::next(direction)：+1 / -1。
  final void Function(int direction) stepTrack;

  /// MusicPlayer::seek(fraction)：0..1。
  final void Function(double fraction) seekFraction;

  /// NativeHud::action(value)，value 形如 player:toggle。
  final void Function(String action) hudAction;

  /// 分发一条意图；[intent] 为 null（被抑制的 seek）时不做任何调用并返回 false。
  bool dispatch(MediaPlaybackIntent? intent) {
    switch (intent) {
      case null:
        return false;
      case MediaSetPaused(:final paused):
        setPaused(paused);
      case MediaStepTrack(:final direction):
        stepTrack(direction);
      case MediaSeekFraction(:final fraction):
        seekFraction(fraction);
      case MediaHudAction(:final action):
        hudAction(action);
    }
    return true;
  }
}

/// 系统媒体控件端口：Flutter 侧对 AndroidMediaSession 的唯一注入点。
///
/// 与 Qt 的三个静态入口一一对应（AndroidMediaSession.h:14-25），
/// 只做「把宿主状态送上去 / 把平台动作收回来」，不复制播放状态，不建第二条队列。
///
/// 契约（实现方必须逐条满足，均为 Qt 侧既有语义）：
/// - [ensureStarted] 幂等：Java 侧 instance != null 早退（RhineMediaService.java:64-70），
///   重复调用无害。POST_NOTIFICATIONS 被拒只是通知不显示、不阻塞启动
///   （AndroidMediaSession.cpp:32-47，Qt 注释明说 MediaSession 与耳机键仍可用）。
///   startForeground 失败在 Java 侧 catch 里走 stopSelf()（RhineMediaService.java:168-175）：
///   服务销毁、通知消失，属平台降级路径；端口不得把异常抛给调用方，
///   也不得据此改动任何播放器状态。
/// - [update] 只用 SHARED 的 MediaSnapshot 表达状态，不引入平行状态类型；
///   待机判定（title 为空或 duration <= 0 时改调 [stop]，前台服务保持）
///   由调用方（上层同步器）按 PlatformAndroid.cpp:62-72 执行，见 [mediaSessionStandby]；
///   本卡不提供该同步器本身——它要读 MediaSnapshot 的字段，而该类尚未引入本树
///   （SHARED-S4 已落盘于 SHARED 工作树，待整合），故不在本卡臆造。
///   title/artist/album 的 256 字符截断在 Host.cpp:952-955 已发生，
///   端口收到什么就送什么，不二次截断。
/// - [stop] 只撤下播放态与音频焦点，不结束前台服务
///   （RhineMediaService.java:101-114、AndroidMediaSession.h:24-25）。
/// - [actions] 承载平台回传的动作，词表见 [MediaSessionAction]；
///   音频焦点丢失、拔耳机等平台合成事件同样以 pause 出现在该流上
///   （RhineMediaService.java:155-162,248-254），不需要额外的错误通道。
/// - 端口不节流：1000ms 上报节奏属于 Host::mediaState（Host.cpp:987-998），
///   由上层同步器决定何时调 [update]；端口层重复 [update] 必须无害。
abstract interface class MediaSessionPort {
  /// 确保平台媒体会话/前台服务已启动；重复调用无害（见类文档）。
  Future<void> ensureStarted();

  /// 上报播放状态与元数据。
  Future<void> update(MediaSnapshot snapshot);

  /// 撤下播放态并释放音频焦点，前台服务继续存活（待机）。
  Future<void> stop();

  /// 平台动作流；订阅者按 [mediaPlaybackIntent] 翻译后交给 [MediaPlaybackDispatcher]。
  Stream<MediaSessionAction> get actions;
}

/// QString::toDouble() 的等价解析：无效输入得 0.0，不抛异常
/// （NativeApplication.cpp:205）。
double _wireMilliseconds(String text) {
  final trimmed = text.trim();
  if (trimmed.isEmpty) {
    return 0;
  }
  final value = double.tryParse(trimmed);
  if (value == null || value.isNaN || value.isInfinite) {
    return 0;
  }
  return value;
}

/// 回写 seek 位置：整数值不带小数点，其余按最短往返表示，
/// 使 [MediaSessionAction.wire] 与原 wire 在常见情形下逐字相同。
String _wireNumber(double value) {
  if (value.isFinite && value == value.roundToDouble() && value.abs() < 1e15) {
    return value.toStringAsFixed(0);
  }
  return value.toString();
}

/// 待机判定：Qt 侧 PlatformAndroid.cpp:64 的 `title.isEmpty() || duration <= 0`。
///
/// 待机不等于撤岗（Qt 注释 :65）：前台服务与通知保持运行，防止系统在无播放时回收进程，
/// 下次打开可立即续播。调用方据此在 [MediaSessionPort.stop]（待机）与
/// [MediaSessionPort.ensureStarted] + [MediaSessionPort.update]（在播）之间二选一，
/// 顺序与 PlatformAndroid.cpp:62-72 完全一致：待机只调 stop，非待机先 ensureStarted 再 update。
///
/// duration 用 int 承接 Qt 的 `toLongLong()`：该路径不存在 NaN/Infinity，
/// 故判据写成 `<= 0` 而非取反的比较，避免把`NaN`类输入混进判定。
bool mediaSessionStandby({required String title, required int durationMs}) {
  return title.isEmpty || durationMs <= 0;
}

/// [mediaSessionReportIntervalMs]：Qt 侧上报节奏的最小间隔
/// （`Host.cpp:993` 的 `now - lastMediaUpdate >= 1000`）。
const int mediaSessionReportIntervalMs = 1000;

/// 系统媒体控件状态上报的节流器，逐字镜像 `Host.h:137` 的
/// `mutable qint64 lastMediaUpdate = 0` 与 `Host.cpp:987-998` 的用法：
///
/// - 初始 lastMediaUpdate = 0，因此**第一次调用必然到点**（epoch 毫秒远大于 1000）；
/// - [due] 到点时先把 lastMediaUpdate 置为当前时间再返回 true（Qt 是"先记账再发布"，
///   所以发布过程本身耗时不会累积成额外的配额）；
/// - [invalidate] 把 lastMediaUpdate 归零，使下一次 [due] 立即到点。Qt 有三处这样做：
///   `Host.cpp:960`（元数据变更）、:968（无封面）、:982（封面落盘完成）。
///
/// 时钟由外部注入：Qt 用 `QDateTime::currentMSecsSinceEpoch()`（epoch 毫秒），
/// 注入后测试不需要真实等待，也不会因为系统时钟回拨而改变判定形状。
class MediaSessionThrottle {
  MediaSessionThrottle({this.intervalMs = mediaSessionReportIntervalMs, int Function()? clock})
      : _clock = clock ?? _epochMilliseconds,
        _lastReportMs = 0;

  /// 最小上报间隔，默认 [mediaSessionReportIntervalMs]（Qt 的 1000ms）。
  final int intervalMs;

  final int Function() _clock;
  int _lastReportMs;

  /// 本次是否到点上报；到点则返回 true 并记下本次时间。
  bool due() {
    final now = _clock();
    if (now - _lastReportMs >= intervalMs) {
      _lastReportMs = now;
      return true;
    }
    return false;
  }

  /// 强制下一次 [due] 到点（Qt 的 `lastMediaUpdate = 0`）。
  void invalidate() {
    _lastReportMs = 0;
  }

  static int _epochMilliseconds() => DateTime.now().millisecondsSinceEpoch;
}

