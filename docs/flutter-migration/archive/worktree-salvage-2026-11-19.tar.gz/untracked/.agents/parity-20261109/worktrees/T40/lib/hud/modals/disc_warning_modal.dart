/// Flutter port of the Qt HUD "disc rotation warning" modal.
///
/// Qt evidence (read-only; every path:line below is the origin of a number or
/// string in this file):
/// * geometry  Qt/src/NativeHud.cpp:140-159 modalBounds(), generic branch:
///             modalWidth = min(1260, width - 100), left = (width - modalWidth) / 2,
///             bounds = {left, 122, modalWidth, 836}
/// * draw      Qt/src/NativeHudModal.cpp:80-257 modalDraw(), generic branch:
///             :83-84   save(); alpha(motion.opacity)
///             :163-165 scrim fill(0, 0, width, 1080, ...) BEFORE translate
///             :166     translate(0, motion.offset)
///             :171-172 fill(x, y, usable, 836, panelFill)
///             :173     hits = {} (base layer keeps no events)
///             :188-202 category line, header back button, title, subtitle
///             :203-209 the disc-rotation-warning body ported here
///             :255-256 m_modalControls = false; restore()
/// * prims     Qt/src/NativeHud.cpp:10-15 ink, :16-43 op/save/restore/alpha/
///             translate/fill/text, :48-76 fit, :77-79 limited, :102-109 hit,
///             :110-120 button, :125-129 rule
/// * motion    Qt/src/UiMotion.h:24-42 SurfaceMotion, Qt/src/UiMotion.cpp:86-120
/// * actions   Qt/src/NativeHudController.cpp:711-723 (open + both content
///             actions), :887-925 (key handling, Escape, modal key swallow)
///
/// Host contract (documented here, resolved by the host, not by this file):
/// both content actions REPLACE this modal with the settings modal:
///   "disc-rotation:enable" -> discRotation = true;
///                             setPreference("disc-rotation", "on");
///                             openModal("settings")   (NativeHudController.cpp:718-721)
///   "disc-rotation:cancel" -> openModal("settings")    (NativeHudController.cpp:722-723)
/// openModal() has no early return for "settings" (NativeHudController.cpp:64-130),
/// so it overwrites the modal kind in place: the warning disappears without a close
/// animation and the settings panel enters with its own motion.set(true).
///
/// This library is self-contained: no imports, no I/O, no domain state.
library;

// ---------------------------------------------------------------------------
// Injected host callbacks
// ---------------------------------------------------------------------------

/// Text measurement injected by the host (contract §4).
///
/// Mirrors Glyphs::width(text, size, weight, tracking) at
/// Qt/src/Glyphs.h:25; [weight] is nullable so the caller can express the Qt
/// default "regular" for the two-argument case.
typedef DiscWarningMeasureText = double Function(
    String text, double size, String? weight, double tracking);

/// Landscape-stage rect transform injected by the host (contract §5).
///
/// Identity by default: the Qt stage is 1920x1080 and every coordinate in this
/// file is a Qt stage pixel. A portrait host supplies a hook that maps a
/// landscape rect to its own device rect; this file never invents portrait
/// pixels of its own.
typedef DiscWarningRectHook = List<double> Function(
    double x, double y, double width, double height);

List<double> _identityRect(double x, double y, double width, double height) =>
    <double>[x, y, width, height];

// ---------------------------------------------------------------------------
// Small numeric helpers (no dart:math: the file imports nothing)
// ---------------------------------------------------------------------------

double _min(double a, double b) => a < b ? a : b;

double _clamp(double value, double low, double high) =>
    value < low ? low : (value > high ? high : value);

/// Qt/src/UiMotion.cpp:7-22 bezier(), reproduced command for command:
/// cubic component with P0 = 0 and P3 = 1, x inverted by 24 bisections.
double _bezier(double x, double x1, double y1, double x2, double y2) {
  double component(double t, double a, double b) =>
      3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
  var lower = 0.0;
  var upper = 1.0;
  for (var i = 0; i < 24; i++) {
    final t = (lower + upper) / 2;
    if (component(t, x1, x2) < x) {
      lower = t;
    } else {
      upper = t;
    }
  }
  return component((lower + upper) / 2, y1, y2);
}

// ---------------------------------------------------------------------------
// Motion (contract §6)
// ---------------------------------------------------------------------------

/// Port of UiMotion::SurfaceMotion (Qt/src/UiMotion.h:24-42,
/// Qt/src/UiMotion.cpp:86-120).
///
/// Unit-testable: no widget, no clock, no I/O. The host feeds stage time.
class DiscWarningMotion {
  /// Qt/src/UiMotion.h:31-33 initial fields: opacity 0, offset 12, duration 0.
  double opacity = 0.0;
  double offset = 12.0;
  double duration = 0.0;

  double _fromOpacity = 0.0;
  double _fromOffset = 12.0;
  double _targetOpacity = 0.0;
  double _targetOffset = 12.0;
  double _start = 0.0;
  bool _entering = true;

  /// Qt/src/UiMotion.h:28-30: finished() is "duration == 0"; sample() zeroes the
  /// duration once progress reaches 1, so "finished" covers both spellings used
  /// by the port contract.
  bool get finished => duration == 0.0;

  /// Qt/src/UiMotion.cpp:86-98 sample().
  void sample(double time) {
    if (duration <= 0) {
      return;
    }
    final progress = _clamp((time - _start) / duration, 0.0, 1.0);
    final amount = _bezier(
      progress,
      _entering ? 0.22 : 0.4,
      _entering ? 1.0 : 0.0,
      _entering ? 0.36 : 1.0,
      1.0,
    );
    opacity = _fromOpacity + (_targetOpacity - _fromOpacity) * amount;
    offset = _fromOffset + (_targetOffset - _fromOffset) * amount;
    if (progress >= 1) {
      duration = 0.0;
    }
  }

  /// Qt/src/UiMotion.cpp:100-120 set(): sample the running transition first so
  /// a fast open/close continues from the current opacity and offset.
  void set(bool shown, double time, {bool reduced = false}) {
    sample(time);
    _fromOpacity = opacity;
    _fromOffset = offset;
    _targetOpacity = shown ? 1.0 : 0.0;
    _targetOffset = shown ? 0.0 : 8.0;
    _entering = shown;
    _start = time;
    if (reduced) {
      duration = 0.0;
    } else if (shown) {
      duration = 0.3;
    } else {
      duration = 0.2;
    }
    if (reduced) {
      opacity = _targetOpacity;
      offset = _targetOffset;
    }
  }
}

// ---------------------------------------------------------------------------
// Injected state (contract §7)
// ---------------------------------------------------------------------------

/// Everything the modal is allowed to read. No domain values, no credentials,
/// no badge availability: the disc rotation warning needs none of them
/// (Qt/src/NativeHudModal.cpp:203-209 references only geometry and motion).
class DiscWarningModalState {
  const DiscWarningModalState({
    required this.width,
    required this.measureText,
    this.dark = false,
    this.reduced = false,
    this.closing = false,
    this.search = false,
    this.opacity = 1.0,
    this.offset = 0.0,
    this.rectHook = _identityRect,
  });

  /// Landscape stage width (Qt/src/NativeHud.cpp:50, member "width"). 1920 on
  /// the design stage; modalBounds() is the only place it is consumed.
  final double width;

  /// Contract §4: fit() must measure through this callback, never hardcode.
  final DiscWarningMeasureText measureText;

  /// Theme flag (Qt/src/NativeHud.h:140).
  final bool dark;

  /// Reduced motion (Qt/src/NativeHud.h:141). Injected for host parity; it only
  /// changes DiscWarningMotion durations, never the geometry below.
  final bool reduced;

  /// Close animation in flight (Qt/src/NativeHud.h:146). Inert for drawing:
  /// modalDraw() paints the same panel until NativeHud.cpp:262-266 clears the
  /// modal after motion.finished().
  final bool closing;

  /// True only when the modal kind is "search" (Qt/src/NativeHudModal.cpp:162).
  /// This modal is "disc-rotation-warning", so the host passes false; the field
  /// exists because the generic scrim formula is shared by all full modals.
  final bool search;

  /// motion.opacity, drawn as alpha() before anything else
  /// (Qt/src/NativeHudModal.cpp:84).
  final double opacity;

  /// motion.offset, drawn as translate(0, offset) after the scrim
  /// (Qt/src/NativeHudModal.cpp:166).
  final double offset;

  /// Portrait hook; identity keeps the Qt 1920x1080 stage pixel exact.
  final DiscWarningRectHook rectHook;
}

/// Return value of DiscWarningModal.build (contract §7).
class DiscWarningModalFrame {
  const DiscWarningModalFrame({required this.commands, required this.hits});

  /// Flat Qt op() stream, same shapes as NativeHud::op()
  /// (Qt/src/NativeHud.cpp:16-43).
  final List<List<Object?>> commands;

  /// Hits in draw order, exactly six fields: x, y, width, height, action, label
  /// (Qt/src/NativeHud.cpp:102-109).
  final List<List<Object?>> hits;
}

// ---------------------------------------------------------------------------
// The modal (contract §7 entry point)
// ---------------------------------------------------------------------------

/// "DISC ROTATION" warning, shown by the "disc-rotation" action while the
/// feature is off (Qt/src/NativeHudController.cpp:711-717).
class DiscWarningModal {
  const DiscWarningModal(this.state);

  final DiscWarningModalState state;

  /// Every action string this modal can emit, in draw order.
  ///
  /// * "close-modal"          - header back button "← 返回"
  ///                            (Qt/src/NativeHudModal.cpp:199-200)
  /// * "disc-rotation:enable" - "了解风险，仍然开启"
  ///                            (Qt/src/NativeHudModal.cpp:208)
  /// * "disc-rotation:cancel" - "保持关闭"
  ///                            (Qt/src/NativeHudModal.cpp:209)
  ///
  /// There is deliberately no "取消" button and no outside catcher in this
  /// modal: the generic path emits no hit for the scrim
  /// (Qt/src/NativeHudModal.cpp:163-173); only the detail-sort popover installs
  /// a full-screen catcher (Qt/src/NativeHudModal.cpp:128).
  static const List<String> actions = <String>[
    'close-modal',
    'disc-rotation:enable',
    'disc-rotation:cancel',
  ];

  /// Escape while this modal is open (Qt/src/NativeHudController.cpp:913-922):
  /// modal is neither empty nor "desktop-lyrics", so Escape runs
  /// action("close-modal") -> closeModal() (Qt/src/NativeHudController.cpp:132-143).
  static const String escapeAction = 'close-modal';

  /// The only key Qt reaches while this modal is open.
  ///
  /// Qt swallows everything else: NativeHudController.cpp:923-925 returns for
  /// any key once a modal is open, and the arrow-scroll branches at :891-903 are
  /// limited to settings / desktop-lyrics. There is no Tab focus order in Qt;
  /// do not invent one.
  static const Map<String, String> keyActions = <String, String>{
    'Escape': 'close-modal',
  };

  /// Action for a key press while this modal is open, or null when Qt swallows
  /// the key.
  static String? actionForKey(String key) => keyActions[key];

  /// Qt/src/NativeHud.cpp:140-159 generic modal bound
  /// {left, 122, modalWidth, 836} with modalWidth = min(1260, width - 100).
  static List<double> boundsFor(double width) {
    final modalWidth = _min(1260.0, width - 100.0);
    final left = (width - modalWidth) / 2.0;
    return <double>[left, 122.0, modalWidth, 836.0];
  }

  /// Pure: builds the command and hit stream for the injected state.
  DiscWarningModalFrame build() {
    final painter = _DiscWarningPainter(state);

    // Qt/src/NativeHudModal.cpp:83-84.
    painter.save();
    painter.alpha(state.opacity);

    // Qt/src/NativeHudModal.cpp:163-165: the scrim is painted before the
    // translate, so it does not travel with the panel.
    painter.fill(0.0, 0.0, state.width, 1080.0, painter.scrim());

    // Qt/src/NativeHudModal.cpp:166.
    painter.translate(0.0, state.offset);

    final bounds = DiscWarningModal.boundsFor(state.width);
    final x = bounds[0];
    final y = bounds[1];
    final usable = bounds[2];

    // Qt/src/NativeHudModal.cpp:171-172: panel plate, height literal 836.
    painter.fill(x, y, usable, 836.0, painter.panelFill());

    // Qt/src/NativeHudModal.cpp:173: base layer keeps no events from here on.
    painter.hits.clear();

    // Qt/src/NativeHudModal.cpp:188-198: category stays "MUSIC DIRECTORY";
    // size is 11 because the modal is not "settings".
    painter.text(
      'RHINE LAB / MUSIC DATABASE / MUSIC DIRECTORY',
      x + 53.0,
      y + 37.0,
      11.0,
      'regular',
      0.0,
    );

    // Qt/src/NativeHudModal.cpp:199-200: header back button.
    painter.button(
      '← 返回',
      x + usable - 220.0,
      y + 18.0,
      167.0,
      54.0,
      'close-modal',
      20.0,
      'demibold',
    );

    // Qt/src/NativeHudModal.cpp:201-202: title 38, subtitle 15 (not settings).
    painter.text('DISC ROTATION', x + 53.0, y + 91.0, 38.0, 'demibold', 0.0);
    painter.text(
      '开启前请确认资源与功耗风险',
      x + 53.0,
      y + 147.0,
      15.0,
      'regular',
      0.0,
    );

    // Qt/src/NativeHudModal.cpp:203-209: disc rotation warning body.
    painter.text(
      '唱片旋转需要持续刷新画面。',
      x + 53.0,
      y + 250.0,
      22.0,
      'demibold',
      0.0,
    );
    painter.text(
      '开启后会增加 CPU / GPU 占用、耗电和发热，可能缩短电池续航。',
      x + 53.0,
      y + 310.0,
      16.0,
      'regular',
      0.0,
    );
    painter.text(
      '仅当前歌曲的详情页和歌词页旋转；资源库、暂停和后台均不旋转。',
      x + 53.0,
      y + 352.0,
      16.0,
      'regular',
      0.0,
    );
    painter.text(
      '该功能默认关闭，减少动态效果开启时也不会旋转。',
      x + 53.0,
      y + 394.0,
      16.0,
      'regular',
      0.0,
    );
    painter.button(
      '了解风险，仍然开启',
      x + 53.0,
      y + 480.0,
      260.0,
      48.0,
      'disc-rotation:enable',
      16.0,
    );
    painter.button(
      '保持关闭',
      x + 340.0,
      y + 480.0,
      180.0,
      48.0,
      'disc-rotation:cancel',
      16.0,
    );

    // Qt/src/NativeHudModal.cpp:255-256.
    painter.restore();

    return DiscWarningModalFrame(
      commands: painter.commands,
      hits: painter.hits,
    );
  }
}

// ---------------------------------------------------------------------------
// Painter: one-to-one copy of the NativeHud primitives this modal uses
// ---------------------------------------------------------------------------

class _DiscWarningPainter {
  _DiscWarningPainter(this.state);

  final DiscWarningModalState state;
  final List<List<Object?>> commands = <List<Object?>>[];
  final List<List<Object?>> hits = <List<Object?>>[];

  // --- contract §5: every rect and text anchor goes through the hook --------

  List<double> rect(double x, double y, double width, double height) =>
      state.rectHook(x, y, width, height);

  /// Text has no rect of its own; a zero-size rect yields the mapped origin.
  List<double> anchor(double x, double y) => state.rectHook(x, y, 0.0, 0.0);

  // --- contract §1: colour literals, exact Qt components -------------------

  /// Qt/src/NativeHud.cpp:10-15 ink().
  List<Object?> ink() => state.dark
      ? <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite']
      : <Object?>[0.08, 0.085, 0.075, 1.0, 'calibratedRGB'];

  /// Qt/src/NativeHudModal.cpp:171-172 panel plate. The light literal has four
  /// components in Qt, the dark one carries "calibratedWhite"; both are exact.
  List<Object?> panelFill() => state.dark
      ? <Object?>[0.15, 0.15, 0.15, 1.0, 'calibratedWhite']
      : <Object?>[0.929, 0.922, 0.894, 1.0];

  /// Qt/src/NativeHudModal.cpp:163-165 scrim, alpha 0.15/0.12 on the search
  /// modal and 0.6/0.45 everywhere else (this modal is never "search").
  List<Object?> scrim() => state.dark
      ? <Object?>[17.0 / 255, 24.0 / 255, 27.0 / 255, state.search ? 0.15 : 0.6]
      : <Object?>[
          227.0 / 255,
          224.0 / 255,
          215.0 / 255,
          state.search ? 0.12 : 0.45,
        ];

  /// Qt/src/NativeHud.cpp:115-116 button plate while m_modalControls is true.
  List<Object?> buttonTint() => state.dark
      ? <Object?>[0.55, 0.59, 0.46, 0.13]
      : <Object?>[0.44, 0.49, 0.36, 0.1];

  // --- contract §2: command shapes -----------------------------------------

  void save() => commands.add(<Object?>['save']);

  void restore() => commands.add(<Object?>['restore']);

  void alpha(double value) => commands.add(<Object?>['alpha', value]);

  void translate(double x, double y) =>
      commands.add(<Object?>['translate', x, y]);

  void fill(double x, double y, double width, double height,
      List<Object?> color) {
    final bounds = rect(x, y, width, height);
    commands.add(<Object?>[
      'fill',
      color,
      bounds[0],
      bounds[1],
      bounds[2],
      bounds[3],
    ]);
  }

  /// Qt/src/NativeHud.cpp:40-43 text(); weight is explicit here because Qt's
  /// default "regular" is a C++ default argument, not a wire value.
  void text(
    String value,
    double x,
    double y,
    double size,
    String weight,
    double tracking, [
    List<Object?>? color,
  ]) {
    final point = anchor(x, y);
    commands.add(<Object?>[
      'text',
      value,
      point[0],
      point[1],
      size,
      weight,
      tracking,
      color ?? ink(),
    ]);
  }

  // --- contract §3: hits, six fields, draw order ---------------------------

  /// Qt/src/NativeHud.cpp:102-109 hit(); label falls back to action.
  void hit(
    double x,
    double y,
    double width,
    double height,
    String action, [
    String? label,
  ]) {
    final bounds = rect(x, y, width, height);
    hits.add(<Object?>[
      bounds[0],
      bounds[1],
      bounds[2],
      bounds[3],
      action,
      label ?? action,
    ]);
  }

  // --- contract §8: button -------------------------------------------------

  /// Qt/src/NativeHud.cpp:110-120 button() with m_modalControls true:
  /// hit, inset = min(10, width / 8), tint plate, fitted text at
  /// (x + inset, y + (height - size) / 2 - 4).
  ///
  /// Qt forwards only `fit(label, size, width - inset * 2)` (NativeHud.cpp:118)
  /// and this button's own weight is never passed to fit, so the measurement
  /// always uses fit's C++ default `weight = "regular"` (NativeHud.h:249) even
  /// when the label is drawn demibold. The drawn weight stays [resolved].
  void button(
    String label,
    double x,
    double y,
    double width,
    double height,
    String action,
    double size, [
    String? weight,
  ]) {
    final resolved = weight ?? 'regular';
    hit(x, y, width, height, action, label);
    final inset = _min(10.0, width / 8.0);
    fill(x, y, width, height, buttonTint());
    text(
      fit(label, size, width - inset * 2.0),
      x + inset,
      y + (height - size) / 2.0 - 4.0,
      size,
      resolved,
      0.0,
    );
  }

  // --- contract §4: fit through the injected measurement -------------------

  /// Qt/src/NativeHud.cpp:48-76 fit(): binary search over QString::left() units
  /// (Dart String.length counts the same UTF-16 code units), then drop one kept
  /// unit and append U+2026 when truncation happened.
  String fit(String value, double size, double width, [String? weight]) {
    final resolved = weight ?? 'regular';
    var length = value.length;
    if (state.measureText(value, size, resolved, 0.0) > width) {
      var low = 1;
      var high = length;
      while (low < high) {
        final middle = (low + high + 1) ~/ 2;
        if (state.measureText(value.substring(0, middle), size, resolved, 0.0) <=
            width) {
          low = middle;
        } else {
          high = middle - 1;
        }
      }
      length = low;
    }
    if (length != value.length) {
      final keep = length - 1 < 0 ? 0 : length - 1;
      return value.substring(0, keep) + '…';
    }
    return value;
  }

  // --- contract §9: shared primitives kept identical across the 8 modals ---

  /// Qt/src/NativeHud.cpp:125-129 rule() = fill(x, y, width, 1, ink with alpha).
  ///
  /// Unused here: the disc rotation warning panel draws no rule
  /// (Qt/src/NativeHudModal.cpp:203-209). Kept so every modal port exposes the
  /// same primitive with the same numbers.
  // ignore: unused_element
  void rule(double x, double y, double width, double opacity) {
    final color = ink();
    color[3] = opacity;
    fill(x, y, width, 1.0, color);
  }

  /// Qt/src/NativeHudModal.cpp:106-107 muted = ink() with alpha 0.45.
  ///
  /// Unused here: every text on this panel uses the full ink
  /// (Qt/src/NativeHudModal.cpp:203-209).
  // ignore: unused_element
  List<Object?> muted() {
    final color = ink();
    color[3] = 0.45;
    return color;
  }

  /// Qt/src/NativeHud.cpp:77-79 limited().
  ///
  /// Unused here: this panel has no truncated single-line label
  /// (Qt/src/NativeHudModal.cpp:203-209); the three buttons fit their text.
  // ignore: unused_element
  void limited(
    String value,
    double x,
    double y,
    double size,
    double width, [
    String? weight,
  ]) {
    final resolved = weight ?? 'regular';
    text(fit(value, size, width, resolved), x, y, size, resolved, 0.0);
  }
}
