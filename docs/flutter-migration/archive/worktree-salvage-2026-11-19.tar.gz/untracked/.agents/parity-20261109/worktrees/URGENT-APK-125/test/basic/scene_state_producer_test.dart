/// SCENE-PRODUCER-120：HUD → ScenePreview 的 boot/detail/lyrics 模式与昼夜生产者回归。
///
/// 真值来源（以 Qt 原始源码为准，不转述旧报告的结论）：
/// - Qt/src/MusicSession.cpp:262：恢复路径 mode = (view["mode"] == "detail" &&
///   !music.current.isEmpty()) ? "detail" : "archive"——detail 要求“详情页”加
///   “确实有当前曲目”。
/// - Qt/src/NativeHudController.cpp:310-321：playerAction("lyrics") 在有当前曲目时
///   显式调用 m_scene.mode("detail") 并写 frame["mode"] = "detail"；lyrics-close
///   只清 lyricsMode。所以 Qt 的歌词是 detail；历史版 114 把歌词映射成 archive
///   与 Qt 相反，本原子按 Qt 纠正并在 basic_hud.dart:433-437 写明。
/// - Qt/src/NativeSceneCamera.cpp:100-105：archiveOffset = cinema || m_mode == "boot"
///   ? 0.0 : 1 - detailProgress——boot 是独立模式，不是 archive 的默认值。
/// - Qt/src/NativeScene.cpp:165-198 setMode / :199-202 theme(bool dark)：boot 会
///   select() 解密层、锁住 m_bootStart 并停掉 actor 循环；模式与昼夜是两个独立
///   输入，archive 只切换陈列状态，不销毁视图。
/// - lib/basic/scene_preview.dart：ScenePreview 的 mode 只认 archive/detail/boot
///   （_isSceneMode），未知值回落 archive；ready 之后 theme/mode 走 setScene
///   增量下发，AndroidView 的 key 只跟 model 走，所以同一 model 下切歌/换专辑
///   不需要重建视图。
///
/// 本文件只断言源码级生产者与挂载参数（作者被授权编写、不授权执行测试，运行时/
/// 设备/像素轴是 NOT_RUN，不能把这些用例当成运行时证据）。widget 用例在 iOS
/// 覆盖下运行（ScenePreview 走可见说明分支），因为 widget 测试没有 Android
/// 平台视图；寿命判据取 ScenePreview 的 Element 身份，身份键一旦回来，
/// Element 必被替换，用例即失败。
library;

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/basic/basic_hud.dart';
import 'package:rhine_music_database/basic/basic_hud_resources.dart';
import 'package:rhine_music_database/basic/basic_models.dart';
import 'package:rhine_music_database/basic/scene_preview.dart';
import 'package:rhine_music_database/hud/input/hit_layer.dart';
import 'package:rhine_music_database/hud/protocol/hud_frame.dart';
import 'package:rhine_music_database/hud/text/glyph_font.dart';
import 'package:rhine_music_database/hud/text/glyph_run.dart';
import 'package:rhine_music_database/ui/layout/portrait_stage.dart';

SirenSong _song(String id, {String albumId = 'album-a'}) => SirenSong(
      id: id,
      title: '曲目 $id',
      artist: '塞壬唱片-MSR',
      album: '合集 $albumId',
      albumId: albumId,
      cover: '',
      sourceUrl: '',
      lyricUrl: '',
      durationMs: 0,
    );

SirenAlbum _album(String id, List<SirenSong> songs) => SirenAlbum(
      id: id,
      name: '专辑 $id',
      artist: '塞壬唱片-MSR',
      cover: '',
      songCount: songs.length,
      songs: songs,
    );

BasicGlyphPorts _ports() {
  final GlyphFontSet fonts = GlyphFontSet.empty;
  final GlyphText text = GlyphText.resourceOnly(fonts);
  return BasicGlyphPorts(glyphs: fonts, text: text);
}

Widget _landscapeHarness({required BasicViewState state}) {
  const Size size = Size(1920, 1080);
  final StageGeometry geometry = StageGeometry(
    logicalWidth: size.width,
    logicalHeight: size.height,
  );
  final HudStage stage = HudStage(
    scale: geometry.stageScale,
    width: geometry.stageWidth,
    height: StageGeometry.baseHeight,
  );
  return Directionality(
    textDirection: TextDirection.ltr,
    child: SizedBox(
      width: size.width,
      height: size.height,
      child: StageGeometryScope(
        geometry: geometry,
        child: HudStageScope(
          stage: stage,
          child: BasicHudSurface(
            state: state,
            ports: _ports(),
            onAction: (String _) {},
            geometry: geometry,
            stage: stage,
          ),
        ),
      ),
    ),
  );
}

/// 把一帧状态推进 HUD，返回 HUD 实际挂载的 ScenePreview。
Future<ScenePreview> _pump(WidgetTester tester, BasicViewState state) async {
  await tester.pumpWidget(_landscapeHarness(state: state));
  await tester.pump();
  expect(find.byType(ScenePreview), findsOneWidget);
  return tester.widget<ScenePreview>(find.byType(ScenePreview));
}

void _expectParams(
  ScenePreview preview, {
  required String songId,
  required String albumId,
  required double theme,
  required String mode,
}) {
  expect(preview.songId, songId);
  expect(preview.albumId, albumId);
  expect(preview.theme, theme);
  expect(preview.mode, mode);
  expect(preview.model, basicSceneDefaultModel);
  expect(preview.initialYaw, 0);
  expect(preview.onReady, isNull);
  // 不许出现第四种 mode/中间主题：Qt 只有这三个模式名与两端亮度。
  expect(
    <String>[basicSceneArchiveMode, basicSceneDetailMode, basicSceneBootMode],
    contains(preview.mode),
  );
  expect(preview.theme, anyOf(0.0, 1.0));
}

void main() {
  group('Qt 主题/模式生产者（纯）', () {
    test('dark 只映射 1.0，light 只映射 0.0（Qt bool，不造中间值）', () {
      expect(basicSceneTheme(const BasicViewState(dark: true)), 1.0);
      expect(basicSceneTheme(const BasicViewState(dark: false)), 0.0);
      expect(
        basicScenePreview(const BasicViewState(dark: false)).theme,
        0.0,
      );
      expect(
        basicScenePreview(const BasicViewState(dark: true)).theme,
        1.0,
      );
    });

    test('详情页/歌词页 + 有当前曲目才请求 detail', () {
      final SirenSong song = _song('s1');
      expect(
        basicSceneMode(BasicViewState(phase: BasicPhase.detail, song: song)),
        basicSceneDetailMode,
      );
      // 歌词是 Qt 的 detail：NativeHudController.cpp:310-318 显式 mode("detail")，
      // 历史版 114 映射成 archive 与 Qt 相反，本原子按 Qt 纠正。
      expect(
        basicSceneMode(BasicViewState(phase: BasicPhase.lyrics, song: song)),
        basicSceneDetailMode,
      );
      // 没有当前曲目：Qt 的 !music.current.isEmpty() 为假，必须 archive，
      // 场景绝不能凭空进入详情混合状态。
      expect(
        basicSceneMode(const BasicViewState(phase: BasicPhase.detail)),
        basicSceneArchiveMode,
      );
      expect(
        basicSceneMode(const BasicViewState(phase: BasicPhase.lyrics)),
        basicSceneArchiveMode,
      );
      final SirenAlbum album = _album('album-a', <SirenSong>[song]);
      expect(
        basicSceneMode(BasicViewState(
          phase: BasicPhase.detail,
          album: album,
        )),
        basicSceneArchiveMode,
      );
      expect(
        basicSceneMode(BasicViewState(phase: BasicPhase.lyrics, album: album)),
        basicSceneArchiveMode,
      );
    });

    test('启动阶段一律 boot（即使留着上一轮的曲目），曲库仍是 archive', () {
      final SirenSong stale = _song('s1');
      expect(
        basicSceneMode(const BasicViewState(phase: BasicPhase.boot)),
        basicSceneBootMode,
      );
      // 冷启动时 HUD 可能还带着上次的选中曲目：boot 优先，不能被 detail 逻辑吃掉。
      expect(
        basicSceneMode(BasicViewState(phase: BasicPhase.boot, song: stale)),
        basicSceneBootMode,
      );
      expect(
        basicSceneMode(BasicViewState(
          phase: BasicPhase.boot,
          song: stale,
          album: _album('album-a', <SirenSong>[stale]),
        )),
        basicSceneBootMode,
      );
      expect(
        basicSceneMode(BasicViewState(phase: BasicPhase.library, song: stale)),
        basicSceneArchiveMode,
      );
    });

    test('场景矩形与舞台约定不变（横屏 1131×984、竖屏封顶 1080、退化不挂载）', () {
      expect(
        basicSceneStageRect(portrait: false, width: 1920, height: 1080),
        const Rect.fromLTWH(0, 0, 1131, 984),
      );
      expect(
        basicSceneStageRect(portrait: true, width: 1080, height: 1920),
        const Rect.fromLTWH(0, 0, 1080, 1080),
      );
      // 竖屏高度不足 1080 设计高度时用实际高度，不越过曲目列。
      expect(
        basicSceneStageRect(portrait: true, width: 720, height: 900),
        const Rect.fromLTWH(0, 0, 720, 900),
      );
      expect(
        basicSceneStageRect(portrait: false, width: 300, height: 200),
        isNull,
      );
    });

    test('身份字段沿用原语义：无选中时是空串，专辑页用专辑 id', () {
      final SirenSong song = _song('s1');
      final SirenAlbum album = _album('album-a', <SirenSong>[song]);
      const BasicViewState empty = BasicViewState(phase: BasicPhase.library);
      expect(basicScenePreview(empty).songId, '');
      expect(basicScenePreview(empty).albumId, '');
      // 详情（从曲目进入）：albumId 回落到曲目自带的专辑 id。
      final ScenePreview fromSong = basicScenePreview(
        BasicViewState(phase: BasicPhase.detail, song: song),
      );
      expect(fromSong.songId, 's1');
      expect(fromSong.albumId, 'album-a');
      // 详情（从专辑进入）：显式打开的专辑优先，与既有实现一致。
      final ScenePreview fromAlbum = basicScenePreview(BasicViewState(
        phase: BasicPhase.detail,
        album: album,
        song: song,
      ));
      expect(fromAlbum.albumId, 'album-a');
      expect(fromAlbum.mode, basicSceneDetailMode);
    });

    test('生产函数本体不含任何身份键（补充守卫，主判据是元素寿命用例）', () {
      final String source = File('lib/basic/basic_hud.dart').readAsStringSync();
      final String body = _blockAfter(source, 'ScenePreview basicScenePreview(');
      expect(body.contains('key'), isFalse,
          reason: 'basicScenePreview 不得给 ScenePreview 传 key：'
              '身份键会销毁 AndroidView 并重载 GLB（RUNTIME-98 回归）');
      expect(body.contains('ValueKey'), isFalse);
      expect(body.contains('basicSceneIdentityKey'), isFalse);
    });
  });

  group('HUD 实际挂载的 ScenePreview 参数', () {
    testWidgets('light/dark × boot/archive/detail × 有曲目/无曲目 都由状态决定',
        (WidgetTester tester) async {
      debugDefaultTargetPlatformOverride = TargetPlatform.iOS;
      addTearDown(() => debugDefaultTargetPlatformOverride = null);

      final SirenSong song = _song('s1');

      // 启动空曲库：深色、boot（不是 archive 的默认值）、无 id。
      _expectParams(
        await _pump(tester, const BasicViewState(phase: BasicPhase.boot)),
        songId: '',
        albumId: '',
        theme: 1.0,
        mode: basicSceneBootMode,
      );

      // 冷启动但 HUD 还留着上一轮的曲目：boot 优先，id 照实透传。
      _expectParams(
        await _pump(
          tester,
          BasicViewState(phase: BasicPhase.boot, song: song, dark: false),
        ),
        songId: 's1',
        albumId: 'album-a',
        theme: 0.0,
        mode: basicSceneBootMode,
      );

      // 曲库亮色：0.0，archive。
      _expectParams(
        await _pump(
          tester,
          const BasicViewState(phase: BasicPhase.library, dark: false),
        ),
        songId: '',
        albumId: '',
        theme: 0.0,
        mode: basicSceneArchiveMode,
      );

      // 详情 + 曲目 + 深色：1.0/detail。
      _expectParams(
        await _pump(
          tester,
          BasicViewState(phase: BasicPhase.detail, song: song),
        ),
        songId: 's1',
        albumId: 'album-a',
        theme: 1.0,
        mode: basicSceneDetailMode,
      );

      // 歌词 + 曲目：Qt 里就是 detail，不许回 archive。
      _expectParams(
        await _pump(
          tester,
          BasicViewState(phase: BasicPhase.lyrics, song: song, dark: false),
        ),
        songId: 's1',
        albumId: 'album-a',
        theme: 0.0,
        mode: basicSceneDetailMode,
      );

      // 详情 + 无曲目：绝不允许 detail。
      _expectParams(
        await _pump(
          tester,
          const BasicViewState(phase: BasicPhase.detail, dark: false),
        ),
        songId: '',
        albumId: '',
        theme: 0.0,
        mode: basicSceneArchiveMode,
      );

      expect(tester.takeException(), isNull);
    });

    testWidgets('HUD 的参数与 basicScenePreview 逐字段一致（不是另一份字面量）',
        (WidgetTester tester) async {
      debugDefaultTargetPlatformOverride = TargetPlatform.iOS;
      addTearDown(() => debugDefaultTargetPlatformOverride = null);
      final SirenSong song = _song('s9', albumId: 'album-z');
      final List<BasicViewState> states = <BasicViewState>[
        const BasicViewState(phase: BasicPhase.boot),
        BasicViewState(phase: BasicPhase.boot, song: song, dark: false),
        const BasicViewState(phase: BasicPhase.library),
        const BasicViewState(phase: BasicPhase.library, dark: false),
        BasicViewState(phase: BasicPhase.detail, song: song, dark: false),
        BasicViewState(phase: BasicPhase.lyrics, song: song, dark: false),
        const BasicViewState(phase: BasicPhase.detail, dark: false),
      ];
      for (final BasicViewState state in states) {
        final ScenePreview mounted = await _pump(tester, state);
        final ScenePreview produced = basicScenePreview(state);
        // HUD 必须调用生产函数本身，不能在挂载处另抄一份 mode/theme 字面量。
        expect(mounted.songId, produced.songId, reason: '$state');
        expect(mounted.albumId, produced.albumId, reason: '$state');
        expect(mounted.model, produced.model, reason: '$state');
        expect(mounted.theme, produced.theme, reason: '$state');
        expect(mounted.mode, produced.mode, reason: '$state');
        expect(mounted.initialYaw, produced.initialYaw, reason: '$state');
        expect(mounted.onReady, produced.onReady, reason: '$state');
        expect(mounted.key, isNull, reason: '$state');
      }
    });
  });

  group('同一 model 下的视图寿命（切歌/换专辑/切昼夜/进出详情不重建）', () {
    testWidgets('连续状态变化保持同一个 ScenePreview Element，且始终没有身份键',
        (WidgetTester tester) async {
      debugDefaultTargetPlatformOverride = TargetPlatform.iOS;
      addTearDown(() => debugDefaultTargetPlatformOverride = null);

      final SirenSong songA = _song('s1', albumId: 'album-a');
      final SirenSong songB = _song('s2', albumId: 'album-b');
      final SirenAlbum albumB = _album('album-b', <SirenSong>[songB]);

      // 起点是冷启动：HUD 还留着上一轮的 songA，模式必须是 boot。
      final ScenePreview preview = await _pump(
        tester,
        BasicViewState(phase: BasicPhase.boot, song: songA, albums: <SirenAlbum>[albumB]),
      );
      final Element first = tester.element(find.byType(ScenePreview));
      expect(preview.key, isNull);
      expect(preview.mode, basicSceneBootMode);
      expect(preview.songId, 's1');
      expect(tester.getSize(find.byType(ScenePreview)), const Size(1131, 984));

      Future<void> expectSameElement(
        BasicViewState next, {
        required String songId,
        required String albumId,
        required double theme,
        required String mode,
      }) async {
        final ScenePreview updated = await _pump(tester, next);
        // 元素身份 = 没有销毁重建；一旦身份键回来，这里必然换成新 Element。
        expect(identical(tester.element(find.byType(ScenePreview)), first), isTrue,
            reason: '同一 model 下状态变化不得重建 ScenePreview（禁止身份 key 重挂载）');
        expect(updated.key, isNull);
        _expectParams(
          updated,
          songId: songId,
          albumId: albumId,
          theme: theme,
          mode: mode,
        );
        expect(tester.getSize(find.byType(ScenePreview)), const Size(1131, 984));
        expect(find.byType(ScenePreview), findsOneWidget);
        expect(tester.takeException(), isNull);
      }

      // 1) 启动结束进入曲库：boot → archive，视图不重建。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.library, song: songA),
        songId: 's1',
        albumId: 'album-a',
        theme: 1.0,
        mode: basicSceneArchiveMode,
      );

      // 2) 打开详情（同一首歌）：archive → detail。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.detail, song: songA),
        songId: 's1',
        albumId: 'album-a',
        theme: 1.0,
        mode: basicSceneDetailMode,
      );

      // 3) 切到另一首歌（连同专辑变化）：只换参数，不换视图。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.detail, song: songB),
        songId: 's2',
        albumId: 'album-b',
        theme: 1.0,
        mode: basicSceneDetailMode,
      );

      // 4) 打开专辑详情（album 显式提供）：albumId 走专辑，视图仍是同一个。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.detail, album: albumB, song: songB),
        songId: 's2',
        albumId: 'album-b',
        theme: 1.0,
        mode: basicSceneDetailMode,
      );

      // 5) 切回亮色：theme 走 setScene，不重载。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.detail, album: albumB, song: songB, dark: false),
        songId: 's2',
        albumId: 'album-b',
        theme: 0.0,
        mode: basicSceneDetailMode,
      );

      // 6) 进入歌词页：视图继续存活；Qt 里歌词是 detail，模式不许回 archive。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.lyrics, album: albumB, song: songB, dark: false),
        songId: 's2',
        albumId: 'album-b',
        theme: 0.0,
        mode: basicSceneDetailMode,
      );

      // 7) 返回曲库、清空选中：songId/albumId 回空串，视图仍然不重建。
      await expectSameElement(
        const BasicViewState(phase: BasicPhase.library, dark: false),
        songId: '',
        albumId: '',
        theme: 0.0,
        mode: basicSceneArchiveMode,
      );

      // 8) 再次选歌（跨专辑）：仍旧是同一个 Element。
      await expectSameElement(
        BasicViewState(phase: BasicPhase.detail, song: songA, dark: false),
        songId: 's1',
        albumId: 'album-a',
        theme: 0.0,
        mode: basicSceneDetailMode,
      );
    });
  });
}

/// 取出 [marker] 之后第一个花括号块（只用于把源码守卫限制在生产函数体内）。
String _blockAfter(String source, String marker) {
  final int at = source.indexOf(marker);
  expect(at, greaterThanOrEqualTo(0), reason: 'missing source marker: $marker');
  final int start = source.indexOf('{', at);
  expect(start, greaterThanOrEqualTo(0), reason: 'no block after: $marker');
  int depth = 0;
  for (int index = start; index < source.length; index++) {
    final String ch = source[index];
    if (ch == '{') {
      depth++;
    }
    if (ch == '}') {
      depth--;
      if (depth == 0) {
        return source.substring(at, index + 1);
      }
    }
  }
  return source.substring(at);
}
