// Qt Android -> Flutter 迁移：MusicData / MusicItem 的 1:1 移植单元测试。
//
// 【本测试未执行】本文件**未执行**。本会话被明确禁止运行 flutter/dart 的任何
// build / test / analyze / format（含 dart test、flutter test、pub get、代码生成），
// 是否执行由 Lead 统一决定。所有断言按 Qt/src/MusicData.cpp 原文逐条推导。
//
// 依赖：只有 package:flutter_test 与被测文件，未新增任何依赖
// （本仓 pubspec.lock 无独立的 test 包，与 test/domain/provider_id_test.dart、
// test/domain/api_result_test.dart 一致，统一用 flutter_test 的 test/expect）。
// 规则编号 R1..R20 与 atom 报告、Qt/src/MusicData.cpp 行号一一对应。
import 'package:flutter_test/flutter_test.dart';

import 'package:rhine_music_database/domain/models/music_item.dart';

/// 复刻 Qt 的 yyyy-MM-dd（Qt/src/MusicData.cpp:77），用于校验 [MusicItem.date]。
///
/// 这里刻意用字符串拼接而不是插值，避免与被测实现的格式化写法雷同。
String expectedDate(DateTime value) {
  final String year = value.year.toString().padLeft(4, '0');
  final String month = value.month.toString().padLeft(2, '0');
  final String day = value.day.toString().padLeft(2, '0');
  return year + '-' + month + '-' + day;
}

/// 构造一条最小可解析的原始 JSON（parse 只强制要求 id 与 name，:42-46）。
JsonMap rawItem({
  Object? id = '1',
  Object? name = 'A',
  bool withName = true,
}) {
  final JsonMap value = <String, dynamic>{'id': id};
  if (withName) {
    value['name'] = name;
  }
  return value;
}

MusicItem song(String id, {String title = '', String artist = '', String album = ''}) {
  return MusicItem(kind: 'song', id: id, title: title, artist: artist, album: album);
}

void main() {
  // -------------------------------------------------------------------------
  // R1 identifier（Qt/src/MusicData.cpp:10-18）
  // -------------------------------------------------------------------------
  group('R1 identifier（Qt/src/MusicData.cpp:10-18）', () {
    test('字符串原样返回（:11-13 value.isString）', () {
      expect(MusicData.identifier('abc'), 'abc');
      expect(MusicData.identifier(''), '');
      // 前导零必须保留：identifier 不是数字规范化。
      expect(MusicData.identifier('007'), '007');
      expect(MusicData.identifier('12a'), '12a');
    });

    test('整数转十进制字符串（:14-16 QString::number(value.toInteger())）', () {
      expect(MusicData.identifier(0), '0');
      expect(MusicData.identifier(12345), '12345');
      expect(MusicData.identifier(-7), '-7');
    });

    test('整数值 double 转十进制字符串（:15 toInteger 的 convertDoubleTo 路径）', () {
      expect(MusicData.identifier(1.0), '1');
      expect(MusicData.identifier(3.0), '3');
      expect(MusicData.identifier(-0.0), '0');
      // 大整数形式的 double 也要保持十进制、不带小数点。
      expect(MusicData.identifier(123.0), '123');
    });

    test('非整数 double 得 "0"，不是向零截断（qjsonvalue.cpp:719-728 + qnumeric_p.h:286）', () {
      // convertDoubleTo<qint64> 的整性判定是 return *value == v，失败即回默认值 0。
      expect(MusicData.identifier(1.9), '0');
      expect(MusicData.identifier(-1.9), '0');
      expect(MusicData.identifier(3.7), '0');
      expect(MusicData.identifier(0.5), '0');
    });

    test('超出 qint64 或非有限 double 得 "0"（qnumeric_p.h:277-284 范围门）', () {
      expect(MusicData.identifier(1e300), '0');
      expect(MusicData.identifier(-1e300), '0');
      expect(MusicData.identifier(double.infinity), '0');
      expect(MusicData.identifier(double.nan), '0');
    });

    test('null 返回空串（:17 return {}）', () {
      expect(MusicData.identifier(null), '');
    });

    test('bool 不是数字，返回空串（:11-17 只有 isString / isDouble 两支）', () {
      // QJsonValue(true).isDouble() == false，因此落到 return {}。
      expect(MusicData.identifier(true), '');
      expect(MusicData.identifier(false), '');
    });

    test('List / Map 返回空串（:17）', () {
      expect(MusicData.identifier(<Object?>[1, 2]), '');
      expect(MusicData.identifier(<String, dynamic>{'id': 1}), '');
    });
  });

  // -------------------------------------------------------------------------
  // R2 item()（Qt/src/MusicData.cpp:22-39）
  // -------------------------------------------------------------------------
  group('R2 item() 的 16 个键（Qt/src/MusicData.cpp:22-39）', () {
    test('键集合与键名与 Qt 字面量一致；Dart 保留插入序，Qt QJsonObject 内部是字典序（:23-38）', () {
      final JsonMap item = MusicData.item('song', '42');
      expect(item.keys.toList(), <String>[
        'kind',
        'id',
        'title',
        'artist',
        'artists',
        'creatorID',
        'albumID',
        'album',
        'cover',
        'description',
        'wiki',
        'date',
        'duration',
        'trackCount',
        'provider',
        'key',
      ]);
      expect(item.length, 16);
    });

    test('默认参数：title=正在读取…、artist 空、provider=netease（:22-23）', () {
      final JsonMap item = MusicData.item('album', '9');
      expect(item['title'], '正在读取…');
      expect(item['artist'], '');
      expect(item['provider'], 'netease');
    });

    test('命名参数可覆盖 title/artist/provider（:22 函数签名）', () {
      final JsonMap item =
          MusicData.item('artist', '5', title: '名字', artist: '歌手', provider: 'qq');
      expect(item['title'], '名字');
      expect(item['artist'], '歌手');
      expect(item['provider'], 'qq');
      expect(item['key'], 'qq:artist:5');
    });

    test('其余字段初值照抄（:27-36）', () {
      final JsonMap item = MusicData.item('playlist', '7');
      expect(item['artists'], isEmpty);
      expect(item['creatorID'], '');
      expect(item['albumID'], '');
      expect(item['album'], '');
      expect(item['cover'], '');
      expect(item['description'], '');
      expect(item['wiki'], '');
      expect(item['date'], '');
      expect(item['duration'], 0);
      expect(item['trackCount'], 0);
    });

    test('key = provider + ":" + kind + ":" + id（:38）', () {
      expect(MusicData.item('song', '1', provider: 'kugou')['key'], 'kugou:song:1');
      expect(MusicData.item('album', 'abc')['key'], 'netease:album:abc');
    });

    test('JSON 键是大写 ID，Dart 字段名不是键名（:28-29）', () {
      final JsonMap item = MusicData.item('song', '1');
      expect(item.containsKey('creatorID'), isTrue);
      expect(item.containsKey('albumID'), isTrue);
      expect(item.containsKey('creatorId'), isFalse);
      expect(item.containsKey('albumId'), isFalse);
    });
  });

  // -------------------------------------------------------------------------
  // R2b MusicItem 模型本身
  // -------------------------------------------------------------------------
  group('R2b MusicItem 形状（Qt/src/MusicData.cpp:22-39, :62）', () {
    test('key getter 逐字等于 provider:kind:id', () {
      expect(song('9').key, 'netease:song:9');
      expect(
        const MusicItem(kind: 'playlist', id: '3', provider: 'qq').key,
        'qq:playlist:3',
      );
    });

    test('placeholder 走 item() 的默认值（:22-39, :65）', () {
      final MusicItem item = MusicItem.placeholder('album', '77');
      expect(item.kind, 'album');
      expect(item.id, '77');
      expect(item.title, '正在读取…');
      expect(item.artist, '');
      expect(item.provider, 'netease');
      expect(item.artists, isEmpty);
      expect(item.duration, 0);
      expect(item.trackCount, 0);
      expect(item.creatorId, '');
      expect(item.albumId, '');
      expect(item.date, '');
      expect(item.wiki, '');
    });

    test('placeholder 的 toJson 与 MusicData.item 的产物深相等', () {
      expect(MusicItem.placeholder('song', '1').toJson(), MusicData.item('song', '1'));
      expect(
        MusicItem.placeholder('artist', '2', title: 'T', artist: 'S', provider: 'kugou').toJson(),
        MusicData.item('artist', '2', title: 'T', artist: 'S', provider: 'kugou'),
      );
    });

    test('toJson 的 artists 是 [{id, name}] 形状（:62）', () {
      const MusicItem item = MusicItem(
        kind: 'song',
        id: '1',
        artists: <ArtistRef>[ArtistRef(id: '5', name: '甲'), ArtistRef(id: '', name: '乙')],
      );
      expect(item.toJson()['artists'], <JsonMap>[
        <String, dynamic>{'id': '5', 'name': '甲'},
        <String, dynamic>{'id': '', 'name': '乙'},
      ]);
    });

    test('MusicItem.parse 与 MusicData.parse 等价（同一实现）', () {
      final JsonMap raw = <String, dynamic>{
        'id': 12,
        'name': '晴天',
        'ar': <Object?>[
          <String, dynamic>{'id': 3, 'name': '周杰伦'},
        ],
      };
      final MusicItem? viaModel = MusicItem.parse(raw, 'song');
      final MusicItem? viaHelpers = MusicData.parse(raw, 'song');
      expect(viaModel, isNotNull);
      expect(viaModel!.toJson(), viaHelpers!.toJson());
      expect(viaModel.id, '12');
      expect(viaModel.artists.single.id, '3');
    });
  });

  // -------------------------------------------------------------------------
  // R3 parse 前置校验（Qt/src/MusicData.cpp:41-46）
  // -------------------------------------------------------------------------
  group('R3 parse 前置校验（Qt/src/MusicData.cpp:41-46）', () {
    test('合法 id + 字符串 name 解析成功（:44）', () {
      final MusicItem item = MusicData.parse(rawItem(id: '123', name: '歌名'), 'song')!;
      expect(item.kind, 'song');
      expect(item.id, '123');
      expect(item.title, '歌名');
    });

    test('id 含字母 -> null（:43-44 正则不匹配 -> return {}）', () {
      expect(MusicData.parse(rawItem(id: '12a'), 'song'), isNull);
      expect(MusicData.parse(rawItem(id: 'abc'), 'song'), isNull);
      expect(MusicData.parse(rawItem(id: '1 2'), 'song'), isNull);
    });

    test('id 长度边界：20 位通过、21 位失败（:43 {1,20}）', () {
      final String twenty = '1' * 20;
      final String twentyOne = '1' * 21;
      expect(MusicData.parse(rawItem(id: twenty), 'song'), isNotNull);
      expect(MusicData.parse(rawItem(id: twentyOne), 'song'), isNull);
    });

    test('id 空串 / 缺失 -> null（:42 identifier 得空串，正则要求至少 1 位）', () {
      expect(MusicData.parse(rawItem(id: ''), 'song'), isNull);
      expect(MusicData.parse(<String, dynamic>{'name': 'A'}, 'song'), isNull);
    });

    test('id 为 null / bool -> null（:10-18 identifier 返回空串）', () {
      expect(MusicData.parse(rawItem(id: null), 'song'), isNull);
      expect(MusicData.parse(rawItem(id: true), 'song'), isNull);
    });

    test('name 缺失 -> null（:44 raw["name"].isString()）', () {
      expect(MusicData.parse(rawItem(withName: false), 'song'), isNull);
    });

    test('name 非字符串 -> null（:44）', () {
      expect(MusicData.parse(rawItem(name: 123), 'song'), isNull);
      expect(MusicData.parse(rawItem(name: null), 'song'), isNull);
      expect(MusicData.parse(rawItem(name: <Object?>['A']), 'song'), isNull);
    });

    test('数字 id 经 identifier 转成十进制字符串（:42）', () {
      final MusicItem item = MusicData.parse(rawItem(id: 456), 'song')!;
      expect(item.id, '456');
      expect(item.key, 'netease:song:456');
    });

    test('负 id 得 "-5" 被 ^[0-9]{1,20}$ 拒 -> null（:43-44）', () {
      expect(MusicData.identifier(-5), '-5');
      expect(MusicData.parse(rawItem(id: -5), 'song'), isNull);
      expect(MusicData.parse(rawItem(id: -5.0), 'song'), isNull);
    });

    test('字符串 id 带前导零原样保留，不做数字规范化（:11-13）', () {
      final MusicItem item = MusicData.parse(rawItem(id: '007'), 'song')!;
      expect(item.id, '007');
      expect(item.key, 'netease:song:007');
    });

    test('小数 id 经 toInteger 得 0，反而通过正则产生 id "0"（Qt 同此行为）', () {
      // 已知风险点（reports/SHARED-V4-INV-A.json F2）：3.7 -> "0" 仍命中正则，
      // 因此会产生退化 id；这里按 Qt 真实语义断言，不做“修正”。
      final MusicItem item = MusicData.parse(rawItem(id: 3.7), 'song')!;
      expect(item.id, '0');
      expect(item.key, 'netease:song:0');
    });
  });

  // -------------------------------------------------------------------------
  // R4 artists 来源回退链（Qt/src/MusicData.cpp:47-53）
  // -------------------------------------------------------------------------
  group('R4 artists 来源与回退（Qt/src/MusicData.cpp:47-53）', () {
    test('优先 raw["ar"]（:47）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[
          <String, dynamic>{'id': 1, 'name': '甲'},
        ],
        'artists': <Object?>[
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
      }, 'song')!;
      expect(item.artists.single.name, '甲');
      expect(item.artist, '甲');
    });

    test('ar 键缺失 -> 回退 raw["artists"]（:48 isUndefined）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'artists': <Object?>[
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
      }, 'song')!;
      expect(item.artists.single.name, '乙');
    });

    test('ar 为 null -> 回退 raw["artists"]（:48 isNull）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': null,
        'artists': <Object?>[
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
      }, 'song')!;
      expect(item.artists.single.name, '乙');
    });

    test('ar 与 artists 都缺失、artist 是 Map -> 单元素数组（:50-51）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'artist': <String, dynamic>{'id': 7, 'name': '丙'},
      }, 'song')!;
      expect(item.artists.length, 1);
      expect(item.artists.single.id, '7');
      expect(item.artists.single.name, '丙');
      expect(item.artist, '丙');
    });

    test('ar 是空数组时**不**回退（:47 非 null 即不进 fallback）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[],
        'artists': <Object?>[
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
        'artist': <String, dynamic>{'id': 3, 'name': '丁'},
      }, 'song')!;
      expect(item.artists, isEmpty);
      expect(item.artist, '');
    });

    test('ar 是非数组（字符串）也不回退，按空数组处理（:47 toArray）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': 'nope',
        'artists': <Object?>[
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
      }, 'song')!;
      expect(item.artists, isEmpty);
    });

    test('artists 是空数组时不落到 artist 单对象（:50 只看 null/undefined）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'artists': <Object?>[],
        'artist': <String, dynamic>{'id': 3, 'name': '丁'},
      }, 'song')!;
      expect(item.artists, isEmpty);
    });

    test('artist 不是 Map 时不做单元素回退（:50 isObject）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'artist': '丁',
      }, 'song')!;
      expect(item.artists, isEmpty);
      expect(item.artist, '');
    });
  });

  // -------------------------------------------------------------------------
  // R5 逐元素过滤（Qt/src/MusicData.cpp:54-64）
  // -------------------------------------------------------------------------
  group('R5 逐元素过滤（Qt/src/MusicData.cpp:56-64）', () {
    test('非 Map 元素与 name 非字符串的元素被跳过（:58-60）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[
          'x',
          42,
          null,
          <String, dynamic>{'id': 1},
          <String, dynamic>{'id': 2, 'name': 99},
          <String, dynamic>{'id': 3, 'name': '留下'},
        ],
      }, 'song')!;
      expect(item.artists.length, 1);
      expect(item.artists.single.name, '留下');
      expect(item.artist, '留下');
    });

    test('多人名用 " / " 拼接（:66 names.join(" / ")）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[
          <String, dynamic>{'id': 1, 'name': '甲'},
          <String, dynamic>{'id': 2, 'name': '乙'},
          <String, dynamic>{'id': 3, 'name': '丙'},
        ],
      }, 'song')!;
      expect(item.artist, '甲 / 乙 / 丙');
      expect(item.artists.length, 3);
    });

    test('人名 id 走 identifier：数字转字符串、缺失为空串（:62）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[
          <String, dynamic>{'id': 99, 'name': '甲'},
          <String, dynamic>{'name': '乙'},
          <String, dynamic>{'id': 'x7', 'name': '丙'},
        ],
      }, 'song')!;
      expect(item.artists[0].id, '99');
      expect(item.artists[1].id, '');
      expect(item.artists[2].id, 'x7');
    });

    test('全部元素不合法时 artists 为空、artist 为空串（:58-66）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'ar': <Object?>[<String, dynamic>{}, <String, dynamic>{'name': null}],
      }, 'song')!;
      expect(item.artists, isEmpty);
      expect(item.artist, '');
    });
  });

  // -------------------------------------------------------------------------
  // R6 title / playlist 的 artist 取值（Qt/src/MusicData.cpp:65-66）
  // -------------------------------------------------------------------------
  group('R6 artist 取值（Qt/src/MusicData.cpp:65-66）', () {
    test('playlist 取 creator.nickname（:66）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': '歌单',
        'creator': <String, dynamic>{'nickname': '小明', 'userId': 5},
      }, 'playlist')!;
      expect(item.artist, '小明');
    });

    test('playlist 的 nickname 是空串时保留空串，不回落默认值（:66 toString(默认值) 只看类型）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': '歌单',
        'creator': <String, dynamic>{'nickname': ''},
      }, 'playlist')!;
      expect(item.artist, '');
    });

    test('playlist 的 nickname 缺失 -> 暂无创建者（:66）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': '歌单',
        'creator': <String, dynamic>{'userId': 5},
      }, 'playlist')!;
      expect(item.artist, '暂无创建者');
    });

    test('playlist 的 nickname 类型不符 -> 暂无创建者（:66）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': '歌单',
        'creator': <String, dynamic>{'nickname': 123},
      }, 'playlist')!;
      expect(item.artist, '暂无创建者');
    });

    test('playlist 的 creator 不是 Map 时也走默认值（:54 toObject -> 空对象）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': '歌单',
        'creator': 'nope',
      }, 'playlist')!;
      expect(item.artist, '暂无创建者');
    });

    test('非 playlist 忽略 nickname，仍用 " / " 拼接（:66 另一分支）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'creator': <String, dynamic>{'nickname': '小明'},
        'ar': <Object?>[
          <String, dynamic>{'id': 1, 'name': '甲'},
          <String, dynamic>{'id': 2, 'name': '乙'},
        ],
      }, 'song')!;
      expect(item.artist, '甲 / 乙');
    });
  });

  // -------------------------------------------------------------------------
  // R7 creatorID / albumID / album（Qt/src/MusicData.cpp:68-71）
  // -------------------------------------------------------------------------
  group('R7 creatorID / albumID / album（Qt/src/MusicData.cpp:54-71）', () {
    test('creator.userId 走 identifier（:68）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'creator': <String, dynamic>{'userId': 88},
      }, 'song')!;
      expect(item.creatorId, '88');
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
        }, 'song')!
            .creatorId,
        '',
      );
    });

    test('al 优先于 album（:55）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'al': <String, dynamic>{'id': 11, 'name': '专辑甲'},
        'album': <String, dynamic>{'id': 22, 'name': '专辑乙'},
      }, 'song')!;
      expect(item.albumId, '11');
      expect(item.album, '专辑甲');
    });

    test('al 不是 Map 时用 album（:55 另一分支）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'al': 'nope',
        'album': <String, dynamic>{'id': 22, 'name': '专辑乙'},
      }, 'song')!;
      expect(item.albumId, '22');
      expect(item.album, '专辑乙');
    });

    test('album.name 非字符串 -> 空串（:70 toString()）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'al': <String, dynamic>{'id': 11, 'name': 5},
      }, 'song')!;
      expect(item.album, '');
      expect(item.albumId, '11');
    });

    test('al 与 album 都缺失 -> 空串（:55 -> 空对象）', () {
      final MusicItem item = MusicData.parse(rawItem(), 'song')!;
      expect(item.albumId, '');
      expect(item.album, '');
    });
  });

  // -------------------------------------------------------------------------
  // R8 cover 三层默认（Qt/src/MusicData.cpp:71）
  // -------------------------------------------------------------------------
  group('R8 cover 三层默认（Qt/src/MusicData.cpp:71）', () {
    test('picUrl 优先（:71 第一层）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'picUrl': 'p',
        'coverImgUrl': 'c',
        'al': <String, dynamic>{'picUrl': 'a'},
      }, 'song')!;
      expect(item.cover, 'p');
    });

    test('picUrl 非字符串 -> coverImgUrl（:71 第二层）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'picUrl': 123,
        'coverImgUrl': 'c',
        'al': <String, dynamic>{'picUrl': 'a'},
      }, 'song')!;
      expect(item.cover, 'c');
    });

    test('前两层都不是字符串 -> 专辑封面（:71 第三层）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'picUrl': null,
        'coverImgUrl': <Object?>[],
        'al': <String, dynamic>{'picUrl': 'a'},
      }, 'song')!;
      expect(item.cover, 'a');
    });

    test('三层都不可用 -> 空串（:71 默认值 ""）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'picUrl': 1,
        'coverImgUrl': false,
        'al': <String, dynamic>{'picUrl': 2},
      }, 'song')!;
      expect(item.cover, '');
    });

    test('album 回退到 raw["album"] 时用它的 picUrl（:55 + :71）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'album': <String, dynamic>{'picUrl': 'from-album'},
      }, 'song')!;
      expect(item.cover, 'from-album');
    });
  });

  // -------------------------------------------------------------------------
  // R9 duration / trackCount（Qt/src/MusicData.cpp:72-73）
  // -------------------------------------------------------------------------
  group('R9 duration / trackCount（Qt/src/MusicData.cpp:72-73）', () {
    test('dt 优先（:72）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'dt': 180000,
        'duration': 5,
      }, 'song')!;
      expect(item.duration, 180000);
    });

    test('dt 缺失时用 duration（:72 默认值链）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'duration': 5,
      }, 'song')!;
      expect(item.duration, 5);
    });

    test('小数保持原值不截断，parse 产物恒为 double（:72 toDouble）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'dt': 180000.5,
      }, 'song')!;
      expect(item.duration, 180000.5);
      expect(item.duration, isA<double>());
      final MusicItem album = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'trackCount': 12,
      }, 'album')!;
      expect(album.trackCount, 12);
      // JSON 整数经 double(qint64) 变 double，与 Qt QJsonValue::toDouble 一致。
      expect(album.trackCount, isA<double>());
    });

    test('字符串数字不转换，落回 0（:72 toDouble 对非数字返回默认值）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'dt': '180000',
        'duration': '5',
      }, 'song')!;
      expect(item.duration, 0);
    });

    test('dt 为 0 视为有效数字，不回退 duration（:72 isDouble）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'dt': 0,
        'duration': 5,
      }, 'song')!;
      expect(item.duration, 0);
    });

    test('trackCount 优先于 size，且同样不做字符串转换（:73）', () {
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
          'trackCount': 12,
          'size': 3,
        }, 'album')!
            .trackCount,
        12,
      );
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
          'size': 3,
        }, 'album')!
            .trackCount,
        3,
      );
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
          'trackCount': '12',
        }, 'album')!
            .trackCount,
        0,
      );
    });
  });

  // -------------------------------------------------------------------------
  // R10 description（Qt/src/MusicData.cpp:74）
  // -------------------------------------------------------------------------
  group('R10 description（Qt/src/MusicData.cpp:74）', () {
    test('description 优先（:74）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'description': '简介',
        'briefDesc': '短简介',
      }, 'song')!;
      expect(item.description, '简介');
    });

    test('description 非字符串 -> briefDesc（:74）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'description': 1,
        'briefDesc': '短简介',
      }, 'song')!;
      expect(item.description, '短简介');
    });

    test('两者都不可用 -> 空串（:74 默认值）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'description': null,
        'briefDesc': <Object?>[],
      }, 'song')!;
      expect(item.description, '');
    });
  });

  // -------------------------------------------------------------------------
  // R11 date（Qt/src/MusicData.cpp:75-78）
  // -------------------------------------------------------------------------
  group('R11 date（Qt/src/MusicData.cpp:75-78）', () {
    test('publishTime = 0 -> 空串（:75 toDouble() > 0）', () {
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
          'publishTime': 0,
        }, 'song')!
            .date,
        '',
      );
    });

    test('publishTime 为负数 -> 空串（:75 > 0）', () {
      expect(
        MusicData.parse(<String, dynamic>{
          'id': '1',
          'name': 'A',
          'publishTime': -1000,
        }, 'song')!
            .date,
        '',
      );
    });

    test('publishTime 非数字 -> 空串（:75 toDouble 得 0）', () {
      for (final Object? value in <Object?>['1700000000000', null, true, <Object?>[]]) {
        expect(
          MusicData.parse(<String, dynamic>{
            'id': '1',
            'name': 'A',
            'publishTime': value,
          }, 'song')!
              .date,
          '',
          reason: 'publishTime=' + value.runtimeType.toString(),
        );
      }
    });

    test('合法毫秒 -> 本地时区 yyyy-MM-dd（:76-77）', () {
      final int milliseconds = DateTime(2021, 3, 4, 12, 30).millisecondsSinceEpoch;
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'publishTime': milliseconds,
      }, 'song')!;
      expect(item.date, '2021-03-04');
      expect(item.date, expectedDate(DateTime.fromMillisecondsSinceEpoch(milliseconds)));
    });

    test('月/日零填充（:77 yyyy-MM-dd）', () {
      final int milliseconds = DateTime(2020, 1, 5, 8).millisecondsSinceEpoch;
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'publishTime': milliseconds,
      }, 'song')!;
      expect(item.date, '2020-01-05');
      expect(item.date, matches(RegExp(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$')));
    });

    test('小数 publishTime 过门但 toInteger 得 0 -> epoch 当天（:75-77）', () {
      // 1700000000123.7 不是整数，convertDoubleTo<qint64> 失败，toInteger() 回默认 0；
      // 门槛 toDouble() > 0 仍然为真，所以写 date，但日期是 epoch(0) 的本地日期。
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'publishTime': 1700000000123.7,
      }, 'song')!;
      expect(item.date, expectedDate(DateTime.fromMillisecondsSinceEpoch(0)));
      expect(
        item.date,
        isNot(expectedDate(DateTime.fromMillisecondsSinceEpoch(1700000000123))),
      );
    });

    test('整数值的 double publishTime 正常取整（:77 toInteger 成功分支）', () {
      final int milliseconds = 1700000000123;
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'publishTime': 1700000000123.0,
      }, 'song')!;
      expect(item.date, expectedDate(DateTime.fromMillisecondsSinceEpoch(milliseconds)));
    });

    test('超出 qint64 的 publishTime 同样得 0 -> epoch 当天（qnumeric_p.h:277-284）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'publishTime': 1e300,
      }, 'song')!;
      expect(item.date, expectedDate(DateTime.fromMillisecondsSinceEpoch(0)));
    });
  });

  // -------------------------------------------------------------------------
  // R12 wiki（Qt/src/MusicData.cpp:33, :67-78）
  // -------------------------------------------------------------------------
  group('R12 wiki 在 parse 中不赋值（Qt/src/MusicData.cpp:33, :67-78）', () {
    test('即使 raw 里带 wiki 也保持空串（parse 不写该键）', () {
      final MusicItem item = MusicData.parse(<String, dynamic>{
        'id': '1',
        'name': 'A',
        'wiki': '来自 raw 的百科',
      }, 'song')!;
      expect(item.wiki, '');
      expect(item.toJson()['wiki'], '');
    });

    test('没有 wiki 键时也是空串', () {
      expect(MusicData.parse(rawItem(), 'song')!.wiki, '');
    });
  });

  // -------------------------------------------------------------------------
  // R13 unique（Qt/src/MusicData.cpp:82-96）
  // -------------------------------------------------------------------------
  group('R13 unique（Qt/src/MusicData.cpp:82-96）', () {
    test('existing 原序在前，values 新 key 按序追加（:87-93）', () {
      final List<MusicItem> existing = <MusicItem>[song('1'), song('2')];
      final List<MusicItem> values = <MusicItem>[song('2'), song('3'), song('1'), song('4')];
      final List<MusicItem> result = MusicData.unique(existing, values);
      expect(result.map((MusicItem value) => value.id).toList(), <String>['1', '2', '3', '4']);
    });

    test('values 内部重复只保留第一个（:90-92 keys.insert 后跳过）', () {
      final List<MusicItem> result = MusicData.unique(<MusicItem>[], <MusicItem>[
        song('1', title: '第一次'),
        song('1', title: '第二次'),
      ]);
      expect(result.length, 1);
      expect(result.single.title, '第一次');
    });

    test('existing 内部的重复项全部保留（:87 auto result = existing）', () {
      final List<MusicItem> result = MusicData.unique(
        <MusicItem>[song('1', title: 'A'), song('1', title: 'B')],
        <MusicItem>[song('1', title: 'C')],
      );
      expect(result.length, 2);
      expect(result.map((MusicItem value) => value.title).toList(), <String>['A', 'B']);
    });

    test('同 id 不同 provider 是不同 key，都保留（:38, :89）', () {
      final List<MusicItem> result = MusicData.unique(
        <MusicItem>[const MusicItem(kind: 'song', id: '1', provider: 'netease')],
        <MusicItem>[const MusicItem(kind: 'song', id: '1', provider: 'qq')],
      );
      expect(result.length, 2);
    });

    test('退化 key 视为同一个键（:89 toString -> 同一字符串）', () {
      // MusicItem.key 恒为 provider:kind:id，三项全空时退化成 "::"，
      // 与 Qt 里 key 字段缺失 -> toString() 得空串同属"同一个键"的场景。
      const MusicItem first = MusicItem(kind: '', id: '', provider: '', title: 'A');
      const MusicItem second = MusicItem(kind: '', id: '', provider: '', title: 'B');
      expect(first.key, second.key);
      final List<MusicItem> result = MusicData.unique(<MusicItem>[], <MusicItem>[first, second]);
      expect(result.length, 1);
      expect(result.single.title, 'A');
    });

    test('空输入返回空列表（:87-95）', () {
      expect(MusicData.unique(<MusicItem>[], <MusicItem>[]), isEmpty);
    });
  });

  // -------------------------------------------------------------------------
  // R14 ordered（Qt/src/MusicData.cpp:98-114）
  // -------------------------------------------------------------------------
  group('R14 ordered（Qt/src/MusicData.cpp:98-114）', () {
    final List<MusicItem> songs = <MusicItem>[
      song('1', title: 'one'),
      song('2', title: 'two'),
      song('1', title: 'one-dup'),
    ];

    test('按 ids 顺序输出（:107-112）', () {
      final List<MusicItem> result = MusicData.ordered(<Object?>['2', '1'], songs);
      expect(result.map((MusicItem value) => value.title).toList(), <String>['two', 'one']);
    });

    test('重复 id 只保留 songs 里的首现（:103-105 !contains 才插入）', () {
      final List<MusicItem> result = MusicData.ordered(<Object?>['1'], songs);
      expect(result.single.title, 'one');
    });

    test('ids 里重复同一 id 会重复输出同一曲目（:107-112 不去重）', () {
      final List<MusicItem> result = MusicData.ordered(<Object?>['2', '2'], songs);
      expect(result.length, 2);
      expect(result.map((MusicItem value) => value.title).toList(), <String>['two', 'two']);
    });

    test('ids 里查不到的跳过（:109 contains 判定）', () {
      final List<MusicItem> result = MusicData.ordered(<Object?>['9', '2', '8'], songs);
      expect(result.map((MusicItem value) => value.title).toList(), <String>['two']);
    });

    test('ids 元素是数字时按 toString() 变空串，查不到字符串 id（:109）', () {
      expect(MusicData.ordered(<Object?>[1, 2], songs), isEmpty);
    });

    test('ids 元素为 null / bool 同样变空串（:109）', () {
      expect(MusicData.ordered(<Object?>[null, true], songs), isEmpty);
    });

    test('曲目 id 为空串时，数字 id 反而能命中（toString 得空串，:102/:109）', () {
      final List<MusicItem> withEmpty = <MusicItem>[song('', title: 'empty-id')];
      final List<MusicItem> result = MusicData.ordered(<Object?>[1], withEmpty);
      expect(result.single.title, 'empty-id');
    });

    test('空 ids 或空 songs 都返回空列表（:107-113）', () {
      expect(MusicData.ordered(<Object?>[], songs), isEmpty);
      expect(MusicData.ordered(<Object?>['1'], <MusicItem>[]), isEmpty);
    });
  });

  // -------------------------------------------------------------------------
  // R15 slice（Qt/src/MusicData.cpp:116-123）
  // -------------------------------------------------------------------------
  group('R15 slice（Qt/src/MusicData.cpp:116-123）', () {
    final List<int> values = <int>[0, 1, 2, 3, 4];

    test('常规区间（:118-121）', () {
      expect(MusicData.slice(values, 1, 2), <int>[1, 2]);
      expect(MusicData.slice(values, 0, 5), <int>[0, 1, 2, 3, 4]);
    });

    test('count 超界时截到末尾（:118 std::min(values.size(), start + count)）', () {
      expect(MusicData.slice(values, 3, 10), <int>[3, 4]);
      expect(MusicData.slice(values, 5, 2), isEmpty);
      expect(MusicData.slice(values, 9, 2), isEmpty);
    });

    test('count <= 0 得空列表（:118-119）', () {
      expect(MusicData.slice(values, 0, 0), isEmpty);
      expect(MusicData.slice(values, 2, -1), isEmpty);
    });

    test('start 为负且 start+count <= 0 -> 空（end 用未抬正的 start 计算，:118-119）', () {
      expect(MusicData.slice(values, -2, 1), isEmpty);
      expect(MusicData.slice(values, -9, 3), isEmpty);
    });

    test('start 为负但 start+count > 0 -> 取前 start+count 个（:118-119）', () {
      // end = min(5, -2 + 4) = 2，循环从 max(0, -2) = 0 开始 -> [0, 1]
      expect(MusicData.slice(values, -2, 4), <int>[0, 1]);
      expect(MusicData.slice(values, -1, 2), <int>[0]);
    });

    test('不修改原列表（:117 auto result，拷贝语义）', () {
      final List<int> source = <int>[0, 1, 2, 3, 4];
      MusicData.slice(source, 1, 2);
      expect(source, <int>[0, 1, 2, 3, 4]);
    });

    test('泛型对 String 与对象同样成立', () {
      expect(MusicData.slice<String>(<String>['a', 'b', 'c'], 1, 5), <String>['b', 'c']);
      final List<MusicItem> items = <MusicItem>[song('1'), song('2')];
      expect(MusicData.slice<MusicItem>(items, 1, 1).single.id, '2');
    });
  });

  // -------------------------------------------------------------------------
  // R16 indexOf / indexOfId（Qt/src/MusicData.cpp:125-141）
  // -------------------------------------------------------------------------
  group('R16 indexOf / indexOfId（Qt/src/MusicData.cpp:125-141）', () {
    final List<Object?> values = <Object?>[
      1,
      '1',
      true,
      null,
      1.0,
      <Object?>['a'],
      <String, dynamic>{'a': 1},
    ];

    test('数字与数字按数值比较（:127 QJsonValue::operator==）', () {
      expect(MusicData.indexOf(values, 1), 0);
      expect(MusicData.indexOf(values, 1.0), 0);
      expect(MusicData.indexOf(<Object?>[2, 3], 3), 1);
    });

    test('字符串只与字符串相等（:127 类型敏感）', () {
      expect(MusicData.indexOf(values, '1'), 1);
      expect(MusicData.indexOf(<Object?>['1'], 1), -1);
      expect(MusicData.indexOf(<Object?>[1], '1'), -1);
    });

    test('bool 与数字不互相相等（:127）', () {
      expect(MusicData.indexOf(values, true), 2);
      expect(MusicData.indexOf(<Object?>[1], true), -1);
      expect(MusicData.indexOf(<Object?>[true], 1), -1);
      expect(MusicData.indexOf(values, false), -1);
    });

    test('null 与 null 相等，且不等于空串（:127 Null/Undefined 相等）', () {
      expect(MusicData.indexOf(values, null), 3);
      expect(MusicData.indexOf(<Object?>[''], null), -1);
      expect(MusicData.indexOf(<Object?>[null], ''), -1);
    });

    test('数组与对象按内容深比较（:127）', () {
      expect(MusicData.indexOf(values, <Object?>['a']), 5);
      expect(MusicData.indexOf(values, <String, dynamic>{'a': 1}), 6);
      expect(MusicData.indexOf(values, <String, dynamic>{'a': 2}), -1);
      expect(MusicData.indexOf(values, <Object?>['a', 'b']), -1);
    });

    test('找不到返回 -1，空列表返回 -1（:131）', () {
      expect(MusicData.indexOf(values, '不存在'), -1);
      expect(MusicData.indexOf(<Object?>[], 1), -1);
    });

    test('indexOfId 用 ["id"].toString()：字符串 id 命中（:136）', () {
      final List<Object?> entries = <Object?>[
        <String, dynamic>{'id': '7'},
        <String, dynamic>{'id': '8'},
      ];
      expect(MusicData.indexOfId(entries, '7'), 0);
      expect(MusicData.indexOfId(entries, '8'), 1);
      expect(MusicData.indexOfId(entries, '9'), -1);
    });

    test('indexOfId 不做 identifier：数字 id 变空串，只有 id == "" 命中（:136）', () {
      final List<Object?> entries = <Object?>[
        <String, dynamic>{'id': 7},
        <String, dynamic>{'id': '8'},
      ];
      expect(MusicData.indexOfId(entries, '7'), -1);
      expect(MusicData.indexOfId(entries, ''), 0);
    });

    test('indexOfId 跳过非 Map 元素（:136 toObject -> 空对象）', () {
      final List<Object?> entries = <Object?>[
        'x',
        null,
        <String, dynamic>{'id': ''},
      ];
      expect(MusicData.indexOfId(entries, ''), 0);
      expect(MusicData.indexOfId(<Object?>[], '1'), -1);
    });

    test('indexOfId 是精确匹配，不做前缀或大小写归一（:136 ==）', () {
      final List<Object?> entries = <Object?>[
        <String, dynamic>{'id': 'ABC'},
      ];
      expect(MusicData.indexOfId(entries, 'ABC'), 0);
      expect(MusicData.indexOfId(entries, 'abc'), -1);
      expect(MusicData.indexOfId(entries, 'AB'), -1);
    });
  });

  // -------------------------------------------------------------------------
  // R17 cursor（Qt/src/MusicData.cpp:143-146）
  // -------------------------------------------------------------------------
  group('R17 cursor（Qt/src/MusicData.cpp:143-146）', () {
    test('songs 为空 -> 返回 songs.size() 即 0（:144-145）', () {
      expect(MusicData.cursor(<MusicItem>[], <Object?>['1']), 0);
      expect(MusicData.cursor(<MusicItem>[], <Object?>[]), 0);
    });

    test('命中 -> 下标 + 1（:144-145）', () {
      final List<MusicItem> songs = <MusicItem>[song('1'), song('2')];
      expect(MusicData.cursor(songs, <Object?>['2', '1']), 1);
      expect(MusicData.cursor(songs, <Object?>['1', '2']), 2);
      expect(MusicData.cursor(songs, <Object?>['9', '2', '1']), 2);
    });

    test('ids 里是数字 123 而歌曲 id 是字符串 "123" -> 类型敏感找不到 -> songs.length（:144）', () {
      final List<MusicItem> songs = <MusicItem>[song('123')];
      expect(MusicData.cursor(songs, <Object?>[123]), 1);
      expect(MusicData.cursor(songs, <Object?>['123']), 1);
    });

    test('找不到 -> 返回 songs.length（:145 index < 0）', () {
      final List<MusicItem> songs = <MusicItem>[song('1'), song('2'), song('3')];
      expect(MusicData.cursor(songs, <Object?>['9']), 3);
      expect(MusicData.cursor(songs, <Object?>[]), 3);
      expect(MusicData.cursor(songs, <Object?>[null]), 3);
    });

    test('歌曲 id 为空串且 ids 里有 null/数字（toString 得空串）-> 命中（:144）', () {
      final List<MusicItem> songs = <MusicItem>[song('')];
      expect(MusicData.cursor(songs, <Object?>[null]), 1);
      expect(MusicData.cursor(songs, <Object?>[0]), 1);
    });
  });

  // -------------------------------------------------------------------------
  // R18 pad（Qt/src/MusicData.cpp:148-150）
  // -------------------------------------------------------------------------
  group('R18 pad（Qt/src/MusicData.cpp:148-150）', () {
    test('默认 width = 2（:148）', () {
      expect(MusicData.pad(5), '05');
      expect(MusicData.pad(0), '00');
      expect(MusicData.pad(12), '12');
    });

    test('长度已足够时原样返回（:149 rightJustified）', () {
      expect(MusicData.pad(100, 2), '100');
      expect(MusicData.pad(1234, 4), '1234');
      expect(MusicData.pad(5, 0), '5');
      expect(MusicData.pad(5, -3), '5');
    });

    test('在最左补 0（:149 rightJustified 从左侧填充）', () {
      expect(MusicData.pad(7, 3), '007');
      expect(MusicData.pad(0, 3), '000');
    });

    test('负数的负号被推到右侧：pad(-5, 3) == "0-5"（:149 左填充的字面结果）', () {
      expect(MusicData.pad(-5, 3), '0-5');
      expect(MusicData.pad(-1, 3), '0-1');
      expect(MusicData.pad(-1, 4), '00-1');
      // width 等于 "-1" 的长度时不再补。
      expect(MusicData.pad(-1), '-1');
      expect(MusicData.pad(-1, 5), '000-1');
    });

    test('多位数字只有一个前导 0 的边界', () {
      expect(MusicData.pad(9), '09');
      expect(MusicData.pad(10), '10');
    });
  });

  // -------------------------------------------------------------------------
  // R19 time（Qt/src/MusicData.cpp:152-158）
  // -------------------------------------------------------------------------
  group('R19 time（Qt/src/MusicData.cpp:152-158）', () {
    test('duration <= 0 -> 暂无（:154-156）', () {
      expect(MusicData.time(0), '暂无');
      expect(MusicData.time(-1), '暂无');
      expect(MusicData.time(-99999), '暂无');
      expect(MusicData.time(0.0), '暂无');
    });

    test('整分钟与不足一秒（:157）', () {
      expect(MusicData.time(60000), '1:00');
      expect(MusicData.time(1000), '0:01');
      expect(MusicData.time(999), '0:00');
      expect(MusicData.time(61000), '1:01');
    });

    test('59999 -> 0:59（秒向下截断，:157）', () {
      expect(MusicData.time(59999), '0:59');
      expect(MusicData.time(59999.9), '0:59');
    });

    test('239999 -> 3:59（分钟独立截断，:157）', () {
      expect(MusicData.time(239999), '3:59');
    });

    test('3599999 -> 59:59（不是先算总秒，:157 两次独立除法）', () {
      expect(MusicData.time(3599999), '59:59');
    });

    test('超过一小时按分钟累计并两位补零（:157 pad(int(duration / 60000))）', () {
      expect(MusicData.time(3600000), '60:00');
      expect(MusicData.time(600000), '10:00');
      expect(MusicData.time(3599999 + 1), '60:00');
    });

    test('分钟数超过两位时不再补零（:149 width 已足够）', () {
      expect(MusicData.time(6000000), '100:00');
    });
  });

  // -------------------------------------------------------------------------
  // R20 sortOrder（Qt/src/MusicData.cpp:161-184）
  // -------------------------------------------------------------------------
  group('R20 sortOrder（Qt/src/MusicData.cpp:161-184）', () {
    test('非法 field 返回恒等排列（:167-169）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'c'),
        song('2', title: 'a'),
      ];
      expect(MusicData.sortOrder(values, 'none'), <int>[0, 1]);
      expect(MusicData.sortOrder(values, 'duration'), <int>[0, 1]);
      expect(MusicData.sortOrder(values, ''), <int>[0, 1]);
      expect(MusicData.sortOrder(values, 'Title'), <int>[0, 1]);
    });

    test('按 title 升序（:174-181）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'c'),
        song('2', title: 'a'),
        song('3', title: 'b'),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 2, 0]);
    });

    test('空名称排在最后（:178-180 isEmpty 分支）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: ''),
        song('2', title: 'a'),
        song('3', title: ''),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 0, 2]);
    });

    test('纯空白 trim 后算空名称，也排最后（:175 trimmed）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: '   '),
        song('2', title: 'a'),
        song('3', title: '  b  '),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 2, 0]);
    });

    test('相同名称保持原下标顺序（:177 std::stable_sort）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'b'),
        song('2', title: 'a'),
        song('3', title: 'b'),
        song('4', title: 'a'),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 3, 0, 2]);
    });

    test('全部同名时顺序不变（:178-181 collator.compare == 0）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'x'),
        song('2', title: 'x'),
        song('3', title: 'x'),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[0, 1, 2]);
    });

    test('默认比较器大小写不敏感（:171 CaseInsensitive）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'banana'),
        song('2', title: 'Apple'),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 0]);
    });

    test('默认比较器数字段按数值（:172 NumericMode）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'track 10'),
        song('2', title: 'track 2'),
      ];
      expect(MusicData.sortOrder(values, 'title'), <int>[1, 0]);
    });

    test('album 与 artist 字段同样支持（:167 白名单）', () {
      final List<MusicItem> byAlbum = <MusicItem>[
        song('1', album: 'B'),
        song('2', album: 'A'),
      ];
      expect(MusicData.sortOrder(byAlbum, 'album'), <int>[1, 0]);
      final List<MusicItem> byArtist = <MusicItem>[
        song('1', artist: '乙'),
        song('2', artist: '甲'),
      ];
      expect(MusicData.sortOrder(byArtist, 'artist').length, 2);
    });

    test('注入 compare 完全取代默认比较器（:181 collator.compare）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'a'),
        song('2', title: 'c'),
        song('3', title: 'b'),
      ];
      final List<int> result = MusicData.sortOrder(
        values,
        'title',
        compare: (String a, String b) => b.compareTo(a),
      );
      expect(result, <int>[1, 2, 0]);
    });

    test('注入 compare 返回 0 时保持原序（稳定 + 空名规则）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'z'),
        song('2', title: ''),
        song('3', title: 'a'),
      ];
      final List<int> result = MusicData.sortOrder(
        values,
        'title',
        compare: (String a, String b) => 0,
      );
      // 非空的 0、2 保持原序，空名 1 排最后。
      expect(result, <int>[0, 2, 1]);
    });

    test('空列表与单元素（:163-169）', () {
      expect(MusicData.sortOrder(<MusicItem>[], 'title'), isEmpty);
      expect(MusicData.sortOrder(<MusicItem>[song('1')], 'title'), <int>[0]);
    });

    test('不修改入参列表顺序（:164-176 只操作索引）', () {
      final List<MusicItem> values = <MusicItem>[
        song('1', title: 'c'),
        song('2', title: 'a'),
      ];
      MusicData.sortOrder(values, 'title');
      expect(values.map((MusicItem value) => value.id).toList(), <String>['1', '2']);
    });
  });
}
