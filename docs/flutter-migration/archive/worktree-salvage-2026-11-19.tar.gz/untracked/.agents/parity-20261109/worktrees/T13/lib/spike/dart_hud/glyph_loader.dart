// Dart mirror of the glyph pipeline in Qt/src/Glyphs.cpp for the T13 HUD spike.
//
// Scope: the per-glyph path that every HUD string in the slice uses. Qt hands a
// string to QTextLayout when Glyphs::needsLayout() is true (Qt/src/Glyphs.cpp
// 108-139); that branch is NOT ported here and is reported through
// [GlyphAtlas.shapedTextCount] so a device gate fails honestly instead of
// silently drawing wrong glyphs.
//
// Source of truth, Qt tree at baseline 8ed3067b0812eb2612f7841ec127a6e8ca93231b:
//   Qt/src/Glyphs.cpp:28-34    resource load helper
//   Qt/src/Glyphs.cpp:35-49    color(): calibrated gamma 1.8 -> sRGB
//   Qt/src/Glyphs.cpp:65-90    weights, glyph table, lettering parse
//   Qt/src/Glyphs.cpp:108-139  needsLayout()
//   Qt/src/Glyphs.cpp:190-265  SVG path subset (M/L/H/V/C/Q/Z, WindingFill)
//   Qt/src/Glyphs.cpp:266-285  glyph(): weight font -> symbols font -> {}
//   Qt/src/Glyphs.cpp:286-311  width()
//   Qt/src/Glyphs.cpp:312-338  bounds()
//   Qt/src/Glyphs.cpp:339-349  inset()
//   Qt/src/Glyphs.cpp:403-412  artWidth()
//   Qt/src/Glyphs.cpp:530-563  text(): baseline y + size * 1.044, y flip
//   Qt/src/Glyphs.cpp:565-588  art(): no 1.044 baseline, positive y scale
//   Qt/src/Glyphs.h:21-24      struct Glyph { double advance = 1; ... }
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/services.dart' show AssetBundle;

/// Port for the glyph sources Qt consults after the JSON table misses.
///
/// Qt resolves a character in three steps (Qt/src/Glyphs.cpp:266-285):
///   1. the pre-baked misans-glyphs.json entry for the requested weight;
///   2. fonts[weight].glyphIndexesForString(ch), i.e. the real OTF outlines;
///   3. fonts["symbols"], i.e. NotoSansSymbols2-Regular.ttf;
///   4. otherwise it returns an empty Glyph, i.e. advance 1 and no contour.
///
/// Step 1 is fully data-driven and lives in this file. Steps 2-3 need
/// QRawFont::pathForGlyph, which has no Flutter equivalent: the engine can
/// rasterise a bundled font but cannot hand back glyph outlines. This port is
/// therefore the injection point for those two steps. A host that installs no
/// port gets step 4 verbatim, and [GlyphAtlas.missingGlyphCount] /
/// [GlyphAtlas.symbolFallbackCount] tell it how many characters that costs.
abstract class GlyphFallbackSource {
  /// Outline for [ch] in em units (y-up, 1000 units per em), or null when this
  /// source has no glyph for it.
  GlyphShape? glyphFor(String ch);
}

/// One contour entry from Assets/fonts/misans-glyphs.json.
///
/// Coordinates stay in the 1000-unit em space of the resource (y-up, baseline
/// at zero), exactly like the JSON. Scaling and the y flip happen per draw so
/// [GlyphShape.path] can be shared between strings of different sizes.
class GlyphShape {
  const GlyphShape({
    required this.advance,
    required this.path,
    required this.hasContour,
  });

  /// Advance width as a fraction of the em (JSON advance, e.g. 0.639).
  final double advance;

  /// Contour in 1000-unit em space, y-up.
  final ui.Path path;

  /// Mirrors QPainterPath::isEmpty(), which bounds()/inset() use to skip a
  /// glyph (Qt/src/Glyphs.cpp:327, 348).
  final bool hasContour;

  /// Qt returns an empty Glyph for a character no font can resolve; struct
  /// Glyph in Qt/src/Glyphs.h:21-24 defaults advance to 1 with no contour.
  static GlyphShape empty() =>
      GlyphShape(advance: 1, path: ui.Path(), hasContour: false);
}

/// Glyph metrics and drawing for the HUD, loaded from the same resources the
/// Qt build ships.
class GlyphAtlas {
  GlyphAtlas._({
    required Map<String, Map<String, GlyphShape>> glyphs,
    required Map<String, List<GlyphShape>> lettering,
    required this.artText,
    required this.resourceUnitsPerEm,
    required this.resourceAscent,
    required this.resourceDescent,
    GlyphFallbackSource? fallback,
  })  : _glyphs = glyphs,
        _lettering = lettering,
        _fallback = fallback;

  /// Builds an atlas from already decoded JSON maps.
  ///
  /// Mirrors the constructor loop at Qt/src/Glyphs.cpp:65-90: four weights in
  /// the fixed order below, the per-weight glyphs object, then every lettering
  /// key with its letters array. The per-weight units/ascent/descent header is
  /// parsed as well; Qt reads it only implicitly because the C++ hardcodes
  /// /1000 and *1.044, so this file keeps those two constants as the operative
  /// values and only validates the header through
  /// [resourceMatchesQtContract].
  factory GlyphAtlas.fromMaps({
    required Map<String, dynamic> glyphs,
    required Map<String, dynamic> lettering,
    GlyphFallbackSource? fallback,
  }) {
    final Map<String, Map<String, GlyphShape>> byWeight =
        <String, Map<String, GlyphShape>>{};
    for (final String weight in weights) {
      final Map<String, dynamic> table = _asMap(glyphs[weight]);
      final Map<String, GlyphShape> parsed = <String, GlyphShape>{};
      _asMap(table['glyphs']).forEach((String ch, dynamic value) {
        if (value is! Map) {
          return;
        }
        final Map<String, dynamic> entry = value.cast<String, dynamic>();
        final _ParsedPath parsedPath = _parseSvg(_string(entry['path']));
        parsed[ch] = GlyphShape(
          // Qt: o["advance"].toDouble(), i.e. 0 when the key is absent or not
          // numeric (QJsonValue::toDouble returns 0).
          advance: _toDouble(entry['advance'], 0),
          path: parsedPath.path,
          hasContour: parsedPath.hasContour,
        );
      });
      byWeight[weight] = parsed;
    }

    final Map<String, List<GlyphShape>> art = <String, List<GlyphShape>>{};
    final Map<String, String> artText = <String, String>{};
    lettering.forEach((String key, dynamic value) {
      if (value is! Map) {
        return;
      }
      final Map<String, dynamic> entry = value.cast<String, dynamic>();
      final dynamic letters = entry['letters'];
      if (letters is! List) {
        return;
      }
      artText[key] = _string(entry['text']);
      art[key] = <GlyphShape>[
        for (final dynamic letter in letters)
          if (letter is Map) _letterShape(letter.cast<String, dynamic>()),
      ];
    });

    final Map<String, dynamic> regular = _asMap(glyphs[kDefaultWeight]);
    return GlyphAtlas._(
      glyphs: byWeight,
      lettering: art,
      artText: artText,
      resourceUnitsPerEm: _toInt(regular['units'], kQtUnitsPerEm),
      resourceAscent: _toInt(regular['ascent'], kQtAscent),
      resourceDescent: _toInt(regular['descent'], kQtDescent),
      fallback: fallback,
    );
  }

  /// Builds an atlas from the raw resource strings.
  factory GlyphAtlas.fromJsonStrings({
    required String glyphsJson,
    required String letteringJson,
    GlyphFallbackSource? fallback,
  }) {
    final dynamic glyphs = jsonDecode(glyphsJson);
    final dynamic lettering = jsonDecode(letteringJson);
    return GlyphAtlas.fromMaps(
      glyphs:
          glyphs is Map ? glyphs.cast<String, dynamic>() : <String, dynamic>{},
      lettering: lettering is Map
          ? lettering.cast<String, dynamic>()
          : <String, dynamic>{},
      fallback: fallback,
    );
  }

  /// Loads the two Qt resources through an [AssetBundle].
  ///
  /// Qt reads Assets/fonts/misans-glyphs.json and
  /// Resources/boot-lettering-art.json from the resource root
  /// (Qt/src/Glyphs.cpp:75, 83); the Flutter asset declaration for those two
  /// paths is owned by the shared pubspec owner, not by this spike.
  static Future<GlyphAtlas> load(
    AssetBundle bundle, {
    String glyphsAsset = kGlyphsAsset,
    String letteringAsset = kLetteringAsset,
    GlyphFallbackSource? fallback,
  }) async {
    final String glyphsJson = await bundle.loadString(glyphsAsset);
    final String letteringJson = await bundle.loadString(letteringAsset);
    return GlyphAtlas.fromJsonStrings(
      glyphsJson: glyphsJson,
      letteringJson: letteringJson,
      fallback: fallback,
    );
  }

  /// Resource path of the glyph table (Qt/src/Glyphs.cpp:75).
  static const String kGlyphsAsset = 'Assets/fonts/misans-glyphs.json';

  /// Resource path of the boot lettering art (Qt/src/Glyphs.cpp:83).
  static const String kLetteringAsset = 'Resources/boot-lettering-art.json';

  /// Weights the Qt build loads, in order (Qt/src/Glyphs.cpp:66).
  static const List<String> weights = <String>[
    'light',
    'regular',
    'demibold',
    'bold',
  ];

  /// Weight Qt falls back to when a table or font is missing
  /// (Qt/src/Glyphs.cpp:114, 272: fonts.value(weight, fonts["regular"])).
  static const String kDefaultWeight = 'regular';

  /// Resource units per em; every metric below divides by it. Qt hardcodes
  /// /1000 (Qt/src/Glyphs.cpp:170, 317, 330, 345, 537, 559, 583).
  static const double unitsPerEm = 1000;

  /// Baseline offset Qt applies to per-glyph text drawing. Qt hardcodes
  /// size * 1.044 (Qt/src/Glyphs.cpp:316, 329, 536, 558); 1044/1000 is the
  /// ascent the shipped resource declares for every weight. The lettering art
  /// path deliberately does not use it (Qt/src/Glyphs.cpp:565-588).
  static const double baselineFactor = 1.044;

  /// units the shipped resource declares for all four weights.
  static const int kQtUnitsPerEm = 1000;

  /// ascent the shipped resource declares for all four weights; equals
  /// unitsPerEm * baselineFactor.
  static const int kQtAscent = 1044;

  /// descent the shipped resource declares for all four weights.
  static const int kQtDescent = -282;

  static final RegExp _tokenPattern = RegExp(
      r'[a-zA-Z]|[-+]?(?:[0-9]*\.[0-9]+|[0-9]+\.?[0-9]*)(?:[eE][-+]?[0-9]+)?');

  static final RegExp _letterPattern = RegExp(r'^[a-zA-Z]$');

  final Map<String, Map<String, GlyphShape>> _glyphs;
  final Map<String, List<GlyphShape>> _lettering;
  final Map<String, ui.Path> _pathCache = <String, ui.Path>{};
  final Set<String> _missing = <String>{};
  final Set<String> _symbolResolved = <String>{};
  final Map<String, GlyphShape> _fallbackCache = <String, GlyphShape>{};
  final GlyphFallbackSource? _fallback;
  int _shapedTextCount = 0;

  /// The literal text each lettering key spells, straight from the resource.
  ///
  /// Qt parses text/weight but never reads them; the HUD command stream carries
  /// the string and count comes from a prefix length
  /// (Qt/src/NativeHudBoot.cpp:235). Exposed so the spike can report what the
  /// shipped art actually contains.
  final Map<String, String> artText;

  /// units the loaded resource declares (Qt never reads it; see
  /// [resourceMatchesQtContract]).
  final int resourceUnitsPerEm;

  /// ascent the loaded resource declares.
  final int resourceAscent;

  /// descent the loaded resource declares.
  final int resourceDescent;

  /// True when the resource header agrees with the constants Qt hardcodes.
  ///
  /// Drawing always uses [unitsPerEm] and [baselineFactor] because that is what
  /// Qt does; a false value here means the shipped JSON was regenerated with a
  /// different em square and Qt itself would now render at the wrong scale.
  bool get resourceMatchesQtContract =>
      resourceUnitsPerEm == kQtUnitsPerEm &&
      resourceAscent == kQtAscent &&
      resourceDescent == kQtDescent;

  /// True when a [GlyphFallbackSource] was installed for Qt's font steps.
  bool get hasFallbackSource => _fallback != null;

  /// Number of weight:char lookups that had no entry in the JSON table.
  ///
  /// These are exactly the characters Qt would hand to
  /// QRawFont::glyphIndexesForString (Qt/src/Glyphs.cpp:272-277), so a non-zero
  /// value is the honest measure of how much of the frame depends on the
  /// unported font path.
  int get missingGlyphCount => _missing.length;

  /// Number of distinct characters resolved by [GlyphFallbackSource].
  int get symbolFallbackCount => _symbolResolved.length;

  /// Number of strings that Qt would have handed to QTextLayout.
  ///
  /// The spike does not implement that branch, so callers must treat a non-zero
  /// value as a device/feature gate, never as a passing render.
  int get shapedTextCount => _shapedTextCount;

  /// Glyph for [ch] in [weight], with Qt's three-step resolution order.
  ///
  /// Qt/src/Glyphs.cpp:266-285: JSON entry, then the weight font, then the
  /// symbols font, then an empty Glyph. Steps 2-3 are delegated to
  /// [GlyphFallbackSource]; the outcome is memoised per character.
  GlyphShape glyph(String ch, String weight) {
    final Map<String, GlyphShape>? table =
        _glyphs[weight] ?? _glyphs[kDefaultWeight];
    final GlyphShape? shape = table?[ch];
    if (shape != null) {
      return shape;
    }
    _missing.add(weight + ':' + ch);
    final GlyphShape? cached = _fallbackCache[ch];
    if (cached != null) {
      return cached;
    }
    final GlyphShape? resolved = _fallback?.glyphFor(ch);
    if (resolved != null) {
      _symbolResolved.add(ch);
      _fallbackCache[ch] = resolved;
      return resolved;
    }
    final GlyphShape blank = GlyphShape.empty();
    // Qt does not cache the empty result; caching it here only avoids
    // repeating the same failed lookup for every glyph of every frame.
    _fallbackCache[ch] = blank;
    return blank;
  }

  /// Cached SVG parse; Qt keeps the same 1024-entry cache at
  /// Qt/src/Glyphs.cpp:191-194, 263 (QCache<QString, QPainterPath> paths{1024},
  /// Qt/src/Glyphs.h:52).
  ui.Path pathFor(String svg) {
    final ui.Path? cached = _pathCache[svg];
    if (cached != null) {
      return cached;
    }
    final ui.Path path = parseSvgText(svg);
    if (_pathCache.length >= 1024) {
      _pathCache.clear();
    }
    _pathCache[svg] = path;
    return path;
  }

  /// Mirrors Glyphs::width (Qt/src/Glyphs.cpp:286-311) for the per-glyph
  /// branch: tracking is added between characters, never after the last one,
  /// and the total is clamped at zero.
  double width(String text, double size, String weight, {double tracking = 0}) {
    if (requiresShapedLayout(text)) {
      _shapedTextCount += 1;
    }
    double result = 0;
    for (int i = 0; i < text.length; i += 1) {
      final GlyphShape shape = glyph(_codeUnit(text, i), weight);
      result += shape.advance * size + tracking;
    }
    result -= tracking;
    return result > 0 ? result : 0;
  }

  /// Mirrors Glyphs::bounds (Qt/src/Glyphs.cpp:312-338): each contour is
  /// translated by the pen position and size * 1.044, then flipped, then
  /// united. Advance accumulation ignores tracking, exactly like Qt.
  ui.Rect bounds(String text, double size, String weight) {
    if (requiresShapedLayout(text)) {
      _shapedTextCount += 1;
    }
    ui.Rect? union;
    double x = 0;
    final double scale = size / unitsPerEm;
    for (int i = 0; i < text.length; i += 1) {
      final GlyphShape shape = glyph(_codeUnit(text, i), weight);
      if (shape.hasContour) {
        final ui.Rect rect = _transformedBounds(shape.path, x, size, scale);
        union = union == null ? rect : union.expandToInclude(rect);
      }
      x += shape.advance * size;
    }
    return union ?? ui.Rect.zero;
  }

  /// Mirrors Glyphs::inset (Qt/src/Glyphs.cpp:339-349). Qt reads
  /// text.first(1), i.e. the first UTF-16 code unit.
  double inset(String text, double size, String weight) {
    if (text.isEmpty) {
      return 0;
    }
    if (requiresShapedLayout(text)) {
      _shapedTextCount += 1;
    }
    final GlyphShape shape = glyph(_codeUnit(text, 0), weight);
    if (!shape.hasContour) {
      return 0;
    }
    return shape.path.getBounds().left * size / unitsPerEm;
  }

  /// Mirrors Glyphs::artWidth (Qt/src/Glyphs.cpp:403-412); a negative [count]
  /// means the whole string and an unknown key measures as zero.
  ///
  /// Qt returns visible.isEmpty() ? 0 : result - tracking without clamping, so
  /// the empty-path spacer letters still contribute their advance.
  double artWidth(String key, double size, {double tracking = 0, int count = -1}) {
    final List<GlyphShape>? letters = _lettering[key];
    if (letters == null) {
      return 0;
    }
    final int limit =
        count < 0 ? letters.length : math.min(count, letters.length);
    if (limit <= 0) {
      return 0;
    }
    double result = 0;
    for (int i = 0; i < limit; i += 1) {
      result += letters[i].advance * size + tracking;
    }
    return result - tracking;
  }

  /// Lettering entries for a boot key, or an empty list (Qt returns the same
  /// empty QList for a key that is not in boot-lettering-art.json).
  List<GlyphShape> art(String key) => _lettering[key] ?? const <GlyphShape>[];

  /// Mirrors Glyphs::text (Qt/src/Glyphs.cpp:530-563): every glyph is drawn
  /// with translate(x, y + size * 1.044), scale(size/1000, -size/1000), then
  /// x += advance * size + tracking.
  void drawText(
    ui.Canvas canvas,
    String text,
    double x,
    double y,
    double size,
    String weight,
    ui.Color color, {
    double tracking = 0,
  }) {
    if (requiresShapedLayout(text)) {
      _shapedTextCount += 1;
    }
    final ui.Paint paint = ui.Paint()
      ..style = ui.PaintingStyle.fill
      ..isAntiAlias = true
      ..color = color;
    final double scale = size / unitsPerEm;
    double cursor = x;
    for (int i = 0; i < text.length; i += 1) {
      final GlyphShape shape = glyph(_codeUnit(text, i), weight);
      canvas.save();
      canvas.translate(cursor, y + size * baselineFactor);
      canvas.scale(scale, -scale);
      canvas.drawPath(shape.path, paint);
      canvas.restore();
      cursor += shape.advance * size + tracking;
    }
  }

  /// Mirrors Glyphs::art (Qt/src/Glyphs.cpp:565-588): no 1.044 baseline and a
  /// positive y scale, because the lettering art is authored in screen space.
  void drawArt(
    ui.Canvas canvas,
    String key,
    double x,
    double y,
    double size,
    ui.Color color, {
    int count = -1,
    double tracking = 0,
  }) {
    final List<GlyphShape> letters = art(key);
    if (letters.isEmpty) {
      return;
    }
    final int limit =
        count < 0 ? letters.length : math.min(count, letters.length);
    final ui.Paint paint = ui.Paint()
      ..style = ui.PaintingStyle.fill
      ..isAntiAlias = true
      ..color = color;
    final double scale = size / unitsPerEm;
    double cursor = x;
    for (int i = 0; i < limit; i += 1) {
      final GlyphShape letter = letters[i];
      canvas.save();
      canvas.translate(cursor, y);
      canvas.scale(scale, scale);
      canvas.drawPath(letter.path, paint);
      canvas.restore();
      cursor += letter.advance * size + tracking;
    }
  }

  /// Qt hands a string to QTextLayout when it contains an astral code point, a
  /// combining mark, Hangul jamo, a zero width joiner, a script outside
  /// {Common, Inherited, Latin, Han, Hiragana, Katakana, Hangul}, an RTL/Arabic
  /// direction run, or a character neither font supports
  /// (Qt/src/Glyphs.cpp:108-139).
  ///
  /// This port keeps the script/mark/jamo/joiner/astral/direction rules with
  /// explicit range tables. Font coverage is NOT part of the check: the spike
  /// has no QRawFont, so an uncovered character is reported through
  /// [missingGlyphCount] instead of being promoted to shaped text.
  bool requiresShapedLayout(String text) {
    // Qt reads code points here (text.toUcs4()), unlike the metric loops which
    // walk UTF-16 code units.
    for (final int rune in text.runes) {
      if (rune > 0xffff) {
        return true;
      }
      if (rune == 0x200d) {
        return true;
      }
      if (_isCombiningMark(rune)) {
        return true;
      }
      if (_isHangulJamo(rune)) {
        return true;
      }
      if (_isRightToLeftControl(rune)) {
        return true;
      }
      if (!_isSimpleScript(rune)) {
        return true;
      }
    }
    return false;
  }

  /// Parses the SVG subset Qt accepts (Qt/src/Glyphs.cpp:190-265).
  ///
  /// Supports M/L/H/V/C/Q/Z in absolute and relative form, sets WindingFill
  /// (non-zero), treats a missing coordinate as zero and aborts on any other
  /// command letter while keeping the partial path. All four behaviours are
  /// load-bearing for the shipped glyph resources.
  static ui.Path parseSvgText(String svg) => _parseSvg(svg).path;

  /// Qt color contract (Qt/src/Glyphs.cpp:35-49): a fifth array item starting
  /// with calibrated marks Gamma 1.8 source values that must be converted to
  /// sRGB; everything else is already sRGB.
  static ui.Color colorFromJson(Object? value) {
    final List<dynamic> channels = value is List ? value : const <dynamic>[];
    final bool calibrated = channels.length > 4 &&
        channels[4] is String &&
        (channels[4] as String).startsWith('calibrated');
    double channel(int index) {
      final double raw =
          index < channels.length ? _toDouble(channels[index], 0) : 0;
      if (!calibrated) {
        return raw;
      }
      final double linear = math.pow(raw, 1.8).toDouble();
      return linear <= 0.0031308
          ? 12.92 * linear
          : 1.055 * math.pow(linear, 1 / 2.4).toDouble() - 0.055;
    }

    final double alpha = channels.length > 3 ? _toDouble(channels[3], 1) : 1;
    return ui.Color.from(
      alpha: alpha,
      red: channel(0),
      green: channel(1),
      blue: channel(2),
    );
  }

  /// Qt iterates QString as UTF-16 code units (for (auto ch : text)), so every
  /// metric and draw loop above does the same.
  static String _codeUnit(String text, int index) =>
      String.fromCharCode(text.codeUnitAt(index));

  static GlyphShape _letterShape(Map<String, dynamic> glyph) {
    final _ParsedPath parsedPath = _parseSvg(_string(glyph['path']));
    return GlyphShape(
      // Qt: o["width"].toDouble() (Qt/src/Glyphs.cpp:87).
      advance: _toDouble(glyph['width'], 0),
      path: parsedPath.path,
      hasContour: parsedPath.hasContour,
    );
  }

  static ui.Rect _transformedBounds(
      ui.Path path, double tx, double size, double scale) {
    final Float64List matrix = Float64List.fromList(<double>[
      scale, 0, 0, 0,
      0, -scale, 0, 0,
      0, 0, 1, 0,
      tx, size * baselineFactor, 0, 1,
    ]);
    return path.transform(matrix).getBounds();
  }

  static Map<String, dynamic> _asMap(dynamic value) {
    if (value is! Map) {
      return <String, dynamic>{};
    }
    return value.cast<String, dynamic>();
  }

  static _ParsedPath _parseSvg(String svg) {
    final List<String> tokens = <String>[
      for (final Match match in _tokenPattern.allMatches(svg)) match.group(0)!,
    ];
    final ui.Path path = ui.Path()..fillType = ui.PathFillType.nonZero;
    // QPainterPath::isEmpty() is true when the only element is a MoveTo, so the
    // contour flag counts drawing elements rather than path elements.
    bool hasContour = false;
    bool drawnInSubpath = false;
    bool openSubpath = false;
    int i = 0;
    String command = 'M';
    double px = 0;
    double py = 0;
    double sx = 0;
    double sy = 0;
    double number() {
      if (i >= tokens.length) {
        return 0;
      }
      return double.tryParse(tokens[i++]) ?? 0;
    }

    void drew() {
      hasContour = true;
      drawnInSubpath = true;
    }

    while (i < tokens.length) {
      final String token = tokens[i];
      if (_letterPattern.hasMatch(token)) {
        command = tokens[i++];
        if (command.toUpperCase() == 'Z') {
          // QPainterPath::closeSubpath() does nothing when no subpath is open
          // and adds no element when the subpath never left its start point.
          if (openSubpath) {
            if (drawnInSubpath) {
              path.close();
              hasContour = true;
            }
            drawnInSubpath = false;
            openSubpath = false;
          }
          px = sx;
          py = sy;
          continue;
        }
      }
      final bool relative = command.codeUnitAt(0) >= 0x61;
      final double ox = relative ? px : 0;
      final double oy = relative ? py : 0;
      switch (command.toUpperCase()) {
        case 'M':
          px = number() + ox;
          py = number() + oy;
          path.moveTo(px, py);
          drawnInSubpath = false;
          openSubpath = true;
          sx = px;
          sy = py;
          command = relative ? 'l' : 'L';
          break;
        case 'L':
          px = number() + ox;
          py = number() + oy;
          path.lineTo(px, py);
          drew();
          openSubpath = true;
          break;
        case 'H':
          px = number() + (relative ? px : 0);
          path.lineTo(px, py);
          drew();
          openSubpath = true;
          break;
        case 'V':
          py = number() + (relative ? py : 0);
          path.lineTo(px, py);
          drew();
          openSubpath = true;
          break;
        case 'C':
          final double ax = number() + ox;
          final double ay = number() + oy;
          final double bx = number() + ox;
          final double by = number() + oy;
          final double cx = number() + ox;
          final double cy = number() + oy;
          path.cubicTo(ax, ay, bx, by, cx, cy);
          drew();
          openSubpath = true;
          px = cx;
          py = cy;
          break;
        case 'Q':
          final double ax = number() + ox;
          final double ay = number() + oy;
          final double cx = number() + ox;
          final double cy = number() + oy;
          path.quadraticBezierTo(ax, ay, cx, cy);
          drew();
          openSubpath = true;
          px = cx;
          py = cy;
          break;
        default:
          i = tokens.length;
          break;
      }
    }
    return _ParsedPath(path, hasContour);
  }

  static bool _isCombiningMark(int rune) =>
      (rune >= 0x0300 && rune <= 0x036f) ||
      (rune >= 0x0483 && rune <= 0x0489) ||
      (rune >= 0x0591 && rune <= 0x05bd) ||
      (rune >= 0x0610 && rune <= 0x061a) ||
      (rune >= 0x064b && rune <= 0x065f) ||
      rune == 0x0670 ||
      (rune >= 0x06d6 && rune <= 0x06dc) ||
      (rune >= 0x0900 && rune <= 0x0903) ||
      (rune >= 0x1ab0 && rune <= 0x1aff) ||
      (rune >= 0x1dc0 && rune <= 0x1dff) ||
      (rune >= 0x20d0 && rune <= 0x20ff) ||
      (rune >= 0xfe00 && rune <= 0xfe0f) ||
      (rune >= 0xfe20 && rune <= 0xfe2f) ||
      (rune >= 0xe0100 && rune <= 0xe01ef);

  static bool _isHangulJamo(int rune) =>
      (rune >= 0x1100 && rune <= 0x11ff) ||
      (rune >= 0xa960 && rune <= 0xa97f) ||
      (rune >= 0xd7b0 && rune <= 0xd7ff);

  /// Common/Inherited code points whose bidi class is R or AL
  /// (QChar::DirR / QChar::DirAL at Qt/src/Glyphs.cpp:129). Every RTL letter is
  /// already caught by [_isSimpleScript]; these two marks are the only
  /// Common-script characters with an RTL direction.
  static bool _isRightToLeftControl(int rune) =>
      rune == 0x200f || rune == 0x061c;

  /// Scripts Qt accepts without shaped layout: Common, Inherited, Latin, Han,
  /// Hiragana, Katakana, Hangul. Everything outside these ranges is treated as
  /// a complex script, which is the conservative direction: it can only add
  /// shapedTextCount, never drop a required shaping step.
  static bool _isSimpleScript(int rune) {
    if (rune < 0x0080) {
      return true;
    }
    if (rune >= 0x0080 && rune <= 0x024f) {
      return true;
    }
    if (rune >= 0x1e00 && rune <= 0x1eff) {
      return true;
    }
    if (rune >= 0x2000 && rune <= 0x206f) {
      return true;
    }
    if (rune >= 0x20a0 && rune <= 0x20bf) {
      return true;
    }
    if (rune >= 0x2100 && rune <= 0x21ff) {
      return true;
    }
    if (rune >= 0x2200 && rune <= 0x22ff) {
      return true;
    }
    if (rune >= 0x2500 && rune <= 0x27bf) {
      return true;
    }
    if (rune >= 0x2e80 && rune <= 0x303f) {
      return true;
    }
    if (rune >= 0x3040 && rune <= 0x30ff) {
      return true;
    }
    if (rune >= 0x3130 && rune <= 0x318f) {
      return true;
    }
    if (rune >= 0x31f0 && rune <= 0x31ff) {
      return true;
    }
    if (rune >= 0x3400 && rune <= 0x4dbf) {
      return true;
    }
    if (rune >= 0x4e00 && rune <= 0x9fff) {
      return true;
    }
    if (rune >= 0xac00 && rune <= 0xd7a3) {
      return true;
    }
    if (rune >= 0xf900 && rune <= 0xfaff) {
      return true;
    }
    if (rune >= 0xff00 && rune <= 0xffef) {
      return true;
    }
    return false;
  }

  static String _string(Object? value) => value is String ? value : '';

  static int _toInt(Object? value, int fallback) {
    if (value is num) {
      return value.toInt();
    }
    if (value is String) {
      return int.tryParse(value) ?? fallback;
    }
    return fallback;
  }

  static double _toDouble(dynamic value, double fallback) {
    if (value is num) {
      return value.toDouble();
    }
    if (value is String) {
      return double.tryParse(value) ?? fallback;
    }
    return fallback;
  }
}

class _ParsedPath {
  const _ParsedPath(this.path, this.hasContour);

  final ui.Path path;

  /// Mirrors !QPainterPath::isEmpty() for the parsed path.
  final bool hasContour;
}
