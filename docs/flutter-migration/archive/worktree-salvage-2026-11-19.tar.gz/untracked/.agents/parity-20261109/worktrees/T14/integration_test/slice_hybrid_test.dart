// =============================================================================
// T14 候选 D（混合切片）同切片静态规格测试 · integration_test/slice_hybrid_test.dart
// =============================================================================
//
// 【执行状态：只写不跑 · 未执行（RED/GREEN 未执行）】
//   本文件从未运行：flutter test / dart test / flutter analyze / flutter build /
//   pub get / formatter / 代码生成 / Gradle / adb / 设备截图 / 性能与协议发布验证
//   一律**未执行**。本次 T14 派单的用户禁令禁止执行构建、测试、分析、设备与发布命令，
//   测试只允许写盘。本文件不得被引用为"已通过"的证据。
//
// 【import 面：只用 package:flutter_test】
//   pubspec.yaml:38-40 的 dev_dependencies 只有 flutter_test（flutter sdk），没有
//   integration_test 依赖；pubspec.yaml 不在本原子写域（不可改）。所以本文件虽放在
//   integration_test/ 目录下，却**只** import package:flutter_test，不 import
//   integration_test、不依赖 test runner 的设备侧能力。
//
// 【被测对象与 API 面：以 T14-C18-CONTRACT.json 的 frozenDartApi 为唯一准绳】
//   唯一被测文件 = lib/spike/hybrid/hybrid_host.dart（A1 的当前内容，可直接读）。
//     HybridTexturePort       : int get generation / attach(HybridSurfaceGeometry geometry)
//                               / resize(double,double) / rotate(double) / detach()
//                               —— **没有 advance()**：宿主从不反向推进 Qt 代次
//                               （CONTRACT.frozenDartApi.texturePortChange）
//     HybridHudCommandPainter : paint(List<Object?> commands, HybridStage stage)
//     HybridHost              : HybridHost({required texture, required hud,
//                               HybridSceneClock? clock, double devicePixelRatio = 1.0})
//                               apply(Map<String,Object?>) → HybridApplyResult
//                               / stage / attached / rotationRadians / hits / frame
//                               / state / gate / doubleWriteDetected
//     HybridFrameEnvelope     : decode(Map<String,Object?>) / tryDecode；成员
//                               generation(int) frame(Map) commands(List) hits(List)
//                               state(Map)，全有或全无
//     HybridHit               : static List<HybridHit> decode(List<Object?>) —— **批式**，
//                               不是单条返回可空；字段 x/y/width/height/action/label/fixed
//                               + toJson()
//     HybridStage             : fromLogicalSize(double,double) → scale/width/height；
//                               static engineHudWidth(double,double)
//     HybridColor             : decode(Object?) / hybridSrgbEncode / hybridCalibratedChannel
//                               / kHybridCalibratedGamma / kHybridTouchPadding
//     HybridApplyResult       : applied/generation/reason/commandCount/hitCount/hudPainted
//                               —— **没有** doubleWriteDetected 字段；双写 Fail 证据读
//                               host.doubleWriteDetected（A1 的粘性 getter；核对快照 763 行版本
//                               hybrid_host.dart:578）
//
// 【两条已知不可达 / 不在范围的边界（写在这里，避免被当成"已覆盖"）】
//   1. identical(已发布 commands 外层 List, painter.lastCommands) 不可达：frozen 入口是
//      apply(Map<String,Object?>)，而 HybridFrameEnvelope.decode 内部经 _requireList →
//      List<Object?>.from(value)（核对快照 763 行版本 hybrid_host.dart:759，_requireList 定义 :751-760）对 commands 做
//      **外层浅拷贝**，测试无法持有那份外层 List 实例。
//      **Lead 裁决（T14-C18 m00138）：接受替代形式、不为此改 A1**（增入口或删这层防御性
//      浅拷贝收益低、改动面大）。采纳形式三条，缺一不可：
//      (a) painted.length == source.length；
//      (b) 逐条 identical(painted[i], source[i]) —— 元素实例共享，不拷贝/不重建/不改写；
//      (c) identical(host.stage, painter.lastStage)。
//      另：Lead 明确否决「跨帧外层 List 不得 identical」这条断言（属分配细节而非契约，
//      合法实现可跨帧复用同一不可变列表），故本文件不写该断言。
//   2. 真实 3D（GLB/材质/相机/BVH 拾取/灯光/雾/动画时间）的真实性**不在本文件验证范围**：
//      属 T16 ARCH_BLOCKED（同 slice 五候选真实裁决未测）与设备 DEVICE_BLOCKED。
//      本文件对这条只断言结构事实（第 [12] 条），不得被引用为真实 3D 已通过。
//
// 【本文件按契约写死期望，不迁就现状】
//   第 [3] 条断言 CONTRACT.stageFormula.degenerateExpected（与 Overlay.qml:22 的 ": 1" 回落
//   同式）。**A1 若仍含前置夹取（max(1.0,…)），本树该条为预期 RED —— 属 A1 未关项，
//   不得改断言**（Lead m00138）。核对快照（763 行版本 HybridStage.fromLogicalSize，:212-224）已按
//   "logicalHeight > 0 ? logicalHeight/1080 : 1.0" 落盘，故在该快照下本条预期 GREEN；
//   若 A1 回退夹取则再次 RED。
//
// 【为什么用 fake port】
//   候选 D 依赖三条尚未合入本树的上游产物：T12 的真实 TextureHost
//   （Qt/porting/TextureHost.h，本树不存在）、T30 协议层（lib/hud/protocol/*，禁 import）、
//   T31 字形层（lib/hud/text/*，禁 import）。故只依赖同批 writer A1 的
//   lib/spike/hybrid/hybrid_host.dart，并用 _FakeTexturePort / _FakeHudPainter 注入 port；
//   断言的是契约形状（几何同源、代次、顺序、矩形、颜色、失败出口），不是真实 GPU/Qt 行为。
//
// 【不依赖网络 / 计时等待 / 真实 GPU】
//   全部断言同步完成：无网络、无 sleep、无 pumpAndSettle、无 Future.delayed、无真实帧调度；
//   宿主时钟用可注入假时钟（_FakeClock），不存在"等一帧"式时序掩盖。
//
// 【契约来源】
//   C  = /home/aibeto/code/Rhine-Music-Database/.agents/parity-20261109/reports/T14-C18-CONTRACT.json
//        （Lead 裁决；frozenDartApi / stageFormula / commandsContract / hitsContract /
//         publicationContract / evidence）
//   P1 = docs/superpowers/plans/2026-11-09-qt-to-flutter-parity-plan.md：§4.1 舞台与层
//        （行176-182）、§4.2 commands/hits、§4.3 发布与 generation、§4.5 2D/3D 边界、
//        行138 候选 D、行489-495 T14 与 Fail（两套状态双写导致错帧）
//   Q1 Qt/src/NativeHud.cpp:102-109 hits 六键 + label.isNull() 回落 action
//   Q2 Qt/src/PlayerBar.cpp:46-53 唯一 fixed:true
//   Q3 Qt/qml/Overlay.qml:38-43 touchHitPadding = android ? 16 : 0，hitArea() 只在消费侧外扩
//   Q4 Qt/src/Glyphs.cpp:35-49 calibrated ⇒ Gamma 1.8 → sRGB（只作用于下标 0..2）
//   Q5 Qt/src/NativeScene.cpp:217-224 resize 只更新宽高/投影/viewer，不重建引擎
//   Q6 Qt/src/NativeScene.cpp:190-194 非 detail 态 m_targetRotation = 0（旋转必须回正）
//   Q7 Qt/src/NativeSceneFrame.cpp:87-119 帧 31 字面键 + :164-166/:195 追加键，无 generation
// =============================================================================

import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/spike/hybrid/hybrid_host.dart';

/// 只在这一处绑定 engineHudWidth 的宿主形态（A1 若做成顶层函数，改这一行即可）。
double _engineHudWidth(double widthLogical, double heightLogical) =>
    HybridStage.engineHudWidth(widthLogical, heightLogical);

/// 假 3D 纹理 port：记录每次生命周期调用与 **attach 收到的几何快照**。
///
/// 契约（C.frozenDartApi.texturePort）：只有 generation / attach / resize / rotate / detach，
/// **没有 advance()** —— 宿主绝不反向推进 Qt 代次；generation 由 port 实现方自持，宿主只读。
class _FakeTexturePort implements HybridTexturePort {
  _FakeTexturePort(this.generation);

  @override
  int generation;

  int attachCalls = 0, detachCalls = 0, resizeCalls = 0, rotateCalls = 0;

  /// attach 收到的几何原样保存：用来证明 stage 与纹理同源（不是只数调用次数）。
  HybridSurfaceGeometry? attachGeometry;

  double? resizedWidthLogical, resizedHeightLogical, rotatedRadians;

  @override
  void attach(HybridSurfaceGeometry geometry) {
    attachCalls += 1;
    attachGeometry = geometry;
  }

  @override
  void detach() {
    detachCalls += 1;
  }

  @override
  void resize(double logicalWidth, double logicalHeight) {
    resizeCalls += 1;
    resizedWidthLogical = logicalWidth;
    resizedHeightLogical = logicalHeight;
  }

  @override
  void rotate(double radians) {
    rotateCalls += 1;
    rotatedRadians = radians;
  }
}

/// 假 HUD 绘制器 port：按帧保留命令流与 stage 实例，供 identical 与逐项同序断言。
class _FakeHudPainter implements HybridHudCommandPainter {
  final List<List<Object?>> frames = <List<Object?>>[];
  final List<HybridStage> stages = <HybridStage>[];

  int get paintCalls => frames.length;
  List<Object?>? get lastCommands => frames.isEmpty ? null : frames.last;
  HybridStage? get lastStage => stages.isEmpty ? null : stages.last;

  @override
  void paint(List<Object?> commands, HybridStage stage) {
    frames.add(commands);
    stages.add(stage);
  }
}

/// 假宿主时钟：可注入，避免任何真实计时/等待。
class _FakeClock implements HybridSceneClock {
  _FakeClock(this.seconds);

  final double seconds;

  @override
  double nowSeconds() => seconds;
}

/// 造一条原始 hit；withFixed 为 false 时**不带** fixed 键（Q1：六键基线）。
Map<String, Object?> _rawHit(double x, double y, double w, double h, String action, Object? label,
    {bool withFixed = false}) {
  final map = <String, Object?>{'x': x, 'y': y, 'width': w, 'height': h, 'action': action, 'label': label};
  if (withFixed) map['fixed'] = true;
  return map;
}

/// 固定 hit fixture：一条普通 hit + 一条 PlayerBar 的 fixed hit（Q2）。
List<Object?> _defaultHits() => <Object?>[
      _rawHit(120, 640, 300, 88, 'open-detail', '打开详情'),
      _rawHit(0, 990, 1920, 90, 'player.toggle', '播放/暂停', withFixed: true),
    ];

/// 一份最小的真实形态 frame（只取 Qt 顶层键里的几个代表项；字段清单最终由 T03 冻结，
/// C.frameKeysAdjudication：本文件只做源镜像，不新增/不删减契约）。
Map<String, Object?> _defaultFrame() => <String, Object?>{
      'mode': 'archive',
      'time': 1.25,
      'selected': 16,
      'detail': 0.0,
      'boot': 0.0,
      'actors': <Object?>[],
      'stats': <String, Object?>{'draws': 0.0},
    };

/// 造一份 decode 入口的原始 envelope（frozen 入口是 Map，不是已解码对象）。
/// 五个成员全有或全无，frame 必带（HybridFrameEnvelope.decode 要求 frame 是 Map）。
Map<String, Object?> _rawEnvelope({
  required int generation,
  List<Object?>? commands,
  List<Object?>? hits,
  Map<String, Object?>? state,
  Map<String, Object?>? frame,
}) =>
    <String, Object?>{
      'generation': generation,
      'frame': frame ?? _defaultFrame(),
      'commands': commands ?? <Object?>[<Object?>['save'], <Object?>['restore']],
      'hits': hits ?? _defaultHits(),
      'state': state ?? <String, Object?>{'mode': 'archive', 'time': 1.0},
    };

/// 源矩形与 toJson() 必须逐值相同：padding=16 只在 Overlay 消费侧（Q3），绝不写回源矩形。
void _expectSameRect(Map<String, Object?> source, Map<String, Object?> json) {
  for (final key in <String>['x', 'y', 'width', 'height']) {
    expect(json[key], source[key], reason: key + ' 必须与源矩形逐值相同（padding=16 属于触摸层）');
  }
}

void main() {
  group('T14 候选D 混合切片 · 同切片静态规格', () {
    test('[1] HybridFrameEnvelope.decode 全有或全无：缺 generation/frame/commands/hits/state 或 generation 非 int ⇒ HybridProtocolException', () {
      // 契约来源：C.frozenDartApi.envelope「成员固定 generation(int) frame(Map) commands(List)
      // hits(List) state(Map)，全有或全无」；P1 §4.3「commands/hits/frame 必须同一状态代次发布」。
      Map<String, Object?> base() => <String, Object?>{
            'generation': 7,
            'frame': <String, Object?>{'mode': 'archive', 'time': 1.0},
            'commands': <Object?>[<Object?>['save'], <Object?>['restore']],
            'hits': _defaultHits(),
            'state': <String, Object?>{'mode': 'archive'},
          };

      final envelope = HybridFrameEnvelope.decode(base());
      expect(envelope.generation, 7);
      expect(envelope.commands.length, 2);
      expect(envelope.frame['mode'], 'archive');
      expect(envelope.hits.length, 2);

      // 缺任一必需成员 ⇒ 整体失败，不做"缺省补空"（frame 也在必需集合里）。
      for (final missing in <String>['generation', 'frame', 'commands', 'hits', 'state']) {
        expect(() => HybridFrameEnvelope.decode(base()..remove(missing)),
            throwsA(isA<HybridProtocolException>()),
            reason: '缺 ' + missing + ' 必须抛 HybridProtocolException');
        expect(HybridFrameEnvelope.tryDecode(base()..remove(missing)), isNull,
            reason: 'tryDecode 对同一协议错必须返回 null，不抛');
      }

      // generation 必须严格是 int：字符串/浮点/null/数组都不合法。
      for (final bad in <Object?>['7', 7.5, null, <Object?>[7]]) {
        expect(() => HybridFrameEnvelope.decode(base()..['generation'] = bad),
            throwsA(isA<HybridProtocolException>()),
            reason: 'generation=' + bad.toString() + ' 不是 int，必须失败');
      }

      // 成员类型错同样整体失败（frame 必须是 Map，commands/hits 必须是 List）。
      expect(() => HybridFrameEnvelope.decode(base()..['frame'] = <Object?>[]),
          throwsA(isA<HybridProtocolException>()),
          reason: 'frame 必须是 Map');
      expect(() => HybridFrameEnvelope.decode(base()..['commands'] = <String, Object?>{}),
          throwsA(isA<HybridProtocolException>()),
          reason: 'commands 必须是 List');

      // 空但必须存在：三条空载荷 + int generation 属于合法帧。
      final empty = HybridFrameEnvelope.decode(<String, Object?>{
        'generation': 9,
        'frame': <String, Object?>{},
        'commands': <Object?>[],
        'hits': <Object?>[],
        'state': <String, Object?>{},
      });
      expect(empty.generation, 9);
      expect(empty.commands, isEmpty);
      expect(empty.hits, isEmpty);
      expect(empty.frame, isEmpty);
      expect(empty.state, isEmpty);
    });

    test('[2] HybridFrameGate：相同或更小代不放行（且不合并），更大代放行，markApplied 推进 appliedGeneration', () {
      // 契约来源：C.publicationContract「非更新代整份丢弃，不合并」+「generation 只做一致性校验，
      // 绝不用于去重合法相同命令」；P1 §4.3 发布规则。
      final gate = HybridFrameGate();
      expect(gate.appliedGeneration, isNull, reason: '尚未套用任何代次');
      expect(gate.shouldApply(1), isTrue, reason: '首个更新代必须放行');
      gate.markApplied(1);
      expect(gate.appliedGeneration, 1);

      expect(gate.shouldApply(1), isFalse, reason: '相同代不可重复应用');
      expect(gate.shouldApply(0), isFalse, reason: '更小代必须丢弃');
      expect(gate.shouldApply(-5), isFalse, reason: '负数代必须丢弃');

      // shouldApply 只读：放行也不得自行推进代次（合并是 host 的职责）。
      expect(gate.shouldApply(2), isTrue);
      expect(gate.appliedGeneration, 1, reason: 'shouldApply 不得合并/推进 appliedGeneration');

      gate.markApplied(2);
      expect(gate.appliedGeneration, 2);
      expect(gate.shouldApply(2), isFalse);
      expect(gate.shouldApply(3), isTrue);
    });

    test('[3] HybridStage.fromLogicalSize：按 C.stageFormula.frozen 换算（(0,0)/(1920,1080)/(1200,600)），无 1/1080 退化', () {
      // 契约来源：C.stageFormula.frozen / degenerateExpected；
      // 权威源 Qt/qml/Overlay.qml:22-23 —— stageScale = height > 0 ? height / 1080 : 1；
      // stageWidth = width / stageScale。P1 行178「旋转/尺寸变化只重算 stage，不重建引擎状态」。
      // Lead m00138 要求显式写明：本断言对应 Overlay.qml:22 的 ": 1" 回落；A1 若仍含前置夹取
      // （max(1.0,…)），本树该条为预期 RED，属 A1 未关项，不得改断言。核对快照（763 行版本）
      // 已按 frozen 公式落盘 ⇒ 在该快照下预期 GREEN。

      // (0,0)：height<=0 ⇒ scale 恰为 1.0（**不是** 1/1080），width/height 如实为 0。
      final degenerate = HybridStage.fromLogicalSize(0, 0);
      expect(degenerate.scale, closeTo(1.0, 1e-12),
          reason: 'C.stageFormula.mustNot：不得把 max(1.0,…) 混进 stage 公式 —— height<=0 时 Qt 给 1，不是 1/1080');
      expect(degenerate.width, closeTo(0.0, 1e-12));
      expect(degenerate.height, closeTo(0.0, 1e-12));

      // (1920,1080)：scale 1.0、width 1920。
      final full = HybridStage.fromLogicalSize(1920, 1080);
      expect(full.scale, closeTo(1.0, 1e-12));
      expect(full.width, closeTo(1920.0, 1e-12));
      expect(full.height, closeTo(1080.0, 1e-9), reason: 'height>0 时 height = logicalHeight/scale 恒为 1080');

      // (1200,600)：scale 600/1080、width 2160。
      const bandScale = 600 / 1080;
      final band = HybridStage.fromLogicalSize(1200, 600);
      expect(band.scale, closeTo(bandScale, 1e-12));
      expect(band.width, closeTo(2160.0, 1e-9), reason: '1200 / (600/1080) = 2160');
      expect(band.height, closeTo(1080.0, 1e-9));

      // 同公式的自洽性：width = logicalWidth/scale，height = logicalHeight/scale。
      expect(band.width, closeTo(1200 / band.scale, 1e-9));
      expect(band.height, closeTo(600 / band.scale, 1e-9));

      // engineHudWidth = 同一 stage 的 width（C.frozenDartApi.stage：static engineHudWidth）；
      // 退化输入按同一公式直接推导为 logicalWidth（scale=1.0），**不引入 1920 之类无源兜底**。
      expect(_engineHudWidth(1920, 1080), closeTo(1920.0, 1e-12));
      expect(_engineHudWidth(1200, 600), closeTo(2160.0, 1e-9));
      expect(_engineHudWidth(1200, 0), closeTo(1200.0, 1e-12),
          reason: 'height<=0 ⇒ scale 1.0 ⇒ engineHudWidth = logicalWidth');
      expect(_engineHudWidth(0, 0), closeTo(0.0, 1e-12));
    });

    test('[4] HybridHit.decode（批式）：顺序保持、fixed 仅 true 时出现、label 回落、几何不可用丢弃、源矩形不被 padding 改写', () {
      // 契约来源：C.frozenDartApi.hit「static List<HybridHit> HybridHit.decode(List<Object?>)」；
      // Q1（hits 六键 + label null 回落）、Q2（仅 PlayerBar 带 fixed:true）、
      // Q3（padding=16 只在消费侧）、P1 §4.3「禁止排序改写、禁止外扩写回源矩形」。
      final usable = <Object?>[
        _rawHit(10, 20, 30, 40, 'open-detail', '打开详情'),
        _rawHit(1, 2, 3, 4, 'player.prev', '上一首', withFixed: true),
        <String, Object?>{'x': 5.0, 'y': 6.0, 'width': 7.0, 'height': 8.0, 'action': 'no-label'},
        _rawHit(9, 10, 11, 12, 'explicit-empty', ''),
        _rawHit(13, 14, 15, 16, 'bad-label', 42),
      ];

      // 几何/动作不可用的项（缺项、非数值、整条 null、非 Map）一律整项丢弃，不产生半残 hit。
      final unusable = <Object?>[
        <String, Object?>{'x': 1.0, 'y': 2.0, 'width': 3.0, 'action': 'missing-height'},
        <String, Object?>{'x': '1.0', 'y': 2.0, 'width': 3.0, 'height': 4.0, 'action': 'string-x'},
        <String, Object?>{'x': 1.0, 'y': null, 'width': 3.0, 'height': 4.0, 'action': 'null-y'},
        <String, Object?>{'x': 1.0, 'y': 2.0, 'width': 3.0, 'height': 4.0},
        null,
        3,
        'not-a-map',
      ];

      // 批式入口：一次解码整份 hits（不是逐条可空 decode）。
      final decoded = HybridHit.decode(<Object?>[...usable, ...unusable]);

      // 顺序与源完全一致：不得排序、不得去重、不得猜 z。
      expect(decoded.length, 5, reason: '7 条不可用项必须被丢弃，不得产生半残 hit');
      expect(decoded.map((HybridHit hit) => hit.action).toList(),
          <String>['open-detail', 'player.prev', 'no-label', 'explicit-empty', 'bad-label']);
      expect(HybridHit.decode(<Object?>[]), isEmpty);

      // fixed 只显式出现在 fixed==true 的项上；其余项连键都不能有。
      expect(decoded[1].toJson().containsKey('fixed'), isTrue);
      expect(decoded[1].toJson()['fixed'], isTrue);
      expect(decoded[0].toJson().containsKey('fixed'), isFalse);
      expect(decoded[2].toJson().containsKey('fixed'), isFalse);
      expect(decoded[0].fixed, isFalse);
      expect(decoded[1].fixed, isTrue);

      // label：缺失/非字符串回落 action；显式空串必须保留为空串。
      expect(decoded[2].label, 'no-label');
      expect(decoded[3].label, '');
      expect(decoded[4].label, 'bad-label');
      expect(decoded[0].label, '打开详情');

      // 源矩形逐值相同：外扩 16 只在 Overlay 消费侧。
      for (var index = 0; index < usable.length; index += 1) {
        _expectSameRect(usable[index] as Map<String, Object?>, decoded[index].toJson());
      }
      expect(kHybridTouchPadding, 16.0);
    });

    test('[5] 颜色：calibrated 走 Gamma 1.8 → sRGB；HybridColor 非数组/alpha 非数值按源回落', () {
      // 契约来源：C.colorContract / Q4（Qt/src/Glyphs.cpp:35-49）；P1 §4.2 第 5 项 calibrated 标记。
      expect(kHybridCalibratedGamma, 1.8);
      expect(hybridCalibratedChannel(0.0), 0.0);
      expect(hybridCalibratedChannel(1.0), closeTo(1.0, 1e-9));

      final halfChannel = hybridCalibratedChannel(0.5);
      expect(halfChannel, closeTo(hybridSrgbEncode(math.pow(0.5, 1.8).toDouble()), 1e-12));

      // 逐项核对公式：linear = pow(v,1.8)；srgb(linear) = linear<=0.0031308
      // ? 12.92*linear : 1.055*pow(linear,1/2.4)-0.055。
      double expectedChannel(double value) {
        final linear = math.pow(value, 1.8).toDouble();
        return linear <= 0.0031308 ? 12.92 * linear : 1.055 * math.pow(linear, 1 / 2.4) - 0.055;
      }

      for (final value in <double>[0.08, 0.085, 0.075, 0.92]) {
        expect(hybridCalibratedChannel(value), closeTo(expectedChannel(value), 1e-12));
      }

      // 非数组 ⇒ 不透明黑（对应 Qt 侧 toArray() 为空后 fromRgbF(0,0,0,1)）。
      final black = HybridColor.decode('not-a-list');
      expect(<double>[black.r, black.g, black.b, black.a], <double>[0.0, 0.0, 0.0, 1.0]);

      expect(HybridColor.decode(<Object?>[0.1, 0.2, 0.3]).a, 1.0, reason: '少于 4 项 ⇒ alpha 1');
      expect(HybridColor.decode(<Object?>[0.1, 0.2, 0.3, 'x']).a, 0.0,
          reason: '第 4 项非数值 ⇒ QJsonValue::toDouble() 给 0.0，alpha 0');

      // 第 5 项 calibrated 标记 ⇒ RGB 走 Gamma 1.8 转换；alpha 不参与。
      final calibrated = HybridColor.decode(<Object?>[0.5, 0.5, 0.5, 1.0, 'calibratedRGB']);
      expect(calibrated.r, closeTo(halfChannel, 1e-12));
      expect(calibrated.g, closeTo(halfChannel, 1e-12));
      expect(calibrated.b, closeTo(halfChannel, 1e-12));
      expect(calibrated.a, 1.0, reason: 'calibrated 只作用于下标 0..2，alpha 原样');

      // 第 5 项不是 calibrated 前缀 ⇒ 不做 Gamma 转换（保持原值）。
      final plain = HybridColor.decode(<Object?>[0.5, 0.25, 0.75, 1.0, 'srgb']);
      expect(<double>[plain.r, plain.g, plain.b], <double>[0.5, 0.25, 0.75]);
    });

    test('[6] HybridHost.apply 正常路径：几何同源、同代放行、painter 恰 1 次、命令逐项同序且两条相同命令都到达', () {
      // 契约来源：C.commandsContract.rules（原样透传/同序/不去重/同一 instance）、
      // C.publicationContract、C.frozenDartApi.host（HybridHost(texture:, hud:)）。
      final texture = _FakeTexturePort(5);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter, clock: _FakeClock(1.5));

      final commands = <Object?>[
        <Object?>['save'],
        <Object?>['translate', 12.0, 34.0],
        <Object?>['save'], // 与上一条完全相同的合法命令：绝不能被去重
        <Object?>['fill', <Object?>[0.08, 0.085, 0.075, 1.0, 'calibratedRGB'], 0.0, 0.0, 10.0, 10.0],
        <Object?>['text', 'RHINE', 8.0, 30.0, 12.0, 'regular', 0.0, <Object?>[0.92, 0.92, 0.92, 1.0, 'calibratedWhite']],
      ];
      final state = <String, Object?>{'mode': 'archive', 'time': 1.25, 'selected': 16};
      final result = host.apply(_rawEnvelope(generation: 5, commands: commands, state: state));

      expect(result.applied, isTrue);
      expect(result.hudPainted, isTrue);
      expect(result.generation, 5);
      expect(result.commandCount, commands.length);
      expect(result.hitCount, 2);
      expect(host.doubleWriteDetected, isFalse);
      expect(painter.paintCalls, 1);
      expect(texture.attachCalls, 1);
      expect(host.lastFrameTimeSeconds, 1.5, reason: '注入的假时钟读数原样记录');

      // ── 几何同源（C.mandatoryFixes[A3]#2：不许只看调用次数）──
      // 宿主构造即 attach，交给 port 的几何里 stageWidth/scale 必须与 host.stage 同源。
      final geometry = texture.attachGeometry;
      expect(geometry, isNotNull, reason: 'attach 必须收到 HybridSurfaceGeometry');
      expect(geometry!.stageWidth, closeTo(host.stage.width, 1e-12),
          reason: 'attach 的 stageWidth 必须就是 host.stage.width（坐标同源，不是另算一遍）');
      expect(geometry.stageHeight, closeTo(host.stage.height, 1e-12));
      expect(geometry.scale, closeTo(host.stage.scale, 1e-12));
      expect(geometry.logicalWidth, closeTo(host.stage.width * host.stage.scale, 1e-9));
      expect(geometry.logicalHeight, closeTo(host.stage.height * host.stage.scale, 1e-9));
      expect(geometry.devicePixelRatio, 1.0);

      // dpr 只进几何、绝不参与 stage 换算（C.frozenDartApi.host 的 devicePixelRatio 语义）。
      final dprTexture = _FakeTexturePort(5);
      final dprHost = HybridHost(texture: dprTexture, hud: _FakeHudPainter(), devicePixelRatio: 3.0);
      expect(dprTexture.attachGeometry!.devicePixelRatio, 3.0);
      expect(dprHost.stage.scale, closeTo(host.stage.scale, 1e-12),
          reason: 'dpr 不得参与 stage 换算');
      expect(dprHost.stage.width, closeTo(host.stage.width, 1e-12));

      // ── 命令透传：同序、逐项等值、且不得去重 ──
      final painted = painter.lastCommands;
      expect(painted, isNotNull, reason: 'painter 必须收到命令流');
      if (painted == null) {
        fail('painter.lastCommands 为 null：apply 已 applied 却没有把命令交给绘制器');
      }
      expect(painted.length, commands.length);
      for (var index = 0; index < commands.length; index += 1) {
        expect(painted[index], equals(commands[index]),
            reason: index.toString() + ' 号命令必须逐项同序到达 painter');
        // 同实例透传：decode 只做外层 List 浅拷贝（核对快照 hybrid_host.dart:759，_requireList 定义 :751-760），
        // 逐条命令项必须是源实例本身，不得拷贝/重建/改写（见文件头"不可达边界 1"）。
        expect(identical(painted[index], commands[index]), isTrue,
            reason: index.toString() + ' 号命令必须是源实例本身（不得拷贝/重建/改写参数）');
      }
      // 两条同样的 save 都在（去重即失败）。
      expect(
          painted
              .where((Object? c) => c is List<Object?> && c.length == 1 && c.first == 'save')
              .length,
          2,
          reason: 'C.commandsContract.rules：两条完全相同的命令都必须到达绘制器');

      // ── stage 同实例透传（measure/hit/IME 同一 layout geometry，P1 行213）──
      expect(painter.lastStage, isNotNull);
      expect(identical(host.stage, painter.lastStage), isTrue,
          reason: 'painter 必须拿到 host 的同一个 HybridStage 实例，不是拷贝/重建');

      // ── state 原样透传（state/frame 同代，不由 HUD 改写）──
      expect(host.state, isNotNull);
      expect(host.state!['mode'], 'archive');
      expect(host.state!['time'], 1.25);
      expect(host.gate.appliedGeneration, 5);

      // ── 第二帧仍共用同一 stage 实例（同一 layout geometry，不是每帧重建）──
      // 注意：**不得**断言跨帧外层 commands List 的 identical —— Lead m00138 裁决那是分配
      // 细节而非契约（合法实现可跨帧复用同一不可变列表），只有 stage 同源是可断言语义。
      texture.generation = 6;
      expect(host.apply(_rawEnvelope(generation: 6)).applied, isTrue);
      expect(painter.paintCalls, 2);
      expect(identical(host.stage, painter.stages[1]), isTrue,
          reason: '第二帧仍必须共用同一个 stage 实例');
    });

    test('[7] 双写/错帧显式失败（P1 行495 Fail）：texture.generation != envelope.generation ⇒ applied=false、doubleWriteDetected、painter 不画', () {
      // 契约来源：C.publicationContract.rules[3]「宿主已附着时要求 texture.generation ==
      // envelope.generation，不等即双写/错帧 Fail（plan:495）」；P1 行495
      // 「Fail: 两套状态双写导致错帧」。这是一等失败出口，必须显式可观测，
      // 不能被"尽力合成"掩盖，也不能静默容忍。
      final texture = _FakeTexturePort(11); // 3D 栈停在 N
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);

      final result = host.apply(_rawEnvelope(generation: 12)); // HUD 代 N+1
      expect(result.applied, isFalse);
      expect(result.hudPainted, isFalse);
      expect(result.commandCount, 0);
      expect(result.hitCount, 0);
      expect(host.doubleWriteDetected, isTrue,
          reason: '双写必须作为一等事实被记录（核对快照 hybrid_host.dart:578 的粘性 getter）');
      expect(result.reason.startsWith('double-write'), isTrue,
          reason: 'HybridApplyResult.reason 的文档化 token（核对快照 hybrid_host.dart:499 文档 / :665 的 double-write: 前缀）');
      expect(painter.paintCalls, 0, reason: '错帧时绝不绘制 HUD，避免旧 3D + 新 HUD 合成');
      expect(texture.detachCalls, 0, reason: '失败出口不得顺手拆掉仍在跑的 3D 栈');
      expect(host.gate.appliedGeneration, isNull, reason: '错帧不得推进代次闸门');

      // 粘性：不得因为后续帧成功就静默清除 Fail 证据（"显式失败"而不是"事后忘记"）。
      texture.generation = 12;
      expect(host.apply(_rawEnvelope(generation: 12)).applied, isTrue);
      expect(painter.paintCalls, 1);
      expect(host.doubleWriteDetected, isTrue,
          reason: 'Fail 证据粘性保留：不得被后续成功帧静默清除');
    });

    test('[8] 非更新代整体丢弃：gen=2 两次后第二次不画，gen=3 才放行', () {
      // 契约来源：C.publicationContract.rules[2]「非更新代整份丢弃，不合并」+ P1 §4.3 发布规则。
      final texture = _FakeTexturePort(2);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);

      expect(host.apply(_rawEnvelope(generation: 2)).applied, isTrue);
      expect(painter.paintCalls, 1);
      expect(host.gate.appliedGeneration, 2);

      final stale = host.apply(_rawEnvelope(generation: 2, commands: <Object?>[<Object?>['restore']]));
      expect(stale.applied, isFalse);
      expect(stale.hudPainted, isFalse);
      expect(stale.commandCount, 0, reason: '整体丢弃 ⇒ 透传命令数为 0');
      expect(painter.paintCalls, 1, reason: '非更新代整体丢弃：不得再画一次');
      expect(stale.reason.startsWith('stale-generation'), isTrue,
          reason: 'HybridApplyResult.reason 的文档化丢弃 token（核对快照 hybrid_host.dart:499 文档 / :653 的 stale-generation: 前缀）');
      expect(host.gate.appliedGeneration, 2, reason: '丢弃不得改变已套用代次');

      // 3D 栈同步推进到同一代（否则会被第 [7] 条的双写出口拦住）。
      texture.generation = 3;
      final fresh = host.apply(_rawEnvelope(generation: 3));
      expect(fresh.applied, isTrue);
      expect(fresh.hudPainted, isTrue);
      expect(painter.paintCalls, 2);
      expect(host.gate.appliedGeneration, 3);
    });

    test('[9] resizeLogical(1200,600)：只重算 stage 并 resize 纹理，attach 仍 1 次（不重建引擎状态）', () {
      // 契约来源：P1 行178「旋转/尺寸变化只重算 stage，不重建引擎状态」；
      // Q5（Qt/src/NativeScene.cpp:217-224 只更新宽高/投影/viewer）。
      final texture = _FakeTexturePort(1);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);
      expect(host.apply(_rawEnvelope(generation: 1)).applied, isTrue);
      expect(texture.attachCalls, 1);

      final initialGeometry = texture.attachGeometry;
      expect(initialGeometry, isNotNull);

      host.resizeLogical(1200, 600);

      const bandScale = 600 / 1080;
      expect(host.stage.scale, closeTo(bandScale, 1e-12));
      expect(host.stage.width, closeTo(2160.0, 1e-9));
      expect(host.stage.height, closeTo(1080.0, 1e-9));
      expect(texture.resizeCalls, 1);
      expect(texture.resizedWidthLogical, 1200.0, reason: 'resize 收逻辑尺寸原值，不是 stage 值');
      expect(texture.resizedHeightLogical, 600.0);
      expect(texture.attachCalls, 1, reason: '尺寸变化不得重建引擎：attach 次数不能增加');
      expect(texture.detachCalls, 0, reason: '尺寸变化不得拆栈');

      // attach 是一次性几何快照：resize 只补发尺寸，不重新 attach（不重建 3D 栈身份）。
      expect(identical(texture.attachGeometry, initialGeometry), isTrue,
          reason: 'resize 不得重新 attach（那是重建引擎状态的入口）');
      expect(texture.attachGeometry!.stageWidth, closeTo(initialGeometry!.stageWidth, 1e-12));

      // resize 之后下一次 apply：painter 仍拿到 host 的同一个 stage 实例（坐标仍同源）。
      texture.generation = 2;
      expect(host.apply(_rawEnvelope(generation: 2)).applied, isTrue);
      expect(identical(host.stage, painter.lastStage), isTrue,
          reason: 'resize 后 measure/hit/paint 仍必须共用同一 stage 实例（P1 行213）');
      expect(painter.lastStage!.scale, closeTo(bandScale, 1e-12));
      expect(painter.lastStage!.width, closeTo(2160.0, 1e-9));
    });

    test('[10] rotateTo(pi/3)：HUD 与 3D 同角；回到 0 即回正（NativeScene.cpp:190-194）', () {
      // 契约来源：P1 行489「验证坐标同源、同步、旋转、退出条件」；
      // Q6（非 detail 态 m_targetRotation=0，未完成的旋转必须回正）。
      final texture = _FakeTexturePort(4);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);
      expect(host.apply(_rawEnvelope(generation: 4)).applied, isTrue);

      final stageBeforeRotate = host.stage;

      host.rotateTo(math.pi / 3);
      expect(host.rotationRadians, closeTo(math.pi / 3, 1e-12));
      expect(texture.rotateCalls, 1);
      expect(texture.rotatedRadians, closeTo(math.pi / 3, 1e-12),
          reason: '3D 纹理必须收到同一角度（双栈同步，不是只转 HUD）');
      expect(identical(host.stage, stageBeforeRotate), isTrue,
          reason: '旋转只改呈现变换，不得重建 stage 实例/尺寸');

      // 回正：两栈必须同时归零，不能只转 HUD 或只转纹理。
      host.rotateTo(0);
      expect(host.rotationRadians, 0.0);
      expect(texture.rotateCalls, 2);
      expect(texture.rotatedRadians, 0.0);
      expect(painter.paintCalls, 1, reason: '旋转本身不重发 HUD 命令流');
      expect(texture.attachCalls, 1, reason: '旋转不得重建引擎（P1 行178）');
      expect(texture.resizeCalls, 0, reason: '旋转不改变逻辑尺寸');
    });

    test('[11] rollbackToDartOnly：detach 恰 1 次、attached=false、旋转回正；之后新代仍可画 HUD 且不再要求 generation 相等', () {
      // 契约来源：P1 行138「渐进、可回退」+ 行492「记录双栈成本与可回退点」；
      // Q6（离开 detail ⇒ m_targetRotation=0）；port 契约「detach 之后不得再收到 resize/rotate」。
      final texture = _FakeTexturePort(1);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);
      expect(host.apply(_rawEnvelope(generation: 1)).applied, isTrue);
      expect(host.attached, isTrue);

      host.rotateTo(math.pi / 4);
      expect(texture.rotateCalls, 1);

      host.rollbackToDartOnly();
      expect(texture.detachCalls, 1);
      expect(host.attached, isFalse);
      expect(host.rotationRadians, 0.0,
          reason: '退出时必须回正旋转（NativeScene.cpp:190-194 非 detail ⇒ m_targetRotation=0）');
      expect(texture.rotateCalls, 1,
          reason: 'detach 之后不得再向 port 发 rotate（port 明言之后不得再收到 resize/rotate）');

      // 回退后：3D 栈停在 1，HUD 走 2 —— 仍必须能画，且不得报双写。
      final dartOnly = host.apply(_rawEnvelope(generation: 2, commands: <Object?>[<Object?>['restore']]));
      expect(dartOnly.applied, isTrue);
      expect(dartOnly.hudPainted, isTrue);
      expect(host.doubleWriteDetected, isFalse,
          reason: '已回退到纯 Dart HUD：没有 Qt 帧可双写，不得误报');
      expect(painter.paintCalls, 2);
      expect(texture.attachCalls, 1, reason: '回退后不得偷偷重新 attach 3D 栈');
      expect(texture.detachCalls, 1);

      // 回退后的纯 Dart HUD 仍按同一 stage 公式布局，且不再触碰 Qt 侧。
      host.resizeLogical(1200, 600);
      expect(texture.resizeCalls, 0, reason: '已 detached，不得再触碰 Qt 侧几何');
      expect(host.stage.width, closeTo(2160.0, 1e-9),
          reason: '纯 Dart HUD 仍须用同一 stage 公式（可回退不等于降级几何）');
      expect(host.stage.scale, closeTo(600 / 1080, 1e-12));
    });

    test('[12] applied 帧的结构事实：frame 原样透传、无占位位图注入、HUD 命令不进 3D —— 真实 3D 属 T16 ARCH_BLOCKED 与设备 DEVICE_BLOCKED', () {
      // 契约来源：C.mandatoryFixes[A3]#5 —— 只允许断言结构事实；
      // P1 §4.5「3D 必须保留真实 GLB、材质、相机、BVH 拾取、灯光、雾、动画时间、纹理准入；
      // 禁止静态背景、预渲染视频」。
      //
      // 本测试**不验证**真实 GLB/材质/相机/BVH/灯光/雾/动画：
      //   * T16 ARCH_BLOCKED —— 同 slice 五候选的真实裁决尚未测量；
      //   * DEVICE_BLOCKED  —— 未跑设备/GPU/像素/性能。
      // 因此本测试不得被引用为"真实 3D 已通过"。
      final texture = _FakeTexturePort(8);
      final painter = _FakeHudPainter();
      final host = HybridHost(texture: texture, hud: painter);

      final frame = <String, Object?>{
        'mode': 'archive',
        'time': 3.5,
        'selected': 16,
        'detail': 0.0,
        'boot': 0.0,
        'actors': <Object?>[
          <String, Object?>{'cell': 3, 'x': 0.0, 'y': 1.5},
        ],
        'stats': <String, Object?>{'draws': 42.0},
        'appearanceRevision': 7,
      };
      final commands = <Object?>[
        <Object?>['save'],
        <Object?>['fill', <Object?>[0.1, 0.2, 0.3, 1.0], 0.0, 0.0, 8.0, 8.0],
        <Object?>['restore'],
      ];

      expect(host.apply(_rawEnvelope(generation: 8, commands: commands, frame: frame)).applied, isTrue);

      // 交付帧键数是**路径相关**的（Lead m00138：A2 上报、Lead 复核 NativeCards.cpp）：
      //   写入 35 键；成功 expand 主动 remove actorTemplate/actors ⇒ 33 键；
      //   校验失败提前返回则仍 35 键。因此本条只断言「原样透传、不增不删、不合成」，
      //   **绝不断言固定 33 或 35 键**（那会把路径相关的实现细节当成共享契约）。
      //
      // (a) frame 原样透传：键集合/值与源逐项相同，不得增删。
      final Map<String, Object?> deliveredFrame = host.frame!;
      expect(deliveredFrame.keys.toSet(), frame.keys.toSet(),
          reason: 'frame 必须原样透传（不增键不删键）；真实 GLB/材质/相机/BVH/灯光/雾/动画属 '
              'T16 ARCH_BLOCKED 与设备 DEVICE_BLOCKED，本文件未验证');
      expect(deliveredFrame, equals(frame));

      // (b) 不得出现"把 HUD / 占位图烤进 3D"的字段：命令、命中、state 只属 2D 侧。
      for (final forbidden in <String>[
        'commands',
        'hits',
        'state',
        'hudCommands',
        'hudTexture',
        'placeholder',
        'placeholderTexture',
        'bitmap',
        'textureId',
      ]) {
        expect(deliveredFrame.containsKey(forbidden), isFalse,
            reason: forbidden + ' 不是 Qt 顶层 frame 键，出现即说明 HUD/占位位图被注入 3D 帧');
      }
      expect(deliveredFrame.containsKey('actors'), isTrue,
          reason: '真实 actors 键必须保留（HUD 不得替换 3D 侧真实数据）');

      // (c) 本帧对 3D 端口只做代次一致性校验：不重建、不重挂、不拆栈，
      //     端口签名里也没有"接收命令"的能力 —— HUD 只能进 painter（结构事实）。
      expect(texture.attachCalls, 1, reason: 'apply 不得重建 3D 栈（attach 次数必须仍是 1）');
      expect(texture.resizeCalls, 0, reason: 'apply 不得顺手 resize');
      expect(texture.rotateCalls, 0, reason: 'apply 不得顺手旋转');
      expect(texture.detachCalls, 0, reason: 'apply 不得拆栈');
      expect(painter.paintCalls, 1, reason: '命令只进 painter');
      expect(host.gate.appliedGeneration, 8);
      expect(identical(painter.lastCommands, painter.frames.first), isTrue);

      // (d) 命令确实没有流向 3D 侧：port 收到的唯一载荷是几何，不是命令流。
      expect(texture.attachGeometry, isNotNull);
      expect(texture.attachGeometry!.stageWidth, closeTo(host.stage.width, 1e-12));
    });
  });
}
