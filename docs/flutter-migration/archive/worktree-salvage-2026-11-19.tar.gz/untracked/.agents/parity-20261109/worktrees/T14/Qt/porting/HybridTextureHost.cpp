#include "HybridTextureHost.h"

#include <QJsonArray>

#include <algorithm>

namespace {

// plan §4.1 行178 / Qt/qml/Overlay.qml:22：横屏舞台以 1080 逻辑高为基准，3D 与 Overlay 同窗独立层。
constexpr double kReferenceStageHeight = 1080.0;

// 纹理像素下限：QSize 不接受 0/负像素，0 尺寸纹理在 GL 侧也非法。
// 这是**本宿主的卫生下限（host hygiene floor），不是 Qt 的声明**：Qt 侧的 std::max(1.0, ·)
// 在 Qt/src/NativeScene.cpp:219-220，属「引擎 resize」层（投影比例/视口保护），与 stage 公式
// 无关，不得用它推导 stageScale。stage 公式在 height <= 0 时只回落 scale = 1（Overlay.qml:22），
// 此时 stage 高为 0，纹理高仍被夹到 1 px。
constexpr int kMinimumTexturePixels = 1;

// 非法 dpr（<=0）回落到 1.0：不静默产生 0 像素纹理。
constexpr double kFallbackDevicePixelRatio = 1.0;

// 像素分配：把候选像素尺寸夹到合法整数像素。qRound(NaN/±Inf) 属未定义转换，0/负像素在
// QSize 与 GL 侧都不合法，故非有限与 <= 0 一律落到卫生下限 kMinimumTexturePixels。
// 这是宿主/硬件事实，**不是几何事实**：stage 记录仍按源公式镜像原始输入，不在此改写。
int pixelExtent(double candidate) {
    if (!qIsFinite(candidate)) {
        return kMinimumTexturePixels;
    }
    return std::max(kMinimumTexturePixels, qRound(candidate));
}

}  // namespace

HybridTextureHost::HybridTextureHost(QObject *parent) : QObject(parent) {}

HybridTextureHost::~HybridTextureHost() {
    // 幂等拆卸：只清内部状态，不发信号（析构期连接不可靠，且调用方不应在这里收事件）。
    teardown();
}

quint64 HybridTextureHost::generation() const { return m_generation; }

QSize HybridTextureHost::textureSize() const { return m_textureSize; }

double HybridTextureHost::stageScale() const { return m_stageScale; }

double HybridTextureHost::stageWidth() const { return m_stageWidth; }

double HybridTextureHost::stageHeight() const { return m_stageHeight; }

bool HybridTextureHost::isAttached() const { return m_attached; }

double HybridTextureHost::rotation() const { return m_rotation; }

quint64 HybridTextureHost::teardownCount() const { return m_teardownCount; }

void HybridTextureHost::setSurface(double logicalWidth, double logicalHeight, double devicePixelRatio) {
    // 与 Qt/src/NativeScene.cpp:217-224 的 resize 同语义：只更新尺寸与几何，不重建引擎状态。
    // 这里**不**对逻辑尺寸做 max(1.0, ·)：引擎层（NativeScene::resize）的夹取属投影/视口保护，
    // 不属于 stage 公式；把它搬进来会让 height <= 0 时算出 1/1080 而不是 Qt 的 1。
    // ===== 几何记录区（与 Dart 侧 HybridTexturePort 逐值同源，禁止消毒）=====
    // 非有限输入只可能来自错误的布局产物；本类仍按源公式镜像，以便与 Dart 侧 stage 记录逐值
    // 一致，绝不伪造有限值（Dart 侧 scale = h > 0 ? h/1080 : 1，h=NaN ⇒ false ⇒ 1.0，
    // width 随之传播 NaN —— QML 的 stageWidth 同样是 NaN）。消毒只发生在下方像素分配区。
    m_logicalWidth = logicalWidth;
    m_logicalHeight = logicalHeight;
    // dpr 不属于 stage 几何记录（Dart 侧 HybridStage 无 dpr 字段），只参与像素分配，
    // 故非有限/<=0 直接回落 1.0，不会影响两栈的 stage 记录同源。
    m_devicePixelRatio = (qIsFinite(devicePixelRatio) && devicePixelRatio > 0.0)
                             ? devicePixelRatio
                             : kFallbackDevicePixelRatio;

    // 冻结公式（T14-C18-CONTRACT stageFormula.frozen；源 Qt/qml/Overlay.qml:22-23，逐字）：
    //   stageScale  = logicalHeight > 0 ? logicalHeight / 1080 : 1
    //   stageWidth  = logicalWidth / stageScale
    //   stageHeight = logicalHeight / stageScale
    // 先算 scale 再算宽高，且只在公式内部做 >0 分支 —— 顺序不可交换。
    m_stageScale = m_logicalHeight > 0.0 ? m_logicalHeight / kReferenceStageHeight : 1.0;
    m_stageWidth = m_logicalWidth / m_stageScale;
    m_stageHeight = m_logicalHeight / m_stageScale;

    // ===== 像素分配区（唯一消毒点：只服务 QSize/GL 的整数像素事实，不回写几何）=====
    // 纹理像素尺寸直接取逻辑尺寸 × dpr：**不**用 stageWidth * stageScale 的乘除链，
    // 浮点上 (w / s) * s 不保证逐位回到 w。退化尺寸下 logicalHeight = 0 ⇒ 1 px，
    // 而不是按 1080 * scale * dpr 造出一张 1080*dpr 高的假纹理。
    const int textureWidth = pixelExtent(m_logicalWidth * m_devicePixelRatio);
    const int textureHeight = pixelExtent(m_logicalHeight * m_devicePixelRatio);
    m_textureSize = QSize(textureWidth, textureHeight);
    m_attached = true;

    // 不去重：即使与上一状态完全相同也发信号。合法相同的尺寸不是「重复事件」，
    // 消费侧必须以自身 generation/几何为准（plan 行159 禁止对合法相同内容去重）。
    emit surfaceChanged(m_stageScale);
}

void HybridTextureHost::rotate(double radians) {
    // 精确记录：不归一化到 [0, 2π)、不夹取、不舍入。旋转必须可逆且与 Qt 侧输入逐位一致。
    m_rotation = radians;
    // 标记「未完成」：只有成功产出一帧才说明该旋转已被本次合成承接；
    // 否则退出时必须回正，避免下一次附着的纹理带着半程角度（plan 行491 验证旋转/退出条件）。
    // 本方法允许在附着前调用，故 teardown() 的回正必须在「未附着早退」之前执行。
    m_rotationPending = true;
}

quint64 HybridTextureHost::produceFrame(const QJsonObject &sceneFrame) {
    if (!m_attached) {
        // 无表面时不推进 generation：否则 Dart 侧会拿到一个永不出现的纹理帧。
        qWarning("HybridTextureHost::produceFrame ignored: no surface attached");
        return m_generation;
    }
    if (sceneFrame.isEmpty()) {
        // 空帧视为非法输入而非合法空场景：不推进、不缓存，避免用空帧覆盖上一帧。
        qWarning("HybridTextureHost::produceFrame ignored: empty scene frame");
        return m_generation;
    }

    // 只读引用：这里只复制到本类自己的存储，既不修改调用方的 sceneFrame，
    // 也不产生任何写回 HUD/state 的路径（plan 行493 的单向防线）。
    m_lastFrame = sceneFrame;
    m_rotationPending = false;  // 该旋转已被这一帧承接
    ++m_generation;             // 单一 generation：仅成功产出时自增，release 不回退

    emit frameProduced(m_generation, m_textureSize);
    return m_generation;
}

QJsonObject HybridTextureHost::frameEnvelope() const {
    // 本地适配 envelope —— generation 是本适配层概念，Qt wire 帧
    // （Qt/src/NativeSceneFrame.cpp:87-119,164-166,195）里没有这个键，不得当成 Qt 协议事实。
    // commands / hits / state 恒为空：HUD 由 Dart 自绘，本类单向，只交付 3D。
    // generation 以 JSON number 承载（C++ 侧仍是 quint64）：消费侧**只做相等比较、不做算术**，
    // 超过 2^53 后 double 不再逐位精确，这是 JSON 兼容的代价。
    return QJsonObject{{"generation", double(m_generation)},
                       {"frame", m_lastFrame},
                       {"commands", QJsonArray{}},
                       {"hits", QJsonArray{}},
                       {"state", QJsonObject{}}};
}

void HybridTextureHost::release() {
    const bool wasAttached = m_attached;
    teardown();
    if (wasAttached) {
        // 只在真正发生拆卸的那一次发信号：重复 release 保持静默（幂等）。
        emit released();
    }
}

void HybridTextureHost::teardown() {
    // 未完成旋转的回正必须在「未附着早退」之前：rotate() 允许在 attach 前调用，
    // 若放在早退之后，这类 pending 会永久残留，下一次附着就带着半程角度（plan 行491）。
    // 它同时保证「先 rotate 再 release」是可回退点：角度回到 0，且不发 released()、不计数。
    if (m_rotationPending) {
        m_rotation = 0.0;
        m_rotationPending = false;
    }
    if (!m_attached) {
        // 已拆卸或从未附着：不重复计数、不覆盖任何状态、不重复发信号（release 幂等）。
        return;
    }
    m_attached = false;
    m_textureSize = QSize();
    m_lastFrame = QJsonObject();
    ++m_teardownCount;  // 只在真正发生拆卸时 +1
    // 保留 m_logicalWidth/m_logicalHeight/m_devicePixelRatio/m_stage*/m_generation：
    // 它们是几何与代次记录，不是引擎状态；重新 setSurface 即可再次附着（可回退点）。
}

QStringList HybridTextureHost::qtWireFrameKeyOrder() {
    // 镜像 Qt 源事实 Qt/src/NativeSceneFrame.cpp:87-119 的 31 个基础键及其写入顺序
    // （已逐项核对，不得增删/重排）。同一 emit 随后追加 actorTemplate / appearanceRevision /
    // actors（:164-166）与 stats（:195），故**写入点**顶层键为 35。
    // 键数边界（T14-C18-CONTRACT frameKeysAdjudication.threeLayerMechanism_v3，
    // supersedes frozenRuling / frozenRuling_v2）：
    //   写入点 35 → NativeCards::expand 成功时覆写 draws 并 remove actorTemplate/actors
    //   （NativeCards.cpp:236-237 Darwin、:303-304 非 Darwin）⇒ NativeScene::sample 返回帧 33；
    //   expand 校验失败提前 return（:160-162 / :253-255）时两键不删 ⇒ 该路径 35。
    //   引擎/渲染消费点还会继续加键：Engine.cpp:1143 取 scene.frame，:1248 每帧无条件写 discAngle，
    //   :1196-1199 条件写 jitter，:1203-1204 条件写 temporalReset；RhiScene.cpp:3883-3885 再写
    //   opticalLightEnabled / geometryRevision ⇒ 至少 36 键（expand 失败路径至少 38）。
    // 33 只是「sample 成功返回路径」的交付集，不是契约冻结的固定键数；消费者禁断言键数/键序。
    // 字段清单由 T03 从 RhiScene/Engine 边界冻结（plan:212），本类只镜像写入点的 31 个字面键，
    // 已上报 T10/T16，不裁决总数、不改契约。
    // QJsonObject 序列化按键排序，故此顺序只是源文件写入顺序，不是线上字节顺序。
    return QStringList{
        QStringLiteral("pendingAnimations"),  QStringLiteral("pointerCursor"),
        QStringLiteral("aoProjection"),       QStringLiteral("reference"),
        QStringLiteral("near"),               QStringLiteral("far"),
        QStringLiteral("viewer"),             QStringLiteral("viewerReady"),
        QStringLiteral("viewerState"),        QStringLiteral("mode"),
        QStringLiteral("selected"),           QStringLiteral("culledCards"),
        QStringLiteral("shadowCards"),        QStringLiteral("returningCards"),
        QStringLiteral("returningPartNodes"), QStringLiteral("globalSubdued"),
        QStringLiteral("returningMusicKeys"), QStringLiteral("returningAgeMax"),
        QStringLiteral("time"),               QStringLiteral("draws"),
        QStringLiteral("view"),               QStringLiteral("projection"),
        QStringLiteral("eye"),                QStringLiteral("background"),
        QStringLiteral("fogColor"),           QStringLiteral("fogNear"),
        QStringLiteral("fogFar"),             QStringLiteral("detail"),
        QStringLiteral("boot"),               QStringLiteral("focus"),
        QStringLiteral("aperture"),
    };
}
