/// NodeHostBridgeChannel 的行为测试：真实 loopback socket + 可注入假原生平台。
///
/// 只写不跑；本文件不依赖 Android，也不启动真实 NodeHost。
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

import 'package:rhine_music_database/bootstrap/node_host_bridge_channel.dart';
import 'package:rhine_music_database/bootstrap/node_host_platform.dart';
import 'package:rhine_music_database/bridge/bridge_types.dart';
import 'package:rhine_music_database/features/accounts/domain/account_scope.dart';

void main() {
  late _FakeNodeHostPlatform platform;
  late NodeHostBridgeChannel channel;
  late List<String> logs;
  late StreamController<String> logStream;

  setUp(() {
    platform = _FakeNodeHostPlatform();
    logs = <String>[];
    logStream = StreamController<String>.broadcast();
    channel = NodeHostBridgeChannel(
      platform: platform,
      edition: KugouEdition.standard,
      log: (String message) {
        logs.add(message);
        logStream.add(message);
      },
    );
  });

  tearDown(() async {
    await channel.close();
    await platform.close();
    await logStream.close();
  });

  test('start 绑定回环端口，先认证 token，再发送 start/env', () async {
    final Future<BridgeLifecycleEvent> ready = channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) => event.kind == BridgeLifecycleKind.ready,
    );
    final Future<void> startFuture = channel.start();
    final _StartRequest request =
        await platform.firstStart.future.timeout(const Duration(seconds: 2));
    expect(request.port, inInclusiveRange(1, 65535));
    expect(NodeHostNativeToken.isValid(request.token), isTrue);

    final Socket socket = await Socket.connect(
      InternetAddress.loopbackIPv4,
      request.port,
    );
    addTearDown(socket.destroy);
    final _LineReader reader = _LineReader(socket);
    socket.add(_frame(<String, Object?>{'token': request.token}));

    final Map<String, Object?> startFrame = await reader.next();
    expect(startFrame['type'], 'start');
    expect(startFrame['script'], platform.prepared.workerPath);
    final Map<String, Object?> env = _stringMap(startFrame['env']);
    expect(env, <String, Object?>{
      'TMPDIR': platform.prepared.tmpDir,
      'RHINE_QQ_DEVICE_STATE_PATH': platform.prepared.qqStatePath,
      'RHINE_KUGOU_DEVICE_STATE_PATH': platform.prepared.kugouStatePath,
      'RHINE_KUGOU_EDITION': 'standard',
    });
    final Object? session = startFrame['session'];
    expect(session, isA<String>());
    expect(channel.sessionId, session);
    expect(channel.generation, 1);

    socket.add(_frame(<String, Object?>{
      'type': 'started',
      'session': session,
    }));
    await startFuture.timeout(const Duration(seconds: 2));
    await ready.timeout(const Duration(seconds: 2));
    expect(channel.isReady, isTrue);
    expect(platform.startRequests, hasLength(1));
    await reader.cancel();
  });

  test('错误 token 被丢弃，且不发送 start；随后合法连接仍可握手', () async {
    final Future<void> startFuture = channel.start();
    final _StartRequest request =
        await platform.firstStart.future.timeout(const Duration(seconds: 2));

    final Socket bad = await Socket.connect(
      InternetAddress.loopbackIPv4,
      request.port,
    );
    final _LineReader badReader = _LineReader(bad);
    bad.add(_frame(<String, Object?>{
      'token': 'x' * request.token.length,
    }));
    expect(
      await badReader.nextOrDone(timeout: const Duration(seconds: 2)),
      isFalse,
      reason: '错误 token 的 candidate 必须被关闭，不能收到 start',
    );
    await badReader.cancel();

    final Socket good = await Socket.connect(
      InternetAddress.loopbackIPv4,
      request.port,
    );
    addTearDown(good.destroy);
    final _LineReader goodReader = _LineReader(good);
    good.add(_frame(<String, Object?>{'token': request.token}));
    final Map<String, Object?> startFrame = await goodReader.next();
    expect(startFrame['type'], 'start');
    final Object? session = startFrame['session'];
    expect(session, isA<String>());
    good.add(_frame(<String, Object?>{
      'type': 'started',
      'session': session,
    }));
    await startFuture.timeout(const Duration(seconds: 2));
    expect(channel.isReady, isTrue);
    await goodReader.cancel();
  });

  test('send 编码 base64(JSON + 换行)', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    channel.send(<String, Object?>{
      'id': 7,
      'route': 'song',
      'params': <String, Object?>{'id': 'abc'},
    });
    final Map<String, Object?> frame = await ready.reader.next();
    expect(frame['type'], 'input');
    expect(frame['session'], ready.session);
    final String data = frame['data']! as String;
    final String decoded = utf8.decode(base64Decode(data));
    expect(decoded.endsWith('\n'), isTrue);
    expect(jsonDecode(decoded), <String, Object?>{
      'id': 7,
      'route': 'song',
      'params': <String, Object?>{'id': 'abc'},
    });
    await ready.reader.cancel();
  });

  test('output 跨帧拼接为完整 NDJSON 后才交付 envelope', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<BridgeEnvelope> envelopeFuture = channel.envelopes.first;

    // 第一段没有换行，第二段补齐 body 与换行后才应交付。
    ready.socket.add(_outputFrame(ready.session, '{"id":1,'));
    ready.socket.add(_outputFrame(ready.session, '"body":{"ok":true}}\n'));

    final BridgeEnvelope envelope = await envelopeFuture.timeout(
      const Duration(seconds: 2),
    );
    expect(envelope.id, 1);
    expect(envelope.body['ok'], isTrue);
    await ready.reader.cancel();
  });

  test('worker 退出后保留 runtime；再次 start 只重发 start，不重开原生', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<BridgeLifecycleEvent> exited = channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) =>
          event.kind == BridgeLifecycleKind.workerExited,
    );
    ready.socket.add(_frame(<String, Object?>{
      'type': 'finished',
      'session': ready.session,
      'exitCode': 1,
    }));
    await exited.timeout(const Duration(seconds: 2));
    expect(channel.isReady, isFalse);
    expect(channel.isFatal, isFalse);

    final Future<BridgeLifecycleEvent> readyAgain =
        channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) => event.kind == BridgeLifecycleKind.ready,
    );
    final Future<void> startAgain = channel.start();
    final Map<String, Object?> startFrame = await ready.reader.next();
    expect(startFrame['type'], 'start');
    expect(startFrame['session'], ready.session);
    ready.socket.add(_frame(<String, Object?>{
      'type': 'started',
      'session': ready.session,
    }));
    await startAgain.timeout(const Duration(seconds: 2));
    await readyAgain.timeout(const Duration(seconds: 2));
    expect(platform.startRequests, hasLength(1));
    expect(channel.isReady, isTrue);
    await ready.reader.cancel();
  });

  test('restart 发送旧 session 的 stop，再发送新 session 的 start', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<BridgeLifecycleEvent> readyAgain =
        channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) => event.kind == BridgeLifecycleKind.ready,
    );

    final Future<void> restartFuture = channel.restart();
    final Map<String, Object?> stopFrame = await ready.reader.next();
    expect(stopFrame['type'], 'stop');
    expect(stopFrame['session'], ready.session);

    final Map<String, Object?> startFrame = await ready.reader.next();
    expect(startFrame['type'], 'start');
    final Object? nextSession = startFrame['session'];
    expect(nextSession, isA<String>());
    expect(nextSession, isNot(ready.session));

    ready.socket.add(_frame(<String, Object?>{
      'type': 'started',
      'session': nextSession,
    }));
    await restartFuture.timeout(const Duration(seconds: 2));
    await readyAgain.timeout(const Duration(seconds: 2));
    expect(channel.generation, 2);
    expect(channel.sessionId, nextSession);
    await ready.reader.cancel();
  });

  test('setEdition 未启动时只更新配置，不调用原生 start', () async {
    await channel.setEdition(KugouEdition.concept);
    expect(platform.startRequests, isEmpty);
    expect(channel.generation, 0);
    expect(channel.isReady, isFalse);
  });

  test('setEdition 在同一 runtime 切 edition，新 start 带 lite', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<BridgeLifecycleEvent> readyAgain =
        channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) => event.kind == BridgeLifecycleKind.ready,
    );

    final Future<void> editionFuture = channel.setEdition(KugouEdition.concept);
    final Map<String, Object?> stopFrame = await ready.reader.next();
    expect(stopFrame['type'], 'stop');
    expect(stopFrame['session'], ready.session);

    final Map<String, Object?> startFrame = await ready.reader.next();
    expect(startFrame['type'], 'start');
    final Map<String, Object?> env = _stringMap(startFrame['env']);
    expect(env['RHINE_KUGOU_EDITION'], 'lite');
    final Object? nextSession = startFrame['session'];
    expect(nextSession, isA<String>());
    expect(nextSession, isNot(ready.session));

    ready.socket.add(_frame(<String, Object?>{
      'type': 'started',
      'session': nextSession,
    }));
    await editionFuture.timeout(const Duration(seconds: 2));
    await readyAgain.timeout(const Duration(seconds: 2));
    expect(channel.generation, 2);
    expect(channel.sessionId, nextSession);
    await ready.reader.cancel();
  });

  test('native runtime-exited 进入 fatal，永久拒绝 start', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<BridgeLifecycleEvent> fatal = channel.lifecycle.firstWhere(
      (BridgeLifecycleEvent event) =>
          event.kind == BridgeLifecycleKind.runtimeExited,
    );
    platform.emit(const NodeHostRuntimeEvent(
      type: NodeHostEventType.runtimeExited,
      exitCode: 137,
    ));
    await fatal.timeout(const Duration(seconds: 2));
    expect(channel.isFatal, isTrue);
    expect(channel.isReady, isFalse);

    await expectLater(
      Future<void>.sync(() async {
        await channel.start();
      }),
      throwsA(
        isA<NodeHostBridgeException>()
            .having((NodeHostBridgeException error) => error.code, 'code', 'runtime_exited'),
      ),
    );
    await ready.reader.cancel();
  });

  test('close 幂等，并使后续 start 以 closed 失败', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    await channel.close();
    await channel.close();
    expect(channel.isClosed, isTrue);
    await expectLater(
      Future<void>.sync(() async {
        await channel.start();
      }),
      throwsA(
        isA<NodeHostBridgeException>()
            .having((NodeHostBridgeException error) => error.code, 'code', 'closed'),
      ),
    );
    await ready.reader.cancel();
  });

  test('system-trust 请求解析，respond 回传当前 session/id', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final Future<NodeHostSystemTrustRequest> requestFuture =
        channel.systemTrustRequests.first;
    ready.socket.add(_frame(<String, Object?>{
      'type': 'system-trust',
      'session': ready.session,
      'id': 'trust-1',
      'hostname': 'example.com',
      'certificates': <String>['CERT'],
    }));
    final NodeHostSystemTrustRequest request = await requestFuture.timeout(
      const Duration(seconds: 2),
    );
    expect(request.session, ready.session);
    expect(request.id, 'trust-1');
    expect(request.hostname, 'example.com');
    expect(request.certificates, <String>['CERT']);

    channel.respondSystemTrust(request, trusted: true);
    final Map<String, Object?> response = await ready.reader.next();
    expect(response['type'], 'system-trust-result');
    expect(response['session'], ready.session);
    expect(response['id'], 'trust-1');
    expect(response['trusted'], isTrue);
    await ready.reader.cancel();
  });

  test('stderr 脱敏 token 与 Authorization/Cookie/密码，不打印原文', () async {
    final _ReadySocket ready = await _openReady();
    addTearDown(ready.socket.destroy);
    final String token = platform.startRequests.single.token;
    final Future<String> logLine = logStream.stream.firstWhere(
      (String line) => line.contains('nodehost worker stderr:'),
    );
    ready.socket.add(_stderrFrame(
      ready.session,
      'Authorization: Bearer supersecret\n'
      'Cookie: MUSIC_U=abc; qqmusic_key=def\n'
      'password=hunter2\n'
      'opaque ' + token + '\n',
    ));
    final String line = await logLine.timeout(const Duration(seconds: 2));
    expect(line, contains('Authorization=[redacted]'));
    expect(line, contains('Cookie=[redacted]'));
    expect(line, contains('password=[redacted]'));
    expect(line, contains('[redacted-token]'));
    expect(logs.join('\n'), isNot(contains('supersecret')));
    expect(logs.join('\n'), isNot(contains('hunter2')));
    await ready.reader.cancel();
  });

  test('status 不是 READY 时不调用原生 start', () async {
    platform.status = _status(
      state: NodeHostNativeState.preparing,
      nativeLoaded: true,
    );
    await expectLater(
      channel.start(),
      throwsA(
        isA<NodeHostBridgeException>()
            .having((NodeHostBridgeException error) => error.code, 'code', 'not_prepared'),
      ),
    );
    expect(platform.startRequests, isEmpty);
    expect(channel.wiringStatus, '启动失败');
  });

  test('status 为 exited/failed 时进入 fatal', () async {
    platform.status = _status(
      state: NodeHostNativeState.exited,
      nativeLoaded: true,
    );
    await expectLater(
      channel.start(),
      throwsA(
        isA<NodeHostBridgeException>()
            .having((NodeHostBridgeException error) => error.code, 'code', 'runtime_exited'),
      ),
    );
    expect(channel.isFatal, isTrue);
    expect(platform.startRequests, isEmpty);
  });

  Future<_ReadySocket> _openReady() async {
    final Future<void> startFuture = channel.start();
    final _StartRequest request =
        await platform.firstStart.future.timeout(const Duration(seconds: 2));
    final Socket socket = await Socket.connect(
      InternetAddress.loopbackIPv4,
      request.port,
    );
    final _LineReader reader = _LineReader(socket);
    socket.add(_frame(<String, Object?>{'token': request.token}));
    final Map<String, Object?> startFrame = await reader.next();
    final Object? session = startFrame['session'];
    expect(session, isA<String>());
    socket.add(_frame(<String, Object?>{
      'type': 'started',
      'session': session,
    }));
    await startFuture.timeout(const Duration(seconds: 2));
    return _ReadySocket(socket, reader, session as String);
  }
}

final class _FakeNodeHostPlatform implements NodeHostPlatform {
  _FakeNodeHostPlatform()
      : prepared = _prepared(),
        status = _status();

  NodeHostNativePrepared prepared;
  NodeHostNativeStatus status;
  final List<_StartRequest> startRequests = <_StartRequest>[];
  final Completer<_StartRequest> firstStart = Completer<_StartRequest>();
  final StreamController<NodeHostRuntimeEvent> _events =
      StreamController<NodeHostRuntimeEvent>.broadcast();

  int prepareCalls = 0;

  @override
  Future<NodeHostNativePrepared> prepare() async {
    prepareCalls += 1;
    return prepared;
  }

  @override
  Future<void> start({required int port, required String token}) async {
    final _StartRequest request = _StartRequest(port, token);
    startRequests.add(request);
    if (!firstStart.isCompleted) {
      firstStart.complete(request);
    }
  }

  @override
  Future<NodeHostNativeStatus> status() async => status;

  @override
  Stream<NodeHostRuntimeEvent> get events => _events.stream;

  void emit(NodeHostRuntimeEvent event) {
    _events.add(event);
  }

  Future<void> close() => _events.close();
}

final class _StartRequest {
  const _StartRequest(this.port, this.token);

  final int port;
  final String token;
}

final class _ReadySocket {
  const _ReadySocket(this.socket, this.reader, this.session);

  final Socket socket;
  final _LineReader reader;
  final String session;
}

final class _LineReader {
  _LineReader(Socket socket)
      : _iterator = StreamIterator<String>(
          socket.transform(utf8.decoder).transform(const LineSplitter()),
        );

  final StreamIterator<String> _iterator;

  Future<Map<String, Object?>> next({
    Duration timeout = const Duration(seconds: 3),
  }) async {
    final bool hasNext =
        await _iterator.moveNext().timeout(timeout);
    expect(hasNext, isTrue, reason: '连接提前关闭或没有等到下一帧');
    final Object? decoded = jsonDecode(_iterator.current);
    expect(decoded, isA<Map<Object?, Object?>>());
    return _stringMap(decoded);
  }

  Future<bool> nextOrDone({
    Duration timeout = const Duration(seconds: 3),
  }) =>
      _iterator.moveNext().timeout(timeout);

  Future<void> cancel() => _iterator.cancel();
}

NodeHostNativePrepared _prepared() => const NodeHostNativePrepared(
      root: '/data/root',
      scriptPath: '/data/root/ios-runtime.cjs',
      workerPath: '/data/root/worker.cjs',
      tmpDir: '/data/root/tmp',
      qqStatePath: '/data/root/qq-state',
      kugouStatePath: '/data/root/kugou-state',
      bundleVersion: '1.0.0',
      versionCode: 1,
    );

NodeHostNativeStatus _status({
  NodeHostNativeState state = NodeHostNativeState.ready,
  bool nativeLoaded = true,
  bool nativeRunning = false,
}) =>
    NodeHostNativeStatus(
      state: state,
      nativeLoaded: nativeLoaded,
      nativeRunning: nativeRunning,
      lastExitCode: null,
      port: null,
      bundleVersion: '1.0.0',
      versionCode: 1,
      root: '/data/root',
      scriptPath: '/data/root/ios-runtime.cjs',
    );

Uint8List _frame(Map<String, Object?> message) =>
    Uint8List.fromList(utf8.encode(jsonEncode(message) + '\n'));

Uint8List _outputFrame(String session, String text) => _frame(<String, Object?>{
      'type': 'output',
      'session': session,
      'data': base64Encode(utf8.encode(text)),
    });

Uint8List _stderrFrame(String session, String text) => _frame(<String, Object?>{
      'type': 'stderr',
      'session': session,
      'data': base64Encode(utf8.encode(text)),
    });

Map<String, Object?> _stringMap(Object? value) {
  expect(value, isA<Map<Object?, Object?>>());
  final Map<Object?, Object?> map = value! as Map<Object?, Object?>;
  return map.map<String, Object?>(
    (Object? key, Object? item) => MapEntry<String, Object?>(key.toString(), item),
  );
}
