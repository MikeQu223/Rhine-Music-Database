/// 真实的 NodeHost 传输：Dart 绑定回环端口，原生启动 Node runtime，runtime 反连
/// 并通过 token 握手；握手成功后由本类发送 worker start 帧、转发 input、接收 output。
///
/// 协议来源（只读）：
/// - `android/app/src/main/kotlin/rhine/music/database/node/NodeHost.kt`
/// - `MusicBridge/ios-runtime.cjs`
/// - `MusicBridge/worker.cjs`
/// - `Qt/src/BridgeProcessAndroid.cpp`
///
/// 本类不实现 stub：没有原生 `prepare()` 返回的路径就不启动；没有完成 token
/// 握手就不发送 `start`（env 只在 start 帧里出现）。
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../bridge/bridge_types.dart';
import '../features/accounts/domain/account_scope.dart';
import 'bridge_frame_decoder.dart';
import 'node_host_platform.dart';
import 'worker_output_decoder.dart';

/// 日志回调；生产默认写 Android logcat（`debugPrint`），测试可注入收集器。
typedef NodeHostLogSink = void Function(String message);

/// 通道自身的失败；`code` 与原生错误码或传输阶段对应。
final class NodeHostBridgeException implements Exception {
  const NodeHostBridgeException(this.code, this.message, {this.cause});

  final String code;
  final String message;
  final Object? cause;

  @override
  String toString() => 'NodeHostBridgeException($code): $message';
}

/// iOS 系统信任请求；Android 不安装 ios-system-trust.cjs，实际不会产生。
final class NodeHostSystemTrustRequest {
  const NodeHostSystemTrustRequest({
    required this.session,
    required this.id,
    required this.hostname,
    required this.certificates,
    required this.raw,
  });

  final String? session;
  final String id;
  final String hostname;
  final List<String> certificates;
  final Map<String, Object?> raw;
}

/// 真实桥接通道；生命周期由 [BridgeCoordinator] 负责。
final class NodeHostBridgeChannel implements BridgeChannel {
  NodeHostBridgeChannel({
    required NodeHostPlatform platform,
    required KugouEdition edition,
    NodeHostLogSink? log,
    WorkerOutputDecoder? outputDecoder,
    this.connectionTimeout = const Duration(seconds: 15),
    this.handshakeTimeout = const Duration(seconds: 10),
    this.workerStartTimeout = const Duration(seconds: 30),
    this.shutdownTimeout = const Duration(seconds: 5),
  })  : _platform = platform,
        _edition = edition,
        _log = log ?? _defaultLog,
        _outputDecoder = outputDecoder ?? WorkerOutputDecoder();

  final NodeHostPlatform _platform;
  KugouEdition _edition;
  final NodeHostLogSink _log;
  final WorkerOutputDecoder _outputDecoder;

  final Duration connectionTimeout;
  final Duration handshakeTimeout;
  final Duration workerStartTimeout;
  final Duration shutdownTimeout;

  final StreamController<BridgeEnvelope> _envelopes =
      StreamController<BridgeEnvelope>.broadcast();
  final StreamController<BridgeLifecycleEvent> _lifecycle =
      StreamController<BridgeLifecycleEvent>.broadcast();
  final StreamController<NodeHostSystemTrustRequest> _systemTrustRequests =
      StreamController<NodeHostSystemTrustRequest>.broadcast();

  ServerSocket? _server;
  StreamSubscription<Socket>? _serverSubscription;
  Socket? _candidate;
  Socket? _socket;
  StreamSubscription<Uint8List>? _socketSubscription;
  StreamSubscription<NodeHostRuntimeEvent>? _nativeEvents;
  BridgeFrameDecoder? _candidateDecoder;
  BridgeFrameDecoder? _frameDecoder;

  Timer? _connectionTimer;
  Timer? _handshakeTimer;
  Timer? _workerStartTimer;

  Completer<void>? _connectionCompleter;
  Completer<void>? _workerStartCompleter;
  Completer<void>? _startCompleter;
  Completer<void>? _restartCompleter;

  Future<void>? _startFuture;
  Future<void>? _restartFuture;
  Future<void>? _closeFuture;

  NodeHostNativePrepared? _prepared;
  String? _token;
  String? _session;
  String _wiringStatus = '未启动';
  String _wiringDetail = '尚未调用 start()';

  bool _authenticated = false;
  bool _ready = false;
  bool _fatal = false;
  bool _closed = false;
  int _generation = 0;

  @override
  Stream<BridgeEnvelope> get envelopes => _envelopes.stream;

  @override
  Stream<BridgeLifecycleEvent> get lifecycle => _lifecycle.stream;

  Stream<NodeHostSystemTrustRequest> get systemTrustRequests =>
      _systemTrustRequests.stream;

  String? get sessionId => _session;

  int get generation => _generation;

  bool get isReady => _ready;

  bool get isClosed => _closed;

  bool get isFatal => _fatal;

  String get wiringStatus => _wiringStatus;

  String get wiringDetail => _wiringDetail;

  /// 读取原生状态；不改变通道状态，供诊断页使用。
  Future<NodeHostNativeStatus> status() => _platform.status();

  /// 启动原生 runtime 与第一个 worker。重复调用共享同一个 Future。
  Future<void> start() {
    _throwIfUnavailable();
    final Future<void>? restart = _restartFuture;
    if (restart != null) {
      return restart;
    }
    if (_ready) {
      _emitReady();
      return Future<void>.value();
    }
    final Future<void>? pending = _startFuture;
    if (pending != null) {
      return pending;
    }
    final Completer<void> completer = Completer<void>();
    _startCompleter = completer;
    _startFuture = completer.future;
    unawaited(_runStart(completer));
    return completer.future;
  }

  /// 切换酷狗 edition；同一物理 runtime 只更新后续 start 帧的 env。
  ///
  /// 未启动时只改内存配置，下一次 start 使用新值；已有认证连接时向同一
  /// runtime 发 stop + 新 start（新 session），不会再次调用原生 start()。
  /// 相同的 edition 幂等，不触发 worker 重启。
  Future<void> setEdition(KugouEdition edition) {
    _throwIfUnavailable();
    if (edition == _edition) {
      return Future<void>.value();
    }
    _edition = edition;
    final bool connected = _authenticated && _socket != null;
    if (!connected) {
      return Future<void>.value();
    }
    return restart();
  }

  /// 重启 worker；已有认证连接时向同一 runtime 发 stop + 新 start。
  Future<void> restart() {
    _throwIfUnavailable();
    final Future<void>? pending = _restartFuture;
    if (pending != null) {
      return pending;
    }
    final Completer<void> completer = Completer<void>();
    _restartCompleter = completer;
    _restartFuture = completer.future;
    unawaited(_runRestart(completer));
    return completer.future;
  }

  /// 转发一条 worker 请求；`data=base64(JSON + '\n')`。
  @override
  void send(Map<String, Object?> payload) {
    _throwIfUnavailable();
    if (!_ready || !_authenticated || _socket == null || _session == null) {
      throw const NodeHostBridgeException('not_ready', 'Worker 尚未就绪');
    }
    final Object? id = payload['id'];
    if (id is! int) {
      throw const NodeHostBridgeException('invalid_payload', 'payload 缺少 int id');
    }
    final String line = jsonEncode(payload) + '\n';
    _writeFrame(<String, Object?>{
      'type': 'input',
      'session': _session,
      'data': base64Encode(utf8.encode(line)),
    });
  }

  /// 回应 iOS 系统信任请求；Android 实际不会触发。
  void respondSystemTrust(
    NodeHostSystemTrustRequest request, {
    required bool trusted,
  }) {
    _throwIfUnavailable();
    if (!_ready || !_authenticated || _socket == null || _session == null) {
      throw const NodeHostBridgeException('not_ready', 'Worker 尚未就绪');
    }
    if (request.session != _session) {
      throw const NodeHostBridgeException('stale_request', '系统信任请求不属于当前会话');
    }
    _writeFrame(<String, Object?>{
      'type': 'system-trust-result',
      'session': _session,
      'id': request.id,
      'trusted': trusted,
    });
  }

  /// 关闭通道；使在途启动失败并清理 socket/server/timer，但不等待原生 start 返回。
  @override
  Future<void> close() {
    final Future<void>? pending = _closeFuture;
    if (pending != null) {
      return pending;
    }
    final Completer<void> completer = Completer<void>();
    _closeFuture = completer.future;
    unawaited(_closeInternal(completer));
    return completer.future;
  }

  Future<void> _runStart(Completer<void> done) async {
    try {
      if (_authenticated && _socket != null) {
        await _startWorker();
      } else {
        await _openNativeAndWorker();
      }
      if (!done.isCompleted) {
        done.complete();
      }
    } catch (error, stackTrace) {
      if (!done.isCompleted) {
        done.completeError(_normalizeError(error), stackTrace);
      }
      if (!_closed && !_fatal) {
        final NodeHostBridgeException failure = _normalizeError(error);
        _setWiring('启动失败', failure.message);
        if (!_authenticated) {
          _cleanupAttempt();
        }
      }
    } finally {
      if (identical(_startCompleter, done)) {
        _startCompleter = null;
      }
      if (identical(_startFuture, done.future)) {
        _startFuture = null;
      }
    }
  }

  Future<void> _runRestart(Completer<void> done) async {
    try {
      final Future<void>? start = _startFuture;
      if (start != null) {
        try {
          await start;
        } catch (_) {
          // 启动失败后仍尝试一次完整重建；错误会由下面的路径重新分类。
        }
      }
      _throwIfUnavailable();
      if (_authenticated && _socket != null) {
        await _restartWorkerOnSocket();
      } else {
        await _openNativeAndWorker();
      }
      if (!done.isCompleted) {
        done.complete();
      }
    } catch (error, stackTrace) {
      final NodeHostBridgeException failure = _normalizeError(error);
      if (!_closed && !_fatal) {
        _setWiring('重启失败', failure.message);
      }
      if (!done.isCompleted) {
        done.completeError(failure, stackTrace);
      }
    } finally {
      if (identical(_restartCompleter, done)) {
        _restartCompleter = null;
      }
      if (identical(_restartFuture, done.future)) {
        _restartFuture = null;
      }
    }
  }

  Future<void> _openNativeAndWorker() async {
    _setWiring('启动中', '调用原生 prepare()');
    final NodeHostNativePrepared prepared = await _platform.prepare();
    _throwIfClosed();
    if (!prepared.isComplete) {
      throw const NodeHostBridgeException('prepare_incomplete', 'prepare() 返回的路径不完整');
    }
    _prepared = prepared;

    _setWiring('启动中', '复核原生状态');
    final NodeHostNativeStatus status = await _platform.status();
    _throwIfClosed();
    if (status.isTerminal) {
      _enterFatal('原生 Node runtime 已处于 ' + status.state.wire + ' 状态');
      throw NodeHostBridgeException('runtime_exited', _wiringDetail);
    }
    if (!status.nativeLoaded) {
      throw const NodeHostBridgeException('native_unavailable', 'libnode 未加载');
    }
    if (status.nativeRunning) {
      throw const NodeHostBridgeException('already_running', '已有 Node runtime 在运行，不能重复启动');
    }
    if (!status.canStart) {
      throw NodeHostBridgeException(
        'not_prepared',
        '原生状态尚未 READY（state=' + status.state.wire + '）',
      );
    }

    _listenNativeEvents();
    final ServerSocket server = await ServerSocket.bind(
      InternetAddress.loopbackIPv4,
      0,
    );
    if (_closed) {
      unawaited(server.close().then<void>((_) {}));
      throw _closedError();
    }
    _server = server;
    _token = NodeHostNativeToken.generate();
    _session = _nextSession();
    _authenticated = false;
    _ready = false;
    _candidateDecoder = null;
    _frameDecoder = null;
    _connectionCompleter = _newCompleter();
    _wiringDetail = '等待原生 runtime 连接 127.0.0.1:' + server.port.toString();
    _serverSubscription = server.listen(
      _onCandidate,
      onError: _onServerError,
    );
    _connectionTimer = Timer(connectionTimeout, () {
      _failConnection(
        NodeHostBridgeException(
          'connection_timeout',
          '等待 Node runtime 连接超时（' + connectionTimeout.toString() + '）',
        ),
      );
    });

    _setWiring('启动中', '原生 start(port=' + server.port.toString() + ')');
    try {
      await _platform.start(port: server.port, token: _token!).timeout(connectionTimeout);
    } on TimeoutException {
      throw NodeHostBridgeException(
        'connection_timeout',
        '原生 start 超时（' + connectionTimeout.toString() + '）',
      );
    }
    _throwIfClosed();
    await _connectionCompleter!.future;
    _throwIfClosed();
    await _startWorker();
  }

  void _onCandidate(Socket socket) {
    if (_closed || _fatal || _authenticated || _candidate != null) {
      socket.destroy();
      return;
    }
    final BridgeFrameDecoder decoder = BridgeFrameDecoder(
      session: _session,
      requireHandshake: true,
    );
    _candidate = socket;
    _candidateDecoder = decoder;
    _armHandshakeTimer();
    _socketSubscription = socket.listen(
      (Uint8List data) => _onCandidateData(socket, decoder, data),
      onError: (Object error, StackTrace stackTrace) => _onSocketError(socket, error),
      onDone: () => _onSocketDone(socket),
    );
  }

  void _onCandidateData(
    Socket socket,
    BridgeFrameDecoder decoder,
    Uint8List data,
  ) {
    if (_closed || _fatal) {
      return;
    }
    if (!identical(_candidate, socket) && !identical(_socket, socket)) {
      return;
    }
    final List<BridgeRuntimeFrame> frames;
    try {
      frames = decoder.add(data);
    } on StateError {
      _dropCandidate();
      _failConnection(const NodeHostBridgeException('protocol_error', '握手帧解码器已终止'));
      return;
    }
    for (final BridgeRuntimeFrame frame in frames) {
      if (frame is BridgeHandshakeFrame) {
        if (!_constantTimeEquals(frame.token, _token ?? '')) {
          _log('nodehost: 拒绝 token 不匹配的回环连接');
          _dropCandidate();
          continue;
        }
        _acceptCandidate(socket, decoder);
        continue;
      }
      if (!_authenticated || !identical(_socket, socket)) {
        _dropCandidate();
        return;
      }
      _handleFrame(frame);
    }
  }

  void _acceptCandidate(Socket socket, BridgeFrameDecoder decoder) {
    _handshakeTimer?.cancel();
    _handshakeTimer = null;
    _connectionTimer?.cancel();
    _connectionTimer = null;
    _authenticated = true;
    _socket = socket;
    _candidate = null;
    _candidateDecoder = null;
    _frameDecoder = decoder;
    _setWiring('握手中', '回环连接已认证，等待 Worker start');

    final StreamSubscription<Socket>? serverSubscription = _serverSubscription;
    _serverSubscription = null;
    unawaited(serverSubscription?.cancel());
    final ServerSocket? server = _server;
    _server = null;
    if (server != null) {
      unawaited(server.close().then<void>((_) {}));
    }
    final Completer<void>? connection = _connectionCompleter;
    if (connection != null && !connection.isCompleted) {
      connection.complete();
    }
  }

  void _dropCandidate() {
    final Socket? socket = _candidate;
    _candidate = null;
    _candidateDecoder = null;
    _handshakeTimer?.cancel();
    _handshakeTimer = null;
    unawaited(_socketSubscription?.cancel());
    _socketSubscription = null;
    socket?.destroy();
  }

  void _armHandshakeTimer() {
    _handshakeTimer?.cancel();
    _handshakeTimer = Timer(handshakeTimeout, () {
      if (_authenticated || _candidate == null) {
        return;
      }
      _dropCandidate();
      _failConnection(
        NodeHostBridgeException(
          'handshake_timeout',
          '等待 token 握手超时（' + handshakeTimeout.toString() + '）',
        ),
      );
    });
  }

  void _onSocketDone(Socket socket) {
    if (_closed) {
      return;
    }
    if (identical(_socket, socket)) {
      _enterFatal('Node runtime 回环连接已断开');
    } else if (identical(_candidate, socket)) {
      _dropCandidate();
    }
  }

  void _onSocketError(Socket socket, Object error) {
    if (_closed) {
      return;
    }
    _log('nodehost: 回环连接错误: ' + _sanitize(error.toString()));
    if (identical(_socket, socket)) {
      _enterFatal('Node runtime 回环连接错误');
    } else if (identical(_candidate, socket)) {
      _dropCandidate();
    }
  }

  void _onServerError(Object error, StackTrace stackTrace) {
    if (_closed || _fatal) {
      return;
    }
    _failConnection(
      NodeHostBridgeException('server_error', '回环 server 错误: ' + _sanitize(error.toString())),
    );
  }

  void _listenNativeEvents() {
    if (_nativeEvents != null) {
      return;
    }
    _nativeEvents = _platform.events.listen(
      _onNativeEvent,
      onError: (Object error, StackTrace stackTrace) {
        _log('nodehost: 原生事件流错误: ' + _sanitize(error.toString()));
      },
    );
  }

  void _onNativeEvent(NodeHostRuntimeEvent event) {
    if (_closed) {
      return;
    }
    switch (event.type) {
      case NodeHostEventType.runtimeExited:
        final int? code = event.exitCode;
        _enterFatal('Node runtime 已退出' + (code == null ? '' : '（code=' + code.toString() + '）'));
        break;
      case NodeHostEventType.runtimeStarted:
        _log('nodehost: 原生 runtime 已启动 port=' + (event.port?.toString() ?? 'unknown'));
        break;
      case NodeHostEventType.prepareFailed:
        _log('nodehost: 原生 prepare 失败: ' + _sanitize(event.message));
        break;
      case NodeHostEventType.prepareStarted:
      case NodeHostEventType.extractProgress:
      case NodeHostEventType.prepareFinished:
      case NodeHostEventType.unknown:
        break;
    }
  }

  Future<void> _startWorker() async {
    _throwIfUnavailable();
    final NodeHostNativePrepared? prepared = _prepared;
    if (!_authenticated || _socket == null) {
      throw const NodeHostBridgeException('not_connected', '没有已认证的回环连接');
    }
    if (prepared == null || !prepared.isComplete) {
      throw const NodeHostBridgeException('prepare_incomplete', '缺少完整的 prepare 结果');
    }
    if (_session == null) {
      throw const NodeHostBridgeException('not_connected', '缺少 worker session');
    }

    _ready = false;
    _setWiring('启动 Worker', '等待 worker started（session=' + _session! + '）');
    final Completer<void> completer = _newCompleter();
    _workerStartCompleter = completer;
    _workerStartTimer = Timer(workerStartTimeout, () {
      _failWorkerStart(
        NodeHostBridgeException(
          'worker_start_timeout',
          '等待 worker started 超时（' + workerStartTimeout.toString() + '）',
        ),
      );
    });
    try {
      _writeFrame(<String, Object?>{
        'type': 'start',
        'session': _session,
        'script': prepared.workerPath,
        'env': <String, Object?>{
          'TMPDIR': prepared.tmpDir,
          'RHINE_QQ_DEVICE_STATE_PATH': prepared.qqStatePath,
          'RHINE_KUGOU_DEVICE_STATE_PATH': prepared.kugouStatePath,
          'RHINE_KUGOU_EDITION': _edition.wire,
        },
        'stderrLog': true,
      });
      await completer.future;
    } finally {
      _workerStartTimer?.cancel();
      _workerStartTimer = null;
      if (identical(_workerStartCompleter, completer)) {
        _workerStartCompleter = null;
      }
    }
  }

  Future<void> _restartWorkerOnSocket() async {
    _throwIfUnavailable();
    _flushOutputDecoder();
    final String? previous = _session;
    if (previous == null || previous.isEmpty) {
      throw const NodeHostBridgeException('not_connected', '缺少旧 worker session');
    }
    final String next = _nextSession();
    _session = next;
    _frameDecoder?.session = next;
    _outputDecoder.reset();
    _ready = false;
    _setWiring('重启 Worker', '旧 session=' + previous + '，新 session=' + next);
    _writeFrame(<String, Object?>{
      'type': 'stop',
      'session': previous,
    });
    await _startWorker();
  }

  void _handleFrame(BridgeRuntimeFrame frame) {
    if (_closed || _fatal) {
      return;
    }
    switch (frame) {
      case BridgeStartedFrame():
        _onWorkerStarted();
      case BridgeOutputFrame(:final Uint8List bytes):
        _onWorkerOutput(bytes);
      case BridgeStderrFrame(:final Uint8List bytes):
        _log('nodehost worker stderr: ' + _sanitize(utf8.decode(bytes, allowMalformed: true)));
      case BridgeErrorFrame(:final String detail):
        _onWorkerError(detail);
      case BridgeFinishedFrame(:final int? exitCode):
        _onWorkerFinished(exitCode);
      case BridgeSystemTrustFrame(:final Map<String, Object?> payload):
        _onSystemTrust(payload);
      case BridgeUnsupportedFrame(:final String type):
        _log('nodehost: 忽略未知运行时帧 type=' + type);
      case BridgeFrameRejected(:final String reason, :final bool terminal):
        if (terminal) {
          _enterFatal('运行时协议终止: ' + reason);
        } else {
          _log('nodehost: 丢弃运行时帧: ' + reason);
        }
      case BridgeHandshakeFrame():
        _log('nodehost: 忽略认证后的重复握手帧');
    }
  }

  void _onWorkerStarted() {
    final Completer<void>? completer = _workerStartCompleter;
    if (completer == null || completer.isCompleted) {
      _log('nodehost: 忽略未请求的 worker started');
      return;
    }
    _workerStartTimer?.cancel();
    _workerStartTimer = null;
    _emitReady();
    completer.complete();
  }

  void _onWorkerOutput(Uint8List bytes) {
    _emitWorkerOutputBatch(_outputDecoder.add(bytes));
  }

  /// 会话结束/重启前把未终止的尾部行交给解码器，避免静默丢失。
  void _flushOutputDecoder() {
    _emitWorkerOutputBatch(_outputDecoder.flush());
  }

  void _emitWorkerOutputBatch(WorkerOutputBatch batch) {
    for (final WorkerOutputRejection rejection in batch.rejections) {
      _log('nodehost: 丢弃 worker 输出行 reason=' +
          rejection.reason.wire +
          ' bytes=' +
          rejection.bytes.toString());
    }
    for (final BridgeEnvelope envelope in batch.envelopes) {
      if (!_envelopes.isClosed) {
        _envelopes.add(envelope);
      }
    }
  }

  void _onWorkerError(String detail) {
    final String sanitized = _sanitize(detail);
    final Completer<void>? completer = _workerStartCompleter;
    if (completer != null && !completer.isCompleted) {
      _failWorkerStart(
        NodeHostBridgeException(
          'worker_error',
          sanitized.isEmpty ? 'worker 启动失败' : sanitized,
        ),
      );
      return;
    }
    _log('nodehost worker error: ' + (sanitized.isEmpty ? 'unknown' : sanitized));
  }

  void _onWorkerFinished(int? exitCode) {
    final Completer<void>? completer = _workerStartCompleter;
    if (completer != null && !completer.isCompleted) {
      _failWorkerStart(
        NodeHostBridgeException(
          'worker_exited',
          'worker 在 started 前退出' + (exitCode == null ? '' : ' code=' + exitCode.toString()),
        ),
      );
      return;
    }
    if (!_ready) {
      _log('nodehost: worker 已退出（当前未就绪）');
      return;
    }
    _ready = false;
    final String detail = 'worker 已退出' + (exitCode == null ? '' : ' code=' + exitCode.toString());
    _setWiring('Worker 已退出', detail);
    _emitLifecycle(BridgeLifecycleKind.workerExited, detail);
  }

  void _onSystemTrust(Map<String, Object?> payload) {
    final Object? id = payload['id'];
    final Object? hostname = payload['hostname'];
    final Object? certificates = payload['certificates'];
    if (id is! String || id.isEmpty || hostname is! String || certificates is! List) {
      _log('nodehost: 丢弃字段不完整的 system-trust 请求');
      return;
    }
    final List<String> parsed = <String>[];
    for (final Object? certificate in certificates) {
      if (certificate is! String) {
        _log('nodehost: 丢弃包含非字符串证书的 system-trust 请求');
        return;
      }
      parsed.add(certificate);
    }
    final NodeHostSystemTrustRequest request = NodeHostSystemTrustRequest(
      session: _session,
      id: id,
      hostname: hostname,
      certificates: List<String>.unmodifiable(parsed),
      raw: Map<String, Object?>.unmodifiable(payload),
    );
    if (!_systemTrustRequests.isClosed) {
      _systemTrustRequests.add(request);
    }
  }

  void _failWorkerStart(Object error) {
    _workerStartTimer?.cancel();
    _workerStartTimer = null;
    final Completer<void>? completer = _workerStartCompleter;
    if (completer != null && !completer.isCompleted) {
      completer.completeError(_normalizeError(error));
    }
  }

  void _writeFrame(Map<String, Object?> frame) {
    final Socket? socket = _socket;
    if (socket == null) {
      throw const NodeHostBridgeException('not_connected', '回环连接不存在');
    }
    try {
      socket.add(utf8.encode(jsonEncode(frame) + '\n'));
    } catch (error) {
      _enterFatal('写入回环连接失败: ' + _sanitize(error.toString()));
      throw NodeHostBridgeException(
        'socket_write_failed',
        _sanitize(error.toString()),
        cause: error,
      );
    }
  }

  void _emitReady() {
    _ready = true;
    _setWiring('已连接', 'Worker 已启动（session=' + (_session ?? '') + '）');
    _emitLifecycle(BridgeLifecycleKind.ready, _wiringDetail);
  }

  void _emitLifecycle(BridgeLifecycleKind kind, String detail) {
    if (!_lifecycle.isClosed) {
      _lifecycle.add(BridgeLifecycleEvent(kind, detail: _sanitize(detail)));
    }
  }

  void _enterFatal(String detail) {
    if (_fatal || _closed) {
      return;
    }
    _fatal = true;
    _ready = false;
    final String reason = _sanitize(detail);
    _setWiring('运行时不可用', reason);
    final NodeHostBridgeException failure =
        NodeHostBridgeException('runtime_exited', reason);
    final Completer<void>? connection = _connectionCompleter;
    if (connection != null && !connection.isCompleted) {
      connection.completeError(failure);
    }
    final Completer<void>? workerStart = _workerStartCompleter;
    if (workerStart != null && !workerStart.isCompleted) {
      workerStart.completeError(failure);
    }
    final Completer<void>? start = _startCompleter;
    if (start != null && !start.isCompleted) {
      start.completeError(failure);
    }
    final Completer<void>? restart = _restartCompleter;
    if (restart != null && !restart.isCompleted) {
      restart.completeError(failure);
    }
    _cancelTimers();
    final ServerSocket? server = _server;
    _server = null;
    unawaited(_serverSubscription?.cancel());
    _serverSubscription = null;
    if (server != null) {
      unawaited(server.close().then<void>((_) {}));
    }
    final Socket? candidate = _candidate;
    _candidate = null;
    _candidateDecoder = null;
    candidate?.destroy();
    final Socket? socket = _socket;
    _socket = null;
    _authenticated = false;
    socket?.destroy();
    unawaited(_socketSubscription?.cancel());
    _socketSubscription = null;
    unawaited(_nativeEvents?.cancel());
    _nativeEvents = null;
    _emitLifecycle(BridgeLifecycleKind.runtimeExited, reason);
  }

  Future<void> _closeInternal(Completer<void> done) async {
    if (_closed) {
      if (!done.isCompleted) {
        done.complete();
      }
      return;
    }
    _closed = true;
    _ready = false;
    _flushOutputDecoder();
    _setWiring('已关闭', '通道已关闭');
    final NodeHostBridgeException failure =
        const NodeHostBridgeException('closed', '通道已关闭');
    final Completer<void>? connection = _connectionCompleter;
    if (connection != null && !connection.isCompleted) {
      connection.completeError(failure);
    }
    final Completer<void>? workerStart = _workerStartCompleter;
    if (workerStart != null && !workerStart.isCompleted) {
      workerStart.completeError(failure);
    }
    final Completer<void>? start = _startCompleter;
    if (start != null && !start.isCompleted) {
      start.completeError(failure);
    }
    final Completer<void>? restart = _restartCompleter;
    if (restart != null && !restart.isCompleted) {
      restart.completeError(failure);
    }
    _cancelTimers();
    final ServerSocket? server = _server;
    _server = null;
    unawaited(_serverSubscription?.cancel());
    _serverSubscription = null;
    if (server != null) {
      unawaited(server.close().then<void>((_) {}));
    }
    final Socket? candidate = _candidate;
    _candidate = null;
    _candidateDecoder = null;
    candidate?.destroy();
    final Socket? socket = _socket;
    _socket = null;
    _authenticated = false;
    unawaited(_socketSubscription?.cancel());
    _socketSubscription = null;
    if (socket != null) {
      try {
        await socket.close().timeout(shutdownTimeout);
      } on Object {
        socket.destroy();
      }
    }
    await _nativeEvents?.cancel();
    _nativeEvents = null;
    await _envelopes.close();
    await _lifecycle.close();
    await _systemTrustRequests.close();
    if (!done.isCompleted) {
      done.complete();
    }
  }

  void _cancelTimers() {
    _connectionTimer?.cancel();
    _connectionTimer = null;
    _handshakeTimer?.cancel();
    _handshakeTimer = null;
    _workerStartTimer?.cancel();
    _workerStartTimer = null;
  }

  void _failConnection(Object error) {
    final Completer<void>? completer = _connectionCompleter;
    if (completer != null && !completer.isCompleted) {
      completer.completeError(_normalizeError(error));
    }
  }

  void _cleanupAttempt() {
    _connectionTimer?.cancel();
    _connectionTimer = null;
    _handshakeTimer?.cancel();
    _handshakeTimer = null;
    final Socket? candidate = _candidate;
    _candidate = null;
    _candidateDecoder = null;
    unawaited(_socketSubscription?.cancel());
    _socketSubscription = null;
    candidate?.destroy();
    final ServerSocket? server = _server;
    _server = null;
    unawaited(_serverSubscription?.cancel());
    _serverSubscription = null;
    if (server != null) {
      unawaited(server.close().then<void>((_) {}));
    }
    _connectionCompleter = null;
    _frameDecoder = null;
    _token = null;
    _session = null;
    _authenticated = false;
    _ready = false;
  }

  Completer<void> _newCompleter() {
    final Completer<void> completer = Completer<void>();
    unawaited(completer.future.catchError((Object _) {}));
    return completer;
  }

  String _nextSession() {
    _generation += 1;
    return 'node-' + DateTime.now().microsecondsSinceEpoch.toString() + '-' + _generation.toString();
  }

  void _setWiring(String status, String detail) {
    _wiringStatus = status;
    _wiringDetail = _sanitize(detail);
  }

  void _throwIfUnavailable() {
    if (_closed) {
      throw _closedError();
    }
    if (_fatal) {
      throw NodeHostBridgeException('runtime_exited', _wiringDetail);
    }
  }

  void _throwIfClosed() {
    if (_closed) {
      throw _closedError();
    }
  }

  NodeHostBridgeException _closedError() =>
      const NodeHostBridgeException('closed', '通道已关闭');

  NodeHostBridgeException _normalizeError(Object error) {
    if (error is NodeHostBridgeException) {
      return error;
    }
    if (error is NodeHostPlatformException) {
      return NodeHostBridgeException(error.code, error.message, cause: error);
    }
    if (error is TimeoutException) {
      return NodeHostBridgeException('timeout', error.toString(), cause: error);
    }
    return NodeHostBridgeException('start_failed', error.toString(), cause: error);
  }

  String _sanitize(String input) {
    String text = input.replaceAll(RegExp(r'\x1B\[[0-?]*[ -/]*[@-~]'), '');
    text = text.replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'), '');
    final String? token = _token;
    if (token != null && token.isNotEmpty) {
      text = text.replaceAll(token, '[redacted-token]');
    }
    // Authorization/Cookie 的值可能带空格（Bearer xxx、多个 cookie），整行脱敏。
    text = text.replaceAll(
      RegExp(
        r'(authorization|cookie|set-cookie)\s*[:=]\s*[^\r\n]*',
        caseSensitive: false,
      ),
      (Match match) => (match[1] ?? 'secret') + '=[redacted]',
    );
    text = text.replaceAll(
      RegExp(
        r'(token|access_token|refresh_token|password|secret|MUSIC_U|qqmusic_key|kugou_token)\s*[:=]\s*[^\s,;]+',
        caseSensitive: false,
      ),
      (Match match) => (match[1] ?? 'secret') + '=[redacted]',
    );
    if (text.length > 4096) {
      return text.substring(0, 4096) + '…';
    }
    return text;
  }

  static bool _constantTimeEquals(String a, String b) {
    if (a.length != b.length) {
      return false;
    }
    int difference = 0;
    for (int index = 0; index < a.length; index += 1) {
      difference |= a.codeUnitAt(index) ^ b.codeUnitAt(index);
    }
    return difference == 0;
  }

  static void _defaultLog(String message) {
    debugPrint('[nodehost] ' + message);
  }
}
