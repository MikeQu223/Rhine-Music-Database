/// 收藏歌单/专辑/歌手栏目：按平台能力展示、分页与错误恢复。
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../../../../domain/models/library_item.dart';
import '../../application/library_controller.dart';
import '../../domain/library_page.dart';
import '../../domain/library_state.dart';
import 'library_status_panel.dart';

class LibraryCollectionPanel extends StatelessWidget {
  const LibraryCollectionPanel({
    super.key,
    required this.section,
    required this.controller,
    this.onOpenPlaylist,
  });

  final LibrarySection section;
  final LibraryController controller;
  final ValueChanged<Playlist>? onOpenPlaylist;

  @override
  Widget build(BuildContext context) {
    final state = controller.state;
    if (!_enabled) {
      return LibraryMessagePanel(
        key: Key('library.collections.' + section.name + '.disabled'),
        icon: Icons.lock_outline,
        title: '当前平台不支持',
        message: '该平台没有提供这个收藏栏目。',
      );
    }

    final page = state.pageOf(section);
    final items = _items(state);
    if (items.isEmpty) {
      if (state.loading) {
        return Center(
          child: CircularProgressIndicator(
            key: Key('library.collections.' + section.name + '.loading'),
          ),
        );
      }
      if (state.error.isNotEmpty) {
        return LibraryErrorPanel(
          key: Key('library.collections.' + section.name + '.error'),
          message: state.error,
          onRetry: () => unawaited(controller.retry()),
        );
      }
      return LibraryMessagePanel(
        key: Key('library.collections.' + section.name + '.empty'),
        icon: _icon,
        title: _emptyTitle,
        message: '收藏的内容会出现在这里。',
      );
    }

    return Column(
      children: <Widget>[
        Expanded(
          child: NotificationListener<ScrollNotification>(
            onNotification: (notification) {
              if (notification.metrics.axis == Axis.vertical &&
                  notification.metrics.extentAfter < 320 &&
                  controller.canLoadMore) {
                unawaited(controller.loadMore());
              }
              return false;
            },
            child: ListView.separated(
              key: Key('library.collections.' + section.name + '.list'),
              padding: const EdgeInsets.only(bottom: 16),
              itemCount: items.length + 1,
              separatorBuilder: (context, index) => const Divider(height: 1),
              itemBuilder: (context, index) {
                if (index == items.length) {
                  return _buildFooter(state, page);
                }
                return _buildTile(context, state, items[index]);
              },
            ),
          ),
        ),
        if (state.error.isNotEmpty)
          LibraryInlineError(
            key: Key('library.collections.' + section.name + '.error.inline'),
            message: state.error,
            onRetry: () => unawaited(controller.retry()),
          ),
      ],
    );
  }

  bool get _enabled {
    switch (section) {
      case LibrarySection.collectedPlaylists:
        return controller.capabilities.canViewPlaylists;
      case LibrarySection.albums:
        return controller.capabilities.canViewCollectedAlbums;
      case LibrarySection.artists:
        return controller.capabilities.canViewCollectedArtists;
      case LibrarySection.liked:
      case LibrarySection.myPlaylists:
      case LibrarySection.playlistTracks:
        return true;
    }
  }

  List<MediaItem> _items(LibraryState state) {
    switch (section) {
      case LibrarySection.collectedPlaylists:
        return state.collectedPlaylists;
      case LibrarySection.albums:
        return state.albums;
      case LibrarySection.artists:
        return state.artists;
      case LibrarySection.liked:
      case LibrarySection.myPlaylists:
      case LibrarySection.playlistTracks:
        return const <MediaItem>[];
    }
  }

  IconData get _icon {
    switch (section) {
      case LibrarySection.albums:
        return Icons.album_outlined;
      case LibrarySection.artists:
        return Icons.person_outline;
      default:
        return Icons.collections_bookmark_outlined;
    }
  }

  String get _emptyTitle {
    switch (section) {
      case LibrarySection.albums:
        return '还没有收藏专辑';
      case LibrarySection.artists:
        return '还没有收藏歌手';
      default:
        return '还没有收藏歌单';
    }
  }

  Widget _buildTile(
    BuildContext context,
    LibraryState state,
    MediaItem item,
  ) {
    if (item is Playlist) {
      return ListTile(
        key: Key('library.collections.' + section.name + '.item.' + item.key),
        leading: const CircleAvatar(child: Icon(Icons.queue_music)),
        title: Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text(item.trackCount.toString() + ' 首'),
        onTap: onOpenPlaylist == null ? null : () => onOpenPlaylist!(item),
      );
    }
    final subtitle = item is Album
        ? item.artist
        : item is ArtistItem
            ? '歌手'
            : '';
    return ListTile(
      key: Key('library.collections.' + section.name + '.item.' + item.key),
      leading: CircleAvatar(child: Icon(_icon)),
      title: Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: subtitle.isEmpty
          ? null
          : Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
    );
  }

  Widget _buildFooter(LibraryState state, LibraryPage<MediaItem> page) {
    if (state.error.isNotEmpty) {
      return Center(
        child: TextButton(
          key: Key('library.collections.' + section.name + '.retry.loadMore'),
          onPressed: () => unawaited(controller.retry()),
          child: const Text('重试加载更多'),
        ),
      );
    }
    if (state.loadingMore) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              key: Key('library.collections.' + section.name + '.loadingMore'),
              strokeWidth: 2,
            ),
          ),
        ),
      );
    }
    if (page.more) {
      return Center(
        child: TextButton(
          key: Key('library.collections.' + section.name + '.loadMore'),
          onPressed: () => unawaited(controller.loadMore()),
          child: const Text('加载更多'),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Center(
        child: Text(
          '没有更多了',
          key: Key('library.collections.' + section.name + '.end'),
        ),
      ),
    );
  }
}
