import 'package:flutter_test/flutter_test.dart';
import 'package:rhine_music_database/features/playback/playback.dart';

void main() {
  group('AudioPlaybackIntent', () {
    test('按 generation 绑定并忽略旧意图', () {
      final intent = AudioPlaybackIntent();
      intent.note(1, requested: false);
      expect(intent.requestedFor(1), isFalse);
      expect(intent.requestedFor(2), isNull);

      intent.note(2, requested: true);
      expect(intent.requestedFor(1), isNull);
      expect(intent.requestedFor(2), isTrue);

      intent.markPaused();
      expect(intent.requestedFor(2), isFalse);
      expect(intent.hasPending, isTrue);

      intent.reset();
      expect(intent.requestedFor(2), isNull);
      expect(intent.hasPending, isFalse);
    });

    test('clear 只清除匹配的 generation', () {
      final intent = AudioPlaybackIntent()..note(7, requested: true);
      intent.clear(8);
      expect(intent.requestedFor(7), isTrue);
      intent.clear(7);
      expect(intent.requestedFor(7), isNull);
    });
  });

  group('AudioLoadIntent', () {
    test('用户暂停意图让 load 以暂停开始且不自动起播', () {
      final intent = AudioLoadIntent.resolve(
        requestStartPaused: false,
        interruptedBeforeLoad: false,
        userRequested: false,
      );
      expect(intent.startPaused, isTrue);
      expect(intent.pauseRequested, isTrue);
      expect(
        intent.shouldPause(
          playRequestedWhileLoading: false,
          pauseRequestedWhileLoading: intent.pauseRequested,
        ),
        isTrue,
      );
    });

    test('准备期间显式 play 覆盖暂停意图', () {
      final intent = AudioLoadIntent.resolve(
        requestStartPaused: false,
        interruptedBeforeLoad: false,
        userRequested: false,
      );
      expect(
        intent.shouldPause(
          playRequestedWhileLoading: true,
          pauseRequestedWhileLoading: intent.pauseRequested,
        ),
        isFalse,
      );
    });

    test('准备期间 pause 压制原本 autoplay', () {
      final intent = AudioLoadIntent.resolve(
        requestStartPaused: false,
        interruptedBeforeLoad: false,
        userRequested: true,
      );
      expect(intent.startPaused, isFalse);
      expect(intent.pauseRequested, isFalse);
      expect(
        intent.shouldPause(
          playRequestedWhileLoading: false,
          pauseRequestedWhileLoading: true,
        ),
        isTrue,
      );
    });

    test('中断在 load 前发生或旧 generation 均不会自动起播', () {
      final interrupted = AudioLoadIntent.resolve(
        requestStartPaused: false,
        interruptedBeforeLoad: true,
        userRequested: null,
      );
      expect(interrupted.startPaused, isTrue);
      expect(interrupted.pauseRequested, isTrue);

      final stale = AudioLoadIntent.resolve(
        requestStartPaused: false,
        interruptedBeforeLoad: false,
        userRequested: null,
      );
      expect(stale.startPaused, isFalse);
      expect(stale.pauseRequested, isFalse);
    });

    test('startPaused 时显式 play 可开始播放', () {
      final intent = AudioLoadIntent.resolve(
        requestStartPaused: true,
        interruptedBeforeLoad: false,
        userRequested: true,
      );
      expect(intent.startPaused, isTrue);
      expect(
        intent.shouldPause(
          playRequestedWhileLoading: true,
          pauseRequestedWhileLoading: intent.pauseRequested,
        ),
        isFalse,
      );
    });
  });
}
