/// Rhine Music Database 的 Flutter 组合根入口。
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../features/accounts/accounts.dart';
import '../features/queue/queue.dart';
import '../features/settings/settings.dart';
import '../scene/scene.dart';
import '../ui/core/components/rhine_components.dart';
import '../ui/core/responsive/rhine_media.dart';
import '../ui/core/responsive/rhine_system_ui.dart';
import '../ui/core/rhine_core.dart';
import 'rhine_composition.dart';
import 'rhine_settings_state.dart';

class RhineApp extends StatefulWidget {
  const RhineApp({super.key, required this.composition});

  final RhineComposition composition;

  @override
  State<RhineApp> createState() => _RhineAppState();
}

class _RhineAppState extends State<RhineApp> {
  late final Future<void> _initialization;

  @override
  void initState() {
    super.initState();
    _initialization = widget.composition.initialize();
  }

  @override
  void dispose() {
    unawaited(widget.composition.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.composition.settingsState,
      builder: (BuildContext context, Widget? _) {
        final RhineSettingsState state = widget.composition.settingsState;
        return MaterialApp(
          title: 'Rhine Music Database',
          debugShowCheckedModeBanner: false,
          theme: RhineTheme.light(
            RhineLayout.fromSize(const Size(390, 844)),
          ),
          darkTheme: RhineTheme.dark(
            RhineLayout.fromSize(const Size(390, 844)),
          ),
          themeMode: state.themeMode,
          builder: (BuildContext context, Widget? child) {
            final MediaQueryData media = MediaQuery.of(context);
            final RhineLayout layout = RhineLayout.fromMediaQuery(media);
            final Brightness brightness = Theme.of(context).brightness;
            return RhineMediaQuery(
              child: Theme(
                data: RhineTheme.data(
                  brightness: brightness,
                  layout: layout,
                ),
                child: child ?? const SizedBox.shrink(),
              ),
            );
          },
          home: FutureBuilder<void>(
            future: _initialization,
            builder: (BuildContext context, AsyncSnapshot<void> snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Scaffold(
                  body: Center(child: RhineLoadingState(label: '正在启动')),
                );
              }
              if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: RhineErrorState(
                        title: '启动失败',
                        message: '${snapshot.error}',
                      ),
                    ),
                  ),
                );
              }
              return RhineHomeShell(composition: widget.composition);
            },
          ),
        );
      },
    );
  }
}

class RhineHomeShell extends StatefulWidget {
  const RhineHomeShell({super.key, required this.composition});

  final RhineComposition composition;

  @override
  State<RhineHomeShell> createState() => _RhineHomeShellState();
}

class _RhineHomeShellState extends State<RhineHomeShell> {
  int _selected = 0;

  static const List<RhineDestination> _destinations = <RhineDestination>[
    RhineDestination(label: '首页', icon: Icons.home_outlined, shortLabel: '首页'),
    RhineDestination(label: '账号', icon: Icons.person_outline, shortLabel: '账号'),
    RhineDestination(label: '设置', icon: Icons.settings_outlined, shortLabel: '设置'),
  ];

  RhineComposition get _composition => widget.composition;

  void _select(int index) {
    if (_selected == index) {
      return;
    }
    setState(() => _selected = index);
  }

  @override
  Widget build(BuildContext context) {
    final RhineColors colors = context.rhineColors;
    final RhineLayout layout = context.rhineLayout;
    return RhineSystemUiScope(
      colors: colors,
      child: Scaffold(
        body: SafeArea(
          bottom: false,
          child: AnimatedBuilder(
            animation: Listenable.merge(<Listenable>[
              _composition.settingsState,
              _composition.session,
              _composition.queue,
            ]),
            builder: (BuildContext context, Widget? _) {
              return Column(
                children: <Widget>[
                  RhineTopBar(
                    libraryName: 'RHINE MUSIC DATABASE',
                    totalLabel: _composition.session.platformLabel,
                    trailing: IconButton(
                      tooltip: '打开设置',
                      onPressed: () => _select(2),
                      icon: const Icon(Icons.tune_outlined),
                    ),
                  ),
                  Expanded(child: _buildBody(context, layout)),
                  RhineNavBar(
                    destinations: _destinations,
                    selectedIndex: _selected,
                    onSelected: _select,
                  ),
                  _buildPlayerBar(context, layout),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, RhineLayout layout) {
    final Widget page = _buildPage(context);
    if (!layout.twoPane) {
      return page;
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Expanded(flex: 5, child: page),
        const VerticalDivider(width: 1),
        Expanded(
          flex: 6,
          child: ColoredBox(
            color: Theme.of(context).scaffoldBackgroundColor,
            child: RhineSceneStage(backends: _composition.scene),
          ),
        ),
      ],
    );
  }

  Widget _buildPage(BuildContext context) {
    switch (_selected) {
      case 1:
        return AccountsScreen(session: _composition.session);
      case 2:
        return SettingsPage(controller: _composition.settings);
      case 0:
      default:
        return _OverviewPage(
          composition: _composition,
          onOpenPage: _select,
        );
    }
  }

  Widget _buildPlayerBar(BuildContext context, RhineLayout layout) {
    final QueueState queue = _composition.queue.state;
    final String? title = queue.currentTrack?.title;
    final String? artist = queue.currentTrack?.artist;
    return RhinePlayerBar(
      title: title ?? '未在播放',
      artist: artist ?? _composition.playback.unavailableReason,
      expanded: layout.isTablet || layout.isLandscape,
      onPlayPause: () => _showPlaybackUnavailable(context),
      onPrevious: () => _showPlaybackUnavailable(context),
      onNext: () => _showPlaybackUnavailable(context),
    );
  }

  void _showPlaybackUnavailable(BuildContext context) {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(
      SnackBar(content: Text(_composition.playback.unavailableReason)),
    );
  }
}

class _OverviewPage extends StatefulWidget {
  const _OverviewPage({required this.composition, required this.onOpenPage});

  final RhineComposition composition;
  final ValueChanged<int> onOpenPage;

  @override
  State<_OverviewPage> createState() => _OverviewPageState();
}

class _OverviewPageState extends State<_OverviewPage> {
  String _bridgeStatus = '未启动（需要 Android 原生 NodeHost）';
  bool _starting = false;

  RhineComposition get _composition => widget.composition;

  Future<void> _startBridge() async {
    if (_starting) {
      return;
    }
    setState(() {
      _starting = true;
      _bridgeStatus = '正在启动…';
    });
    try {
      await _composition.startBridge();
      if (!mounted) {
        return;
      }
      setState(() {
        _starting = false;
        _bridgeStatus = '已连接（回环桥接就绪）';
      });
    } catch (error) {
      if (!mounted) {
        return;
      }
      setState(() {
        _starting = false;
        _bridgeStatus = '启动失败：$error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final String sceneLabel = _composition.scene.registeredBackends
        .map((SceneBackend backend) => backend.kind.name)
        .join(' / ');
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
      children: <Widget>[
        Text('M0 · 组合根', style: theme.textTheme.headlineSmall),
        const SizedBox(height: 6),
        Text(
          '本页只展示真实已接线的能力；网络、音频与 3D 未就绪时明确标记。',
          style: theme.textTheme.bodyMedium,
        ),
        const SizedBox(height: 16),
        Card(
          child: Column(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.cloud_outlined),
                title: const Text('Node 桥接'),
                subtitle: Text(_bridgeStatus),
                trailing: FilledButton(
                  onPressed: _starting ? null : _startBridge,
                  child: Text(_starting ? '启动中' : '启动'),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: const Text('账号'),
                subtitle: Text(
                  '${_composition.session.platformLabel} · ${_composition.session.accountLabel}',
                ),
                trailing: TextButton(
                  onPressed: () => widget.onOpenPage(1),
                  child: const Text('打开'),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.headphones_outlined),
                title: const Text('播放引擎'),
                subtitle: Text(_composition.playback.unavailableReason),
                trailing: Text(
                  _composition.playback.isAvailable ? '已接入' : '未接入',
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.view_in_ar_outlined),
                title: const Text('3D 场景'),
                subtitle: Text('仅注册 $sceneLabel；不提供 GLES / 2D / Qt 回退'),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.tune_outlined),
                title: const Text('偏好存储'),
                subtitle: Text(_composition.preferences.storageLabel),
                trailing: TextButton(
                  onPressed: () => widget.onOpenPage(2),
                  child: const Text('设置'),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Text(
          '账号页使用内存账号缓存；凭据写入由安全存储端口负责，未接入时不会退回明文。',
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }
}
