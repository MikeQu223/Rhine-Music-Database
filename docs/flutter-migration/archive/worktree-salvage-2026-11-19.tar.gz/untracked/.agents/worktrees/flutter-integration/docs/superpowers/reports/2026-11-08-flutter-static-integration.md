# Flutter Android 重构 · 静态集成验收记录

- 日期：2026-11-08
- 工作树：`/home/aibeto/code/Rhine-Music-Database/.agents/worktrees/flutter-integration`
- 分支：`flutter-integration`
- 基线提交：`7edd8ac`（Flutter 工程模板，`lib/main.dart` 为 counter app）
- 本报告父提交：`05b6b1e`
- 方法：**纯静态**。未运行 `flutter` / `dart` / `pub` / `build` / `test` / `analyze` / Gradle / adb / 真机 / 模拟器 / 3D 渲染。

## 1. 结论摘要

1. 本次静态集成共提交 17 个 stage，全部为当前分支 HEAD 的祖先；没有改写他人提交，没有夹带并发执行体的未提交改动。
2. 最终树静态扫描：260 个 `*.dart`（lib + test）import 全部可解析，barrel/export 无悬空目标，`lib/` 顶层重复声明仅剩两处私有 `_CacheEntry`（`lib/bridge/music_gateway.dart`、`lib/data/cache_store.dart`，文件私有、不冲突）。
3. 已消除的编译级问题：队列身份 `.wire` 误用、`Track(provider: MusicProvider.x)` 枚举传 String、`selectedLane` int/String 冲突、`domain/scene_backend.dart` 与 `lib/scene` 同名异义双契约、`QualityOption` 重复定义。
4. 静态集成可合入，但**不是 Gate 通过**：播放引擎、桥接、账号、3D 仍为显式未接线适配器；依赖仍是 `any` 占位且无 lock；全部设备/运行期门禁未执行。

## 2. 提交清单与审查结论

审查均为只读独立 GINKA（`provider=ginka, model=deepseek-v4.1-flash, reasoning=max`），只看 `git show`，不运行 Dart/Flutter。

| stage | 提交 | 标题 | 审查结论 |
| --- | --- | --- | --- |
| 1 | `e7c6095` | build: 登记播放与存储依赖占位并补齐资源审计 | PASS-WITH-NOTES（883e5a05） |
| 2 | `cc35339` | test(gate): 覆盖 M1 会话恢复隔离与本地来源退出标准 | FAIL（55ac0c40）：夹具枚举传 String，编译不过；后由 `3273e97` 修复 |
| 3 | `3a77bae` | fix(domain): 队列身份改用 provider 字符串拼接 | FAIL（5bf5ca03）：身份与 `track.key` 不同域；后由 `a94bdc4` 取代 |
| 4 | `7507cdf` | refactor(domain): 场景契约收敛到 scene 层单一导出面 | FAIL（c4dd69f5）：只删 barrel、双契约仍在；后由 `d3760c1` 完成 |
| 5 | `e218678` | fix(domain): 统一浏览快照选中车道为字符串键 | FAIL（3ac5912d）：键域/旧档语义未定；后由 `de26bea`/`69ccdff`/`5f2441f` 收敛 |
| 6 | `a94bdc4` | fix(queue): 队列身份统一为歌曲键 | PASS-WITH-NOTES（670fd901） |
| 7 | `de26bea` | fix(domain): 兼容旧档数字车道序号 | 已审查（253bb9dc，补充意见撤回 containsKey 校验建议） |
| 8 | `d3760c1` | fix(domain): 收敛场景契约注释并迁移更新服务测试 | PASS-WITH-NOTES（931b3a10） |
| 9 | `3273e97` | fix(gate): 修正会话夹具来源参数类型 | PASS-WITH-NOTES（14c902c8） |
| 10 | `69ccdff` | fix(domain): 加固车道键兼容与旧档断言 | PASS-WITH-NOTES（66e912f1） |
| 11 | `5f2441f` | fix(domain): 明确旧档车道归一语义 | PASS-WITH-NOTES（5555f33a） |
| 12 | `2792aa4` | fix(test): 修正曲目夹具来源参数类型 | PASS-WITH-NOTES（85494840） |
| 13 | `636db7f` | docs(scene): 记录场景 DTO 不迁移决定 | 审查 c0a7999b 复核中（PASS-WITH-NOTES 倾向；其「文档从未列过 domain 版」主张与 git 历史不符，未采纳） |
| 14 | `26cff61` | fix(data): 拒收非有限版本号避免误判整档损坏 | PASS-WITH-NOTES（3176a863） |
| 15 | `4fbc4d9` | refactor(settings): 复用播放层音质档位类型 | PASS-WITH-NOTES（67ee8d3d） |
| 16 | `9974ddd` | docs(domain): 限定车道归一语义的适用范围 | PASS（5555f33a 复审） |
| 17 | `416b7d1` | fix(data): 版本门按值拒收字符串与非整数 | 审查 3176a863 复核中 |

> stage2–5 的 FAIL 是其快照的真实结论，未通过 amend/force 伪装为通过；后续 stage 以独立提交收敛，最终树以第 3 节的静态证据为准。

## 3. 修复明细

### 3.1 队列身份

- `a94bdc4`：`QueueItem.identity` 改为 `track.key`（`provider:kind:id`），与 `PlaybackQueue` 全部查找/替换/恢复路径同域；修复 `_indexOfKey` 恒 `-1`、替换丢选中、`_historyRecordedKey` 恒不命中等潜伏错误。
- 审查 670fd901 确认：identity 不落盘、Qt 不持久化 identity，无需迁移；同时指出 `provider` setter 缓存清理、`updateCurrent` 无测试、`identity` 注释过度声明等 N1–N6 项，其中缓存清理已在并发提交中由 `_resetIdsFromItems()` 覆盖。

### 3.2 浏览车道 schema

- `e218678`：`BrowseSnapshot.selectedLane` 由 `int` 改 `String`（默认 `''`），与 `laneOffsets: Map<String,int>` 同键域。
- `de26bea`：`_laneKey` 兼容旧档数字（`num` → 十进制字符串）。
- `69ccdff`：加 `isFinite` 守卫（`1e401` 解码为 `Infinity` 时 `toInt` 抛 `UnsupportedError`，会拖垮整档恢复）；补 `selectedLane == '2'` 断言。
- `5f2441f`：数字 `0` 归为未选择（`''`），修正 `de26bea` 的 `'0'` 语义漂移；补 2→`'2'`、0→`''`、Infinity→`''` 断言。
- `9974ddd`：注释限定「Dart 旧模型」；注明字符串原样保留（`'0'` 仍是 `'0'`），Qt 的 0 是「搜索结果」列，将来导入 Qt 档须保留 `'0'`。
- 遗留：键域仍有三套（数字串、`'album'`、`'song'`/`'playlist'`），模型不做校验；`selectedLane` 无生产 reader。见 B-07。

### 3.3 场景契约去重

- `d3760c1`：删除 `lib/domain/scene_backend.dart`（`SceneBackendKind`、`SceneFixture`/`SceneState` JSON、`GlesSceneBackend` 副本），场景契约只保留在 `lib/scene/scene.dart`。
- `test/domain/scene_and_update_test.dart` 经 `git mv` 改为 `test/domain/update_service_test.dart`，只保留 `DisabledUpdateService` 用例。
- `636db7f`：在 `docs/scene/M0.5-3d-gate.md:50` 记录 DTO 不迁移；设备阶段若需 MethodChannel 载荷，须在 `lib/scene` 重定义并补往返测试。
- 审查 931b3a10：删除彻底（`git grep domain/scene_backend` 0 命中），`test/scene/scene_backend_test.dart:54-67` 覆盖 GLES kind/load/build/dispose 等价行为；P2-1 `c21a6e8` 单提交不可编译（改名与 import 分属两提交），建议 squash，属历史记录问题。

### 3.4 测试夹具编译错误

- `3273e97`：`test/domain/m1_gate_test.dart:51` 改 `Track(provider: provider.wire)`。
- `2792aa4`：`test/data/session_store_test.dart:25`、`history_store_test.dart:8`、`repositories_test.dart:10` 三处同类错误改 `.wire`。
- 审查 14c902c8/85494840 确认 `MediaItem.provider` 是 `final String`（`library_item.dart:100`），枚举无隐式转换，原代码为硬编译错误；全仓复扫无第二处。

### 3.5 数据版本门

- `26cff61`：`SessionStore.load` 对非有限版本号记 `session.version-mismatch` 并返回 null，不再落入 catch 记 `session.corrupt`。
- `416b7d1`：版本门改为按值比较 `storedVersion != null && storedVersion != expectedVersion`；字符串 `"2"`/`"1"`、`1.5`、`true` 均拒收，缺失 `version` 仍按旧档容忍；补 1e401、字符串/非整数、缺失版本测试。

### 3.6 设置层类型

- `4fbc4d9`：删除 `settings_catalog.dart` 本地 `QualityOption`，复用 `playback_quality.dart` 并 `export show QualityOption`；响应 `QualityOption` 顶层重复声明。
- 审查 67ee8d3d：barrel 可见性、依赖方向、identity 语义均安全；但四张音质表仍在 settings/playback 各存一份，文案漂移风险未消（B-12）。

## 4. 静态审计证据

- import/export 扫描（脚本遍历 `git ls-files`，解析 `import`/`export` URI 并对 `package:rhine_music_database/` 与相对路径做存在性检查）：260 文件，0 处未解析。
- 顶层声明扫描：320 个顶层声明，重复名仅 `_CacheEntry`（两个库各自私有）。
- provider 枚举扫描：对 `Track(`/`MediaItem(` 加词边界后，`provider: MusicProvider.<x>` 传 String 的编译错 0 处；首轮 20 个命中均为 `makeTrack(` 子串误报。
- 场景残留扫描：`git grep "domain/scene_backend"` 与 `git grep "SceneFixture|SceneState.fromJson"` 在 lib/test 无悬空引用。
- 车道引用扫描：`selectedLane` 仅模型与三处测试；测试值 `'2'`、`'album'`、`'playlist'` 与实现兼容，但键域不统一（B-07）。

## 5. 未解静态阻塞与风险

| ID | 阻塞/风险 | 证据 | 解除条件 |
| --- | --- | --- | --- |
| B-04 | 依赖全为 `any` 占位、无 lock，无法 `pub get`/测试 | `pubspec.yaml:43-54`（7 个包 any；文件内注明不得 pub get） | owner 批准精确版本并生成 lock |
| B-05 | CI 不跑 Flutter 静态/测试 | `.github/workflows/desktop.yml`、`scripts/test.cjs` 只跑 ctest+node | 增加 `dart analyze` + `flutter test` job（或合入门禁） |
| B-06 | SessionStore 无生产构造点；Qt 与 Flutter 会话 JSON 顶层形状不同（Qt: `version/library/player/view`，Flutter: `version/provider/…/browse`），都写 `version:1`，无判别字段 | `lib/data/session_store.dart`、Qt `MusicSession.cpp:215-235`；`git grep FileSessionDocumentStore` 无构造点 | 接线前加格式判别与迁移测试 |
| B-07 | `selectedLane` 键域三套并存、无校验、无生产 reader | fixture `'2'`、`m1_gate_test.dart:72` `'album'`、`session_store_test.dart:49` `'playlist'` | 定义 lane 注册表并统一键 |
| B-08 | 场景 JSON DTO 随 domain 副本删除且未迁移，设备阶段无等价实现 | `docs/scene/M0.5-3d-gate.md:50` | 在 `lib/scene` 重定义并补往返测试 |
| B-09 | 播放引擎/桥接/账号/3D 为显式未接线 | `app_adapters.dart`（UnsupportedAudioEngine / UnsupportedAccountGateway / VulkanOnlySceneSelection）、`node_host_bridge.dart`、`app_effects.dart:83-85` | 实现对应适配器并接线 |
| B-10 | 兄弟工作树 `flutter-app-entry` 仍保留 `lib/domain/scene_backend.dart` 与旧测试 import | 审查 931b3a10 实地核查 | 合入前迁移该分支 |
| B-11 | `c21a6e8` 单提交不可编译（删除与测试改名分离） | 审查 931b3a10 | squash 或补中间提交 |
| B-12 | 音质四张表在 settings 与 playback 双份，文案/顺序漂移风险 | `settings_catalog.dart:91-117` vs `playback_quality.dart:28-53` | 单一数据源或 parity 测试 |
| B-13 | `SessionSnapshot.fromJson` 缺失/未知 provider 回退 netease，静默丢非 netease 队列 | 审查 14c902c8；`session.dart:259/263` | 未知 provider 记日志或迁移 |
| B-14 | 有限超大数字车道值饱和为 `9223372036854775807` 幽灵键 | 审查 66e912f1；`num.dart:345-354` | 加范围上限 |
| B-15 | M1 gate 测试存在不可证伪断言（`isUnrecoverable` 恒真、Gate 5 三 store 零共享） | 审查 14c902c8；`m1_gate_test.dart:167/197-219` | 重写为可证伪用例 |

## 6. 未执行的门禁

| 门禁/命令 | 状态 | 原因 |
| --- | --- | --- |
| `dart format` / `dart analyze` | 未执行 | 任务禁止；且依赖未解析 |
| `flutter test` | 未执行 | 同上（`pubspec` 为 any 占位） |
| `flutter build apk` / Gradle | 未执行 | 任务禁止 |
| adb 安装/冷启动/重启恢复 | 未执行 | 无设备，任务禁止 |
| Node 握手、播放、锁屏续播、通知 | 未执行 | 无设备/运行期 |
| 方向/旋转、16 KB 页、字体矩阵 | 未执行 | 无设备 |
| M0.5 3D A/B、ΔE2000/SSIM、Vulkan | 未执行 | 引擎未选定 |
| 抓包/无遥测动态验证、60 分钟并排走查 | 未执行 | 无设备 |

整体对齐状态仍为 **NOT ALIGNED**；本报告只证明「静态集成问题已收敛」，不构成 Gate 0/0.5/1–6 任何一项通过。

## 7. 并发与工作树状态

- 本 worktree 同时有另一执行体在 `flutter-integration` 上提交与改文件；HEAD 在本次工作期间从 `d646aa1` 推进到 `05b6b1e`。
- 本报告父提交 `05b6b1e` 时 `git status` 存在对方未提交的 scene/app/library 修改与 `docs/scene/reviews/` 未跟踪目录；这些改动**不属于本报告作者**，未被我暂存或提交。
- 17 个 stage 提交均以 `git commit --only <精确路径>` 生成，未夹带他人改动。

## 8. 限制

- 全部结论为静态推断；Dart 语义依据本地 SDK 源码（`core/num.dart`、`_internal/vm/lib/double.dart`、`convert_patch.dart`），未实跑。
- 审查者未运行分析器/测试；「编译级」判断基于构造签名与字段类型的逐行核对。
- 行号以报告父提交 `05b6b1e` 为准，后续并发提交可能使其漂移。
