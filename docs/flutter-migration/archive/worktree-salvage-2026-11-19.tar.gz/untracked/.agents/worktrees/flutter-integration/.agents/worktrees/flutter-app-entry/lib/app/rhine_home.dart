import 'package:flutter/material.dart';

import '../ui/core/components/rhine_components.dart';
import '../ui/core/responsive/rhine_responsive.dart';
import '../ui/core/tokens/rhine_tokens.dart';
import 'rhine_composition.dart';
import 'rhine_scene_backends.dart';
import 'rhine_shell.dart';
import 'rhine_status_view.dart';

/// 应用首屏：只搭壳与真实状态，不创建 M3 尚未存在的页面。
class RhineHome extends StatelessWidget {
  const RhineHome({super.key, required this.composition});

  final RhineComposition composition;

  @override
  Widget build(BuildContext context) {
    final RhineLayout layout = context.rhineLayout;
    final RhineColors colors = context.rhineColors;
    final String playbackLabel = composition.playback.isAvailable
        ? composition.playback.label
        : composition.playback.unavailableReason;

    return RhineSystemUiScope(
      colors: colors,
      child: Scaffold(
        backgroundColor: colors.canvas,
        body: SafeArea(
          bottom: false,
          child: RhineShell(
            layout: layout,
            header: const RhineTopBar(
              libraryName: '音乐库',
              totalLabel: '未载入',
            ),
            content: RhineStatusView(composition: composition),
            stage: layout.twoPane
                ? RhineSceneStage(backends: composition.scene)
                : null,
            player: RhinePlayerBar(
              title: '未在播放',
              artist: playbackLabel,
            ),
          ),
        ),
      ),
    );
  }
}
