import 'package:flutter/material.dart';

import '../ui/core/responsive/rhine_responsive.dart';
import '../ui/core/tokens/rhine_spacing.dart';
import 'rhine_composition.dart';
import 'rhine_login_gateway.dart';

/// 首屏状态页：只报告组合根真实装配了什么、缺什么，不发起网络/音频/3D。
///
/// 没有 M3 页面，因此这里不提供伪造的导航入口；所有不可用能力都显示
/// 明确原因，而不是“加载中”或成功态。
class RhineStatusView extends StatelessWidget {
  const RhineStatusView({super.key, required this.composition});

  final RhineComposition composition;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final RhineMetrics metrics = context.rhineMetrics;
    final String account = _accountStatus();
    final String login = _loginStatus();
    final String playback = composition.playback.isAvailable
        ? composition.playback.label
        : composition.playback.unavailableReason;
    final String sceneKinds = composition.scene.registeredBackends
        .map((dynamic backend) => backend.kind.label as String)
        .join(' / ');

    return ListView(
      padding: EdgeInsets.fromLTRB(
        metrics.pageInset,
        RhineSpacing.lg,
        metrics.pageInset,
        RhineSpacing.xxl,
      ),
      children: <Widget>[
        Text(
          'Rhine Flutter 入口',
          style: theme.textTheme.headlineSmall?.copyWith(
            color: theme.colorScheme.onSurface,
          ),
        ),
        const SizedBox(height: RhineSpacing.sm),
        Text(
          '组合根已接管 counter 示例。Node、网络、音频与 3D 渲染均未启动；'
          '以下状态来自实际装配结果。',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: RhineSpacing.xl),
        _StatusSection(
          title: '启动与桥接',
          rows: <_StatusRow>[
            const _StatusRow('Node 宿主', 'Android MethodChannel 已装配；未自动 prepare/start'),
            const _StatusRow('回环桥接', '127.0.0.1:0 + 一次性令牌；调用 startBridge() 才绑定'),
            const _StatusRow('启动顺序', 'prepare → bind → token 握手 → Worker start'),
          ],
        ),
        _StatusSection(
          title: '能力接缝',
          rows: <_StatusRow>[
            _StatusRow('偏好', composition.preferences.storageLabel),
            const _StatusRow('设置', 'SettingsController 已载入；主题/动效即时生效'),
            _StatusRow('账号', account),
            _StatusRow('登录', login),
            _StatusRow('播放', playback),
            _StatusRow('3D', '仅注册 $sceneKinds；GLES 不注册，也不回退 GLES/2D/Qt'),
            const _StatusRow('本地音乐/更新', '接口占位，无 UI 入口'),
            const _StatusRow('导航', 'M3 页面未实现，因此未创建路由或导航目的地'),
          ],
        ),
        _StatusSection(
          title: '门禁与未验证项',
          rows: <_StatusRow>[
            const _StatusRow('插件', '7 个依赖仍为 any；未声明版本，也未执行 pub get'),
            const _StatusRow('本地化', '未加入 flutter_localizations；Material 内建英文文案可能保留'),
            const _StatusRow('设备', '未运行 flutter / Gradle / adb；B4 设备验证未完成'),
            const _StatusRow('回退', '无 GLES / 2D / Qt；不伪造网络、音频或 3D 成功'),
          ],
        ),
      ],
    );
  }

  String _accountStatus() {
    final session = composition.session;
    return '${session.platformLabel} · ${session.accountLabel}（内存账号缓存）';
  }

  String _loginStatus() {
    final gateway = composition.loginGateway;
    if (gateway is RhineLoginGateway) {
      return 'RhineLoginGateway 已装配；网易云二维码待本地渲染';
    }
    return '登录网关已装配：${gateway.runtimeType}';
  }
}

class _StatusSection extends StatelessWidget {
  const _StatusSection({required this.title, required this.rows});

  final String title;
  final List<_StatusRow> rows;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: RhineSpacing.lg),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(RhineSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: theme.textTheme.titleMedium),
              const SizedBox(height: RhineSpacing.md),
              for (final _StatusRow row in rows) row,
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusRow extends StatelessWidget {
  const _StatusRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: RhineSpacing.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            label,
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: RhineSpacing.xxs),
          Text(value, style: theme.textTheme.bodyMedium),
        ],
      ),
    );
  }
}
