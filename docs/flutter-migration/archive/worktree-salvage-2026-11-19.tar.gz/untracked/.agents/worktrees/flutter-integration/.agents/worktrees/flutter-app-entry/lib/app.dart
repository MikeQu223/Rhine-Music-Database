/// Rhine Flutter 应用的唯一入口面。
///
/// 实际组合根实现放在 `app/rhine_app.dart`，这里只导出 `RhineApp`，避免
/// 入口类在多个库中重复定义。main.dart 从这里导入。
library;

export 'app/rhine_app.dart' show RhineApp;
