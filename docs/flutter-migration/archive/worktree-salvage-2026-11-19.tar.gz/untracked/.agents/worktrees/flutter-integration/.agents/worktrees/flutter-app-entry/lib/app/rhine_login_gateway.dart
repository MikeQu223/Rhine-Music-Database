/// 桥接账号/登录适配器：把已提交的 [GatewayAccountRepository] 接到
/// feature 层的 [LoginGateway]，不把网络或二维码实现放进页面。
library;

import '../bridge/music_gateway.dart';
import '../data/credential_store.dart';
import '../data/repositories/gateway_account_repository.dart';
import '../domain/domain.dart';
import '../domain/repositories/account_repository.dart';
import '../features/accounts/accounts.dart';
import 'rhine_account_gateway.dart';

/// 真实登录网关。
///
/// 网易云二维码需要宿主本地渲染，当前没有可用的二维码渲染依赖，因此该
/// 入口明确失败并提示改用短信登录；其余二维码由上游返回图片。
class RhineLoginGateway implements LoginGateway {
  RhineLoginGateway({
    required MusicGateway gateway,
    CredentialStore? credentials,
    void Function(String message)? log,
  })  : _gateway = gateway,
        _repository = GatewayAccountRepository(
          gateway,
          credentials: credentials ?? UnsupportedCredentialStore(),
          log: log,
        );

  final MusicGateway _gateway;
  final GatewayAccountRepository _repository;

  AccountScope get _scope => AccountScope.forProvider(
        _gateway.provider,
        edition: KugouEdition.parse(_gateway.edition),
      );

  void _ensureScope(AccountScope scope) {
    if (scope.provider != _gateway.provider) {
      throw const AccountGatewayUnavailable('账号平台与当前 Node 网关不一致');
    }
    if (scope.isKugou && scope.edition.wire != _gateway.edition) {
      throw const AccountGatewayUnavailable('酷狗版本与当前 Node 网关不一致');
    }
  }

  void _ensureMethod(LoginMethod method) => _ensureScope(method.scope);

  @override
  Future<Account> fetchAccount(AccountScope scope) async {
    _ensureScope(scope);
    return _gateway.account();
  }

  @override
  Future<void> logout(AccountScope scope) async {
    _ensureScope(scope);
    await _repository.logout();
  }

  @override
  Future<QrTicket> createQr({
    required LoginMethod method,
    required String timestamp,
  }) async {
    _ensureMethod(method);
    if (method.provider == MusicProvider.netease) {
      throw const AccountGatewayUnavailable(
        '网易云二维码需要本地渲染，当前未接入；请使用短信登录',
      );
    }
    final QrLoginChallenge challenge = await _repository.beginQrLogin();
    if (challenge.key.isEmpty || challenge.imageData.isEmpty) {
      throw const AccountGatewayUnavailable('上游没有返回可用的二维码图片');
    }
    return QrTicket(key: challenge.key, image: challenge.imageData);
  }

  @override
  Future<QrPollResult> checkQr({
    required LoginMethod method,
    required String key,
    required String timestamp,
  }) async {
    _ensureMethod(method);
    final QrLoginStatus status = await _repository.pollQrLogin(key);
    return QrPollResult(code: status.code, message: status.message);
  }

  @override
  Future<void> cancelQr({
    required LoginMethod method,
    required String key,
  }) async {
    _ensureMethod(method);
    await _repository.cancelQrLogin(key);
  }

  @override
  Future<void> sendSmsCode({required String phone}) async {
    if (_gateway.provider != MusicProvider.netease) {
      throw const AccountGatewayUnavailable('短信登录仅支持网易云');
    }
    await _repository.sendCaptcha(phone);
  }

  @override
  Future<Account> loginWithSms({
    required String phone,
    required String captcha,
  }) async {
    if (_gateway.provider != MusicProvider.netease) {
      throw const AccountGatewayUnavailable('短信登录仅支持网易云');
    }
    final Account account = await _repository.loginWithCaptcha(
      phone: phone,
      captcha: captcha,
    );
    return account;
  }
}
