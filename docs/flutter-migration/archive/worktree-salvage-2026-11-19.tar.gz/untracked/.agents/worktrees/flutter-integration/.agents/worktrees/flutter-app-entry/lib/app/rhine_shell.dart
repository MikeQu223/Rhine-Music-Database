import 'package:flutter/material.dart';

import '../ui/core/responsive/rhine_responsive.dart';

/// 响应式外壳：只负责槽位与两栏/单栏几何，不创建路由或业务页面。
///
/// 竖屏单栏：header → navigation → content；横屏/平板双栏：左侧
/// primaryPaneWidth 放 navigation + content，右侧 secondaryPaneWidth 放
/// stage；player 始终横跨底部。所有尺寸来自 [RhineLayout]，不锁定方向。
class RhineShell extends StatelessWidget {
  const RhineShell({
    super.key,
    required this.layout,
    required this.header,
    this.navigation,
    required this.content,
    this.stage,
    this.player,
  });

  static const Key primaryPaneKey = Key('rhine-shell-primary');
  static const Key secondaryPaneKey = Key('rhine-shell-secondary');
  static const Key playerKey = Key('rhine-shell-player');

  final RhineLayout layout;
  final Widget header;
  final Widget? navigation;
  final Widget content;
  final Widget? stage;
  final Widget? player;

  @override
  Widget build(BuildContext context) {
    final Widget panes = layout.twoPane
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                key: primaryPaneKey,
                width: layout.primaryPaneWidth,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    if (navigation != null) navigation!,
                    Expanded(child: content),
                  ],
                ),
              ),
              const VerticalDivider(width: 1, thickness: 1),
              Expanded(
                key: secondaryPaneKey,
                child: stage ?? const SizedBox.shrink(),
              ),
            ],
          )
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              if (navigation != null) navigation!,
              Expanded(child: content),
            ],
          );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        header,
        Expanded(child: panes),
        if (player != null)
          KeyedSubtree(key: playerKey, child: player!),
      ],
    );
  }
}
